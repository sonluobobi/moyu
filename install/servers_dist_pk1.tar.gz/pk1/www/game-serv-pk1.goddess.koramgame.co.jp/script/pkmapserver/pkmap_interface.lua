--[[
框架入口 c++调用入口函数
--]]
local tostring = tostring
local mapserver_id = g_mapserver_id
local pairs = pairs
local c_opHandlers = c_opHandlers._handlers
local i_opHandlers = i_opHandlers._handlers
local opcodeNames = opcodeNames
local AoiSceneService = AoiSceneService
local CharacterService = CharacterService
local CharacterCtrl = CharacterCtrl
local SceneCtrl = SceneCtrl
local Time = Time
local WorldPacket = WorldPacket
local Logger = Logger
local profile_ontimer=profile_ontimer

local GLOBAL_PROCESS_ID=GLOBAL_PROCESS_ID
local GLOBAL_THREAD_ID=GLOBAL_THREAD_ID

-- 游戏是否已启动并初始化完成
-- 具体点说：c++框架层已调用c_initWorld 函数，lua并已经加载完成所有csv表 
g_is_world_inited = false

--加载LUA脚本完成后（包括reload)
do
	-- 响应LUA脚本加载或热更新完成
	local string_find, string_len = string.find, string.len
	function c_after_load()
		local ReadOnly = ReadOnly
		local gmt = getmetatable(_G)
		
		-- 调用所有service  ctrl 的 onAfterLoadLua(响应LUA脚本加载或热更新完成) 函数
		for cls_name, cls_obj in pairs(_G) do
			if type(cls_obj) == 'table' and cls_obj ~= _G and cls_obj ~= gmt then
				local mt = getmetatable(cls_obj)
				if mt ~= ReadOnly and type(cls_obj.onAfterLoadLua) == 'function' and
					(string_find(cls_name, 'Ctrl') == string_len(cls_name) - 3 or
						string_find(cls_name, 'Service') == string_len(cls_name) - 6)
					then
					cls_obj:onAfterLoadLua()
				end
			end
		end
	end
end

-- 启动初始化
function c_initWorld()
	local area_id = external.getAid()
	if area_id < 970 then print = function()end end
		
	-- 加载所有mapserver相关的csv表
	CsvLoader:load('pkmap')
	
	-- 加载跨服竞技场数据
	GlobalArenaService:load()

	g_is_world_inited = true

	return 12345
end

local function dohandle(request_name, handlers, character, packet)
	local opcode = packet:getOpcode()
	local handler = handlers[opcode]
	
	WorldPacket:prepareReadPacket(packet, opcode)
	
	if not handler then
		local opcode_name = opcodeNames[opcode] or 'unknown'
		Logger:error('pkmapserver no found the function for',request_name,'opcode',opcode,'opcode_name',opcode_name)
	else
	
		if character and request_name == 'c_clientIndex' then	
			--
		end
		
		WorldPacket.g_character = character
		WorldPacket.g_opcode = opcode
		WorldPacket.g_packet_id = packet:getPacketId()
		
		handler(character, packet)
		
		WorldPacket.g_character = 0
		WorldPacket.g_opcode = 0
		WorldPacket.g_packet_id = 0
	end
end

--客户端请求
do
	local upvalue_packet = external.makeNoGcPacket() -- 不会被gc的一块内存，用于在不同mapserver之间迁移角色数据的时候打包属性复用，不会每次都生成新的内存
	function get_upvalue_packet()
		return upvalue_packet
	end

	function c_clientIndex(character, gpid, packet)
		dohandle('c_clientIndex',c_opHandlers,character,packet or upvalue_packet)
	end

	-- 内部请求
	function c_internalIndex(character, gpid, packet)
		dohandle('c_internalIndex',i_opHandlers,character,packet or upvalue_packet)
	end

	--- 玩家离开场景
	-- character
	-- is_diff_map_server : 是否是不同的mapserver
	-- packet_id : 包的id
	function c_leaveMap(character, is_diff_map_server, packet_id)
		WorldPacket.g_packet_id = packet_id
		WorldPacket.g_character = character
		
		-- 不同mapserver就需要利用共享内存来打包角色数据
		local initData = is_diff_map_server and upvalue_packet or nil 
		
		-- AOI对象被删除的时候是否保留appear_bin(appear_bin是一个userdata)
		-- 注：如果是同mapserver迁移，是需要保留appear_bin的，反之回收掉appear_bin
		character.is_keep_appear_bin = not is_diff_map_server 		
		
		-- 里面会根据 is_keep_appear_bin 决定是否保留 appear_bin
		SceneCtrl:leaveScene(character, 1, packet_id)
		
		-- 还原标志位
		character.is_keep_appear_bin = nil
		
		if is_diff_map_server then
			CharacterService:buildInitData(character,initData)
		end
		
		WorldPacket.g_character = 0
		WorldPacket.g_packet_id = 0
		return 12345
	end


	-- 创建lua玩家实体，和c++实体互绑
	-- cplr : 
	-- is_login : 是否是登录第一次调用
	-- packet_id : 包的id
	local push_character_garbage = assert(push_character_garbage)
	function c_initPlayer(cplr, is_login, packet_id)
		WorldPacket.g_packet_id = packet_id
		
		local initData = upvalue_packet
		local character = CharacterCtrl:init(cplr, is_login, initData)
		
		-- 加入角色对象垃圾回收管理
		push_character_garbage(character)
		
		WorldPacket.g_character = 0
		WorldPacket.g_packet_id = 0
		return 1;
	end
end


---进入场景
do
	local params = {}
	function c_enterMap(character, space_id, scene_id, line_id, is_login, packet_id)
		WorldPacket.g_packet_id = packet_id
		WorldPacket.g_character = character
		
		params.space_id = space_id
		params.scene_id = scene_id
		params.line_id = line_id
		params.is_login	= is_login	--第一次登录/切换场景
		params.is_reconnect	= false --是否是掉线重连
		
		SceneCtrl:enterScene(character, params, packet_id)
		
		WorldPacket.g_character = 0
		WorldPacket.g_packet_id = 0

		return 12345
	end
end

---销毁场景
function c_removeSpace(space_id)	
	AoiSceneService:delAoiScene(space_id)
end

-- 每帧调用
do
	local random = math.random
	local floor = math.floor
	local collectgarbage = collectgarbage
	
	local updated_frame = 1				--帧序号
	local last_timeout_frame_num = 0	--最后一次超时的帧序号
	local frame_ms_cd = Config.FRAME_MS_CD	-- 一帧时长
	local next_update_time = 0
	
	local next_collectgarbage = 0
	local getNowUnixUsTime = external.getNowUnixUsTime
	local getNowUnixMsTime = external.getNowUnixMsTime
	--local randomize=external.randomize
	
	function c_update(time_now)
		-- 打乱随机数 不打乱 
		--xbq:改成c++里面randomize 只要5分钟初始化重置随机因子一次就好了 没必要这么频繁 random 也不会改变走向
		--randomize()--		
		--random(1,100)
		
		-- 不到下帧开始时间，返回
		if time_now < next_update_time then return end
		
		-- 计算下载开始时间
		next_update_time = time_now + frame_ms_cd
		
		-- 进入新的帧
		Time:enterFrame(time_now)
		
		-- 更新帧序号
		updated_frame = updated_frame + 1
		-- 帧序号重置
		if updated_frame > 1728000 then
			updated_frame = 1
			last_timeout_frame_num = 0
		end
		
		-- 帧开始之前事件
		AoiSceneService:beforeFrame()
		
		local frame_start_time = getNowUnixMsTime()		-- 帧开始时间点
		local is_entry_new_frame = true					-- 是否进入新的一帧
		local update_obj_num, scene_num = 0, 0
		
		-- 执行帧更新逻辑
		is_entry_new_frame, scene_num, update_obj_num = SceneCtrl:update(time_now, frame_ms_cd, updated_frame)
		
		-- 本帧超时
		-- 改成仅仅警告
		if not is_entry_new_frame then
			--记录耗时帧日志
			local used_time = getNowUnixMsTime() - frame_start_time
			local warn_msg = string.format('\r\n [%u:%u] [c_update] use time(ms):%d, updated_frame:%d, last_timeout_frame_num:%d, frame_ms_cd:%d, update_obj_num:%d, scene_num:%d', GLOBAL_PROCESS_ID,GLOBAL_THREAD_ID,used_time, updated_frame, last_timeout_frame_num, frame_ms_cd, update_obj_num, scene_num)
			Logger:warn(warn_msg)
			
			-- 记录最后一次耗时帧序号
			last_timeout_frame_num = updated_frame
		else
			--
		end
		
		-- 每秒 垃圾回收一次
		if Time.is_second_start then
			collectgarbage('step')
		end

		profile_ontimer(time_now)
				
	end
end

-- 定时器回调
do
	local CharacterService
	local c_internalIndex = c_internalIndex
	function c_timerIndex(packet)
		CharacterService = CharacterService or _G.CharacterService
		local character = CharacterService:getCharacterByGcid(packet:getGcid())		
		WorldPacket.g_packet_id = packet:getPacketId()
		WorldPacket.g_character = character		
		c_internalIndex(character,0,packet)		
		WorldPacket.g_character = 0
		WorldPacket.g_packet_id = 0
	end
end

-- 服务器退出
function c_shutdownWorld()
end

-- 掉线重连
local params = {}
local SceneBaseDao = SceneBaseDao
function c_reconnect(character,packet_id,ip)
	WorldPacket.g_packet_id = packet_id
	WorldPacket.g_character = character
	
	CharacterCtrl:reconnect(character)
	
	WorldPacket.g_character = 0
	WorldPacket.g_packet_id = 0
end

--离线之前Base向Map请求确认当前是否允许玩家离线 目前基本上都返回true
function c_try_logout(character,packet_id)
	WorldPacket.g_packet_id = packet_id
	WorldPacket.g_character = character
	
	CharacterCtrl:try_logout(character, packet_id)
	
	WorldPacket.g_character = 0
	WorldPacket.g_packet_id = 0
	return true
end

-- 离线退出游戏
function c_logout(character, packet_id)
	WorldPacket.g_packet_id = packet_id
	WorldPacket.g_character = character
	
	CharacterCtrl:logout(character, packet_id)
	
	WorldPacket.g_character = 0
	WorldPacket.g_packet_id = 0
	
end

--关闭服务器时保存数据
function c_save_table(character)
end

