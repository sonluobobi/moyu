--[[
摇骰子奖励系统 CTRL
author : xingzeng.jiang
date : 2014-07-15
--]]

RewardShaiziCtrl = RewardShaiziCtrl or {}
local RewardShaiziCtrl = RewardShaiziCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local external = external
local send_error = WorldPacket.m2cSendDebugError
local errorCodes = errorCodes
local RewardShaiziService = RewardShaiziService

do
	local msg_name = "PackHorse.C2PKM_REWARD_SHAIZI_FINISH"
	function RewardShaiziCtrl.c2m_yaoShaiziFinish(character, packet)
		local params = packet:readParams(msg_name)
		local jie_id = params.jie_id
		
		if jie_id <= 0 then
			send_error('[c2m_yaoShaiziFinish] params error')
			return
		end
		
		RewardShaiziService:assignReward(character, jie_id)
	end
	c_opHandlers[opCodes.C2PKM_REWARD_SHAIZI_FINISH] = RewardShaiziCtrl.c2m_yaoShaiziFinish
end

