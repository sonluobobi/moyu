--[[
运营活动系统 CTRL
author : xingzeng.jiang
date : 2014-07-15
--]]

OpeActivityCtrl = OpeActivityCtrl or {}
local OpeActivityCtrl = OpeActivityCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local external = external
local send_error = WorldPacket.m2cSendDebugError
local errorCodes = errorCodes

-- 游戏服活动数据同步到跨服
do
	function OpeActivityCtrl.b2m_syncOpeActivitys(_, params)
		local activity_items = params.activity_items
		local area_id = params.area_id
		
		if not area_id or not activity_items then
			Logger:fatal('[OpeActivityCtrl.b2m_syncOpeActivitys]activity_items is nil', params)
			return 
		end
		
		OpeActivityService:saveActivityItems(area_id, activity_items)
	end
end

