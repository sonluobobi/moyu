--[[
角色装备栏系统ctrl
author : xingzeng.jiang
]]--

local c_opHandlers = c_opHandlers
local opCodes = opCodes
local WorldPacket = WorldPacket
local send_error = WorldPacket.m2cSendDebugError

ChSkillCtrl = ChSkillCtrl or {}

local f_sk_skill_id = 'skill_id'
local f_sk_level = 'level'

-- 获取角色技能信息
do
	function ChSkillCtrl.c2m_getChSkillsInfo(character, packet)
		ChSkillService:sendChChSkillsInfo(character)
	end
	c_opHandlers[opCodes.C2M_CH_SKILL_SKILLS_INFO_GET] = ChSkillCtrl.c2m_getChSkillsInfo
end

-- 更新技能槽
--[[
do
	local msg_name = "PackSkill.C2M_CH_SKILL_SLOT_UPDATE"
	function ChSkillCtrl.c2m_updateSkillSlot(character, packet)
		local params = packet:readParams(msg_name)
		local order_by = params.order_by
		local skill_id = params.skill_id
		
		if order_by <= 0 or skill_id <= 0 then
			send_error('[c2m_updateSkillSlot] params error')
			return
		end
		
		local is_ok, err_id, err_params = ChSkillService:updateSkillSlot(character, order_by, skill_id, true)
		if not is_ok then
			send_error(err_id, err_params)
			return
		end
		-- 更新战力
		CharacterService:updateChFightCapacity(character, true)
		
	end
	c_opHandlers[opCodes.C2M_CH_SKILL_SLOT_UPDATE] = ChSkillCtrl.c2m_updateSkillSlot
end
]]
