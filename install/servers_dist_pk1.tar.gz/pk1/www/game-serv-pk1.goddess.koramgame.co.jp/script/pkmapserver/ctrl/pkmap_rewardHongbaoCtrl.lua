--[[
抽红包奖励系统 CTRL
author : xingzeng.jiang
date : 2014-07-15
--]]

RewardHongbaoCtrl = RewardHongbaoCtrl or {}
local RewardHongbaoCtrl = RewardHongbaoCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local external = external
local send_error = WorldPacket.m2cSendDebugError
local errorCodes = errorCodes
local RewardHongbaoService = RewardHongbaoService

do
	local msg_name = "PackRewardHongbao.C2M_REWARD_HONGBAO_FETCH"
	function RewardHongbaoCtrl.c2m_chouHongbao(character, packet)
		local params = packet:readParams(msg_name)
		local jie_id = params.jie_id
		
		if jie_id <= 0 then
			send_error('[c2m_chouHongbao] params error')
			return
		end
		
		RewardHongbaoService:chouHongbao(character, jie_id)
	end
	c_opHandlers[opCodes.C2M_REWARD_HONGBAO_FETCH] = RewardHongbaoCtrl.c2m_chouHongbao
end

