--[[
GM
author : xingzeng
date : 2012-03-27
]]--

local opCodes = opCodes
local Utils = Utils
local WorldPacket = WorldPacket
local UNumber = UNumber
local strLen = string.len
local send_error = WorldPacket.m2cSendDebugError
local my_area_id = external.getAid()
local my_varea_id = external.getVouchAid()

local remote_debug_fn = nil
local str2Int=UNumber.str2Int
local random = math.random
GM = GM or {packet_id = 0, is_command = false, is_rsp = false}

function GM.b2m_main(character, packet)
	-- 获取参数
	local arr_params, packet_id = packet:readParams()
	local method = arr_params.method
	local rsp_gpid = UNumber.str2Int(arr_params.rsp_gpid)
	local is_gm_token = arr_params.is_gm_token
	
	-- 设置packet_id
	GM.packet_id = packet_id
	GM.is_command =  Utils.isFromCommand(packet_id)
	GM.is_rsp = false
	
	-- 检查参数
	if rsp_gpid <= 0 or 
		method == nil then
		error('[GM.main]param error')
	end
	
	-- 检查角色是否为GM帐户
	if not GM:_validPermit(character, is_gm_token, method) then
		return GM:rspGM(rsp_gpid, '你没有权限执行GM命令')
	end
	
	-- 修改 g_packet_id 为 0
	if GM.is_command then
		WorldPacket.g_packet_id = 0
	end
	
	-- 执行调度
	local deal_func = GM[method]
	if deal_func == nil then
		error('[GM.main] error method:' .. method)
	end
	deal_func(character, arr_params, packet)

	-- 补回包，避免WEB端的GM CLIENT 阻塞住
	if not GM.is_rsp then
		GM:rspGM(rsp_gpid, "GM指令执行完成")
	end

	do
		return
	end
	-- 重算属性(用于检查战力出现下降的情况)
	if method == 'attrib_to_test' or method == 'attrib_to_r'  then 
		return 
	end
--[[	local fight_pet = ChPetService:getFightChPet(character)
	local heti_w_pet = ChPetService:getHeTiChPetByOrderBy(character, PetDefs.HETI_POS_OUT)
	local heti_n_pet = ChPetService:getHeTiChPetByOrderBy(character, PetDefs.HETI_POS_IN)
	if fight_pet then 
		ChPetService:calcChPetEffectValues(character, fight_pet, true)
	end
	if heti_w_pet then 
		ChPetService:calcChPetEffectValues(character, heti_w_pet, true)
	end	
	if heti_n_pet then 
		ChPetService:calcChPetEffectValues(character, heti_n_pet, true)
	end	
	-- 重算角色战力
	CharacterService:calCharacterAttrib(character, true)	
]]
end
i_opHandlers[opCodes.B2M_COMMON_GM] = GM.b2m_main

-- 检查权限
-- 这里不与BASESERVER公用权限认证方法，方便做一些额外的权限认证
function GM:_validPermit(character, is_gm_token, method)
	--TEST 
	
	local is_valid = false
	
	if false and Config.GAME_AREA_CODE == Config.TEST_GAME_AREA_CODE then
		is_valid = true
	elseif my_area_id==900 then
	   	is_valid = true
	elseif my_area_id>=980 and my_area_id<=999 then
        is_valid = true
    elseif not Language:isCN() and my_area_id>=800 and my_area_id<=900 then
        is_valid = true	
	elseif character and character.is_gm and character.is_gm >= 1 then
		is_valid = true
	elseif Config.PROXY_SERVER_IP and Config.PROXY_SERVER_IP == '14.17.124.159' then
		is_valid = true
	elseif Config.PROXY_SERVER_IP and Config.PROXY_SERVER_IP == '42.62.23.214' then --内部测试pk服
		is_valid = true
	elseif is_gm_token == '(*&#FHKE9|8347&' and (method == 'getMemData' or method == 'getChData') then
		is_valid = true
	end
	if my_varea_id == 2078001 or my_varea_id == 2104002 or my_varea_id == 2104902 or my_varea_id == 2104001 or my_varea_id == 2104901 then
		is_valid = true
	end
	return is_valid
end

-- 执行注入的LUA脚本(GM指令)
function GM.do_inject_cmd(character, arr_params)
	local rsp_gpid = UNumber.str2Int(arr_params.rsp_gpid)
	
	if remote_debug_fn == nil then
		remote_debug_fn = debug_open()
	end
	
	local ret_data = remote_debug_fn(character, arr_params.inject_cmd_str)
	
	return GM:rspGM(rsp_gpid, ret_data)
end

-- 持久化玩家的数据到DB
function GM.save2db(character, arr_params)
	local rsp_gpid = UNumber.str2Int(arr_params.rsp_gpid)
	local cid = UNumber.str2Int(arr_params.cid)
	
	if cid > 0 then
		character = CharacterService:getCharacterById(cid)
		if character == nil then
			error(' cid is not exist')
		end
	end
	
	CharacterService:saveDirtyToDB(character,  CharacterDefs.SAVE_TYPE_NORMAL)
	return GM:rspGM(rsp_gpid, 'save to db ok')
end

-- 获取内存的数据
function GM.getMemData(character, arr_params)
	local note_tree = arr_params.note_tree
	local rsp_gpid = UNumber.str2Int(arr_params.rsp_gpid)
	local note = _G
	
	if not table.isTableEmpty(note_tree) then
		for _, note_name in ipairs(note_tree) do
			note_name = GM:_formatNoteName(note_name)
			note = note[note_name]
		end
	end
	
	if note == nil then
		return GM:rspGM(rsp_gpid, 'note == nil')
	end
	
	local note_new = {}
	for k, v in pairs(note) do
		if type(v) ~= 'function' and 
		(note ~= _G or string.find(k, 'Dao') or string.find(k, 'Defs') or string.find(k, 'Config')) then
			note_new[k] = v
		end
	end

	note_new = GM:_format(note_new)
	
	return GM:rspGM(rsp_gpid, note_new)
end

-- 获取玩家的数据
function GM.getChData(character, arr_params)
	local note_tree = arr_params.note_tree
	local rsp_gpid = UNumber.str2Int(arr_params.rsp_gpid)
	local note = character
	
	if not table.isTableEmpty(note_tree) then
		for _, note_name in ipairs(note_tree) do
			note_name = GM:_formatNoteName(note_name)
			note = note[note_name]
			--table.dump(note_name, note, 1)
		end
	end
	
	if note == nil then
		return GM:rspGM(rsp_gpid, 'note == nil')
	end
	
	note = GM:_format(note)
	return GM:rspGM(rsp_gpid, note)
end

-- 修改角色的数据(不可以修改元宝)
function GM.setMemData(character, arr_params)
	local new_value = arr_params.new_value
	local note_tree = arr_params.note_tree
	local rsp_gpid = UNumber.str2Int(arr_params.rsp_gpid)
	local isSave = arr_params.isSave or true		-- 默认持久化
	local old_value = nil

	-- check
	local idx, k = next(note_tree)
	if k == 'gold' then
		k = 'game_gold'
		note_tree[idx] = k
	end
		
	if k == 'level' then
		old_value = character.level
	end

	if not character[k] then
		print('GM 指令错误:不存在的角色属性字段 ' .. k)
		return GM:rspGM(rsp_gpid, 'GM 指令错误:不存在的角色属性字段 ' .. k)
	end
	
	local rsp_data = GM:_setMemData(note_tree, new_value, character)
	
	if isSave then
		local data = {}
		
		if k == 'gold' then k = 'game_gold' end
		data[k] = tonumber(new_value)
		
		CharacterService:key2Dirty(character, k)
		if k == "game_gold" then CharacterService:sendCharacterUpdate(character, "gold") end
		CharacterService:sendCharacterUpdate(character, k)
		
		if k == "level" then			
			-- 响应升级成功
			local ret_data = {}
			ret_data.opcode = opCodes.M2C_CHARACTERS_UPGRADE_LEVEL
			WorldPacket:m2cSendOK(ret_data, nil, character.gpid)
			
			-- 触发幻兽自动升级
			ChPetService:onCharacterLevelUp(character)
	
			-- 功能开启
			FuncOpensService:onLevelUp( character, old_value )
		end

		if k == 'vip' then
			CounterService:onVipUp( character )
		end
	end
	
	GM:rspGM(rsp_gpid, rsp_data)
end

function GM:_format(ret_data, formated_data)
	if formated_data == nil then formated_data = {} end

	if not table.isTableEmpty(ret_data) then
		local i = 0
		
		for k, v in pairs(ret_data) do
			-- 仅仅显示前300个，避免查看内存页面卡死
			if i > 200 then
				formated_data["____more"] = "太多后面不显示"
				break
			end
			
			local new_k
			local type_k = type(k)
			if type_k == 'number' then
				new_k = string.format('n|||%d', k)
			elseif type_k == 'string' or type_k == 'boolean' then
				new_k = k
			else
				new_k = tostring(k)
			end
			
			if table.isTable(v) then
				formated_data[new_k] = tostring(v)
			elseif type(v) == 'userdata' then
				--formated_data[k] = nil
			else
				formated_data[new_k] = v
			end
		end
	end
	
	if not next(formated_data) then
		return "数据为空"
	end
	
	return formated_data
end

function GM:rspGM(rsp_gpid, ret_data)
	-- 还原 packet id
	WorldPacket.g_packet_id = GM.packet_id
	
	local rsp_pack = {}
	rsp_pack.data = ret_data
	rsp_pack.opcode = opCodes.M2C_COMMON_GM
	
	WorldPacket:m2cSendOK(rsp_pack, nil, rsp_gpid)
	
	-- 标志已RSP
	GM.is_rsp = true
end

function GM:_formatNoteName(note_name)
	if note_name == nil then return nil end
	
	local first_char = string.byte(note_name, 1)
	local second_char = string.byte(note_name, 2)
	--if first_char > 48 and first_char <= 57 then
	if first_char == 110 and second_char == 124 and string.len(note_name) > 2 then-- note_name prefix='n|'
		local note_name_number = tonumber(string.sub(note_name, 3))
		if note_name_number ~= nil and note_name_number ~= false then
			note_name = note_name_number
		end
	end
	
	return note_name
end

function GM:_setMemData(note_tree, new_v, root)
	local note = root == nil and _G or root
	local parent_note, note_name
	
	if not table.isTableEmpty(note_tree) then
		for _, note_n in ipairs(note_tree) do
			note_name = GM:_formatNoteName(note_n)
			parent_note = note
			note = parent_note[note_name]
		end
	end
	
	if note == nil then
		return 'note == nil'
	end
	
	local note_vtype = type(note) 
	if note_vtype == 'number' or note_vtype == 'string' or note_vtype == 'boolean' then
		parent_note[note_name] = new_v
		return 'map set value ok:'..note_name
	end

	return 'set value fail'
end


--简单测试
function GM.gmtest(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	local cmd=params[1]
	if cmd=='' then	
	end
	
end 

--玩家升级
function GM.uplev(character, arr_params,packet)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded


	local nLevAdd = 1
	if params and #params>=1 then
	   nLevAdd=UNumber.str2Int(params[1])--arr_params.p1)
	end 
	if nLevAdd<=0 then
	  nLevAdd = 1
	end
	
	print('uplev:',nLevAdd)
	
	if character.level>=CharacterDefs.CHARACTER_LEVEL_MAX then
		GM:rspGM(rsp_gpid, "uplev ok.max level reached:"..CharacterDefs.CHARACTER_LEVEL_MAX)	
		return
	end
	local nLevDeltaReal=0
	for k=1,nLevAdd do
	    nLevDeltaReal=nLevDeltaReal+1
		character.exp=character.upgrade_exp
		CharacterCtrl.c2m_levelUp(character, packet)
	end
	
	GM:rspGM(rsp_gpid, "uplev ok.lev delta real:".. nLevDeltaReal..' now level:'..character.level..' nLevAdd:'..nLevAdd)	
end 

--宠物升级
local function uplev_pet(character,ch_pet,nLevAdd)	
	local PetExpBaseDao_quality_lev_2entitys = PetExpBaseDao.quality_lev_2entitys
	local nNewLev=ch_pet.level+nLevAdd
	local nLevDeltaReal=0
	for k=1,nLevAdd do	
		if ch_pet.level >= character.level then
			break
		end				    	
		if ch_pet.level >= PetDefs.MAX_PET_LEVEL then
			break;
		end
		if ch_pet.level >= ch_pet.max_level then
			--期望的等级太高必须先突破	 这里自动突破
			--GM:rspGM(rsp_gpid, "uplevpet info.auto break level.")
			local max_level = ch_pet.max_level
			local break_lev_equip_id, breaked_lev = PetBreakLevBaseService:getBreakLevelEquipId(max_level, ch_pet.pet_base.sort_id)
			ChPetService:incPetAttrib(character, ch_pet, 'max_level', breaked_lev-max_level, true)
			
			-- RSP
			ChPetService:sendPetBreakLevel(character, ch_pet_id)
			
			-- 自动升级
			ChPetService:upgrade(character, ch_pet)
			
			GM:rspGM(rsp_gpid, "uplevpet info.auto break level.max_level:"..max_level..' breaked_lev:'..breaked_lev)
		end
		if ch_pet.level >= ch_pet.max_level then
		  --突破完等级还是到顶
		  break
		end
		if ch_pet.level >= character.level then
			break
		end		
		if ch_pet.level >= nNewLev then
			break
		end
			
	    nLevDeltaReal=nLevDeltaReal+1
	    
			
		-- 升级
		local quality = ch_pet.pet_base.quality
		local pet_upgrade_exp = PetExpBaseDao_quality_lev_2entitys[quality][ch_pet.level+1]
		pet_upgrade_exp = pet_upgrade_exp and pet_upgrade_exp.exp or 2147483647
		
		ch_pet.exp=pet_upgrade_exp
		local is_ok, err_id = ChPetService:upgrade(character, ch_pet)
		if not is_ok then
		
			ChPetService:sendGetChPetDetail(character, ch_pet)
			
		    return false,nLevDeltaReal,err_id
		end
		
		-- RSP
		ChPetService:sendPetUpgrade(character, ch_pet.id)
		
	end
	
	ChPetService:sendGetChPetDetail(character, ch_pet)
		
	return true,nLevDeltaReal
end

--宠物升级
function GM.uplevpet(character, arr_params,packet)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
	local idPet = UNumber.str2Int(params[1])--arr_params.p1)
	
	local ch_pet = ChPetService:getChPet(character, idPet)
		
	if not ch_pet then	   
		GM:rspGM(rsp_gpid, "uplevpet error.not pet for idPet:",idPet)	
		return
	end
	
	local nLevAdd = 1
	if #params>=2 then
	   nLevAdd=UNumber.str2Int(params[2])--arr_params.p1)	   
	end 
	if nLevAdd<=0 then
	  nLevAdd = 1
	end
	
	local bOK,nLevDeltaReal,err_id=uplev_pet(character,ch_pet,nLevAdd);
	if not bOK then
	   GM:rspGM(rsp_gpid, "uplevpet error.ChPetService:upgrade failed.idPet:",idPet,' err_id:',err_id)	
	else		
		GM:rspGM(rsp_gpid, "uplevpet ok.idPet:"..idPet.." lev delta real:".. nLevDeltaReal..' now level:'..ch_pet.level..' max_level:'..ch_pet.max_level..' chLevel:'..character.level.. ' nLevAdd:'..nLevAdd)	
	end
end 


--所有宠物升级
function GM.uplevpetall(character, arr_params,packet)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
		
	local nLevAdd = 1
	if params and #params>=1 then
	   nLevAdd=UNumber.str2Int(params[1])--arr_params.p1)	   
	end 
	if nLevAdd<=0 then
	  nLevAdd = 1
	end
	
	local pets_info = character.pets	
	local ch_pets = pets_info.ch_pets
	for idPet, ch_pet in pairs(ch_pets) do		
		local PetExpBaseDao_quality_lev_2entitys = PetExpBaseDao.quality_lev_2entitys
			
		local nLevDeltaReal=0
		for k=1,nLevAdd do	
			if ch_pet.level >= character.level then
				break
			end		
			if ch_pet.level >= ch_pet.max_level then
				break
			end		
			nLevDeltaReal=nLevDeltaReal+1
		    
				
			-- 升级
			local quality = ch_pet.pet_base.quality
			local pet_upgrade_exp = PetExpBaseDao_quality_lev_2entitys[quality][ch_pet.level+1]
			pet_upgrade_exp = pet_upgrade_exp and pet_upgrade_exp.exp or 2147483647
			
			ch_pet.exp=pet_upgrade_exp
			local is_ok, err_id = ChPetService:upgrade(character, ch_pet)
			if not is_ok then
				GM:rspGM(rsp_gpid, "uplevpet error.ChPetService:upgrade failed.idPet:",idPet)	
				break
			end
			
			-- RSP
			ChPetService:sendPetUpgrade(character, idPet)
		end
		GM:rspGM(rsp_gpid, "uplevpet .ok .idPet:" ..idPet.." lev delta real:".. nLevDeltaReal..' now level:'..ch_pet.level)
	end	
	GM:rspGM(rsp_gpid, "uplevpet ok.lev delta real:".. nLevDeltaReal..' now level:'..ch_pet.level)
end 

--宠物合体
function GM.hetipet(character, arr_params,packet)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
	local idPet = UNumber.str2Int(params[1])
	
	local order_by=1--默认内层合体
	if #params>=2 then
	   order_by=UNumber.str2Int(params[2])
	end
	
	local ch_pet = ChPetService:getChPet(character, idPet)
		
	if not ch_pet then	   
		GM:rspGM(rsp_gpid, "hetipet error.not pet for idPet:"..idPet)	
		return
	end
	
	-- 判断是否开放
	local open_func_id = order_by == PetDefs.HETI_POS_IN and OpenFuncDefs.ID_FOR_HETI_NEI or OpenFuncDefs.ID_FOR_HETI_WAI
	if not FuncOpensService:isOpen(character, open_func_id) then
		GM:rspGM(rsp_gpid, "角色等级不够")
		return
	end
	
	local is_ok, err_id = ChPetService:setHetiPet(character, order_by, idPet)
	if not is_ok then
		GM:rspGM(rsp_gpid, "hetipet error."..err_id)
		return 
	end
	GM:rspGM(rsp_gpid, "hetipet ok.order_by:"..order_by.." idPet:"..idPet)
end

function GM.server_configs(character, arr_params,packet)
    Logger:error("server_configs：",PkserverMappingService:getGroupIds(9))
end

--宠物出战
function GM.setfightpet(character, arr_params,packet)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
	
	--table.dump('setfightpet params:',params,-1)
	
	local idPet = UNumber.str2Int(params[1])--arr_params.p1)
	
	local ch_pet = ChPetService:getChPet(character, idPet)
		
	if not ch_pet then	   
		GM:rspGM(rsp_gpid, string.format("setfightpet error.not pet for idPet:%d",idPet))	
		return
	end

	-- PVP场景不能设置出战幻兽
	--local scene_base = SceneBaseService:getSceneBaseById(character.scene_id)
	--local scene_sort_id = scene_base.scene_sort_id
	--if scene_sort_id == SceneDefs.SCENE_SAFE_MODE_PVP or scene_sort_id == SceneDefs.SCENE_SAFE_MODE_PVPE then
	--	GM:rspGM(rsp_gpid, "setfightpet error.PVP_SCENE_NO_SET_FIGHT idPet:",idPet," err_id:",err_id)	
	--	return 
	--end
	
	local is_ok, err_id = ChPetService:setFightPet(character, idPet)
	if not is_ok then
		GM:rspGM(rsp_gpid, string.format("setfightpet error. idPet:%d  err_id:%d",idPet,err_id))	
		return 
	end
	GM:rspGM(rsp_gpid, string.format("setfightpet ok.idPet:%d",idPet))
end

--宠物信息查询
function GM.pet(character, arr_params,packet)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
	local idPet = UNumber.str2Int(params[1])--arr_params.p1)
	
	local ch_pet = ChPetService:getChPet(character, idPet)
		
	if not ch_pet then	   
		GM:rspGM(rsp_gpid, "pet error.not pet for id:",idPet)	
		return
	end
	
	local txt
	for k, v in pairs(ch_pet) do
	    if (type(v)=="string" or type(v)=="number" or type(v)=="float") then
	        if txt then
	          txt=txt..","
	        else
	          txt=""
	        end
	        txt=txt.. k.."="..v
		end
	end
	
	if not txt then txt="" end
	GM:rspGM(rsp_gpid, "pet ok."..txt)	
end 


--修改角色数据
function GM.setchattr(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
	local attr_name=params[1]--arr_params.p1
	
	local attr=character[attr_name]
	if not attr then
	   print("setchattr error.attr_name:"..attr_name .. " attr_val:"..attr_val)
	   return 
	end
	local attr_val 
	if type(attr)=='string' then
	   attr_val=params[2]
	else
		attr_val=UNumber.str2Int(params[2])--arr_params.p3)
	end
	
	if attr_name == 'gold' then attr_name = 'game_gold' end
	
	if true then
		character[attr_name]=attr_val
			
		CharacterService:key2Dirty(character, attr_name)
		if attr_name == "game_gold" then CharacterService:sendCharacterUpdate(character, "gold") end
		CharacterService:sendCharacterUpdate(character, attr_name)		
	end
	
	GM:rspGM(rsp_gpid, "setchattr ok.".. attr_name .." attr_val:" ..attr_val)		
end 

--查询角色数据
function GM.getchattr(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
	
	--table.dump( "getchattr:", params, 10 )
	
	local attr_name=params[1]--arr_params.p1
		
	local attr_val=character[attr_name]
	if not attr_val then
	   GM:rspGM(rsp_gpid,"getchattr error.attr_name:"..attr_name )
	   return 
	end
			
	GM:rspGM(rsp_gpid, "getchattr ok.attr_name:".. attr_name .." attr_val:" ..attr_val)		
end 

--查询宠物列表
function GM.pets(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	local pets=character.pets
	
	local k=0
	
	local txt
	
	local pets_info = character.pets	
	local ch_pets = pets_info.ch_pets
	for id, pet in pairs(ch_pets) do
	    k=k+1
		if txt then
		  txt=txt.. ","
		else
		  txt=""
		end
		txt= txt.."["..k.."] idPet:"..pet.id.. " pet_id:"..pet.pet_id.." ("..pet.pet_base.nick..")".." level:"..pet.level.." star:" .. pet.star	
		--table.dump("ch_pet:", pet, 1)
	end
	
	if not txt then txt="" end
	
	GM:rspGM(rsp_gpid,"pets ok."..txt)	
end 

--修改宠物数据
function GM.setpetttr(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
	local idPet = UNumber.str2Int(params[1])--arr_params.p1)
	local attr_name=params[2]--arr_params.p2
	
	local pet = ChPetService:getChPet(character, idPet)
		
	if not pet then	   
		GM:rspGM(rsp_gpid, "getpetattr error.not pet for idPet:",idPet)	
		return
	end
	local attr=pet[attr_name]
	if not attr then
		GM:rspGM(rsp_gpid, "setpetattr error. idPet:"..idPet.." attr_name:"..attr_name .. " attr_val:"..attr_val)	
	   return 
	end
	local attr_val 
	if type(attr)=='string' then
	   attr_val=params[3]
	else
		attr_val=UNumber.str2Int(params[3])--arr_params.p3)
	end
	pet[attr_name]=attr_val
		
	---保存宠物属性
	CharacterService:key2Dirty(character, "pets")	
	--CharacterService:sendCharacterUpdate(character, "pets")		
	
	local attrs={attr_name}
	ChPetService:sendChPetUpdate(character, pet, attrs)
		
	GM:rspGM(rsp_gpid, "setpetattr ok.idPet:"..idPet.." attr_name:".. attr_name .." attr_val:" ..attr_val)		
end 

--查询宠物数据
function GM.getpetattr(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local params = arr_params.params_decoded
	local idPet = UNumber.str2Int(params[1])--arr_params.p1)
	local attr_name=params[2]--arr_params.p2
	
	local pet = ChPetService:getChPet(character, idPet)
		
	if not pet then	   
		GM:rspGM(rsp_gpid, "getpetattr error.not pet for idPet:",idPet)	
		return
	end
	
		
	local attr_val=pet[attr_name]
	if not attr_val then
	   GM:rspGM(rsp_gpid,"getpetattr error.idPet:"..idPet.." attr_name:"..attr_name )
	   return 
	end
				
	GM:rspGM(rsp_gpid, "getpetattr ok.attr_name:".. attr_name .." attr_val:" ..attr_val)			
end 

function GM.skills_reinit( character, arr_params )
	character.skills = nil
	ChSkillService:init(character)
	ChSkillService:sendChChSkillsInfo(character)
	ChSkillService:sendChChSkillSlotInfo(character)
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "skills_reinit ok")		
end

--查询技能列表
function GM.skills(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local k=0
	
	local txt
	
	local skills = character.skills
	local ch_skills = skills.ch_skills
	
	for _,skill in pairs(ch_skills) do
	    k=k+1
		if txt then
		  txt=txt.. ","
		else
		  txt=""
		end
		txt= txt.."{skill_id="..skill.skill_id..",level="..skill.level.."}"
		--txt= txt.."["..k.."] idPet:"..pet.id.. " pet_id:"..pet.pet_id.." ("..pet.pet_base.nick..")".." level:"..pet.level.." star:" .. pet.star	
		--table.dump(k.." skill:", skill, 1)
	end
	
	if not txt then txt="" end
	
	GM:rspGM(rsp_gpid,"skills ok."..txt)	
end 



--升级玩家技能
function GM.uplevskill(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
end

--查询服务端内存中角色信息
function GM.svrrole(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	
	local txt="svrrole ok.roleinfo:x:"..character.x .." y:"..character.y..' id:'..character.id..' gcid:'..character.gcid..' gpid:'..character.gpid..' scene_id:'..character.scene_id..' space_id:'..character.space_id..' playerid:'..character.player_id .. ' aid:'..character.area_id .. ' nick:'..character.nick
	
	txt=txt..' hp:'..character.hp
	txt=txt..' hp2:'..character.hp2
	txt=txt..' hp3:'..character.hp3
	
	txt=txt..' max_hp:'..character.max_hp
	txt=txt..' max_hp2:'..character.max_hp2
	txt=txt..' max_hp3:'..character.max_hp3
		
	GM:rspGM(rsp_gpid, txt)		
	--WorldPacket:m2cSendOK(nil, nil, character.gpid,txt)
end 


--查询宠物技能列表
function GM.petskills(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid

	GM:rspGM(rsp_gpid, "petskills error.not implemented yet!")
end 


--复活
function GM.relive(character, arr_params)	
	ReliveService:characterRelive(character)

	-- 通知其他模块
	TollgateService:onRelive(character)
end 

--添加道具到某角色
function GM.equip_add(character, arr_params)
	local cid = arr_params.cid or character.id
	local params = arr_params.params_decoded
	local equip_id = str2Int(arr_params.equip_id or (params and params[1]))
	local num_str=arr_params.value or (params and params[2])
	if not num_str then
	  num_str="1"
	end
	local value = str2Int(num_str)
	local rsp_gpid = arr_params.rsp_gpid
	local add_equip = {}
	add_equip[equip_id] = value
	
	local equip_base = EquipBaseService:getEquipBaseById(equip_id)
	if EquipDefs:isPetBaowuChip(equip_base.equip_sort_id) then
		return GM:rspGM(rsp_gpid, "equip_add error.宝物碎片，得用GM指令:bwchip_add ")
	end
	
	local result, errorcode = ChItemPackageService:addEquip(character, add_equip, true)
	if not result then
		return	WorldPacket:m2cSendErr(nil, nil, rsp_gpid, errorcode)
	end
	
	GM:rspGM(rsp_gpid, "equip_add ok.")
end

--添加道具到某角色
function GM.awarditem(character, arr_params)
    return GM.equip_add(character,arr_params)
end

-- 获得幻兽
function GM.pet_obtain(character, arr_params)
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded
	local pet_id = UNumber.str2Int(params[1])
	local pet_level= 0
	if #params>=2 then
	   pet_level = UNumber.str2Int(params[2])
	end
	
	if ChPetService:isOwnPetNumFull(character) then	
		GM:rspGM(rsp_gpid, "pet_obtain error.too many pet.")
	else	
		local pet_base = PetBaseDao.data[pet_id]
		if not pet_base then
			GM:rspGM(rsp_gpid, "pet_obtain.invalid pet_id.",pet_id)
			return
		end
		local ch_pet, err_id = ChPetService:addChPet(character, pet_base, false, true)
		if not ch_pet then
			send_error(err_id)
	
			GM:rspGM(rsp_gpid, "pet_obtain error.failed to addChPet.")
			return 
		end
		local nLevAdd=pet_level-1
		if(nLevAdd>0) then
			local bOK,nLevDeltaReal=uplev_pet(character,ch_pet,nLevAdd);
			if not bOK then
			   GM:rspGM(rsp_gpid, "pet_obtain  error.failed to uplevpet.ChPetService:upgrade failed.idPet:",ch_pet.id)		
			end
		end
		
		GM:rspGM(rsp_gpid, "pet_obtain ok.pet_id:"..pet_id.. ' '..pet_base.nick.. ' idPet:'..ch_pet.id,' level:',ch_pet.level )
	end
end

-- 获得幻兽
function GM.awardpet(character, arr_params)
    return GM.pet_obtain(character, arr_params)
end


-- 获得技能
function GM.uplevskill(character, arr_params)
	local rsp_gpid = arr_params.rsp_gpid
	
	local cid = arr_params.cid or character.id
	local params = arr_params.params_decoded
	local skill_id = str2Int(params[1])
	local level_delta_wanted = str2Int(params[2])
	
	local skill_base=SkillBaseService:getSkillBaseById(skill_id) 		
	local ch_skill=ChSkillService:getChSkill(character, skill_id)
	if not skill_base then
	   GM:rspGM(rsp_gpid,"uplevskill failed.skill_base not found. skill_id:",skill_id)
	  return
	end
	
	if not ch_skill then
		ch_skill=ChSkillService:openChSkill(character, skill_base, false, true)
		if not ch_skill then
			return GM:rspGM(rsp_gpid, "uplevskill failed.auto award failed .skill_id:"..skill_id)
		else
			GM:rspGM(rsp_gpid, "uplevskill info.auto award ok.skill_id:"..skill_id)
		end
	end
	
	local level=ChSkillService:getChSkillLevel(character,skill_id)
	local level_new=level+level_delta_wanted
	for k=level,level_new do
	    --if skill_detail>=character.level then
	    --  break
	    --end
		local skill_detail =  SkillBaseService:getSkillDetail(skill_id, k) 
	
		local bOK,errCode=ChSkillService:upgradeSkill(character, skill_id)
		if not bOK then
		  break
		end
	end
	level=ChSkillService:getChSkillLevel(character,skill_id)
	return GM:rspGM(rsp_gpid, "uplevskill ok.skill id:"..skill_id.." level:"..level)
end
	
-- 获得技能
function GM.awardskill(character, arr_params)
	local cid = arr_params.cid or character.id
	local params = arr_params.params_decoded
	
	--table.dump( "awardskill:", params, 10 )
	
	local skill_id = str2Int(params[1])
	
	local rsp_gpid = arr_params.rsp_gpid
	
	local skill_base=SkillBaseService:getSkillBaseById(skill_id)
	local ch_skill=ChSkillService:getChSkill(character, skill_id)
	if ch_skill then
		return GM:rspGM(rsp_gpid, "awardskill ok.already found.skill_id:"..skill_id.. " name:"..skill_base.title.." level:"..ch_skill.level)
	end
	
	local ch_skills = character.skills.ch_skills
		
	local skill_detail =  SkillBaseService:getSkillDetail(skill_id, 1) 
	if skill_detail.ch_level >character.level then 	
		return GM:rspGM(rsp_gpid, "awardskill error.level can't GT:"..character.level)
	end
	
	ch_skill=ChSkillService:openChSkill(character, skill_base, false, true)
	if not ch_skill then
		return GM:rspGM(rsp_gpid, "awardskill error.failed to open skill_id:"..skill_id)
	else
		return GM:rspGM(rsp_gpid, "awardskill ok.skill_id:"..skill_id.. " name:"..skill_base.title)
	end
	
end

--幻兽宝物碎片清空
function GM.bwchip_clear(character, arr_params)
	local rsp_data = "bwchip_clear ok.幻兽宝物碎片清空."
	local rsp_gpid = arr_params.rsp_gpid
	
	if g_mapserver_id ~= ArenaDefs.ARENA_MAP_ID then
		rsp_data = "bwchip_clear error.只能在夺宝场景执行该GM指令"
		return GM:rspGM(rsp_gpid, rsp_data)
	end
	
	local chpet_baowu_chips = ChPetBaowuChipService:getChPetBaowuChips(character.id)
	for _, chpet_baowu_chip in pairs(chpet_baowu_chips) do
		ChPetBaowuChipService:delOneBaowuChip(character, chpet_baowu_chip, chpet_baowu_chip.stack_num, {is_gm=1})
	end
	
	return GM:rspGM(rsp_gpid, rsp_data)
end

--添加幻兽宝物碎片
function GM.bwchip_add(character, arr_params)
	local rsp_data = "bwchip_add ok.添加幻兽宝物碎片OK"
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded
	local chip_equip_id = UNumber.str2Int(params[1])
	local chip_equip_num = tonumber(params[2]) or 1
	
	assert(chip_equip_id > 0)
	assert(chip_equip_num > 0)
	
	local chip_equip_base = EquipBaseService:getEquipBaseById(chip_equip_id)
	if not EquipDefs:isPetBaowuChip(chip_equip_base.equip_sort_id) then
		return GM:rspGM(rsp_gpid, 'bwchip_add error.该道具不是宝物碎片')
	end
	
	ChPetBaowuChipService:addBaowuChipForExternal(character, chip_equip_id, chip_equip_num, 0, {is_gm=1})
	
	return GM:rspGM(rsp_gpid, rsp_data)
end

function GM.bwchip_init(character, arr_params)
	local rsp_data = "添加一批幻兽宝物碎片OK"
	local rsp_gpid = arr_params.rsp_gpid
	
	local equips = EquipBaseDao.data
	local already_init_baowu_eids = {}
	
	for _, equip in pairs(equips) do
		local equip_sort_id = equip.equip_sort_id
		if equip_sort_id >= EquipDefs.EQUIP_SORT_ID_BAOWU_CHIP_START and
			equip_sort_id <= EquipDefs.EQUIP_SORT_ID_BAOWU_CHIP_END
			then
			if not already_init_baowu_eids[equip.baowu_equip_id] then
				ChPetBaowuChipService:addBaowuChipForExternal(character, equip.id, 1, 0, {is_gm=1})
				already_init_baowu_eids[equip.baowu_equip_id] = 1
			end
		end
	end
	
	return GM:rspGM(rsp_gpid, rsp_data)
end

-- 初始化测试帐号：加上测试所有用到的东西
--[[
	魔石10000
	金币90000
	初始体力100
	幻兽4只
	自身职业装备一套
	现有全部道具各50个
--]]
function GM.init_test_player(character, arr_params)
	local rsp_data = "初始化测试帐号完成 ok"
	local rsp_gpid = arr_params.rsp_gpid
	
	local init_equip_id2nums_zhbei = {
		[10010001]=1,
		[10020001]=1,
		[10040001]=1,
		[10050001]=1,
		[10060001]=1,
		[10070001]=1,
		[10080001]=1,
		[10090001]=1,
		[10100001]=1,
	}
	local init_equip_id2nums_daoju = {
		[24010001] = 50,
		[24010002] = 50,
		[24010003] = 50,
		[24010004] = 50,
		[24010005] = 50,
		[24010006] = 50,
		[24010007] = 50,
		[24010008] = 50,
		[21010001] = 50,
		[23010001] = 50,
		[21010201] = 50,
		[21010601] = 50,
		[21010002] = 50,
		[21010003] = 50,
		[21010004] = 50,
		[21010005] = 50,
		[21010009] = 50,
		[21010701] = 50,
		[21010702] = 50,
		[21010801] = 50,
		[21010802] = 50,
		[21010803] = 50,
	}
	local init_game_gold = 20000
	local init_siliver = 200000
	local init_vit = 100
	local init_pets = {
		50001,50001,50001,50001,50002,50002,50002
	}
	
	local is_ok, arr_up_item = ChItemPackageService:addEquip(character, init_equip_id2nums_zhbei, true)
	for _, item in pairs(arr_up_item) do
		local packet = {
			readParams = function () return {
				packet_id = WorldPacket.g_packet_id,
				package_order_by = item.order_by,
			} end }
		ChItemBarCtrl.c2m_dressEquip(character, packet)
	end
	
	ChItemPackageService:addEquip(character, init_equip_id2nums_daoju, true)
	
	character.game_gold = init_game_gold
	character.siliver = init_siliver
	character.vit = init_vit
	local PetBaseDao_data = PetBaseDao.data
	
	for _, pet_id in pairs(init_pets) do
		local pet_base = assert(PetBaseDao_data[pet_id], pet_id)
		ChPetService:addChPet(character, pet_base, false, true)
	end
	
	return GM:rspGM(rsp_gpid, rsp_data)
end

-- TEST 函数
local dt_expired=Time:getSecondsByDateTimeStr('2015-09-30 00:00:00')
function GM.package_clear(character, arr_params)
	local rsp_data = "清空包裹 ok"
	local rsp_gpid = arr_params.rsp_gpid
	
	-- 2014-11-01 关闭
	if os.time() >= dt_expired then
		rsp_data = "该GM指令已关闭 ok"
		return GM:rspGM(rsp_gpid, rsp_data)
	end
	
	local packages_info = character.packages
	packages_info.items = {}
	ChItemPackageService:clearEquip2Items(packages_info)
	ChItemPackageService:key2Dirty(character)
	
	GM:rspGM(rsp_gpid, rsp_data)
	
end

function GM.tollgate_clear_cnt(character, arr_params)
	local rsp_data = "清空关卡次数 ok"
	local rsp_gpid = arr_params.rsp_gpid
	
	local tollgates_info = character.tollgates
	tollgates_info.times_up_ltime = 0
	CharacterService:key2Dirty(character, 'tollgates')
	
	GM:rspGM(rsp_gpid, rsp_data)
end

function GM.scene_move(character, arr_params)
	local rsp_data = "move scene ok"
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded
	local scene_id = UNumber.str2Int(params[1])
	
	if not scene_id or scene_id <= 0 then
		SceneService:moveToLastScene(character, true)
	else
		SceneService:moveScene(character, scene_id, nil, nil, nil, nil, true)
	end
	
	GM:rspGM(rsp_gpid, rsp_data)
end

function GM.horse_add(character, arr_params)
	local rsp_data = "添加坐骑 ok"
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded
	local horse_base_id = UNumber.str2Int(params[1])
	
	local horse_base = HorseBaseDao.data[horse_base_id]
	if not horse_base then
		GM:rspGM(rsp_gpid, "该坐骑ID不存在")
		return
	end
	local ch_horse, err_id = ChHorseService:addHorse(character, horse_base_id, true, true)
	if not ch_horse then
		send_error(err_id)
		rsp_data = "添加坐骑失败"
	end
	
	GM:rspGM(rsp_gpid, rsp_data)
end

function GM.horse_del(character, arr_params)
	local rsp_data = "删除坐骑 ok"
	local rsp_gpid = arr_params.rsp_gpid
	
	character.horses = ChHorseInfo:new(character)
	
	GM:rspGM(rsp_gpid, rsp_data)
end

function GM.jitan_reset(character, arr_params)
	local rsp_data = "充值祭坛第一次刷新状态 ok"
	local rsp_gpid = arr_params.rsp_gpid
	
	character.pet_refresh.nofirst_ref = 0
	
	GM:rspGM(rsp_gpid, rsp_data)
end
--[[
	s 4258 {"order_by":1}
	s 4256 {"package_order_by":10}
	s 4260 {"order_by":2}
	s 4365 {"equip_id":23010001}
	s 4261 {"order_by":2,"embed_pos":1,"equip_id":24010001}
	s 4266 {"order_by":1,"embed_pos":1}
	s 4268 {"mixtrue_num":1,"upgraded_lev":5,"jewel_eid":24010004,"order_by":1,"embed_pos":1}
	s 4656 {"ch_pet_id":2,"exp_equip_num":1}
	s 4706 {"chapter_id":70001,"order_by":1}
	}
--]]
--[[
	./test_diy ChEquipCtrl.c2m_chipMixtrue {"equip_id":}
	./test_diy ChItemBarCtrl.c2m_jewelOpenHole {"order_by":1}
--]]
function GM.test_diy(character, arr_params, packet)
	do
		local ch_pet = ChPetService:getChPet(character, 2)
		ChPetService:calcChPetEffectValues(character, ch_pet)
		
		return
	end
	local params_decoded = arr_params.params_decoded
	local func_name = params_decoded[1]
	local params = params_decoded[2] or '{}'
	
	if params and string.len(params) > 0 then
		packet:writeString(params)
	end
	
	func_name(character, packet)
end

--添加道具到某角色
function GM.wing_del(character, arr_params)
	character.wing = ChWing:new()
	CharacterService:key2Dirty(character, 'wing')
	ChWingService:sendWingBase(character)
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "del wing ok")
end

--删除角色商店购买量数据
function GM.shop_del(character, arr_params)
	character.shop = nil
	ShopService:init(character)
	CharacterService:key2Dirty(character, 'shop')

	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "del shop ok")	
end

-- 清除角色身上的女神及签到数据
function GM.goddess_del( character, arr_params )
	character.goddess = nil
	GoddessService:init( character, true)
	GoddessService:sendChGoddessInfo(character)
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "del goddess ok")	
end

-- 修改角色已签到天数
function GM.sign_days_ch( character, arr_params )
	local params = arr_params.params_decoded
	character.goddess.signed_days_num = UNumber.str2Int(params[1])
	character.goddess.last_signed_day = ""
	character.goddess.next_signed_day_start = 0
	GoddessService:save(character)
	GoddessService:sendChGoddessInfo(character)
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "ch sign days ok")	
end

-- 修改角色上次签到时间
function GM.sign_last_days_ch( character, arr_params )
	local params = arr_params.params_decoded
	local str_day = params[1]
	local str_time = params[1] .. '-' .. params[2] .. '-' .. params[3] .. ' 00:00:00'
	local timestamp = Time:getSecondsByDateTimeStr( str_time)
	if not timestamp then 
		return GM:rspGM(rsp_gpid, "ch_sign_last_days error , ./ch_sign_last_days 2015-04-04")	
	end

	character.goddess.next_signed_day_start = timestamp + 24 * 3600
	character.goddess.last_signed_day =params[1] .. '-' .. params[2] .. '-' .. params[3] 
	GoddessService:save(character)
	GoddessService:sendChGoddessInfo(character)
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "ch_sign_last_days ok")	
end

-- 修改角色在线时长
function GM.sign_online_time_ch( character, arr_params )
	local params = arr_params.params_decoded
	character.goddess.accum_time = UNumber.str2Int(params[1]) * 60
	GoddessService:save(character)
	GoddessService:sendChGoddessInfo(character)
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "ch_sign_online_time ok")	
end


-- 删除每日任务数据
function GM.dailyt_del( character, arr_params )
	local daily_task = character.daily_task
	daily_task.level = 1
	DailyTaskService:updateTask(character, true)
	DailyTaskService:sendChDailyTask(character)
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "dailyt_del ok")		
end


-- 计数器扣除次数
function GM.counter_del( character, arr_params )
	local params = arr_params.params_decoded
	character.counters = nil
	CounterService:init(character)
	CounterService:sendChCounter(character)
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "counter_del ok")	
end

-- 目标数据重置
function GM.target_del( character, arr_params )
	character.targets = nil
	TargetService:init(character)
	TargetService:sendTarget(character)
	-- 重算幻兽属性
	local fight_pet = ChPetService:getFightChPet(character)
	local heti_w_pet = ChPetService:getHeTiChPetByOrderBy(character, PetDefs.HETI_POS_OUT)
	local heti_n_pet = ChPetService:getHeTiChPetByOrderBy(character, PetDefs.HETI_POS_IN)
	if fight_pet then 
		ChPetService:calcChPetEffectValues(character, fight_pet, true)
	end
	if heti_w_pet then 
		ChPetService:calcChPetEffectValues(character, heti_w_pet, true)
	end	
	if heti_n_pet then 
		ChPetService:calcChPetEffectValues(character, heti_n_pet, true)
	end	
	-- 重算角色战力
	CharacterService:calCharacterAttrib(character, true)
	local params = arr_params.params_decoded
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "target_del ok")	
end

function GM.target_finish( character, arr_params )
	local params = arr_params.params_decoded
	local targets = character.targets
	local target_id = UNumber.str2Int(params and params[1] or '0') 	--目标ID
	
	if 0 == target_id then 
		for _, target_info in pairs(targets.next_targets) do
			target_info.status = 1
		end
	else
		targets.next_targets[target_id].status = 1
	end
	TargetService:sendTarget(character)
	local params = arr_params.params_decoded
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "target_finish ok")	
end


-- 杀死当前场景里所有的怪物(add by suwin at 2015-06-01)
function GM.kill_all( character, arr_params )
	local aoiScene = GameObjectService:getAoiScene(character)
	local aoi_type2game_objs = aoiScene.aoi_type2game_objs
	local arr_monster = aoi_type2game_objs[AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER] -- 场景实例中的怪物队列
	local arr_targeter = {}
	local arr_aoi_change_hp = {}
	local tableInsert = table.insert
	for _, monster in pairs(arr_monster) do
		if not FightService:isDead(monster) then
			monster.hp = 0
			tableInsert(arr_targeter, monster)

			local hp_index, hp_key, max_hp_key = FightService:getHpInfo(monster)
			local now_aoi_change_hp = FightService:newObjChangeHp(monster.aoi_id, hp_index, -99999999, monster[hp_key])
			tableInsert(arr_aoi_change_hp, now_aoi_change_hp)
		end
	end
	FightService:doAfterFight(aoiScene, character, nil, arr_targeter)

	FightService:sendObjsChangeHp(aoiScene, character, arr_aoi_change_hp)

	local params = arr_params.params_decoded
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "kill all monster ok")	
end


-- 添加一个boss，并给boss指定ai(add by suwin at 2015-06-01)
function GM.add_boss( character, arr_params )
	local params = arr_params.params_decoded
	local boss_monster_id = (params[1]) + 0
	local boss_ai_ids = params[2]

	local aoiScene = GameObjectService:getAoiScene(character)
	local monster_id = boss_monster_id
	local scene_id = character.scene_id
	local init_x, init_y = character.x + 2, character.y + 2
	local direction = 0

	-- 创建怪物
	local boss = MonsterService:dymCreateMonster(aoiScene, monster_id, scene_id, init_x, init_y, direction)
	if boss and boss_ai_ids then
		-- 清空默认的ai
		boss.monster_ai = {}
		boss.tmps.ai_datas = {}

		local tableInsert = table.insert
		local MonsterSkillAiDao_data = MonsterSkillAiDao.data
		local arr_ids = UString.splitString(boss_ai_ids, ',', true)
		-- 初始化该ai的参数
		local ai, my_ai
		for _, ai_id in pairs(arr_ids) do
			ai = MonsterSkillAiDao_data[ai_id]
			if ai then
				my_ai = boss.monster_ai
				tableInsert(my_ai, ai)

				-- 初始化该ai的参数
				local time_ai_key = 'time_' .. ai_id
				local nums_ai_key = 'nums_' .. ai_id
				boss.tmps.ai_datas[time_ai_key] = 0
				boss.tmps.ai_datas[nums_ai_key] = 0
			end
		end
	end

	-- 让这个boss不会复活
	boss.tmps.my_relive_nums = 1000000

	-- table.dump(boss, 3)

	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "add boss ok")
end


-- 清空任务
function GM.task_del( character, arr_params )
	character.tasks = nil
	ChTaskService:init(character)
	ChTaskService:sendOwnTaskList(character)

	-- 清除新手指引
	character.guides = nil
	GuidesService:init(character)
	GuidesService:sendGuides(character)

	local params = arr_params.params_decoded
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "task_del ok")	
end

-- 完成任务
function GM.task_finish( character, arr_params )
	local params = arr_params.params_decoded
	local task_id = UNumber.str2Int(params and params[1] or '0') 	--任务Id
	local rsp_gpid = arr_params.rsp_gpid

	if task_id == 0 then 
		for k, v in pairs(character.tasks.task_list) do
			if v.status == 1 then 
				v.status = 2
			end
		end
		ChTaskService:save(character)
		ChTaskService:sendOwnTaskList(character)
		return GM:rspGM(rsp_gpid, "task_finish ok")	
	end

	local ch_task = ChTaskService:getChTaskById( character, task_id )
	local task_base = TaskBaseService:getTaskById(task_id)
	
	if not task_base then 
		return GM:rspGM(rsp_gpid, "task_finish err, task not exist")	
	end

	if not ch_task then 
		return GM:rspGM(rsp_gpid, "task_finish err, task not accept")	
	end



	if not ChTaskService:isTaskAccpted(character, task_id) then 
		return GM:rspGM(rsp_gpid, "task_finish err, task is finished or delivered")	
	end
	
	ChTaskService:finishTask(character, task_id)
	ChTaskService:sendUpdateTask(character, task_id)
	return GM:rspGM(rsp_gpid, "task_finish ok")	
end

-- 完成任务
function GM.task_jump( character, arr_params )
	local params = arr_params.params_decoded
	local task_id = UNumber.str2Int(params and params[1] or '0') 	--任务Id
	local rsp_gpid = arr_params.rsp_gpid


	if task_id == 0 then 
		return GM:rspGM(rsp_gpid, "task_jump err! ./task_jump [task_id]")	
	end

	local req_task_base = TaskBaseService:getTaskById(task_id)
	local task_type = req_task_base.task_type

	-- 清除此任务及此任务后的所有任务
	local task_list = character.tasks.task_list
	for k, v in pairs(task_list) do
		if v.task_id >= task_id then 
			local task_base = TaskBaseService:getTaskById(v.task_id)
			if not task_base or task_type == task_base.task_type then 
				task_list[k] = nil
			end
		end
	end
	for _, id in pairs(req_task_base.pre_task_ids) do
		local ch_task = {task_id = id, status = TaskDefs.CH_TASK_STATUS_DELIVERED	}
		task_list[id] = ch_task
	end
	ChTaskService:getAcceptableTasks(character)
	ChTaskService:sendOwnTaskList(character)
	return GM:rspGM(rsp_gpid, "task_jump ok!")	
end

-- 完成任务
function GM.task_accept( character, arr_params )
	local params = arr_params.params_decoded
	local task_id = UNumber.str2Int(params and params[1] or '0') 	--任务Id
	local rsp_gpid = arr_params.rsp_gpid


	if task_id == 0 then 
		return GM:rspGM(rsp_gpid, "task_jump err! ./task_jump [task_id]")	
	end

	local req_task_base = TaskBaseService:getTaskById(task_id)
	local task_type = req_task_base.task_type

	-- 清除此任务及此任务后的所有任务
	local task_list = character.tasks.task_list
	for k, v in pairs(task_list) do
		if v.task_id >= task_id then 
			local task_base = TaskBaseService:getTaskById(v.task_id)
			if task_type == task_base.task_type then 
				task_list[k] = nil
			end
		end
	end
	for _, id in pairs(req_task_base.pre_task_ids) do
		local ch_task = {task_id = id, status = TaskDefs.CH_TASK_STATUS_DELIVERED	}
		task_list[id] = ch_task
	end
	-- 添加任务
--	ChTaskService:getAcceptableTasks(character)
--	ChTaskService:sendOwnTaskList(character)

	local ch_task = ChTaskService:addChTask(character, req_task_base)
	-- 检查任务是否能已经完成
--	ChTaskService:checkFinishedTask(character, ch_task)
	-- 持久化
	ChTaskService:save(character)
	-- 发送接取任务成功
	ChTaskService:sendOwnTaskList(character)
	ChTaskService:getAcceptableTasks(character)

	return GM:rspGM(rsp_gpid, "task_jump ok!")	
end


-- 打开需要做任务类才打开的功能开关
function GM.open_all_task_func(character, arr_params)
	local TASK_OPEN_LIST = OpenFuncDefs.TASK_OPEN_LIST -- 结构 : TASK_OPEN_LIST[value] = open_func_id

	-- 都打开
	for _, arr_open_func_id in pairs(TASK_OPEN_LIST) do
		for _, open_func_id in pairs(arr_open_func_id) do
			character.func_opens[open_func_id] = 1
		end
	end

	-- 持久化数据
	CharacterService:key2Dirty(character, 'func_opens')

	-- 广播给客户端
	FuncOpensService:sendCharacterOpenFunc(character)
	
	local rsp_gpid = arr_params.rsp_gpid
	GM:rspGM(rsp_gpid, "open_all_task_func ok")	
end

-- 设置角色及幻兽属性为测试用属性
do

	local prof_test_info = {
		[1] = {
			pet_ids = {
				[1]=500805,
				[2]=500703,
				[3]=500603,		

			},
		},
		[2] = {
			pet_ids = {
				[1]=500806,
				[2]=500705,
				[3]=500605,
			},
		},
		[3] = {
			pet_ids = {
				[1]=500805,
				[2]=500703,
				[3]=500603,
			},
		},		
	}
	local attrib = {
		[1]={level=70, max_hp=100975, max_attack=6933,min_attack=3466,defence_phy=1336,defence_magic=1137,dodge=168,critical_hit=178,parry=168,luck=259,douzhi=220,kill_force=19,addi_harm=522,reduce_harm=116},
		[2]={level=60, max_hp=100558, max_attack=8014,min_attack=4007,defence_phy=1309,defence_magic=1233,dodge=116,critical_hit=166,parry=116,luck=129,douzhi=96,kill_force=0,addi_harm=841,reduce_harm=391},
		[3]={level=60, max_hp=89160, max_attack=3784,min_attack=1892,defence_phy=1164,defence_magic=989,dodge=110,critical_hit=160,parry=120,luck=90,douzhi=24,kill_force=0,addi_harm=841,reduce_harm=391},
		[4]={level=60, max_hp=59709, max_attack=3784,min_attack=1892,defence_phy=738,defence_magic=989,dodge=110,critical_hit=110,parry=20,luck=90,douzhi=24,kill_force=0,addi_harm=41,reduce_harm=41},
		[5]={level=70, max_hp=121347, max_attack=5428,min_attack=2714,defence_phy=1523,defence_magic=1657,dodge=178,critical_hit=168,parry=168,luck=259,douzhi=220,kill_force=19,addi_harm=522,reduce_harm=116},
		[6]={level=60, max_hp=100558, max_attack=8014,min_attack=4007,defence_phy=1233,defence_magic=1309,dodge=166,critical_hit=116,parry=116,luck=129,douzhi=96,kill_force=0,addi_harm=841,reduce_harm=391},
		[7]={level=60, max_hp=89160, max_attack=3784,min_attack=1892,defence_phy=989,defence_magic=1164,dodge=160,critical_hit=120,parry=120,luck=90,douzhi=24,kill_force=0,addi_harm=841,reduce_harm=391},
		[8]={level=60, max_hp=59709, max_attack=3784,min_attack=1892,defence_phy=989,defence_magic=738,dodge=110,critical_hit=20,parry=110,luck=90,douzhi=24,kill_force=0,addi_harm=41,reduce_harm=41},
		[9]={level=70, max_hp=121347, max_attack=6132,min_attack=3066,defence_phy=1336,defence_magic=1137,dodge=168,critical_hit=168,parry=178,luck=259,douzhi=220,kill_force=19,addi_harm=522,reduce_harm=116},
		[10]={level=60, max_hp=100558, max_attack=8014,min_attack=4007,defence_phy=1309,defence_magic=1233,dodge=116,critical_hit=116,parry=166,luck=129,douzhi=96,kill_force=0,addi_harm=841,reduce_harm=391},
		[11]={level=60, max_hp=89160, max_attack=3784,min_attack=1892,defence_phy=1164,defence_magic=989,dodge=110,critical_hit=120,parry=160,luck=90,douzhi=24,kill_force=0,addi_harm=841,reduce_harm=391},
		[12]={level=60, max_hp=59709, max_attack=3784,min_attack=1892,defence_phy=738,defence_magic=989,dodge=20,critical_hit=110,parry=110,luck=90,douzhi=24,kill_force=0,addi_harm=41,reduce_harm=41},
	}
	local tasks = {
		[1] = 1002801,
	}
	local not_need_upgrade_skill = {
		[10111] = true,
		[11104] = true,
		[10311] = true,
	}
	function GM.attrib_to_test( character, arr_params )
		-- 先将玩家属性变为100级
		character.level = 100

		-- 重置技能，并将所有技能设置为2级
--		character.skills = nil
--		ChSkillService:init(character)
		for k, v in pairs(character.skills.ch_skills) do
			if not not_need_upgrade_skill[v.skill_id] then 
				v.level = 2
			else
				v.level = 1
			end
		end
		ChSkillService:sendChChSkillsInfo(character)
		ChSkillService:sendChChSkillSlotInfo(character)

		local prof = character.prof

		-- 隐藏出战
		local aoi_scene = GameObjectService:getAoiScene(character)	
		ChPetService:hideFightPet(character, aoi_scene, true)

		-- 清空角色幻兽
		character.pets = nil
		ChPetService:init(character)

		-- 幻兽阵法信息 (注：要在幻兽信息之前返回)
		ChPetTroopService:sendChPetTroopInfo(character)
		
		-- 返回幻兽简要信息
		ChPetService:sendPetAllInfo(character)		

		-- 添加幻兽
		local pet_ids = prof_test_info[prof].pet_ids

		for index, pet_id in pairs(pet_ids) do
			local pet_base = PetBaseDao.data[pet_id]

			-- 添加幻兽
			local ch_pet = ChPetService:addChPet(character, pet_base, false, true)
			
			-- 添加到对应位置
			if index == 1 then 
				local is_ok, err = ChPetService:setFightPet(character, ch_pet.id)
				if not is_ok then Logger:error(err) end
			elseif index == 2 then 
				ChPetService:setHetiPet(character, PetDefs.HETI_POS_OUT, ch_pet.id)
			else
				ChPetService:setHetiPet(character, PetDefs.HETI_POS_IN, ch_pet.id)
			end

			-- 所有属性配置
			local attrib_config = attrib[(prof-1) * 4 + index + 1]

			-- 重置幻兽属性
			for attribute, value in pairs(attrib_config) do
				ch_pet[attribute] = value
			end

			ch_pet.kill_force = 0
			
			ch_pet.fight_capacity = BaseAttribFormula:calcFightCapacity(pet_base.prof, ch_pet)
			ch_pet.hp = ch_pet.max_hp
			
			-- 更新角色对象上的合体幻兽的最大/当前血量
			ChPetService:updateHetiPetHpInCh(character, false, true)
			
			CharacterService:key2Dirty(character, 'pets')

			local up_keys_calc_effect = table.mergeTwoArrayTable({'fight_capacity'}, EffectNamesForFight)
			up_keys_calc_effect[#up_keys_calc_effect+1] = 'level'
			up_keys_calc_effect[#up_keys_calc_effect+1] = 'exp'
			ChPetService:sendChPetUpdate(character, ch_pet, up_keys_calc_effect)
		end
		
		-- 返回幻兽简要信息
--		ChPetService:sendPetAllInfo(character)	

		--- 设置角色属性
		local ch_attr_config = attrib[(prof-1) * 4 + 1]
		for attribute, value in pairs(ch_attr_config) do
			character[attribute] = value

		end
		character['addi_harm_perc'] = 0

		-- 重算战力
		character.hp = character.max_hp
		
		-- 更新战力
		CharacterService:updateChFightCapacity(character, false)
		
		-- 设置脏标志
		local ch_fight_attribs = table.mergeTwoArrayTable({"level", "addi_harm_perc"},EffectTypeDefs.ch_recalc_fc_relate_attribs)
		CharacterService:key2Dirty(character, ch_fight_attribs)
		CharacterService:sendCharacterUpdate(character, ch_fight_attribs)

		for k, task_id in pairs(tasks) do
			FuncOpensService:taskOpenFunc(character, task_id)
		end
	end
end

do

	local prof_test_info = {
		[1] = {
			pet_ids = {
				[1]=500805,
				[2]=500703,
				[3]=500603,		

			},
		},
		[2] = {
			pet_ids = {
				[1]=500806,
				[2]=500705,
				[3]=500605,
			},
		},
		[3] = {
			pet_ids = {
				[1]=500805,
				[2]=500703,
				[3]=500603,
			},
		},		
	}
	local attrib = {
		[1]={level=70, max_hp=234258, max_attack=18300,min_attack=9150,defence_phy=3272,defence_magic=2844,dodge=1001,critical_hit=1011,parry=1001,luck=1371,douzhi=1240,kill_force=50,addi_harm=10000,reduce_harm=7500},
		[2]={level=70, max_hp=421104, max_attack=22240,min_attack=11120,defence_phy=4422,defence_magic=4221,dodge=1050,critical_hit=1150,parry=1050,luck=1305,douzhi=1193,kill_force=0,addi_harm=8624,reduce_harm=4574},
		[3]={level=70, max_hp=464694, max_attack=18716,min_attack=9358,defence_phy=6188,defence_magic=4155,dodge=1050,critical_hit=1150,parry=1070,luck=1239,douzhi=1171,kill_force=0,addi_harm=8624,reduce_harm=4574},
		[4]={level=70, max_hp=287787, max_attack=18716,min_attack=9358,defence_phy=4739,defence_magic=3120,dodge=1050,critical_hit=1150,parry=1070,luck=1239,douzhi=1171,kill_force=0,addi_harm=8624,reduce_harm=4574},
		[5]={level=70, max_hp=273397, max_attack=14532,min_attack=7266,defence_phy=3817,defence_magic=3817,dodge=1011,critical_hit=1001,parry=1001,luck=1371,douzhi=1240,kill_force=50,addi_harm=10000,reduce_harm=7500},
		[6]={level=70, max_hp=421104, max_attack=22240,min_attack=11120,defence_phy=4221,defence_magic=4422,dodge=1050,critical_hit=1150,parry=1050,luck=1305,douzhi=1193,kill_force=0,addi_harm=8624,reduce_harm=4574},
		[7]={level=70, max_hp=464694, max_attack=18716,min_attack=9358,defence_phy=4155,defence_magic=6188,dodge=1050,critical_hit=1150,parry=1070,luck=1239,douzhi=1171,kill_force=0,addi_harm=8624,reduce_harm=4574},
		[8]={level=70, max_hp=287787, max_attack=18716,min_attack=9358,defence_phy=3120,defence_magic=4739,dodge=1050,critical_hit=1150,parry=1070,luck=1239,douzhi=1171,kill_force=0,addi_harm=8624,reduce_harm=4574},
		[9]={level=70, max_hp=273397, max_attack=16560,min_attack=8280,defence_phy=3274,defence_magic=2844,dodge=1001,critical_hit=1001,parry=1011,luck=1371,douzhi=1240,kill_force=50,addi_harm=10000,reduce_harm=7500},
		[10]={level=70, max_hp=421104, max_attack=22240,min_attack=11120,defence_phy=4422,defence_magic=4221,dodge=1050,critical_hit=1150,parry=1050,luck=1305,douzhi=1193,kill_force=0,addi_harm=8624,reduce_harm=4574},
		[11]={level=70, max_hp=464694, max_attack=18716,min_attack=9358,defence_phy=6188,defence_magic=4155,dodge=1050,critical_hit=1150,parry=1070,luck=1239,douzhi=1171,kill_force=0,addi_harm=8624,reduce_harm=4574},
		[12]={level=70, max_hp=287787, max_attack=18716,min_attack=9358,defence_phy=4739,defence_magic=3120,dodge=1050,critical_hit=1150,parry=1070,luck=1239,douzhi=1171,kill_force=0,addi_harm=8624,reduce_harm=4574},
	}
	local tasks = {
		[1] = 1002801,
	}
	local not_need_upgrade_skill = {
		[10111] = true,
		[11104] = true,
		[10311] = true,
	}
	local big_r_palyers = {
		[80101] = true,
		[80305] = true,
		[80501] = true,
		[80102] = true,
	}
	function GM.attrib_to_r( character, arr_params )
		local player_id = character.player_id
		if not big_r_palyers[player_id] then 
			return GM.attrib_to_test(character, arr_params)
		end

		-- 先将玩家属性变为100级
		character.level = 100

		-- 重置技能，并将所有技能设置为2级
--		character.skills = nil
--		ChSkillService:init(character)
		for k, v in pairs(character.skills.ch_skills) do
			if not not_need_upgrade_skill[v.skill_id] then 
				v.level = 2
			else
				v.level = 1
			end
		end
		ChSkillService:sendChChSkillsInfo(character)
		ChSkillService:sendChChSkillSlotInfo(character)

		local prof = character.prof

		-- 隐藏出战
		local aoi_scene = GameObjectService:getAoiScene(character)	
		ChPetService:hideFightPet(character, aoi_scene, true)

		-- 清空角色幻兽
		character.pets = nil
		ChPetService:init(character)

		-- 幻兽阵法信息 (注：要在幻兽信息之前返回)
		ChPetTroopService:sendChPetTroopInfo(character)
		
		-- 返回幻兽简要信息
		ChPetService:sendPetAllInfo(character)		

		-- 添加幻兽
		local pet_ids = prof_test_info[prof].pet_ids

		for index, pet_id in pairs(pet_ids) do
			local pet_base = PetBaseDao.data[pet_id]

			-- 添加幻兽
			local ch_pet = ChPetService:addChPet(character, pet_base, false, true)
			
			-- 添加到对应位置
			if index == 1 then 
				local is_ok, err = ChPetService:setFightPet(character, ch_pet.id)
				if not is_ok then Logger:error(err) end
			elseif index == 2 then 
				ChPetService:setHetiPet(character, PetDefs.HETI_POS_OUT, ch_pet.id)
			else
				ChPetService:setHetiPet(character, PetDefs.HETI_POS_IN, ch_pet.id)
			end

			-- 所有属性配置
			local attrib_config = attrib[(prof-1) * 4 + index + 1]

			-- 重置幻兽属性
			for attribute, value in pairs(attrib_config) do
				ch_pet[attribute] = value
			end

			ch_pet.kill_force = 0
			
			ch_pet.fight_capacity = BaseAttribFormula:calcFightCapacity(pet_base.prof, ch_pet)
			ch_pet.hp = ch_pet.max_hp
			
			-- 更新角色对象上的合体幻兽的最大/当前血量
			ChPetService:updateHetiPetHpInCh(character, false, true)
			
			CharacterService:key2Dirty(character, 'pets')

			local up_keys_calc_effect = table.mergeTwoArrayTable({'fight_capacity'}, EffectNamesForFight)
			up_keys_calc_effect[#up_keys_calc_effect+1] = 'level'
			up_keys_calc_effect[#up_keys_calc_effect+1] = 'exp'
			ChPetService:sendChPetUpdate(character, ch_pet, up_keys_calc_effect)
		end
		
		-- 返回幻兽简要信息
--		ChPetService:sendPetAllInfo(character)	

		--- 设置角色属性
		local ch_attr_config = attrib[(prof-1) * 4 + 1]
		for attribute, value in pairs(ch_attr_config) do
			character[attribute] = value

		end
		character['addi_harm_perc'] = 0

		-- 重算战力
		character.hp = character.max_hp
		
		-- 更新战力
		CharacterService:updateChFightCapacity(character, false)
		
		-- 设置脏标志
		local ch_fight_attribs = table.mergeTwoArrayTable({"level", "addi_harm_perc"},EffectTypeDefs.ch_recalc_fc_relate_attribs)
		CharacterService:key2Dirty(character, ch_fight_attribs)
		CharacterService:sendCharacterUpdate(character, ch_fight_attribs)

		for k, task_id in pairs(tasks) do
			FuncOpensService:taskOpenFunc(character, task_id)
		end
	end
end


-- 添加军团经验
function GM.add_gang_exp( character, arr_params )
	local params = arr_params.params_decoded
	local add_gang_exp = UNumber.str2Int(params and params[1] or '0') 	--任务Id
	local rsp_gpid = arr_params.rsp_gpid


	if add_gang_exp == 0 then 
		return GM:rspGM(rsp_gpid, "add_gang_exp err! ./add_gang_exp [exp]")	
	end

	local gang_id = character.gang_id

	if not gang_id or gang_id < 0 then 
		GM:rspGM(rsp_gpid, "please join gang first !")
	end

	--添加军团经验
	GangService:addGangExp(character, add_gang_exp)

	GM:rspGM(rsp_gpid, "add_gang_exp ok")	
end


--定位到玩家并飞到同位置
local time_now=Time.time_now
function GM.loc(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded
	
	local nick = params[1]--arr_params.p1--params[1]
	
	local ch_target=CharacterService:getCharacterByNick(nick)
	
	print('loc',nick,ch_target)
	
	
	if  ch_target then		
		if ch_target.scene_id==character.scene_id then		
			MotionService:setPos(character,ch_target.x, ch_target.y, true)
		else
			SceneService:moveScene(character, ch_target.scene_id, ch_target.space_id, nil, ch_target.x, ch_target.y)	
		end
	else
		return GM:rspGM(rsp_gpid, "loc error."..nick,' not found')
	end
	
	--local rsp_pack = GM:_packGM("roleinfo:x:",character.x," y:",character.y)
	--WorldPacket:m2cSendOK(rsp_pack, nil, WorldPacket.g_character.gpid)
end 


--定位到玩家并拉到自己同位置
function GM.pull(character, arr_params)
	local cid = arr_params.cid or character.id
	local params = arr_params.params_decoded
	
	local nick = params[1]--arr_params.p1
	local ch_target=CharacterService:getCharacterByNick(nick)
	if  ch_target then		
		if ch_target.scene_id==character.scene_id then		
			MotionService:setPos(ch_target,character.x, character.y, true)
		else
			SceneService:moveScene(ch_target, character.scene_id, character.space_id, nil, character.x, character.y)	
		end
	else
		return GM:rspGM(rsp_gpid, "pull error."..nick,' not found')
	end
	
	--local rsp_pack = GM:_packGM("roleinfo:x:",character.x," y:",character.y)
	--WorldPacket:m2cSendOK(rsp_pack, nil, WorldPacket.g_character.gpid)
end 

--飞到指定地图指定位置
function GM.fly(character, arr_params)
	local cid = arr_params.cid or character.id
	--local params = arr_params.params_decoded
	
	local params = arr_params.params_decoded
	local x = str2Int(params[1])--arr_params.p1)
	local y = str2Int(params[2])--arr_params.p2)
	local scene_id =0
	
	if #params>=3 then
	   scene_id= str2Int(params[3])--arr_params.p3)
	end
	if scene_id==0 then
		scene_id=character.scene_id
	end
	
	if scene_id==character.scene_id then		
		MotionService:setPos(character,x, y, true)
	else
		SceneService:moveScene(character, scene_id,0 , nil, x, y)	
	end	
end 


--玩家升级
function GM.uplev(character, arr_params,packet)
	local cid = arr_params.cid or character.id
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded

--table.dump('uplev:',params,-1)

	local nLevAdd = 1
	if params and #params>=1 then
	   nLevAdd=str2Int(params[1])--arr_params.p1)
	end 
	if nLevAdd<=0 then
	  nLevAdd = 1
	end
	
	if character.level>=CharacterDefs.CHARACTER_LEVEL_MAX then
		--GM:rspGM(character.player_id, "uplev ok.max level reached:"..CharacterDefs.CHARACTER_LEVEL_MAX)
		local str=string.format("uplev ok.plr>=max %d.",CharacterDefs.CHARACTER_LEVEL_MAX)
		print(str)
		
		GM:rspGM(rsp_gpid, str)
		
		--local rsp_pack = CharacterService:packUpdateCharacter(character.id, {level =character.level})
		--WorldPacket:m2cSendOK(rsp_pack, g_packet_id, arr_params.rsp_pid)		
		return
	end
	local nLevDeltaReal=0
	for k=1,nLevAdd do
	    nLevDeltaReal=nLevDeltaReal+1
		character.exp=character.upgrade_exp
		 CharacterCtrl.c2m_levelUp(character, packet)
	end
	
	print('plr uplev result.pid,level:',character.player_id,character.level)
	
	GM:rspGM(rsp_gpid, "uplev ok.lev delta real:".. nLevDeltaReal..' now level:'..character.level..' nLevAdd:'..nLevAdd)
		
	--local rsp_pack = CharacterService:packUpdateCharacter(character.id, {level =character.level})
	--WorldPacket:m2cSendOK(rsp_pack, g_packet_id, arr_params.rsp_pid)	
		
	--GM:rspGM(character.player_id, "uplev ok.lev delta real:".. nLevDeltaReal..' now level:'..character.level..' nLevAdd:'..nLevAdd)	
end 


function GM.pos(character, arr_params)
	local cid = arr_params.cid or character.id


	local posinfo=string.format('[%u] pid:%u scene_id:%u space_id:%d scene_ins_id:%u %f,%f',character.id,character.player_id,character.scene_id,character.space_id,character.scene_ins_id or 0,character.x,character.y)
		
	local rsp_gpid = UNumber.str2Int(arr_params.rsp_gpid)
	return GM:rspGM(rsp_gpid, posinfo)
end


--自动满血
function GM.ch_full(character, arr_params)
	local cid = arr_params.cid or character.id
	local rsp_pid = arr_params.rsp_pid
	local rsp_data = "set hp, mp, zhenqi max ok"
	
	local ch = CharacterService:getCharacterById(cid)
	if not ch then
		rsp_data = "character id error"
	else
		ch.hp = ch.max_hp
		ch.mp = ch.max_mp
		ch.zhenqi = ch.zhenqi_max
	end
	
	return GM:rspGM(rsp_gpid, rsp_data)	
end



function GM.querygold(character, arr_params)
print('querygold----')
	PlatFormService:queryGold(character)
end

-----------------------------------------压力测试支持
function GM.prandmove(character, arr_params)
	if character.hp<=0 then 
		GM.relive(character, nil)
		return
	end
	local params = arr_params.params_decoded
	local dist = 5--str2Int(params[1])
	local dist_real=random(1,dist)
	
	local game_obj = character
	local aoiScene = GameObjectService:getAoiScene(character)
	
	local nx,ny=aoiScene:randPos(character.x,character.y,dist_real)
	local pos_arr={character.x,character.y,nx,ny}
	
	--print('prandmove:',character.nick,character.aoi_id,character.x,character.y,nx,ny)
	
	if MotionService:isMoving(game_obj) then
	   --正在移动
	   return
	end
	 
	MotionService:startMoveByClient(aoiScene, game_obj, MotionDefs.TYPE_MOVE, pos_arr,0)		
end


function GM.pattack(character, arr_params)
	if character.hp<=0 then 
		GM.relive(character, nil)
		return
	end
	
	local params = arr_params.params_decoded
	local skill_id = str2Int(params[1])
	
	local aoiScene = GameObjectService:getAoiScene(character)
	local atker_aoi_obj=character.aoi_obj
	--local arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(atker_aoi_obj, atker_aoi_obj.x, atker_aoi_obj.y, 100, AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER)
	
	local arr_aoiObj=GameObjectService:getFovMonsterAoiObjs(character, aoiScene)
	local aoiObj_num=#arr_aoiObj
	
	if aoiObj_num<1 then
		--print('pattack error aoiObj_num<1:',character.aoi_id,skill_id,aoiObj_num,atker_aoi_obj.x, atker_aoi_obj.y,character.x,character.y)
	   return 
	end
	if not arr_aoiObj then
		print('pattack error no arr_aoiObj:',character.aoi_id,targeter.aoi_id,skill_id)
	   return
	end
	
	local targeter
	local mindxy=nil
	for k=1,#arr_aoiObj do
	  local aoiobj=arr_aoiObj[k]
	  local dx=(aoiobj.x-character.x)
	  local dy=(aoiobj.y-character.y)
	  local dxy=dx*dx+dy*dy
	  if not mindxy then
	    mindxy=dxy
	    targeter=aoiobj
	  else
	     if mindxy>dxy then
			mindxy=dxy
			targeter=aoiobj
	     end
	  end
	end
	
	--print(aoiObj_num,targeter)
		
		
	local fighter =character
			
	local skill = FightService:getFighterSkill(character, skill_id)
	if not skill then
		print('pattack error no skill:',character.aoi_id,targeter.aoi_id,skill_id)
	   return
	end
	--table.dump('targeter:',targeter,-1)
	--print('pattack:',character.nick,character.aoi_id,targeter.obj_id,skill_id)
	
	local target = GameObjectService:getGameObjectByAoiId(aoiScene, targeter.obj_id)
		
		local upval_arr_pos=nil
		
		if not upval_arr_pos then
			upval_arr_pos = FightService:getDefaultPos()
		end
		upval_arr_pos.target_x = target.aoi_obj.x
		upval_arr_pos.target_y = target.aoi_obj.y
		upval_arr_pos.fighter_new_x = character.x
		upval_arr_pos.fighter_new_y = character.x
		upval_arr_pos.targeter_new_x = target.aoi_obj.x
		upval_arr_pos.targeter_new_y = target.aoi_obj.y
		
	FightCtrl:callFight(aoiScene, fighter, target, skill, nil, upval_arr_pos, 0)				
end

--aoi范围内玩家
function GM.pcountaoi(character, arr_params)

	local aoiScene = GameObjectService:getAoiScene(character)
	local pids=GameObjectService:getFovGPids(character, aoiScene)
	
    local cnt=#pids
	local rsp_data =string.format("pcount aoi:%d.",cnt);
	
	return GM:rspGM(arr_params.rsp_gpid, rsp_data)	
end

--aoi范围内玩家
function GM.pidsaoi(character, arr_params)
	local aoiScene = GameObjectService:getAoiScene(character)
	
	local pids=GameObjectService:getFovGPids(character, aoiScene)
	
    local cnt=#pids
    local str_pids=""
    local aid,pid
    local GAME_AREA_CODE=Config.GAME_AREA_CODE
    for k=1,cnt do
		aid,pid=external.splitUInt(pids[k])
		if GAME_AREA_CODE== aid then
			str_pids=str_pids..string.format(",%d",pid)
		else
			str_pids=str_pids..string.format(",%d.%d",aid,pid)
		end
    end
	local rsp_data =string.format("players aoi .cnt:%d pids:%s .",cnt,str_pids);
	
	return GM:rspGM(arr_params.rsp_gpid, rsp_data)	
end


function GM.print_scenedata(character, arr_params)

  external.printSceneData(character.scene_id,0)
  local rsp_data="printSceneData"
	return GM:rspGM(arr_params.rsp_gpid, rsp_data)	
end

function GM.mask(character, arr_params)
	local params = arr_params.params_decoded
	
	local x = UNumber.str2Int(params and params[1])
	local y = UNumber.str2Int(params and params[2])
	
	local aoiScene = GameObjectService:getAoiScene(character)
		
	local res_id
	if (#params>2) then
	   res_id=UNumber.str2Int(params and params[3])
	else
		res_id=aoiScene.scene_base.res_id
	end
	
	
	print('mask:',res_id,x,y)
	local lev = external.getShieldLevel(res_id,x,y,true)

	local rsp_data=string.format("mask res_id:%u x,y:%.5f,%.5f lev:%u.",res_id,x,y,lev)
	return GM:rspGM(arr_params.rsp_gpid, rsp_data)	
end

function GM.recalc(character, arr_params)
   print('recalc',character.player_id,character.id)
	CharacterService:calCharacterAttrib(character)
end

-- 在离玩家最近的区域生成临危任务
function GM.linwei_open( character, arr_params )
	local rsp_data = "linwei_open ok"
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded	

	local aoi_scene = GameObjectService:getAoiScene(character)

	-- 查看玩家是否在临危场景中
	if not OutdoorService:isInOutdoor( aoi_scene.scene_id ) then
		return 
	end

	-- 如果临危任务进行中，则停止任务
	
	if LinweiTaskService:isInLinweiTask( aoi_scene ) then 
		LinweiTaskService:onTaskFail( aoi_scene )
	end

	-- 计算最近的位置
	local min_pos = 0
	local min_lenth = 99999999
	local x = character.x
	local y = character.y
	for _, task_pos in pairs(LinweiTaskConfig.CENTER_POS) do
		if (task_pos.x - x)^2 + (task_pos.y - y)^2 < min_lenth then 
			min_pos = _
			min_lenth = (task_pos.x - x)^2 + (task_pos.y - y)^2
		end
	end

	local pos = min_pos
	assert(pos > 0)

	if params then
		local first_type = params[1]	--任务大类
		local second_type = params[2]	--任务小类
		local gm_param = {}
		gm_param.pos = pos
		gm_param.first_type = tonumber(first_type)
		gm_param.second_type = second_type and tonumber(second_type) or nil

		LinweiTaskService:addNewTask( aoi_scene, gm_param)
	else
		local gm_param = {}
		gm_param.pos = pos		
		LinweiTaskService:addNewTask( aoi_scene, gm_param)
	end

	GM:rspGM(rsp_gpid, "linwei_open ok")	
end

function GM.jiebiao_open( character, arr_params )
	local rsp_data = "jiebao_open ok"
	local rsp_gpid = arr_params.rsp_gpid
	local aoi_scene = GameObjectService:getAoiScene(character)

	-- 查看玩家是否在临危场景中
	if not OutdoorService:isInOutdoor( aoi_scene.scene_id ) then
		return 
	end

	local outdoor = aoi_scene.outdoor
	if outdoor.task_type == OutdoorDefs.OUTDOOR_TASK_TYPE_JEIBIAO then 

	else
		if LinweiTaskService:isInLinweiTask( aoi_scene ) then 
			LinweiTaskService:onTaskFail( aoi_scene )
		else
			LinweiTaskService:onFinishTask( aoi_scene )
		end
	end
	GM:rspGM(rsp_gpid, "jiebao_open ok")
end

function GM.linwei_create_boss(character)
	local aoi_scene = GameObjectService:getAoiScene(character)

	-- 查看玩家是否在临危场景中
	if not OutdoorBossService:isInOutdoorBoss( aoi_scene.scene_id ) then
		return 
	end
	aoi_scene.outdoor.next_create_boss_timestamp = os.time()
	OutdoorBossService:checkCreateBossMonster(aoi_scene, os.time())
	GM:rspGM(character.gpid, "linwei_create_boss ok")	
end

function GM.linwei_sync_boss_kill( character )
	local aoi_scene = GameObjectService:getAoiScene(character)
	-- 查看玩家是否在临危场景中
	if not OutdoorService:isInOutdoor( aoi_scene.scene_id ) then
		return 
	end	
	OutdoorService:centerbossSyncCenterBossKillInfo( aoi_scene )
end

function GM.scene_goto(character, arr_params)
  return GM.scene_move(character, arr_params)
end
function GM.goto(character, arr_params)
  return GM.scene_move(character, arr_params)
end

-- 创建自己这个机器人
function GM.create_self( character )
	GM.robot_start_id = GM.robot_start_id or 990000
	GM.robot_start_id = GM.robot_start_id + 1
	local aoi_scene = GameObjectService:getAoiScene(character)
	local robot_cid = GM.robot_start_id 
	local robot_attrib_str = CharacterService:builtMoveCharacter(character)
	SceneRobotService:createSceneRobot(aoi_scene, robot_cid, robot_attrib_str, character)
end

function GM.achieve_add(character, arr_params)
	local aoi_scene = GameObjectService:getAoiScene(character)
	OutdoorService:centerbossSyncCenterBossKillInfo(aoi_scene)
end

-- 劫镖任务开启
function GM.jb_open( character, arr_params )
  local rsp_data = "jb_open ok"
  local rsp_gpid = arr_params.rsp_gpid
  local params = arr_params.params_decoded  

  local aoi_scene = GameObjectService:getAoiScene(character)
  
  JieBiaoService:outPrepareTask(aoi_scene)
  local table1 = JieBiaoService:outGetJieBiaoTask(aoi_scene, character.gcid)
  table.dump("getjbtask",table1,5) 
  
  JieBiaoService:join(character,1)

  GM:rspGM(rsp_gpid, "jb_open ok")  
end


-------------

--添加BUFFER
--添加BUFFER
function GM.buffer_add(character, arr_params)
	local rsp_gpid = arr_params.rsp_gpid
	local params = arr_params.params_decoded
	local buffer_id = UNumber.str2Int(params and params[1] or 0)

	if buffer_id == 0 then 
		return GM:rspGM(rsp_gpid, "buffer_id=" .. buffer_id .. " 错误")	
	end
	
	
--	BufferService:addTmpBuffer(character, buffer_base)
	local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(buffer_id)
	SceneBufferService:addSceneBuffer(character, scene_buffer_base, 1)
	SceneBufferService:useSceneBuffer(character,buffer_id, nil, 1)	
	GM:rspGM(rsp_gpid, "buffer_add ok")	
end

function GM.gn_finish( character )
	local aoi_scene = GameObjectService:getAoiScene(character)
	GangBattleNewService:finish( aoi_scene )
end


function GM.shengcun_gr( character )
	local aoi_scene = GameObjectService:getAoiScene(character)
	assert(ShengcunService:isInShengcun( character.scene_id ))
	ShengcunService:onVirusBufferAdd( aoi_scene, character )
end

function GM.shengcun_prof( character, arr_params )
	local params = arr_params.params_decoded	
	local prof = UNumber.str2Int(params and params[1] or 0)
	local aoi_scene = GameObjectService:getAoiScene(character)
	assert(ShengcunService:isInShengcun( character.scene_id ))
	local ch_info = ShengcunService:getChInfoByGcid( aoi_scene, character.gcid )
	if not ch_info.is_zombie then 
		ch_info.shengcun_prof = prof
		ShengcunService:onVirusChange( aoi_scene, character )
	end
end