--[[
动态采集系统ctrl
author : xingzeng
date : 2012-03-27
]]--

local opCodes = opCodes
local packet = packet
local Utils = Utils
local WorldPacket = WorldPacket
local tableInsert = table.insert
local Formula = Formula
local send_error = WorldPacket.m2cSendDebugError

GatherCtrl = GatherCtrl or {}

--- 开始采集
do
	local msg = "PackGather.C2M_SCENE_BUFFER_USE"
	function GatherCtrl.c2m_start(character, packet)
		local params, packet_id = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id or 0
		local dst_aoi_id = params.aoi_id or 0
		
		if scene_ins_id < 0 or dst_aoi_id < 0 then
			return send_error('[GatherCtrl.c2m_start] params error')
		end
		
		if character.scene_ins_id ~= scene_ins_id then
			return
		end
		
		local ok, err = GatherService:startGather(character, dst_aoi_id)
		if not ok then
			return send_error(err)
		end
	end
	c_opHandlers[opCodes.C2M_GATHER_START] = GatherCtrl.c2m_start
end

--- 完成采集
do
	local msg = "PackGather.C2M_GATHER_FINISH"
	function GatherCtrl.c2m_finish(character, packet)
		local params, packet_id = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id or 0
		local dst_aoi_id = params.aoi_id or 0
		
		if scene_ins_id < 0 or dst_aoi_id < 0 then
			return send_error('[GatherCtrl.c2m_start] params error')
		end
		
		if character.scene_ins_id ~= scene_ins_id then
			return
		end
		
		local ok, err = GatherService:finishGather(character, dst_aoi_id)
		if not ok then
			return send_error(err)
		end
	end
	c_opHandlers[opCodes.C2M_GATHER_FINISH] = GatherCtrl.c2m_finish
end