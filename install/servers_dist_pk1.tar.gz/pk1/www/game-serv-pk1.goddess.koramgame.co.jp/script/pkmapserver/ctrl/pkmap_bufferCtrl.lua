--[[
BUFFER系统ctrl
author : xingzeng
date : 2012-03-27
]]--

local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local WorldPacket = WorldPacket

local BufferService = BufferService

BufferCtrl = BufferCtrl or {}

-- BUFFER过期timer回调
function BufferCtrl.t2m_expire(_, packet)
	-- 获取参数
	local arr_params, packet_id = packet:readParams()
	local buffer_id = arr_params.buffer_id
	local space_id = arr_params.space_id
	local aoi_id = arr_params.aoi_id
	local is_tmp_buffer = arr_params.is_tmp_buffer
	local id = arr_params.id
	local aoi_type = arr_params.aoi_type
	local character_id = arr_params.character_id
	
	local aoi_scene = AoiSceneService:getAoiScene(space_id)
	if aoi_scene then
		local game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
		if game_obj then
			BufferService:expire(game_obj, buffer_id, is_tmp_buffer)
		end
	end
end
i_opHandlers[opCodes.T2M_BUFFER_EXPIRE] = BufferCtrl.t2m_expire
