--[[
玩法通用AOI数据 CTRL
author : xingzeng.jiang
date : 2015-04-16
--]]

WanAoiCtrl = WanAoiCtrl or {}
local WanAoiCtrl = WanAoiCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local external = external
local send_error = WorldPacket.m2cSendDebugError
local errorCodes = errorCodes
local WanfaAoiService = WanfaAoiService

-- 获取玩法通用AOI数据
do
	local msg_name = "PackAoi.C2M_SCENE_WANFA_AOI_DATA_GET"
	function WanAoiCtrl.c2m_getWanfaAoiData(character, packet)
		local arr_params, packet_id = packet:readParams(msg_name)
		local aoi_ids = arr_params.aoi_ids
		
		if table.isTableEmpty(aoi_ids) then
			return send_error('[c2m_getWanfaAoiData] param error.')
		end
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		local aoi_objs = aoi_scene:getObjsByIds(aoi_ids)
		WanfaAoiService:sendWanfaAoiDatas(aoi_scene, aoi_objs, character.gpid)
	end
	c_opHandlers[opCodes.C2M_SCENE_WANFA_AOI_DATA_GET] = WanAoiCtrl.c2m_getWanfaAoiData
end
