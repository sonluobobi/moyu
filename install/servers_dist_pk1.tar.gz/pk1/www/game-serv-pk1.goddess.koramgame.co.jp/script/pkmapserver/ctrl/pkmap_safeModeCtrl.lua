--[[
安全模式系统ctrl
author : xingzeng
date : 2015-06-25
]]--

local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local WorldPacket = WorldPacket
local SafeModeDefs = SafeModeDefs
local SafeModeService = SafeModeService
local send_error = WorldPacket.m2cSendDebugError

SafeModeCtrl = SafeModeCtrl or {}

-- 设置安全模式
do
	local msg_name = "PackSafeMode.C2PKM_SAFE_MODE_SET"
	function SafeModeCtrl.c2m_safeModeSet(character, packet)
		-- 获取参数
		local arr_params, packet_id = packet:readParams(msg_name)
		local safe_mode = arr_params.safe_mode
		
		-- 检查参数
		if safe_mode < SafeModeDefs.SAFE_MODE_START or safe_mode > SafeModeDefs.SAFE_MODE_END then
			send_error('[c2m_safeModeSet] param error')
			return
		end
		
		-- 红名不能切换成安全模式
		if RednameService:isReadname(character) then
			return send_error(errorCodes.SAFE_MODE_SET_IN_REDNAME)
		end
		
		-- BOSS野外中，不能切换到和平模式
		--local aoi_scene = GameObjectService:getAoiScene(character)
		--if safe_mode == SafeModeDefs.SAFE_MODE_SPACE and aoi_scene.scene_base.scene_sort_id == SceneDefs.SCENE_SORT_ID_OUTDOOR_BOSS then
		--	send_error(errorCodes.SAFE_MODE_CANNOT_SET_PEACE)
		--	return
		--end
		
		-- 检查切换冷却
		local now_sec = Time:getSecondsNow()
		if safe_mode == SafeModeDefs.SAFE_MODE_SPACE and character.safe_mode_info.safe_mode_cool > now_sec then
			send_error(errorCodes.SAFE_MODE_SET_IN_COOL, character.safe_mode_info.safe_mode_cool - now_sec)
			return
		end
		
		local token = Utils.genConsumeGoldToken(character)
		SafeModeService:sendSafeModeSet(character, safe_mode, token)
	end
	c_opHandlers[opCodes.C2PKM_SAFE_MODE_SET] = SafeModeCtrl.c2m_safeModeSet
end

do
	local msg_name = "PackSafeMode.C2M_SAFE_MODE_GET_TMP_ENEMYS"
	function SafeModeCtrl.c2m_getTmpEnemys(character, packet)
		SafeModeService:sendTmpEnemys(character)
	end
	c_opHandlers[opCodes.C2M_SAFE_MODE_GET_TMP_ENEMYS] = SafeModeCtrl.c2m_getTmpEnemys
end

-- 同步安全模式、红名相关数据
do
	function SafeModeCtrl.pkb2pkm_sync(character, pack_data)
		if character then
			SafeModeService:sync(character, pack_data.safe_mode_info)
		end
	end
end

