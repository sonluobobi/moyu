--[[
角色坐骑系统 CTRL
author : xingzeng.jiang
date : 2014-07-15
--]]

ChHorseCtrl = ChHorseCtrl or {}
local ChHorseCtrl = ChHorseCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local external = external
local send_error = WorldPacket.m2cSendDebugError
local errorCodes = errorCodes
local ChHorseService = ChHorseService

-- 乘骑
do
	local msg = "PackHorse.C2M_CH_HORSE_RIDE"
	function ChHorseCtrl.c2m_ride(character, packet)				
		local params = packet:readParams(msg)
		local is_ride = params.is_ride
		
		if is_ride ~= 1 and is_ride ~= 0 then
			return send_error('参数错误:' .. is_ride)
		end
		
		local is_ok, err_id = ChHorseService:ride(character, is_ride, true)
		if not is_ok then
			send_error(err_id)
			return
		end
	end
	c_opHandlers[opCodes.C2M_CH_HORSE_RIDE] = ChHorseCtrl.c2m_ride
end

--- 获取坐骑信息
do
	local msg = "PackHorse.C2M_CH_HORSE_GET_INFO"
	function ChHorseCtrl.c2m_getChHorsesInfo(character, packet)
		ChHorseService:sendChHorsesInfo(character)
	end
	c_opHandlers[opCodes.C2M_CH_HORSE_GET_INFO] = ChHorseCtrl.c2m_getChHorsesInfo
end

