--[[
野外系统ctrl
author : xingzeng
date : 2015-06-25
]]--

local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local WorldPacket = WorldPacket
local OutdoorConfig = OutdoorConfig

OutdoorCtrl = OutdoorCtrl or {}

-- 进入到野外的安全模式内
do
	local msg_name = "PackOutdoor.C2M_OUTDOOR_IN_OUT_PKAREA"
	function OutdoorCtrl.c2m_inOutPKArea(character, packet)
		local arr_params, packet_id = packet:readParams(msg_name)
		local is_in_pk_area = arr_params.is_in_pk_area
		
		-- 在非PK野外
		--if character.scene_id ~= SceneDefs.OUTDOOR_SCENE_ID_PK then
		--	return WorldPacket:m2cSendCommEmpty(character.gpid)
		--end
		if OutdoorBossService:isInOutdoorBoss( character.scene_id ) or JieBiaoService:isCanUpdateZhengYing(character) then
  		local team = TeamService:getTeamByCid(character.gcid)
  		local zhenying
  		if is_in_pk_area then
  			zhenying = team and Utils.getZhenYingId(team.id) or -1 * character.aoi_id
  		else
  			zhenying = Statics.DEFAULT_ZHENYING_NEUTRAL
  		end
  		
  		local aoi_scene = GameObjectService:getAoiScene(character)
  		GameObjectService:updateZhenying(aoi_scene, character, zhenying, true)
  		
  		local ch_pet_fight = ChPetService:getFightChPet(character)
  		if ch_pet_fight and GameObjectService:isVisible(ch_pet_fight, aoi_scene) then
  			GameObjectService:updateZhenying(aoi_scene, ch_pet_fight, zhenying, true)
  		end
  		
  		local move_beast, no_move_beast = BeastService:getMyBeast(aoi_scene, character)
  		if move_beast and GameObjectService:isVisible(move_beast, aoi_scene) then
  			GameObjectService:updateZhenying(aoi_scene, move_beast, zhenying, true)
  		end
  	end	
	end
	c_opHandlers[opCodes.C2M_OUTDOOR_IN_OUT_PKAREA] = OutdoorCtrl.c2m_inOutPKArea	
end