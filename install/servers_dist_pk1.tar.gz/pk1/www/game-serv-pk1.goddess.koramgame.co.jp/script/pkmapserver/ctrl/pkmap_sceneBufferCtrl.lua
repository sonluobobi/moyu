--[[
场景BUFFER系统ctrl
author : xingzeng
date : 2012-03-27
]]--

local opCodes = opCodes
local packet = packet
local Utils = Utils
local WorldPacket = WorldPacket
local tableInsert = table.insert
local Formula = Formula

SceneBufferCtrl = SceneBufferCtrl or {}

-- 获取指定玩家、侠客、怪物的BUFFER列表
function SceneBufferCtrl.c2m_getSceneBuffers(character, packet)
	-- RSP
	SceneBufferService:sendSceneBuffers(character)
	
	-- 返回所有有附加效果给客户端
	SceneBufferService:sendAppearAllChSceneBuffers(character)
end
c_opHandlers[opCodes.C2M_SCENE_BUFFER_GET] = SceneBufferCtrl.c2m_getSceneBuffers

-- 使用场景BUFFER
do
	local msg = "PackSceneBuffer.C2M_SCENE_BUFFER_USE"
	function SceneBufferCtrl.c2m_useSceneBuffer(character, packet)
		-- 获取参数
		local arr_params, packet_id = packet:readParams(msg)
		local scene_buffer_id = arr_params.scene_buffer_id
		local targeter_aoi_id = arr_params.targeter_aoi_id
		local token = arr_params.token
		local buy_num = arr_params.buy_num or 0
		
		if scene_buffer_id <= 0 or targeter_aoi_id < 0 then
			return WorldPacket.m2cSendDebugError('[c2m_useSceneBuffer] param error')
		end
		
		if buy_num > 0 and not token then
			return WorldPacket.m2cSendDebugError('[c2m_useSceneBuffer] param error')
		end
		
		-- 校验TOKEN
		if buy_num > 0 and not Utils.checkConsumeGoldToken(character, token) then
			return WorldPacket.m2cSendDebugError(errorCodes.COMMON_ILLEGAL)
		end
		
		local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
		assert(scene_buffer_base, scene_buffer_id)
		
		if buy_num > 0 then
			SceneBufferService:addSceneBuffer(character, scene_buffer_base, buy_num)
		end
		
		local use_num = buy_num > 0 and buy_num or 1
		local is_ok, err_id = SceneBufferService:useSceneBuffer(character, scene_buffer_id, targeter_aoi_id, use_num)
		if not is_ok then
			return WorldPacket.m2cSendDebugError(err_id)
		end
	end
	c_opHandlers[opCodes.C2M_SCENE_BUFFER_USE] = SceneBufferCtrl.c2m_useSceneBuffer
end