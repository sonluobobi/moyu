--[[
天魔灭心系统ctrl
author : xingzeng
date : 2013-03-26
]]--

local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local Utils = Utils
local WorldPacket = WorldPacket
local send_error = WorldPacket.m2cSendDebugError
local tableInsert = table.insert
local Formula = Formula
local TianmoDefs = TianmoDefs
local TianmoService = TianmoService
local pairs = pairs

TianmoCtrl = TianmoCtrl or {}

function TianmoCtrl.b2m_entryTianmo(character, pack_data)
	local team_id = pack_data.team_id
	local door_type = pack_data.door_type
	local group_id = pack_data.group_id
	
	-- 获取前往的层次、场景ID
	local lay, err_id = TianmoService:getGotoLay(character)
	if not lay then
		return send_error(err_id)
	end
	
	-- 检查角色当前场景是否为准备厅或者天魔灭心
	local scene_id = character.scene_id
	if scene_id ~= TianmoConfig.pre_scene_id and not TianmoService:isTianmo(scene_id) then
		return send_error('必须从准备厅进入')
	end
	
	-- 判断传送点是否已经开启
	local is_open_transfer, err_id = TianmoService:isRoomTransferOpen(character)
	if not is_open_transfer then
		return send_error(err_id)
	end
	
	-- 检查BOSS房间是否已关闭
	if lay > 1 and TianmoService:isBossRoomClose(group_id) then
		return send_error(errorCodes.TIANMO_BOSSROOM_FULL)
	end
	
	--获取传入下一层的场景ID
	local dst_scene_id, err_id = TianmoService:getGotoSceneId(character, lay, door_type)
	if not dst_scene_id then
		return send_error(err_id)
	end
	
	-- 对进入BOSS房间的检查
	if dst_scene_id == TianmoConfig.boss_room_scene_id then
		local is_ok, err_id = TianmoService:checkEntryBossRoom(group_id)
		if not is_ok then
			return send_error(err_id)
		end
	end
	
	-- 通知BASE进入房间分配
	local tomap_pack = pack_data
	tomap_pack.dst_scene_id = dst_scene_id
	tomap_pack.nick = character.nick
	ServerCall:m2bCall('TianmoCtrl.m2b_entryRoomAssign', character.gcid, tomap_pack)
	
	-- 某些情况下不会回包，故此这里返回一个空包，避免没有任何回包的情况
	WorldPacket:m2cSendCommEmpty(character.gpid)
end

-- 进入已分配的房间 (注，活动已开启, 进入第一层，不会走准备厅，所以不会走到该接口)
function TianmoCtrl.b2m_entryAssignedRoom(character, pack_data)
	local params = pack_data
	local team_id = params.team_id
	local members_gcids = params.members_gcids
	local scene_ins_id = params.scene_ins_id
	local dst_scene_id = params.dst_scene_id
	local is_first_team = params.is_first_team
	local group_id = params.group_id
	local first_enter_bc_data = params.first_enter_bc_data
	local all_gpids = params.all_gpids
	local scene_aoi
	
	if table.isTableEmpty(members_gcids) then
		error('[b2m_entryRoomAssign] params error')
	end
		
	-- 对进入BOSS房间的检查
	if dst_scene_id == TianmoConfig.boss_room_scene_id then
		local is_ok, err_id = TianmoService:checkEntryBossRoom(group_id)
		if not is_ok then
			return
		end
	end
	
	-- 已经离线3分钟了
	if not character then
		return
	end
	
	local dst_x, dst_y	-- 出生点设置已改成在 TianmoService:getBirthPos 设置了
	local is_has_player_in = false
	local members_gpids = {}
	
	--队伍成员依次进入下一层
	for _, gcid_t in pairs(members_gcids) do
		local ch_obj = CharacterService:getCharacterByGcid(gcid_t)
		if ch_obj then
			members_gpids[ch_obj.gpid] = 1
			
			if ch_obj.space_id == scene_ins_id then
				is_has_player_in = true
			else
				local is_ok = SceneService:moveScene(ch_obj, dst_scene_id, scene_ins_id, 0, dst_x, dst_y, true)
				if not is_ok then
					TianmoCtrl:_noticeBaseEntryFail(character, team_id)
				end
			end
		end
	end
	
	if is_has_player_in then
		Logger:info('[TianmoCtrl.b2m_entryAssignedRoom] is_has_player_in is true', dst_scene_id, character and character.id or '', character and character.nick or '')
		return
	end
	
	-- BOSS房间处理
	if dst_scene_id == TianmoConfig.boss_room_scene_id then
		TianmoService:recordTeam2BossRoom(character, group_id)
		
		local boss_room = TianmoService:getBossRoom(group_id)
		local all_gpids_new = {}
		if boss_room.history_team_num >= TianmoDefs.TIANMO_BOSS_ROOM_TEAM_NUM_MAX then
			-- 过滤掉当前队伍玩家
			for _, gpid in pairs(all_gpids) do
				if not members_gpids[gpid] then
					all_gpids_new[#all_gpids_new+1] = gpid
				end
			end
		else
			all_gpids_new = all_gpids
		end
		TianmoService:bcBossRoomTeamNumUp(boss_room, all_gpids_new)
	end
	
	-- 记录当前到达最高层的队伍数
	TianmoService:recordTopLayTeamNum(dst_scene_id, team_id, group_id)
	
	local lay = TianmoService:getLayBySid(dst_scene_id)
	if lay > 1 and first_enter_bc_data then
		TianmoService:setFirstEnter(character, first_enter_bc_data, lay)
	end
	
	Logger:warn('[TianmoCtrl:b2m_entryAssignedRoom] ', character and character.nick or 0, dst_scene_id)
end

function TianmoCtrl.b2m_createTianmoIns(_, pack_data)
	local tianmo_ins = pack_data.tianmo_ins
	
	-- 生成新的天魔实列对象
	TianmoService:reNewTianmoIns(tianmo_ins.group_id)
	
	-- 创建天魔灭心实列
	TianmoService:createTianmoIns(tianmo_ins)
	
	-- 创建BOSS房间
	TianmoService:createBossRoom(tianmo_ins)
end

function TianmoCtrl.endTianmo(_, pack_data)
	local tianmo_ins_id = pack_data.tianmo_ins_id
	local open_time = pack_data.open_time
	local group_id = pack_data.group_id
	
	-- 广播
	--NoticeService:sysMsgBcMap(OKMsgCodes.TIANMO_END_BOSS_NO_KILL_BC, monster_base.nick)
	
	-- 结束、发奖
	TianmoService:finish(group_id, false)
end

function TianmoCtrl.b2m_finish(_nil, pack_data)
	-- 获取参数
	local tianmo_ins_id = pack_data.tianmo_ins_id
	local is_win = pack_data.is_win
	local group_id = pack_data.group_id
	
	-- 结束、发奖
	TianmoService:finish(group_id, is_win)
end

-- 响应队伍退队消息
function TianmoCtrl.b2m_onTeamQuit(character, pack_data)
	local gcid = pack_data.gcid
	local nick = pack_data.nick
	local team_id = pack_data.team_id
	local scene_ins_id = pack_data.scene_ins_id
	TianmoService:onTeamQuit(scene_ins_id, team_id, gcid, nick)
end

-- 天魔定时广播
-- 广播当前达到最高层的队伍数
function TianmoCtrl.t2m_timerBc(pack_data)
	local tianmo_ins_id = pack_data.tianmo_ins_id
	local group_id = pack_data.group_id
	
	local tianmo_ins = TianmoService:getTianmoIns()
	if not tianmo_ins or tianmo_ins.id ~= tianmo_ins_id then
		return
	end
	
	-- BOSS房间是否已经关闭
	if TianmoService:isBossRoomClose(group_id) then
		return
	end
	
	-- 添加下一次广播定时器
	ServerCall:addTimer('TianmoCtrl.t2m_timerBc', 0, pack_data, TianmoDefs.TIANMO_TIMER_BC_INTERVAL * 1000, 1)
	
	-- 广播
	TianmoService:bcNowtopLayTeamNum(group_id)
end

-- 通知BASESERVER进入天魔灭心失败
function TianmoCtrl:_noticeBaseEntryFail(character, team_id)
	local pack_data = {}
	pack_data.team_id = team_id
	ServerCall:m2bCall('TianmoCtrl.m2b_entryFail', character.gcid, pack_data)
end