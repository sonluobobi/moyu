--[[
战斗系统ctrl
author : suwin zhong
date : 2014-10-21
--]]

FightCtrl = FightCtrl or {}

local WorldPacket = WorldPacket
local opCodes = opCodes
local errorCodes = errorCodes
local abs = math.abs
local tableInsert = table.insert
local sizeTable = table.sizeTable

local EFFECT_SORT_ID_NORMAL = SkillDefs.EFFECT_SORT_ID_NORMAL		-- 攻击类技能
local EFFECT_SORT_ID_RESTORE = SkillDefs.EFFECT_SORT_ID_RESTORE		-- 回血类技能
local EFFECT_SORT_ID_RELIVE = SkillDefs.EFFECT_SORT_ID_RELIVE		-- 复活技能
local EFFECT_SORT_ID_CONJURE = SkillDefs.EFFECT_SORT_ID_CONJURE		-- 召唤技能
local EFFECT_SORT_ID_BUFFER = SkillDefs.EFFECT_SORT_ID_BUFFER		-- buff技能
local EFFECT_SORT_ID_DODGE = SkillDefs.EFFECT_SORT_ID_DODGE			-- 闪避技能

local SKILL_ID_FOR_YIZHIJI = SkillDefs.SKILL_ID_FOR_YIZHIJI			-- 丧尸危机，抑制剂技能

local FightService = FightService
local g_fighter_aoi_id = 0

do
	-- local
	local Formula = Formula
	local readUInt = Packet.readUInt
	local readByte = Packet.readByte
	local readUShort = Packet.readUShort
	local readCoord = Packet.readCoord
	local FightDefs_FIGHT_ATTACK_DIST_ERR = FightDefs.FIGHT_ATTACK_DIST_ERR
	local upval_arr_pos = nil
	
	-- 战斗总接口(角色/幻兽/跟随类型的召唤兽等客户端触发的战斗包总入口)
	function FightCtrl.c2m_fight(character, packet)
		-- 客户端上传的参数
		local fight_number_id = readUInt(packet) -- 客户端用的，服务端没用
		local fighter_aoi_id = readUInt(packet)  -- 攻击者的aoi_id(角色/幻兽/召唤兽)
        local skill_id = readUShort(packet)		 -- 使用的技能id
        local targeter_aoi_id = readUInt(packet) -- 被攻击者的aoi_id
		local target_x = readCoord(packet)		 -- X坐标，无目标的技能，需要指向在哪里，例如放一个火焰在某个位置
		local target_y = readCoord(packet)		 -- Y坐标
		local fighter_new_x = readCoord(packet)	 -- 本次攻击后攻击者的新位置X坐标
		local fighter_new_y = readCoord(packet)	 -- Y坐标
		local targeter_new_x = readCoord(packet) -- 本次攻击后被攻击者的新位置X坐标
		local targeter_new_y = readCoord(packet) -- Y坐标
		---------------------------------------  -- 被攻击者数量(攻击类技能才有，在下面读取)
		---------------------------------------  -- 被攻击者aoi_id(攻击类技能才有，在下面读取)

		--print('c2mfight',fight_number_id,fighter_aoi_id,skill_id,targeter_aoi_id,target_x,target_y,fighter_new_x,fighter_new_y,targeter_new_x,targeter_new_y)
		--packet:dumpPkgAsString(0,0,false,"c2m_fight")
		--skill_id = 10311
		
		-- set vals
		g_fighter_aoi_id = fighter_aoi_id

		if not upval_arr_pos then
			upval_arr_pos = FightService:getDefaultPos()
		end
		upval_arr_pos.target_x = target_x
		upval_arr_pos.target_y = target_y
		upval_arr_pos.fighter_new_x = fighter_new_x
		upval_arr_pos.fighter_new_y = fighter_new_y
		upval_arr_pos.targeter_new_x = targeter_new_x
		upval_arr_pos.targeter_new_y = targeter_new_y

		-- local参数
		local keep_on = true
		local error_id = 0		  -- 错误id

		local aoiScene			  -- 攻击者所在的场景实例
		local fighter			  -- 攻击者对象
		local targeter			  -- 被攻击者
		local skill				  -- 技能对象
		local skillBase			  -- 技能基本信息
		local skill_distance	  -- 技能距离

		-- print('--------------------------------------------------------------------------')
		-- print('客户端参数：',  fighter_aoi_id, targeter_aoi_id, skill_id, character.x, character.y, targeter_new_x, targeter_new_y)
		-- table.dump(upval_arr_pos, 1)
		-- print('--------------------------------------------------------------------------')
		
		-- 基本参数检查
		if skill_id <= 0 or fighter_aoi_id <= 0 then
			error_id = errorCodes.COMMON_PARAM_MISS
			keep_on = false
		end

		if keep_on then
			-- 获取场景实例对象
			aoiScene = GameObjectService:getAoiScene(character)
			-- 检查是否安全场景等
			keep_on, error_id = FightService:checkScene(aoiScene)
		end

		if keep_on then
			fighter = GameObjectService:getGameObjectByAoiId(aoiScene, fighter_aoi_id)
			if not fighter then
				print("攻击者不存在", character.nick, fighter_aoi_id, skill_id)
				-- 攻击者已经离开场景，或已经消失
				return
			else
				-- 记录攻击者攻击时候的位置(为了与陷阱攻击统一起来)
				upval_arr_pos.fighter_attack_x = fighter.x
				upval_arr_pos.fighter_attack_y = fighter.y

				-- 检查攻击者是否活着/晕眩/或者是连击中....等等
				keep_on, error_id = FightService:checkFighter(fighter)
			end
		end

		if keep_on then
			if FightService:isBeast(fighter) then
				-- 检查父亲是否在存在于场景中，不存在就忽略掉此次攻击，不然后面的各种结算会出错
				local myParent = BeastService:getMyParent(aoiScene, fighter)
				if not myParent then
					-- 暂时未定位到何时会出现这种情况，但错误日志里有，所以这里先加上判断
					error_id = errorCodes.FIGHT_ERROR_TARGET_TYPE
					keep_on = false
				end
			end
		end

		if keep_on then
			-- 获取攻击者的技能对象
			skill = FightService:getFighterSkill(fighter, skill_id)

			-- 检查技能(技能是否存在/是否主动技能/cd时间是否已经到了/等等.....)
			keep_on, error_id = FightService:checkSkill(fighter, skill, targeter_aoi_id)
		end

		if keep_on then
			-- local
			skillBase = skill.skill_base

			-- 有些技能需要有攻击目标的，有些技能不需要有攻击目标的
			if 0 < targeter_aoi_id then
				-- 获取被攻击者
				targeter = GameObjectService:getGameObjectByAoiId(aoiScene, targeter_aoi_id)
				if not targeter then
					-- 找不到被攻击者
					keep_on = false
					error_id = errorCodes.FIGHT_ERROR_TARGET_NOT_EXIST
				end

				if keep_on then
					if FightService:isDead(targeter) then
						-- 被攻击者已经死亡
						keep_on = false
						error_id = errorCodes.FIGHT_THIS_TARGETER_BEEN_DEAD
					end
				end

				if keep_on then
					-- 检查攻击距离
					if not FightService:isFightDisOk(fighter, targeter, skill, FightDefs_FIGHT_ATTACK_DIST_ERR) then
						keep_on = false
						error_id = errorCodes.FIGHT_ERROR_TARGET_IS_FAR
						print("攻击距离太远...", fighter.nick or '幻兽或者蝙蝠', targeter.nick, skillBase.title, fighter.x, fighter.y, targeter.x, targeter.y)
					end
				end
			end
		end

		if keep_on then
			-- 检查场景事件
			keep_on, error_id = FightService:checkSceneEvent(aoiScene, fighter)
		end

		if keep_on then
			-- 技能效果调度
			local skill_effect_sort_id = skillBase.effect_sort_id

			-- 攻击类技能
			if EFFECT_SORT_ID_NORMAL == skill_effect_sort_id then --------------------- 攻击
				-- 角色攻击
				-- 幻兽攻击(类似绝代的侠客) / 召唤兽攻击(角色技能召唤出来的) --- 追随角色的召唤兽攻击(PS:静止的召唤兽是服务端触发的)
				if FightService:isLikeCharacter(fighter) or 
							FightService:isPet(fighter) or 
								FightService:isBeast(fighter)
						then

					-- 读取被攻击列表(信任客户端)
					local arr_targeter = FightCtrl:_getClientTargeterList(aoiScene, packet)
					-- 攻击
					FightCtrl:callFight(aoiScene, fighter, targeter, skill, arr_targeter, upval_arr_pos, fight_number_id)
					return

				else
					print("未知攻击者类型", fighter.aoi_type)
					return
				end

			elseif EFFECT_SORT_ID_BUFFER == skill_effect_sort_id then ----------------- 加buffer
				-- 加buff类的技能
				if FightService:isLikeCharacter(fighter) then
					local arr_targeter

					if SKILL_ID_FOR_YIZHIJI == skill_id then
						-- 丧尸危机里面的抑制剂，信任客户端上传的列表
						arr_targeter = FightCtrl:_getClientTargeterList(aoiScene, packet)
					end

					FightCtrl:callAddBuffer(aoiScene, fighter, skill, arr_targeter, upval_arr_pos, fight_number_id)
					return
				else
					print("只有角色/机器人可以使用加buffer技能")
				end

			elseif EFFECT_SORT_ID_CONJURE == skill_effect_sort_id then ----------------- 召唤
				-- 召唤类技能
				-- 角色召唤
				if FightService:isLikeCharacter(fighter) then
					FightCtrl:callHelper(aoiScene, fighter, skill, upval_arr_pos, fight_number_id)
					return
				else
					print("只有角色/机器人可以使用召唤技能")
				end
			
			elseif EFFECT_SORT_ID_DODGE == skill_effect_sort_id then ----------------- 闪避
				-- 闪避类技能
				if FightService:isLikeCharacter(fighter) then
					FightCtrl:callDodge(aoiScene, fighter, targeter, skill, upval_arr_pos, fight_number_id)
					return
				else
					print("只有角色/机器人可以使用召唤技能")
				end

			-- elseif EFFECT_SORT_ID_RESTORE == skill_effect_sort_id then
				-- 回血类技能

			-- elseif EFFECT_SORT_ID_RELIVE == skill_effect_sort_id then
				-- 复活类技能

			else
				print("未知技能类型", skillBase.title, skill_effect_sort_id)
			end
		else
			print("战斗包返回错误 error_id=",error_id,'(',errorCodeNames[error_id],')')
			-- 返回错误
			return FightService:fightError(character, error_id, fight_number_id, skill_id, g_fighter_aoi_id)
		end
	end	
	c_opHandlers[opCodes.C2M_FIGHT_FIGHT] = FightCtrl.c2m_fight


	-- 获取客户端上传的被攻击对象列表
	function FightCtrl:_getClientTargeterList(aoiScene, packet)
		-- 读取被攻击列表(信任客户端)
		local targeter_num = readUInt(packet) -- 本次被攻击的数量
		local arr_targeter = {}
		if 0 < targeter_num then
			local now_targeter_aoi_id, now_targeter
			for i = 1, targeter_num do
				now_targeter_aoi_id = readUInt(packet)
				now_targeter = GameObjectService:getGameObjectByAoiId(aoiScene, now_targeter_aoi_id)
				if now_targeter and (not FightService:isDead(now_targeter)) then
					-- 如果是怪物，检查是否在回防中
					if FightService:isMonster(now_targeter) then
						if not MonsterAiService:isHoming(now_targeter.tmps.now_state) then
							tableInsert(arr_targeter, now_targeter)
						end
					else
						tableInsert(arr_targeter, now_targeter)
					end
				end
			end
		end

		return arr_targeter
	end
end

----------------------------------------------------------- 具体逻辑实现 start ----------------------------------------------------------------

do
	-- 攻击类技能
	function FightCtrl:callFight(aoiScene, fighter, targeter, skill, arr_targeter, upval_arr_pos, fight_number_id)
		local keep_on = true
		local error_id = 0

		-- 初始化幻兽天赋
		FightService:initFighterPetTianFu(aoiScene, fighter)		

		-- 执行战斗逻辑
		keep_on, error_id, arr_targeter = FightService:doFight(aoiScene, fighter, targeter, upval_arr_pos, skill, arr_targeter)

		if keep_on then
			-- 技能cd
			FightService:updateSkillTime(fighter, skill)

			-- 正确的响应
			local ret_packet = FightService:buildBinPacket(aoiScene, fighter, targeter, skill, arr_targeter, upval_arr_pos, fight_number_id)
			if ret_packet then
				WorldPacket:m2cSendPacket(ret_packet)
			end

			-- 通知其他功能模块
			FightService:doAfterFight(aoiScene, fighter, targeter, arr_targeter)

			-- 替攻击者加buffer(之所以不放在doFight里面，是避免战士旋风斩多次触发)
			FightService:addBufferForFighter(aoiScene, fighter, skill, true)

			-- print("正常战斗包结束..........................................................")
		else
			print("战斗攻击包有错误，", fighter.nick, skill.skill_base.id, error_id)
			-- 返回错误
			FightService:fightError(fighter, error_id, fight_number_id, skill.skill_base.id, g_fighter_aoi_id)
		end
	end

	---------------------------------------------------------------------------------------------------------------------------------------------
	-- 召唤
	function FightCtrl:callHelper(aoiScene, fighter, skill, arr_pos, fight_number_id)
		-- local
		local skillBase = skill.skill_base
		local skillDetail = skill.skill_detail
		local traps = skillDetail.traps -- 召唤的是陷阱
		local beasts = skillDetail.beasts -- 召唤的是召唤兽

		if traps then
			-- 召唤的是陷阱
			FightService:callTraps(aoiScene, fighter, skill, arr_pos, fight_number_id)

			if 0 < skillBase.self_move_dist then
				-- 玩家瞬移到目标地方
				FightService:moveToPos(fighter, arr_pos.fighter_new_x, arr_pos.fighter_new_y)
				-- print("召唤 the fighter new pos is", fighter.x, fighter.y)
			end
		else
			-- 召唤的是召唤兽
			FightService:callBeast(aoiScene, fighter, skill, arr_pos, fight_number_id)
		end

		-- 技能cd
		FightService:updateSkillTime(fighter, skill)

		-- 非攻击类的战斗响应
		local ret_packet = FightService:buildNoAttackBinPacket(aoiScene, fighter, nil, skill, arr_pos, fight_number_id)
		if ret_packet then
			WorldPacket:m2cSendPacket(ret_packet)
		end

		-- print("正常召唤包结束..........................................................")
	end

	---------------------------------------------------------------------------------------------------------------------------------------------
	-- 加buffer
	function FightCtrl:callAddBuffer(aoiScene, fighter, skill, arr_targeter, arr_pos, fight_number_id)
		-- local
		local arr_buffer_id
		local is_need_bc_buffer = false

		local skill_id = skill.skill_base.id

		if SKILL_ID_FOR_YIZHIJI == skill_id then
			-- 丧尸危机里面的抑制剂
			if arr_targeter then
				-- print("抑制剂...")
				-- table.dump(arr_targeter, -1)

				local arr_buffers = skill.skill_detail.target_buffers or nil
				if arr_buffers then
					local targeter_num = sizeTable(arr_targeter)
					for i = 1, targeter_num do
						local now_targeter = arr_targeter[i]
						FightService:addBuffer(aoiScene, now_targeter, skill, arr_buffers)
					end
				end
			end

		else
			-- 战士的怒吼
			arr_buffer_id = FightService:addBufferForFighter(aoiScene, fighter, skill, false)
			is_need_bc_buffer = true
		end

		-- 技能cd
		FightService:updateSkillTime(fighter, skill)

		-- 非攻击类的战斗响应
		local ret_packet = FightService:buildNoAttackBinPacket(aoiScene, fighter, nil, skill, arr_pos, fight_number_id)
		if ret_packet then
			WorldPacket:m2cSendPacket(ret_packet)
		end

		if is_need_bc_buffer then
			-- 返回给自己buff列表(小蒋提供接口)
			BufferService:sendBuffers(aoiScene, fighter, arr_buffer_id)
		end
	end

	---------------------------------------------------------------------------------------------------------------------------------------------
	-- 闪避类技能
	function FightCtrl:callDodge(aoiScene, fighter, targeter, skill, arr_pos, fight_number_id)
		local keep_on = true
		local error_id = 0

		if not FightService:isSkillLocked(fighter) then
			keep_on = false
			error_id = errorCodes.FIGHT_FIGHTER_IS_NOT_LOCKED
		end

		if keep_on then
			-- 解除技能锁定(攻击者和目标者都要解除)
			fighter.tmps.lock_expire = 0

			targeter.tmps.lock_expire = 0
			targeter.tmps.fight_expire = 0

			-- 闪避技能者跳脱后新的位置
			FightService:moveToPos(fighter, arr_pos.fighter_new_x, arr_pos.fighter_new_y)
		
			-- 技能cd
			FightService:updateSkillTime(fighter, skill)

			-- 闪避技能的战斗响应
			local ret_packet = FightService:buildDodgeBinPacket(aoiScene, fighter, targeter, skill, arr_pos, fight_number_id)
			if ret_packet then
				WorldPacket:m2cSendPacket(ret_packet)
			end
		else
			print("战斗攻击包(闪避技能)有错误，", error_id)
			-- 返回错误
			FightService:fightError(fighter, error_id, fight_number_id, skill.skill_base.id, g_fighter_aoi_id)
		end
	end
end

----------------------------------------------------------- 具体逻辑实现 end ------------------------------------------------------------------

----------------------------------------------------------- 客户端计算伤害 start --------------------------------------------------------------
do
	local msg_name = "PackFight.C2M_FIGHT_CLIENT_FIGHT_HARM"
	function FightCtrl.c2m_clientFightHarm(character, packet)
		local arr_params, packet_id = packet:readParams(msg_name)
		local change_hp = arr_params.change_hp	-- 受击者的变化的血量

		-- local参数
		local keep_on = true
		local error_id = 0		-- 错误id

		-- 场景基本信息
		local sceneBase	= SceneBaseService:getSceneBaseById(character.scene_id)

		-- if 1 ~= sceneBase.is_client_calc_harm then
		if false then
			-- 角色所在的场景不允许客户端计算伤害结果
			keep_on = false
			error_id = errorCodes.FIGHT_THIS_SCENE_NO_CLIENT_HARM
		end

		if keep_on then
			if FightService:isDead(character) then
				-- 已经死亡
				keep_on = false
				error_id = errorCodes.FIGHT_THIS_TARGETER_BEEN_DEAD
			end
		end

		if keep_on then
			local aoiScene = GameObjectService:getAoiScene(character)

			FightService:addObjectHp(character, change_hp, 0, true, aoiScene)
		else
			-- 有错误
			WorldPacket:m2cSendErr(nil, nil, character.gpid, error_id)
		end
	end
	c_opHandlers[opCodes.C2M_FIGHT_CLIENT_FIGHT_HARM] = FightCtrl.c2m_clientFightHarm
end
----------------------------------------------------------- 客户端计算伤害 end ----------------------------------------------------------------

----------------------------------------------------------- 客户端让蝙蝠自爆 start ------------------------------------------------------------
do
	local readUInt = Packet.readUInt
	local ceil = math.ceil

	function FightCtrl.c2m_clientFightZiBao(character, packet)
		local fighter_aoi_id = readUInt(packet)  -- 蝙蝠自爆的aoi_id
        local target_aoi_id  = readUInt(packet)  -- 目标的aoi_id
		-- test
		-- local fighter_aoi_id = character.tmps.child_beast.move_aoi_id or 0
        -- local target_aoi_id  = 0

		-- local参数
		local keep_on = true
		local error_id = 0		-- 错误id

		local aoiScene			  -- 攻击者所在的场景实例
		local fighter			  -- 攻击者对象
		local targeter			  -- 被攻击者

		-- 基本参数检查
		if fighter_aoi_id <= 0 or target_aoi_id < 0 then
			error_id = errorCodes.COMMON_PARAM_MISS
			keep_on = false
		end

		-- if keep_on then
		if false then -- 战士/血族可以召唤出一个法师机器人来帮忙，这时候也会调用这个接口
			-- 目前只有召唤师才可以调用这个接口
			if not FightService:isZhaoHuanShi(character) then
				error_id = errorCodes.COMMON_ILLEGAL
				keep_on = false
			end
		end

		if keep_on then
			-- 获取场景实例对象
			aoiScene = GameObjectService:getAoiScene(character)
			-- 检查是否安全场景等
			keep_on, error_id = FightService:checkScene(aoiScene)
		end

		if keep_on then
			-- 攻击者不存在
			fighter = GameObjectService:getGameObjectByAoiId(aoiScene, fighter_aoi_id)
			if not fighter then
				error_id = errorCodes.FIGHT_FIGHTER_IS_NOT_EXIST
				keep_on = false
			end
		end

		if keep_on then
			-- 检查看看是否是召唤兽，并且是蝙蝠
			if not FightService:isBeast(fighter) then
				error_id = errorCodes.COMMON_ILLEGAL
				keep_on = false
			end

			if keep_on then
				-- 检查是否是是蝙蝠
				if 0 == fighter.speed then
					error_id = errorCodes.COMMON_ILLEGAL
					keep_on = false
				end
			end

			if keep_on then
				-- 检查是否是character的召唤出来的
				local myParent = BeastService:getMyParent(aoiScene, fighter)
				if not myParent then
					-- 暂时未定位到何时会出现这种情况，但错误日志里有，所以这里先加上判断
					error_id = errorCodes.FIGHT_ERROR_TARGET_TYPE
					keep_on = false
				end

				if keep_on then
					if not FightService:isRobot(myParent) then -- 机器人就不判断了
						if myParent ~= character then
							error_id = errorCodes.COMMON_ILLEGAL
							keep_on = false
						end
					end
				end
			end
		end

		if keep_on then
			-- 有可攻击对象
			if 0 < target_aoi_id then
				targeter = GameObjectService:getGameObjectByAoiId(aoiScene, target_aoi_id)
				if not targeter then
					error_id = errorCodes.FIGHT_ERROR_TARGET_NOT_EXIST
					keep_on = false
				end
			end
		end

		if keep_on then
			local tf_radius, tf_harm_num, tf_harm_radix, tf_bianfu_add_harm_radix = FightService:getPetTianFuZiBao(character)

			local arr_params = fighter.beast_base.zibao_params
			local radius = arr_params.radius			-- 半径
			local harm_radix = arr_params.harm_radix	-- 自爆系数
			local harm_num = arr_params.harm_num		-- 伤害人数
			-- print("自爆参数", radius, harm_radix, harm_num)

			-- 蝙蝠自爆伤害值 = (蝙蝠最大攻击 + 蝙蝠最小攻击) / 2 * 自爆系数
			local harm = ceil((fighter.max_attack + fighter.min_attack) / 2 * harm_radix * (1 + tf_bianfu_add_harm_radix))

			-- 执行自爆
			FightService:doZiBao(aoiScene, character, fighter, radius, harm_num, harm, targeter)

			-- 小蒋提供接口(要放在最后面，自爆之后)
			GameObjectService:delObjByAoiId(aoiScene, fighter_aoi_id)
			-- character.tmps.child_beast.move_aoi_id = 0 -- 此时的move_aoi_id其实并不是这只蝙蝠
		else
			-- 有错误
			WorldPacket:m2cSendErr(nil, nil, character.gpid, error_id)
		end
	end
	c_opHandlers[opCodes.C2M_FIGHT_CLIENT_ZI_BAO] = FightCtrl.c2m_clientFightZiBao
end
----------------------------------------------------------- 客户端让蝙蝠自爆 end --------------------------------------------------------------

----------------------------------------------------------- 客户端更新伤害系数 start ----------------------------------------------------------
do
	local UPDATE_FIGHT_RADIX_TYPE_ID_FOR_NONE = FightDefs.UPDATE_FIGHT_RADIX_TYPE_ID_FOR_NONE   -- 无加成
	local UPDATE_FIGHT_RADIX_TYPE_ID_FOR_LOVER = FightDefs.UPDATE_FIGHT_RADIX_TYPE_ID_FOR_LOVER -- 同时在线
	local UPDATE_FIGHT_RADIX_TYPE_ID_FOR_LOVER_TEAM = FightDefs.UPDATE_FIGHT_RADIX_TYPE_ID_FOR_LOVER_TEAM -- 一起组队加成

	local ret_data = {}
	function FightCtrl.c2m_updateFightRadix(character, packet)
		local params = packet:readParams()
		local type_id = params.type_id -- 更新的类型

		-- local参数
		local keep_on = true
		local error_id = 0		-- 错误id
		local lover_radix = 0

		if type_id and (type_id == UPDATE_FIGHT_RADIX_TYPE_ID_FOR_NONE) then
			-- 无加成
			lover_radix = 0

		elseif type_id and (type_id == UPDATE_FIGHT_RADIX_TYPE_ID_FOR_LOVER) then
			-- 情侣在线
			lover_radix = LoversDefs.LOVERS_ONLINE_ADD_PERCENT

		elseif type_id and (type_id == UPDATE_FIGHT_RADIX_TYPE_ID_FOR_LOVER_TEAM) then
			-- 情侣组队
			lover_radix = LoversDefs.LOVERS_ONLINE_ADD_PERCENT_TEAM

		else
			-- 参数错误
			keep_on = false
			error_id = errorCodes.COMMON_PARAM_ERROR
		end

		if keep_on then
			-- 更新
			character.tmps_ex.lover_fight_radix = lover_radix

			-- 响应
			ret_data.opcode = opCodes.M2C_FIGHT_UPDATE_FIGHT_RADIX
			WorldPacket:m2cSendOK(ret_data, packet, character.gpid)
		else
			-- 有错误
			WorldPacket:m2cSendErr(nil, nil, character.gpid, error_id)
		end
	end
	c_opHandlers[opCodes.C2M_FIGHT_UPDATE_FIGHT_RADIX] = FightCtrl.c2m_updateFightRadix
end
----------------------------------------------------------- 客户端更新伤害系数 end ------------------------------------------------------------