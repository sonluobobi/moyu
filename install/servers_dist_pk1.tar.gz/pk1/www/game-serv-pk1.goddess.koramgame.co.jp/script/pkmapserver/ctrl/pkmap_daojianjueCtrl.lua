--[[
帝国争锋系统ctrl
author : guoyin.huang
]]--

local c_opHandlers = c_opHandlers
local opCodes = opCodes
local WorldPacket = WorldPacket
local send_error = WorldPacket.m2cSendDebugError

DaojianjueCtrl = DaojianjueCtrl or {}


-- 获取角色技能信息
do
	function DaojianjueCtrl.c2m_guajiLeave(character, packet)
		DaojianjueService:guajiLeave( character )
	end
	c_opHandlers[opCodes.C2PKM_DJJ_GUAJI_LEAVE] = DaojianjueCtrl.c2m_guajiLeave
end
