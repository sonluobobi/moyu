--[[
3V3玩法ctrl
author : guoyin.huang
date : 2015-04-21
]]--

G3v3Ctrl = G3v3Ctrl or {}

	function G3v3Ctrl.c2pkm_match(character, packet)
		local ch_data = {}
		ch_data.gcid = character.gcid
		ch_data.gpid = character.gpid
		ch_data.level = character.level
		ch_data.top_fight_capacity = character.top_fight_capacity
		ch_data.nick = character.nick
		ServerCall:m2bCall('G3v3Service:c2b_match', character.gcid, ch_data)
	end