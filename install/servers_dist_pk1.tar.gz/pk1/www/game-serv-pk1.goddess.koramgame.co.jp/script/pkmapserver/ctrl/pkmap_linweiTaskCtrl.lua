--[[
翅膀Dao，用于数据管理
author : guoyin.huang
date : 2014年12月10日
]]--

LinweiTaskCtrl = LinweiTaskCtrl or {}


do	--离开队伍
	local msg_name = "PackLinwei.C2PKM_LINWEI_TASK_ACCEPT"
	function LinweiTaskCtrl.c2pkm_accept(character, packet)
		local aoi_scene = GameObjectService:getAoiScene(character)
		
		local arr_params = packet:readParams(msg_name)
		local ok, err_id,err_params = LinweiTaskService:acceptTask( character, arr_params )
		if not ok then 
			WorldPacket:m2cSendErr(nil, nil, character.gpid, err_id, err_params)
		end
	end
end
c_opHandlers[opCodes.C2PKM_LINWEI_TASK_ACCEPT] = LinweiTaskCtrl.c2pkm_accept