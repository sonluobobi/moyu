--[[
复活系统ctrl
author : suwin zhong
date : 2014-11-08
--]]

local WorldPacket = WorldPacket
local errorCodes = errorCodes

ReliveCtrl = ReliveCtrl or {}

do 	--复活
	local msg_name = "PackRelive.C2M_RELIVE_RELIVE"
	function ReliveCtrl.c2m_relive(character, packet)
		-- 判断角色是否死亡
		if not FightService:isDead(character) then
			-- 直接发送复活消息
			ReliveService:sendReliveMsg(character)
			return
		end

		local arr_params = packet:readParams(msg_name)
		local relive_type_id = arr_params.relive_type_id
		
		local is_ok, err = true, 0		

		------------------------------ 复活逻辑 start --------------------------------------
		if relive_type_id == ReliveDefs.RELIVE_TYPE_ID_FOR_LOCAL then -- id 2
			local is_free = false

			-- 判断是否允许原地复活
			local sceneBase = SceneBaseService:getSceneBaseById(character.scene_id)
			local is_allow_local_relive = sceneBase.is_en_yuandi_relive or 0
			if 0 == is_allow_local_relive  then
				is_ok, err = false, errorCodes.COMMON_NOT_ALLOW_RELIVE_LOCAL
			end
			local scene_sort_id = sceneBase.scene_sort_id
			if scene_sort_id == SceneDefs.SCENE_SORT_ID_DAOJJ_WAR or
			   scene_sort_id == SceneDefs.SCENE_SORT_ID_TIANMO or
			   scene_sort_id == SceneDefs.SCENE_SORT_ID_3V3 then 
				is_ok, err = false, errorCodes.COMMON_NOT_ALLOW_RELIVE_LOCAL
			end

		else
			-- 普通复活
			local normal_relive_expire = character.tmps.normal_relive_expire or 0

			-- 判断CD时间是否已到(留多二秒，以防客户端时间误差)
			if normal_relive_expire - 2 > Time:getSecondsNow() then
				is_ok, err = false, errorCodes.COMMON_NORMAL_DEAD_NOT_EXPIRE
			end
		end
		------------------------------ 复活逻辑 end ----------------------------------------

		if is_ok then
			-- 角色复活
			ReliveService:characterRelive(character, relive_type_id == ReliveDefs.RELIVE_TYPE_ID_FOR_LOCAL)
		else
			-- 会走到这一步，肯定是有错误
			WorldPacket:m2cSendErr(nil, nil, character.gpid, err, nil)
		end
	end
	c_opHandlers[opCodes.C2M_RELIVE_RELIVE] = ReliveCtrl.c2m_relive
end

do 	-- 获取玩家复活信息
	local msg_name = "PackRelive.C2M_RELIVE_GET_INFO"
	function ReliveCtrl.c2m_getReliveInfo(character, packet)
		ReliveService:sendReliveInfo(character)
	end
	c_opHandlers[opCodes.C2M_RELIVE_GET_INFO] = ReliveCtrl.c2m_getReliveInfo
end

