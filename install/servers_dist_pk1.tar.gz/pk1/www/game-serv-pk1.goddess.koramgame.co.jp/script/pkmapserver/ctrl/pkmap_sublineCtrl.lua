--[[
副本 CTRL
author : xingzeng.jiang
date : 2015-04-16
--]]

SublineCtrl = SublineCtrl or {}
local SublineCtrl = SublineCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local external = external
local send_error = WorldPacket.m2cSendDebugError
local errorCodes = errorCodes
local SublineService = SublineService

-- 副本通关
do
	local msg = "PackSubline.C2M_SUBLINE_FINISH"
	function SublineCtrl.c2m_pass(character, packet)
		local params = packet:readParams(msg)
		local is_win = params.is_win
		local aoi_scene = GameObjectService:getAoiScene(character)
		
		assert(aoi_scene, character.id)
		
		SublineService:pass(aoi_scene, is_win)
		
		if is_win then
			-- 广播进入多人噩梦副本
			
		end
	end
	c_opHandlers[opCodes.C2M_SUBLINE_FINISH] = SublineCtrl.c2m_pass
end
