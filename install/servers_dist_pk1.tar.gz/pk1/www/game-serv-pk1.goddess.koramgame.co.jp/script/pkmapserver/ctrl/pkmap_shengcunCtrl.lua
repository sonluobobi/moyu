--[[
丧尸玩法ctrl
author : guoyin.huang
date : 2015-04-21
]]--

ShengcunCtrl = ShengcunCtrl or {}

do	--- 获取3V3状态
	local msg_name = "PackShengcun.C2PKM_SHENGCUN_START_ZHANLING"
	function ShengcunCtrl.c2pkm_startZhanling(character, packet)
		local params = packet:readParams(msg_name)
		local id = params.id
		ShengcunService:startZhanling(character, id)
	end
end
c_opHandlers[opCodes.C2PKM_SHENGCUN_START_ZHANLING] = ShengcunCtrl.c2pkm_startZhanling

