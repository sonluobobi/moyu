--[[
竞技场系统CTRL
author : xingzeng.jiang
date : 2014-11-08
--]]

GlobalArenaCtrl = GlobalArenaCtrl or {}

local ArenaService = ArenaService
local WorldPacket = WorldPacket
local GlobalArenaDefs = GlobalArenaDefs
local send_error = WorldPacket.m2cSendDebugError
local ARENA_MAP_ID = GlobalArenaDefs.ARENA_MAP_ID
local math = math
local LanguagePriceFunc = LanguagePriceFunc
local ArenaConfig = ArenaConfig
local is_load_bw_chip_data = false

-- DB获取到竞技场角色详细属性
function GlobalArenaCtrl.d2m_load(character, packet)
	local arr_params = packet:readParams()
	local arena_robot_details = arr_params.arena_robot_details
	local arena_ch_details = arr_params.arena_ch_details
	local toplist = arr_params.toplist

	-- 检查是否在MAP1
	assert(g_mapserver_id == ARENA_MAP_ID)

	-- 玩家数据
	if arena_ch_details then 
		for _, ch_arena in pairs(arena_ch_details) do
			if ch_arena.group_id <= 0 then 
				ch_arena.group_id = PkserverMappingService:getGroupId(ch_arena.area_id,Statics.PK_GAME_TYPE_ID_ZHUSHEN)
			end

			-- 只有能取得有效组ID的玩家数据才导入
			if ch_arena.group_id then 
				GlobalArenaService:createGroupData( ch_arena.group_id )
				-- 解析详细数据
				ch_arena.ch_detail = WorldPacket:decodeData(ch_arena.ch_detail)
				-- 保存到DAO
				GlobalArenaService:saveChArenaData(ch_arena, false)
			end

			if GlobalArenaDao.global_id_start < ch_arena.id then 
				GlobalArenaDao.global_id_start = ch_arena.id
			end			
		end

		for group_id, _ in pairs(GlobalArenaDao.ranks_with_robot) do
			GlobalArenaService:sort(group_id)
		end		
	end

	-- 机器人数据
	if arena_robot_details then 
		local robot_num = #arena_robot_details
		-- 通过数据库中的机器人数据，生成100个随机名字的机器人
		local now_cid = 1
		for cid=1, 100 do
			local robot = arena_robot_details[cid%robot_num + 1]
			local nick  = TeamRobotNicksDao.nicks[cid]
			local robot_arena = GlobalArenaService:newRobotArena( robot, cid,  nick)
			GlobalArenaDao.arenaid_2_arena[robot_arena.id] = robot_arena
			table.insert(GlobalArenaDao.robots, robot_arena)
		end
	end

	-- 排行榜数据
	if toplist then 
		for _, top in pairs(toplist) do
			top.oldrank = top.rank
			if top.group_id <= 0 then 
				top.group_id = PkserverMappingService:getGroupId(top.area_id,Statics.PK_GAME_TYPE_ID_ZHUSHEN)
			end
			if top.group_id then
				GlobalArenaService:createGroupData( top.group_id )
				table.insert(GlobalArenaDao.toplist[top.group_id], top)
				GlobalArenaDao.uk_2_top[top.group_id][top.unique_key] = top
			end
		end
		for group_id, toplist in pairs(GlobalArenaDao.toplist) do
			table.sort(toplist, function ( l, r )
				return l.rank < r.rank
			end)
		end
	end
end
i_opHandlers[opCodes.D2M_ARENA_LOAD] = GlobalArenaCtrl.d2m_load


-- 竞赛时间结束，生成排行榜
function GlobalArenaCtrl.b2m_genToplist(sid, packet)
	-- 发送到DB生成排行榜(防止有数据未保存完整)
	local to_db_data = {base_sid=sid}
	to_db_data.opcode = opCodes.M2D_GLOBAL_ARENA_GEN_TOPLIST
	WorldPacket:m2dSendOK(to_db_data, nil, 0)

	-- 本地生成排行榜并发送到BASE，因为末日之战需要使用
	
	GlobalArenaDao.toplist = {}
	GlobalArenaDao.uk_2_top = {}
	
	for group_id, _ in pairs(GlobalArenaDao.ranks) do
		GlobalArenaService:sort(group_id)

		-- 将排行数据存到排行榜字段中
		GlobalArenaDao.toplist[group_id] = {}
		for k, v in pairs(GlobalArenaDao.ranks[group_id]) do
			GlobalArenaDao.toplist[group_id][k] = v
		end
		
		GlobalArenaDao.uk_2_top[group_id] = {}
		for k, v in pairs(GlobalArenaDao.ch_arena_details[group_id]) do
			GlobalArenaDao.uk_2_top[group_id][k] = v
		end
	end


	-- 将非机器人的数据清理掉
	for id, arena in pairs(GlobalArenaDao.arenaid_2_arena) do
		if not arena.is_robot then 
			GlobalArenaDao.arenaid_2_arena[id] = nil
		end
	end
	
	local to_base_data = {}
	for group_id, _ in pairs(GlobalArenaDao.toplist) do
		
		-- 将排行榜前面的发到BASE，供末日之战判断是否可以参加使用
		
		for i=1, GlobalArenaDefs.FINAL_WAR_PLAYER_NUM do
			local arena = GlobalArenaDao.toplist[group_id][i]
			if arena then 
				local tmp = {}
				tmp.unique_key = arena.unique_key
				tmp.score = arena.score
				tmp.rank = arena.rank
				tmp.group_id = group_id
				tmp.area_id = arena.area_id
				table.insert(to_base_data, tmp)
			end
		end
	end
	-- 清除不需要保留的数据
	table.clearTable(GlobalArenaDao.ranks)
	table.clearTable(GlobalArenaDao.ch_arena_details)
	table.clearTable(GlobalArenaDao.arenaid_2_history)
	table.clearTable(GlobalArenaDao.pking_data)
	table.clearTable(GlobalArenaDao.ranks_with_robot)
	ServerCall:m2bCall('GlobalArenaService:loadTopList', 0, to_base_data)
end

-- 发送排行奖励
function GlobalArenaCtrl.b2m_rewardToplist(sid, packet)
	-- 发送奖励
	for group_id, group_toplist in pairs(GlobalArenaDao.toplist) do
		for _, arena in pairs(group_toplist) do
			local gcid = arena.gcid
			local gpid = external.mergeUInt(arena.area_id, arena.player_id)
			RewardService:reward(Statics.PK_GAME_TYPE_ID_ZHUSHEN_TOP_REWARD, 0, gpid, gcid, {rank=arena.rank, cid=arena.cid, player_id=arena.player_id})
		end
	end
end

do  -- 获取数据
	function GlobalArenaCtrl.c2m_getChGlobalArenaInfo(character, packet)
		GlobalArenaService:sendArenaData(character)
	end
	c_opHandlers[opCodes.C2PKM_GLOBAL_ARENA_GET_INFO] = GlobalArenaCtrl.c2m_getChGlobalArenaInfo
end


do  -- 报名
	function GlobalArenaCtrl.c2m_baoming(character, packet)
		local is_ok, err = GlobalArenaService:baoming(character)
		if not is_ok then 
			WorldPacket:m2cSendErr(nil, nil, character.gpid, err, nil)
		end
	end
	c_opHandlers[opCodes.C2PKM_GLOBAL_ARENA_BAOMING] = GlobalArenaCtrl.c2m_baoming
end


do  -- 刷新
	function GlobalArenaCtrl.c2m_refresh(character, packet)
		GlobalArenaService:sendArenaDataUpdate(character)
	end
	c_opHandlers[opCodes.C2PKM_GLOBAL_ARENA_REFRESH] = GlobalArenaCtrl.c2m_refresh
end

do  -- 开始PK
	local msg_name = "PackGlobalArena.C2PKM_GLOBAL_ARENA_PK_START"
	function GlobalArenaCtrl.c2m_startPK(character, packet)
		local params = packet:readParams(msg_name)
		local passive_arena_id = params.passive_arena_id
		local is_ok, err = GlobalArenaService:startPk(character, passive_arena_id)
		if not is_ok then 
			WorldPacket:m2cSendErr(nil, nil, character.gpid, err, nil)
		end
	end
	c_opHandlers[opCodes.C2PKM_GLOBAL_ARENA_PK_START] = GlobalArenaCtrl.c2m_startPK
end

do  -- PK完成
	local msg_name = "PackGlobalArena.C2PKM_GLOBAL_ARENA_PK_FINISH"
	function GlobalArenaCtrl.c2m_finishPK(character, packet)
		local params = packet:readParams(msg_name)
		local passive_arena_id = params.passive_arena_id
		local is_win = params.is_win
		local is_ok, err = GlobalArenaService:finishPk( character,passive_arena_id, is_win)
		if not is_ok then 
			WorldPacket:m2cSendErr(nil, nil, character.gpid, err, nil)
		end
	end
	c_opHandlers[opCodes.C2PKM_GLOBAL_ARENA_PK_FINISH] = GlobalArenaCtrl.c2m_finishPK
end

do  -- 获取被PK历史
	local msg_name = "PackGlobalArena.C2PKM_GLOBAL_ARENA_GET_HISTORY"
	function GlobalArenaCtrl.c2m_getPKHistory(character, packet)
		local my_arena = GlobalArenaService:getArenaDt(character)
		if not my_arena then 
			WorldPacket:m2cSendCommEmpty(character.gpid)
		end

		local pk_history = GlobalArenaService:getPKHistory( character )
		if not pk_history then 
			WorldPacket:m2cSendCommEmpty(character.gpid)
			-- 从DB获取
			GlobalArenaService:m2d_getPKHistory( character )
		else
			GlobalArenaService:sendPKHistory(character)
		end
	end
	c_opHandlers[opCodes.C2PKM_GLOBAL_ARENA_GET_HISTORY] = GlobalArenaCtrl.c2m_getPKHistory
end