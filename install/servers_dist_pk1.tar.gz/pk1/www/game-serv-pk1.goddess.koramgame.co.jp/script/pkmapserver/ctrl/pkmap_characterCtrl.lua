--[[
角色系统 ctrl
author : suwin zhong
date : 2014-10-14
--]]

CharacterCtrl = CharacterCtrl or {}
local CharacterCtrl = CharacterCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local CharacterDefs = CharacterDefs
local ostime = os.time
local osdate = os.date
local pairs = pairs
local assert = assert
local Time = Time
local UNumber = UNumber
local errorCodes = errorCodes

local g_mapserver_id = g_mapserver_id


-- 角色初始化(上线初始化/mapserver切换等)
do
	function CharacterCtrl:init(cplr, is_login, packet)
		-- 创建一个character
		local character = Character:new(cplr)

		WorldPacket.g_character = character
	
		-- 将character绑定到cplr
		cplr:bindLuaPlayer(character)
	
		-- 填充character对象
		local arr_params = packet:readTable()
		local arr_base_attribs = packet:readTable() -- 从base带过来的额外属性

		local db_character = arr_params.character	-- 从数据库中/从map打包得到的character属性
		for k, v in pairs(arr_base_attribs) do		-- 把base属性填充进去
			db_character[k] = v
		end
		
		local gpid = cplr:getGpid()
		local gcid = cplr:getGcid()

		local brecalc_ch_attrib, brecalc_part_arr
		character:init(db_character)
		character.gpid = gpid
		character.gcid = gcid
		
		-- 往该方法里面注册初始化函数
		CharacterService:initObject(character, is_login)
		
		-- 登陆
		if is_login then
		end

		return character
	end
end


-- 玩家重连
-- character : 角色对象
function CharacterCtrl:reconnect(character)
	local packet_id = WorldPacket.g_packet_id
	
	local scenes = character.scenes		-- 上一次场景信息
	local space_id = character.space_id	-- 场景实例id
	local scene_id = character.scene_id -- 场景原始id
	local line_id = scenes.line_id		-- 分线
	print("角色断线重连", character.id, character.nick, space_id, scene_id, line_id)
	
	-- 重连后继续进入原来所在场景
	local params = {}
	params.space_id = space_id
	params.scene_id = scene_id
	params.line_id = line_id
	params.is_login	= false		-- 第一次登录/切换场景
	params.is_reconnect	= true  -- 是否是掉线重连
	SceneCtrl:enterScene(character, params, packet_id)	
end


-- 离线 之前
function CharacterCtrl:try_logout(character, packet_id)
	print("pk服准备离线", character.id, character.nick)
end


do
	-- 离线 , 玩家已经离开场景了
	-- character : 角色对象
	-- packet_id : 数据包id
	function CharacterCtrl:logout(character, packet_id)
		local space_id = character.space_id	-- 场景实例id
		local scene_id = character.scene_id -- 场景原始id
		print("pk服离线完成", character.id, character.nick)
		
		-- 清掉缓存数据
		character.is_keep_appear_bin = nil

		-- 从场景里离开
		SceneCtrl:leaveScene(character, 2, packet_id)
		
		character.c_obj:onLogoutCallBack(true, packet_id)
		character.c_obj = nil
	end
end


do
	local arr_ret_data = {}
	-- 查看其他玩家数据
	function CharacterCtrl.pkb2pkm_viewOther(character, packet)
		local arr_params = packet:readParams()
		local bc_gpid = arr_params.bc_gpid -- 把我的信息广播给这个人
		
		-- 简单的角色信息
		arr_ret_data['character_simple'] = character

		-- 坐骑id(小蒋提供接口)
		arr_ret_data['horse_id'] = ChHorseService:getHorseId(character)

		-- 幻兽id+战力(小蒋提供接口)
		arr_ret_data['pet_simple'] = ChPetService:getFightHetiCPets(character)
		
		-- 响应给客户端
		local opcode = opCodes.PKM2C_CHARACTERS_VIEW_OTHER
		local msg_name = 'PackViewCharacter.PKM2C_CHARACTERS_VIEW_OTHER'
		WorldPacket:m2cSendOKProtoBuf(opcode, msg_name, arr_ret_data, packet, bc_gpid)
	end
	i_opHandlers[opCodes.PKB2PKM_CHARACTERS_VIEW_OTHER] = CharacterCtrl.pkb2pkm_viewOther
end