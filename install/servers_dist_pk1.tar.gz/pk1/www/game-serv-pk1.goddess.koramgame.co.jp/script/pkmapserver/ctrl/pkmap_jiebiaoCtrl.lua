--[[
劫镖 入口
author : jinlin.liu
date : 2016年04月13日
]]--

JieBiaoCtrl = JieBiaoCtrl or {}
local JieBiaoService = JieBiaoService
local errorCodes = errorCodes

do	--离开队伍
	local msg_name = "PackJb.C2PKM_JB_TASK_ACCEPT"
	function JieBiaoCtrl.c2pkm_accept(character, packet)
		local arr_params = packet:readParams(msg_name)
		if arr_params and arr_params.type then
  		JieBiaoService:join(character,arr_params.type)
  	else
  	 	WorldPacket:m2cSendErr(nil, nil, character.gpid, errorCodes.JB_JOIN_PARAM_ERROR)
		end
	end
end
c_opHandlers[opCodes.C2PKM_JB_TASK_ACCEPT] = JieBiaoCtrl.c2pkm_accept