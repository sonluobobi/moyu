--[[
爱情圣殿ctrl
author : guoyin.huang
date : 2015-04-21
]]--

LoverTempleCtrl = LoverTempleCtrl or {}

do	--- 接任务
	local msg_name = "PackLoverTemple.C2PKM_LOVE_TEMPLE_ACCEPT"
	function LoverTempleCtrl.c2pkm_accept(character, packet)
		local arr_params= packet:readParams(msg_name)
		local aoi_scene = GameObjectService:getAoiScene(character)
		local is_ok, error_id = LoverTempleService:acceptTask(aoi_scene, character, arr_params )
		if not is_ok then 
			return WorldPacket:m2cSendErr(nil, nil, character.gpid, error_id, nil)
		end
	end
end
c_opHandlers[opCodes.C2PKM_LOVE_TEMPLE_ACCEPT] = LoverTempleCtrl.c2pkm_accept

do	--- 完成任务
	local msg_name = "PackLoverTemple.C2PKM_LOVE_TEMPLE_FINISH"
	function LoverTempleCtrl.c2pkm_finish(character, packet)
		local arr_params= packet:readParams(msg_name)
		local aoi_scene = GameObjectService:getAoiScene(character)
		local is_ok, error_id = LoverTempleService:finishTask( aoi_scene, character, arr_params )
		if not is_ok then 
			return WorldPacket:m2cSendErr(nil, nil, character.gpid, error_id, nil)
		end
	end
end
c_opHandlers[opCodes.C2PKM_LOVE_TEMPLE_FINISH] = LoverTempleCtrl.c2pkm_finish

do	--- 放弃任务
	local msg_name = "PackLoverTemple.C2PKM_LOVE_TEMPLE_GIVE_UP"
	function LoverTempleCtrl.c2pkm_giveup(character, packet)
		local arr_params= packet:readParams(msg_name)
		local aoi_scene = GameObjectService:getAoiScene(character)
		local is_ok, error_id = LoverTempleService:giveupTask( aoi_scene, character, arr_params )
		if not is_ok then 
			return WorldPacket:m2cSendErr(nil, nil, character.gpid, error_id, nil)
		end
	end
end
c_opHandlers[opCodes.C2PKM_LOVE_TEMPLE_GIVE_UP] = LoverTempleCtrl.c2pkm_giveup


-- 以下为采集与挖宝相关的请求
do	--- 开始采集
	local msg_name = "PackLoverTemple.C2PKM_LOVE_TEMPLE_CAIJI_START"
	local rsp_opcode = opCodes.PKM2C_LOVE_TEMPLE_CAIJI_START
	local resp_msg_name = "PackLoverTemple.PKM2C_LOVE_TEMPLE_CAIJI_START"
	function LoverTempleCtrl.startCaiji(character, packet)
		local arr_params= packet:readParams(msg_name)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, resp_msg_name, arr_params, nil, character.gpid)
	end
end
c_opHandlers[opCodes.C2PKM_LOVE_TEMPLE_CAIJI_START] = LoverTempleCtrl.startCaiji

do	--- 结束采集
	local msg_name = "PackLoverTemple.C2PKM_LOVE_TEMPLE_CAIJI_FIN"
	local resp_msg_name = "PackLoverTemple.PKM2C_LOVE_TEMPLE_CAIJI_FIN"
	local rsp_opcode = opCodes.PKM2C_LOVE_TEMPLE_CAIJI_FIN
	function LoverTempleCtrl.finishCaiji(character, packet)
		local arr_params= packet:readParams(msg_name)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, resp_msg_name, arr_params, nil, character.gpid)
		local aoi_scene = GameObjectService:getAoiScene(character)
		LoverTempleService:onFinCaiji( aoi_scene, character, arr_params.caiji_id )		
	end
end
c_opHandlers[opCodes.C2PKM_LOVE_TEMPLE_CAIJI_FIN] = LoverTempleCtrl.finishCaiji

do	--- 开始挖宝
	local msg_name = "PackLoverTemple.C2PKM_LOVE_TEMPLE_WABAO_START"
	local resp_msg_name = "PackLoverTemple.PKM2C_LOVE_TEMPLE_WABAO_START"
	local rsp_opcode = opCodes.PKM2C_LOVE_TEMPLE_WABAO_START
	function LoverTempleCtrl.startWabao(character, packet)
		local arr_params= packet:readParams(msg_name)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, resp_msg_name, arr_params, nil, character.gpid)
	end
end
c_opHandlers[opCodes.C2PKM_LOVE_TEMPLE_WABAO_START] = LoverTempleCtrl.startWabao

do	--- 结束挖宝
	local msg_name = "PackLoverTemple.C2PKM_LOVE_TEMPLE_WABAO_FIN"
	local resp_msg_name = "PackLoverTemple.PKM2C_LOVE_TEMPLE_WABAO_FIN"
	local rsp_opcode = opCodes.PKM2C_LOVE_TEMPLE_WABAO_FIN
	function LoverTempleCtrl.finishWabao(character, packet)
		local arr_params= packet:readParams(msg_name)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, resp_msg_name, arr_params, nil, character.gpid)
		local aoi_scene = GameObjectService:getAoiScene(character)
		LoverTempleService:onFinWabao( aoi_scene, character, arr_params )
	end
end
c_opHandlers[opCodes.C2PKM_LOVE_TEMPLE_WABAO_FIN] = LoverTempleCtrl.finishWabao
