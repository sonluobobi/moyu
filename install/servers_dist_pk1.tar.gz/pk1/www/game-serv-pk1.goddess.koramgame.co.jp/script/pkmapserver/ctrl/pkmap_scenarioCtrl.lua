--[[
剧情系统 CTRL
author : xingzeng.jiang
date : 2014-07-15
--]]

ScenarioCtrl = ScenarioCtrl or {}
local ScenarioCtrl = ScenarioCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local external = external
local send_error = WorldPacket.m2cSendDebugError
local errorCodes = errorCodes
local ScenarioService = ScenarioService
local GameObjectService = GameObjectService
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
local aoi_type_trap = AoiObjectType.AOI_OBJECT_TYPE_ID_TRAP
local math_random, math_min, math_max = math.random, math.min, math.max
local ScenarioDefs = ScenarioDefs

-- 初始化剧情状态
do
	local msg = "PackScenario.C2M_SCENARIO_INIT_STATES"
	function ScenarioCtrl.c2m_iniStates(character, packet)				
		local params = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id
		local states = params.states
		
		if scene_ins_id <= 0 or type(states) ~= 'table' then
			return send_error('[ScenarioCtrl.c2m_iniStates] params error')
		end
		
		local aoi_scene = GameObjectService:getAoiSceneBySpaceId(scene_ins_id)
		if not aoi_scene then
			Logger:error('[ScenarioCtrl.c2m_iniStates] aoi_scene is nil. cid,scene_id,space_id,scene_ins_id=', character.id,character.scene_id,character.space_id,scene_ins_id)
			return WorldPacket:m2cSendCommEmpty()
		end
				
		-- 在主城，直接忽略改包
		--if SceneDefs:isNormalScene(aoi_scene.scene_base) then
		--	return Logger:debug('[ScenarioCtrl.c2m_iniStates] 在主城不能发该包')
		--end
		
		ScenarioService:initScenarioState(aoi_scene, states)
		
		-- RSP
		ScenarioService:sendScenarioState(character, aoi_scene)
	end
	c_opHandlers[opCodes.C2M_SCENARIO_INIT_STATES] = ScenarioCtrl.c2m_iniStates
end

-- 设置状态
do
	local msg = "PackScenario.C2M_SCENARIO_SET_STATE"
	function ScenarioCtrl.c2m_setState(character, packet)
		local params = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id
		local state_idx = params.state_idx + 1
		local state_from = tonumber(params.state_from)
		local state_to = tonumber(params.state_to)
		
		if scene_ins_id <= 0 or state_idx <= 0 or not state_from or not state_to then
			return send_error('[ScenarioCtrl.c2m_setState] params error')
		end
		
		local aoi_scene = GameObjectService:getAoiSceneBySpaceId(scene_ins_id)
		if not aoi_scene then
			return WorldPacket:m2cSendCommEmpty()
		end
		
		
		-- 在主城，直接忽略改包
		--if SceneDefs:isNormalScene(aoi_scene.scene_base) then
		--	return Logger:debug('[ScenarioCtrl.c2m_setState] 在主城不能发该包')
		--end
		
		-- 设置状态
		ScenarioService:setScenarioState(aoi_scene, state_idx, state_from, state_to)
	end
	c_opHandlers[opCodes.C2M_SCENARIO_SET_STATE] = ScenarioCtrl.c2m_setState
end

-- 设置剧情定时器
do
	local msg = "PackScenario.C2M_SCENARIO_ADD_TIMER"
	function ScenarioCtrl.c2m_setScenarioTimer(character, packet)
		local params = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id
		local id = params.id
		local state_idx = params.state_idx + 1
		local duration = params.duration
		local can_add_time = params.can_add_time
		
		if scene_ins_id <= 0 or state_idx <= 0 or duration <= 0 or can_add_time < 0 then
			return send_error('[ScenarioCtrl.c2m_setScenarioTimer] params error')
		end
		
		if character.space_id ~= scene_ins_id then
			return WorldPacket:m2cSendCommEmpty()
		end
		
		local aoi_scene = GameObjectService:getAoiSceneBySpaceId(scene_ins_id)
		if not aoi_scene then
			return WorldPacket:m2cSendCommEmpty()
		end
				
		-- 设置定时器
		ScenarioService:setScenarioTimer(aoi_scene, state_idx, state_from, state_to)
	end
	c_opHandlers[opCodes.C2M_SCENARIO_ADD_TIMER] = ScenarioCtrl.c2m_setScenarioTimer
end

-- 召唤怪物
do
	local msg = "PackScenario.C2M_SCENARIO_ADD_OBJS"
	function ScenarioCtrl.c2m_callObjs(character, packet)
		local params = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id
		local phase_id = params.phase_id
		local phase_type_id = params.type
		local num = params.num
		local is_face_player = params.ftp == 1 and true or false
		
		if phase_id <= 0 or phase_type_id < 0 or num < 0 then
			return send_error('[ScenarioCtrl.c2m_callObjs] params error')
		end
				
		if character.space_id ~= scene_ins_id then
			return WorldPacket:m2cSendCommEmpty()
		end
		
		local face_game_obj = is_face_player and character or nil
		local aoi_scene = GameObjectService:getAoiScene(character)
		if not aoi_scene then
			return WorldPacket:m2cSendCommEmpty()
		end
		
		local scene_id = aoi_scene.scene_id
		
		-- 在主城，直接忽略该包
		--if SceneDefs:isNormalScene(aoi_scene.scene_base) then
		--	return Logger:debug('[ScenarioCtrl.c2m_callObjs] 在主城不能发该包')
		--end
		
		-- 检查是否已触发过
		if ScenarioService:isTriggered(aoi_scene, phase_id, phase_type_id) then
			WorldPacket:m2cSendCommEmpty(character.gpid)
			return 
		end
		
		-- 获取该波怪物scene aoi列表
		local scene_aois = SceneAoiService:getSceneAoisByPhaseId(scene_id, aoi_type_monster, phase_id)
		
		local called_scene_aoi_infos = {}
		local phase_info = ScenarioService:getPhaseInfo(aoi_scene, phase_id)
		if phase_info and phase_info.called_scene_aoi_infos then
			called_scene_aoi_infos = phase_info.called_scene_aoi_infos
		end
		
		local random_scene_aois = {}
		local total_num = 0
		for i, scene_aoi in ipairs(scene_aois) do
			total_num = total_num + 1
			local is_need_called = true
			local scene_aoi_id = scene_aoi.id
			
			if phase_type_id == ScenarioDefs.CALL_M_PHASE_TYPE_CIRCLE then
				local aoi_id = called_scene_aoi_infos[scene_aoi_id]
				if GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id) then
					is_need_called = false
				end
				
			elseif phase_type_id == ScenarioDefs.CALL_M_PHASE_TYPE_SIT_RAND then
				is_need_called = false
				
				if not called_scene_aoi_infos[scene_aoi_id] then
					random_scene_aois[#random_scene_aois+1] = scene_aoi
				end
			end
			
			-- 创建对象
			if is_need_called then
				local game_obj = GameObjectService:createGameObj(aoi_scene, scene_aoi, character.prof, face_game_obj)
				if game_obj then
					called_scene_aoi_infos[scene_aoi_id] = game_obj.aoi_id
				end
			end
		end
		
		if phase_type_id == ScenarioDefs.CALL_M_PHASE_TYPE_SIT_RAND then
			local random_scene_aois_num = #random_scene_aois
			local need_call_num = num - table.sizeTable(called_scene_aoi_infos)
			if need_call_num > random_scene_aois_num then need_call_num = random_scene_aois_num end
			
			if need_call_num > 0 then
				local random_idxs = {}
				math.randomN(1, random_scene_aois_num, need_call_num, random_idxs)
				for i, scene_aoi in ipairs(random_scene_aois) do
					if random_idxs[i] then
						local game_obj = GameObjectService:createGameObj(aoi_scene, scene_aoi, character.prof, face_game_obj)
						if game_obj then
							called_scene_aoi_infos[scene_aoi.id] = game_obj.aoi_id
						end
					end
				end
			end
		end
		
		-- 记录该波次已触发
		ScenarioService:recordPhaseInfo(aoi_scene, phase_id, phase_type_id, called_scene_aoi_infos, total_num)
		
	end
	c_opHandlers[opCodes.C2M_SCENARIO_ADD_OBJS] = ScenarioCtrl.c2m_callObjs
end

-- 召唤动态怪物
do
	local msg = "PackScenario.C2M_SCENARIO_ADD_DYN_OBJS"
	function ScenarioCtrl.c2m_callDyObjs(character, packet)
		local params = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id
		local phase_id = params.dyn_phase_id
		local base_id = params.base_id
		local aoi_type = params.aoi_type
		local num = tonumber(params.num)
		local x1, y1, x2, y2 = tonumber(params.x1), tonumber(params.y1), tonumber(params.x2), tonumber(params.y2)
		local is_face_player = params.ftp == 1 and true or false
		
		if phase_id <= 0 or monster_base_id <= 0 or num <= 0 then
			return send_error('[ScenarioCtrl.c2m_callDyObjs] params error')
		end
			
		if character.space_id ~= scene_ins_id then
			return WorldPacket:m2cSendCommEmpty()
		end
			
		local face_game_obj = is_face_player and character or nil
		local aoi_scene = GameObjectService:getAoiScene(character)
		if not aoi_scene then
			return WorldPacket:m2cSendCommEmpty()
		end
		
		local scene_id = aoi_scene.scene_id
		
		-- 在主城，直接忽略改包
		--if SceneDefs:isNormalScene(aoi_scene.scene_base) then
		--	return Logger:debug('[ScenarioCtrl.c2m_callDyObjs] 在主城不能发该包')
		--end
		
		-- 检查是否已触发过
		if ScenarioService:isTriggered(aoi_scene, phase_id, ScenarioDefs.CALL_M_PHASE_TYPE_NORMAL) then
			WorldPacket:m2cSendCommEmpty(character.gpid)
			return 
		end
		
		local called_scene_aoi_infos = {}
		local phase_info = ScenarioService:getPhaseInfo(aoi_scene, phase_id)
		if phase_info and phase_info.called_scene_aoi_infos then
			called_scene_aoi_infos = phase_info.called_scene_aoi_infos
		end
		
		-- 创建怪物
		local total_num = num
		for i = 1, num do
			local x = math_random(math_min(x1, x2),math_max(x1, x2))
			local y = math_random(math_min(y1, y2),math_max(y1, y2))
			local game_obj = GameObjectService:createGameObjByPos(aoi_scene, aoi_type, base_id, x, y, phase_id, face_game_obj)
			called_scene_aoi_infos[game_obj.monster_aoi.id] = game_obj.aoi_id
		end
		
		-- 记录该波次已触发
		ScenarioService:recordPhaseInfo(aoi_scene, phase_id, ScenarioDefs.CALL_M_PHASE_TYPE_NORMAL, called_scene_aoi_infos, total_num)
		
	end
	c_opHandlers[opCodes.C2M_SCENARIO_ADD_DYN_OBJS] = ScenarioCtrl.c2m_callDyObjs
end

-- 召唤单个对象, 怪物/火球/陷阱/...
do
	local msg = "PackScenario.C2M_SCENARIO_ADD_DYN_OBJ"
	function ScenarioCtrl.c2m_callDyObj(character, packet)
		local params = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id
		local phase_id = params.dyn_phase_id
		local base_id = params.base_id
		local aoi_type = params.aoi_type
		local x, y = tonumber(params.x), tonumber(params.y)
		local is_face_player = params.ftp == 1 and true or false
		
		if phase_id <= 0 or base_id <= 0 or aoi_type <= 0 or x < 0 or y < 0 then
			return send_error('[ScenarioCtrl.c2m_callDyObj] params error')
		end
		
		if character.space_id ~= scene_ins_id then
			return WorldPacket:m2cSendCommEmpty()
		end
		
		local face_game_obj = is_face_player and character or nil
		local aoi_scene = GameObjectService:getAoiScene(character)
		if not aoi_scene then
			return WorldPacket:m2cSendCommEmpty()
		end
		
		local scene_id = aoi_scene.scene_id
		
		-- 在主城，直接忽略改包
		--if SceneDefs:isNormalScene(aoi_scene.scene_base) then
		--	return Logger:debug('[ScenarioCtrl.c2m_callDyObj] 在主城不能发该包')
		--end
		
		-- 检查是否已触发过
		local scenario_done_phase_ids = aoi_scene.scenario_done_phase_ids
		if scenario_done_phase_ids and scenario_done_phase_ids[phase_id] then
			WorldPacket:m2cSendCommEmpty(character.gpid)
			return 
		end
		
		-- 创建场景实例对象
		local called_scene_aoi_infos = {}
		local game_obj = GameObjectService:createGameObjByPos(aoi_scene, aoi_type, base_id, x, y, phase_id, face_game_obj)
		called_scene_aoi_infos[game_obj.monster_aoi.id] = game_obj.aoi_id
		
		-- 记录该波次已触发
		ScenarioService:recordPhaseInfo(aoi_scene, phase_id, ScenarioDefs.CALL_M_PHASE_TYPE_NORMAL, called_scene_aoi_infos, 1)
		
	end
	c_opHandlers[opCodes.C2M_SCENARIO_ADD_DYN_OBJ] = ScenarioCtrl.c2m_callDyObj
end

-- 杀死所有怪
do
	local msg = "PackScenario.C2M_SCENARIO_KILL_ALL_MONSTER"
	function ScenarioCtrl.c2m_killAllMonster(character, packet)				
		local params = packet:readParams(msg)
		local scene_ins_id = params.scene_ins_id
		local states = params.states
		
		-- 暂不做任何处理
		WorldPacket:m2cSendCommEmpty()
	end
	c_opHandlers[opCodes.C2M_SCENARIO_KILL_ALL_MONSTER] = ScenarioCtrl.c2m_killAllMonster
end


