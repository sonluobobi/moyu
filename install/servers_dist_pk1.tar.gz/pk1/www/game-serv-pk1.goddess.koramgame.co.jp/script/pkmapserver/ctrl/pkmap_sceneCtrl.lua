
SceneCtrl = SceneCtrl or {}

local errorCodes = errorCodes
local SceneCtrl = SceneCtrl
local SceneService = SceneService
local CharacterService = CharacterService
local SceneBaseService = SceneBaseService
local AoiSceneService = AoiSceneService
local AoiObjectType = AoiObjectType
local AoiObject = AoiObject
local WorldPacket = WorldPacket
local CharacterDefs = CharacterDefs
local GameObjectService = GameObjectService
local MotionService = MotionService
local SceneDefs = SceneDefs
local SceneAoiService = SceneAoiService
local Time = Time
local UString = UString
local UNumber = UNumber
local next = next
local pairs = pairs
local opCodes = opCodes
local type = type
local assert = assert
local math = math
local random = math.random
local floor = math.floor
local TransferDotBaseDao = TransferDotBaseDao
local movescene_ret_opcode = opCodes.M2C_SCENE_MOVE_SCENE
local g_mapserver_id = g_mapserver_id
local printf = printf
local g_bEnableLuaTimeoutGuard=OptimizeDbg.g_bEnableLuaTimeoutGuard
local MotionService = MotionService
local send_error = WorldPacket.m2cSendDebugError
local ItemDefs = ItemDefs

local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local g_FrameIdx=g_FrameIdx

local readInt,readByte,readShort,readUShort,readCoord,readPath,enableTraceBin = Packet.readInt, Packet.readByte, Packet.readShort,Packet.readUShort, Packet.readCoord,Packet.readPath,Packet.enableTraceBin
local dumpPkgAsString = Packet.dumpPkgAsString
local packet_ReadPath=packet_ReadPath

---进入场景
do
	local SceneBaseDao = SceneBaseDao
	local CharacterCtrl
	local entry_ret_data = {}
	local appear_data_game_objs, appear_data_aoi_objs = {},{}
	local update_data = {}
	local ChPetService = ChPetService
	local GAME_OBJECT_STATUS_ID_IDLE = Statics.GAME_OBJECT_STATUS_ID_IDLE
	local AoiObject_new = AoiObject.new
	local ReliveService = ReliveService
	
	function SceneCtrl:enterScene(character, params ,packet_id)
		local space_id = params.space_id
		local scene_id = params.scene_id
		local line_id = params.line_id
		local is_login = params.is_login			--第一次登录/切换场景
		local is_reconnect = params.is_reconnect	--是否是掉线重连	
		
		printf('EnterScene mapid=%d,pid=%d,cid=%d,nick=%s,space_id=%d,scene_id=%d,blogin=%s,breconn=%s', g_mapserver_id, character.player_id, character.id, character.nick, space_id, scene_id, tostring(is_login), tostring(is_reconnect))
		
		local scene_base = SceneBaseDao[scene_id]	
		local scene_sort_id = scene_base.scene_sort_id
		
		-- 场景实例初始化
		local aoi_scene = AoiSceneService:getAoiScene(space_id)	
		if not aoi_scene then
			aoi_scene = AoiSceneService:newAoiScene(space_id, scene_base)
			SceneEventService:onInitScene(character, aoi_scene, scene_base)
		end		
		
		-- 派发事件：进入场景前
		SceneEventService:beforeEnterScene(character, aoi_scene, is_reconnect)
		
		local scenes = character.scenes
		local prev_scene_id = character.scene_id	-- 进入场景前所在场景ID
		local aoi_obj = character.aoi_obj
		local is_entry_normal_scene = SceneDefs:isNormalScene(scene_base)
		
		-- 重连处理
		if is_reconnect then
			assert(aoi_obj)
						
			--防止客户端卡在阻挡位置
			local x,y = aoi_scene:fixPos(aoi_obj.x, aoi_obj.y, true)
			character.x,character.y = x,y
			aoi_obj.x,aoi_obj.y = x,y
		
		-- 进入场景
		else			
			assert(not aoi_obj)
			
			-- 登录进入场景
			if is_login then
				-- 设置将进入的场景的坐标(next_x, next_y)
				if scene_id == character.scene_id then					
					scenes.next_x = character.x
					scenes.next_y = character.y
				elseif scene_id == scenes.last_scene_id then
					scenes.next_x = scenes.last_x
					scenes.next_y = scenes.last_y
				else
					scenes.next_x,scenes.next_y = SceneAoiService:getRandomTransferInForNormal(scene_id)
				end
				
			-- moveScene 进入场景
			else
				-- 记录最后一次离开主城 信息
				local prev_scene_base = SceneBaseService:getSceneBaseById(prev_scene_id)
				-- 离开的场景是主城，则记录
				if SceneDefs:isNormalScene(prev_scene_base) then
					scenes.last_scene_id = prev_scene_id
					scenes.last_line_id = scenes.line_id
					scenes.last_space_id = character.space_id
					scenes.last_x = floor(character.x * 100)/100
					scenes.last_y = floor(character.y * 100)/100
				end
			end			
			
			-- 各个玩法指定出生点
			local is_get_ok, new_birth_x, now_birth_y = SceneEventService:getBirthPos(aoi_scene, character)
			if is_get_ok then
				scenes.next_x, scenes.next_y = new_birth_x, now_birth_y
			end
			
			-- 设置进入新的场景
			scenes.line_id = line_id
			character.space_id = space_id
			character.scene_id = scene_id
			
			-- 设置进入新场景的坐标
			local x,y = aoi_scene:fixPos(scenes.next_x, scenes.next_y, true)
			
			-- 创建aoi
			local player_type = aoi_type_player
			aoi_obj =  AoiObject_new(AoiObject, player_type, x, y, scenes.direction, character, aoi_scene)	
			
		end
		
		-- 设置进入新的场景的坐标
		character.x,character.y = aoi_obj.x, aoi_obj.y
		
		-- 还原将进入的场景的坐标
		scenes.next_x = nil
		scenes.next_y = nil		
		
		-- 清空 正在切换场景的开始时间
		character.tmps.moving_scene_stime = nil
		
		-- 进入主城满血
		if not is_reconnect and is_entry_normal_scene then
			-- 主角满血
			if character.hp > 0 then
				ReliveService:characterFullHp(character)
			end
			
			-- 合体幻兽满血
			character.hp2 = character.max_hp2
			character.hp3 = character.max_hp3
		end
		
		-- 设置进入场景保护状态
		CharacterService:protect(CharacterDefs.PROTECT_TYPE_ID_FOR_ENTER_SCENE, character, CharacterDefs.SAFE_TIME_FOR_ENTER_SCENE)
		
		-- 设置正在进入场景 开始时间 (客户端加载场景完成才算进入完成)
		character.tmps.entering_scene_stime = Time.time_now
		
		-- 返回 进入场景包
		-- 注：进入场景包需要先回给客户端
		entry_ret_data.aoi_id = aoi_obj.obj_id
		entry_ret_data.scene_ins_id = space_id
		entry_ret_data.server_time = Time:getTimeNow()-- 当前帧开始时间
		entry_ret_data.line_id = line_id
		entry_ret_data.scene_id = scene_id	
		entry_ret_data.x = character.x
		entry_ret_data.y = character.y
		entry_ret_data.opcode = opCodes.M2C_SCENE_ENTRY
		WorldPacket:m2cSendOK(entry_ret_data, packet_id, character.gpid )					
		
		-- 非重连， 登录或切换场景
		if not is_reconnect then			
			-- 添加主角到AOI
			-- 注：底层会调用SceneService:sendAppearPacket回包给客户端
			GameObjectService:addObj(character, aoi_obj, aoi_scene)
			
			-- 添加出战幻兽到AOI
			ChPetService:showFightPet(character, aoi_scene)
		end
		
		-- 将自己Appear DATA数据发给自己
		appear_data_game_objs[1] = character
		appear_data_aoi_objs[1] = aoi_obj
		SceneService:sendAppearPacket(aoi_scene, aoi_obj.gpid, appear_data_aoi_objs)			
		SceneService:sendAppearDetailPacket(space_id, appear_data_game_objs, character.gpid)
		
		-- 进入主城, 如果是死亡的，自动复活
		if not is_reconnect and is_entry_normal_scene and character.hp <= 0 then
			ReliveService:characterRelive(character)
		end
		
		-- 重连
		if is_reconnect then
			local arr_appear = GameObjectService:getFovAllAoiObjs(character, aoi_scene)
			
			-- 过滤自己
			local len = #arr_appear
			for i=1,len do			
				local me = arr_appear[i]
				if me == aoi_obj then
					-- 排除自己
					arr_appear[i] = arr_appear[len]
					arr_appear[len] = nil
					len = len -1
					break;
				end	
			end
			
			-- 把视野内的其他玩家appear data 发给自己
			SceneService:sendAppearPacket(aoi_scene, aoi_obj.gpid, arr_appear)
		end
		
		-- 派发事件：进入场景完成
		SceneEventService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
		
		-------------- 进入场景后其他处理 start ---------------
		-- BUFFER
		BufferService.afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
		
		-- 机器人
		SceneRobotService:afterEnterScene(character, aoi_scene)
		
		-- AOI对象玩法数据
		WanfaAoiService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
		
		-- 小地图
		SmallMapService.afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)

		-- 清空原地复活计数器（国印的接口)
		ReliveService:clearRevivalCounter( character )
		
		-- 发送队伍血量信息(策划说不需要了)
--		TeamService:sendChTeamRealInfo( character )
		
		-- 红名惩罚
		RednameService:afterEnterScene(character, aoi_scene)
		
		-- 进入场景的时候清空技能CD
		FightService:cleanSkillCd(character)
		-------------- 进入场景后其他处理 end ---------------
	end
	
end

---[[
-- 离开场景
-- @param leave_type 1=场景切换，2=离线
-- ]]
do
	local ChPetService = ChPetService
	function SceneCtrl:leaveScene(character, leave_type, packet_id)	
		local aoi_obj = character.aoi_obj
		local space_id, scene_id, line_id = character.space_id, character.scene_id, character.scenes.line_id
		printf('LeaveScene mapid=%d,pid=%d,cid=%d,nick=%s,space_id=%d,scene_id=%d', g_mapserver_id, character.player_id, character.id, character.nick, space_id, scene_id)
		
		--还没有创建aoi对象
		if not aoi_obj then 
			return 
		end
		
		local aoi_scene = GameObjectService:getAoiScene(character)	
		
		--还没有没有进入场景
		if not aoi_scene then return end		
		
		-- 记录玩家的离线时的当前位置、方向
		character.x = aoi_obj.x
		character.y = aoi_obj.y
		character.direction = aoi_obj.direction
		
		-- 派发事件：离开场景之前
		SceneEventService:beforeLeaveScene(character, aoi_scene, leave_type)
		
		-- 把自己侠客从AOI删除
		ChPetService:hideFightPet(character, aoi_scene)
		
		-- 把自己从AOI删除
		GameObjectService:delObj(character, aoi_scene)

		-- 角色数据清理(add by suwin at 2014-10-31)
		CharacterService:afterLeaveScene(character, aoi_scene)
		
		-- 派发事件：离开场景之后
		SceneEventService:afterLeaveScene(character, aoi_scene, leave_type)	
		
		-- 小地图清理
		SmallMapService:afterLeaveScene(character, aoi_scene )

		-- BUFFER
		BufferService.afterLeaveScene(character, aoi_scene, leave_type)
		
		FightService:cancleFightState(character, true)
	end
end

---帧更新
do
	local getNowUnixUsTime = external.getNowUnixUsTime
	local getNowUnixMsTime = external.getNowUnixMsTime
	local small_map_scene_sorts = SceneDefs.small_map_scene_sorts
	
	-- 帧更新
	function SceneCtrl:update(time_now, frame_ms_cd, updated_frame)
		local update_obj_num = 0								-- 更新的对象数
		local scene_num = 0										-- 更新的场景数
		local frame_etime = getNowUnixUsTime() + frame_ms_cd*1000	-- 帧结束时间
		local is_entry_new_frame = true							-- 是否进入新的一帧
		
		local aoi_scenes = AoiSceneService:getAoiScenes()
		local SceneCtrl_updateScene = SceneCtrl.updateScene
		local AoiSceneService_updateAoiScene = AoiSceneService.updateAoiScene
		
		g_FrameIdx=g_FrameIdx+1
		
		local stime
		
		-- 与场景无关的定时逻辑
		if Time.is_second_start then
			-- 每秒复活玩家
			ReliveService:onTimer( time_now )
			-- 每秒同步队伍血量状态(策划说不需要了)
--			TeamService:onTimer( )
		end
		
		for space_id, aoi_scene in pairs(aoi_scenes) do
			if aoi_scene then
				local scene_base = aoi_scene.scene_base
				
				-- 帧序号相关，说明该场景已执行过该帧更新
				if aoi_scene.updated_frame == updated_frame then
					
				-- 执行帧更新
				-- 本地AI的场景不执行帧更新
				elseif scene_base.is_local_ai ~= 1 then
					if g_bEnableLuaTimeoutGuard then
					   stime = getNowUnixUsTime()
					end
					
					scene_num = scene_num + 1
					
					-- 赋值帧序号, 标识为已更新
					aoi_scene.updated_frame = updated_frame
					
					-- 场景 帧更新
					SceneCtrl_updateScene(SceneCtrl, time_now, aoi_scene, scene_base)
					
					local etime1 
					if g_bEnableLuaTimeoutGuard then
					  etime1= getNowUnixUsTime()
					end
					
					-- AOI 帧更新
					local num_x = AoiSceneService_updateAoiScene(AoiSceneService, time_now, aoi_scene, scene_base,g_FrameIdx)
					
					if num_x then
						update_obj_num = update_obj_num + num_x
					end
					
					local etime = getNowUnixUsTime()
					
					if g_bEnableLuaTimeoutGuard then
						
						-- DEBUG:打印出耗时超过2MS的
						if etime - stime >= 1000 then
							printf('[%u] ******* [SceneCtrl:update] use time(us) :%d delta1(%d) s:%d e:%d.\n',g_FrameIdx,etime - stime,etime-etime1,stime,etime)
						 end
					end
					
					-- 执行已经超过1帧的时间，跳出循环
					-- 帧序号不变，下次继续该帧
					if etime >= frame_etime then
						is_entry_new_frame = false
						-- 不再退出，只警告
						--break
					end
				end
			end
		end

		return is_entry_new_frame, scene_num, update_obj_num
	end
	
	-- 场景帧更新
	local SceneEventService = SceneEventService
	local BattleService = BattleService
	function SceneCtrl:updateScene(time_now, aoi_scene, scene_base)
		local scene_id = aoi_scene.scene_id
		
		--场景中没有玩家，跳过	
		if aoi_scene.player_num <= 0 then		
			if Time.is_second_start then
				SceneEventService:updateForNoPlayer(time_now, aoi_scene)
			end
			return
		end
		
		--场景暂停中
		local is_pause = aoi_scene.is_pause
		if is_pause and (aoi_scene.is_pause_expire or 0) > time_now then
			return
		end
		
		-- 每500毫秒
		if Time.is_500ms_start then	
			--场景500MS事件
			SceneEventService:update500ms(time_now, aoi_scene)
		end
		
		-- 每秒
		if Time.is_second_start then			
			--场景每秒事件
			SceneEventService:update(time_now, aoi_scene)
			
			if small_map_scene_sorts[scene_base.scene_sort_id] then
				SmallMapService:update(time_now, aoi_scene)
			end

			TrapRefreshService:update(time_now, aoi_scene)
		end		
		
		
		-- 每5秒 
		if Time.is_5s_start then	
			
		end
		
		
		-- 每10秒 
		if Time.is_10s_start then
			
		end
		
		
		--每分钟
		if Time.is_minute_start then			
	
		end
		
	end
end

---base 通知 map 切换场景
do
	local SceneBaseDao = SceneBaseDao
	
	function SceneCtrl.b2m_moveScene(character, packet)
		if not character then return end
		local data = packet:readParams()
		local is_no_check = data.is_no_check
		
		-- 检查是否可以进入目标场景
		if not is_no_check then
			local ret , msg = CharacterService:canDo(character, CharacterDefs.DO_TYPE_FOR_MOVE)
			if not ret then
				WorldPacket:m2cSendErr(movescene_ret_opcode, packet, gpid, msg)
				return
			end
		end
		
		local x,y			-- 进入目标场景的x,y坐标
		local  dst_scene_id, dst_space_id, line_id = data.dst_scene_id, data.dst_space_id, data.line_id		
		
		-- 通过传入点获得进入目标场景的坐标
		local transfer_ins_id = data.transfer_ins_id
		if transfer_ins_id then
			local aoi_dot = SceneAoiService:getInitObjsById(transfer_ins_id)
			local dot_base = TransferDotBaseDao.id2entity[aoi_dot.class_id]
			local dest = dot_base.map_dest_scene_ids[dst_scene_id]
			x,y = dest[2],dest[3]
		end
		
		-- 随机一个传入点 作为 进入目标场景的坐标
		if not x then
			local scene_base = SceneBaseDao[dst_scene_id]
			x,y = SceneAoiService:getRandomTransferInForNormal(dst_scene_id)
		end
		
		-- 在传入点2米范围内随机下
		x,y = x + random(-2,2), y + random(-2,2)
		
		-- 切换场景
		SceneService:moveScene(character, dst_scene_id, dst_space_id, line_id, x, y)
	end
	i_opHandlers[opCodes.B2M_SCENE_MOVE_SCENE] = SceneCtrl.b2m_moveScene
end

do
	-- BASE发来的删除场景（针对调用了external.setKeepInstanceSpace的场景）
	local externalRemoveScene = external.removeScene	
	local aoi_scenes = AoiDao.aoi_scenes
	function SceneCtrl.b2m_deleteKeepedScene(_, data)
		local space_id = data.space_id
		Logger:info('SceneService:b2m_deleteKeepedScene', space_id)
		if aoi_scenes[space_id] then
			-- 清除LUA
			AoiSceneService:delAoiScene(space_id, true)

			-- 删除场景
			externalRemoveScene(space_id)
			
		else
			-- 删除场景
--			externalRemoveScene(space_id)			
		end
	end
end

-- 通过传送点切换场景
do
	local SceneBaseDao = SceneBaseDao
	

	function SceneCtrl.c2m_moveSceneByTransfer(character, packet)	
		--packet:dumpPkgAsString(0,0,true,"c2m_moveSceneByTransfer")		
		local params = packet:readParams()
		local dst_index = UNumber.str2Int(params.dst_index)
		local dst_scene_id = UNumber.str2Int(params.dst_scene_id)
		local transfer_ins_id = UNumber.str2Int(params.transfer_ins_id)
		
		local gpid = character.gpid
		
		-- 检查是否可以进入目标场景
		local ret , msg = CharacterService:canDo(character, CharacterDefs.DO_TYPE_FOR_MOVE)
		if not ret then
			WorldPacket:m2cSendErr(movescene_ret_opcode, packet, gpid, msg)
			return
		end
		
		-- 获取传出点实例对象
		local aoi_dot = SceneAoiService:getInitObjsById(transfer_ins_id)	
		if not aoi_dot then
			WorldPacket:m2cSendErr(movescene_ret_opcode, packet, gpid, errorCodes.SCENE_ERROR_TRANSFER_NOT_EXISTS)
			return
		end
		
		local aoi_obj = character.aoi_obj
		local aoi_scene = GameObjectService:getAoiScene(character)
		local scene_id = aoi_scene.scene_id
		
		-- 传出点指向目标场景 错误
		if aoi_dot.scene_id ~= scene_id then
			Logger:debug('[c2m_moveSceneByTransfer] aoi_dot.scene_id ~= scene_id', aoi_dot, scene_id)
			--WorldPacket:m2cSendErr(movescene_ret_opcode, packet, gpid, errorCodes.SCENE_ERROR_TRANSFER_NOT_HERE)
			return
		end
		
		-- 检查是否为传出点
		if aoi_dot.type ~= AoiObjectType.AOI_OBJECT_TYPE_ID_TRANSMIT then
			WorldPacket:m2cSendErr(movescene_ret_opcode, packet, gpid, errorCodes.SCENE_ERROR_NOT_TRANSFER)
			return
		end
		
		local dot_base = TransferDotBaseDao.id2entity[aoi_dot.class_id]
		local dest_scenes = dot_base.dest_scenes
		local move_info = dest_scenes[dst_index]
		if not move_info or move_info[1] ~= dst_scene_id then
			WorldPacket:m2cSendErr(movescene_ret_opcode, packet, gpid, errorCodes.SCENE_ERROR_TRANSFER_CANT_TO_DST)
			return
		end
		
		local radius = dot_base.radius		--传出点的范围半径
		
		-- 检查传送点实例与玩家的距离
		-- 不再校验
		--if not Formula:isNearbyDistance(aoi_dot.x, aoi_dot.y, aoi_obj.x, aoi_obj.y, radius+8) then
		--	Logger:debug('[c2m_moveSceneByTransfer] isNearbyDistance', aoi_dot.x, aoi_dot.y, aoi_obj.x, aoi_obj.y, radius)
		--	WorldPacket:m2cSendErr(movescene_ret_opcode, packet, gpid, errorCodes.SCENE_ERROR_TRANSFER_TOO_FAR)
		--	return
		--end
		
		-- 获取进入目标场景的坐标
		local transfer_dot_in_id = move_info[2]
		local x, y
		if transfer_dot_in_id then
			x,y = SceneAoiService:getRandomTransferIn(dst_scene_id, transfer_dot_in_id)
		else
			x,y = SceneAoiService:getRandomTransferInForNormal(dst_scene_id)
		end
		
		if not (x and y and x > 0 and y > 0) then
			WorldPacket:m2cSendErr(movescene_ret_opcode,packet,gpid,errorCodes.SCENE_ERROR_TRANSFER_XY,aoi_dot.class_id)
			return
		end
		
		-- 在传入点2米范围内随机下
		x,y = x + random(-2,2), y + random(-2,2)
		
		-- 执行场景移动
		SceneService:moveScene(character, dst_scene_id, nil, nil, x, y)	
	end
	c_opHandlers[opCodes.C2M_SCENE_MOVE_SCENE_BY_TRANSFER] = SceneCtrl.c2m_moveSceneByTransfer
end

-- 回到到最后一次所在主城(简称：回城)
do
	function SceneCtrl.c2m_moveToLastScene(character, packet)
		local params = packet:readParams()
		local last_x = tonumber(params.last_x)
		local last_y = tonumber(params.last_y)
		
		if (last_x and not last_y) or (not last_x and last_y) then
			send_error("[c2m_moveToLastScene] param error:last_x,last_y")
			return
		end
		
		local now_time = Time.time_now
		local tmps = character.tmps
		
		-- 检查是否可以进入目标场景
		local ret , msg = CharacterService:canDo(character, CharacterDefs.DO_TYPE_FOR_MOVE)
		if not ret then
			WorldPacket:m2cSendErr(movescene_ret_opcode, packet, character.gpid, msg)
			return
		end
		
		-- 检查最后一次回城的时间 (间隔时间：需 >= 1秒)
		local last_move_scene_time = tmps.last_move_scene_time or 0
		if now_time - last_move_scene_time < 1000 then
			WorldPacket:m2cSendErr(movescene_ret_opcode,packet,character.gpid,errorCodes.CLICK_TOO_FAST)
			return
		end
		
		-- 设置最后一次回城的时间
		tmps.last_move_scene_time = now_time
		
		-- 回城
		SceneService:moveToLastScene(character, false, last_x, last_y)
		WorldPacket:m2cSendCommEmpty(character.gpid)
	end
	c_opHandlers[opCodes.C2M_SCENE_MOVE_SCENE_TO_LAST] = SceneCtrl.c2m_moveToLastScene
	
end

---移动到任何场景
do
	local msg_name = "PackScene.C2M_SCENE_MOVE_SCENE"
	local SceneBaseDao = SceneBaseDao
	function SceneCtrl.c2m_moveToScene(character, packet)
		local params = packet:readParams(msg_name)
		local dst_scene_id = UNumber.str2Int(params.dst_scene_id)
		local dst_space_id = params.dst_space_id ~= 0 and params.dst_space_id or nil
		local last_x = tonumber(params.last_x)
		local last_y = tonumber(params.last_y)
		
		if (last_x and not last_y) or (not last_x and last_y) then
			send_error("[c2m_moveToScene] param error:last_x,last_y")
			return
		end
		
		if dst_scene_id <= 0 then
			WorldPacket:m2cSendErr(movescene_ret_opcode, packet, character.gpid, '[c2m_moveToScene]param error.' .. dst_scene_id)
			return
		end
		
		-- 检查是否可以进入目标场景
		local ret , msg = CharacterService:canDo(character, CharacterDefs.DO_TYPE_FOR_MOVE)
		if not ret then
			WorldPacket:m2cSendErr(movescene_ret_opcode, packet, gpid, msg)
			return
		end
		
		local dst_scene_base = SceneBaseDao[dst_scene_id]		
		if not dst_scene_base then
			WorldPacket:m2cSendErr(movescene_ret_opcode, packet, character.gpid, 'SCENE NOT EXISTS ' .. dst_scene_id)
			return
		end
		
		-- 如果是本服玩法, 不能进入
		local scene_sort_id = dst_scene_base.scene_sort_id
		if scene_sort_id == SceneDefs.SCENE_SORT_ID_TOLLGATE or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_BAOWU_ROB or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_ARENA or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_SLAVE or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_SCENARIO or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_2V2 or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_OUTDOOR_BENFU or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_GANG_DRAGON or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_BABEL or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_WEDDING
			then
			Logger:warn('已在跨服，不可以进入本服玩法 scene_sort_id:' .. scene_sort_id .. ',' .. dst_scene_id)
			WorldPacket:m2cSendCommEmpty(character.gpid)
			return
		end
		
		local x, y
		
		-- 如果是剧情场景/主城
		-- 1：目标场景与当前场景同资源 ，则位置不变; 2,没有录入传入点，则位置不变
		if dst_scene_base.scene_sort_id == SceneDefs.SCENE_SORT_ID_SCENARIO or
			dst_scene_base.scene_sort_id == SceneDefs.SCENE_SORT_ID_OUTDOOR_BENFU or
			dst_scene_base.scene_sort_id == SceneDefs.SCENE_SORT_ID_NORMAL_MCITY then
			local aoi_scene = GameObjectService:getAoiScene(character)
			if dst_scene_base.res_id == aoi_scene.scene_base.res_id then
				x, y = last_x, last_y
			end
		end
		
		-- 执行进入场景
		-- 无指定目标坐标x,y， 会随机一个传入点进入到目标场景
		SceneService:moveScene(character, dst_scene_id, dst_space_id, nil, last_x, last_y)
	end
	c_opHandlers[opCodes.C2M_SCENE_MOVE_SCENE] = SceneCtrl.c2m_moveToScene
end

---场景内移动
do
	local update_data = {}
	local TYPE_SHAN_YI = MotionDefs.TYPE_SHAN_YI
	local ret_opcode = nil
	local SAFE_TIME_FOR_NO_ENTER_SCENE_MAX_MS = CharacterDefs.SAFE_TIME_FOR_NO_ENTER_SCENE_MAX * 1000

	local Config = Config
	
	function SceneCtrl.c2m_moveToDest(character, packet)	
        
        local scene_ins_id
        local aoi_id
        local move_type
        
		scene_ins_id = readInt(packet)
		aoi_id = readInt(packet)
		move_type = readByte(packet)
		
		-- 闪移
        if move_type == TYPE_SHAN_YI then
        	local tmps = character.tmps
        	if not tmps.can_shunyi then
        		return WorldPacket:m2cSendCommEmpty(character.gpid)
        	end
        	tmps.can_shunyi = nil
        end
        
		-- 获取路径参数
		local pos_arr,pos_len=packet_ReadPath(packet)
		
		-- check params
		if scene_ins_id <=0 or aoi_id <=0 then		
			local err_id = errorCodes.COMMON_PARAM_MISS
			WorldPacket:m2cSendErr(ret_opcode, packet, character.gpid, err_id)
			return
		end
		
		-- 获取场景实例、角色AOI对象
		local aoi_scene, aoi_obj = GameObjectService:getAoiSceneAndAoiObj(character)	
		if not aoi_scene or aoi_scene.space_id ~= scene_ins_id then
			return WorldPacket:m2cSendCommEmpty(character.gpid)
		end
		
		-- 获取移动对象的 AoiObj 和 GameObj (可能是召唤兽，侠客、角色)
		local game_obj = character
		if character.aoi_id ~= aoi_id then
			aoi_obj = aoi_scene:getObj(aoi_id)
			if not aoi_obj then
				Logger:warn('[SceneCtrl.c2m_moveToDest] not aoi_obj', character.id, character.nick, character.scene_id, scene_ins_id, aoi_scene.scene_base.id, aoi_id, character.aoi_id)
				WorldPacket:m2cSendCommEmpty(character.gpid)
				return
			end
			
			game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)				
			if not game_obj then
				Logger:warn('[SceneCtrl.c2m_moveToDest] not game_obj',character.nick, aoi_id)
				WorldPacket:m2cSendCommEmpty(character.gpid)
				return
			end
			
			if game_obj.parent_aoi_id ~= character.aoi_id then
				-- 机器人
				local parent_game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, game_obj.parent_aoi_id)
				-- 检查自己是否可以控制该机器人
				if not parent_game_obj or parent_game_obj.parent_aoi_id ~= character.aoi_id then
					Logger:debug('[SceneCtrl.c2m_moveToDest] 不能移动别人的幻兽或召唤兽', character.id, character.player_id, aoi_obj, game_obj.parent_aoi_id, character.aoi_id)
					WorldPacket:m2cSendErr(ret_opcode,packet,character.gpid,errorCodes.SCENE_ERROR_DST_NOT_ALLOWED)
					return
				end
			end
		end
		--PKTEST
		--if game_obj.aoi_type == aoi_type_player then
			--external.info('cstartmove ', game_obj.id,' ', game_obj.player_id,' ', pos_arr[1],' ', pos_arr[2], ' ',pos_arr[#pos_arr-1], ' ',pos_arr[#pos_arr], move_type)
		--end
		--local path_log = ''
		--for _, pos_t in pairs(pos_arr) do path_log = path_log .. ', ' .. string.format('%.3f', pos_t) end
		--if aoi_id == 2 then Logger:debug('move ', aoi_id, move_type, string.format('%.3f', aoi_obj.x), string.format('%.3f', aoi_obj.y), '|', path_log) end
		
		-- 判断下路径起始点是否离当前点太远 超过8米 打个 LOOSE 日志
		local dist_sqr = Formula:sqrDistance(pos_arr[1], pos_arr[2], aoi_obj.x, aoi_obj.y)
		local is_player = game_obj.aoi_type == aoi_type_player and true or false
		if is_player and dist_sqr > 49 then
			local err_params = (not is_player) and
								'幻兽路径开始位置离当前点已有' .. string.format('%.2f', math.sqrt(dist_sqr)) .. '米' or
								'路径开始位置离当前点已有' .. string.format('%.2f', math.sqrt(dist_sqr)) .. '米'
			Logger:debug('[SceneCtrl.c2m_moveToDest] ', character.nick, err_params, dist_sqr, game_obj.speed, aoi_obj.x, aoi_obj.y, pos_arr[1], pos_arr[2])
		end
		if dist_sqr > 400 and game_obj.aoi_type == aoi_type_player then
			-- 相差太远, 强行拉回
			MotionService:stopByError(character, errorCodes.SCENE_MOVE_DEST_DOT_TOO_FAR)
			return
		end
				
		local scene_base = aoi_scene.scene_base	
		
		-- 移动，内部会检查玩家状态、如有错误，会 RSP错误
		MotionService:startMoveByClient(aoi_scene, game_obj, move_type, pos_arr, packet:getPacketId())
		
		-- 取消进入场景的保护状态
		if game_obj == character and CharacterService:isProtected(character) then
			CharacterService:cancelProtect(CharacterDefs.PROTECT_TYPE_ID_FOR_ENTER_SCENE, character)
		end
	end
	c_opHandlers[opCodes.C2M_SCENE_START_MOVE_TO_DEST] = SceneCtrl.c2m_moveToDest
end

-- 把自己的子对象(幻兽、召唤兽)瞬移到自己身边
do
	local msg_name = "PackScene.C2M_SCENE_MOVE_CHILDS_LAHUI"
	function SceneCtrl.c2m_lahuiChilds(character, packet)
		local params = packet:readParams(msg_name)
		local aoi_type = params.aoi_type
		local parent_aoi_id = params.parent_aoi_id
		local aoi_id = params.aoi_id
		local space_id = params.space_id
		
		if parent_aoi_id <= 0 or aoi_type <= 0 or space_id <= 0 then
			return WorldPacket:m2cSendErr(nil, nil, character.gpid, '[c2m_lahuiChilds] param error')
		end
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		if aoi_scene.space_id ~= space_id then
			return WorldPacket:m2cSendCommEmpty(character.gpid)
		end
		
		local parent_game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, parent_aoi_id)
		if not parent_game_obj then
			Logger:debug('[SceneCtrl.c2m_lahuiChilds] parent_game_obj is nil')
			return WorldPacket:m2cSendCommEmpty(character.gpid)
		end
		
		local is_need_repair_rsp = true
		local aoi_obj = parent_game_obj.aoi_obj
		local x, y = aoi_scene:randPos(aoi_obj.x, aoi_obj.y, 4)
		
		-- 拉幻兽
		if aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_PET then
			local ch_pet = ChPetService:getFightChPet(parent_game_obj)
			if ch_pet and ch_pet.hp > 0 and GameObjectService:isVisible(ch_pet, aoi_scene) then
				MotionService:shunYi(ch_pet, x, y)
				is_need_repair_rsp = false
			end
			
		-- 拉召唤兽
		elseif aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_BEAST then
			local child_beast = parent_game_obj.tmps.child_beast
			if child_beast then
				local beast_aoi_id = child_beast.move_aoi_id
				if beast_aoi_id and beast_aoi_id > 0 and (not aoi_id or aoi_id == 0 or aoi_id == beast_aoi_id) then
					local beast = GameObjectService:getGameObjectByAoiId(aoi_scene, beast_aoi_id)
					if beast and beast.hp > 0 then
						MotionService:shunYi(beast, x, y)
						is_need_repair_rsp = false
					end
				end
			end
		
		-- 机器人
		elseif aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT then
			if not aoi_id or aoi_id <= 0 then
				return WorldPacket:m2cSendErr(nil, nil, character.gpid, '[c2m_lahuiChilds] param error:aoi_id')
			end
			
			local robot = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
			if robot and robot.hp > 0 then
				MotionService:shunYi(robot, x, y)
				is_need_repair_rsp = false
			end
		end
		
		if is_need_repair_rsp then WorldPacket:m2cSendCommEmpty(character.gpid) end
	end
	c_opHandlers[opCodes.C2M_SCENE_MOVE_CHILDS_LAHUI] = SceneCtrl.c2m_lahuiChilds
end

---获取外观信息
do
	-- TODO : 协议需要优化 (将json 改成二进制)
	function SceneCtrl.c2m_getAppear(character,packet)
		local params = packet:readParams()
		local scene_ins_id = UNumber.str2Int(params.scene_ins_id)
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		if scene_ins_id ~= aoi_scene.space_id then
			return
		end
		
		local aoi_ids =  params.aoi_ids
		local aoi_ids = UString.splitString(aoi_ids,',',true)
		local game_objs = GameObjectService:getGameObjectsByAoiIds(aoi_scene, aoi_ids)
		
		-- RSP
		SceneService:sendAppearDetailPacket(scene_ins_id, game_objs, character.gpid)
	end
	c_opHandlers[opCodes.C2M_SCENE_GET_OBJ_APPEAR_DATA] = SceneCtrl.c2m_getAppear
end

do
	-- 客户端已进入场景完成(客户端已加载完成场景)
	local ret_opcode = opCodes.M2C_SCENE_ENTER_SCENE_COMPLETE
	local ret_date = {}
	function SceneCtrl.c2m_enterSceneOK(character, packet)
		local params = packet:readParams()
		local scene_ins_id = params.scene_ins_id
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		local tmps = character.tmps
		
		-- 已进入了其他场景
		if aoi_scene.space_id ~= scene_ins_id then
			WorldPacket:m2cSendErr(ret_opcode, packet, character.gpid, errorCodes.SCENE_ERROR_HAD_ENTERED)
			return
		end		
		
		-- 已进入场景完成
		if not tmps.entering_scene_stime then
			WorldPacket:m2cSendErr(ret_opcode, packet, character.gpid, errorCodes.SCENE_ERROR_HAD_ENTERED)
			return
		end
		
		-- 清空正在进入场景开始时间
		tmps.entering_scene_stime = nil
		
		-- RSP
		ret_date.opcode = ret_opcode
		ret_date.scene_ins_id = params.scene_ins_id
		WorldPacket:m2cSendOK(ret_date, packet, character.gpid)		
		
		-- 事件派发：客户端加载完成场景
		local ret , err_id, err_params = SceneEventService:afterClientEnterScene(character, aoi_scene)
		
		-- RSP ERROR
		if ret == false then			
			WorldPacket:m2cSendErr(ret_opcode, packet, character.gpid, err_id,err_params)
		end			
		
	end
	c_opHandlers[opCodes.C2M_SCENE_ENTER_SCENE_COMPLETE] = SceneCtrl.c2m_enterSceneOK
end

-- 拾取物体
do
	local msg = "PackDropItem.C2M_SCENE_DROP_ITEM_PICKUP"
	function SceneCtrl.c2m_pickupItem(character, packet)
		local params, packet_id = packet:readParams(msg)
		local scene_ins_id = tonumber(params.scene_ins_id)
		local aoi_id = tonumber(params.aoi_id)
		
		if aoi_id <= 0 then
			return WorldPacket.m2cSendDebugError('[c2m_pickupItem] param error')
		end
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		
		-- check: scene_ins_id
		if not aoi_scene or character.space_id ~= scene_ins_id then
			return
		end
		
		local scenebase = SceneBaseService:getSceneBaseById(character.scene_id)
		
		-- check: itemobj
		local itemobj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
		
		-- 找不到道具
		if not itemobj then
			return send_error( errorCodes.SCENE_DROP_ITEM_IS_NOT_EXIST )
			
		-- 道具类型错误
		elseif itemobj.aoi_type ~= AoiObjectType.AOI_OBJECT_TYPE_ID_ITEM then
			return send_error( errorCodes.COMMON_PARAM_ERROR )
		end
		
		-- 判断距离
		local func_id = itemobj.func_id
		local check_distance = DropPackDefs.DROP_PACK_PICKUP_DIST + 5		-- 限制的距离
		
		if not Formula:isNearbyDistanceSquare( character.x, character.y, itemobj.x, itemobj.y, check_distance * check_distance ) then
			Logger:debug('[SceneCtrl.pickupItem] is too far', character.x, character.y, itemobj.x, itemobj.y, check_distance * check_distance)
			--TEST return send_error( errorCodes.COMMON_OUT_OF_DISTANCE )
		end
		
		-- 拾取
		local ok, err, err_params = DropItemsService:pickup(character, itemobj)
		if not ok then
			return send_error(err,err_params)
		end
		
		-- 立即使用
		if itemobj.sort_id == ItemDefs.ITEM_SORT_ID_SCENE_BUFFER and itemobj.item_base.is_pickup_use == 1 then
			local is_ok, err_id = SceneBufferService:useSceneBuffer(character, itemobj.item_base.id, nil, 1)
			if not is_ok then
				return WorldPacket.m2cSendDebugError(err_id)
			end
		end
	end
	c_opHandlers[opCodes.C2M_SCENE_DROP_ITEM_PICKUP] = SceneCtrl.c2m_pickupItem
end

-- 在当前场景内获取指定怪物实例位置信息
do
	local msg_name = "PackScene.C2M_SCENE_FIND_MONSTER"
	function SceneCtrl.c2m_findMonster(character, packet)
		local arr_params, packet_id = packet:readParams(msg_name)
		local monster_base_ids = arr_params.monster_base_ids
		
		if not monster_base_ids then
			WorldPacket.m2cSendDebugError('[SceneCtrl.c2m_findMonster] param error.')
			return
		end
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		local monster = GameObjectService:findliveMonster2(aoi_scene, monster_base_ids)
		if monster then
			SceneService:sendFindMonster(character, monster)
		else
			WorldPacket:m2cSendCommEmpty(character.gpid)
		end
	end
	c_opHandlers[opCodes.C2M_SCENE_FIND_MONSTER] = SceneCtrl.c2m_findMonster	
end

-- 查找指定类型的任一AOI对象的位置
do
	local msg_name = "PackScene.C2M_SCENE_FIND_AOI_OBJ"
	function SceneCtrl.c2m_findAoiObj(character, packet)
		local arr_params, packet_id = packet:readParams(msg_name)
		local target_aoi_type = tonumber(arr_params.target_aoi_type)
		local monster_base_ids = arr_params.monster_base_ids
		
		if target_aoi_type <= 0 then
			WorldPacket.m2cSendDebugError('[SceneCtrl.c2m_findAoiObj] param error.' .. target_aoi_type)
			return
		end
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		local aoi_obj = GameObjectService:findLiveAoiObj(aoi_scene, target_aoi_type, monster_base_ids)
		SceneService:sendFindAoiObj(character, target_aoi_type, aoi_obj)
	end
	c_opHandlers[opCodes.C2M_SCENE_FIND_AOI_OBJ] = SceneCtrl.c2m_findAoiObj	
end
