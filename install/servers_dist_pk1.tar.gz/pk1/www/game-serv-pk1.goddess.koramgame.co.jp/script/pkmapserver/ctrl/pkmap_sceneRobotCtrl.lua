--[[
场景机器人 CTRL
author : xingzeng.jiang
date : 2015-04-16
--]]

SceneRobotCtrl = SceneRobotCtrl or {}
local SceneRobotCtrl = SceneRobotCtrl

local error = error
local opCodes = opCodes
local WorldPacket = WorldPacket
local external = external
local send_error = WorldPacket.m2cSendDebugError
local errorCodes = errorCodes
local SceneRobotService = SceneRobotService

-- 获取机器人属性
do
	local msg = "PackSceneRobot.C2M_SCENE_ROBOT_INFO_GET"
	function SceneRobotCtrl.c2m_getSceneRobotInfo(character, packet)
		local arr_params = packet:readParams(msg)
		local aoi_id = arr_params.aoi_id
		if aoi_id <= 0 then
			return send_error('[c2m_getSceneRobotInfo] param error.')
		end
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		local robot = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
		if not robot then
			Logger:error('[c2m_getSceneRobotInfo] robot is nil', aoi_id)
			return send_error('[c2m_getSceneRobotInfo] param error:robot is nil')
		end
		
		-- 是自己主人才会返回
		if robot.parent_aoi_id ~= character.aoi_id then
			Logger:debug('[c2m_getSceneRobotInfo] robot.parent_aoi_id ~= character.aoi_id', robot.parent_aoi_id, character.aoi_id)
			return
		end
		
		-- RSP
		SceneRobotService:sendSceneRobotInfo(character, robot)
	end
	c_opHandlers[opCodes.C2M_SCENE_ROBOT_INFO_GET] = SceneRobotCtrl.c2m_getSceneRobotInfo
end

-- 机器人进入场景
do
	function SceneRobotCtrl.b2m_entryScene(character, pack_data)
		local space_id = pack_data.space_id
		local scene_id = pack_data.scene_id
		local robot_attrib_str = pack_data.robot_attrib_str
		local parent_gcid = pack_data.parent_gcid
		local robot_cid = pack_data.robot_cid
		
		local aoi_scene = GameObjectService:getAoiSceneBySpaceId(space_id)
		if not aoi_scene then
			Logger:fatal('[SceneRobotCtrl.b2m_entryScene] aoi_scene is nil', space_id, scene_id)
		end
		
		local parent_ch_obj = character
		assert(parent_ch_obj, parent_gcid)
		SceneRobotService:createSceneRobot(aoi_scene, robot_cid, robot_attrib_str, parent_ch_obj)
	end
end
