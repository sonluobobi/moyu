--[[
	临危任务Dao
--]]

LinweiTaskBaseDao = {
	taskbase_list = {},
	type_2_taskbase = {},			--task_type->task_base
	libtype_2_tasklib_list = {},	--lib_type->step->is_surprise->lib
	total_random_weight = 0,		--任务总权重 
	
	task_id_index = 1,		--任务ID,全局唯一，自增

	normal_tasklist = {},	--基础任务数组
}

LinweiTaskLibDao = {}

function LinweiTaskBaseDao:loadFromCsv(csv_data)
	if csv_data then 
		local type_2_taskbase = LinweiTaskBaseDao.type_2_taskbase
		local taskbase_list = LinweiTaskBaseDao.taskbase_list
		local normal_tasklist = LinweiTaskBaseDao.normal_tasklist
		local random_weight = 0
		local random_normal_weight = 0
		for _, task_base in pairs(csv_data) do
			taskbase_list[#taskbase_list + 1] = task_base

			type_2_taskbase[task_base.task_type] = task_base
			task_base.random_start = random_weight 	--随机数据开始位置
			random_weight = random_weight + task_base.random_weight
			task_base.random_end = random_weight    --随机区间结束位置
			if task_base.sort_id == 1 then 
				normal_tasklist[#normal_tasklist +1] = task_base
			end
		end
		LinweiTaskBaseDao.total_random_weight = random_weight
	end
end

function LinweiTaskLibDao:loadFromCsv( csv_data )
	if csv_data then 
		local libtype_2_tasklib_list = LinweiTaskBaseDao.libtype_2_tasklib_list
		for _, task_lib in pairs(csv_data) do
			local lib_type = task_lib.lib_type
			local is_surprise = task_lib.is_surprise
			local useful_step = task_lib.useful_step
			-- lib_type->is_surprise->useful_step->layer->array(task_lib)
			-- 库类型->是否惊喜任务->用于第几步->用于第几层->可用库列表
			-- 运行一次，不考虑性能问题
			libtype_2_tasklib_list[lib_type] = libtype_2_tasklib_list[lib_type] or {}
			libtype_2_tasklib_list[lib_type][is_surprise] = libtype_2_tasklib_list[lib_type][is_surprise] or {}
			libtype_2_tasklib_list[lib_type][is_surprise][useful_step] = libtype_2_tasklib_list[lib_type][is_surprise][useful_step] or {}
			local useful_level_list = task_lib.useful_level_list
			for k, layer in pairs(useful_level_list) do
				libtype_2_tasklib_list[lib_type][is_surprise][useful_step][layer] = libtype_2_tasklib_list[lib_type][is_surprise][useful_step][layer] or {}
				local tmp = libtype_2_tasklib_list[lib_type][is_surprise][useful_step][layer]
				tmp[#tmp+1] = task_lib
			end
		end
	end
end


