--[[
复活Dao，用于数据管理
author : guoyin.huang
date : 2015年5月5日
]]--


ReliveDao = {
	time_wheel = {},			--时间轮信息
	is_time_wheel_init = false,	--时间轮是否已经初始化
}
