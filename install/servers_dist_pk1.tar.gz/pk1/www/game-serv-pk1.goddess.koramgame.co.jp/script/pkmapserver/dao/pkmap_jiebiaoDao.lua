--[[
劫镖系统 DAO
author : jinlin.liu
date : 2016-04-12
--]]
local tableInsert = table.insert
local isTableEmpty = table.isTableEmpty
local externalSplitUInt = external.splitUInt
local externalMergeUInt = external.mergeUInt

local JieBiaoDefs = JieBiaoDefs


------------------------------------------------------------------------------------
-----------------------------------csv 配置相关begin----------------------------------
--
JieBiaoDao = JieBiaoDao or {
  data = {}, --id为索引，后面是{开始等级,结束等级,预备时间,怪物ids,奖励内容}
  levels = {}, -- 也就是所有的id及场景的lv
}

function JieBiaoDao:loadFromCsv(csv_data)
  local Data = JieBiaoDao.data
  for _, info in pairs(csv_data) do
    if info and info.id then ---csv_data已经确保奖励内容有序
      --#Id,任务名字,开始等级,结束等级,描述,怪物ids,奖励内容
      --id__kn,name__s,levelb__n,levele__n,interval__n,desc__s,monster_ids__t,reward__t
      local lvb = info.levelb
      local lee = info.levele
      local id = info.id
      local reward = info.reward
      local interval = info.interval
      local monster_ids = info.monster_ids
      
      Data[id] = {gongcount=info.gongcount,shoucount=info.shoucount,interval=interval,levelb=lvb,levele=lee,reward=reward,monster_ids=monster_ids}
      
    end
  end 
end




