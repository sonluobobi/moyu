--[[
目标系统数据Dao，用于数据管理
author : guoyin.huang
date : 2015-01-06
]]--

local tableInsert = table.insert

TargetBaseDao = {

	achieveid_2_achieve_base = {},	 --成就ID到成就配置
	achievetype_2_achieve_list = {}, --成就类型到成就列表
}

AchieveBaseDao = {
}

function AchieveBaseDao:loadFromCsv( csv )

	local achieveid_2_achieve_base = TargetBaseDao.achieveid_2_achieve_base
	local achievetype_2_achieve_list = TargetBaseDao.achievetype_2_achieve_list
	for _, achieve_base in pairs(csv) do
		local id = achieve_base.id
		local sort_id = achieve_base.sort_id
		achievetype_2_achieve_list[sort_id] = achievetype_2_achieve_list[sort_id] or {}
		table.insert(achievetype_2_achieve_list[sort_id], achieve_base)
		achieveid_2_achieve_base[id] = achieve_base
	end
end

function TargetBaseDao:getAchieveBaseById( achieve_id )
	return self.achieveid_2_achieve_base[achieve_id]
end

function TargetBaseDao:getAchieveListBySortId( achieve_sort_id )
	return self.achievetype_2_achieve_list[achieve_sort_id]
end