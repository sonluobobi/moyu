--[[
怪物基础数据系统Dao，用于数据管理
author : suwin zhong
date : 2012-03-01
--]]
MonsterBaseDao = {
	data = nil, -- 存储monster基础数据，格式 : {id => obj, ...}
}

-- 格式化怪物数据
function MonsterBaseDao:loadFromCsv(csv_data)
	if table.isTable(csv_data) then
		-- 初始化data
		self.data = {}

		-- 存储monster数据
		for _, monster_base in pairs(csv_data) do
			local monster_id = monster_base.id
			if not self.data[monster_id] then
				self.data[monster_id] = {}
			end

			for key, value in pairs(monster_base) do
				self.data[monster_id][key] = value
			end
		end
	end
end
