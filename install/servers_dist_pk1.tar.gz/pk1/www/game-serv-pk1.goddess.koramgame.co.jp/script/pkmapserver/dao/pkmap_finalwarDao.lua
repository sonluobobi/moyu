--[[
末日战场数据管理
autor: jinlin.liu 	
Date : 2016.08.10
--]]

FinalWarDao = FinalWarDao or {
	scene_id_2_data = {},		--场景实例ID到数据
}
