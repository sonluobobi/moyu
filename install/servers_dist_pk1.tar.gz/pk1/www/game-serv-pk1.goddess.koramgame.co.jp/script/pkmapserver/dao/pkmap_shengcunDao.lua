--[[
生存挑战数据管理
autor: guoyin.huang 	
Date : 2015.04.21
--]]

ShengcunDao = {
	space_id_2_battle_info = {},
}
