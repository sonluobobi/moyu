--[[
运营活动数据层
author : xingzeng
date : 2013-03-26
]]--

OpeActivityDao = {
	area2data = {},
	--[[
		area2data[area_id] = {
			drop_activity_itemss = {},	-- 掉落包活动项列表 drop_activity_itemss[scene_sort_id]={ActivityItem, ActivityItem,...}
			activity_items = {},
		},
	--]]
}
