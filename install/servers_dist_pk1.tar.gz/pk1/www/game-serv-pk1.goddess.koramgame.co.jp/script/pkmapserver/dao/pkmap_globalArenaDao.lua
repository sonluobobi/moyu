--[[
跨服竞技场（诸神黄昏）Dao，用于数据管理
author : guoyin
date : 2016-07-08
]]--

GlobalArenaDao = {
	
	-- 竞技场排名信息
	ranks = {},		

	-- 带机器人的竞技场排名数据
	ranks_with_robot = {},		

	-- 机器人的数据
	robots = {},

	-- 角色跨服竞技场详细信息
	ch_arena_details = {},	--  character.unique_key->data

	-- 竞技场ID到竞技场数据
	arenaid_2_arena = {},	

	-- 挑战历史记录
	arenaid_2_history = {},

	-- 竞技场ID起始值
	global_id_start = 1000,

	-- 正在PK的玩家
	pking_data = {},

	-- 生成的排行榜
	toplist = {},	
	uk_2_top = {},	
}

function GlobalArenaDao:getArenaId()
	self.global_id_start = self.global_id_start + 1
	return self.global_id_start
end