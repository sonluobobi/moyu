--[[
Buffer基础数据系统Dao，用于数据管理
author : Zhao Yi
date : 2012-03-27
]]--
BufferBaseDao = { -- 存储技能基础数据，格式 : {id => obj, ...}
}

-- 格式化技能数据
function BufferBaseDao:loadFromCsv(csv_data)
	for id, csv in pairs(csv_data) do
		local buffer_base = BufferBase:new(csv)
		
		BufferBaseDao[buffer_base.id] = buffer_base
	end
end
