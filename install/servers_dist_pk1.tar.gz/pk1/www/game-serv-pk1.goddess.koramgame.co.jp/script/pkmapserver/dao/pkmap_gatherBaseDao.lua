--[[
采集物基础数据Dao
author : Zhao Yi
date : 2012-03-27
]]--

GatherBaseDao = {
	data = nil,
}

-- 格式化技能数据
function GatherBaseDao:loadFromCsv(csv)
	-- 初始化data
	self.data = {}
	
	for _, e in pairs(csv) do
		self.data[e.id] = e
	end
end
