LoverTempleTaskBaseDao = {
	id_2_task_base = {},
	all_tasks = {},	--所有任务
	weight_total = 0,

	all_tasks_without_find = {},	--所有的非找队友任务
	weight_total_wightout_find = 0,

	weight_total_for_lover = 0,
}

function LoverTempleTaskBaseDao:loadFromCsv(csv)
	for _, task_base in pairs(csv) do
		LoverTempleTaskBaseDao.id_2_task_base[task_base.id] = task_base
		table.insert(LoverTempleTaskBaseDao.all_tasks, task_base)

		LoverTempleTaskBaseDao.weight_total = LoverTempleTaskBaseDao.weight_total + task_base.random_weight
		LoverTempleTaskBaseDao.weight_total_for_lover = LoverTempleTaskBaseDao.weight_total_for_lover + task_base.random_weight_for_lover
		if task_base.dst_sort_id ~= TaskDefs.LOVE_TEMPLE_SORT_ID_FIND_MEMBER then 
			table.insert(LoverTempleTaskBaseDao.all_tasks_without_find, task_base)

			LoverTempleTaskBaseDao.weight_total_wightout_find = LoverTempleTaskBaseDao.weight_total_wightout_find + task_base.random_weight			
		end
	end
end

function LoverTempleTaskBaseDao:random( is_except_find, is_lover )
	if is_lover then 
		local value = math.random(1, LoverTempleTaskBaseDao.weight_total_for_lover)
		for i=1, #LoverTempleTaskBaseDao.all_tasks do
			value = value - LoverTempleTaskBaseDao.all_tasks[i].random_weight_for_lover
			if value <= 0 then 
				return LoverTempleTaskBaseDao.all_tasks[i]
			end
		end			
	elseif not is_except_find then 
		local value = math.random(1, LoverTempleTaskBaseDao.weight_total)
		for i=1, #LoverTempleTaskBaseDao.all_tasks do
			value = value - LoverTempleTaskBaseDao.all_tasks[i].random_weight
			if value <= 0 then 
				return LoverTempleTaskBaseDao.all_tasks[i]
			end
		end
	else
		local value = math.random(1, LoverTempleTaskBaseDao.weight_total_wightout_find)
		for i=1, #LoverTempleTaskBaseDao.all_tasks_without_find do
			value = value - LoverTempleTaskBaseDao.all_tasks_without_find[i].random_weight
			if value <= 0 then 
				return LoverTempleTaskBaseDao.all_tasks_without_find[i]
			end
		end	
	end
end