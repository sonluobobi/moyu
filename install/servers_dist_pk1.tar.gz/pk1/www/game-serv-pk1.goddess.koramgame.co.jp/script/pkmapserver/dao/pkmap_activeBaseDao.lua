--[[
活跃度Dao，用于数据管理
author: fuqian.liao
date :2015-01-05
]]--

local isTableEmpty = table.isTableEmpty
local osdate = os.date

ActiveBaseDao = {
	childgametypeid_2_data = nil, 	-- 子玩法数据
	gametypeid_2_data = nil,		-- 玩法数据
	scene_id_2_data = nil,			-- 场景ID对应子玩法数据
}

ActiveSubBaseDao = {
	
}

-- 加载玩法表
function ActiveBaseDao:loadFromCsv(csv_data)
	ActiveBaseDao.gametypeid_2_data = {}
	local gametypeid_2_data = ActiveBaseDao.gametypeid_2_data

	for _, parent_active_base in pairs(csv_data) do
		local game_type_id = parent_active_base.game_type_id
		if not gametypeid_2_data[game_type_id] then
			gametypeid_2_data[game_type_id] = parent_active_base
		else
			error('active base id duplicate,game_type_id='..game_type_id)
		end
	end
end

-- 加载子玩法表
function ActiveSubBaseDao:loadFromCsv(csv_data)
	-- 初始化data
	ActiveBaseDao.childgametypeid_2_data = {}
	ActiveBaseDao.scene_id_2_data = {}
	local childgametypeid_2_data = ActiveBaseDao.childgametypeid_2_data
	local scene_id_2_data = ActiveBaseDao.scene_id_2_data
	local gametypeid_2_data = ActiveBaseDao.gametypeid_2_data
	-- 存储活跃度数据
	for _, active_base in pairs(csv_data) do
		local child_game_type_id = active_base.child_game_type_id
		local game_type_id = active_base.game_type_id
		if not gametypeid_2_data[game_type_id] then
			Logger:error('子玩法表中存在未知的game_type_id', active_base)
		end

		if not childgametypeid_2_data[child_game_type_id] then
			childgametypeid_2_data[child_game_type_id] = active_base

			-- 拷贝主玩法表中的数据，以方便使用
			local parent_active_base = gametypeid_2_data[game_type_id]
			for k, v in pairs(parent_active_base) do
				if not active_base[k] then 
					active_base[k] = v
				end
			end
		else
			error('active sub base id duplicate,child_game_type_id='..child_game_type_id)
		end
		
		if active_base.scene_id then
			scene_id_2_data[active_base.scene_id] = active_base
		end
	end

end

function ActiveBaseDao:getActiveBaseById( child_game_type_id )
	return self.childgametypeid_2_data[child_game_type_id]
end

function ActiveBaseDao:getActiveBaseBySceneId(scene_id)
	return self.scene_id_2_data[scene_id]
end
