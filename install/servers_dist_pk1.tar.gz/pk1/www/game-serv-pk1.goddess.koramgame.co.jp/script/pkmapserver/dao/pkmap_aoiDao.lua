AoiDao = {}

AoiDao.aoi_scene_datas = {}		-- scene_id => data_scene
AoiDao.aoi_scenes = {}   		-- space_id => aoi_scene
AoiDao.is_dirty = false


