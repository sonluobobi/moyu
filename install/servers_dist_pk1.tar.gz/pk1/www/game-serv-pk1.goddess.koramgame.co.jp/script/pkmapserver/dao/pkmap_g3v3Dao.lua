--[[
3V3数据管理
autor: guoyin.huang 	
Date : 2015.04.21
--]]

G3v3Dao = {
	scene_insid_2_vs_info = {},		--场景实例ID到对战数据
}
