GangBattleChusaiDao = {
	-- 存储spaceid到对战信息
	scene_insid_2_vs_info = {},
}