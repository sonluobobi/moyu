TransferDotBaseDao = {
	sort_id2entity = {},		-- [transfer_sort_id][id] = csv
	id2entity = {},				-- [id] = csv
}

function TransferDotBaseDao:loadFromCsv(csv_data)
	for id, csv in pairs(csv_data) do
		local id2entity_t = self.sort_id2entity[csv.sort_id] or {}
		self.sort_id2entity[csv.sort_id] = id2entity_t
		id2entity_t[id] = csv
		
		self.id2entity[id] = csv
	end
end

