--[[
场景坐标点Dao，用于数据管理
author: guoyin.huang
date :2015-01-05
]]--

local isTableEmpty = table.isTableEmpty
local osdate = os.date
local tableInsert = table.insert

ScenePositionDao = {
	sceneid_2_type_2_pointlist = {}
}

-- 加载玩法表
function ScenePositionDao:loadFromCsv(csv_data)
	local sceneid_2_type_2_pointlist = ScenePositionDao.sceneid_2_type_2_pointlist

	for _, position_base in pairs(csv_data) do
		local scene_id = position_base.scene_id
		local type_id = position_base.type
		assert(scene_id)
		assert(type_id)

		local scene_position = sceneid_2_type_2_pointlist[scene_id]
		if not scene_position then
			scene_position = {}
			sceneid_2_type_2_pointlist[scene_id] = scene_position
		end
		local scene_type_position = scene_position[type_id]
		if not scene_type_position then 
			scene_type_position = {}
			scene_position[type_id] = scene_type_position
		end
		tableInsert(scene_type_position, position_base)
	end
end

function ScenePositionDao:getScenePosByType(scene_id, type_id)
	return self.sceneid_2_type_2_pointlist[scene_id][type_id]
end

function ScenePositionDao:getScenePosRandomByType(scene_id, type_id)
	local scene_points = self.sceneid_2_type_2_pointlist[scene_id][type_id]
	return scene_points[math.random(1, #scene_points)]
end

function ScenePositionDao:getScenePosesByType(scene_id, type_id)
	return ScenePositionDao.sceneid_2_type_2_pointlist[scene_id][type_id]
end