--[[
怪物AI数据系统Dao，用于数据管理
author : suwin zhong
date : 2012-06-27
--]]
MonsterAiDao = {
	data = nil, -- 存储怪物AI数据，格式 : {id => obj, ...}
}

-- 格式化怪物数据
function MonsterAiDao:formatMonsterAiData()
	if table.isTable(csv.MonsterAi) then
		-- 初始化data
		self.data = {}

		-- 存储ai数据
		for _, monster_ai in pairs(csv.MonsterAi) do
			local ai_id = monster_ai.id
			if not self.data[ai_id] then
				self.data[ai_id] = {}
			end

			for key, value in pairs(monster_ai) do
				self.data[ai_id][key] = value
			end
		end

		-- 释放csv数据
		csv.MonsterAi = nil
	end
end