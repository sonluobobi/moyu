--[[
称号系统Dao，用于数据管理
author : guoyin.huang
date : 2015-06-15
--]]

local Utils = Utils

TitleBaseDao = {
	data = nil,
	type_2_data = nil,
}

-- 格式化称号系统基本数据
function TitleBaseDao:loadFromCsv(csv_data)
	if table.isTable(csv_data) then
		-- 初始化data
		self.data = {}
		self.type_2_data = {}

		-- 存储称号数据
		for _, title_base in pairs(csv_data) do
			local title_id = title_base.id
			if self.data[title_id] then
				Logger:fatal('TibleBase.csv中重复的称号ID', title_id)
				assert(false)
			end
			self.data[title_id] = title_base
			self.type_2_data[title_base.type] = self.type_2_data[title_base.type] or {}
			table.insert(self.type_2_data[title_base.type], title_id)
		end
	end
end
