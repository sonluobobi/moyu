SceneAoiDao = 
{
	data = {},							--[scene_id][type] => {data}
	next_dy_sceneaoi_id = 100000000,		-- ��һ����̬������SceneAoi�����id
}
SceneAoiObjsDao = {}

function SceneAoiDao:loadFromCsv(csv_data)	
	local SceneAoiDao_data = self.data
	
	for i, csv in pairs(csv_data) do
		setmetatable(csv, SceneAoi)
		
		local scene_id = csv.scene_id
		local type_objs = SceneAoiDao_data[scene_id] or {}
		SceneAoiDao_data[scene_id] = type_objs
		
		local type = csv.type
		local objs = type_objs[type] or {}
		type_objs[type] = objs
		
		objs[csv.id] = csv		
		SceneAoiObjsDao[csv.id] = csv
	end
	
	SceneAoiDao.loadFromCsv = nil
	
end