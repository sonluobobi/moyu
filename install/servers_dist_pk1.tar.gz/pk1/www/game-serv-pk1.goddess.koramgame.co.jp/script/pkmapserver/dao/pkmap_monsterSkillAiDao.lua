--[[
怪物技能AI数据系统Dao，用于数据管理
author : suwin zhong
date : 2015-04-24
--]]
MonsterSkillAiDao = {
	data = nil, -- 存储怪物技能AI数据，格式 : {id => obj, ...}
}

-- 格式化怪物数据
function MonsterSkillAiDao:loadFromCsv(csv_data)
	if table.isTable(csv_data) then
		-- 初始化data
		self.data = {}

		-- 存储怪物技能ai数据
		for _, monster_skill_ai in pairs(csv_data) do
			local ai_id = monster_skill_ai.id
			if not self.data[ai_id] then
				self.data[ai_id] = {}
			end

			for key, value in pairs(monster_skill_ai) do
				self.data[ai_id][key] = value
			end
		end
	end
end