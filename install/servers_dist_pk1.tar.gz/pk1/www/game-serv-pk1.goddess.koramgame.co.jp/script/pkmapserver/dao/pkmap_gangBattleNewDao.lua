--[[
军团战  Dao
author: guoyin.huang
date: 2016-04-05
]]--
GangBattleNewDao = {
	sceneid_2_vsinfo = {},
	prepare_time = 0,
	start_time = 0,
	end_time = 0,
}
