--[[
VIP的数据Dao，用于数据管理
author : xingzeng
date : 2012-08-30
]]--

VipBaseDao = {
	data = nil,
}
-- 格式化道具数据
function VipBaseDao:loadFromCsv(csv)
	if table.isTable(csv) then
		-- 初始化data
		self.data = {}

		-- 存储vip_func数据
		for _, vip_func_db in pairs(csv) do
			local func_id = vip_func_db.func_id
			local vip_lev = vip_func_db.level
			
			local vip_func_base = self.data[vip_lev]
			if vip_func_base == nil then
				vip_func_base = {}
				vip_func_base.id = vip_lev
				vip_func_base.funcs = {}
				
				self.data[vip_lev] = vip_func_base
			end
			local funcs = vip_func_base.funcs
			funcs[func_id] = vip_func_db
		end

	end
end
