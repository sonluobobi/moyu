--[[
组队数据管理
autor: guoyin.huang 	
Date : 2015.03.24
--]]

TeamDao = {
	gcid_2_team = {},		--角色ID->team
	teamid_2_team = {},		--teamid->team
	is_on_timer = false,
}
