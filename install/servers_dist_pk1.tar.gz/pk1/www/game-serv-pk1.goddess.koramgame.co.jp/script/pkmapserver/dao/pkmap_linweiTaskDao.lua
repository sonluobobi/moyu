--[[
	临危任务Dao

--------------------角色临危信息------------------

--]]

LinweiTaskDao = {
	gcid_2_linwei_info = {},		--gcid->角色临危信息
	task_id_2_linwei_info = {},		--task_id->临危任务信息
}
