
OutdoorBossDao = {
	lays_rooms = {},			--
	spaceid_2_layer = nil,		-- 房间ID到层对应关系

	monster_id_2_lv = {},			--各层BOSS的等级(会存数据库)
}
