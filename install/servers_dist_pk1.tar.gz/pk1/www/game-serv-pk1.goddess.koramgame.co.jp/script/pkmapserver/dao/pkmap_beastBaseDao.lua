--[[
召唤物系统 DAO
author : shuyi.zhong
date : 2014-10-31
--]]

BeastBaseDao = {}

function BeastBaseDao:loadFromCsv(csv_data)
	for i, csv_db in pairs(csv_data) do
		local beast_base = BeastBase:new(csv_db)
		
		BeastBaseDao[beast_base.id] = beast_base
	end
end
