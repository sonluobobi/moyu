--[[
陷阱基础数据系统Dao，用于数据管理
author : suwin zhong
date : 2012-03-01
--]]

TrapBaseDao = {}

function TrapBaseDao:loadFromCsv(csv_data)
	for i, csv_db in pairs(csv_data) do
		local trap_base = TrapBase:new(csv_db)
		
		TrapBaseDao[trap_base.id] = trap_base
	end
end

