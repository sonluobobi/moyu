--[[
玩法DAO，用于数据管理
author: guoyin.huang
date :2015-01-05
]]--

local isTableEmpty = table.isTableEmpty
local osdate = os.date

ActiveDao = {
	gametypeid_2_activetime = {},	--玩法ID到玩法时间信息
	game_active_time = {},			--玩法时间信息数组，用于发送
	finished_list = {},				--已经完成的子玩法列表
	finished_hash = {}, 
}
