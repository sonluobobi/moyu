--[[
神兵 BASE Dao
author : guoyin.huang
date : 2015-01-05
]]--

ShenbingBaseDao = {
	skill_base_data = {},		--神兵阶数对应的配置
}
ShenbingSkillBaseDao = {
}

-- 加载神兵技能表
function ShenbingSkillBaseDao:loadFromCsv( csv_data )
	local skill_base_data = ShenbingBaseDao.skill_base_data
	for _, sb_skill_base in pairs(csv_data) do
		skill_base_data[sb_skill_base.prof] =skill_base_data[sb_skill_base.prof] or {}
		skill_base_data[sb_skill_base.prof][sb_skill_base.level] = sb_skill_base
	end
end

function ShenbingBaseDao:getSkilBase(prof, level)
	return ShenbingBaseDao.skill_base_data[prof][level]
end