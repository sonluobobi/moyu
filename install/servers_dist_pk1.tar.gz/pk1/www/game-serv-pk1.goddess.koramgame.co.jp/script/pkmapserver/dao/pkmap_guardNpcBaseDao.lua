--[[
守护NPC基础数据系统Dao，用于数据管理
author : suwin zhong
date : 2015-04-09
--]]

GuardNpcBaseDao = {}

function GuardNpcBaseDao:loadFromCsv(csv_data)
	for i, csv_db in pairs(csv_data) do
		local guard_npc_base = GuardNpcBase:new(csv_db)
		
		GuardNpcBaseDao[guard_npc_base.id] = guard_npc_base
	end
end

