--[[
���޻������� DAO
author : xingzeng.jiang
date : 2014-10-13
--]]

PetBaseDao = 
{
	data = {}, 				--[pet_base_id] = pet_base
	quality_2_pet_base = {}, -- quality_2_pet_base[quality][pet_base_id] = pet_base
	quality_aptitude_2_pet_base = {},-- quality_2_pet_base[quality][aptitude][pet_base_id] = pet_base
	pet_list = {}, --��Ż���ͼ����Ϣ
}

function PetBaseDao:loadFromCsv(csv_data)
	local pet_base_list = {}
	for i, csv_db in pairs(csv_data) do
		local pet_base = PetBase:new(csv_db)
		PetBaseDao.data[pet_base.id] = pet_base
		
		local quality , aptitude = pet_base.quality,pet_base.aptitude
		if not self.quality_2_pet_base[quality] then 
			self.quality_2_pet_base[quality] = {}
		end
		self.quality_2_pet_base[quality][pet_base.id] = pet_base
		
		if not self.quality_aptitude_2_pet_base[quality] then 
			self.quality_aptitude_2_pet_base[quality] = {}
		end
		if not self.quality_aptitude_2_pet_base[quality][aptitude] then 
			self.quality_aptitude_2_pet_base[quality][aptitude] = {}
		end
		
		self.quality_aptitude_2_pet_base[quality][aptitude][pet_base.id] = pet_base
		
		table.insert(pet_base_list,pet_base)
	end
	
	--------------------------- ��װ����ͼ����Ϣ start  -------------------------
	
	local compFunc = function(a,b)
		return a.aptitude > b.aptitude
	end
	
	table.sort(pet_base_list,compFunc)
	local arr_tmp_data = table.table_values( pet_base_list )
	
	for _,pet_base in ipairs(arr_tmp_data) do
		local quality = pet_base.quality
		if not self.pet_list[quality] then
			self.pet_list[quality] = {}
			self.pet_list[quality].quality = quality
			self.pet_list[quality].arr_pet = {}
		end
		table.insert(self.pet_list[quality].arr_pet,pet_base)
	end
	
	--------------------------- ��װ����ͼ����Ϣ end  -------------------------
end

