--[[
场景Buffer刷新表数据系统Dao
author : Zhao Yi
date : 2012-03-27
]]--
SceneBufferRefBaseDao = {
	data = nil,
}

-- 格式化技能数据
function SceneBufferRefBaseDao:loadFromCsv(csv)
	-- 初始化data
	self.data = {}
	
	for _, scene_buffer_ref_db in pairs(csv) do
		local arr_scene_buffer_ref_db = self.data[scene_buffer_ref_db.scene_id]
		if not arr_scene_buffer_ref_db then
			arr_scene_buffer_ref_db = {}
			self.data[scene_buffer_ref_db.scene_id] = arr_scene_buffer_ref_db
		end
		arr_scene_buffer_ref_db[#arr_scene_buffer_ref_db+1] = scene_buffer_ref_db
		self.data[scene_buffer_ref_db.scene_id] = arr_scene_buffer_ref_db
	end
end
