
TeamRobotNicksDao = {
	nicks = {}
}

function TeamRobotNicksDao:loadFromCsv(csv_data)
	local nicks = self.nicks
	for _, base_data in pairs(csv_data) do
		nicks[#nicks + 1] = base_data.nick
	end
end
