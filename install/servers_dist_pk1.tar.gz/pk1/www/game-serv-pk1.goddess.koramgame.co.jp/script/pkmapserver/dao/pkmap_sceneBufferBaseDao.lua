--[[
场景Buffer基础数据系统Dao
author : Zhao Yi
date : 2012-03-27
]]--
SceneBufferBaseDao = {
	data = nil,
}

-- 格式化技能数据
function SceneBufferBaseDao:loadFromCsv(csv)
	-- 初始化data
	self.data = {}
	
	for _, scene_buffer_db in pairs(csv) do
		self.data[scene_buffer_db.id] = scene_buffer_db
	end
end
