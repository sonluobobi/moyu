--[[
场景Trap刷新表数据系统Dao
author : Zhao Yi
date : 2012-03-27
]]--
TrapRefreshBaseDao = {
	data = {},
}

-- 格式化技能数据
function TrapRefreshBaseDao:loadFromCsv(csv)
	-- 初始化data
	self.data = {}
	
	for _, trap_ref_db in pairs(csv) do
		local arr_trap_ref_db = self.data[trap_ref_db.scene_id]
		if not arr_trap_ref_db then
			arr_trap_ref_db = {}
			self.data[trap_ref_db.scene_id] = arr_trap_ref_db
		end
		arr_trap_ref_db[#arr_trap_ref_db+1] = trap_ref_db
		self.data[trap_ref_db.scene_id] = arr_trap_ref_db
	end
end
