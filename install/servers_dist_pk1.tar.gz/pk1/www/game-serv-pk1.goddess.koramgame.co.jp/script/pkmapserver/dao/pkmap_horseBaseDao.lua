--[[
坐骑基础表 DAO
author : xingzeng.jiang
date : 2014-10-13
--]]

HorseBaseDao = {
	data = {},				-- {id->HorseBase}
	horse_by_lay_id = {},			-- {evolve_lay_id->HorseBase}
}

--- 从 CSV 读入
function HorseBaseDao:loadFromCsv(csv_data)
	local data = HorseBaseDao.data
	local horse_by_lay_id = HorseBaseDao.horse_by_lay_id
	
	for i, csv_db in pairs(csv_data) do
		local id, evolve_lay_id = csv_db.id, csv_db.evolve_lay_id
		data[id] = csv_db
		horse_by_lay_id[evolve_lay_id] = csv_db
	end
end
