--[[
天魔灭心数据层
author : xingzeng
date : 2013-03-26
]]--

TianmoDao = {
	ch_reach_lays = {},		-- 本次活动角色达到的最高层数 ch_reach_lays[cid] = lay_max
	boss_room_ins = nil,	-- BOSS房间实例
	tianmo_ins = nil,		-- 天魔灭心实例
	
	old_boss_room_ins = nil,
	old_ch_reach_lays = nil,
}

TianmosDao = {
	daos = {},
}