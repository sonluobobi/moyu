--[[
	陷阱实体
--]]

Trap = 
{
	-- 存储trap.csv中的结构
	trap_base = nil,

	-------- 实例化后增加属性 --------
	aoi_id = 0,		-- id(aoi_obj.obj_id)
	aoi_type = 0,	-- AoiObjectType.AOI_OBJECT_TYPE_ID_TRAP
	aoi_obj = nil,
	x = 0,
	y = 0,
	
	nick = '',

	expire_time = 0,	-- 陷阱过期时间(毫秒级)
	next_play_time = 0,	-- 下一次触发事件

	parent_aoi_id = 0,	-- 主人的AOI ID

	tmps = nil,			-- 临时数据
}

function Trap:createTmps(my_zhenying)
	-- 初始化tmps
	local tmps =
	{
		now_state = 0,						-- 当前状态
		now_state_expire = 0,				-- nil，代表永不过期

		motion_state = false,

		fight_number_id = 0,		-- 战斗计算id
		fight_expire = 0,			-- 攻击状态的过期时间(有的是瞬时战斗，而引导技能有持续时间)
		lock_expire = 0,			-- 锁定的过期时间(有些锁定技能在播放期间不允许被其他人攻击)
		self_skill_expires = {},	-- 所有私有技能cd过期时间
		play_skill_expire = 0,		-- 允许触发下一个技能的时间
		fight_info = {},			-- 每次战斗攻击的临时信息(add by suwin)
		targeter_fight_info = {},	-- 被攻击者临时战斗信息(add by suwin)
		pet_tianfu = {},			-- 幻兽天赋能力加成
		fight_buffers = nil,		-- 战斗BUFFER

		zhenying = my_zhenying,		-- 阵营
	}

	return tmps
end