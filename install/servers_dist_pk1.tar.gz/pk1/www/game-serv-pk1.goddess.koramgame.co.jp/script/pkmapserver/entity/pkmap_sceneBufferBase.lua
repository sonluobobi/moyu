--[[
场景BUFFER数据实体
author : xingzeng jiang
date : 2012-6-15
--]]


SceneBufferBase = {
	id = 0,					--自增ID
	sort_id = 0,			--类型。 1:BUFFER， 2:特殊技能， 3：陷阱, 4: 积分, 5：女神变身BUFF
	res_id = 0,				--3D资源ID
	pic_id = 0,				--2D图标ID
	texiao_id = 0,			--特效ID
	nick = '',				--名称
	
	is_en_use_gold = 0,		--是否允许使用元宝购买(价格在LanguagePrice里面定义)
	need_vip = 0,			--需要VIP等级
	cd_time = 0,			--使用的CD时间(毫秒)
	attach_res_id = 0,		--拾取后附加在头顶的资源ID
	is_pickup_use = 0,		--是否拾取就立即使用
	life_mtime = 0,			--存活时间(毫秒)
	zhenying = 0,			--所属阵营(0:无阵营)
	
	buffer_ids = false,		--BUFFER ID列表 type:ArrayList
	trap_id = 0,			--触发的陷阱ID
	skill_type = 0,			--特殊技能类型
	skill_value1 = 0,		--特殊技能效果值1
	skill_value2 = 0,		--特殊技能效果值2
	score = 0,				--所加积分
	
	ok_tips = '',			--使用成功的提示
	intro = '',				--场景BUFF描述
}
