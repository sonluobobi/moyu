--[[
魅力活动
author: liujinlin
date: 2016-04-12
]]--

JBTask = {
  dyn_id = 0,  --动态id
  type = 0,--接任务的类型 1为守，2为攻
  status = 0, --1预备，2开始，3结束
  monster_pos_id = 0, --下1,右2,上3，左4
  shou_pos_id = 0, --守的位置
  gong_pos_id = 0,--攻的位置
  start_time = 0, --开始时间(时间戳)
  monsters = {}, --所有女神最新信息   
  task_base_id = 0, --基本任务id
  arrived_ids = {}, --到达的女神aoi,ids
}

function JBTask:new(id,godposid,sposid,gposid,st,goddess,arrived_ids)
  local o = {}
  o.dyn_id = id
  o.type = 0
  o.status = 0
  o.monster_pos_id = godposid
  o.shou_pos_id = sposid
  o.gong_pos_id = gposid
  o.start_time = st
  o.monsters = goddess   
  o.task_base_id = id
  o.arrived_ids = arrived_ids
  return o  
end

JB_role = {
  start_time = 0,--报名的任务时间可以唯一确定
  status = 0,--接任务的类型 1为守，2为攻,没接就是0
}


JB_monster_status = {
  monster_baseid = 0,
  isdead = false,  
}