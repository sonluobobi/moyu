--[[
场景BUFFER刷新表
author : xingzeng jiang
date : 2015-04-29
--]]

SceneBufferRefBase = {
	id = 0,					--自增ID
	sort_id = 0,			--类型。 0:定时刷出场景BUFF掉落物, 1:60副本的场景BUFF, 2:定点刷出
	scene_id = 0,    		--场景ID
	
	scene_buffer_ids = false,--场景BUFFER ID列表 type:ArrayList
	
	drop_type = 0,			--掉落方式。 0:掉落物, 1:采集物， 2,-- 掉落物(多个点占位随机)
	max_pickup_num = 0,		--最大可拾取个数
	drop_poss = nil,		--掉落的位置范围(一个矩形范围列表)
	drop_radius = 0,		--掉落半径
	is_in_one_area = 0,		--是否只在一个区域内随机刷出 0:各个区域纯随机，1：仅出现在1个区域
	
	ref_frequency = 0,		--掉落物刷新频率(秒)
	ref_per_num = 0,		--每次的刷新个数
	ref_time_dots = false,	--刷新的时间区间(ref_time_dots = {830,1011,1300})  type:ArrayList
	
	is_bc = 0,				--刷出时是否广播
}
