--[[
	临危任务实体
--]]

LinweiTaskBaseCsv = 
{
	id = 0,			--ID
	task_type = 0,	--任务类型
	task_title = '',--任务名称
	task_desc = '',	--任务描述串
	step_num = 0,	--任务步数
	random_weight = 0,	--刷出权重
	sort_id = 0,		--任务类别(1为基础任务，2为组合任务)
	lib_type_list = nil,--每波怪对应库列表
	hongbao_param = 0,	--红包的参数（守护任务为NPC血量百分比，其他为时长	//type:float
	task_time_long = 0,	--任务总时长
}

--基本任务信息
LinweiTaskBase = 
{
	task_type = 0,		--任务类型
	totle_steps = 0,	--怪物总的波数
	now_step = 0,		--现在处于第几波
	common_monster_id = 0,	--基础怪物ID
	need_kill_num = 0,		--需要杀死的怪物数量
	killed_num = 0,			--已经杀死的怪物数量
	npc_id = 0,				--需要守护的NPC的ID
	boss_monster_id = 0,	--需要杀死的BOSS怪ID
	boomb_monster_id = 0,	--爆炸怪
	boomb_monster_num = 0,	--爆炸怪数量
	boomb_monster_killed_num = 0,	--爆炸怪已杀数量
}

-- 临危任务库
LinweiTaskLib = 
{
	id__kn		= 0,		--#"ID"
	lib_type	= 0, 		--库类型(1用于清怪任务、2用于守护NPC中NPC配置、3用于守护NPC中怪物配置、4用于击杀BOSS
	is_surprise = 0,		--是否用于惊喜任务
	useful_step = false,	--可用于第几波(清怪任务、守护NPC、其他的填1)
	sort_id 	= 0,		--类型(1普通怪、2BOSS、3NPC)
	useful_level_list = false,--可用于的野外等级
	common_monster_id = 0,	--普通怪物ID(清怪任务，守护NPC)
	boss_monster_id = 0,	--BOSS怪ID(击杀BOSS任务)
	npc_id = 0,				--守护NPC的NPC ID(GuardNpc.csv)
	bomb_monster = nil, 	--爆炸怪信息 {{{monster_id, num, rate}, {monster_id, num, rate}}}
}


--一组任务信息
LinweiTaskArray = {
	arr_total_steps = 0,	--总的任务数
	arr_now_step = 0,		--现在处于第几个任务
	task_type_list = false,	--任务列表（存储类型) -- type:uint[]
}

-- 临危任务信息
LinweTask = {
	task_id = 0,		--任务ID，每个任务均有独立的ID
	task_type = 0,		--任务类型
	task_pos = 0,		--任务生成的位置 左下1，右下2，右上3，左上4
	arr_task = false,	--如果是任务组，此为任务组的信息	--type:LinweiTaskArray
	base_task = false,	--正在进行的基础任务的信息			--type:LinweiTaskBase
}

-- 角色临危信息
ChLinweiInfo = {
	gcid = 0,	-- 角色gcid
	gpid = 0,	-- 角色gpid
	nick = '',	-- 角色nick
	total_hurt = 0,	--总伤害
}

-- 临危任务进行信息
LinweiInfo = {
	gpid_list = nil,		--已经加入任务的角色PID数组
	task = nil,				--临危任务信息
	aoiid_2_monstertype = nil,	--对象ID->对象类型列表
}