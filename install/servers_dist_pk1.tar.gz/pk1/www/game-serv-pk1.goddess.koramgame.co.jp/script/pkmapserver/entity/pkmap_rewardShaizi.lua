--[[
摇骰子奖励数据结构
author : xingzeng
date : 2015-04-10
--]]

RewardShaizi = 
{
	jie_id = 0,						-- 届ID
	gcid = 0,						-- 角色ID
	nick = '',						-- 角色名
	dianshu = 0,					-- 点数
	is_first = false,				-- 是否最高点数
	is_assigned_reward = false,		-- 是否已发放奖励
	
	reward_module_id = 0,			-- 奖励模块ID
	reward_equips = {},				-- 奖励内容		type:List<int>
}

function RewardShaizi:new(jie_id, reward_module_id, gcid, nick, dianshu, reward_equips)
	local o = {}
	o.jie_id = jie_id
	o.gcid = gcid
	o.nick = nick
	o.dianshu = dianshu
	o.is_first = false
	o.is_assigned_reward = false
	o.reward_module_id = reward_module_id
	o.reward_equips = reward_equips
	return o
end