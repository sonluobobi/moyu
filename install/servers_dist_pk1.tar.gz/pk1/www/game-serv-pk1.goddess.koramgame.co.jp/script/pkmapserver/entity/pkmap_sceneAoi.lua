SceneAoi = 
{
	id = 0,
	type = 0,
	class_id = 0,
	phase_id = 0,
	scene_id = 0,
	x = 0, --type:float
	y = 0, --type:float
	direction = 0, --type:float
	patro_ways = {},-- 巡逻路径 {{x,y},{x,y},{x,y}}  type:ArrayList
	caller_prof = 0,	--召唤者职业
	zhenying = 0,		--阵营（默认填0或不填）服务器暂不使用
}

function SceneAoi:new(id, type, class_id, scene_id, x, y, direction, patro_ways, phase_id)
	local o = {}
	o.id = id
	o.type = type
	o.class_id = class_id
	o.scene_id = scene_id
	o.x = x
	o.y = y
	o.direction = direction
	o.patro_ways = patro_ways
	o.phase_id = phase_id
	return o
end