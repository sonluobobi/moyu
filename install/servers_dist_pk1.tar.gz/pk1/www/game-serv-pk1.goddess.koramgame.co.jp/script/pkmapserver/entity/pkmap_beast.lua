--[[
	召唤兽实体
--]]

Beast = 
{
	-- 存储beast.csv中的结构
	beast_base = nil,

	-------- 实例化后增加属性 --------
	aoi_id = 0,		-- id(aoi_obj.obj_id)
	aoi_type = 0,	-- AoiObjectType.AOI_OBJECT_TYPE_ID_BEAST
	aoi_obj = nil,
	x = 0,
	y = 0,
	scene_id = 0,	-- 当前所在场景ID
	space_id = 0,	-- 当前所在场景实列ID

	nick = '',
	level = 1,			-- 等级
	speed = 0,			-- 速度

	expire_time = 0,	-- 召唤物过期时间(毫秒级)
	parent_aoi_id = 0,	-- 主人的AOI ID

	model_times = 1,	-- 放大倍数 //type:float
	body_size = 0,		-- 身体大小

	---------------- 战斗相关属性 start ------------------
	hp			 = 0,			-- 当前hp值	type:long
	max_hp 		 = 0,			-- 最大HP值	type:long

	min_attack = 0,				-- 最小攻击
	max_attack = 0,				-- 最大攻击
	
	defence_phy = 0,			-- 物理防御
	defence_magic = 0,			-- 魔法防御
	
	dodge = 0,					-- 闪避
	critical_hit = 0,			-- 暴击
	parry = 0,					-- 格挡

	addi_harm_perc = 0,			-- 加伤百分比
	addi_harm = 0,				-- 加伤绝对值
	reduce_harm_perc = 0,		-- 减伤百分比
	reduce_harm = 0,			-- 减伤绝对值

	douzhi = 0,					-- 斗志
	luck = 0,					-- 幸运
	kill_force = 0,				-- 斩杀力
	---------------- 战斗相关属性 end --------------------

	tmps = nil,			-- 临时数据()
}


function Beast:createTmps(my_zhenying)
	-- 初始化tmps
	local tmps =
	{
		now_state = 0,						-- 当前状态
		now_state_expire = 0,				-- nil，代表永不过期

		motion_state = false,

		fight_number_id = 0,		-- 战斗计算id
		fight_expire = 0,			-- 攻击状态的过期时间(有的是瞬时战斗，而引导技能有持续时间)
		self_skill_expires = {},	-- 所有私有技能cd过期时间
		play_skill_expire = 0,		-- 允许触发下一个技能的时间
		in_server_fight = 0,		-- 是否在由服务器触发的战斗状态中
		arr_server_fight_skill = {},-- 服务器触发的战斗技能信息
		fight_info = {},			-- 每次战斗攻击的临时信息(add by suwin)
		targeter_fight_info = {},	-- 被攻击者临时战斗信息(add by suwin)
		pet_tianfu = {},			-- 幻兽天赋能力加成
		fight_buffers = nil,		-- 战斗BUFFER
		my_targeter_aoi_id = 0,		-- 我的攻击目标aoi_id

		delete_time = 0,			-- 死亡后(通知客户端)删除尸体的时间

		zhenying = my_zhenying,		-- 阵营
	}

	return tmps
end