--[[
	场景机器人数据实体
--]]

-- local
local createFastPacket = FastPacket and getmetatable(FastPacket).__call

-- 场景机器人 数据结构共享角色的
SceneRobot = {}

local pairs = pairs
local Statics = Statics

-- new 场景机器人对象
local AOI_OBJECT_TYPE_ID_ROBOT = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT
local DEFAULT_ZHENYING_PLAYER = Statics.DEFAULT_ZHENYING_PLAYER
local setmetatable = setmetatable
function SceneRobot.new()
	local o = {}
	setmetatable(o, Character)
	
	-- 存放c对象
	o.aoi_type = AOI_OBJECT_TYPE_ID_ROBOT
	
	-- 初始化临时数据
	o.tmps, o.tmps_ex = SceneRobot.createTmps(o)

	return o
end


-- 创建角色临时数据
function SceneRobot.createTmps(robot)
	-- 目前与玩家逻辑一致，故用角色的createTmps接口
	return Character.createTmps(robot)
end


-- 初始化角色对象
function SceneRobot.init(robot, robot_attrib_db, parent_game_obj)
	-- 目前与玩家逻辑一致，故用角色的init接口
	Character.init(robot, robot_attrib_db)
	
	robot.parent_aoi_id = parent_game_obj.aoi_id
end

