
-- 基础buffer表
BufferBase = 
{	
	id = 0,					-- id
	title = '',				-- BUFFER名
	sort_id = 0,			-- BUFFER类型 (0: 普通BUFF)
	level = 0,				-- 等级(主要用于BUFFER 替换规则)
	
	effect_id = 0,			-- 属性加成类型ID
	effect_type = '',		-- 属性加成类型名
	effect_value = 0,		-- 加成值(支持小数)		type:float
	effect_value2 = 0,		-- 加成值2(支持小数)	type:float
	effect_value_ext = false,--额外加成值(复杂数据结构，table类型)	type:Hashtable __t
	duration = 0,			-- buffer持续时间(豪秒) (0 代表非持续性BUFF)
	cd_time = 0,			-- BUFFER使用的CD时间(毫秒)
	freq_msec = 0,			-- 状态触发频率间隔(毫秒) (注：最少得大于等于500毫秒)
	is_formula = 0,			-- BUFFER效果值是否需要通过公式计算获得(0:不需要，1：需要)
	
	picture = 0,			-- BUFFER图标ID
	texiao_ids = '',		-- BUFFER特效ID串(eg:45,33)
	big_picture = 0,		-- BUFFER大图标ID (用于场景BUFFER界面显示)
	is_debuffer = 0,		-- 是否反面BUFFER(0:正面, 1:反面)
	is_dead_del = 0,		-- 是否死亡删除
	attch_dots = '',		-- 特效挂接点列表(eg:45,33)
	height = 0,				-- BUFF放置相对AOI对象的高度	type:float
	attach_res_id = 0,		-- 附着到角色身上的资源ID
	model_times = 0,		-- AOI对象中BUFF后的模型放大倍数 type:float
	
	target_id = 0,			-- 目标类型  具体定义见SkillDefx定义 SKILL_TARGET_ID_*
	is_bc_other = 0,		-- 是否需要把BUFFER状态广播给其他玩家
	fight_text_id = 0,		-- 战斗飘字 ID
	
	tips = '',				-- BUFFER tips
	intro = '',             -- BUFFER 技能描述
}
BufferBase.__index = BufferBase

local table = table
function BufferBase:new(csv)
	local o = {}
	setmetatable(o, self)
	
	for key, value in pairs(csv) do
		-- 基类值为nil，代表是table类型的字段
		if not self[key] then
			if not table.isTableEmpty(value) then
				o[key] = value
			end
		elseif value ~= o[key] then
			o[key] = value
		end
	end
	
	-- 去掉服务器不使用的字段
	o.tips = nil
	o.intro = nil
	o.title = nil
	o.height = nil
	o.attch_dots = nil
	o.texiao_ids = nil
	
	return o
end


