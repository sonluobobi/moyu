--[[
采集物
author : xingzeng
date : 2015-05-06
--]]

--- 基础信息
GatherBase = {
	id = 0,				--ID
	nick = '',			--采集物的名字
	
	res_id = 0,			--采集物的资源ID
	--[[
	sort_id = 0,		--类型ID(0:普通类型， 1:能召唤出场景BUFF, 2: 场景道具宝箱)

	scene_id = 0,		--场景ID
	group_id = 0,		--组ID(同一组内只能采集一个)	
	buffer_id = 0,		--采集会获得的BUFFER ID
	buffer_num = 0,		--采集会获得的BUFFER 个数
	equip_id = 0,		--采集会获得的道具 ID (采集一个只能获取一个道具)
	powers_id = 0,		--阵营ID
]]--
	gather_time = 0,	--采集需要的时间
}
