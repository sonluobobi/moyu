
-- 召唤兽基础表
BeastBase = 
{
	id = 0,						-- 召唤兽基础ID
	title = '',					-- 陷阱名字
	res_id = 0,					-- 资源id(客户端只需要资源id)
	model_times = 1,			-- 模型倍数, type:float
	body_size = 0,				-- 身型长度(身体中心点到身体最远边界的距离), type:float 
	sort_id = 0,				-- 召唤兽类型(1:攻击类/2:辅助类(复活,加血))
	skill_id1 = 0,				-- 召唤兽技能id
	skill_id2 = 0,				-- 召唤兽技能id2
	zibao_params = {},			-- 自爆的参数  __t type:Hashtable {radius=*半径, harm_radix=*伤害系数, harm_num=*伤害人数}

	is_follow = 0,				-- 是否跟随召唤者移动
	speed = 0,					-- type:float

	hp_radix = 1,				-- hp系数 type:float
	
	attack_radix = 1,			-- 攻击系数 type:float

	defence_phy_radix = 1,		-- 物理防御系数 type:float
	defence_magic_radix = 1,	-- 魔法防御系数 type:float

	dodge_radix = 1,			-- 闪避系数 type:float
	critical_hit_radix = 1,		-- 暴击系数 type:float
	parry_radix = 1,			-- 格挡系数 type:float

	addi_harm_perc_radix = 1,	-- 加伤百分比系数 type:float
	addi_harm_radix = 1,		-- 加伤绝对值系数 type:float
	reduce_harm_perc_radix = 1, -- 减伤百分比系数 type:float
	reduce_harm_radix = 1,		-- 减伤绝对值系数 type:float

	douzhi_radix = 1,			-- 斗志系数 type:float
	luck_radix = 1,				-- 幸运系数 type:float
	kill_force_radix = 1,		-- 斩杀力系数 type:float

	dead_delay_ms = 0,			-- 死亡延迟消失的毫秒数
	distance_del = 0,			-- 距离角色多少米就自动删除
}
BeastBase.__index = BeastBase


local table = table
function BeastBase:new(csv)
	local o = {}
	setmetatable(o, self)
	
	for key, value in pairs(csv) do
		-- 基类值为nil，代表是table类型的字段
		if not self[key] then
			if not table.isTableEmpty(value) then
				o[key] = value
			end
		else
			o[key] = value
		end
	end
	
	return o
end
