--[[
任务数据实体
author : guoyin.huang
date : 2014-12-24
--]]

LoverTempleTaskBase = {
	---------------------------------------- 基础属性 start ----------------------------------
	id = 0,             				--任务ID
	title = "",							--任务的名称
	dst_intro = "",						--任务描述
	accept_npc_dialog = "",				--领取时npc的对话文字串
	dst_sort_id = 0,					--目标类型id 
	quality = 0,						--任务品阶
	reward = false,						--奖励 		//type:Hashtable
	reward_num = 0,						--奖励扣除的数量
	random_weight = 0,					--刷出权重
	random_weight_for_lover = 0,		--情侣组队的刷出权重
}


