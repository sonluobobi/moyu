--[[
小地图
author : xingzeng
date : 2015-04-21
--]]

SmallMapItem = {
	aoi_id = 0,			--AOI ID(如果不是AOI对象，则是SmallMapDao分配的负数的ID)
	sort_id = 0,		--小地图对象类型
	x = 0,				-- x type:float
	y = 0,				-- y type:float
	zhenying_id = 0,	--阵营ID
	state = 0,			--状态
	team_id = 0,		--队伍ID
}

function SmallMapItem:new(aoi_id, sort_id, x, y, zhenying, state)
	local o = {}
	o.aoi_id = aoi_id
	o.sort_id = sort_id
	o.x = x
	o.y = y
	o.zhenying_id = zhenying
	o.state = state
	o.team_id = 0
	return o
end
