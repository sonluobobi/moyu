
-- 守护NPC基础表
GuardNpcBase = 
{
	id = 0,						-- 守护npc基础ID
	title = '',					-- 名字
	res_id = 0,					-- 资源id(客户端只需要资源id)
	model_times = 1,			-- 放大倍数 //type:float
	body_size = 0,				-- 身型长度(身体中心点到身体最远边界的距离), type:float

	speed = 0,					-- type:float
	max_hp = 0,					-- 最大HP值	type:long

	attacked_lost_hp = 0,		-- 每次被攻击扣多少血

	is_save_visible = 0,		-- 保护字样是否可见
	is_play_dead_action = 0,	-- 是否播放死亡特效 1播放，0或不填不播放 
}
GuardNpcBase.__index = GuardNpcBase


local table = table
function GuardNpcBase:new(csv)
	local o = {}
	setmetatable(o, self)
	
	for key, value in pairs(csv) do
		-- 基类值为nil，代表是table类型的字段
		if not self[key] then
			if not table.isTableEmpty(value) then
				o[key] = value
			end
		else
			o[key] = value
		end
	end
	
	return o
end
