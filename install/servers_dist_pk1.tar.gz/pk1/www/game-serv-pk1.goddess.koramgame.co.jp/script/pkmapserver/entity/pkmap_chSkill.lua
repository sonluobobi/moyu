---[[
--	角色技能
--  by mjl
--  at 2013年7月15日
---]]

--客户端使用
ChSkill = 
{
	skill_id = 0,					-- 技能ID
	level = 0,						-- 等级
}

ChSkillsInfo = 
{
	slot = {},						--技能槽 --type:Hashtable	slot[order_by] = skill_id
	ch_skills = {},					--已开启的技能 --type:Hashtable   ch_skills[skill_id] = ChSkill
}

function ChSkillsInfo:init()
	local o = 
	{
		slot = {},
		ch_skills = {}	,
	}
	return o
end

