--[[
怪物基本属性信息，csv结构
author : suwin zhong
date : 2014-11-03
--]]

MonsterBase = {
	------------------ 基本信息 -------------------
	id = 0,					-- 怪物ID
	monster_sort_id = 0,	-- 怪物类型ID(1 : 普通怪; 2 : boss怪; 3 : 奖励酒坛; 4 : 普通酒坛; 5 : 世界boss; 6 : 帮会boss)
	res_id = 0,				-- 资源ID, 如果是多个id数组, 则为 "己方ID,地方ID" 格式
	pic_id = 0,				-- 头像id
	nick = '',				-- 怪物名字
	level = 0,				-- 等级
	hp_bar_num = 0,			-- 血条量
	model_times = 0,		-- 模型倍数, type:float
	body_size = 0,			-- 身型长度(身体中心点到身体最远边界的距离), type:float 
	drop_pickup_mode = 0,	-- 掉落物拾取模式(定义见 ItemDefs.ITEM_PICKUP_MODE_*)
	drop_pack_ids = false,	-- 怪物掉落包绑定	type:ArrayList
	powers_id = 0,			-- 所属势力
	is_hate = 0,			-- 是否有仇恨(默认0 : 没有仇恨; 1 : 有仇恨)
	is_can_attack = 0,		-- 是否会攻击(默认1 : 会攻击; 0 : 不会攻击; 2 : 会逃跑)
	is_idle_homing = 0,		-- 是否空闲回家(默认1 : 会; 0 : 不会)
	is_homing_max_hp = 0,	-- 是否回家时候会满血(默认1 : 会; 0 : 不会)
	attack_delay_ms = 0,	-- 怪物被攻击的时候cd延迟数(毫秒)
	is_can_lock = 0,		-- 是否连击会被锁定(1 : 会被锁定，0 : 不会被锁定)
	is_no_yun_mabi = 0,		-- 是否免疫晕眩/麻痹(1 : 会免疫，0 : 不会免疫)
	is_nvsheng = 0,			-- 是不是女神

	------------------ 战斗信息 -------------------
	skill_id = 0,			-- 默认技能id
	ai_ids = {},			-- AI串, type:int[]
	ai_delay_msec = 0,		-- 怪物出生多久后才开始判断ai条件(毫秒)
	move_delay_msec = 0,	-- 怪物出生后多久才开始做移动逻辑(毫秒)(用于怪物出生有特效，免得特效没播放完就开始移动)
	is_homing_reset_ai = 0, -- 怪物回防是否重置ai(1 : 重置； 0 : 不重置)

	speed = 0,				-- 怪物移动速度(跑动), type:float
	walk_speed = 0,			-- 怪物走动速度(走动), type:float
	max_hp = 0,				-- 最大HP值	type:long

	max_attack = 0,			-- 最大攻击
	min_attack = 0,			-- 最小攻击
	
	defence_phy = 0,		-- 物理防御
	defence_magic = 0,		-- 魔法防御
	
	douzhi = 0,				-- 斗志
	critical_hit = 0,		-- 暴击
	dodge = 0,				-- 闪避
	parry = 0,				-- 格挡

	-- 高级属性
	addi_harm = 0,			-- 附伤 附加伤害绝对值
	addi_harm_perc = 0,		-- 加伤 增加百分比伤害
	reduce_harm = 0,		-- 减伤 : 降低伤害绝对值
	reduce_harm_perc = 0,	-- 免伤 : 降低百分比伤害
	kill_force = 0,			-- 斩杀力
	luck = 0,				-- 幸运

	------------------ 其他信息 -------------------
	is_active_monster = 0,	-- 是否主动怪(0 : 被动, 1 : 主动)
	view_dist = 0,			-- 怪物视野范围(玩家进入怪物的视野的距离，怪物会主动攻击), type:float
	follow_dist = 0,		-- 怪物跟随攻击距离(怪物追踪玩家距离自己出生点的最长距离), type:float

	-- 循环移动(规则: 策划预先写好移动路径，两个/多个坐标，怪物顺序从开始坐标点向下一个坐标点移动)
	-- 随机移动(规则: 距离出生点2米内，随机找一个点移动；触发条件是被玩家看到)
	-- 静止移动(规则: 永远不会动，就算被攻击也不动，但是会反击)
	move_sort_id = 0,		-- 移动方式(0 : 静止类型, 1 : 循环移动, 2 : 随机移动, ...)

	-- 复活相关
	relive_num = 0,			-- 复活次数(0无限次复活)
	relive_interval = 0,	-- 复活间隔(不复活填0)

	-- 扣血相关(大于0的就认为是固定扣血的；如果两个值一样大，就是固定扣血的；不然就在最大和最小值之间随机)
	min_lost_hp = 0,		-- 固定伤害的怪物扣血最小值
	max_lost_hp = 0,		-- 固定伤害的怪物扣血最大值

	-- 攻击其他对象固定扣血百分比
	attack_lost_hp_perc = 0,

	-- 主要应用在关卡、副本里面的塔防式玩法；并不是所有怪物都需要
	dup_num = 0,			-- 出现次数(默认是0，填2及以上就是间隔x时间后，出现怪物后，再间隔x时间后再刷出怪物；进入怪物视野后开始计时(eg:2)；最大9999)
	dup_interval = 0,		-- 怪物复制的刷出时间间隔(单位 秒)(eg:10)

	sound = 0,				-- 怪物战斗的声音
	fight_dialog = '',		-- 战斗对话
	idle_dialog	= '',		-- 怪物自言自语
	boss_tips = '',			-- 给玩家提示boss怪物的特点
	appear_texiao = '',		-- 怪物出现时候的特效
	appear_type = 0,		-- (临危怪，身上有闪烁的发光)
	dead_texiao_type = 0,	-- 死亡特效类型(0就是动作，大于0就是特效)
	dead_add_ms = 0,		-- 死亡后加的毫秒数(某些玩法怪物死亡后会增加玩法的持续时间)
	dead_music = 0,			-- 死亡的声音
	attach_effect_id = 0,	-- 脚底特效
	show_title = 0,			-- 是否显示名字
	del_delay_sec = 0,		-- 延迟删除秒数
	attacker_sound_type = 0, -- 怪物攻击声效类型
	level_repress = 0,		-- 是否需要等级压制(0:不压制，1压制)
	effect_id = 0,			-- 怪物特效id
}

-- 客户端不需要的字段(生成的.cs文件里面的EquipBase类不会含下面字段)
MonsterBase__noclient = {
	drop_pack_ids=1,
}