--[[
角色坐骑实体
author : xingzeng
date : 2014-08-15
--]]

--- 角色坐骑对象
ChHorse = {
	id = 0,           	 		-- 坐骑ID (同坐骑基础ID)
	
	fight_capacity = 0,			-- 战力
	addi_harm = 0,				-- 当前加伤
	reduce_harm = 0,			-- 当前减伤
	fruit_addi_harm = 0,		-- 朱果增加的 加伤
	fruit_reduce_harm = 0,		-- 朱果增加的 加伤
	
	eat_fruit_num = 0, 			-- 已经吃了多少个朱果
	evolve_failed_num = 0, 		-- 祝福值
	
	-- 下面字段不会持久化到数据库
	cid = 0,					-- 所属主人的角色ID
	horse_base = nil,			-- 坐骑基础数据
	add_speed = 0,				-- 坐骑当前的加成给玩家的速度
	-- 客户端使用字段
	speed_level = 0,			-- 坐骑速度等级
}

function ChHorse:new(character, horse_base)
	local ch_horse = {}
	
	ch_horse.id = horse_base.id
	ch_horse.fight_capacity = 0
	ch_horse.addi_harm = 0
	ch_horse.reduce_harm = 0
	ch_horse.fruit_addi_harm = 0
	ch_horse.fruit_reduce_harm = 0
	ch_horse.eat_fruit_num = 0
	ch_horse.evolve_failed_num = 0
	
	ch_horse.cid = character.id
	ch_horse.horse_base = horse_base
	
	return ch_horse
end

-- 不需要持久化到DB的字段
-- 注：玩家迁移MAP，不需要持久化的这些字段
ChHorseNoSaveDbField = {
	cid = 0,					-- 所属主人的角色ID
	horse_base = false,			-- 坐骑基础数据
	add_speed = 0,
}
ChHorseSaveDbField = {}
do
	for k, v in pairs(ChHorse) do
		if not ChHorseNoSaveDbField[k] and type(v) ~= 'function' then
			ChHorseSaveDbField[k] = 1
		end
	end
end


-- 角色坐骑信息
ChHorseInfo = {
	ch_horse = nil,				-- 当前拥有的角色坐骑
	ride_horse_id = 0,			-- 当前骑乘的坐骑ID 0:代表未乘骑
	is_ride = 0,				-- 是否骑乘
	level = 0,					-- 等级(速度)
	exp = 0,					-- 当前经验
	is_lev_full = 0,			-- 是否已满级
	speed = 0,					-- 坐骑给玩家增加的速度
	skin_equip_id = 0,			-- 当前设置显示的坐骑皮肤ID
	skins = false,				-- 坐骑当前的皮肤列表 {{id=xx,expire=xx},...}	type:List<ChHorseSkin>
	
	--下面字段不会持久化到数据库 供客户端使用
	toplist_add_speed = 0,		-- 坐骑积分排行榜增加的速度
	extra_effect = false,		-- 属性加成	type:Effects
	now_speed = 0,				-- 角色当前速度
	next_speed = 0,				-- 升到下一级后角色速度
}
ChHorseSkin = {
	id = 0,						-- 皮肤道具ID
	expire = 0,					-- 过期时间
	client_Equals__ = 'id',
}

function ChHorseInfo:new(character)
	local horses_info = {}
	horses_info.ch_horse = nil
	horses_info.ride_horse_id = nil
	return horses_info
end

