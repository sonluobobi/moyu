--[[
	角色数据实体
--]]

-- local
local createFastPacket = FastPacket and getmetatable(FastPacket).__call

-- 角色对象类定义
Character = 
{
	c_obj		 = nil, 	-- 绑定的c++对象

	------------------- 所有不需要持久化/迁移的属性 start --------------------------
	tmps 		 = nil,
	
	-- aoi 相关字段 (在创建AOI对象(AoiObject:new)时赋值)
	aoi_id 		 = 0,
	aoi_type     = 0,
	aoi_obj		 = nil,
	space_id     = 0,
	scene_id     = 0,
	
	-- 需要在场景切换的时候进行迁移(特别注意，里面不能存放引用的值)
	tmps_ex		 = nil,
	gold		 = 0,		-- 元宝(并不隶属于character表)(程序中不能直接引用这个字段去使用，而是要调用CharacterService:getGold()方法去用)
	gold_state   = 1,		-- 0 : 未对账，1 : 已对账
	pay_gold_total = 0,		-- 历史充值魔石总数
	product_id   = 0,		-- 产品Id
	area_id		 = 0,		-- 所属大区id
	gcid         = 0,		-- type:ulong
	gpid         = 0,		-- type:ulong

	now_state    = 0,		-- type:int	仅仅用于客户端，服务端是存于tmps内
	now_state_expire = 0,	-- type:long 仅仅用于客户端，服务端是存于tmps内

	-- 跨服额外增加字段(只有跨服服务器才可以用)
	game_type_id = 0,		-- 参加的游戏类型id
	child_game_type_id = 0, -- 参加的游戏类型的子类型id
	area_name = '',			-- 所属服务器名字
	------------------- 所有不需要持久化/迁移的属性 end --------------------------
	
	------------------------ 数据表结构字段 start -----------------------
	id = 0,					-- 角色ID
	player_id	 = 0,		-- 玩家ID, type:long
	unique_key   = '',		-- 全局唯一id
	account		 = '',		-- 玩家帐号信息
	channel_id   = 0,		-- 渠道id
	nick 		 = '',		-- 昵称
	gender 		 = 0,		-- 性别
	valid		 = 1,		-- 角色是否有效(有效1，删除0)
	
	prof         = 0,		-- 职业
	level 		 = 0,		-- 等级
	exp 		 = 0,		-- 经验值
	upgrade_exp  = 0,		-- 升级到下一级需要的经验值
	vip			 = 0,		-- vip等级
	gm_level	 = 0,		-- GM等级 (大于0为GM)
	scene_id	 = 0,		-- 当前所在场景id
	x			 = 0,		-- 当前所在场景的x坐标
	y			 = 0,		-- 当前所在场景的y坐标
	direction	 = 0,		-- 方向

	pre_login_time = '',	-- 上次登录时间
	now_login_time = '',	-- 本次登录时间
	now_login_ip = '',		-- 本次登录的ip
	logout_time  = '',		-- 上一次离线时间
	ban_type	 = 0,		-- 是否被封停(0 : 正常，1 : 封停，2:禁言)
	ban_expire   = '',		-- 封停的过期时间
	created 	 = '',		-- 创建时间
	
	picture 	 = 0,		-- 头像
	res_id       = 0,		-- 角色外形部件(发型，肤色.....)
	body_size	 = 0,		-- 角色尺寸(坐骑可以修改该值) type:float
	model_times	 = 1,		-- 角色身体大小的基数(默认1)
	model_times_expire = 0, -- 当角色身体大小的基数不等于1的时候的过期时间 type:long
	
	browser_id	 = 1,		-- 创建角色时候的客户端id(浏览器/微端等/见defs/CharacterDefs.lua)
	now_login_browser_id = 0,
	
	game_gold	 = 0,		-- 游戏中的魔石，其实就是元宝(游戏赠送给玩家的魔石，非平台充值的)
	silver		 = 0,		-- 银两
	vit			 = 0,		-- 体力
	endurance    = 0,		-- 耐力
	cost_date	 = 0,		-- 消耗体力耐力的日期
	cost_vit     = 0,		-- 消耗的体力
	cost_endurance = 0,		-- 消耗的耐力
	gang_id		 = 0,	    -- 军团id
	contribute   = 0,       -- 军功
	rob_mianzhan_expire = 0,-- 幻兽宝物碎片抢夺免战过期时间(单位:秒 时间戳)
	shouhun = 0,                        --兽魂数量
	need_sync = 0,                      --是否需要将角色列表同步到中心服
	honour = 0,				--荣誉
	top_arena_rank = 0,		-- 竞技场历史最高排名
	invite_score = 0,		-- 推广积分
	kill_player_num = 0,	-- 在野外的杀人数(野外杀戮模式下击杀人数)
	kill_player_ltime = 0,	-- 最后一次杀人时间(野外杀戮模式下击杀人)
	
	speed = 0,				--type:float
	base_speed = 0,			--type:float
	lover_cid  = 0,	  		--情侣帐号id  type:ulong
	lover_nick = '',		--情侣昵称, 非数据库字段
	tollgate_star_total = 0,--关卡总星数, 非数据库字段
	
	---------------------- 战斗属性 start --------------------
	-- 基础属性
	hp			 = 0,			-- 当前hp值 type:long
	max_hp 		 = 0,			-- 最大HP值	type:long
	base_max_hp  = 0,			-- 基础最大HP值 type:long

	hp2			 = 0,			-- 合体幻兽内 type:long
	max_hp2		 = 0,			-- 合体幻兽内maxp_hp type:long

	hp3			 = 0,			-- 合体幻兽外 type:long
	max_hp3		 = 0,			-- 合体幻兽外maxp_hp type:long
	
	min_attack = 0,				-- 最小攻击
	base_min_attack = 0,		-- 基础最小攻击
	max_attack = 0,				-- 最大攻击
	base_max_attack = 0,		-- 基础最大攻击

	defence_phy = 0,			-- 物理防御
	base_defence_phy = 0,		-- 基础物理防御
	defence_magic = 0,			-- 魔法防御
	base_defence_magic = 0,		-- 基础魔法防御
	
	douzhi = 0,					-- 斗志
	base_douzhi = 0,			-- 基础斗志
	dodge = 0,					-- 闪避
	base_dodge = 0,				-- 基础闪避
	critical_hit = 0,			-- 暴击
	base_critical_hit = 0,		-- 基础暴击
	parry = 0,					-- 格挡
	base_parry = 0,				-- 基础格挡
	luck = 0,					-- 幸运
	base_luck = 0,				-- 基础幸运
	
	-- 高级属性
	addi_harm = 0,				-- 加伤绝对值(加伤)
	addi_harm_perc = 0,			-- 加伤百分比(附伤)
	reduce_harm = 0,			-- 减伤绝对值(减伤)
	reduce_harm_perc = 0,		-- 减伤百分比(免伤)
	kill_force = 0,				-- 斩杀力
	
	fight_capacity = 0,			-- 战力
	top_fight_capacity = 0, 	-- 历史最高战力	
	---------------------- 战斗属性 end --------------------
	
	scenes		 	= nil,	-- 场景信息
	tollgates	 	= nil,	-- 关卡数据
	skills			= nil,	-- 技能
	ch_equips		= nil,	-- 角色装备
	items			= nil,	-- 装备栏
	item_strongs_info= nil,	-- 装备栏部位强化信息
	items_special	= nil,	-- 特殊装备栏(无法穿戴、卸载)
	packages		= nil,	-- 包裹
	horses			= nil,	-- 坐骑
	pets			= nil,	-- 幻兽
	tasks			= nil,	-- 任务
--	taskmodels 		= nil,	-- 任务模板
	rewards			= nil,	-- 通用奖励
	pets_equip 		= nil,	-- 幻兽装备
	targets			= nil,	-- 目标系统
	achieves 		= nil,	-- 成就系统
	login_rewards 	= nil,	-- 登陆与在线奖励
	wing			= nil,	-- 翅膀
	titles 			= nil,	-- 称号
	safe_mode_info  = nil,	-- 安全模式、红名相关
	guides			= nil,	-- 新手引导
	func_opens		= nil,	-- 功能开关
	goddess_fc 		= 0,	-- 女神系统战力
	sb_skill_level = 0,		--神兵技能等级

--	tmp_ch_attrib   = '',	-- 临时角色属性(计算战力前后属性对比，检查战力下降用)

	global_pk		= nil,	-- 跨服pk玩法相关
	zhaohui 		= nil,  -- 玩法奖找回
	spirit 			= nil,	-- 精灵阵法
	undercroft 		= nil,	-- 地下城堡
	------------------------ 数据表结构字段 start -----------------------
}
Character.__index = Character

local pairs = pairs
local Statics = Statics

-- new 新角色对象
-- c_obj : c对象
local AOI_OBJECT_TYPE_ID_PLAYER = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local DEFAULT_ZHENYING_PLAYER = Statics.DEFAULT_ZHENYING_PLAYER
local setmetatable = setmetatable
function Character:new(c_obj)
	local o = {}
	setmetatable(o, self)

	-- 存放c对象
	o.c_obj = c_obj
	o.aoi_type = AOI_OBJECT_TYPE_ID_PLAYER
	
	-- 初始化临时数据
	o.tmps, o.tmps_ex = self:createTmps()

	return o
end


-- 创建角色临时数据
local SceneGameObject = SceneGameObject
local init_dtate = Statics.GAME_OBJECT_STATUS_ID_IDLE
function Character:createTmps()
	-- 初始化tmps
	local tmps =
	{
		init = nil,					-- 是否成功初始化

		----------------- aoi对象公有属性 start --------------------
		now_state = 0,				-- 当前状态
		now_state_expire = 0,		-- nil，代表永不过期

		sys_protect_expire = 0,		-- 系统保护状态过期时间(进入场景)	type:long
		relive_protect_expire = 0,	-- 死亡保护状态过期时间	type:long

		appear_ver = 0,						-- 外观版本号
		appear_bin = createFastPacket(nil),	-- 缓存的外观packet对象
		appear_bin_ver = nil,				-- 缓存的外观版本
		
		is_pause = false,
		motion_state = false,		-- 移动信息

		normal_relive_expire = 0,	-- 普通复活过期时间(被杀，普通复活有*秒的倒计时)
		is_refuse_mabi = 0,			-- 本次攻击是否有免疫麻痹
		refuse_mabi_expire = 0,		-- 免疫麻痹过期时间(冥国圣女)
		is_refuse_yuanxuan = 0,		-- 本次攻击是否有免疫晕眩
		refuse_yunxuan_expire = 0,  -- 免疫晕眩过期时间(战士冲锋)

		fight_number_id = 0,		-- 战斗计算id
		fight_expire = 0,			-- 攻击状态的过期时间(有的是瞬时战斗，而引导技能有持续时间)
		lock_expire = 0,			-- 锁定的过期时间(有些锁定技能在播放期间不允许被其他人攻击)
		self_skill_expires = {},	-- 所有私有技能cd过期时间
		play_skill_expire = 0,		-- 允许触发下一个技能的时间
		fight_info = {},			-- 每次战斗攻击的临时信息(add by suwin)
		targeter_fight_info = {},	-- 被攻击者临时战斗信息(add by suwin)
		fight_buffers = nil,		-- 战斗BUFFER

		in_server_fight = 0,		-- 是否在由服务器触发的战斗状态中
		arr_server_fight_skill = {},-- 服务器触发的战斗技能信息
		child_beast = {				-- 召唤物信息
				move_aoi_id = 0,	-- 能移动的召唤物的aoi_id
			not_move_aoi_id = 0,	-- 不能移动的召唤物的aoi_id
		},
		my_trap_aoi_id = 0,			-- 我当前召唤的陷阱的aoi_id
		pet_tianfu = {},			-- 幻兽天赋能力加成
		

		zhenying = DEFAULT_ZHENYING_PLAYER,	-- 默认阵营
		----------------- aoi对象公有属性 end ----------------------		

		entering_scene_stime = nil,	-- 正在进入场景的开始时间(进入场景完成会重置为nil)
		moving_scene_stime = nil,	-- 正在切换场景的开始时间(调用SceneCtrl:enterScene时会重置为nil)
		frame_buffers_up_ltime = nil,	-- 帧触发的BUFFER 最后更新时间 frame_buffers_up_ltime[buffer_id]=last_update_time
		request_robot_timestamp = nil,	--上次请求机器人的时间（防止有客户端频繁请求，导致数据库无响应）
		tianfus_triggered_times = nil,	-- 天赋已触发的次数(目前仅仅kill_add_hp_perc类型的天赋才会记次数)
	}

	-- 初始化tmps_ex (特别注意，里面不能存放引用的值)
	local tmps_ex = 
	{
		dirty_keys = {},				-- 需要持久化的字段
		dirty_keys_next_save_time = 0,
		next_hp_resotre_second = 0,		-- 下一次回血时间(秒)

		gold_state = 1,					-- 0 : 未对账，1 : 已对账
		
		vit_restore_ltime = nil,	-- 体力最后一次定时回复时间
		endurance_restore_ltime = nil,	-- 耐力最后一次定时回复时间

		last_leave_djj_pk = 0,	--离开帝国争锋的时间
		last_leave_fw_pk = 0,    --离开末日之战的时间

		lover_fight_radix = 0, -- 情侣pve伤害加成
	}

	return tmps, tmps_ex
end


-- 初始化角色对象
-- db_character : 从db取出的角色对象数据
local Time = Time
function Character:init(db_character)
	for k, v in pairs(db_character) do
		self[k] = v
	end
	
	-- 默认没有保护状态
	self.protect_expire = 0
	
	-- 死亡状态
	if self.hp <= 0 then
		self.tmps.now_state = Statics.GAME_OBJECT_STATUS_ID_PRE_DEAD
		self.tmps.now_state_expire = Time.time_now + 10000
	end
	
	self.tmps.init = true
end

