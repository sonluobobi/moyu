local setmetatable = setmetatable

-- aoi对象
AoiObject =
{
	c_obj = nil,				-- 对应的 c++ aoi object(在调用AoiScene:addObj时赋值)
	
	obj_id = 0,					-- aoi id (自增)
	rang_id = 0,				-- (LUA仅负责生成和回收rang_id，其他地方不会使用，在创建AOI对象的时候传入给C++)是自己在其他人视野中的缓存数组的 下标(其实由C++底层管理更好)
	obj_type = 0,				-- 类型见 AoiObjectType
	
	gpid = 0,					-- 玩家 64位player id
	
	space_id = 0,           	-- 所属场景实例ID
	x = 0,						-- x坐标
	y = 0,						-- y坐标
	direction = 0,				-- 方向
	speed = 0,					-- 速度
	
	see_player_num = 0,			--视野内玩家数量(目前进陷阱、怪物会对该字段赋值)
	is_deleted = false,			-- 标志该AOI对象已从场景里面删除
	
	wanfa_aoiobj_data = nil,	-- 玩法通用数据 type:WanfaAoiObjData 注：不能存一些实时性要求很高的数据，如果红名状态需存入到AOI APPEAR DATA里面去
}
AoiObject.__index = AoiObject

WanfaAoiObjData = {
	aoi_id = 0,		--AOI id
	zhenying = 0,	--阵营ID
	score = 0,		--积分
	kill_num = 0,	--击杀数量
	redname_status = 0,	--红名状态
	safe_mode = 0,	--安全模式
	star_num = 0,	--星星数

	-- 以下为丧尸危机中使用
	virus_speed = 0,	--病毒感染速度			//type:float
	virus_value = 0,	--当前病毒感染值		//type:float
	virus_tm = 0,		--当前病毒感染值的时间	
	shengcun_prof = 0,	--丧尸危机的职业	
	is_zombie = true,	--是否丧尸
	group_id = 0,		--所在分组ID（同原始阵营ID）
	-- end

	-- 以下为爱情圣殿中使用
	caiji_end_time = 0,
	wabao_end_time = 0,
	-- end	
}

local Time = Time
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local aoi_type_pet = AoiObjectType.AOI_OBJECT_TYPE_ID_PET
local aoi_type_robot = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER

function AoiObject:new(obj_type, x, y, direction, game_obj, aoi_scene)
	local o = {}
	setmetatable(o,self)
	
	local gcid,pet_id	
	local is_player = obj_type == aoi_type_player	
	
	local obj_id,rang_id = aoi_scene:nextObjId()	
	
	o.obj_id = obj_id
	o.rang_id = rang_id
	o.obj_type = obj_type
	
	o.space_id = aoi_scene.space_id
	o.x = x
	o.y = y
	o.direction = direction
	o.speed = game_obj.speed
	
	-- 游戏对象的AOI相关属性赋值
	game_obj.aoi_obj = o
	game_obj.aoi_id = obj_id
	game_obj.aoi_type = obj_type
	game_obj.space_id = aoi_scene.space_id
	game_obj.scene_id = aoi_scene.scene_id
	game_obj.x = x
	game_obj.y = y
	
	o.gpid = is_player and game_obj.gpid or false
	
	o.created = Time.time_now
	o.see_player_num = 0
	o.is_deleted = false
	
	return o
end

--地图阻挡文件
AoiSceneData = 
{
	res_id = 0,
	width = 0,
	height = 0,
	cells = nil,
}
function AoiSceneData:new(res_id,width,height,cells)	
	local o = {}
	o.res_id = res_id
	o.width = width
	o.height = height
	o.cells = cells
	return o	
end


-- aoi 场景
AoiScene = 
{
	next_obj_id = 0,		--下一个AOI OBJ 实例ID
	next_rang_ids = nil,	--回收那些已经被删除的下标ID
	next_rang_id = 0,		--下一个下标ID(自己在其他人视野中的缓存数组的下标)
	
	space_id = 0,		--场景实例ID
	scene_base = nil,	--原始场景
	scene_data = nil,	--阻挡信息
	cells = nil,		--地图格子信息
	width = 0,			--地图宽度
	height = 0,			--地图长度
	res_id = 0,			--资源id
	scene_id = 0,		--原始场景id
	objs = nil,			--AOI对象列表
	aoi_id2game_objs = nil,	--游戏对象列表
	aoi_type2game_objs = nil,--类型对应游戏对象列表
	is_deleted = false,	--已从场景删除标志
	is_pause = false,	--场景已暂停标志(如果已暂停，场景不会再触发update事件)
	is_dirty = nil,		--是否脏标志(如果非脏，场景不会触发update事件)
	created = 0,		--创建时间戳 （秒）
	
	updated_frame = 0,		--帧序号
	player_num = 0,			--玩家数量
	monster_num = 0,		--怪物数量
	
	powers2aoi_ids = nil,	--阵营对应的AOI ID 列表(用于战斗攻击目标拾取，由个玩法系统去赋值维护)
	
	is_need_fight_update = nil,	--是否需要战斗每帧UPDATE更新
	is_need_buffer_update = nil,--是否需要BUFFER 每帧更新
	
	updateFov = nil,		--优化:更新视野函数 (调用频繁，不读元表)
	
	scenario_timers = nil,			--剧情系统的定时器列表
	scenario_noend_timer_ids = nil,	--剧情系统未结束定时器ID列表
	scenario_finished_phases = nil,	--已完成的波数列表	scenario_finished_phases[phase_id] = 1
	scenario_state_qe = nil,		--剧情状态队列	scenario_state_qe[idx] = state
	scenario_time_qe = nil,			--剧情状态开始时间队列 	scenario_time_qe[idx] = state_start_time
	scenario_done_phases = nil,		--[[剧情已触发过的波数 scenario_done_phases[phase_id] = {
										phase_id=xx,
										phase_type_id=xx,
										called_scene_aoi_infos={[scene_aoi_id]=aoi_id,...},
										total_num=xx,
									}
									--]]
	subline = nil,					-- 副本相关数据
	
	small_map_items = nil,			-- 小地图ITEM列表
	small_map_sort2items = nil,		-- 小地图ITEM列表
	small_map_items_bc_ltimes = nil,-- 各类型的ITEM信息广播时间 items_bc_ltimes[sort_id] = bc_time
	scene_enemy = nil,				-- 场景仇敌
	first_enter_teamid = 0,			-- 第一个进入该场景的队伍(部分玩法用到)
}
AoiScene.__index = AoiScene

local ostime = os.time
local AoiObjectType = AoiObjectType
function AoiScene:new(space_id,scene_base,scene_data)

	local o = {}
	setmetatable(o,self)
	
	o.next_obj_id = 100
	o.next_rang_id = 1
	o.next_rang_ids = false
	
	o.space_id = space_id
	o.scene_base = scene_base
	o.scene_data = scene_data
	o.width = scene_data.width
	o.height = scene_data.height
	o.cells = scene_data.cells
	o.res_id = scene_data.res_id
	o.scene_id = scene_base.id
	o.objs = {}
	o.aoi_id2game_objs = {}
	local aoi_type2game_objs = {}
	for _, aoi_type in pairs(AoiObjectType) do
		aoi_type2game_objs[aoi_type] = {}
	end
	o.aoi_type2game_objs = aoi_type2game_objs
	
	o.is_deleted = false
	o.is_pause = false
	o.is_dirty = false
	o.created = ostime()
	
	o.updated_frame = 0
	o.player_num = 0
	o.monster_num = 0
	
	-- 优化:
	o.updateFov = self.updateFov	--更新视野函数 (调用频繁，不读元表)
	
	o.small_map_items = {}
	o.small_map_sort2items = {}
	o.first_enter_teamid = 0
	
	return o
end
