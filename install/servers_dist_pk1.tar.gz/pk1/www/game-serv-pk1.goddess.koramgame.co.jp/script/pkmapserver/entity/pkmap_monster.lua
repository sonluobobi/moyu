--[[
怪物实体
author : suwin zhong
date : 2015-04-24
--]]

local tableInsert = table.insert
local sizeTable = table.sizeTable

local suwin = 1

Monster = {

	-------- 实例化后增加属性 start --------
	id = 0,			-- id(冗余，保持sceneGameObj统一性)
	aoi_type = 0,	-- 在aoi中定义的类型(冗余，保持sceneGameObj统一性)
	aoi_id	= 0,	-- 怪物在一个场景里的唯一id(进入场景时力志那边会替该值进行赋值)
	aoi_obj = nil,	-- 
	hp = 0,			-- 当前hp值
	max_hp = 0,		-- 最大血
	x = 0,			-- 当前所在x坐标
	y = 0,			-- 当前所在y坐标
	direction = 0,	-- 方向
	speed = 0,		-- 速度(冗余，保持sceneGameObj统一性)
	nick = '',		-- 名字
	scene_id = 0,	-- 当前所在场景ID
	space_id = 0,	-- 当前所在场景实列ID

	model_times = 1, -- 放大倍数 //type:float
	body_size = 0,	 -- 身体大小

	-- 所有不需要持久化/迁移的属性存放在这里面
	tmps 		= nil,
	-------- 实例化后增加属性 end ----------

	-- 存储monster.csv中的结构
	monster_base = nil,

	-- 存储SceneAoi.csv中的结构
	monster_aoi = nil,

	-- 怪物ai
	monster_ai = nil,

	-- 新的属性(一个怪物根据不同等级而有不同的属性值)(特殊玩法才用得到(木人巷))
	monster_base_new = nil,
}

local DEFAULT_ZHENYING_MONSTER = Statics.DEFAULT_ZHENYING_MONSTER

-- new 新怪物对象
-- monster_base : 怪物原始对象
-- monster_aoi : 怪物aoi属性对象
function Monster:new(monster_base, monster_aoi)
	local o = {}
	setmetatable(o, self)
	self.__index = self

	-- 填充monster_base结构
	o.monster_base = monster_base

	-- 填充scene_aoi结构
	o.monster_aoi = monster_aoi

	-- 补充实例化属性
	o.id = monster_aoi.id
	o.aoi_type = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
	o.hp = monster_base.max_hp
	o.max_hp = monster_base.max_hp
	o.x  = monster_aoi.x
	o.y  = monster_aoi.y
	o.direction = monster_aoi.direction
	o.speed = monster_base.speed
	o.nick = monster_base.nick
	o.model_times = monster_base.model_times or 1
	o.body_size = monster_base.body_size or 0

	-- 初始化tmps
	local aoi_obj_status_id_idle = Statics.AOI_OBJECT_STATUS_ID_IDLE
	o.tmps = {
		powers_id = monster_base.powers_id or 0,-- 怪物所属势力id

		target_aoi_id = 0,						-- 攻击/追踪的目标aoi_id
		born_target_aoi_id = 0,					-- 出生就要打的目标的aoi_id(主要用于攻击守护者NPC的怪物身上)
		find_time = 0,							-- 下一次寻找目标的触发时间

		pre_state = aoi_obj_status_id_idle,		-- 怪物上一个状态索引
		now_state = aoi_obj_status_id_idle,		-- 怪物的当前状态索引(空闲/死亡等)，初始化时是空闲状态

		action_expire = 0,   					-- 某个动作的播放过期时间(例如技能攻击，客户端需要播放一段时间)

		fight_time = 0,							-- 允许攻击的时间点

		delete_time = 0,						-- 死亡后(通知客户端)删除尸体的时间
		relive_time = 0,						-- 死亡后复活时间点
		my_relive_nums = 0,						-- 已复活次数

		move_type_id = 0,						-- 移动类型(走动/跑动)
		active_x = monster_aoi.x,				-- 主动怪发现追踪目标时候的x位置
		active_y = monster_aoi.y,				-- 主动怪发现追踪目标时候的y位置

		allow_move_time = 0,					-- 允许走移动流程的时间点(怪物出生的时候，会有出生特效，需要等特效播放完才能移动)
		random_move_time = 0,					-- 随机移动时间点

		loop_move_time = 0,						-- 循环移动时间点
		loop_move_index = 1,					-- 循环移动的索引

		is_stop_move = 0,						-- 是否停止移动

		see_me_num = 0,							-- 怪物在多少玩家视野里

		zhenying = DEFAULT_ZHENYING_MONSTER,	-- 默认阵营

		add_hp = 0,								-- 记录一次技能攻击对hp的影响值
		add_hp2 = 0,							-- 针对连击情况，连击第二次攻击对hp的影响值
		add_hp3 = 0,							-- 针对有3次攻击的情况
		add_mp = 0,								-- 记录一次技能攻击对mp的影响值
		
		arr_buffer_targeter = nil,				-- 记录一次技能攻击，有被中buffer的对象列表

		drop_items = nil,						-- 怪物掉落物
		fight_buffers = nil,					-- 战斗期间临时buffer

		reward_own_cid = 0,						-- 酒坛所属角色id
		reward_own_nick = '',					-- 酒坛所属角色名字

		fight_number_id = 0,		-- 战斗计算id
		fight_expire = 0,			-- 攻击状态的过期时间(有的是瞬时战斗，而引导技能有持续时间)
		lock_expire = 0,			-- 锁定的过期时间(有些锁定技能在播放期间不允许被其他人攻击)
		self_skill_expires = {},	-- 所有私有技能cd过期时间
		play_skill_expire = 0,		-- 允许触发下一个技能的时间
		fight_info = {},			-- 每次战斗攻击的临时信息(add by suwin)
		targeter_fight_info = {},	-- 被攻击者临时战斗信息(add by suwin)
		pet_tianfu = {},			-- 幻兽天赋能力加成
		fight_buffers = nil,		-- 战斗BUFFER

		hate_lists = nil,						-- 仇恨列表
		tmp_hate = nil,							-- 临时仇恨信息

		check_range_time = 0,					-- 检查范围的时间(无主之地boss，检查玩家是否有在范围内)

		-- buffer相关
		buff_hp_lost_attack_perc_time = 0,		-- 下一次流失hp的时间(按攻击力百分比)
		buff_hp_lost_time = 0,					-- 下一次流失hp的时间(固定值)
		buff_hp_lost_lev_rel_time = 0,	 		-- 下一次流失hp的时间(按陷阱等级计算)

		-- 要发生的ai信息(用于返回给客户端，区分怪物状态的)
		ai_can_play_expire = 0,					-- (秒)可以开始判断ai条件的过期时间(怪物出生多久后才可以走AI判断 / 怪物触发一次AI之后，进入公共cd判断)
		ai_now_monster_ai = 0,					-- 要发生的ai
		ai_prepare_expire = 0,					-- 准备的到期时间
		ai_playing_time = 0,					-- 下一次ai的播放时间
		ai_playing_expire = 0,					-- ai播放的总过期时间

		ai_targeter_aoi_id = 0,					-- 本次ai要攻击的对象的aoi_id(针对单攻类)
		ai_targeter_pos_x = 0,					-- 本次ai要攻击的位置x坐标
		ai_targeter_pos_y = 0,					-- 本次ai要攻击的位置y坐标
		
		-- 技能ai相关参数
		ai_datas = {},							-- 该怪物身上拥有的ai的信息，格式 : {{time_ai1 = 0, nums_ai1 = 0}, {time_ai2 = 0, nums_ai2 = 0}, ...}

		-- 技能ai其他参数值
		ai_kill_monster_num = 0,				-- 杀死某些怪物，然后根据杀死的数量，变化自己的buffer

		ai_child_monster_aoi_id = {},			-- 召唤出来的子怪物的aoi_id

		-- 击杀者
		killer_nick = '',						-- 击杀者的名字
		outdoor_boss_tmp_hate = nil,			-- 临危野外中心BOSS的仇恨值
		outdoor_boss_craete_time = nil,			-- 临危野外中心BOSS的创建时间		
	}

	-- 可移动时间
	local move_delay_msec = o.monster_base.move_delay_msec or 1000
	o.tmps.allow_move_time = Time:getSecondsNow() + (move_delay_msec / 1000)

	--------------------- 填充怪物ai start -------------------------
	local arr_ids = monster_base.ai_ids
	-- if Config:isSuwinServer() then
	--	if o.monster_base.id == 2001001 then
	--		ai_ids = '9002'
	--	end
	-- end
	if arr_ids and (0 < sizeTable(arr_ids)) then
		-- local
		local MonsterSkillAiDao_data = MonsterSkillAiDao.data
		
		-- 替怪物加上触发ai判断时间
		local ai_delay_msec = o.monster_base.ai_delay_msec or 10000
		o.tmps.ai_can_play_expire = Time:getSecondsNow() + (ai_delay_msec / 1000)

		-- value
		-- local arr_ids = UString.splitString(ai_ids, ',', true)

		local ai, my_ai
		for _, ai_id in pairs(arr_ids) do
			ai = MonsterSkillAiDao_data[ai_id]
			if ai then
				my_ai = o.monster_ai
				if not my_ai then 
					o.monster_ai = {}
					my_ai = o.monster_ai
				end
				tableInsert(my_ai, ai)

				-- 初始化该ai的参数
				local time_ai_key = 'time_' .. ai_id
				local nums_ai_key = 'nums_' .. ai_id
				o.tmps.ai_datas[time_ai_key] = 0
				o.tmps.ai_datas[nums_ai_key] = 0
			end
		end

		--if Config:isSuwinServer() then
		--	if 1 == suwin then
		--		table.dump(o, -1)
		--		suwin = suwin + 1
		--	end
		--end
	end
	--------------------- 填充怪物ai end ---------------------------

	return o
end