--[[
怪物技能AI
author : suwin zhong
date : 2015-04-24
--]]

MonsterSkillAi = {
	id = 0,						 -- ai id
	
	trigger_id = 0,				 -- 触发类型id
	trigger_params = {},		 -- 触发条件参数	type:Hashtable
	trigger_percent = 0,		 -- 触发的成功概率		type:float
	trigger_interval = 0,		 -- 触发间隔时间(秒)	type:float
	trigger_num = 0,			 -- 触发次数上限
	trigger_text = '',			 -- 触发时候怪物要说的文字

	prepare_msec = 0,			 -- 蓄力时间(毫秒)
	prepare_anim = '',			 -- 蓄力动作
	prepare_partice = '',		 -- 蓄力特效
	prepare_partice_height = 0,  -- 蓄力特效挂载高度(客户端用)		type:float
	prepare_target_pos = 0,		 -- 是否在蓄力的时候就记录攻击位置，还是随玩家移动而继续攻击玩家(0 : 实时根据玩家位置; 1 : 记录蓄力时候的位置; 2 : 以自己的位置来攻击)
	prepare_partice_target = '', -- 准备位置的特效id(客户端用)

	need_shunyi = 0,			 -- 蓄力结束之后是否需要瞬移到目标点(1 : 需要瞬移; 0 : 不需要瞬移)
	
	play_skill_msec = 0,		 -- 播放攻击时间(毫秒)
								 -- = (play_skill_times * play_skill_interval) + 一点延迟
	play_skill_id = 0,			 -- 攻击时候的技能id
	play_skill_times = 0,		 -- 技能使用的次数
	play_skill_interval = 0,	 -- 每次技能的间隔	type:float
	
	play_cool_msec = 0,		     -- 技能使用后需要冷却的时间(毫秒)(播放这个技能之后，需要多久才换成普通攻击/追踪玩家)
								 -- play_cool_msec = 蓄力时间 + 技能播放后需要等待的时间
	ai_cool_msec = 0,			 -- (AI公共cd)触发下一次ai需要间隔的时间(毫秒)

	machine_param = '',			 -- 客户端用的其他参数
	sound_id = 0,				 -- 使用ai时候的声音id
}
