--[[
ITEM 对象
author : xingzeng
date : 2015-05-06
]]--

ItemObj = {
	id = 0,
	sort_id = 0,				-- 物品类型, ItemDefs.ITEM_SORT_ID_
	func_id = 0,				-- 功能类型, ItemDefs.ITEM_FUNC_ID_ 
	pickup_mode = 0,			-- 拾取模式, 某些物品是无法被拾取的. ItemDefs.ITEM_PICKUP_MODE_
	own_gcids = nil,			-- 可拾取该物品的角色id数组
	life_expire = 0,			-- 过期时间, 毫秒, 如果是 nil/0 表示不过期
	create_mtime = 0,			-- 创建时间
	master_aoi_id = 0,			-- 掉落主人的AOI ID
	
	-- 内容
	item_base = nil,			-- ITEM基础数据
	item_num = 0,				-- 掉落物堆叠数
	
	-------- 实例化后增加属性 --------		
	aoi_id	= 0,	
	aoi_type = 0,	
	aoi_obj = nil,	
	x = 0,			
	y = 0,		
	
	tmps = nil,--[[ tmps = {
					zhenying = 0,				-- 所属阵营
				}
				--]]
}

local type = type

--- 新建一个对象
--		不自动添加到场景
function ItemObj:new(sort_id, func_id, pickup_mode, own_gcids, life_expire, item_base, item_num, master_aoi_id)
	local itemobj = {}
	
	-- 基本信息
	itemobj.id = item_base and item_base.id or 0
	itemobj.sort_id = sort_id
	itemobj.func_id = func_id
	itemobj.pickup_mode = pickup_mode
	itemobj.own_gcids = type(own_gcids) == 'number' and {own_gcids} or own_gcids
	itemobj.life_expire = life_expire
	itemobj.master_aoi_id = master_aoi_id
	
	-- 内容
	itemobj.item_base = item_base
	itemobj.item_num = item_num or 1
	
	itemobj.tmps = {zhenying = item_base and item_base.zhenying or 0}
	
	return itemobj
end
