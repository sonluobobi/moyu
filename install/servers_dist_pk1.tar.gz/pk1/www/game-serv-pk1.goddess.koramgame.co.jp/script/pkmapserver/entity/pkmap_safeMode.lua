--[[
安全模式、红名相关信息
author : xingzeng.jiang
date : 2012-03-01
--]]

SafeModeInfo = {
	redname = 0,			-- 红名
	safe_mode = 0,			-- 安全模式
	safe_mode_cool = 0,		-- 安全模式切换冷却时间
	is_rn_dead = 0,			-- 是否红名死亡(0:没有， 1:有)
}

SafeModeInfo.__index = SafeModeInfo

function SafeModeInfo:new()
	local o = {}
	setmetatable(o, self)
		
	return o
end