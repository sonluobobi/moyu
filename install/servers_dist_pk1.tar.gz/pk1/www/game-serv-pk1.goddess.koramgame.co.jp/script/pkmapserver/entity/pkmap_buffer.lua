--[[
buffer数据结构
author : xingzeng
date : 2014-08-25
--]]

Buffers = {
	bufobjs = nil,
	
	-- tmps.fight_buffers 中缓存字段
	_is_dirty = nil,			--缓存是否已经脏
	_perframework_buffers = nil,	--每帧都工作的BUFFER列表(eg: {[508]=buffer)
}
function Buffers:new()
	local o = {}
	o.bufobjs = {}
	return o
end

--buffer实例
Buffer = 
{
	id = 0,						--BUFFER ID (目前等于buffer基础ID)
	__buffer_base		= nil,	-- 基础buffer
	
	effect_type		= '',		-- 效果类型  定义见 EffectType
	effect_value	= 0,		-- 效果值1
	effect_value2	= 0,		-- 效果值2
	
	expire_time = 0,     		--BUFFER的过期时间(unix时间戳 毫秒级)
	__add_time = 0,				--BUFFER的获得时间(unix时间戳 毫秒级)
}

