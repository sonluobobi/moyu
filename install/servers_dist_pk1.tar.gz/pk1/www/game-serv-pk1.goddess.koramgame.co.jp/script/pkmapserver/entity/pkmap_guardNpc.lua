--[[
	守护NPC实体(守护任务里，怪物会攻击这种NPC)
--]]

GuardNpc = 
{
	-- 存储GuardNpc.csv中的结构
	guard_npc_base = nil,

	-------- 实例化后增加属性 --------
	aoi_id = 0,		-- id(aoi_obj.obj_id)
	aoi_type = 0,	-- AoiObjectType.AOI_OBJECT_TYPE_ID_BEAST
	aoi_obj = nil,
	x = 0,
	y = 0,
	scene_id = 0,	-- 当前所在场景ID
	space_id = 0,	-- 当前所在场景实列ID

	nick = '',
	speed = 0,		-- 速度

	model_times = 1, -- 模型倍数, type:float
	body_size = 0,	 -- 身型长度, type:float

	---------------- 战斗相关属性 start ------------------
	hp			 = 0,			-- 当前hp值	type:long
	max_hp 		 = 0,			-- 最大HP值	type:long
	---------------- 战斗相关属性 end --------------------

	tmps = nil,			-- 临时数据()
}


function GuardNpc:createTmps(my_zhenying)
	-- 初始化tmps
	local tmps =
	{
		now_state = 0,				-- 当前状态
		now_state_expire = 0,		-- nil，代表永不过期

		motion_state = false,

		fight_number_id = 0,		-- 战斗计算id
		fight_info = {},			-- 每次战斗攻击的临时信息(add by suwin)
		pet_tianfu = {},			-- 幻兽天赋能力加成
		targeter_fight_info = {},	-- 被攻击者临时战斗信息(add by suwin)

		delete_time = 0,			-- 死亡后(通知客户端)删除尸体的时间

		zhenying = my_zhenying,		-- 阵营
	}

	return tmps
end