--[[
场景BUFFER
author : xingzeng jiang
date : 2012-06-29
--]]

SceneBuffer = {
	gcid2ch_scene_buffers = nil,	--角色拥有的场景BUFF信息 ch_scene_buffers[cid] = scene_buffers
	ref_last_time = 0,		--最后一次刷新场景BUFF掉落物的时间
	gather_items = nil,
	gcid2comm_cd_expire = nil,
}

ChSceneBuffer = {
	id = 0,					--场景BUFFER ID
	cid = 0,				--角色ID
	gather_item_id = nil,	--场景采集物的ID
	num = 0,				--拥有的数量
	cd_expire = 0,			--CD 冷却时间	type:long
	cd_stime = 0,			--CD 冷却开始时间	type:long
	bomb_mtime = 0,			--炸弹爆炸时间(单位：毫秒)
}

function ChSceneBuffer:new(character, scene_buffer_id, own_num, gather_item_id)
	local o = {}
	o.id = scene_buffer_id
	o.cid = character.id
	o.num = own_num
	o.cd_expire = 0
	o.gather_item_id = gather_item_id
	return o
end