--[[
天魔灭心数据结构定义
author : xingzeng
date : 2012-03-27
--]]

Tianmo = {
	id = 0,					-- 天魔灭心 ID
	pass_time = 0,			-- 通关时间
	open_time = 0,			-- 天魔灭心活动开始时间
	etime = 0,				-- 天魔灭心活动结束时间
	created = 0,			-- 实列创建的时间
	is_win = false, 		-- 是否胜利
	is_rewarded = false, 	-- 是否已发奖(避免重复发奖)
	nowtop_room = {},		--当前到达最高房间信息 {scene_id, lay, team_num, first_team_id}
}

-- 天魔灭心房间实体
TianmoRoom = {
	scene_ins_id = 0,		--房间实例ID
	scene_id = 0,			--天魔灭心的场景ID
	status = 0,				--状态 1：匹配对手阶段 2： 已经匹配成功, 3: 开打中
	status_expire = 0,		--状态过期时间
	lay = 0,				--房间的层数
	win_team_id = 0,		--胜利的队伍ID
	pass_time = 0,			--通关的时间
	teams = {},				--[[房间的队伍列表 teams[team_id] = {
									id=xx,score=xx,order_by=xx,team_name=xx,gender=xx,ccid=xx
									}
							--]]
	cid2teamid = {},		--角色ID到队伍ID映射表 cid2teamid[cid] = team_id
	group_id = 0,			--所属分组ID
	is_kickout = false,		--是否已踢出所有玩家
}

-- BOSS房间
TianmoBossRoom = {
	lay = 0,				--房间的层数
	scene_ins_id = 0,		--房间实例ID
	status = 1,				--BOSS房间状态
	status_expire = 0,		--BOSS房间状态过期时间
	teams = {},				--[[房间的队伍列表 teams[team_id] = {
									id=xx,score=xx,order_by=xx,team_name=xx,gender=xx,ccid=xx
									}
							--]]
	win_team_id = 0,		--胜利的队伍ID
	history_team_ids = {},	--历史进入队伍ID列表
	history_team_num = 0,	--历史进入队伍数量
	cid2teamid = {},		--角色ID到队伍ID映射表 cid2teamid[cid] = team_id
	killed_boss_gcid = 0,	--击杀BOSS的角色ID
	killed_boss_gpid = 0,	--击杀BOSS的帐号ID
	harm_list = {},			--各个队伍的伤害列表
	toplist = {},			--伤害排行榜
	tianshen_opened_ids = {},--已开启了的天神下凡ID列表
	ts_cur_opened_info = {},--天神下凡当前开启信息 ts_cur_opened_info={id=xx,win_team_id=xx,stime=xx,etime=xx,boss_mid=xx}
	now_enter_max_lay = 0,	--当前已达到的最大层数
	
	boss_harm_add_bc_minutes = nil,	--BOSS伤害加成 已广播的分钟数
}