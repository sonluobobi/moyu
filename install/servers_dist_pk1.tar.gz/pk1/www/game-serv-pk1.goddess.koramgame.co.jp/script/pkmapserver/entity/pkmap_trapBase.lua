
-- 陷阱基础表
TrapBase = 
{
	id = 0,						-- 陷阱基础ID
	title = '',					-- 陷阱名字
	sort_id = 0,				-- 陷阱类型(详见TrapDefs.lua)
	res_id = 0,					-- 资源id(客户端只需要资源id)
	radius = 0,					-- 半径(陷阱都是圆形)
	
	param = 0,					-- 参数

	buffer_ids = false,			-- 陷阱对应的BUFFER ID列表 type:ArrayList
	
	perpare_time = 0,			-- 准备时间(单位 : 毫秒)
	duration = 0,				-- 陷阱持续时长(单位 : 毫秒)
	interval = 0,				-- 陷阱释放效果频率(单位 : 毫秒)

	repeat_times = 0,			-- 重复次数(目前仅客户端用上)
	repeat_interval = 0,		-- 重复间隔(目前仅客户端用上)
}
TrapBase.__index = TrapBase


local table = table
function TrapBase:new(csv)
	local o = {}
	setmetatable(o, self)
	
	for key, value in pairs(csv) do
		-- 基类值为nil，代表是table类型的字段
		if not self[key] then
			if not table.isTableEmpty(value) then
				o[key] = value
			end
		else
			o[key] = value
		end
	end
	
	return o
end
