--[[
场景陷阱刷新表
author : xingzeng jiang
date : 2015-04-29
--]]

TrapRefreshBase = {
	id = 0,					--自增ID
	sort_id = 0,			--类型。 0:定时刷出场景, 2:定点刷出
	scene_id = 0,    		--场景ID
	
	drop_dots = nil,		--掉落的点列表
	
	ref_frequency = 0,		--掉落物刷新频率(秒)
	ref_per_num = 0,		--每次的刷新个数
	
	trap_ids = nil,			--刷出的陷阱ID列表 type:List __t
}
