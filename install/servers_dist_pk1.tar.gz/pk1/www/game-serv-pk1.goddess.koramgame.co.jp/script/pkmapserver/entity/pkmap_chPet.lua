--[[
角色幻兽数据实体
author : xingzeng
date : 2014-08-15
--]]

local createFastPacket = FastPacket and getmetatable(FastPacket).__call

-- 角色幻兽列表 (角色幻兽ID为KEY)
ChPetsInfo = {
	ch_pets = nil,			-- 幻兽列表	type:ArrayList
	fight_ch_pet_id = 0,	-- 当前出战的幻兽ID
	heti_ch_pet_ids = nil,	-- 当前已合体的幻兽ID列表	type:ArrayList
	ch_petid_inc_start = 0,	-- 角色幻兽ID开始增长编号
	troop_chpet_ids = nil,	-- 幻兽阵法信息
	troop_id_max = nil,		-- 已开启的最大阵法ID
	en_own_pet_num = 0,		-- 当前最多可拥有的幻兽数量
	up_autosel_set = nil,	-- 幻兽升级一键添加设置
	auto_free_conf = nil,	-- 自动献祭配置(砸蛋时)
	chaos_num = nil,		-- 训练总次数
}
ChPetsInfo.__index = ChPetsInfo

function ChPetsInfo:new()
	local o = {}
	setmetatable(o, self)
	
	o.ch_pets = {}
	o.fight_ch_pet_id = nil
	o.heti_ch_pet_ids = nil
	o.ch_petid_inc_start = 1
	o.en_own_pet_num = PetDefs.INIT_MAX_OWN_PET_NUM
	
	return o
end

----------------- 幻兽装备栏 start -------------------
ChPetItemBars = {
	size = 0,					-- 装备栏大小
	items = false,				-- 装备栏的内容数据 item[order_by] = ChItemBar	type:ArrayList
	item_strongs = false,		-- 部位强化信息 item_strongs[order_by] = ChItemStrong 	type:ArrayList
	_items_effect_values = nil, --[[缓存了强化后基础属性、宝石加成属性
								= {
									[order_by] = {douzhi=33,max_hp=332},
									...
								}
								--]]
}
function ChPetItemBars:new(size)
	local o = {}
	o.size = size
	o.items = {}
	o.item_strongs = {}
	return o
end

------------------ 幻兽装备栏 end --------------------

-- 角色幻兽数据结构定义
ChPet = {
	-------------- AOI 相关属性 不会持久化 start ----------------
	-- 在创建AOI对象(AoiObject:new)时赋值
	-- 注意：出战侠客才有下面字段
	aoi_id = 0,		--id(aoi_obj.obj_id)
	aoi_type = 0,	--Statics.AOI_OBJECT_TYPE_ID_PET
	aoi_obj = nil,
	scene_id = 0,	-- 当前所在场景ID
	space_id = 0,	-- 当前所在场景实列ID
	x = 0,
	y = 0,
	-------------- AOI 相关属性 不会持久化 end ----------------
	
	cid = 0,				-- 主人的角色ID
	gcid = 0,				-- 主人的64位角色ID
	parent_aoi_id = 0,		-- 主人AOI ID 注意：出战侠客才有该字段
	parent_gpid = 0,		-- 主人的GPID
	hp = 0,					-- 当前hp值
	body_size = 0,			-- 身体大小(冗余基础表数据)
	
	------------------  以下字段才会持久化到DB start ------------------
	id = 0,					-- 角色幻兽ID
	pet_id = 0,				-- 幻兽CLASS ID(基础幻兽ID)
	jieshu = 0,				-- 升阶的阶数
	
	level = 0,				-- 幻兽当前等级
	max_level = 0,			-- 幻兽最高等级
	star = 0,				-- 星数
	huanhua_num = 0,		-- 幻兽幻化次数(星数=次数*每次幻化增加的星数)
	exp = 0,				-- 当前的经验
	chaos_num = 0,			-- 该侠客已训练的次数
	used_xo_num = 0,		-- 幻化已使用XO总数
	eat_pet_num = 0,		-- 幻化已吞噬同ID幻兽个数
	used_hj_num = 0,		-- 已消耗的幻晶总数
	
	chaos_kill_force = 0,		--训练附加 斩杀力
	chaos_addi_harm = 0,		--训练附加 附伤
	chaos_attack = 0,			--训练附加 攻击
	chaos_luck = 0,				--训练附加 幸运
	chaos_douzhi = 0,			--训练附加 斗志
	
	-------------- 战斗 相关属性 start ----------------
	speed = 0,					--当前速度
	max_hp = 0,					--当前最大生命值
	max_attack = 0,				--当前最大攻击
	min_attack = 0,				--当前最小攻击
	defence_phy = 0,			--当前物理防御
	defence_magic = 0,			--当前魔法防御
	
	douzhi = 0,					-- 斗志
	critical_hit = 0,			-- 暴击
	dodge = 0,					-- 闪避
	parry = 0,					-- 格挡
	
	-- 高级属性
	addi_harm = 0,				-- 附伤 附加伤害绝对值
	addi_harm_perc = 0,			-- 加伤 增加百分比伤害
	reduce_harm = 0,			-- 减伤：降低伤害绝对值
	reduce_harm_perc = 0,		-- 免伤：降低百分比伤害
	kill_force = 0,				-- 斩杀力
	luck = 0,					-- 幸运
	
	fight_capacity = 0,			-- 幻兽战力
	-------------- 战斗 相关属性 end ----------------
	
	chaos_is_replace = 0,		--训练附加 洗练结果值 是否已确认
	tchaos_kill_force = 0,		--训练附加 洗练结果值 斩杀力
	tchaos_addi_harm = 0,		--训练附加 洗练结果值 附伤
	tchaos_attack = 0,			--训练附加 洗练结果值 攻击
	tchaos_luck = 0,			--训练附加 洗练结果值 幸运
	tchaos_douzhi = 0,			--训练附加 洗练结果值 斗志
	------------------  以上字段才会持久化到DB end ------------------
	
	pet_base = nil,			-- 幻兽基础属性
	client_Equals__ = "id",	-- 重载等于符号，提供客户端使用
	client_in_bar_id = -1,	-- 当前所在的装备栏ID 提供客户端使用(服务器未使用该字段)
}


do
	local init_state = Statics.GAME_OBJECT_STATUS_ID_IDLE
	local PET_INIT_LEVEL = PetDefs.PET_INIT_LEVEL
	
	function ChPet:new(character, ch_pet_id, pet_base)
		local ch_pet = {}
		ch_pet.id = ch_pet_id
		ch_pet.pet_id = pet_base.id
		
		ch_pet.level = PET_INIT_LEVEL
		--TEST
		ch_pet.max_level = pet_base.max_level or 50
		ch_pet.huanhua_num = 0
		ch_pet.star = 0
		ch_pet.exp = 0
		ch_pet.chaos_num = 0
		ch_pet.used_xo_num = 0
		ch_pet.eat_pet_num = 0
		
		ch_pet.chaos_kill_force = 0
		ch_pet.chaos_addi_harm =0
		ch_pet.chaos_attack = 0
		ch_pet.chaos_luck = 0
		ch_pet.chaos_douzhi = 0
		
		ch_pet.speed = character.speed
		
		ch_pet.max_hp = 0
		ch_pet.max_attack = 0
		ch_pet.min_attack = 0
		ch_pet.defence_phy = 0
		ch_pet.defence_magic = 0
		
		ch_pet.douzhi = 0
		ch_pet.critical_hit = 0
		ch_pet.dodge = 0
		ch_pet.parry = 0
		
		ch_pet.addi_harm = 0
		ch_pet.addi_harm_perc = 0
		ch_pet.reduce_harm = 0
		ch_pet.reduce_harm_perc = 0
		ch_pet.kill_force = 0
		ch_pet.luck = 0
		ch_pet.fight_capacity = 0
		
		ch_pet.chaos_is_replace = 1
		ch_pet.tchaos_kill_force = nil
		ch_pet.tchaos_addi_harm = nil
		ch_pet.tchaos_attack = nil
		ch_pet.tchaos_luck = nil
		ch_pet.tchaos_douzhi = nil
		
		ch_pet.cid = character.id
		ch_pet.gcid = character.gcid
		ch_pet.parent_aoi_id = character.aoi_id
		ch_pet.parent_gpid = character.gpid
		ch_pet.pet_base = pet_base
		ch_pet.hp = pet_base.init_max_hp
		ch_pet.body_size = pet_base.body_size
		
		return ch_pet
	end
	
	function ChPet:init(character, ch_pet, pet_base)
		ch_pet.cid = character.id
		ch_pet.parent_aoi_id = character.aoi_id
		ch_pet.pet_base = pet_base
		ch_pet.hp = ch_pet.max_hp > 0 and ch_pet.max_hp or pet_base.init_max_hp
		
		-- 初始化tmps
		ch_pet.tmps = 
		{
			----------------- aoi对象公有属性 start --------------------
			now_state = init_state,				-- 当前状态
			now_state_expire = 0,				-- nil，代表永不过期

			appear_ver = 0,						-- 外观缓存版本
			appear_bin = createFastPacket(nil),	-- 缓存的外观packet对象
			appear_bin_ver = nil,				-- 缓存的外观版本
			
			is_pause = false,
			motion_state = false,
			----------------- aoi对象公有属性 end ----------------------
			
			fight_number_id = 0,		-- 战斗计算id
			fight_expire = 0,			-- 攻击状态的过期时间(有的是瞬时战斗，而引导技能有持续时间)
			lock_expire = 0,			-- 锁定的过期时间(有些锁定技能在播放期间不允许被其他人攻击)
			self_skill_expires = {},	-- 所有私有技能cd过期时间
			play_skill_expire = 0,		-- 允许触发下一个技能的时间
			fight_info = {},			-- 每次战斗攻击的临时信息(add by suwin)
			targeter_fight_info = {},	-- 被攻击者临时战斗信息(add by suwin)
			fight_buffers = nil,		-- 战斗BUFFER
			pet_tianfu = {},			-- 幻兽天赋能力加成(add by suwin)

			target_aoi_id = nil,		--目标id
			zhenying = character.tmps.zhenying,
			fight_number_id = 0,		--战斗序号ID
		}
		
	end
end



-- 不需要持久化到DB的字段
-- 注：玩家迁移MAP，不需要持久化的这些字段
ChPetNoSaveDbField = {
	aoi_id = 1,		--id(aoi_obj.obj_id)
	aoi_type = 1,	--Statics.AOI_OBJECT_TYPE_ID_PET
	aoi_obj = 1,
	space_id = 1,
	
	cid = 1,				-- 主人的角色ID
	gcid = 1,
	parent_aoi_id = 1,		
	parent_gpid = 1,
	hp = 1,					-- 当前hp值
	body_size = 1,			-- 身体大小
	
	star = 1,				-- 星数
	pet_base = 1,			-- 幻兽基础属性
}

ChPetSaveDbField = {}
do
	for k, v in pairs(ChPet) do
		if not ChPetNoSaveDbField[k] and type(v) ~= 'function' and k ~= "client_Equals__" and k ~= 'client_in_bar_id' then
			ChPetSaveDbField[k] = 1
		end
	end
end