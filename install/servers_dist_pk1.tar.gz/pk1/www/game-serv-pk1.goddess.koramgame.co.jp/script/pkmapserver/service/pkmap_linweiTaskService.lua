--[[
	临危任务Service
	任务状态切换图:
		任务打怪状态 -> 完成状态（失败/左边) -> 任务打怪状态
	aoi_scene 
		linwei_obj  	任务生成的对象（包括 需要守护的NPC、传送门、怪物)
		linwei_task 	任务数据
		linwei_player	摘取任务的玩家列
			player_list		列表
			player_hash		hash
		linwei_warp_obj 		需要删除的传送门
		linwei_warp_del_time 	需要删除传送门的时间（为了在客户端能够看到传送门消失的特效，若一直不删除，特效会重复出现)
		linwei_ex		此数据不会被清除
			next_linwei_task_time 下一次任务生成的时间

--]]

LinweiTaskService = LinweiTaskService or {}

---------------------------- 客户端请求 [BEG] -------------------------
-- 接取任务
function LinweiTaskService:acceptTask( character, arr_params )
	local task_id = arr_params.task_id
	local aoi_scene = GameObjectService:getAoiScene(character)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	-- 任务是否已经结束
	if not linwei_task then 
		return false, errorCodes.LINEWI_FINISHED
	end

	-- 信息是否错误
	if linwei_task.task_id ~= task_id then 
		return false, errorCodes.COMMON_PARAM_ERROR
	end

	-- 参与次数是否还有
	if not LinweiTaskService:isCanJoinTask(character) then 
		return false, errorCodes.LINEWI_TIMES_NOT_ENOUGH
	end

	-- 判断任务是否已经结束了
	local status = self:getStatus(aoi_scene)
	local status_update_time = linwei_task.status_update_time
	local end_time = linwei_task.base_task.end_time
	if self:getStatus(aoi_scene) ~= LinweiTaskDefs.LINWEI_STATUS_COMMON or 
		end_time and end_time ~= 0 and end_time < os.time() then 
		WorldPacket:m2cSendCommEmpty(character.gpid)
		return true
	end

	self:addPlayerToTask(character, aoi_scene)
	self:sendAcceptTaskSuc(character, arr_params)
	self:sendSceneLinweiTask(character, aoi_scene)
	return true
end
---------------------------- 客户端请求 [END] -------------------------

---------------------------- 场景相关 [BEG] -------------------------
-- 玩家进入场景后，发送场景给玩家 
function LinweiTaskService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	
end

-- 离开场景时,将奖牌发到游戏玩家身上
function LinweiTaskService:afterLeaveScene(character, aoi_scene, leave_type)
	LinweiTaskService:erasePlayerFromTask( character, aoi_scene )
	return true
end

-- 场景初始化时即添加怪物
function LinweiTaskService:onInitScene(character, aoi_scene)
	aoi_scene.linwei_ex = {}
	return true
end

-- 场景周期更新
function LinweiTaskService:update500ms(now_time_msec, aoi_scene)
	-- 查看这个等级段是否有临危任务
	local space_id = aoi_scene.space_id
	local layer = OutdoorDao.spaceid_2_layer[space_id]
	local lay_conf = OutdoorConfig.lay_conf
	local this_layer_conf = lay_conf[layer]	
	if not this_layer_conf or not this_layer_conf.is_linwei then 
		return 
	end

	if self:isInLinweiTask(aoi_scene) then 
		local linwei_task = self:getSceneLinweiTask(aoi_scene)
		-- 检测任务状态
		local status = self:getStatus(aoi_scene)
		local status_update_time = linwei_task.status_update_time
		local now_time = os.time()
		if status == LinweiTaskDefs.LINWEI_STATUS_FAIL then
			if now_time >= status_update_time then 
				self:onTaskFail(aoi_scene)
			end
		elseif status == LinweiTaskDefs.LINWEI_STATUS_WAVE_FINISH then 
			if now_time >= status_update_time then 
				self:onWaveFinish(aoi_scene)
			end
		else
			local base_task = linwei_task.base_task
			-- 需要创建的怪物，如果是守护NPC，一波任务生成后，不会为0，每次调用从每个传送门生成
			-- 一只，直到全部生成
			if base_task.need_create_num and base_task.need_create_num > 0 then 
				self:addWarpMonster( aoi_scene )		
			end

			-- 限时任务时间到
			local end_time = base_task.end_time
			if end_time and end_time ~= 0 and end_time < os.time() then 
				-- 设置状态为失败
				self:setStatus(aoi_scene, LinweiTaskDefs.LINWEI_STATUS_FAIL)
			else
				-- 定期广播血量变化
				self:noticeNpcHp(aoi_scene)
			end
		end
	else
		-- 不在任务中,检测是否开启下一场任务
		local linwei_ex = aoi_scene.linwei_ex
		if linwei_ex.is_start and self:genNextTaskTime(aoi_scene) <= os.time() then 
			self:addNewTask(aoi_scene)
		end
	end

	-- 检测是否删除传送门
	if aoi_scene.linwei_warp_del_time and os.time() >= aoi_scene.linwei_warp_del_time then
		LinweiTaskService:clearWarpNpc( aoi_scene )
	end
end

-- 当玩家被杀,扣除奖牌
function LinweiTaskService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
end

-- 当怪物被杀
function LinweiTaskService:onKilledMonster(character, arr_kill_monster_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(character)

	-- 不在任务中，直接返回
	if not self:isInLinweiTask(aoi_scene) or
		LinweiTaskService:getStatus( aoi_scene ) == LinweiTaskDefs.LINWEI_STATUS_FAIL then
		return 
	end

	-- 获取临危任务对象
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
	local ch_linwei_obj = linwei_player.player_hash[character.gcid]	--角色临危数据
	local base_task = linwei_task.base_task


	-- 所有此次死掉的爆炸怪
	local boom_objs = nil

	-- 遍历所有怪物
	for k, aoi_id in pairs(arr_kill_monster_aoi_id) do
		local obj_type = linwei_obj[aoi_id]
		linwei_obj[aoi_id] = nil

		-- 只处理创建时有记录的怪物
		if obj_type then 
			local is_wave_finish = false
			
			-- 当普通任务怪或爆炸怪被杀
			if LinweiTaskDefs.LINWEI_OBJ_TYPE_MONSTER == obj_type or  
				LinweiTaskDefs.LINWEI_OBJ_TYPE_BOMB_MONSTER == obj_type then
				base_task.killed_num = base_task.killed_num + 1
				is_wave_finish = base_task.killed_num == base_task.need_kill_num
			-- 当BOSS怪被杀
			elseif LinweiTaskDefs.LINWEI_OBJ_TYPE_BOSS == obj_type then
				base_task.is_boss_kiled = true
				is_wave_finish = true
				base_task.boss_killer = character.gcid
			else
				assert(false)
			end

			-- 爆炸怪存储起来
			if LinweiTaskDefs.LINWEI_OBJ_TYPE_BOMB_MONSTER == obj_type then
				boom_objs = boom_objs or {}
				table.insert(boom_objs, aoi_id)
			end

			-- 任务不是失败的情况下，才出下一波
			if LinweiTaskService:getStatus( aoi_scene ) ~= LinweiTaskDefs.LINWEI_STATUS_FAIL then 
				-- 如果一波完成
				if is_wave_finish and LinweiTaskService:getStatus( aoi_scene ) then 
					self:setStatus(aoi_scene, LinweiTaskDefs.LINWEI_STATUS_WAVE_FINISH)
				-- 此波怪物未杀完,直接通知所有任务玩家
				else
					self:sendUpdate(aoi_scene)
				end
			end

		end
	end


	-- 爆炸处理
	if boom_objs then 

		-- 被沾染的怪物
		local need_boom_aoi_hash = {}
		local data_send_2_client = {dead_aoi_ids = {}}

		-- 获取爆炸范围内的所有怪物
		for _, boom_aoi_id in pairs(boom_objs) do
			
			data_send_2_client.boom_aoi_id = boom_aoi_id

			-- 爆炸怪
			local boom_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, boom_aoi_id)
			local x = boom_obj.x
			local y = boom_obj.y

			-- 获取范围内的怪物
			for aoi_id, aoi_type in pairs(linwei_obj) do
				if aoi_type == LinweiTaskDefs.LINWEI_OBJ_TYPE_MONSTER then 

					local monster_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
					
					-- 计算距离(测试的时候暂时使用固定距离10)
					if (monster_obj.x - x)^2 + (monster_obj.y - y)^2 <= 10^2 
					and not need_boom_aoi_hash[aoi_id] then 
						need_boom_aoi_hash[aoi_id] = true

						-- 设置怪物为死亡状态						
						local hp_index = FightService:getHpInfo(monster_obj)
						local add_hp = 0 - monster_obj.hp
						monster_obj.hp = 0
						local arr_aoi_change_hp = {FightService:newObjChangeHp(monster_obj.aoi_id, hp_index, add_hp, 0)}
						FightService:sendObjsChangeHp(aoi_scene, monster_obj, arr_aoi_change_hp)
						MonsterAiService:toPreDeadState(monster_obj)

						-- 增加攻击者的积分
						base_task.killed_num = base_task.killed_num + 1
						if ch_linwei_obj then 
							ch_linwei_obj.total_harm = (ch_linwei_obj.total_harm or 0) + monster_obj.max_hp
						end
					end
				end
			end
		end

		-- 删除所有怪物
		for del_aoi_id, v in pairs(need_boom_aoi_hash) do
			table.insert(data_send_2_client.dead_aoi_ids, del_aoi_id)
			linwei_obj[del_aoi_id] = nil
		end

		-- 查看是否到下一波
		if next(need_boom_aoi_hash) then 
			local is_wave_finish = base_task.killed_num >= base_task.need_kill_num
			if is_wave_finish and LinweiTaskService:getStatus( aoi_scene ) then 
				self:setStatus(aoi_scene, LinweiTaskDefs.LINWEI_STATUS_WAVE_FINISH)
			-- 此波怪物未杀完,直接通知所有任务玩家
			else
				self:sendUpdate(aoi_scene)
			end
		end

		--  是否下发被炸怪物列表给客户端
		self:sendBoom(aoi_scene, data_send_2_client)
	end
end

-- 当怪物受伤害时
function LinweiTaskService:onMonsterHarm(character, arr_kill_monster_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(character)

	-- 不在任务中，直接返回
	if not self:isInLinweiTask(aoi_scene) then
		return 
	end

	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
	local ch_linwei_obj = linwei_player.player_hash[character.gcid]	--角色临危数据

	-- 如果玩家没接任务，不计算伤害
	if not ch_linwei_obj then 
		return
	end

	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)

	local base_task = linwei_task.base_task

	for aoi_id, harm in pairs(arr_kill_monster_aoi_id) do
		-- 如果是注册的怪物，则计算伤害
		if linwei_obj[aoi_id] then 
			ch_linwei_obj.harm = (ch_linwei_obj.harm or 0) + harm
		end
	end
end

-- 当NPC被杀
function LinweiTaskService:onNpcKilled(fighter, arr_kill_guard_npc_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(fighter)

	-- 不在任务中，直接返回
	if not self:isInLinweiTask(aoi_scene) then
		return 
	end

	local linwei_task  = self:getSceneLinweiTask(aoi_scene)
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)

	-- 不可能同时几个NPC被杀的，除非之前的NPC没死
	assert(#arr_kill_guard_npc_aoi_id == 1)

	for k, npc_aoi_id in pairs(arr_kill_guard_npc_aoi_id) do
		if linwei_obj[npc_aoi_id] then 
			self:noticeNpcHp(aoi_scene)
			--NPC对象不立即清除，状态切换时再进行清除,不然NPC尸体会突然不见
			self:setStatus(aoi_scene, LinweiTaskDefs.LINWEI_STATUS_FAIL)
		end
	end
end

-- 当任务失败时
function LinweiTaskService:onTaskFail( aoi_scene )
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)	
	local base_task = linwei_task.base_task	

	-- 设置为初始状态(一到此步骤即切换状态，以防后面出错，接下来的任务不出)
	self:setStatus(aoi_scene, LinweiTaskDefs.LINWEI_STATUS_COMMON)
	
	-- 发失败奖励
	self:reward(aoi_scene, false)

	-- 清理小地图
	self:delSmallMap(aoi_scene)

	-- 清除所有任务怪
	self:clearAllAoiObj(aoi_scene)	
	self:clearTaskInfo(aoi_scene)	

	-- 将控制权交给野外模块
	self:onFinishTask(aoi_scene)
end

-- 当一波怪完成时(BOSS被杀，一波怪被清均会进入此逻辑)
function LinweiTaskService:onWaveFinish( aoi_scene )

	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)	
	local base_task = linwei_task.base_task

	self:setStatus(aoi_scene, LinweiTaskDefs.LINWEI_STATUS_COMMON)
	
	-- 任务的最后一波
	if base_task.now_step == base_task.totle_steps then 

		LinweiTaskService:delSmallMap(aoi_scene)

		-- 发红包
		self:rewardSurprise( aoi_scene )

		-- 发奖
		self:reward( aoi_scene, true)		

		-- 清除任务生成的对象(红包中要使用NPC血量，所以放在发红包之后)
		self:clearAllAoiObj(aoi_scene)

		-- 如果是最后一个任务
		if LinweiTaskBaseService:isLastTask( linwei_task ) then 
			-- 清除任务信息	
			self:clearTaskInfo( aoi_scene )

			self:onFinishTask(aoi_scene)
		else
			-- 生成下一个任务
			LinweiTaskBaseService:genCombNextTask( linwei_task )
			
			-- 任务下一波（任务生成后初始是没有的）
			LinweiTaskBaseService:genTaskNextStep(linwei_task)

			-- 生成小地图提示
			LinweiTaskService:setSmallMap(aoi_scene)

			-- 创建怪物
			self:createTaskObject( aoi_scene )

			-- 通知玩家任务更新
			self:sendUpdate(aoi_scene)
		end

	-- 还有下一波
	else 
		-- 生成下一波的数据
		LinweiTaskBaseService:genTaskNextStep( linwei_task )
		-- 添加普通怪
		self:addMonster(aoi_scene)
		-- 通知所有任务中的玩家
		self:sendUpdate(aoi_scene)
	end	
end

-- 设置下次任务时间
function LinweiTaskService:setNextTaskTime( aoi_scene, next_time)
	aoi_scene.linwei_ex.next_linwei_task_time = next_time
	if next_time then 
		self:setNextTaskPos(aoi_scene)
	end
end

-- 获取下次任务时间
function LinweiTaskService:genNextTaskTime( aoi_scene )
	return aoi_scene.linwei_ex.next_linwei_task_time
end

-- 获取下次任务位置
function LinweiTaskService:genNextTaskPos(aoi_scene)
	return aoi_scene.linwei_ex.next_linwei_task_pos
end
-- 获取下次任务位置
function LinweiTaskService:setNextTaskPos(aoi_scene)
	aoi_scene.linwei_ex.next_linwei_task_pos = math.random(1, 4)
end
---------------------------- 场景相关 [END] -------------------------

-- 任务开始
function LinweiTaskService:startAfter( aoi_scene, sec )
	local linwei_ex = aoi_scene.linwei_ex
	linwei_ex.is_start = true
	self:setNextTaskTime(aoi_scene, os.time() + sec)
end

-- 任务结束
function LinweiTaskService:onFinishTask( aoi_scene )
	local linwei_ex = aoi_scene.linwei_ex
	linwei_ex.is_start = false
	OutdoorService:onTaskFinish( aoi_scene, OutdoorDefs.OUTDOOR_TASK_TYPE_LINWEI )
end

---------------------------- 怪物与NPC相关辅助 [BEG] -------------------------
-- 创建新一波任务的怪及NPC(只能在任务的第一波会调用,不然会导致重复生成NPC)
function LinweiTaskService:createTaskObject( aoi_scene )
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)

	local base_task = linwei_task.base_task
	local npc_id = base_task.npc_id
	local boss_id = base_task.boss_monster_id
	local monster_id = base_task.common_monster_id
	
	-- 创建NPC
	if npc_id and npc_id > 0 then 
		-- 添加守护的NPC
		self:addNpc(aoi_scene, npc_id)
		-- 添加传送门
		self:addWarpNpc( aoi_scene,  LinweiTaskConfig.WARP_NPC_ID)
	end

	-- 创建怪物
	if monster_id and monster_id > 0 then 
		linwei_task.common_monster_id = monster_id
		self:addMonster(aoi_scene)
	end

	-- 创建BOSS
	if boss_id and boss_id > 0 then 
		self:addBoss(aoi_scene)
	end
end

-- 添加普通任务怪
-- 守护NPC的怪物位置
do  --
	function LinweiTaskService:addMonster( aoi_scene)
		local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
		local linwei_task = self:getSceneLinweiTask(aoi_scene)
		local base_task = linwei_task.base_task
		-- 怪物ID
		local monster_id = linwei_task.base_task.common_monster_id

		-- 如果是守护NPC，则找到对应的NPC
		local npc_obj_id = linwei_task.base_task.npc_obj_id
		local npc = npc_obj_id and GameObjectService:getGameObjectByAoiId(aoi_scene, npc_obj_id) or nil

		-- 计算怪物数量
		local monster_num = self:calcMonterNum(aoi_scene, npc)
		assert(linwei_task.base_task.need_kill_num or linwei_task.base_task.need_kill_num == 0)
		linwei_task.base_task.need_kill_num = monster_num
		linwei_task.base_task.need_create_num = monster_num
		linwei_task.base_task.killed_num = 0		

		-- 不是守护任务的，直接随机生成怪物
		if not npc then
			-- 生成怪物
			local x = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].x
			local y = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].y
			for i=1, monster_num do 
				local x, y = LinweiTaskService:randomCircularPos( x, y, LinweiTaskConfig.RADIUS )
				local monster = assert(MonsterService:dymCreateMonster(aoi_scene, monster_id, nil,  x, y))
				-- 将AOI_ID保存起来
				local obj_id = monster.aoi_obj.obj_id
				linwei_obj[obj_id] = LinweiTaskDefs.LINWEI_OBJ_TYPE_MONSTER

				-- 储存总血量
				LinweiTaskService:addMonsterTotalHp( aoi_scene, monster.max_hp )
			end

			-- 生成爆炸怪
			if base_task.boomb_monster_id then 
				for i=1, base_task.boomb_monster_num do
					local x, y = LinweiTaskService:randomCircularPos( x, y, LinweiTaskConfig.RADIUS )
					local monster = assert(MonsterService:dymCreateMonster(aoi_scene, base_task.boomb_monster_id, nil,  x, y))
					-- 将AOI_ID保存起来
					local obj_id = monster.aoi_obj.obj_id
					linwei_obj[obj_id] = LinweiTaskDefs.LINWEI_OBJ_TYPE_BOMB_MONSTER

					-- 储存总血量
					LinweiTaskService:addMonsterTotalHp( aoi_scene, monster.max_hp )					
				end

				-- 将爆炸怪的数量加到怪物总数量中
				base_task.need_kill_num = base_task.need_kill_num + base_task.boomb_monster_num
			end
			linwei_task.base_task.need_create_num = 0
		else
			-- 守护任务的怪物间隔一定时间从传送门生成，见LinweiTaskService:addWarpMonster
			-- 随机守护任务怪物的出生点
			local live_point_Num = math.random(1, 2)
			linwei_task.base_task.live_points = math.randomN(1, 4, live_point_Num)

			-- 通知客户端，传送门的位置
			LinweiTaskService:sendWarpsPos(aoi_scene)
		end
	end
end

-- 添加BOSS怪
function LinweiTaskService:addBoss( aoi_scene )
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)

	local x = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].x
	local y = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].y
	local boss_id = linwei_task.base_task.boss_monster_id
	local monster = MonsterService:dymCreateMonster(aoi_scene, boss_id, nil,  x, y)

	-- 储存总血量
	LinweiTaskService:addMonsterTotalHp( aoi_scene, monster.max_hp )

	-- 将AOI_ID保存起来
	local obj_id = monster.aoi_obj.obj_id
	linwei_task.base_task.boss_monster_aoi_id = obj_id
	
	linwei_obj[obj_id] = LinweiTaskDefs.LINWEI_OBJ_TYPE_BOSS
end

-- 添加可被攻击NPC
function LinweiTaskService:addNpc( aoi_scene, npc_id )
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local x = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].x
	local y = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].y

	local npc = GuardNpcService:createGuardNpc(aoi_scene, npc_id, x, y)
	-- 将npc的aoiID存储起来
	local npc_obj_id = npc.aoi_obj.obj_id
	local base_task = linwei_task.base_task
	base_task.npc_obj_id = npc_obj_id
	linwei_obj[npc_obj_id] = LinweiTaskDefs.LINWEI_OBJ_TYPE_BOSS
end

-- 添加传送门NPC
function LinweiTaskService:addWarpNpc( aoi_scene, npc_id )
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local x = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].x
	local y = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].y

	-- 生成新的传送门NPC
	local save_npc_transfer_pos = LinweiTaskConfig.save_npc_transfer_pos
	for _, pos in pairs(save_npc_transfer_pos) do
		local real_x = x + pos.x
		local real_y = y + pos.y
		local direct = pos.direct
		local npc = GuardNpcService:createGuardNpc(aoi_scene, npc_id, real_x, real_y)
		local npc_obj_id = npc.aoi_obj.obj_id
		linwei_obj[npc_obj_id] = LinweiTaskDefs.LINWEI_OBJ_TYPE_NPC_WARP
	end
end

-- 从传送门添加一批怪物
function LinweiTaskService:addWarpMonster( aoi_scene )
	local save_npc_transfer_pos = LinweiTaskConfig.save_npc_transfer_pos
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)

	-- 怪物ID
	local monster_id = linwei_task.base_task.common_monster_id

	-- 如果是守护NPC，则找到对应的NPC
	local npc_obj_id = linwei_task.base_task.npc_obj_id
	local npc = assert(GameObjectService:getGameObjectByAoiId(aoi_scene, npc_obj_id))

	local need_create_num = linwei_task.base_task.need_create_num

	local x = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].x
	local y = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].y

	-- 有多少传送门，即有多少NPC
	for index, _ in pairs(linwei_task.base_task.live_points) do
		local pos = LinweiTaskConfig.save_npc_transfer_pos[index]
		local real_x = pos.x + x
		local real_y = pos.y + y
		local monster = assert(MonsterService:dymCreateMonster(aoi_scene, monster_id, nil, real_x, real_y))
		MonsterService:setMyTargeter(monster, npc)
		
		-- 储存总血量
		LinweiTaskService:addMonsterTotalHp( aoi_scene, monster.max_hp )

		-- 将AOI_ID保存起来
		local obj_id = monster.aoi_obj.obj_id
		linwei_obj[obj_id] = LinweiTaskDefs.LINWEI_OBJ_TYPE_MONSTER

		need_create_num = need_create_num - 1
		if need_create_num <= 0 then 
			break
		end
	end
	linwei_task.base_task.need_create_num = need_create_num
end

-- 当一个子任务结束时，清除所有任务怪
function LinweiTaskService:clearAllAoiObj( aoi_scene )
	local linwei_obj = self:getSceneLinweiTaskObj(aoi_scene)
	if linwei_obj then 
		for aoi_id, obj_type in pairs(linwei_obj) do
			local game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
			if game_obj then 
				if obj_type == LinweiTaskDefs.LINWEI_OBJ_TYPE_NPC_WARP then 
					-- 设置传送门为死亡，客户端播放死亡特效
					local hp_index = FightService:getHpInfo(game_obj)
					local add_hp = 0 - game_obj.hp
					game_obj.hp = 0
					local arr_aoi_change_hp = {FightService:newObjChangeHp(game_obj.aoi_id, hp_index, add_hp, 0)}
					FightService:sendObjsChangeHp(aoi_scene, game_obj, arr_aoi_change_hp)				
					
					-- 添加传送门到需要删除的传送门列表,6秒后删除传送门
					aoi_scene.linwei_warp_obj = aoi_scene.linwei_warp_obj or {}
					aoi_scene.linwei_warp_del_time = os.time() + 6
					table.insert(aoi_scene.linwei_warp_obj, aoi_id)
				else
					GameObjectService:delObjByAoiId(aoi_scene, aoi_id)
				end
			end
		end		
	end
end

-- 清除传送门
function LinweiTaskService:clearWarpNpc( aoi_scene )
	for _, aoi_id in pairs(aoi_scene.linwei_warp_obj) do
		GameObjectService:delObjByAoiId(aoi_scene, aoi_id)
	end
	aoi_scene.linwei_warp_obj = nil
	aoi_scene.linwei_warp_del_time = nil	
end

-- 增加怪物总血量(用于计算奖励等级)
function LinweiTaskService:addMonsterTotalHp( aoi_scene, monster_hp )
	aoi_scene.linwei_monster_hp = (aoi_scene.linwei_monster_hp or 0) + monster_hp
end

-- 清空怪物总血量
function LinweiTaskService:clearMonsterTotalHp( aoi_scene )
	aoi_scene.linwei_monster_hp = 0
end

-- 获得怪物总血量
function LinweiTaskService:getMonsterTotalHp( aoi_scene )
	return aoi_scene.linwei_monster_hp
end
---------------------------- 怪物与NPC相关辅助 [END] -------------------------
-- 发奖
function LinweiTaskService:reward( aoi_scene, is_success )
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
	local player_hash = linwei_player.player_hash
	local base_task = linwei_task.base_task
	local task_type = base_task.task_type
	local linwei_base = LinweiTaskBaseService:getTaskBaseByType( task_type )	
	
	if is_success then 
		--local rank_players = self:getRankedPlayers(player_hash)
		local monster_total_hp = self:getMonsterTotalHp(aoi_scene)
		if monster_total_hp == 0 then monster_total_hp = 1 end

		-- 计算人数
		local player_num = 0
		for _, ch_linwei_obj in pairs(player_hash) do
			player_num = player_num + 1
		end

		-- 人数为0，直接退出
		if player_num <= 0 then return end

		local GOLD_HARM_RATE = LinweiTaskConfig.PLAYER_NUM_2_RATE[player_num].s_rate
		local SILVER_HARM_RATE = LinweiTaskConfig.PLAYER_NUM_2_RATE[player_num].a_rate
		local gold_limit = monster_total_hp * GOLD_HARM_RATE 	
		local silver_limit = monster_total_hp * SILVER_HARM_RATE
		local boss_killer  = base_task.boss_killer
		local arr_reward = {}

		local teamid_2_gcids = {}

		-- 计算所有玩家的奖励
		for _, ch_linwei_obj in pairs(player_hash) do
			local gcid = ch_linwei_obj.gcid
			local team = TeamService:getTeamByCid( gcid, boss_killer)
			local is_killer = boss_killer == gcid
			local is_team = team and team.member_num > 1 and true or false
			
			-- 用于亲密度
			if is_team then 
				teamid_2_gcids[team.id] = teamid_2_gcids[team.id] or {}
				table.insert(teamid_2_gcids[team.id], ch_linwei_obj.gcid)
			end

			-- 计算评级
			local reward_type = 0
			local reward_obj = nil
			local harm = ch_linwei_obj.harm
			if harm >= gold_limit then 
				reward_type = 1
			elseif harm >= silver_limit then 
				reward_type = 2
			else 
				reward_type = 3
			end 

			-- 计算宝箱
			local baoxiang_num = LinweiTaskConfig.rate_rewards[reward_type]
			if is_team then baoxiang_num = baoxiang_num + LinweiTaskConfig.team_reward end
			if is_killer then baoxiang_num = baoxiang_num + LinweiTaskConfig.killer_reward end

			-- 计算荣誉
			local honour = LinweiTaskConfig.rate_rewards_honour[reward_type]

			local character = CharacterService:getCharacterByGcid(gcid)
			if character then 
				local finish_data = {}
				finish_data.is_team = is_team
				finish_data.is_killer = is_killer
				finish_data.nick = character.nick
				finish_data.harm = harm
				finish_data.reward_type = reward_type
				finish_data.gcid = gcid
				finish_data.baoxiang_num = baoxiang_num
				finish_data.is_first = false
				finish_data.honour = honour
				arr_reward[#arr_reward + 1] = finish_data
			end
		end

		-- 亲密度(建筑的接口)
		for _, gcids in pairs(teamid_2_gcids) do
			if #gcids > 1 then 
				FriendService:onJoinAcitivty(gcids, FriendDefs.FRIEND_ACT_TYPE_ID_LINWEI)
			end
		end

		-- 排序
		table.sort(arr_reward, function ( l, r )
			return l.harm > r.harm
		end)

		-- 增加第一名的宝箱数量
		if #arr_reward > 0 then 
			arr_reward[1].is_first = true
			arr_reward[1].baoxiang_num = arr_reward[1].baoxiang_num + LinweiTaskConfig.first_reward
		end
		for _, finish_data in pairs(arr_reward) do
			finish_data.rank = _
		end

		-- 组织结束的统一结构
		local task_result = {}
		task_result.is_success = true
		task_result.task_type = task_type
		task_result.ranks = arr_reward
		task_result.exp = 0
		task_result.is_hongbao = base_task.is_hongbao
		task_result.start_time = base_task.start_time
		task_result.finish_param = base_task.finish_param or 0
		local exp_reward_base = LinweiTaskConfig.exp_reward_base
		local exp_reward_radix= LinweiTaskConfig.exp_reward_radix

		for _, finish_data in pairs(arr_reward) do
			local character = CharacterService:getCharacterByGcid(finish_data.gcid)
			task_result.exp = math.floor((exp_reward_base + exp_reward_radix * character.level) * GameInfoService:getExpRadix( character, WorldLevelDefs.WORLD_LV_EXP_LINWEI ))
			task_result.honour = finish_data.honour
			task_result.is_hongbao = base_task.is_hongbao and finish_data.harm and finish_data.harm > 0
			
			-- 发送奖励信息
			self:sendTaskFinish(character.gpid, task_result)
			-- 增加已参与次数
			self:addJoinTimes( character )
			-- 发送奖励到游戏服
			local reward_equips = {}
			reward_equips[EquipDefs.FUNCTION_EQUIP_ID_EXP] = task_result.exp
			if finish_data.baoxiang_num > 0 then 
				reward_equips[LinweiTaskDefs.BAOXIANG_EQUIP_ID] = finish_data.baoxiang_num
			end
			if finish_data.honour > 0 then
				reward_equips[EquipDefs.FUNCTION_EQUIP_ID_HONOUR] = finish_data.honour
			end
			self:sendReward(character, reward_equips)
		end
	else
		local gpids = {}
		for _, ch_linwei_obj in pairs(player_hash) do
			-- 只给有输出伤害的玩家发参与奖
			gpids[#gpids + 1] = ch_linwei_obj.gpid
		end

		-- 发送失败消息
		if #gpids > 0 then 
			local task_result = {}
			task_result.is_success = false
			task_result.task_type = task_type
			task_result.ranks = {}
			task_result.exp = 0
			task_result.is_hongbao = false
			task_result.start_time = base_task.start_time
			task_result.finish_param = 0
			self:sendTaskFinish(gpids, task_result)
		end
	end

	-- 清除怪物总血量信息
	self:clearMonsterTotalHp(aoi_scene)	
end

---------------------------------------- 任务次数相关 【BEG】---------------------------------
-- 判断玩家是否可参与任务
function LinweiTaskService:isCanJoinTask( character )
	local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_LINWEI_TASK_TIMES)
	return en_count > 0
end

-- 参与任务
function LinweiTaskService:addJoinTimes( character )
	local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_LINWEI_TASK_TIMES)
	CounterService:addcount(character, counter, nil, nil, true)
end
---------------------------------------- 任务次数相关 【END】---------------------------------

-- 通知游戏服发奖
function LinweiTaskService:sendReward( character, reward_params)
	RewardService:reward(Statics.PK_GAME_TYPE_ID_LINWEI, 0, character.gpid, character.gcid, reward_params)
end

-- 计算总的伤害值
function LinweiTaskService:getTotalHarm( player_hash )
	local total_harm = 0
	for gcid, player in pairs(player_hash) do
		total_harm = total_harm + player.harm
	end
	return total_harm
end

function LinweiTaskService:getRankedPlayers( player_hash )
	local arr_players = {}
	for gcid, player in pairs(player_hash) do
		arr_players[#arr_players+1] = player
	end

	table.sort(arr_players, function ( a, b )
		return a.harm > b.harm
	end)
	for k, v in pairs(arr_players) do
		v.rank = k
	end
	return arr_players
end

-- 发惊喜奖励
function LinweiTaskService:rewardSurprise( aoi_scene)
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local base_task = linwei_task.base_task
	local player_hash = linwei_player.player_hash
	local arr_character = {}
	local task_type = linwei_task.base_task.task_type
	local task_base = LinweiTaskBaseService:getTaskBaseByType(task_type)

	base_task.is_hongbao = false
	
	-- 所有任务均发奖
	if true then --linwei_task.is_surprise == 1 then 
		-- 查看是否可以领取红包
		if task_type == LinweiTaskDefs.LINWEI_TASK_TYPE_NPC then
			-- 查看NPC的血量
			local npc_obj_id = base_task.npc_obj_id
			local npc_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, npc_obj_id)
			base_task.finish_param = math.floor(npc_obj.hp * 100 / npc_obj.max_hp)
			if npc_obj.hp / npc_obj.max_hp < task_base.hongbao_param then 
				return 
			end
		else
			-- 查看结束时间
			local real_task_time = os.time() - 1 - base_task.start_time
			base_task.finish_param = real_task_time
			if real_task_time > task_base.hongbao_param then 
				return 
			end
		end

		-- 设置为有红包
		base_task.is_hongbao = true

		for _, player in pairs(player_hash) do
			if player.harm > 0 then 
				local gcid = player.gcid
				local character = CharacterService:getCharacterByGcid(gcid)
				if character then 
					arr_character[#arr_character +1] = character.gpid
				end
			end
		end

		-- 计算红包
		local surprice_rewards = LinweiTaskConfig.hongbao
		local equips = math.randRewardEquips(surprice_rewards)

		if #arr_character > 0 then 
			for equip_id, equip_num in pairs(equips) do
				equip_num = equip_num * (#arr_character) --乘以人数
				Logger:info('【LinweiTaskService:rewardSurprise】发红包，道具ID:' .. equip_id .. '数量' .. equip_num)
				RewardHongbaoService:genHongbaos(aoi_scene, arr_character, equip_id, equip_num, #arr_character > 5 and 5 or #arr_character, RewardDefs.REWARD_FROM_MODULE_ID_HONGBAO_LINWEI)
				break
			end
		end
	end
end

-- 生成一个新任务
function LinweiTaskService:addNewTask( aoi_scene, gm_param)
	local pos = self:genNextTaskPos(aoi_scene) or math.random(1, 4)
	if gm_param then pos = gm_param.pos end
	
	local space_id = aoi_scene.space_id
	local layer = OutdoorDao.spaceid_2_layer[space_id]
	local players = GameObjectService:getGPids(aoi_scene)
	local player_num = players and #players or 0
	local task = LinweiTaskBaseService:genFullTask( pos, layer, gm_param, player_num)

	-- 清除旧的传送门NPC
	if aoi_scene.linwei_warp_obj then 
		LinweiTaskService:clearWarpNpc( aoi_scene )
	end

	-- 清除怪物总血量信息
	self:clearMonsterTotalHp(aoi_scene)

	-- 存储任务信息到场景中
	aoi_scene.linwei_task = task
	aoi_scene.linwei_obj = {}	--临危生成的对象
	-- monster = {aoi_id->type}
	aoi_scene.linwei_player = {player_list = {}, player_hash = {}}
	-- player_list = {gpid, gpid}
	-- player_hash = {gcid = {obj}, gcid = {obj}}
	self:createTaskObject(aoi_scene)

	self:setNextTaskTime(aoi_scene, nil)
	-- 设置状态为正常打怪状态
	self:setStatus( aoi_scene, LinweiTaskDefs.LINWEI_STATUS_COMMON)
	-- 通知所有玩家
	self:sendNewTask( aoi_scene )
	-- 小地图显示
	LinweiTaskService:setSmallMap( aoi_scene )
end

-- 清除所有任务相关信息
function LinweiTaskService:clearTaskInfo( aoi_scene )
	aoi_scene.linwei_task = nil
	aoi_scene.linwei_obj = nil
	aoi_scene.linwei_player = nil
end


-- 设置小地图
do
	local small_map = {
		[0] = {
			[LinweiTaskDefs.LINWEI_TASK_TYPE_QINGGUAI] = SmallMapDefs.SMALL_MAP_SORT_ID_LINWEI_MONSTER,
			[LinweiTaskDefs.LINWEI_TASK_TYPE_NPC] = SmallMapDefs.SMALL_MAP_SORT_ID_LINWEI_NPC,
			[LinweiTaskDefs.LINWEI_TASK_TYPE_BOSS] = SmallMapDefs.SMALL_MAP_SORT_ID_LINWEI_BOSS,
		},
		[1] = {
			[LinweiTaskDefs.LINWEI_TASK_TYPE_QINGGUAI] = SmallMapDefs.SMALL_MAP_SORT_ID_LINWEI_MONSTER_SUR,
			[LinweiTaskDefs.LINWEI_TASK_TYPE_NPC] = SmallMapDefs.SMALL_MAP_SORT_ID_LINWEI_NPC_SURP,
			[LinweiTaskDefs.LINWEI_TASK_TYPE_BOSS] = SmallMapDefs.SMALL_MAP_SORT_ID_LINWEI_BOSS_SURP,
		}
	}
	function LinweiTaskService:setSmallMap( aoi_scene )
		self:delSmallMap(aoi_scene)
		local linwei_task = self:getSceneLinweiTask(aoi_scene)
		local base_task = linwei_task.base_task
		local task_type = base_task.task_type
		local is_surprise = linwei_task.is_surprise
		local surp_or_not = small_map[is_surprise]
		local item_type = nil
		if surp_or_not then 
			item_type = surp_or_not[task_type]
		end
		
		if item_type then 
			local pos = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos]
			linwei_task.small_map_id = SmallMapService:addItem(aoi_scene, item_type, pos.x, pos.y)
		end
	end
end

-- 清除小地图
function LinweiTaskService:delSmallMap( aoi_scene )

	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local small_map_id = linwei_task and linwei_task.small_map_id
	if small_map_id then 
		SmallMapService:delItem(aoi_scene, small_map_id)
	end
end

-- 设置状态
function LinweiTaskService:setStatus( aoi_scene, status )
	local linwei_task = self:getSceneLinweiTask( aoi_scene )
	linwei_task.status = status
	linwei_task.status_update_time = os.time() + 3	--3秒后执行更新任务的操作
end

-- 获取状态
function LinweiTaskService:getStatus( aoi_scene )
	local linwei_task = self:getSceneLinweiTask( aoi_scene )
	return linwei_task.status
end

-- 添加玩家到任务中
function LinweiTaskService:addPlayerToTask( character, aoi_scene )
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
	local player_hash = linwei_player.player_hash
	local player_list = linwei_player.player_list
	if player_hash[character.gcid] then 
		return 
	end
	player_hash[character.gcid] = {
		gcid = character.gcid,
		gpid = character.gpid,
		harm = 0,
		level = character.level
	}
	player_list[#player_list + 1] = character.gpid
end

-- 将玩家从任务中删除
function LinweiTaskService:erasePlayerFromTask( character, aoi_scene )
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
	if not linwei_player then 
		return
	end
	local player_hash = linwei_player.player_hash
	local player_list = linwei_player.player_list
	if not player_hash[character.gicd] then return end

	player_hash[character.gicd] = nil
	for _, gpid in pairs(player_list) do
		if gpid == character.gpid then 
			table.remove(player_list, _)
			return
		end
	end
end

-- 获取场景任务信息
function LinweiTaskService:getSceneLinweiTask( aoi_scene )
	return aoi_scene.linwei_task
end

-- 获取场景任务生成的怪对象
function LinweiTaskService:getSceneLinweiTaskObj(aoi_scene )
	return aoi_scene.linwei_obj
end

-- 获取场景已经加入任务的玩家列表
function LinweiTaskService:getSceneLinweiTaskPlayer(aoi_scene )
	return aoi_scene.linwei_player
end

-- 以x,y为中心点，边长一半为size随机一个坐标点
function LinweiTaskService:randomCircularPos( x, y, size_out, size_in )
	local jiaodu = math.rad(math.random(1, 360))	-- 随机角度
	 -- 随机半径（取半径的平方，随机后再取平方根, 使得怪物不会集中在中心区域）
	local radius = (math.random(1, size_out * size_out))^(0.5)
	local x_pos = x + radius * math.cos(jiaodu)
	local y_pos = y + radius * math.sin(jiaodu)
	return x_pos, y_pos
end

function LinweiTaskService:isTableEmpty( tbl )
	for k, v in pairs(tbl) do
		return false
	end
	return true
end

-- 判断临危任务是否进行中
function LinweiTaskService:isInLinweiTask( aoi_scene )
	return self:getSceneLinweiTask(aoi_scene)
end

-- 计算生成的怪的数量
function LinweiTaskService:calcMonterNum( aoi_scene, is_npc)
	-- 获取任务范围内的玩家数量
	local linwei_task = self:getSceneLinweiTask(aoi_scene)
	local pos = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos]
	local x = pos.x
	local y = pos.y
	local r = LinweiTaskConfig.PLAYER_NUM_RADIUS

	-- 获取区域内的玩家数量(只计算参与任务的玩家数) 
	local arr_players = GameObjectService:getPlayerGameObjs(aoi_scene)	
	local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
	local player_hash = linwei_player.player_hash

	local inside_player_num = 0
	for _, character in pairs(arr_players) do
		if player_hash[character.gcid] and (x - character.x)^2 + (y - character.y)^2 <= r^2 then 
			inside_player_num = inside_player_num + 1
		end
	end
	
	-- 根据玩家数量计算出怪的数
	if inside_player_num > 16 then 
		return 50
	elseif inside_player_num > 0 then 
		return inside_player_num * 3
	else
		return 1
	end
	
end

---------------------------- 数据发送 [BEG] ---------------------------

do	-- 发送任务进度给所有玩家
	local rsp_opcode = opCodes.PKM2C_LINWEI_TASK_GET
	local msg_name = "PackLinwei.PKM2C_LINWEI_TASK_GET"
	local data = {is_in_task = 1, task = nil}
	function LinweiTaskService:sendUpdate( aoi_scene)
		local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
		data.task = self:getSceneLinweiTask(aoi_scene)
		local gpids = linwei_player.player_list
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end
end

do -- 发送新任务给所有场景中的玩家 
	local rsp_opcode = opCodes.PKM2C_LINWEI_TASK_GET
	local msg_name = "PackLinwei.PKM2C_LINWEI_TASK_GET"
	local data = {is_in_task = 0, task = nil}
	function LinweiTaskService:sendNewTask( aoi_scene)
		local arr_players = GameObjectService:getPlayerGameObjs(aoi_scene)	
		local gpids = GameObjectService:getGPids(aoi_scene)
		if not gpids then return end
		data.task = self:getSceneLinweiTask(aoi_scene)
		-- 是新建任务，所有玩家都不会在任务中
		data.is_in_task = 0
		data.next_task_time = self:genNextTaskTime(aoi_scene)
		data.next_task_pos = self:genNextTaskPos(aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end	
	function LinweiTaskService:getTask( aoi_scene)
		data.task = self:getSceneLinweiTask(aoi_scene)
		if not data.task then 
			-- 是新建任务，所有玩家都不会在任务中
			data.is_in_task = 0
			data.next_task_time = self:genNextTaskTime(aoi_scene)
			data.next_task_pos = self:genNextTaskPos(aoi_scene)
		end
		data.is_in_task = data.is_in_task or 0
		return data
	end		
end

do	-- 发送场景任务信息
	local rsp_opcode = opCodes.PKM2C_LINWEI_TASK_GET
	local msg_name = "PackLinwei.PKM2C_LINWEI_TASK_GET"
	local data = {is_in_task = nil, task = nil}
	function LinweiTaskService:sendSceneLinweiTask( character , aoi_scene)
		local linwei_task = self:getSceneLinweiTask(aoi_scene)
		if not linwei_task then 
			data.is_in_task = 0
			data.task = nil
			data.next_task_time = self:genNextTaskTime(aoi_scene)
			data.next_task_pos = self:genNextTaskPos(aoi_scene)
		else
			local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
			data.task = self:getSceneLinweiTask(aoi_scene)
			data.is_in_task = linwei_player and linwei_player.player_hash[character.gcid] and 1 or 0			
		end

		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do	-- 发送接取任务成功
	local rsp_opcode = opCodes.PKM2C_LINWEI_TASK_ACCEPT
	local msg_name = "PackLinwei.PKM2C_LINWEI_TASK_ACCEPT"
	local data = {task_id = nil}
	function LinweiTaskService:sendAcceptTaskSuc( character, arr_params)
		data.task_id = arr_params.task_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end	
end

do	-- 发送任务完成
	local rsp_opcode = opCodes.PKM2C_LINWEI_TASK_FINISH
	local msg_name = "PackLinwei.PKM2C_LINWEI_TASK_FINISH"
	function LinweiTaskService:sendTaskFinish( gpid, finish_data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, finish_data, nil, gpid)
	end	
end


do	-- 广播传送门的位置
	local rsp_opcode = opCodes.PKM2C_LINWEI_TASK_WARP_POS
	local msg_name = "PackLinwei.PKM2C_LINWEI_TASK_WARP_POS"
	local data = {}
	function LinweiTaskService:sendWarpsPos( aoi_scene )
		local linwei_task = self:getSceneLinweiTask(aoi_scene)
		data.warps_pos = {}
		local center_x = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].x
		local center_y = LinweiTaskConfig.CENTER_POS[linwei_task.task_pos].y
		for index, _ in pairs(linwei_task.base_task.live_points) do
			local rel_pos = LinweiTaskConfig.save_npc_transfer_pos[index]
			local pos = {}
			pos.x = rel_pos.x + center_x
			pos.y = rel_pos.y + center_y
			table.insert(data.warps_pos, pos)
		end	
		local gpids = GameObjectService:getGPids(aoi_scene)
		if not gpids then return end
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end	
end

do 	--广播爆炸怪爆炸
	local rsp_opcode = opCodes.PKM2C_LINWEI_TASK_BOOM
	local msg_name = "PackLinwei.PKM2C_LINWEI_TASK_BOOM"
	function LinweiTaskService:sendBoom( aoi_scene, data )
		local gpids = GameObjectService:getGPids(aoi_scene)
		if not gpids then return end
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end		
end

do
	local rsp_opcode = opCodes.PKM2C_LINWEI_TASK_NPC_HP
	local msg_name = "PackLinwei.PKM2C_LINWEI_TASK_NPC_HP"
	local data = {hp_perc = 0}
	function LinweiTaskService:noticeNpcHp( aoi_scene )
		local linwei_task = self:getSceneLinweiTask(aoi_scene)
		local base_task = linwei_task.base_task
		local npc_obj_id = base_task.npc_obj_id

		local npc_obj = npc_obj_id and GameObjectService:getGameObjectByAoiId(aoi_scene, npc_obj_id)
		if npc_obj then
			data.hp_perc = npc_obj.hp / npc_obj.max_hp

			local linwei_player = self:getSceneLinweiTaskPlayer(aoi_scene)
			local gpids = linwei_player.player_list	
			if #gpids > 0 then 
				WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)		
			end
		end
	end
end
------------------------------ 数据发送 [END] ---------------------------