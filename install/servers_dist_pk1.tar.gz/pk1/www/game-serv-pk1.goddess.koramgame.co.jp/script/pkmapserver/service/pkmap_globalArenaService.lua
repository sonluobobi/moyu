--[[
野外场景 service
author : xingzeng.jiang
date : 2014-07-15
--]]


GlobalArenaService = GlobalArenaService or {}
GlobalArenaDao = GlobalArenaDao
local ranks = GlobalArenaDao.ranks
local ranks_with_robot = GlobalArenaDao.ranks_with_robot
local ch_arena_details = GlobalArenaDao.ch_arena_details
local arenaid_2_arena = GlobalArenaDao.arenaid_2_arena
local pking_data = GlobalArenaDao.pking_data
local arenaid_2_history = GlobalArenaDao.arenaid_2_history

local ARENA_MAP_ID = GlobalArenaDefs.ARENA_MAP_ID
setmetatable(GlobalArenaService, SceneServiceInterface)

local SceneService = SceneService
function GlobalArenaService:onAfterLoadLua()
	SceneService = _G.SceneService
end

do
	local to_db_data = {}
	function GlobalArenaService:load()
		if g_mapserver_id ~= ARENA_MAP_ID then return end
		
		to_db_data.opcode = opCodes.M2D_GLOBAL_ARENA_LOAD
		WorldPacket:m2dSendOK(to_db_data, nil, 0)
	end
end

function GlobalArenaService:afterEnterScene( character, aoi_scene )
	self:updateChArenaAttrib(character)

	-- 发送红点提醒
	local ch_arena = self:getArenaDt(character)
	if ch_arena and ch_arena.is_need_send_redflag then 
		GlobalArenaService:sendRedFlags(character)
	end
end

function GlobalArenaService:afterLeaveScene( character, aoi_scene )
	local my_arena = self:getArenaDt(character)
	if my_arena then 
		self:clearPKing(my_arena)
	end
end

-- 报名跨服竞技场
function GlobalArenaService:baoming( character )
	-- 判断是否在活动时间内
	if not self:isInActiveTime() then
		ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
		return false, errorCodes.COMMON_ACTIVE_IS_END
	end

	-- 判断是否已经报名
	if self:getArenaDt(character) then 
		return false, errorCodes.COMMON_PARAM_ERROR
	end

	local group_id = PkserverMappingService:getGroupIdByGid(character.gcid,Statics.PK_GAME_TYPE_ID_ZHUSHEN)
	self:createGroupData(group_id)

	-- 生成竞技场数据
	local ch_arena = self:newChArena(character)

	-- 保存到DAO与DB
	self:saveChArenaData(  ch_arena, true )

	-- 排序
	self:sort(group_id)

	-- 发送报名成功
	self:sendArenaDataUpdate(character)
	self:sendBaomingSuc(character)

	return true
end

-- 判断是否在玩法时间内
function GlobalArenaService:isInActiveTime(  )
	-- 判断是否在活动时间内
	local active_obj = ActiveService:getActiveTime( Statics.PK_GAME_TYPE_ID_ZHUSHEN )
	local now_time = os.time()
	if active_obj.start_time >= now_time or active_obj.end_time <= now_time then
		return false
	end	
	return true
end

-- 发起挑战
function GlobalArenaService:startPk(character, passive_arena_id)
	-- 判断是否在活动时间内
	if not self:isInActiveTime() then 
		ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
		return false, errorCodes.COMMON_ACTIVE_IS_END
	end

	local my_arena = self:getArenaDt(character)
	if not my_arena then 
		return false, errorCodes.GLOBAL_ARENA_NOT_BAOMING
	end

	if self:isPKing(my_arena) then 
		return false, errorCodes.GLOBAL_ARENA_PKING
	end

	local my_arena_id = my_arena.id

	-- 检查参数
	if  passive_arena_id <= 0 then
		return false, errorCodes.COMMON_PARAM_ERROR
	end
	
	-- 检查是否在MAP1
	if g_mapserver_id ~= ARENA_MAP_ID then 
		return false, errorCodes.COMMON_PARAM_ERROR
	end
	
	-- 不能PK自己
	if passive_arena_id == my_arena_id then
		return false, errorCodes.GLOBAL_ARENA_CANNOT_PK_SELF
	end
	
	-- 获取对手的竞技场数据
	local passive_arena = self:getArenaDtById(passive_arena_id)
	if not passive_arena then 
		return false, errorCodes.GLOBAL_ARENA_PASSIVE_NOT_RIGHT
	end
	
	-- 查看是否还有次数
	local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_GLOBAL_ARENA)
	if en_count <= 0 then 
		return false, errorCodes.GLOBAL_ARENA_TIMES_UP
	end
	CounterService:addcount(character, counter)

	local is_need_pk = true
	
	-- 战力大于50%，不需要PK
	local beyond_fc = character.fight_capacity - passive_arena.ch_detail.fight_capacity
	if beyond_fc / passive_arena.ch_detail.fight_capacity >= ArenaDefs.MIAOSHA_NEED_BEYOND_FC_PERC then
		is_need_pk = false
	end
	
	-- 不需要PK
	if not is_need_pk then
		-- 直接PK完成
		self:finishPk( character,passive_arena_id, true, true )
		
	-- 需要PK
	else
		-- 记录正在PK中
		self:recordPKing(my_arena.id, passive_arena_id, self:getScore(my_arena, passive_arena))
		
		self:sendArenaPKStart(character, passive_arena_id)
	end
	return true
end

function GlobalArenaService:getScore(my_arena, passive_arena)
	local score = math.round(GlobalArenaDefs.SCORE_RADIUS * (passive_arena.score -my_arena.score ) + GlobalArenaDefs.SCORE_BASE)
	if score < GlobalArenaDefs.SCORE_MIN then score = GlobalArenaDefs.SCORE_MIN end
	if score > GlobalArenaDefs.SCORE_MAX then score = GlobalArenaDefs.SCORE_MAX end 
	return score	
end

-- 挑战完成
function GlobalArenaService:finishPk( character,passive_arena_id, is_win,  is_not_need_pk)
	if not self:isInActiveTime() then 
		ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
		return false, errorCodes.COMMON_ACTIVE_IS_END
	end

	local my_arena = self:getArenaDt(character)
	local passive_arena = self:getArenaDtById(passive_arena_id)

	-- 判断双方是否竞技场报过名
	if not my_arena or not passive_arena then 
		return false, errorCodes.COMMON_PARAM_ERROR
	end
	local old_rank = my_arena.rank
	local is_score_change = false

	-- 判断是否在PK中
	if not is_not_need_pk then 
		if not self:isPKing(my_arena) then 
			return false, errorCode.COMMON_PARAM_ERROR
		end
		if pking_data[my_arena.id].passive_arena_id ~= passive_arena_id then 
			return false, errorCodes.COMMON_PARAM_ERROR
		end
		if is_win then 
			if self:getScore(my_arena, passive_arena) ~= pking_data[my_arena.id].score then 
				is_score_change = true
			end
		end
	end

	-- 设置为不在PK中
	self:clearPKing(my_arena)

	-- 计算获得的积分
	local score = is_win and self:getScore(my_arena, passive_arena) or 0

	local del_score = 0

	-- 增加积分
	if score > 0 then 
		my_arena.score = my_arena.score + score

		-- 不是机器人则减少积分
		if not passive_arena.is_robot then
			del_score = math.ceil(score * GlobalArenaDefs.DEL_SCORE_RADIUS)
			if del_score > passive_arena.score then 
				del_score = passive_arena.score
			end
			passive_arena.score = passive_arena.score - del_score
			GlobalArenaService:saveChArenaScore( passive_arena )
			passive_arena.is_need_send_redflag = true

			-- 如果被打的玩家在线，通知玩家红点变化
			local passive_gcid = passive_arena.gcid
			local passive_character = CharacterService:getCharacterByGcid(passive_gcid)
			if passive_character then 
				GlobalArenaService:sendRedFlags(passive_character)
			end
		end

		-- 重新生成排名
		self:sort(my_arena.group_id)
	end

	-- 获取道具及荣誉奖励
	local reward_info = GlobalArenaService:assginRandReward(character, is_win)

	-- 记录荣誉并保存荣誉与积分
	my_arena.honour = my_arena.honour + reward_info.reward_honour	
	GlobalArenaService:saveChArenaScore( my_arena )

	-- 保存PK历史
	self:savePKHistory(character, my_arena, passive_arena, is_win, del_score)

	-- 发送奖励
	local reward_equips = reward_info.equips

	-- 到游戏服发奖
	RewardService:reward(Statics.PK_GAME_TYPE_ID_ZHUSHEN, 0, character.gpid, character.gcid, reward_equips)	

	-- 组装数据发到客户端
	local data = {}
	data.passive_arena_id = passive_arena_id
	data.is_win = is_win
	data.is_changed = old_rank == my_arena.rank
	data.is_need_pk = not is_not_need_pk
	data.reward_honour = reward_info.reward_honour
	data.is_uprank = old_rank > my_arena.rank
	data.reward_equip_id = reward_info.reward_equip_id
	data.reward_equip_num = reward_info.reward_equip_num
	data.score = score
	data.is_score_change = is_score_change
	data.rank = my_arena.rank

	-- 发送刷新包并发送PK完成
	self:sendArenaDataUpdate(character)	

	self:sendArenaPKFin(character, data)	

	-- 广播(进入前三)
	if old_rank > my_arena.rank and my_arena.rank <= 3 then 
		local area_ids = PkserverMappingService:getAreaids(my_arena.area_id,Statics.PK_GAME_TYPE_ID_ZHUSHEN) or {}
		for _, area_id in pairs(area_ids) do
			NoticeService:sysMsgWorld2GameSrv(area_id, OKMsgCodes.NOTICE_GLOBAL_ARENA_TOP3, {[1] = my_arena.ch_nick, [2] = my_arena.rank})
		end
	end

	local week_day = Time:getWeekDay()
	if old_rank > 40 and my_arena.rank <= 40 and week_day ~= 4 then 
		local area_ids = PkserverMappingService:getAreaids(my_arena.area_id,Statics.PK_GAME_TYPE_ID_ZHUSHEN) or {}
		for _, area_id in pairs(area_ids) do
			NoticeService:sysMsgWorld2GameSrv(area_id, OKMsgCodes.NOTICE_GLOBAL_ARENA_TOP40, {[1] = my_arena.ch_nick})
		end		
	end
	return true
end

-- 获取挑战历史记录
function GlobalArenaService:getPKHistory( character )
	local my_arena = assert(self:getArenaDt(character))
	return arenaid_2_history[my_arena.id], my_arena
end

function GlobalArenaService:m2d_getPKHistory( character )
	local my_arena = assert(self:getArenaDt(character))
	local arena_id = my_arena.id
	local data = {}
	data.arena_id =arena_id
	data.gcid = character.gcid 
	data.opcode = opCodes.M2D_GLOBAL_ARENA_GET_PK_LOG
	data.callback = "GlobalArenaService:d2m_getPkedHistory"

	WorldPacket:m2dSendOK(data, nil, character.gcid)
end

function GlobalArenaService:d2m_getPkedHistory( character, data )
	-- 保存起来
	local arena_id = data.arena_id
	local arena = self:getArenaDtById(arena_id)
	if arenaid_2_history[arena_id] then 
		return 
	end	
	arenaid_2_history[arena_id] = data.historys

	local gcid = data.gcid
	local character = CharacterService:getCharacterByGcid(gcid)
	if character then 
		self:sendPKHistory(character)
	end
end

do
	-- 保存PK历史
	local to_db_data = {}
	function GlobalArenaService:savePKHistory(character, my_arena, passive_arena, is_win, score )
		-- 挑战机器人的不需要保存
		if passive_arena.is_robot then 
			return 
		end

		-- 保存到被挑战者的数据中
		local data = {}
		to_db_data.data = data 
		data.arena_id = my_arena.id
		data.nick = my_arena.ch_detail.nick
		data.passive_arena_id = passive_arena.id
		data.passive_arena_nick = passive_arena.ch_detail.nick
		data.is_win = is_win and 1 or 0
		data.score = score
		data.created = os.time()

		-- 保存到数据库
		to_db_data.opcode = opCodes.M2D_GLOBAL_ARENA_SAVE_PK_LOG
		WorldPacket:m2dSendOK(to_db_data, nil, character.gcid)

		-- 如果已经加载被挑战者的挑战记录，则存储到内存中
		local passive_arena_id = passive_arena.id
		if arenaid_2_history[passive_arena_id] then 
			table.insert(arenaid_2_history[passive_arena_id], 1, data)
			if #arenaid_2_history[passive_arena_id] >  GlobalArenaDefs.PK_LOG_NUM then 
				table.remove(arenaid_2_history[passive_arena_id])
			end
		end
	end
end

function GlobalArenaService:recordPKing(my_arena_id, passive_arena_id, score)
	pking_data[my_arena_id] = {passive_arena_id=passive_arena_id, score=score}
end

function GlobalArenaService:isPKing( arena )
	return pking_data[arena.id]
end

function GlobalArenaService:clearPKing( arena )
	pking_data[arena.id] = nil
end

-- 获取随机的三名玩家
function GlobalArenaService:getRandomArenaChs( character )
	local random_arenas = {}

	-- 先从比玩家排行靠前的30名玩家中随机
	local ch_arena = assert(self:getArenaDt(character))

	local except_unique_ids = {[ch_arena.id] = 1}
	-- 排名在前面的30名玩家中的一个
	do
		local rank_from, rank_to = ch_arena.rank - 10, ch_arena.rank - 1
		if ch_arena.rank == 1 then -- 第一名玩家
			rank_from, rank_to = ch_arena.rank + 1, ch_arena.rank + 10
		elseif rank_from <= 0 then
			rank_from = 1
		end
		local arr_arenas = self:getChsInterRanks(rank_from, rank_to, except_unique_ids, ch_arena)
		if #arr_arenas <= 0 then 
			-- 前10名中没有可用之人
			rank_from, rank_to = ch_arena.rank - 31, ch_arena.rank + 31
			arr_arenas = self:getChsInterRanks(rank_from, rank_to, except_unique_ids, ch_arena)
		end

		if #arr_arenas > 0 then 
			local index = math.random(1, #arr_arenas)
			local ch = arr_arenas[index]
			table.insert(random_arenas, ch)
			except_unique_ids[ch.id] = 1
		end
	end


	-- 排名更后的30名玩家的一个
	do
		local rank_from, rank_to = ch_arena.rank + 1, ch_arena.rank + 10
		if ch_arena.rank == #ranks_with_robot then -- 第一名玩家
			rank_from, rank_to = ch_arena.rank - 10, ch_arena.rank - 1
		elseif rank_to > #ranks_with_robot then
			rank_from = #ranks_with_robot
		end
		local arr_arenas = self:getChsInterRanks(rank_from, rank_to, except_unique_ids, ch_arena)
		if #arr_arenas <= 0 then 
			rank_from, rank_to = ch_arena.rank - 32, ch_arena.rank + 32
			arr_arenas = self:getChsInterRanks(rank_from, rank_to, except_unique_ids, ch_arena)
		end

		if #arr_arenas > 0 then
			local index = math.random(1, #arr_arenas)
			local ch = arr_arenas[index]
			table.insert(random_arenas, ch)
			except_unique_ids[ch.id] = 1
		end
	end

	-- 随机的一名玩家
	do
		local rank_from, rank_to = ch_arena.rank - 10, ch_arena.rank + 10
		local arr_arenas = self:getChsInterRanks(rank_from, rank_to, except_unique_ids, ch_arena)
		if #arr_arenas <= 0 then 
			rank_from, rank_to = ch_arena.rank - 33, ch_arena.rank + 33
			arr_arenas = self:getChsInterRanks(rank_from, rank_to, except_unique_ids, ch_arena)
		end
		if #arr_arenas > 0 then
			local index = math.random(1, #arr_arenas)
			local ch = arr_arenas[index]
			table.insert(random_arenas, ch)
			except_unique_ids[ch.id] = 1
		end
	end
	return random_arenas
end

function GlobalArenaService:getChsInterRanks( from, to, except_unique_ids, req_ch_arena )
	local gang_uk = req_ch_arena.gang_uk
	local group_id = req_ch_arena.group_id
	local ret_arrs = {}
	for index = from, to do 
		local ch_arena = ranks_with_robot[group_id][index]
		if ch_arena and ch_arena.id ~= req_ch_arena.id and not except_unique_ids[ch_arena.id] and not (ch_arena.gang_uk == gang_uk and gang_uk ~= "") then 
			table.insert(ret_arrs, ch_arena)
		end
	end
	return ret_arrs
end

-- 保存角色竞技场数据
function GlobalArenaService:saveChArenaData(  ch_arena, is_to_db )
	table.insert(ranks_with_robot[ch_arena.group_id], ch_arena)
	table.insert(ranks[ch_arena.group_id], ch_arena)
	ch_arena_details[ch_arena.group_id][ch_arena.unique_key] = ch_arena
	arenaid_2_arena[ch_arena.id] = ch_arena

	if is_to_db then 
		local to_db_ch_data = {}
		to_db_ch_data.id = ch_arena.id
		to_db_ch_data.gcid = ch_arena.gcid
		to_db_ch_data.area_id = ch_arena.area_id
		to_db_ch_data.group_id = ch_arena.group_id
		to_db_ch_data.gang_uk = ch_arena.gang_uk
		to_db_ch_data.score = ch_arena.score
		to_db_ch_data.honour = ch_arena.honour
		to_db_ch_data.ch_detail = WorldPacket:encodeData(ch_arena.ch_detail)
		to_db_ch_data.created = os.time()
		to_db_ch_data.unique_key = ch_arena.unique_key
		to_db_ch_data.area_name = ch_arena.area_name
		to_db_ch_data.ch_nick = ch_arena.ch_nick
		to_db_ch_data.cid = ch_arena.cid
		to_db_ch_data.prof = ch_arena.prof
		to_db_ch_data.gender = ch_arena.gender
		to_db_ch_data.badge_id = ch_arena.badge_id
		to_db_ch_data.gang_title = ch_arena.gang_title
		to_db_ch_data.player_id = ch_arena.player_id


		-- 保存到数据库
		local to_db_data = {}
		to_db_data.opcode = opCodes.M2D_GLOBAL_ARENA_SAVE
		to_db_data.data = to_db_ch_data

		WorldPacket:m2dSendOK(to_db_data, nil, 0)
	end
end

function GlobalArenaService:saveChArenaScore( ch_arena )
	local to_db_ch_data = {}
	to_db_ch_data.area_id = ch_arena.area_id
	to_db_ch_data.gang_uk = ch_arena.gang_uk
	to_db_ch_data.score = ch_arena.score
	to_db_ch_data.honour = ch_arena.honour

	-- 保存到数据库
	local to_db_data = {}
	to_db_data.opcode = opCodes.M2D_GLOBAL_ARENA_UPDATE
	to_db_data.data = to_db_ch_data
	to_db_data.arena_id = ch_arena.id
	WorldPacket:m2dSendOK(to_db_data, nil, ch_arena.id)	
end
-- 保存机器人竞技场数据
function GlobalArenaService:saveRobotArenaData( robot_arena )
	table.insert(ranks_with_robot[robot_arena.group_id], robot_arena)
	arenaid_2_arena[robot_arena.id] = robot_arena
end

-- 创建某个大区的数据
function GlobalArenaService:createGroupData( group_id )
	if not ranks_with_robot[group_id] then 
		GlobalArenaDao.ranks_with_robot[group_id] = {}
		-- 初始化机器人
		for _, robot_arena in pairs(GlobalArenaDao.robots) do
			table.insert(GlobalArenaDao.ranks_with_robot[group_id], robot_arena)
		end
		GlobalArenaDao.ranks[group_id] = {}
		GlobalArenaDao.ch_arena_details[group_id] = {}
		GlobalArenaDao.toplist[group_id] = GlobalArenaDao.toplist[group_id] or {}
		GlobalArenaDao.uk_2_top[group_id] = GlobalArenaDao.uk_2_top[group_id] or {}
		self:sort(group_id)
	end
end

-- 排序
function GlobalArenaService:sort( group_id )
	table.sort(ranks[group_id], function ( l, r )
		if l.score ~= r.score then 
			return l.score > r.score
		else
			return l.created < r.created
		end
	end)
	for rank, ch_arena in ipairs(ranks[group_id]) do
		ch_arena.rank = rank
		ch_arena.oldrank = rank
	end

	table.sort(ranks_with_robot[group_id], function ( l, r )
		if l.score ~= r.score then 
			return l.score > r.score
		end
	end)
end

------------------------------------------------- 辅助 【BEG】--------------------------------
-- 获取角色的竞技场数据
function GlobalArenaService:getArenaDt( character )
	local group_id = PkserverMappingService:getGroupId(character,Statics.PK_GAME_TYPE_ID_ZHUSHEN)
	if not ch_arena_details[group_id] then 
		ch_arena_details[group_id] = {}
	end
	return ch_arena_details[group_id][character.unique_key]
end

function GlobalArenaService:getArenaDtByUk( unique_key, gid )
	local group_id = PkserverMappingService:getGroupIdByGid(gid,Statics.PK_GAME_TYPE_ID_ZHUSHEN)
	return ch_arena_details[group_id] and ch_arena_details[group_id][unique_key]
end

-- 通过竞技场Id获取竞技场数据
function GlobalArenaService:getArenaDtById( arena_id )
	return arenaid_2_arena[arena_id]
end

-- 获取排行榜数据
function GlobalArenaService:getToplist( unique_key, start_rank, num, gpid )
	local group_id = PkserverMappingService:getGroupIdByGid(gpid,Statics.PK_GAME_TYPE_ID_ZHUSHEN)
	self:createGroupData(group_id)

	local my_arena = self:getArenaDtByUk(unique_key, gpid)
	local my_rank =my_arena and my_arena.rank or 999
	local toplist = {}

	local src_data = ranks[group_id]

	local active_obj = ActiveService:getActiveTime( Statics.PK_GAME_TYPE_ID_ZHUSHEN )
	local now_time = os.time()
	if active_obj.prepare_time <= now_time and now_time <= active_obj.start_time  then
		if not next(ranks[group_id]) then 
			src_data = GlobalArenaDao.toplist[group_id]
			my_arena = GlobalArenaDao.uk_2_top[group_id][unique_key]
			my_rank = my_arena.rank or 999
		end
	end	
	src_data = src_data or {}

	for k=start_rank, start_rank + num - 1 do
		if src_data[k] then
			src_data[k].gang_badge_id = src_data[k].badge_id
			table.insert(toplist, src_data[k])
		end
	end
	local total_num = #src_data > ToplistDefs.toplist_zhushen_num and ToplistDefs.toplist_zhushen_num or #src_data
	return toplist, my_rank, total_num
end


-- 通过机器人数据创建竞技场数据
function GlobalArenaService:newRobotArena( robot, cid , nick)
	-- 创建一个character
	local robot = table.lightCopyTable(robot)	
	robot.id = cid
	robot.gpid = Utils.genSceneRobotGPid(robot)
	robot.gcid = Utils.genSceneRobotGCid(robot.id)
	robot.nick = nick
	-- 初始化机器人角色数据
	ChSkillService:initForRobot(robot)
	CharacterService:initObject(robot, false)
	robot.skills = nil
	
	SceneRobotService:newRobotChDetailByCharacter(robot)
	robot.ride_horse_id = 0
	robot.wing_base_id = 0
	robot.wuqi_eid = robot.wuqi_eid or 0
	robot.yifu_avatar_eid = robot.yifu_avatar_eid or 0
	robot.qihun_wuqi = robot.qihun_wuqi or 0
	robot.qihun_yifu = robot.qihun_yifu or 0
	robot.shenbing_eid = robot.shenbing_eid or 0
	robot.sb_skill_level = robot.sb_skill_level or 0
	robot.speed = 7

	local robot_arena = {}
	robot_arena.ch_detail = robot
	robot_arena.rank = -1
	robot_arena.score = 1000
	robot_arena.gang_uk = ""
	robot_arena.id = cid
	robot_arena.is_robot = true

	return robot_arena
end

-- 通过角色数据创建竞技场数据
do
function GlobalArenaService:newChArena( character )
	local ch_detail = self:newArenaChDetailByCharacter(character)

	local ch_arena = {}
	
	ch_arena.id = GlobalArenaDao:getArenaId()
	-- 所有属性
	ch_arena.ch_detail = ch_detail
	
	-- 角色相关
	ch_arena.gcid = character.gcid
	ch_arena.rank = -1
	ch_arena.oldrank = -1
	ch_arena.ch_nick = character.nick
	ch_arena.score = 1000
	ch_arena.unique_key = character.unique_key
	ch_arena.area_id = character.area_id
	ch_arena.cid = character.id
	ch_arena.player_id = character.player_id
	ch_arena.area_name  = character.area_name 
	ch_arena.prof = character.prof
	ch_arena.gender = character.gender
	ch_arena.honour = 0
	ch_arena.group_id = assert(PkserverMappingService:getGroupId(character,Statics.PK_GAME_TYPE_ID_ZHUSHEN))

	-- 军团相关
	ch_arena.gang_uk = character.gang_uk or ''
	ch_arena.badge_id = character.appear.badge_id or 0
	ch_arena.gang_title = character.gang_title or ''

	
	ch_arena.created = os.time()
	return ch_arena
end

-- 更新角色的竞技场数据
function GlobalArenaService:updateChArenaAttrib( character )
	local my_arena = self:getArenaDt(character)
	if my_arena then 
		local is_need_save = false
		if my_arena.ch_detail.fight_capacity ~= character.fight_capacity then
			local ch_detail = self:newArenaChDetailByCharacter(character)
			my_arena.ch_detail = ch_detail
		end
		character.gang_uk = character.gang_uk or ''
		my_arena.gang_uk = character.gang_uk or ''
		my_arena.badge_id = character.appear.badge_id or 0
		my_arena.gang_title = character.gang_title or ''
		my_arena.gang_id = character.gang_id or 0		
	end	
end

-- 游戏服传来的角色军团信息变更
function GlobalArenaService:updateChGangUk( unique_key, gang_uk, badge_id, gang_title, gcid )
	local my_arena = self:getArenaDtByUk( unique_key, gcid )
	if my_arena then 
		my_arena.gang_uk = gang_uk or ''
		my_arena.gang_title = gang_title or ''
		my_arena.badge_id = badge_id or 0
	end
end

end
-- 通过游戏对象Character 创建竞技场角色属性对象 ArenaChDetail
function GlobalArenaService:newArenaChDetailByCharacter(character)
	local arena_ch_detail = {}
	arena_ch_detail.id = character.id
	arena_ch_detail.gcid = character.gcid
	arena_ch_detail.nick = character.nick				-- 昵称
	arena_ch_detail.gender = character.gender			-- 性别
	arena_ch_detail.prof = character.prof				-- 职业
	arena_ch_detail.level = character.level				-- 等级

	arena_ch_detail.picture = character.picture			-- 头像
	arena_ch_detail.res_id = character.res_id			-- 头像

	arena_ch_detail.fight_capacity = character.fight_capacity		-- 战力
	arena_ch_detail.speed = character.speed							-- 速度
	
	arena_ch_detail.max_hp = character.max_hp						-- 最大MP值
	arena_ch_detail.max_hp2 = character.max_hp2	or 0				-- 最大MP值
	arena_ch_detail.max_hp3 = character.max_hp3	or 0				-- 最大MP值
	
	arena_ch_detail.max_attack = character.max_attack			-- 最大攻击
	arena_ch_detail.min_attack = character.min_attack			-- 最小攻击

	arena_ch_detail.defence_phy = character.defence_phy				-- 物理防御
	arena_ch_detail.defence_magic = character.defence_magic			-- 魔法防御

	arena_ch_detail.douzhi = character.douzhi						-- 斗志

	arena_ch_detail.critical_hit = character.critical_hit			-- 暴击
	arena_ch_detail.dodge = character.dodge							-- 闪避
	arena_ch_detail.parry = character.parry							-- 格挡
	arena_ch_detail.addi_harm = character.addi_harm					-- 附伤 附加伤害绝对值
	arena_ch_detail.addi_harm_perc = character.addi_harm_perc		-- 加伤 增加百分比伤害
	arena_ch_detail.reduce_harm = character.reduce_harm				-- 减伤：降低伤害绝对值
	arena_ch_detail.reduce_harm_perc = character.reduce_harm_perc	-- 免伤：降低百分比伤害
	arena_ch_detail.kill_force = character.kill_force				-- 斩杀力
	arena_ch_detail.luck = character.luck							-- 幸运
	
	arena_ch_detail.pets = character.pets
	arena_ch_detail.skills = character.skills
	arena_ch_detail.updated = Time:getSecondsNow()
	
	arena_ch_detail.gang_id = character.gang_id
	arena_ch_detail.ride_horse_id = character.horses.ride_horse_id or 0
	
	-- 外形相关
	local ch_appear = character.appear
	arena_ch_detail.qihun_wuqi = ch_appear.qihun_wuqi or 0
	arena_ch_detail.qihun_yifu = ch_appear.qihun_yifu or 0
	arena_ch_detail.wuqi_eid = ch_appear.weaponid or 0  --ChItemBarService:getWuqiEid(character)
	arena_ch_detail.yifu_avatar_eid = ChAppearService:getYifuOrAvatarForFight( ch_appear )
	arena_ch_detail.full_jl_lev = 0 -- ChItemBarStrongService:getFullReachJinglianLev(character)
	arena_ch_detail.wing_base_id = ch_appear.wing_base_id
	arena_ch_detail.shenbing_eid = ch_appear.shenbing or 0
	arena_ch_detail.sb_skill_level = ch_appear.sb_skill_level or 0
	self:initArenaChDetail(arena_ch_detail, true)
	
	return arena_ch_detail
end

-- 初始化竞技场角色属性
do
	local pet_fields = {'speed', 'max_hp', 'max_attack', 'min_attack', 
		'defence_phy', 'defence_magic', 'fight_capacity', 'douzhi', 'critical_hit', 'dodge',
		'parry', 'addi_harm', 'addi_harm_perc', 'reduce_harm', 'reduce_harm_perc', 
		'kill_force', 'luck', 'id', 'pet_id', 'level', 'star'
	}
	local pet_fields_hash = {}
	for _, field in pairs(pet_fields) do 
		pet_fields_hash[field] = true 
	end

	function GlobalArenaService:initArenaChDetail(arena_ch_detail, is_no_set_wing)
		-- 技能
		ChSkillService:initForRobot(arena_ch_detail)
		-- 幻兽
		ChPetService:initForRobot(arena_ch_detail)
		for _, pet in pairs(arena_ch_detail.heti_ch_pets) do
			for field, value in pairs(pet) do
				if not pet_fields_hash[field] then 
					pet[field] = nil
				end
			end
		end
		-- 拷贝出战幻兽的数据（角色的出战幻兽已经被使用）
		local arena_fight_ch_pet = nil
		if arena_ch_detail.arena_fight_ch_pet then
			arena_fight_ch_pet = {}
			for field, value in pairs(arena_ch_detail.arena_fight_ch_pet) do
				if pet_fields_hash[field] then 
					arena_fight_ch_pet[field] = value
				end
			end	
		end	
		arena_ch_detail.arena_fight_ch_pet = arena_fight_ch_pet			
	end
end

-- 生成竞技场战胜随机奖励
function GlobalArenaService:assginRandReward(character, is_win)
	local group_id = RandRewardPackDefs.RAND_REWARD_PACK_GID_ZHUSHENG
	local coeff = is_win and 1 or 0.5
	local reward_info = {}
	
	-- 奖励荣誉
	reward_info.reward_honour = is_win and 150 or 75

	if not is_win then 
		reward_info.reward_equip_id = 0
		reward_info.reward_equip_num = 0
		reward_info.equips = {}
	else
		local reward_equips = {}
		
		-- 随机道具奖励
		local reward_pack = RandRewardPackService:randRewardByGroupId(group_id, character.prof)
		local reward_chip_eid, reward_eid, reward_enum = reward_pack.baowu_chip_equip_id, reward_pack.equip_id, reward_pack.equip_num
		if reward_eid and reward_eid > 0 and reward_enum > 0 then
			reward_equips[reward_eid] = reward_enum
		elseif reward_chip_eid and reward_chip_eid > 0 then
			reward_equips[reward_chip_eid] = 1
		else
			Logger:fatal('[ArenaService:genRandReward] reward_eid is nil', reward_pack)
		end
		
		reward_info.equips = reward_equips
		reward_info.reward_equip_id, reward_info.reward_equip_num = next(reward_equips)
	end

	reward_info.equips[EquipDefs.FUNCTION_EQUIP_ID_HONOUR] = reward_info.reward_honour
	return reward_info
end

------------------------------------------------- 辅助 【END】--------------------------------



------------------------------------- 与客户端交互 【BEG】 ---------------------------


do	-- 发送跨服竞技场数据
	local rsp_opcode = opCodes.PKM2C_GLOBAL_ARENA_GET_INFO
	local msg_name = "PackGlobalArena.PKM2C_GLOBAL_ARENA_GET_INFO"
	local data = {}
	function GlobalArenaService:sendArenaData(character)

		local my_arena = self:getArenaDt(character)
		if my_arena then 
			local send_my_arena = {}
			send_my_arena.rank = my_arena.rank
			send_my_arena.score = my_arena.score
			send_my_arena.id = my_arena.id			
			if self:isInActiveTime() then 
				data.my_arena = send_my_arena	
				data.total_honour = my_arena.honour
				data.arenas = self:getRandomArenaChs(character)
			else
				data.history = send_my_arena
				data.my_arena = nil
				data.arenas = nil				
			end
		else
			data.my_arena = nil
			data.arenas = nil
			local group_id = PkserverMappingService:getGroupId(character, Statics.PK_GAME_TYPE_ID_ZHUSHEN)
			data.history = GlobalArenaDao.uk_2_top[group_id] and GlobalArenaDao.uk_2_top[group_id][character.unique_key]
		end
		data.score_radius = GlobalArenaDefs.SCORE_RADIUS
		data.score_base = GlobalArenaDefs.SCORE_BASE
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do	-- 发送跨服竞技场数据更新
	local rsp_opcode = opCodes.PKM2C_GLOBAL_ARENA_UPDATE
	local msg_name = "PackGlobalArena.PKM2C_GLOBAL_ARENA_UPDATE"
	local data = {}
	function GlobalArenaService:sendArenaDataUpdate(character)
		local my_arena = self:getArenaDt(character)
		if my_arena then 
			local send_my_arena = {}
			send_my_arena.rank = my_arena.rank
			send_my_arena.score = my_arena.score
			send_my_arena.id = my_arena.id

			data.total_honour = my_arena.honour
			data.my_arena = send_my_arena	
			
			data.arenas = self:getRandomArenaChs(character)
		else
			data.my_arena = nil
			data.arenas = nil
		end
--		Logger:info('GlobalArenaService:sendArenaDataUpdate', data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do	-- 发送报名成功
	local rsp_opcode = opCodes.PKM2C_GLOBAL_ARENA_BAOMING
	local msg_name = "PackGlobalArena.PKM2C_GLOBAL_ARENA_BAOMING"
	local data = {}
	function GlobalArenaService:sendBaomingSuc(character, ch_arena, comp_arenas)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do	-- 发送开始挑战
	local rsp_opcode = opCodes.PKM2C_GLOBAL_ARENA_PK_START
	local msg_name = "PackGlobalArena.PKM2C_GLOBAL_ARENA_PK_START"
	local data = {}
	function GlobalArenaService:sendArenaPKStart(character, passive_arena_id)

		data.passive_arena_id = passive_arena_id
--		Logger:info('sendArenaPKStart', data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do	-- 发送挑战完成
	local rsp_opcode = opCodes.PKM2C_GLOBAL_ARENA_PK_FINISH
	local msg_name = "PackGlobalArena.PKM2C_GLOBAL_ARENA_PK_FINISH"
	function GlobalArenaService:sendArenaPKFin(character, data)
--		Logger:info('GlobalArenaService:sendArenaPKFin', data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do	-- 发送挑战历史记录
	local rsp_opcode = opCodes.PKM2C_GLOBAL_ARENA_GET_HISTORY
	local msg_name = "PackGlobalArena.PKM2C_GLOBAL_ARENA_GET_HISTORY"
	local data = {}
	local my_arena 
	function GlobalArenaService:sendPKHistory(character)
		data.arr_pk_log, my_arena = self:getPKHistory(character)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
		if my_arena then 
			my_arena.is_need_send_redflag = false
		end
	end
end

do
	local rsp_opcode = opCodes.M2C_RED_FLAGS
	local msg_name = 'PackRedFlag.M2C_RED_FLAGS'
	local msg_proto = {}
	function GlobalArenaService:sendRedFlags(character)
		msg_proto.own_redflag_ids = {RedFlagDefs.RED_FLAG_ID_GLOBAL_ARENA}
		msg_proto.redflag_2_uptimes = nil
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

------------------------------------- 与客户端交互 【END】 ---------------------------
