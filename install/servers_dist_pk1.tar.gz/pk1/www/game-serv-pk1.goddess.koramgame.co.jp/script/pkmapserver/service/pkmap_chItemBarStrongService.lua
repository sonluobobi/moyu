--[[
角色装备栏强化信息强化系统servuce
author : xingzeng
date : 2014-08-15
]]--
local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local string_len = string.len
local type = type
local table = table
local random = math.random

local EquipDefs = EquipDefs
local EquipConfig = EquipConfig
local ChItemDefs = ChItemDefs
local ChItemPackage = ChItemPackage
local EffectType = EffectType
local EQUIPBAR_POS_WUQI = ChItemDefs.EQUIPBAR_POS_WUQI
local EQUIPBAR_POS_XIEZI = ChItemDefs.EQUIPBAR_POS_XIEZI

ChItemBarStrongService = ChItemBarStrongService or {}

function ChItemBarStrongService:onAfterLoadLua()
end

-- 初始化角色装备栏强化信息
function ChItemBarStrongService:init(character)
	local item_strongs_info = character.item_strongs_info
	
	if (type(item_strongs_info) == "string" and string_len(item_strongs_info) > 1) then
		item_strongs_info = WorldPacket:decodeData(item_strongs_info)
	else
		item_strongs_info = {}
	end
	
	character.item_strongs_info = item_strongs_info
	
	return true
end

-- 打包角色装备栏强化信息数据 (用户角色数据持久化/数据迁移)
function ChItemBarStrongService:pack(character)
	local str = WorldPacket:encodeData(character.item_strongs_info)
	return str
end

-- 获取全身精炼等级
function ChItemBarStrongService:getFullReachJinglianLev(character)
	local item_strongs_info = character.item_strongs_info
	if item_strongs_info then
		return item_strongs_info.reach_jl_lev or 0
	end
	
	return 0
end
