
SceneService = SceneService or 
{
	name = 'SceneService',
}

local WorldPacket = WorldPacket
local SceneDefs = SceneDefs
local pairs = pairs
local Utils = Utils
local SceneBaseDao = SceneBaseDao
local SceneAoiService
local errorCodes = errorCodes
local Time = Time
local move_ret_opcode = opCodes.M2C_SCENE_MOVE_SCENE
local GameObjectService

-- 加载或热更新LUA代码完成
function SceneService:onAfterLoadLua()
	SceneAoiService = _G.SceneAoiService
	GameObjectService = _G.GameObjectService
end

-- 初始化角色场景数据
function SceneService:init(character)
	local scenes = character.scenes
	if scenes and scenes ~= '' then
		scenes = WorldPacket:decodeData(scenes)
	else
		scenes = {}
	end	
	character.scenes = scenes	
end

-- 向框架层发起进入场景请求
do
	local externalRequestSpace = external.requestSpace
	local params = {}
	function SceneService:requestEnterScene(character, dst_scene_id, line_id, dst_space_id ,packet_id, from_space_id)
		local packet = WorldPacket:newPacket(0, packet_id, character.gcid)
		params.scene_id = dst_scene_id
		params.line_id = line_id
		params.space_id = dst_space_id
		params.from_space_id = from_space_id
		packet:writeTable(params)
		externalRequestSpace(character.gcid,packet)
		
		-- 设置开始进入场景时间
		character.tmps.moving_scene_stime = Time.time_now
	end
end

---场景移动
do
	function SceneService:moveScene(character, dst_scene_id, dst_space_id, line_id, x, y, is_no_check)
		local packet_id = WorldPacket.g_packet_id
		if Utils.isFromCommand(packet_id) then packet_id = 0 end
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		local gpid = character.gpid
		
		-- 检查当前是否正在移动场景中
		if self:isMovingScene(character) then
			Logger:debug('[SceneService:moveScene] is busing.', character.id, character.player_id, dst_scene_id, dst_space_id)
			return false
		end
		
		local scene_base = aoi_scene.scene_base
		
		-- 检查当前场景是否可以离开
		local ret, msg_id , msg_param = SceneEventService:checkLeaveScene(character, aoi_scene)
		if not ret then
			WorldPacket:m2cSendErr(move_ret_opcode, packet_id, gpid, msg_id, msg_param)
			return false
		end
		
		local dst_scene_base = SceneBaseService:getSceneBaseById(dst_scene_id)
		if not dst_scene_base then
			WorldPacket:m2cSendErr(move_ret_opcode, packet_id, gpid, 'SCENE_ID NOT EXISTS ' .. dst_scene_id)
			return false
		end
		
		-- 检查进入角色等级限制
		if dst_scene_base.ch_level > character.level then
			local msg_id = errorCodes.CH_LEVEL_NOT_ENOUGH
			WorldPacket:m2cSendErr(move_ret_opcode, packet_id, gpid, msg_id)
			return false
		end		
		
		-- 检查目的场景是否可以进入
		if not is_no_check then
			local ret, err_id, err_params = SceneEventService:checkEnterScene(character, aoi_scene, dst_scene_base)
			if not ret then
				WorldPacket:m2cSendErr(move_ret_opcode, packet_id, gpid, err_id, err_params)
				return  false
			end
		end
		
		-- 随机一个传入点 进入目标场景
		if not x or not y or x <= 0 or y <= 0 then
			x,y = SceneAoiService:getRandomTransferInForNormal(dst_scene_base.id)
			if not x then
				WorldPacket:m2cSendErr(move_ret_opcode,packet_id,character.gpid,errorCodes.SCENE_ERROR_NOT_DEFAULT_POS, dst_scene_id)
				return false
			end
		end
		
		-- 设置进入目标场景的具体x,y位置
		local scenes = character.scenes
		scenes.next_x = x
		scenes.next_y = y		
		
		-- 请求进入场景
		self:requestEnterScene(character, dst_scene_id, line_id, dst_space_id, packet_id, aoi_scene.space_id)
		
		return true
	end
end

-- 回到到最后一次所在主城(简称：回城)
do
	function SceneService:moveToLastScene(character, is_relive, last_x, last_y)
		local aoi_scene = GameObjectService:getAoiScene(character)
		local scene_base = aoi_scene.scene_base
		local gpid = character.gpid
		local packet
		
		-- 已经在主城
		if SceneDefs:isNormalScene(scene_base) then
			WorldPacket:m2cSendCommEmpty()
			--WorldPacket:m2cSendErr(move_ret_opcode,packet,gpid,errorCodes.SCENE_ERROR_CAN_NOT_LEAVE)
			return
		end
		
		local scenes = character.scenes
		local last_scene_id, x, y  = scenes.last_scene_id, scenes.last_x, scenes.last_y
		
		-- 数据错误：最后所在一次主城场景ID不对
		if last_scene_id == scene_base.id then
			WorldPacket:m2cSendCommEmpty()
			--WorldPacket:m2cSendErr(move_ret_opcode,packet,gpid,errorCodes.SCENE_ERROR_CAN_NOT_LEAVE)
			return
		end
		
		-- 在(创建角色后进入的)新手村场景
		if not last_scene_id and scene_base.id == CharacterDefs.CHARACTER_DEFAULT_SCENE_ID then		
			-- 报错，不应该有回城操作
			WorldPacket:m2cSendErr(move_ret_opcode,packet,gpid,errorCodes.SCENE_IN_NEWCOMER_CANNOT_BACK_MCITY)
			return
		end
		
		-- 数据错误：没有最后所在一次主城场景ID
		if not (last_scene_id and x and y) then
			WorldPacket:m2cSendErr(move_ret_opcode,packet,gpid,errorCodes.SCENE_ERROR_NO_LAST_SCENE_INFO)
			return
		end
		if last_scene_id <= 0 then
			WorldPacket:m2cSendErr(move_ret_opcode,packet,gpid,errorCodes.SCENE_ERROR_LAST_SCENE_INFO_ERROR)
			return
		end
		
		if last_x and last_y and last_x > 0 and last_y > 0 then
			local last_scene_base = SceneBaseDao[last_scene_id]
			if last_scene_base.res_id == scene_base.res_id then
				x, y = last_x, last_y
			end
		end
		
		-- 进入场景复活角色对象
		if is_relive and character.hp <= 0 then
			GameObjectService:playerRelive(aoi_scene, character)
		end
		
		-- 进入主城
		self:moveScene(character, last_scene_id, scenes.last_space_id, scenes.last_line_id, x, y)	
	end
end

-- 缺省场景实例初始化函数
do
	local AoiObjectType = AoiObjectType
	local Monster = Monster
	local TransferDot = TransferDot
	
	local pairs = pairs
	local AoiObject = AoiObject
	local error = error
	
	local MonsterBaseDao = MonsterBaseDao
	
	local Monster_new = Monster.new
	local AoiObject_new = AoiObject.new
	local next = next
	local obj_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
	
	function SceneService:onInitSceneDefault(character, aoi_scene, phase_id)	
		local scene_base = aoi_scene.scene_base
		local is_local_ai =  scene_base.is_local_ai	== 1
		
		-- 客户端本地化关卡(场景AI和通关等逻辑客户端实现) 服务端不做初始化
		if is_local_ai then
			return
		end
		
		-- 获取怪物SceneAoi对象列表
		local obj_type = obj_type_monster
		local monster_sceneaois = SceneAoiService:getInitObjsByType( aoi_scene.scene_id, obj_type )		
		if not monster_sceneaois or not next(monster_sceneaois) then		
			return		
		end		
		
		-- 创建怪物 游戏实例对象、 AOI 实例对象
		local aoi_objs = {}
		local game_objs = {}
		local i=0
		for _, monster_sceneaoi in pairs(monster_sceneaois) do
			if not phase_id or monster_sceneaoi.phase_id == phase_id then
				local base_id = monster_sceneaoi.class_id
				local monster_base = MonsterBaseService:getMonsterBaseById(base_id)
				if not monster_base then
					error("can not found monster " .. base_id)
				end				
				
				local x,y = monster_sceneaoi.x,monster_sceneaoi.y
				local monster = Monster_new(Monster, monster_base, monster_sceneaoi)
				local aoi_obj = AoiObject_new(AoiObject, obj_type, x, y, monster_sceneaoi.direction, monster, aoi_scene)					
				i = i + 1
				aoi_objs[i] = aoi_obj
				game_objs[i] = monster
			end
		end
		
		-- 并添加AOI对象列表到场景实例内
		GameObjectService:addObjs(game_objs, aoi_objs, aoi_scene)
	end
end

--- 判断是否在场景移动中
-- @return 是否在移动中
function SceneService:isMovingScene( character )
	local moving_scene_stime = character.tmps.moving_scene_stime or 0
	-- 5秒后认为已经切换场景完成
	return moving_scene_stime + 5000 > Time.time_now
end

--- 玩家是否在进入场景中
-- 当客户端已经加载场景完成 才算进入场景完成
function SceneService:isEnteringScene(character)
	local entering_scene_stime = character.tmps.entering_scene_stime or 0
	return entering_scene_stime > Time.time_now
end

do
	local AoiObject = AoiObject
	local splitUInt = external.splitUInt
	--- 对象进入视野
	-- @param aoi_obj              发起者
	-- @param arr_disappear_objs   对象数组, 可能为空
	local aoi_objs = {}
	local AOI_OBJECT_TYPE_ID_PLAYER = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
	function SceneService:appearAoi(aoi_scene, aoi_obj, arr_appear_aoi_objs)	
		if not arr_appear_aoi_objs or not arr_appear_aoi_objs[1] then return end
		--PKTEST
		if aoi_obj.obj_type == 1 then
			--local _, pid = splitUInt(aoi_obj.gpid)
			--Logger:debug('[SceneService:appearAoi] ', pid, #arr_appear_aoi_objs)
		end
		
		-- 发送自己给其他玩家
		local pids = aoi_scene:getGPidsByAoiObjs(arr_appear_aoi_objs)
		if pids then
			aoi_objs[1] = aoi_obj
			self:sendAppearPacket( aoi_scene, pids, aoi_objs)
		end	
		
		-- 发送其他玩家给自己
		if aoi_obj.obj_type == AOI_OBJECT_TYPE_ID_PLAYER then	
			self:sendAppearPacket( aoi_scene, aoi_obj.gpid , arr_appear_aoi_objs)				
		end
		
		-- 更新怪物视野的玩家数量
		self:_update_aoiobj_visibility( aoi_obj, arr_appear_aoi_objs, true )
	end
	
	--- 对象离开视野
	-- @param aoi_obj              离开场景/移动 的发起者
	-- @param arr_disappear_objs   消失的对象数组, 可能为空
	function SceneService:disappearAoi(aoi_scene,aoi_obj, arr_disappear_objs)
		if not arr_disappear_objs or not arr_disappear_objs[1] then return end
		
		-- 发送自己给他人
		local pids = aoi_scene:getGPidsByAoiObjs(arr_disappear_objs )
		if pids then
			aoi_objs[1] = aoi_obj
			self:sendDisappearPacket( aoi_scene, pids, aoi_objs)
		end
		
		-- 发送他人给自己
		if aoi_obj.obj_type == AOI_OBJECT_TYPE_ID_PLAYER then
			self:sendDisappearPacket( aoi_scene, aoi_obj.gpid, arr_disappear_objs)
		end
		
		-- 更新怪物可见度
		self:_update_aoiobj_visibility( aoi_obj, arr_disappear_objs, false )
	end
end

--- 更新怪物/陷阱可见度, 可见度=怪物/陷阱看见几个玩家
do
	local obj_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
	local obj_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
	local obj_type_trap = AoiObjectType.AOI_OBJECT_TYPE_ID_TRAP
	function SceneService:_update_aoiobj_visibility(aoi_obj, arr_aoi_obj, badd)
		local nadd = badd and 1 or -1	
		local obj_type = aoi_obj.obj_type
		
		-- 玩家主动触发
		if obj_type == obj_type_player then
			for i=1,#arr_aoi_obj do
				local aoi_obj_t = arr_aoi_obj[i]
				local obj_type_t = aoi_obj_t.obj_type
				
				-- 修改改怪物/陷阱的可见度
				if obj_type_t == obj_type_monster or obj_type_t == obj_type_trap then
					local see_player_num = aoi_obj_t.see_player_num + nadd
					if see_player_num < 0 then see_player_num = 0 end
					aoi_obj_t.see_player_num = see_player_num
				end
			end
			
		-- 怪物/陷阱主动触发
		elseif obj_type == obj_type_monster or obj_type == obj_type_trap then
		-- 统计玩家个数
			local num_player = 0
			for i=1,#arr_aoi_obj do
				local aoi_obj_t = arr_aoi_obj[i]
				if aoi_obj_t.obj_type == obj_type_player then
					num_player = num_player + 1 
				end
			end
			
			-- 修改改怪物/陷阱的可见度
			local see_player_num = aoi_obj.see_player_num + nadd*num_player
			if see_player_num < 0 then see_player_num = 0 end
			aoi_obj.see_player_num = see_player_num
		end
	end
end

--- 当玩家被复活时, 移动玩家到复活点位置(修改位置或切换场景)
function SceneService:setReliverPosition(character)
	local aoi_scene = GameObjectService:getAoiScene(character)
	local is_back_to_mcity, x, y = SceneEventService:getRelivePos(character, aoi_scene)
	
	if is_back_to_mcity == false then
		if not x or not y then
			Logger:fatal(x, y, aoi_scene.scene_id, character.nick)
		end
		MotionService:shunYi(character, x, y)
	else
		ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
		-- 跨服不支持回主城复活
		Logger:error('[SceneService:setReliverPosition] 跨服不支持回主城复活', character.player_id, character.nick, character.id, aoi_scene.scene_id)
	end
end

---视野出现
do
	local M2C_SCENE_OBJ_APPEAR = opCodes.M2C_SCENE_OBJ_APPEAR
	local fast_packet = FastPacket(12*1024)
	local packetSize = FastPacket.size
	local writeUInt = Packet.writeUInt
	local writeUShort = Packet.writeUShort
	local fast_writeUInt = FastPacket.writeUInt
	local fast_writeUShort = FastPacket.writeUShort
	
	function SceneService:sendAppearPacket(aoi_scene, gpid, arr_appear_aoi_objs)
		local objs_len = #arr_appear_aoi_objs
		if objs_len <= 0 then return end
		
		-- 清空PACKET (fast_packet 对象会重用)
		WorldPacket:resetWritePacket(fast_packet,opCodes.M2C_SCENE_OBJ_APPEAR)
			
		fast_writeUInt(fast_packet, aoi_scene.space_id)
		fast_writeUShort(fast_packet, objs_len)
		
		local getGameObjectByAoiId = GameObjectService.getGameObjectByAoiId
		local writeObjAppear = GameObjectService.writeObjAppear
		
		for i = 1, objs_len do
			local aoi_obj = arr_appear_aoi_objs[i]			
			local obj_type = aoi_obj.obj_type
			local game_obj = getGameObjectByAoiId(GameObjectService, aoi_scene, aoi_obj.obj_id)
			
			writeObjAppear(GameObjectService, game_obj, fast_packet)
		end
				
		local packet = WorldPacket:newClientPacket(M2C_SCENE_OBJ_APPEAR, WorldPacket.g_packet_id, gpid, packetSize(fast_packet) + 4)		
		packet:writeVer()		
		packet:writeFastPacketRaw(fast_packet)
		
		-- RSP
		WorldPacket:m2cSendPacket(packet)
	end
	
	-- 发送详细外观信息
	local appear_opcode = opCodes.M2C_SCENE_GET_OBJ_APPEAR_DATA
	function SceneService:sendAppearDetailPacket(space_id, game_objs, gpid)
		local len = #game_objs
		if len == 0 then return end
		if not gpid then
			Logger:fatal('[SceneService:sendAppearDetail] gpid err', space_id)
		end
		
		local packet = WorldPacket:newClientPacket(appear_opcode, nil, gpid, 512*len)--opCodes.M2C_SCENE_GET_OBJ_APPEAR_DATA		
		packet:writeVer()		
		
		writeUInt(packet,space_id)
		writeUShort(packet,len)
		
		local writeObjAppearDetail = GameObjectService.writeObjAppearDetail
		for _, game_obj in pairs(game_objs) do
			writeObjAppearDetail(GameObjectService, game_obj, packet)
		end
		
		WorldPacket:m2cSendPacket(packet)
	end
	
	local appear_detail_opcode = opCodes.M2C_SCENE_OBJ_APPEAR_DATA_UPDATE
	local msg_name = "PackAoi.M2C_SCENE_OBJ_APPEAR_DATA_UPDATE"
	function SceneService:sendAppearDetailUpdate(aoi_scene, game_obj, update_data, is_only_to_self, to_gpids)
		local gpids = to_gpids or (is_only_to_self and game_obj.gpid or GameObjectService:getFovGPids(game_obj, aoi_scene))
		if not gpids or gpids == 0 or (type(gpids) == 'table' and not next(gpids)) then
--			Logger:debug('[SceneService:sendAppearDetailUpdate] gpids is nil.', game_obj.aoi_id, game_obj.aoi_type)--, debug_traceback(2,6))
			return
		end
		
		local msg_proto = table.lightCopyTable(update_data)
		msg_proto.aoi_id = game_obj.aoi_id
		msg_proto.aoi_type = game_obj.aoi_type
		msg_proto.appear_ver = game_obj.tmps.appear_ver
		WorldPacket:m2cSendOKProtoBuf(appear_detail_opcode, msg_name, msg_proto, nil, gpids)
	end
	
	function SceneService:sendAppearDetailUpdateEx(aoi_scene, game_obj, fields, is_only_to_self, to_gpids)
		local gpids = to_gpids or (is_only_to_self and game_obj.gpid or GameObjectService:getFovGPids(game_obj, aoi_scene))
		if not gpids or gpids == 0 or (type(gpids) == 'table' and not next(gpids)) then
--			Logger:debug('[SceneService:sendAppearDetailUpdate] gpids is nil.', game_obj.aoi_id, game_obj.aoi_type, debug_traceback(2,6))
		end
		
		local msg_proto = {}
		msg_proto.aoi_id = game_obj.aoi_id
		msg_proto.aoi_type = game_obj.aoi_type
		msg_proto.appear_ver = game_obj.tmps.appear_ver
		for _, field in pairs(fields) do
			if field == 'ride_horse_id' then
				msg_proto[field] = game_obj.horses.ride_horse_id or 0
			else
				msg_proto[field] = game_obj[field]
			end
		end
		WorldPacket:m2cSendOKProtoBuf(appear_detail_opcode, msg_name, msg_proto, nil, gpids)
	end

end

do
	local opcode = opCodes.M2C_SCENE_OBJ_APPEAR_UPDATE
	local msg_name = "PackAoi.M2C_SCENE_OBJ_APPEAR_UPDATE"
	function SceneService:sendAppearUpdate(aoi_scene, game_obj, update_data, is_only_to_self, to_gpids)
		local gpids = to_gpids or (is_only_to_self and game_obj.gpid or GameObjectService:getFovGPids(game_obj, aoi_scene))
		if not gpids or gpids == 0 or (type(gpids) == 'table' and not next(gpids)) then
--			Logger:debug('[SceneService:sendAppearDetailUpdate] gpids is nil.', game_obj.aoi_id, game_obj.aoi_type)--, debug_traceback(2,6))
			return
		end
		
		local msg_proto = table.lightCopyTable(update_data)
		msg_proto.aoi_id = game_obj.aoi_id
		msg_proto.aoi_type = game_obj.aoi_type
		WorldPacket:m2cSendOKProtoBuf(opcode, msg_name, msg_proto, nil, gpids)
	end
end

---视野消失
do
	local M2C_SCENE_OBJ_DISAPPEAR = opCodes.M2C_SCENE_OBJ_DISAPPEAR
	local writeUInt = Packet.writeUInt
	local writeUShort = Packet.writeUShort
	
	function SceneService:sendDisappearPacket( aoi_scene, gpid, arr_disappear_aoi_objs)
		local objs_len = #arr_disappear_aoi_objs		
		if objs_len < 0 then return end
		
		local packet = WorldPacket:newClientPacket(M2C_SCENE_OBJ_DISAPPEAR, WorldPacket.g_packet_id, gpid , objs_len*4 + 10)		
		packet:writeVer()		
		
		writeUInt(packet,aoi_scene.space_id)
		writeUShort(packet,objs_len)	
		
		for i=1,objs_len do
			local aoi_obj = arr_disappear_aoi_objs[i]
			writeUInt(packet, aoi_obj.obj_id )
			--print('aoi del', aoi_scene.space_id, aoi_obj.obj_type, aoi_obj.obj_id, aoi_obj.x, aoi_obj.y)
		end
		WorldPacket:m2cSendPacket(packet)
	end
end

do
	local rsp_opcode = opCodes.M2C_SCENE_FIND_MONSTER
	local msg_name = "PackScene.M2C_SCENE_FIND_MONSTER"
	local msg_proto = {}
	function SceneService:sendFindMonster(character, monster)
		local aoi_obj = monster.aoi_obj
		msg_proto.monster_base_id = monster.monster_base.id
		msg_proto.x = aoi_obj.x
		msg_proto.y = aoi_obj.y
		msg_proto.aoi_id = aoi_obj.obj_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_SCENE_FIND_AOI_OBJ
	local msg_name = "PackScene.M2C_SCENE_FIND_AOI_OBJ"
	local msg_proto = {}
	function SceneService:sendFindAoiObj(character, target_aoi_type, aoi_obj)
		msg_proto.target_aoi_type = target_aoi_type
		msg_proto.target_x = aoi_obj and aoi_obj.x or 0
		msg_proto.target_y = aoi_obj and aoi_obj.y or 0
		msg_proto.target_aoi_id = aoi_obj and aoi_obj.obj_id or 0
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

-- 打包角色场景数据
function SceneService:pack(character)
	return WorldPacket:encodeData(character.scenes)
end
