
GameObjectService = GameObjectService or {}

local assert = assert
local mathCeil = math.ceil
local mathRandom = math.random
local AoiObject = AoiObject
local pairs = pairs
local next = next
local type = type
local Time = Time
local WorldPacket = WorldPacket
local Formula = Formula

local AoiObjectType = AoiObjectType
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local aoi_type_pet = AoiObjectType.AOI_OBJECT_TYPE_ID_PET
local aoi_type_robot = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
local aoi_type_trap = AoiObjectType.AOI_OBJECT_TYPE_ID_TRAP
local aoi_type_beast = AoiObjectType.AOI_OBJECT_TYPE_ID_BEAST
local aoi_type_guard_npc = AoiObjectType.AOI_OBJECT_TYPE_ID_GUARD_NPC
local aoi_type_item = AoiObjectType.AOI_OBJECT_TYPE_ID_ITEM

local wanfa_aoi_data_scene_sorts_ht = SceneDefs.wanfa_aoi_data_scene_sorts_ht
local small_map_scene_sorts = SceneDefs.small_map_scene_sorts
local Statics = Statics
local AoiSceneService
local MotionService
local BufferService, TeamService

function GameObjectService:onAfterLoadLua()
	AoiSceneService = _G.AoiSceneService
	MotionService = _G.MotionService
	BufferService = _G.BufferService
	TeamService = _G.TeamService
end

-- 获取game_obj的aoi_scene 和 aoi_obj
do
	function GameObjectService:getAoiScene(game_obj)
		return AoiSceneService:getAoiScene(game_obj.space_id)
	end
	
	function GameObjectService:getAoiSceneBySpaceId(space_id)
		return AoiSceneService:getAoiScene(space_id)
	end
	
	function GameObjectService:getAoiSceneAndAoiObj(game_obj)
		return AoiSceneService:getAoiScene(game_obj.space_id), game_obj.aoi_obj
	end
end

-- 获取游戏对象
-- 注：如果已从AOI里面删除，则不会获取到该game obj
-- aoi_scene	场景实例对象
-- aoi_id		AOI ID
-- is_get_hide	是否获取隐藏的对象
-- return game_obj 游戏对象
function GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id, is_get_hide)
	if true ~= is_get_hide and not aoi_scene:getObj(aoi_id) then return end
	
	local aoi_id2game_objs = aoi_scene.aoi_id2game_objs
	return aoi_id2game_objs[aoi_id]
end
function GameObjectService:getGameObjectByAoiObj(aoi_obj)
	local aoi_scene = AoiSceneService:getAoiScene(aoi_obj.space_id)
	local aoi_id2game_objs = aoi_scene.aoi_id2game_objs
	return aoi_id2game_objs[aoi_obj.obj_id]
end

-- 获取游戏对象列表
-- 注：如果已从AOI里面删除，则不会获取到该game obj
function GameObjectService:getGameObjectsByAoiIds(aoi_scene, aoi_ids)
	local aoi_id2game_objs = aoi_scene.aoi_id2game_objs
	local game_objs = {}
	local getObj = AoiScene.getObj
	
	for _, aoi_id in pairs(aoi_ids) do
		if getObj(aoi_scene, aoi_id) then
			game_objs[#game_objs+1] = aoi_id2game_objs[aoi_id]
		end
	end
	
	return game_objs
end

-- 获取AOI对象
function GameObjectService:getAoiObjByGameObj(game_obj)
	return game_obj.aoi_obj
end

-- 获取game_obj视野内的玩家global player ids
-- game_obj		游戏对象 如 character ch_pet monster
-- aoi_scene	场景实例对象	可不传该参数
-- filter_gpid	需要过滤掉的gpid
-- return nil/arr_gpid		nil/返回gpid数组
function GameObjectService:getFovGPids(game_obj, aoi_scene, filter_gpid)
	local aoi_obj = game_obj and game_obj.aoi_obj or nil
	if not aoi_scene then
		aoi_scene, aoi_obj = self:getAoiSceneAndAoiObj(game_obj)
	end	
	
	-- 获取视野内所有AOI对象列表
	local aoi_objs = aoi_scene:getFovObjs(aoi_obj, aoi_type_player)	
	local len = #aoi_objs
	if len == 0 then
		--Logger:debug('[GameObjectService:getFovGPids] getFov 返回数据为空', game_obj.id, game_obj.aoi_type, game_obj.player_id, debug_traceback(2, 4))
		return nil
	end
	
	local x = 0
	local pids = {}		
	for i=1,len do		
		local gpid = aoi_objs[i].gpid		
		if gpid and gpid ~= filter_gpid then
			x = x + 1
			pids[x] = gpid 
		end
	end
	
	return x > 0 and pids or nil
end

-- 获取战斗需要广播的对象列表
-- game_obj 			攻击者对象
-- aoi_scene 			所在场景实例
-- bc_num 				广播的总人数(含主角自己)
-- need_bc_game_objs 	需要广播的对象列表
-- return gpids:array	gpid列表(如果是玩家会含自己)
local TianmoConfig = TianmoConfig
local CHARACTER_FOV_SIZE = CharacterDefs.CHARACTER_FOV_SIZE
function GameObjectService:getBcGPidsForFight(game_obj, aoi_scene, bc_num, need_bc_game_objs)
	local need_gpids, gpid_num = {}, 0
	if game_obj.gpid then
		gpid_num = gpid_num + 1
		need_gpids[game_obj.gpid] = 1
	elseif game_obj.parent_gpid then
		gpid_num = gpid_num + 1
		need_gpids[game_obj.parent_gpid] = 1
	end

	if game_obj.aoi_type ~= aoi_type_monster and aoi_scene.scene_id == TianmoConfig.boss_room_scene_id then
		bc_num = 5
		
		-- 把队友加入
		local team = TeamService:getTeamByGCid(game_obj.gcid)
		if team and team.members then
			local members = team.members
			for k, member in pairs(members) do
				if not TeamService:isRobot(member) then 
					need_gpids[member.gpid] = 1
				end
			end
		end
	end
	
	if need_bc_game_objs then
		for _, game_obj_t in pairs(need_bc_game_objs) do
			if game_obj_t.aoi_type == aoi_type_player and not need_gpids[game_obj_t.gpid] then
				gpid_num = gpid_num + 1
				need_gpids[game_obj_t.gpid] = 1
			end
		end
	end
	
	local arr_need_gpid = table.keys(need_gpids)
	
	if gpid_num >= bc_num then
		return arr_need_gpid
	end
	
	local aoi_obj = game_obj and game_obj.aoi_obj or nil
	if not aoi_scene then
		aoi_scene, aoi_obj = self:getAoiSceneAndAoiObj(game_obj)
	end	
	
	-- 获取视野内所有AOI对象列表
	local aoi_objs = aoi_scene:getFovObjs(aoi_obj, aoi_type_player)	
	local len = #aoi_objs
	if len == 0 then
		return arr_need_gpid
	end
		
	-- 为了避免傻呆着不动，这里先取半视野内的对象
	if aoi_scene.scene_id == TianmoConfig.boss_room_scene_id then
		local fov_size_half_sqr = CHARACTER_FOV_SIZE*CHARACTER_FOV_SIZE/4
		local x1, y1 = aoi_obj.x, aoi_obj.y
		
		for i=1,len do
			if gpid_num >= bc_num then break end
			
			local aoi_obj_t = aoi_objs[i]
			local gpid = aoi_obj_t.gpid	
			if gpid and not need_gpids[gpid] then
				local x2, y2 = aoi_obj_t.x, aoi_obj_t.y
				if (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2) < fov_size_half_sqr then
					gpid_num = gpid_num + 1
					arr_need_gpid[gpid_num] = gpid
					need_gpids[gpid] = 1
				end
			end
		end
	end
	
	for i=1,len do
		if gpid_num >= bc_num then break end
		
		local gpid = aoi_objs[i].gpid		
		if gpid and not need_gpids[gpid] then
			gpid_num = gpid_num + 1
			arr_need_gpid[gpid_num] = gpid 
		end
	end
	
	return arr_need_gpid
end

-- 根据 game obj 数组获取
-- return nil/arr_gpid, len		nil/返回gpid数组, 数组长度
function GameObjectService:getGPidsByGameObjs(arr_game_objs)
	local len = 0
	local gpids = {}
	local num = #arr_game_objs
	for i = 1, num do
		local game_obj = arr_game_objs[i]
		if game_obj.aoi_type == aoi_type_player then		
			local gpid = game_obj.gpid
			if gpid and gpid > 0 then
				len = len + 1
				gpids[len] = gpid
			end
		end		
	end	
	return len>0 and gpids or nil, len
end

-- 获取场景内所有的玩家gpid
function GameObjectService:getGPids(aoi_scene, exclude_gpid)
	local arr_game_objs = self:getGameObjsByType(aoi_scene, aoi_type_player)
	local len = 0
	local gpids = {}
	for _, game_obj in pairs(arr_game_objs) do
		local gpid = game_obj.gpid
		if gpid and gpid > 0 and (not exclude_gpid or gpid ~= exclude_gpid) then
			len = len + 1
			gpids[len] = gpid
		end	
	end
	
	return len>0 and gpids or nil, len
end

-- 获取视野内所有AOI对象列表
function GameObjectService:getFovAllAoiObjs(game_obj, aoi_scene)
	local aoi_obj = game_obj and game_obj.aoi_obj or nil
	if not aoi_scene then
		aoi_scene, aoi_obj = self:getAoiSceneAndAoiObj(game_obj)
	end
	local aoi_objs = aoi_scene:getFovObjs(aoi_obj, 0)
	--Logger:debug('adafasfdas2222', aoi_objs)
	return aoi_objs
end

-- 获取视野内所有玩家AOI对象列表
function GameObjectService:getFovPlayerAoiObjs(game_obj, aoi_scene)
	local aoi_obj = game_obj and game_obj.aoi_obj or nil
	if not aoi_scene then
		aoi_scene, aoi_obj = self:getAoiSceneAndAoiObj(game_obj)
	end	
	return aoi_scene:getFovObjs(aoi_obj, aoi_type_player)
end

-- 获取视野内所有怪物AOI对象列表
function GameObjectService:getFovMonsterAoiObjs(game_obj, aoi_scene)
	local aoi_obj = game_obj and game_obj.aoi_obj or nil
	if not aoi_scene then
		aoi_scene, aoi_obj = self:getAoiSceneAndAoiObj(game_obj)
	end	
	return aoi_scene:getFovObjs(aoi_obj, aoi_type_monster)
end

--- 获取场景内 指定类型的 游戏对象列表
function GameObjectService:getGameObjsByType(aoi_scene, aoi_type)
	local aoi_id2game_objs = aoi_scene.aoi_type2game_objs[aoi_type]
	return aoi_id2game_objs
end

-- 获取本场景内所有角色AOI对象
function GameObjectService:getPlayerGameObjs(aoi_scene)	
	return self:getGameObjsByType(aoi_scene, aoi_type_player)
end

--- 获取对象所在 场景实例ID
function GameObjectService:getSceneSpaceId(game_obj)
	return game_obj.space_id
end

do
	-- 获取本场景内所有角色AOI对象
	local monster_tpye = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
	function GameObjectService:findliveMonster(aoi_scene, monster_base_id)
		local aoi_id2game_objs = aoi_scene.aoi_type2game_objs[monster_tpye]
		for aoi_id, game_obj in pairs(aoi_id2game_objs) do
			if game_obj.monster_base.id == monster_base_id and (not self:isDead(game_obj)) then
				return game_obj
			end
		end
	end
	
	function GameObjectService:findliveMonster2(aoi_scene, monster_base_ids)
		local monster_base_ids = table.value2key(monster_base_ids)
		local aoi_id2game_objs = aoi_scene.aoi_type2game_objs[monster_tpye]
		for aoi_id, game_obj in pairs(aoi_id2game_objs) do
			if monster_base_ids[game_obj.monster_base.id] and (not self:isDead(game_obj)) then
				return game_obj
			end
		end
	end
end

-- 查找指定类型的任一AOI对象
function GameObjectService:findLiveAoiObj(aoi_scene, aoi_type, monster_base_ids)
	if monster_base_ids then
		local monster_base_ids2 = {}
		for _, monster_base_id in pairs(monster_base_ids) do
			if monster_base_id <= 0 then
				Logger:error('[GameObjectService:findLiveAoiObj] monster_base_id err.', monster_base_id)
			else
				monster_base_ids2[monster_base_id] = monster_base_id
			end
		end
		monster_base_ids = monster_base_ids2
	end
	
	local aoi_id2game_objs = aoi_scene.aoi_type2game_objs[aoi_type]
	for aoi_id, game_obj in pairs(aoi_id2game_objs) do
		if game_obj.hp and not self:isDead(game_obj) then
			if monster_base_ids and next(monster_base_ids) and game_obj.monster_base then
				if monster_base_ids[game_obj.monster_base.id] then
					return game_obj.aoi_obj
				end
			else
				return game_obj.aoi_obj
			end
		end
	end
end

do
	-- 添加游戏对象、AOI对象 到场景内
	function GameObjectService:addObj(game_obj, aoi_obj, aoi_scene)
		local aoi_scene = aoi_scene or AoiSceneService:getAoiScene(game_obj.space_id)
		local aoi_id2game_objs = aoi_scene.aoi_id2game_objs
		local aoi_type2game_objs = aoi_scene.aoi_type2game_objs
		assert(game_obj.obj_id == nil)
		assert(game_obj.space_id)
		
		local aoi_id, aoi_type = aoi_obj.obj_id, aoi_obj.obj_type
		aoi_id2game_objs[aoi_id] = game_obj
		aoi_type2game_objs[aoi_type][aoi_id] = game_obj
		
		-- 设置阵营
		if game_obj.aoi_type == aoi_type_player or game_obj.aoi_type == aoi_type_robot then
			SceneEventService:setZhenying(aoi_scene, game_obj)
		end
		
		-- 添加到AOI
		aoi_scene:addAoiObj(aoi_obj)
		
		-- 添加小地图对象
		local scene_sort_id = aoi_scene.scene_base.scene_sort_id
		if small_map_scene_sorts[scene_sort_id] then
			SmallMapService:onAddAoiObj(aoi_scene, game_obj)
		end
		
		-- 创建玩法AOI数据
		if wanfa_aoi_data_scene_sorts_ht[scene_sort_id] then
			WanfaAoiService:createWanfaAoiData(game_obj)
		end
	end
	
	-- 添加一批游戏对象、AOI对象 到场景内
	function GameObjectService:addObjs(game_objs, aoi_objs, aoi_scene)
		local aoi_id2game_objs = aoi_scene.aoi_id2game_objs
		local aoi_type2game_objs = aoi_scene.aoi_type2game_objs
		
		for _, game_obj in pairs(game_objs) do
			assert(game_obj.obj_id == nil)
			local aoi_id, aoi_type = game_obj.aoi_id, game_obj.aoi_type
			aoi_id2game_objs[aoi_id] = game_obj
			aoi_type2game_objs[aoi_type][aoi_id] = game_obj
		end
		
		-- 设置阵营
		for _, game_obj in pairs(game_objs) do
			if game_obj.aoi_type == aoi_type_player or game_obj.aoi_type == aoi_type_robot then
				SceneEventService:setZhenying(aoi_scene, game_obj)
			end
		end
		
		-- 添加到AOI
		aoi_scene:addAoiObjs(aoi_objs)
		
		local scene_sort_id = aoi_scene.scene_base.scene_sort_id
		if small_map_scene_sorts[scene_sort_id] or wanfa_aoi_data_scene_sorts_ht[scene_sort_id] then
			for _, game_obj in pairs(game_objs) do
				-- 添加小地图对象
				if wanfa_aoi_data_scene_sorts_ht[scene_sort_id] then
					WanfaAoiService:createWanfaAoiData(game_obj)
				end
				
				-- 创建玩法AOI数据
				if small_map_scene_sorts[scene_sort_id] then
					SmallMapService:onAddAoiObj(aoi_scene, game_obj)
				end
			end
		end
	end
	
	-- AOI ID  删除一个游戏对象，同时会删除它的AOI对象
	function GameObjectService:delObjByAoiId(aoi_scene, aoi_id)
		local game_obj = self:getGameObjectByAoiId(aoi_scene, aoi_id)
		if game_obj then
			self:delObj(game_obj, aoi_scene)
		end
	end
	
	-- 删除一个游戏对象，同时会删除它的AOI对象
	function GameObjectService:delObj(game_obj, aoi_scene)
		local aoi_scene = aoi_scene or AoiSceneService:getAoiScene(game_obj.space_id)
		local aoi_obj = game_obj.aoi_obj
		local aoi_id, aoi_type = aoi_obj.obj_id, aoi_obj.obj_type
		
		MotionService:onRemoveFromscene(game_obj)
		
		if aoi_scene:getObj(aoi_id) then
			aoi_scene:delObj(aoi_obj, game_obj)
		end
		
		aoi_scene.aoi_id2game_objs[aoi_id] = nil
		aoi_scene.aoi_type2game_objs[aoi_type][aoi_id] = nil
		game_obj.aoi_obj = nil
		
		if small_map_scene_sorts[aoi_scene.scene_base.scene_sort_id] then
			SmallMapService:onDelAoiObj(aoi_scene, game_obj)
		end
	end
	
	-- 删除一批游戏对象，同时会删除它们的AOI对象
	function GameObjectService:delObjs(game_objs, aoi_scene)
		local aoi_scene = aoi_scene or AoiSceneService:getAoiScene(game_obj.space_id)
		local aoi_id2game_objs = aoi_scene.aoi_id2game_objs
		local aoi_type2game_objs = aoi_scene.aoi_type2game_objs
		local getObj = AoiScene.getObj
		
		for _, game_obj in pairs(game_objs) do
			local aoi_obj = game_obj.aoi_obj
			local aoi_id, aoi_type = aoi_obj.obj_id, aoi_obj.obj_type
			
			MotionService:onRemoveFromscene(game_obj)
			
			if getObj(aoi_scene, aoi_id) then
				aoi_scene:delObj(aoi_obj, game_obj)
			end
			
			aoi_id2game_objs[aoi_id] = nil
			aoi_type2game_objs[aoi_type][aoi_id] = nil
			game_obj.aoi_obj = nil
			
			if small_map_scene_sorts[aoi_scene.scene_base.scene_sort_id] then
				SmallMapService:onDelAoiObj(aoi_scene, game_obj)
			end
		end
	end
	
	-- 创建一个场景实例对象(怪物、陷阱等)
	-- 波次(可为空)
	function GameObjectService:createGameObjByPos(aoi_scene, aoi_type, base_id, x, y, phase_id, face_game_obj)
		if aoi_type == aoi_type_monster then
			local direction = face_game_obj and Formula:getAngleByVector(x-face_game_obj.x, y-face_game_obj.y) or math_random(60, 150)
			return MonsterService:dymCreateMonster(aoi_scene, base_id, aoi_scene.scene_id, x, y, direction, nil, phase_id)
		elseif aoi_type == aoi_type_trap then
			return TrapService:createTrap(aoi_scene, base_id, x, y)
		else
			error('暂不支持该AOI类型')
		end
	end
	
	function GameObjectService:createGameObj(aoi_scene, scene_aoi, caller_prof, face_game_obj)
		-- 检查职业是否相符
		local caller_prof_ = scene_aoi.caller_prof
		if caller_prof_ and caller_prof_ ~= 0 and caller_prof_ ~= caller_prof then
			return
		end
		
		local aoi_type = scene_aoi.type
		if aoi_type == aoi_type_monster then
			local direction = face_game_obj and Formula:getAngleByVector(scene_aoi.x-face_game_obj.x, scene_aoi.y-face_game_obj.y) or nil
			return MonsterService:createMonster(aoi_scene, scene_aoi.class_id, scene_aoi, direction)
		elseif aoi_type == aoi_type_trap then
			return TrapService:createTrap(aoi_scene, scene_aoi.class_id, scene_aoi.x, scene_aoi.y)
		else
			error('暂不支持该AOI类型')
		end
	end
	
	-- 响应场景实例已删除
	-- 删除场景内所以游戏对象、AOI对象
	local releaseAOIObj = external.releaseAOIObj
	local releaseFastPacket = external.releaseFastPacket
	function GameObjectService:onDelAoiScene(aoi_scene)
		for k, game_obj in pairs(aoi_scene.aoi_id2game_objs) do
			local aoi_obj = game_obj.aoi_obj
			-- 可能是怪物已隐藏
			if not aoi_obj then
				if game_obj.aoi_type ~= aoi_type_monster then
					Logger:error('[GameObjectService:onDelAoiScene] aoi_obj is nil', game_obj.id, game_obj.aoi_type, game_obj.aoi_id)
				end
				
				-- 释放APPEAR BIN
				local appear_bin = game_obj.tmps.appear_bin
				if appear_bin then 
					game_obj.tmps.appear_bin = nil
					releaseFastPacket(appear_bin)
				end
			else
				game_obj.aoi_obj = nil			
				
				-- 释放APPEAR BIN
				local appear_bin = game_obj.tmps.appear_bin
				if appear_bin then 
					game_obj.tmps.appear_bin = nil
					releaseFastPacket(appear_bin)
				end
				
				-- 释放C++的AOI对象资源
				if aoi_obj.c_obj then
					releaseAOIObj(aoi_obj.c_obj)
				else
					Logger:error('[GameObjectService:onDelAoiScene] c_obj is nil.', type(aoi_obj), game_obj.aoi_type, game_obj.aoi_id)
				end
				aoi_obj.c_obj = nil					
				
				-- 设置已删标志
				aoi_obj.is_deleted = true
			end
		end
		
		-- 清空场景实例里面所有对象
		aoi_scene.objs = nil
		aoi_scene.aoi_id2game_objs = nil
		aoi_scene.aoi_type2game_objs = nil
		aoi_scene.is_deleted = true
	end
end

-- 隐藏对象
-- 只允许怪物隐藏
function GameObjectService:hideObject(game_obj, packet_id)
	MotionService:onRemoveFromscene(game_obj)
	
	-- 只允许怪物隐藏
	assert(game_obj.aoi_type == aoi_type_monster)
	local aoi_scene = AoiSceneService:getAoiScene(game_obj.space_id)
	local aoi_obj = game_obj.aoi_obj
	-- 从AOI删除
	aoi_scene:delObj(aoi_obj, game_obj)
	game_obj.aoi_obj = nil
	
	if small_map_scene_sorts[aoi_scene.scene_base.scene_sort_id] then
		SmallMapService:onDelAoiObj(aoi_scene, game_obj)
	end
end

-- 显示对象
function GameObjectService:showObject(game_obj, packet_id)
	local aoi_scene = AoiSceneService:getAoiScene(game_obj.space_id)
	local old_aoi_id = game_obj.aoi_id
	
	local aoi_obj = AoiObject:new(game_obj.aoi_type, game_obj.x, game_obj.y, game_obj.direction, game_obj, aoi_scene)
	
	local aoi_id2game_objs = aoi_scene.aoi_id2game_objs
	local aoi_type2game_objs = aoi_scene.aoi_type2game_objs
	local aoi_id, aoi_type = aoi_obj.obj_id, aoi_obj.obj_type
	
	aoi_id2game_objs[old_aoi_id] = nil
	aoi_type2game_objs[aoi_type][old_aoi_id] = nil
	aoi_id2game_objs[aoi_id] = game_obj
	aoi_type2game_objs[aoi_type][aoi_id] = game_obj
	
	aoi_scene:addAoiObj(aoi_obj)
	
	local scene_sort_id = aoi_scene.scene_base.scene_sort_id
	if wanfa_aoi_data_scene_sorts_ht[scene_sort_id] then
		WanfaAoiService:createWanfaAoiData(game_obj)
	end
	if small_map_scene_sorts[aoi_scene.scene_base.scene_sort_id] and game_obj.aoi_type == aoi_type_monster then
		SmallMapService:onAddAoiObj(aoi_scene, game_obj)
	end
end

-- 设置appear bin数据已脏(每次都将appear bin版本号加一)
function GameObjectService:appearDirty(game_obj)	
	local tmps = game_obj.tmps
	local appear_ver = (tmps.appear_ver or 0) + 1
	tmps.appear_ver = appear_ver	
	return appear_ver
end

do
	local FastPacket = FastPacket
	local createFastPacket = getmetatable(FastPacket).__call
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort
	local writeCoord = FastPacket.writeCoord	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	local writeInt = FastPacket.writeInt
	
	-- 写入基础外观
	local _get_appear_bin_map = nil
	function GameObjectService:writeObjAppear(game_obj, fast_packet)
		-- 外观函数表
		if not _get_appear_bin_map then
			_get_appear_bin_map = {
				[aoi_type_player] = { CharacterService, 'writeObjAppear' },
				[aoi_type_pet] = { ChPetService, 'writeObjAppear' },
				[aoi_type_monster] = { MonsterService, 'writeObjAppear' },
				[aoi_type_trap] = { TrapService, 'writeObjAppear' },
				[aoi_type_beast] = {BeastService, 'writeObjAppear'},
				[aoi_type_guard_npc] = {GuardNpcService, 'writeObjAppear'},
				[aoi_type_robot] = {SceneRobotService, 'writeObjAppear'},
				[aoi_type_item] = {ItemObjService, 'writeObjAppear'},
			}
		end
		if not game_obj then
			return
		end
		
		local tmps = game_obj.tmps
		local aoi_obj = game_obj.aoi_obj
		local aoi_type = game_obj.aoi_type
		
		-- 写入通用外观数据
		writeUInt(fast_packet, aoi_obj.obj_id)
		writeByte(fast_packet, aoi_type)
		writeCoord(fast_packet, aoi_obj.x)
		writeCoord(fast_packet, aoi_obj.y)
		writeUShort(fast_packet, tmps.appear_ver or 0)
		writeUShort(fast_packet, aoi_obj.direction or 0)
		writeInt(fast_packet, tmps.zhenying or 0)
		
		-- 写入路径数据
		MotionService:writeWays(game_obj, fast_packet)
		
		-- 写入各对象外观详细数据
		local arr = assert(_get_appear_bin_map[aoi_type], aoi_type)
		local service, handle_name = arr[1], arr[2]
		local handle = assert(service[handle_name])
		handle(service, game_obj, fast_packet)
		
		--print('write aoi appear', game_obj.space_id, aoi_type, aoi_obj.obj_id, aoi_obj.x, aoi_obj.y, game_obj.parent_aoi_id)
	end
	
	--- 写入对象详细外观
	local writeFastPacketRaw = Packet.writeFastPacketRaw
	function GameObjectService:writeObjAppearDetail(game_obj, pack)
		local tmps = game_obj.tmps
		
		local appear_bin_ver = tmps.appear_bin_ver
		local appear_bin = tmps.appear_bin
		local appear_ver = tmps.appear_ver or 0
		tmps.appear_ver = appear_ver
		
		if not appear_bin then
			-- 重新构造外观packet
			appear_bin = createFastPacket(512)
			appear_bin_ver = nil
		end
		
		-- 缓存过期，重新生成缓存
		if appear_bin_ver ~= appear_ver then
			WorldPacket:resetWritePacket(appear_bin,opCodes.M2C_SCENE_OBJ_APPEAR)
						
			self:_writeObjAppearDetail(game_obj, appear_bin)
			tmps.appear_bin = appear_bin
			tmps.appear_bin_ver = appear_ver
		end
		
		writeFastPacketRaw(pack, appear_bin)
	end

	--- 写入对象详细外观到 packet
	local _get_appear_detail_bin_map = nil
	function GameObjectService:_writeObjAppearDetail(game_obj, fast_packet)
		-- 外观函数表
		if not _get_appear_detail_bin_map then
			_get_appear_detail_bin_map = {
				[aoi_type_player] = { CharacterService, 'writeObjAppearDetail' },
				[aoi_type_pet] = { ChPetService, 'writeObjAppearDetail' },
				[aoi_type_monster] = { MonsterService, 'writeObjAppearDetail' },
				[aoi_type_trap] = { TrapService, 'writeObjAppearDetail' },
				[aoi_type_beast] = {BeastService, 'writeObjAppearDetail'},
				[aoi_type_guard_npc] = {GuardNpcService, 'writeObjAppearDetail'},
				[aoi_type_robot] = {SceneRobotService, 'writeObjAppearDetail'},
				[aoi_type_item] = {ItemObjService, 'writeObjAppearDetail'},
			}
		end
		
		local aoi_type = game_obj.aoi_type
		
		-- 写入外观
		local arr = assert(_get_appear_detail_bin_map[aoi_type], aoi_type)
		local service, handle_name = arr[1], arr[2]
		local handle = assert(service[handle_name], game_obj, fast_packet)
		
		-- 写入通用外观数据
		writeUInt(fast_packet, game_obj.aoi_id)
		writeByte(fast_packet, game_obj.aoi_type)
		writeUShort(fast_packet, game_obj.tmps.appear_ver or 0)
		
		-- 写入BUFFER数据
		BufferService:writeAppearDetail(game_obj, fast_packet)
		
		-- 写入各对象外观详细数据
		handle(service, game_obj, fast_packet)
	end
end

function GameObjectService:isPause(game_obj,now_time)
	local tmps = game_obj.tmps
	if tmps.is_pause then
		if tmps.pause_expire > now_time then
			return true
		end
		tmps.is_pause = false
	end
	return false
end

function GameObjectService:isVisible(game_obj, aoi_scene)
	local aoi_scene = aoi_scene or AoiSceneService:getAoiScene(game_obj.space_id)
	if game_obj.space_id ~= aoi_scene.space_id then
		return false
	end
	local aoi_obj = aoi_scene:getObj(game_obj.aoi_id)
	return aoi_obj and true or false
end

-- 是否已经死亡
function GameObjectService:isDead(game_obj)
	return game_obj.hp <= 0
end

function GameObjectService:pause(game_obj,expire)
	if game_obj.hp > 0 then
		local tmps = game_obj.tmps
		tmps.is_pause = expire and true or false
		tmps.pause_expire = expire
	end
end

-- ITEM AOI对象的帧更新
function GameObjectService:updateItem(time_now, aoi_scene, objs_item)
	
end

-- 更新阵营
function GameObjectService:updateZhenying(aoi_scene, game_obj, zhenying, is_send)
	game_obj.tmps.zhenying = zhenying
	
	-- 广播视野内的人
	if is_send then
		local update_data = {
			zhenying = zhenying
		}
		SceneService:sendAppearUpdate(aoi_scene, game_obj, update_data)
	end
end

do
	local rsp_opcode = opCodes.M2C_GAMEOBJ_DEAD
	local msg_name = "PackFight.M2C_GAMEOBJ_DEAD"
	local msg_proto = {}
	function GameObjectService:sendDead(aoi_scene, game_obj, arr_pid)
		msg_proto.aoi_id = game_obj.aoi_id
		
		local arr_pid = arr_pid or self:getFovGPids(game_obj, aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, arr_pid)
	end
end


-- 给AOI对象添加一个立即消失的特效
function GameObjectService:addAoiInstantTexiao( aoi_scene, game_obj, texiao_sort_id, texiao_value )
	local texiao_data = {}
	texiao_data.sort_id = texiao_sort_id
	texiao_data.value = texiao_value
	texiao_data.aoi_id = game_obj.aoi_id
	local gpids = GameObjectService:getFovGPids(game_obj, aoi_scene)
	GameObjectService:sendInstantTexiao(aoi_scene, texiao_data, gpids)	
end

do 	-- 特效数据视野广播
	local rsp_opcode = opCodes.M2C_SCENE_AOI_INSTANT_TEXIAO
	local msg_name = "PackAoi.M2C_SCENE_AOI_INSTANT_TEXIAO"
	function GameObjectService:sendInstantTexiao(aoi_scene, texiao_data, gpids)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, texiao_data, nil, gpids)
	end
end
