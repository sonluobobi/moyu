
AoiSceneDataService = AoiSceneDataService or {}
local aoi_scene_datas = AoiDao.aoi_scene_datas

local byte = string.byte
local assert = assert
local error = error


function AoiSceneDataService:getAoiSceneData(res_id)

	local aoi_scene_data = aoi_scene_datas[res_id]
	if not aoi_scene_data 
	then 
		aoi_scene_data = self:newAoiSceneData(res_id)
		aoi_scene_datas[res_id] = aoi_scene_data
	end	
	return aoi_scene_data	
end

local AoiDataFileReader = 
{
	path = '',
	data = nil,
	data_len = 0,
	read_pos = 0,
}
AoiDataFileReader.__index = AoiDataFileReader

local AoiSceneData = AoiSceneData
local Config = Config
function AoiSceneDataService:newAoiSceneData(res_id)

	local path = string.format(Config.scenePath,res_id)	
	local fr = AoiDataFileReader:new(path)	
	local map = fr:readUInt()
	local token = fr:readUInt()
	local ver = fr:readUInt()
	local id = fr:readUInt()
	local width = fr:readUInt()
	local height = fr:readUInt()
	local com = fr:readUInt()
	local offect = fr:readUInt()
	local len = fr:readUInt()

	local readByte = fr.readByte
	local readBytes = fr.readBytes	
	local cells = {}
	local len = width * height
	for idx=1,len do
		cells[idx] = readByte(fr)
		--TEST
		--cells[idx] = 1
		readBytes(fr,3)
	end	
	return AoiSceneData:new(res_id,width,height,cells)	
end



function AoiDataFileReader:new(path)
	local fd = io.open(path,'rb');
	if not fd then
		error(' can not open aoi data file! ' .. path)
	end	
	local o = {}
	setmetatable(o,self)
	o.path = path
	o.data = fd:read('*a')
	o.data_len = string.len(o.data)
	o.read_pos = 0	
	fd:close()	
	return o
end

function AoiDataFileReader:readBytes(bytes)
	local to_pos = self.read_pos + bytes
	if to_pos > self.data_len then
		error("aoi data file read too much, path=" .. self.path .. ", read_pos=" .. self.read_pos .. ", bytes=" .. bytes .. ", data_len=" .. self.data_len)
	end	
	local data = self.data
	local read_pos = self.read_pos
	local n = 0
	for i=bytes,1,-1 do
		n = n * 256 + byte(data, i+read_pos)
	end
	self.read_pos = self.read_pos + bytes
	return n
end

function AoiDataFileReader:readByte()	
	return self:readBytes(1)
end

function AoiDataFileReader:readUInt()
	return self:readBytes(4)
end

