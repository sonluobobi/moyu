--[[
	临危任务Base
--]]

local mathrandom = math.random

LinweiTaskBaseService = LinweiTaskBaseService or {}

-- 随机生成一个任务
function LinweiTaskBaseService:randomTaskType(step_num, player_num)
	if not step_num then 
		
		-- 只有场景内人数达到指定人数，才会出BOSS任务
		if LinweiTaskConfig.BOSS_TASK_PLAYERS_NUM <= player_num then 
			-- 先从五个里面随机一个
			local total_random_weight = LinweiTaskBaseDao.total_random_weight
			local index = mathrandom(total_random_weight)

			for _, task_base in pairs(LinweiTaskBaseDao.taskbase_list) do
				if task_base.random_start < index and task_base.random_end >= index then 
					return task_base.task_type
				end
			end
		else
			local boss_task_base = LinweiTaskBaseService:getTaskBaseByType( LinweiTaskDefs.LINWEI_TASK_TYPE_BOSS )
			local total_random_weight = LinweiTaskBaseDao.total_random_weight - boss_task_base.random_weight
			local index = mathrandom(total_random_weight)

			for _, task_base in pairs(LinweiTaskBaseDao.taskbase_list) do
				if task_base.task_type ~= LinweiTaskDefs.LINWEI_TASK_TYPE_BOSS then
					if task_base.random_start < index and task_base.random_end >= index then 
						return task_base.task_type
					end
				else
					index = index + boss_task_base.random_weight
				end
			end			
		end
	else
		-- 不再出组合任务
		assert(false)
		-- 如果是组合任务，再从三个基础任务中随机到指定数量的任务
		local normal_tasklist = LinweiTaskBaseDao.normal_tasklist
		local arr_task = math.randExtract(normal_tasklist, step_num)	
		local ret_arr = {}
		for k, v in pairs(arr_task) do ret_arr[k] = v.task_type end
		return ret_arr
	end
	assert(false)
end

-- 通过任务类型获取任务
function LinweiTaskBaseService:getTaskBaseByType( task_type )
--	Logger:info(LinweiTaskBaseDao.type_2_taskbase[task_type])
	return LinweiTaskBaseDao.type_2_taskbase[task_type]
end

-- 生成一个完整任务
-- @task_pos 	任务生成的位置
-- @layer 		野外层级
function LinweiTaskBaseService:genFullTask( task_pos, layer, gm_param, player_num)
	local task_type = LinweiTaskBaseService:randomTaskType(nil, player_num)
	
	-- 来自GM命令
	if gm_param and gm_param.first_type then 
		task_type = 0 + gm_param.first_type
	end

	local task_base = self:getTaskBaseByType(task_type)
--	Logger:info('task_base', task_base)
	local sort_id = task_base.sort_id
	local task = {}
	task.task_id = self:getNextTaskId()
	task.task_type = task_base.task_type
	task.task_pos = task_pos
	task.base_task = {}
	task.layer = layer
	task.is_surprise = 0
	local base_task = task.base_task

	-- 组合任务，生成子任务
	if sort_id == LinweiTaskDefs.LINWEI_TASK_SORT_COMB then
		task.arr_task = {}
		local arr_task = task.arr_task
		arr_task.arr_now_step = 0
		arr_task.arr_total_steps = task_base.step_num
		arr_task.task_list = self:randomTaskType(task_base.step_num, player_num)
		if gm_param and gm_param.second_type then 
			arr_task.task_list = {[1]=gm_param.second_type}
		end
		self:genCombNextTask(task)
	else
		base_task.now_step = 0
		base_task.totle_steps = task_base.step_num
		base_task.task_type = task_type
		if not task_base.task_time_long or task_base.task_time_long == 0 then
			base_task.end_time = 0
		else
			base_task.end_time = os.time() + task_base.task_time_long
		end
		base_task.start_time = os.time()	
	end

	-- 生成步骤
	self:genTaskNextStep(task)
	return task
end

-- 分配组合任务的下一个任务
function LinweiTaskBaseService:genCombNextTask( task )
	local arr_task = task.arr_task

	local arr_total_steps = arr_task.arr_total_steps
	local arr_now_step = arr_task.arr_now_step
	assert(arr_now_step < arr_total_steps)
	
	-- 步数加1
	arr_now_step = arr_now_step + 1
	arr_task.arr_now_step = arr_now_step

	task.base_task = {}
	local base_task = task.base_task
	local task_type = arr_task.task_list[arr_now_step]
	local task_base = self:getTaskBaseByType(task_type)
	base_task.task_type = task_type
	base_task.task_id = task.task_id
	base_task.totle_steps = task_base.step_num
	base_task.now_step = 0
	base_task.need_kill_num = 0
	if not task_base.task_time_long or task_base.task_time_long == 0 then
		base_task.end_time = 0
	else
		base_task.end_time = os.time() + task_base.task_time_long
	end
	base_task.start_time = os.time()		
end

-- 分配任务的下一个步骤
function LinweiTaskBaseService:genTaskNextStep( task )
	local base_task = task.base_task
	local now_step = base_task.now_step
	local totle_steps = base_task.totle_steps
	local layer = task.layer
	assert(now_step < totle_steps)

	-- 步数加1
	now_step = now_step + 1
	base_task.now_step = now_step

	local task_type = base_task.task_type
	local task_base = self:getTaskBaseByType(task_type)
	assert(task_base.sort_id == LinweiTaskDefs.LINWEI_TASK_SORT_BASE)

	-- 重置任务数据
	base_task.common_monster_id = nil
	base_task.need_kill_num = 0
	base_task.killed_num = 0

	local lib_type_list = task_base.lib_type_list
	for _, lib_type in pairs(lib_type_list) do 
		-- 随机一条
		local is_surprise = task.is_surprise
		local step = base_task.now_step
		local lib_type_tmp = LinweiTaskBaseDao.libtype_2_tasklib_list[lib_type]
		local is_surprise_tmp = lib_type_tmp[is_surprise]
		local step_tmp = is_surprise_tmp[step]
		
		if step_tmp then 
			local lib_arr = step_tmp[layer]
			local random_lib = lib_arr[mathrandom(#lib_arr)]
			local lib_sort_id = random_lib.sort_id

			if lib_sort_id == LinweiTaskDefs.LINWEI_LIB_SORT_NPC then 
				-- NPC只有在第一次的时候需要赋值
				if now_step == 1 then
					base_task.npc_id = random_lib.npc_id
				end
			elseif lib_sort_id == LinweiTaskDefs.LINWEI_LIB_SORT_BOSS then
				if now_step == 1 then 
					base_task.boss_monster_id = random_lib.boss_monster_id
				end
			elseif lib_sort_id == LinweiTaskDefs.LINWEI_LIB_SORT_MONSTER then
				base_task.common_monster_id = random_lib.common_monster_id
				base_task.killed_num = 0
				base_task.need_kill_num = 0

				-- 初始化爆炸怪
				base_task.boomb_monster_num = 0			--爆炸怪数量
				base_task.boomb_monster_killed_num = 0	--爆炸怪已杀数量	
				base_task.boomb_monster_id = nil

				if random_lib.bomb_monster then 
					-- 使用随机奖励的接口
					local monsters = math.randRewardEquips(random_lib.bomb_monster)
					for id, num in pairs(monsters) do
						if num > 0 then 
							base_task.boomb_monster_id = id
							base_task.boomb_monster_num = num
						end
						break
					end
				end
			
			end
		else
			assert(step > 1)
		end
	end
end

-- 获取下一个可用任务ID(自增，唯一)
function LinweiTaskBaseService:getNextTaskId(  )
	local task_id = LinweiTaskBaseDao.task_id_index
	LinweiTaskBaseDao.task_id_index = task_id + 1
	return task_id
end

-- 判断一个任务是否组合任务
function LinweiTaskBaseService:isCombTask( task )
	local task_type = task.task_type
	local task_base = self:getTaskBaseByType(task_type)
	return task_base.sort_id == LinweiTaskDefs.LINWEI_TASK_SORT_COMB
end
	
-- 判断是否组合任务的最后一个任务
function LinweiTaskBaseService:isLastTask( task )
	if not task.arr_task then 
		return true
	end
	assert (self:isCombTask(task))
	return task.arr_task.arr_total_steps == task.arr_task.arr_now_step
end
