--[[
怪物数据系统Service，逻辑处理
author : suwin zhong
date : 2015-04-10
--]]

local abs = math.abs
local floor = math.floor
local isTable = table.isTable
local AoiObject = AoiObject
local PROFILE_BIN_PKG_TAG_NEEDED = OptimizeSetting.PROFILE_BIN_PKG_TAG_NEEDED

MonsterService = MonsterService or {}


-- 写入外观详细信息
do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	local math_floor = math.floor
	
	-- 写入基础外观
	function MonsterService:writeObjAppear(monster, fast_packet)
		writeByte(fast_packet, math_floor((monster.speed or 0) * 10))
		writeLong(fast_packet, monster.hp)
		writeUInt(fast_packet, monster.monster_base.id)				-- base_id
		writeUInt(fast_packet, monster.parent_aoi_id or 0)			-- parent_aoi_id
	end
	
	-- 写入详细外观
	function MonsterService:writeObjAppearDetail(monster, fast_packet)
		if PROFILE_BIN_PKG_TAG_NEEDED then writeByte(fast_packet, 0x11) end
		
		writeLong(fast_packet, monster.max_hp)
		writeString(fast_packet, monster.tmps.killer_nick or '')
		if PROFILE_BIN_PKG_TAG_NEEDED then writeByte(fast_packet, 0x88) end
	end
end


-- 初始化怪物类型的aoi_obj
-- aoi_obj : aoi_obj对象
-- monster : 怪物对象
-- return aoi_obj
function MonsterService:initMonsterAoiObj(aoi_obj, monster)
	local monster_aoi  = monster.monster_aoi
	local monster_base = monster.monster_base

	aoi_obj.obj_type = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
	aoi_obj.obj_id = monster_aoi.id
	aoi_obj.player_id = 0
	aoi_obj.fov_size = monster_base.view_dist
	aoi_obj.pos.x = monster.x
	aoi_obj.pos.y = monster.y
end


do
	-- 创建一个怪物游戏对象、怪物AOI对象
	-- 会自动将怪物实例对象添加到场景内
	-- monster_id : 怪物id
	-- scene_id : 原始场景id
	-- init_x : 出生点x坐标
	-- init_y : 出生点y坐标
	-- direction : 方向(可不传)
	-- patro_ways : 寻路(可不传)
	-- phase_id : 波次(可不传)
	-- return obj / nil
	local Monster = Monster
	local Monster_new = Monster.new
	local AoiObject_new = AoiObject.new
	local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
	function MonsterService:dymCreateMonster(aoi_scene, monster_id, scene_id, init_x, init_y, direction, patro_ways, phase_id)
		local monster_base = MonsterBaseDao.data[monster_id]
		if isTable(monster_base) then
			-- 方向
			direction = direction or 90

			local monster_id = SceneAoiService:genDySceneAoiInsId()
			local monster_sceneaoi = SceneAoi:new(monster_id, aoi_type_monster, monster_base.id, aoi_scene.scene_id, init_x, init_y, direction, patro_ways, phase_id)
			local monster = Monster_new(Monster, monster_base, monster_sceneaoi)					
			local aoi_obj = AoiObject_new(AoiObject, aoi_type_monster, init_x, init_y, direction, monster, aoi_scene)					
			
			GameObjectService:addObj(monster, aoi_obj, aoi_scene)

			return monster
		else
			print("怪物原始数据不存在，无法动态创建怪物，", monster_id)
			return nil
		end
	end
	
	function MonsterService:createMonster(aoi_scene, monster_id, sceneaoi, direction)
		local monster_base = MonsterBaseDao.data[monster_id]
		if isTable(monster_base) then
			local direction = direction and (sceneaoi.direction or 90) or 90
			local monster = Monster_new(Monster, monster_base, sceneaoi)					
			local aoi_obj = AoiObject_new(AoiObject, aoi_type_monster, sceneaoi.x, sceneaoi.y, direction, monster, aoi_scene)					
			
			GameObjectService:addObj(monster, aoi_obj, aoi_scene)

			return monster
		else
			print("怪物原始数据不存在，无法动态创建怪物，", monster_id)
			return nil
		end
	end
	
	-- 替怪物设定一个攻击对象
	function MonsterService:setMyTargeter(monster, targeter)
		-- 加上仇恨
		local hate_value = 10
		local keep_second = 10000
		self:add2HateLists(monster, targeter, hate_value, keep_second)

		-- 出身就要追杀的目标(仇恨值会在怪物被玩家引出追击范围的时候被清空，所以这里再加多一个标志)
		monster.tmps.born_target_aoi_id = targeter.aoi_id

		-- 设置攻击目标
		MonsterAiService:setTargetAoiId(monster, targeter)

		-- 变成攻击状态
		local delay_msec = 100
		local is_force_aoto_fight = true
		MonsterAiService:toFightState(monster, targeter, delay_msec, is_force_aoto_fight)
	end


	-- 替怪物设定一个攻击对象(针对无仇恨的)
	function MonsterService:setMyTargeter2(monster, targeter)
		-- 设置攻击目标
		MonsterAiService:setTargetAoiId(monster, targeter)

		-- 变成攻击状态
		local delay_msec = 100
		local is_force_aoto_fight = true
		MonsterAiService:toFightState(monster, targeter, delay_msec, is_force_aoto_fight)
	end
end


-- 获取怪物速度
-- monster : 怪物
function MonsterService:getSpeed(monster)
	-- 走动
	if MonsterDefs.MOVE_TYPE_ID_FOR_WALK == monster.tmps.move_type_id then
		return monster.monster_base.walk_speed
	else
	-- 跑动
		return monster.monster_base.speed
	end
end


-- 获取一个怪物视野里的玩家列表
-- monster : 怪物
-- aoiScene : 场景对象(可以为nil)
-- return array
function MonsterService:getFovPlayerIds(monster, aoiScene)
	local GameObjectService = GameObjectService
	local aoiScene = aoiScene or assert(GameObjectService:getAoiScene(monster))
	return GameObjectService:getFovGPids(monster, aoiScene)
end


-- 更新看见怪物的人数
-- monster : 怪物
-- num : 数量 (可正负数)
function MonsterService:updateSeeMeNum(monster, num)
	local monster_tmps = monster.tmps
	local see_me_num = monster_tmps.see_me_num
	see_me_num = see_me_num + num
	if see_me_num < 0 then
		see_me_num = 0
	end
	monster_tmps.see_me_num = see_me_num
end


-- 获取一个怪物的占位
-- monster : 怪物
-- return int
function MonsterService:getSize(monster)
	local monster_base = monster.monster_base
	return (monster_base.body_size * monster_base.model_times)
end


-- 判断一个怪物是否是一个世界boss怪
-- monster : 怪物
-- return boolean
function MonsterService:isWorldBoss(monster)
	return monster.monster_base.monster_sort_id == MonsterDefs.MONSTER_SORT_ID_FOR_WORLD_BOSS
end


-- 判断是不是一个滚石
-- monster : 怪物
-- return boolean
function MonsterService:isRock(monster)
	local monster_id = monster.monster_base.id or 0
	if 4100451 <= monster_id and monster_id <= 4100499 then
		return true
	end
	if 4100851 <= monster_id and monster_id <= 4100899 then
		return true
	end
	
	return false
end


-- 判断是不是一个女神
-- monster : 怪物
-- return boolean
function MonsterService:isNvSheng(monster)
	local is_nvsheng = monster.monster_base.is_nvsheng or 0
	if 1 == is_nvsheng then
		return true
	end

	return false
end


-- 判断是不是一个女怪
-- monster : 怪物
-- return boolean
function MonsterService:isFemale(monster)
	local monster_id = monster.monster_base.id or 0
	if 4500101 <= monster_id and monster_id <= 4500120 then
		return true
	end

	return false
end


-- 判断是不是一个男怪
-- monster : 怪物
-- return boolean
function MonsterService:isMale(monster)
	local monster_id = monster.monster_base.id or 0
	if 4500121 <= monster_id and monster_id <= 4500140 then
		return true
	end

	return false
end


-- 判断是不是城战里的建筑
-- monster : 怪物
-- return boolean
function MonsterService:isCityWarMonster(monster)
	local monster_id = monster.monster_base.id or 0
	if CityWarConfig.Tower_mid_start <= monster_id and monster_id <= CityWarConfig.Tower_all_end then
		return true
	end

	return false
end


-- 判断一个怪物是不是固定扣血怪物
-- monster : 怪物
-- return boolean, lost_hp
function MonsterService:isKnownLostHpMonster(monster)
	-- 怪物原始id
	local monster_base_id = monster.monster_base.id

	-- 50级副本，滚石
	if self:isRock(monster) then
		return true, 1
	end

	-- 庄园里的猴子
	if monster_base_id == 5000701 then
		return true, 1
	end

	-- 天魔灭心boss怪物
	if monster_base_id == 510001 then
		return true, 1000000
	end

	-- 城战箭塔
	if (2001401 <= monster_base_id) and (monster_base_id <= 2001421) then
		return true, 1000000
	end

	-- 无主之地怪物
	if (2001501 <= monster_base_id) and (monster_base_id <= 2001510) then
		return true, 10000
	end

	return false, 0
end


-- 判断一个怪物是不是固定扣血怪物2(性别判断)
-- fighter : 攻击者(角色/侠客)
-- monster : 怪物
-- return boolean, lost_hp
function MonsterService:isKnownLostHpMonster2(fighter, monster)
	-- 是否特殊怪物
	local is_female_monster = self:isFemale(monster)
	local is_male_monster = self:isMale(monster)
	if is_female_monster or is_male_monster then
		local fighter_gender
		if FightService:isCharacter(fighter) then
			fighter_gender = fighter.gender
		elseif FightService:isPet(fighter) then
			local my_character = CharacterService:getCharacterById(fighter.character_id)
			fighter_gender = my_character.gender or 0
		end

		-- 女怪
		if is_female_monster and (CharacterDefs.CHARACTER_GENDER_MAN == fighter_gender) then
			return true, 300
		end

		-- 男怪
		if is_male_monster and (CharacterDefs.CHARACTER_GENDER_WOMAN == fighter_gender) then
			return true, 300
		end
	end

	return false, 0
end


-- 判断一个怪物是不是固定伤害别人百分比的
-- monster : 怪物
-- aoi_scene : 场景实例
-- return boolean
function MonsterService:isAttackPercentMonster(monster, aoi_scene)
	-- 怪物原始id
	local monster_base_id = monster.monster_base.id

	-- 城战箭塔，固定伤害15%
	if (2001401 <= monster_base_id) and (monster_base_id <= 2001419) then
		return true, 15
	end

	-- 城战基地，固定伤害50%，随着场景里塔的数量的减少，而减少百分比
	if (2001420 == monster_base_id) or (2001421 == monster_base_id) then
		-- 默认值是50
		local percent = 50

		-- 获取本势力的剩余塔数量
		local aoi_scene_tower_powers = aoi_scene.tower_powers
		if aoi_scene_tower_powers then
			-- local
			local CityWarConfig_DefenceTowerMaxNum = CityWarConfig.DefenceTowerMaxNum
			-- 基地的所属势力id
			local monster_powers_id = monster.monster_base.powers_id
			local left_tower_num = aoi_scene_tower_powers[monster_powers_id] or CityWarConfig_DefenceTowerMaxNum
			percent = percent - ((CityWarConfig_DefenceTowerMaxNum - left_tower_num) * 5)

			-- 最低5%
			if percent < 5 then
				percent = 5
			end
		end

		return true, percent
	end

	return false, 0
end


-- 判断一个怪物是不是无主之地的boss怪物
-- monster : 怪物
-- return boolean
function MonsterService:isKillzoneBoss(monster)
	-- 怪物原始id
	local monster_base_id = monster.monster_base.id

	-- 无主之地boss
	if (20015101 <= monster_base_id) and (monster_base_id <= 20015399) then
		return true
	end

	return false
end


-- 记录怪物仇恨值
-- monster : 怪物
-- object : 角色 / 侠客
-- hate_value : 仇恨值
-- keep_second : 本次增加的仇恨值的过期秒数
function MonsterService:add2HateLists(monster, object, hate_value, keep_second)
	-- local
	local monster_tmps = monster.tmps

	if not monster_tmps.hate_lists then
		monster_tmps.hate_lists = {}
	end

	local object_aoi_id = object.aoi_id
	local object_hate_value = monster_tmps.hate_lists[object_aoi_id] or 0
	object_hate_value = object_hate_value + hate_value

	monster_tmps.hate_lists[object_aoi_id] = object_hate_value

	-- 临时仇恨信息
	if keep_second and 0 < keep_second then
		local tmp_hate_expire = Time:getDelayMsTime(keep_second * 1000)
		if not monster_tmps.tmp_hate then
			monster_tmps.tmp_hate = {object_aoi_id, tmp_hate_expire}
		end
	end
end


-- 删除怪物仇恨值
-- monster : 怪物
-- aoi_id : 指定的aoi_id，没有指定则全部删除
function MonsterService:cleanHateLists(monster, aoi_id)
	-- local
	local monster_tmps = monster.tmps
	local hate_lists = monster_tmps.hate_lists

	if aoi_id then
		hate_lists[aoi_id] = nil
	else
		hate_lists = {}
	end
end


-- 更新怪物最仇恨的对象
-- monster : 怪物
-- filter_aoi_id : 可以不检测的aoi_id
-- return character_id / 0
function MonsterService:updateHatestAoiId(monster, filter_aoi_id)
	-- local
	local monster_tmps = monster.tmps
	local hate_lists = monster_tmps.hate_lists

	-- 怪物当前的追踪目标
	local target_aoi_id = MonsterAiService:getTargetAoiId(monster)
	local target_hate_value = 0

	-- 可以不监测的aoi_id
	local filter_aoi_id = filter_aoi_id or 0

	-- 怪物当前所在的场景
	local aoi_scene = GameObjectService:getAoiScene(monster)
	local monster_scene_ins_id = aoi_scene.space_id

	-- 先将已经不在同一个场景的仇恨对象清除掉
	local now_targeter
	local is_targeter
	local is_can_clean
	for k, _ in pairs(hate_lists) do
		-- 默认值
		is_targeter = false
		is_can_clean = false

		if k ~= filter_aoi_id then
			-- 是目标
			if k == target_aoi_id then
				is_targeter = true
			end

			-- 获取仇恨对象
			now_targeter = GameObjectService:getGameObjectByAoiId(aoi_scene, k)
			-- 目标已经不在/已经不在同一个场景
			if not now_targeter then
				is_can_clean = true
			end

			-- 清理玩家
			if is_can_clean then
				-- 仇恨列表中清除
				hate_lists[k] = nil

				-- 清除掉原来的目标
				if is_targeter then
					target_aoi_id = 0
					target_hate_value = 0
					monster_tmps.target_aoi_id = 0
				end
			end
		end
	end

	-- 最大仇恨的aoi_id
	local max_hate_aoi_id = 0
	local max_hate_value = -1

	-- 寻找当前追踪目标的仇恨值和最大仇恨者的值
	for k, v in pairs(hate_lists) do
		if k == target_aoi_id then
			target_hate_value = v
		end

		if v > max_hate_value then
			max_hate_aoi_id = k
			max_hate_value = v
		end
	end

	-- 当前追踪的人不是最高仇恨者
	if 0 < target_aoi_id then
		if target_aoi_id ~= max_hate_aoi_id then
			target_hate_value = target_hate_value * 1.2
			if max_hate_value >= target_hate_value then
				target_aoi_id = max_hate_aoi_id
			end
		end
	else
		target_aoi_id = max_hate_aoi_id
	end

	-- 更新攻击目标
	monster_tmps.target_aoi_id = target_aoi_id

	return target_aoi_id
end