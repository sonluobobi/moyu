--[[
��������interface ��ȱʡ impl
author : xingzeng.jiang
date : 2014-07-15
--]]


SceneImplDefaultService = SceneImplDefaultService or {}
setmetatable(SceneImplDefaultService, SceneServiceInterface )

local SceneService = SceneService
function SceneImplDefaultService:onAfterLoadLua()
	SceneService = _G.SceneService
end

function SceneImplDefaultService:checkEnterScene(character, aoi_scene, dst_scene_base)
	return true
end

function SceneImplDefaultService:checkLeaveScene(character, aoi_scene)
	return true
end

function SceneImplDefaultService:onInitScene(character, aoi_scene)
	SceneService:onInitSceneDefault(character, aoi_scene)
	
	return true
end


function SceneImplDefaultService:update(time_now, aoi_scene)
	do return end
end

