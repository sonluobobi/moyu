--[[
小地图系统servuce
author : xingzeng
date : 2014-08-15
]]--

local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local type = type
local opCodes = opCodes
local string_len = string.len
local math_random = math.random
local GameObjectService
local math_ceil = math.ceil
local SmallMapDao = SmallMapDao
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local SmallMapDefs = SmallMapDefs
local SceneDefs = SceneDefs
local TeamDao = TeamDao
local MonsterDefs = MonsterDefs
local tableInsert = table.insert

SmallMapService = SmallMapService or {}

function SmallMapItem:newByGameObj(game_obj, sort_id, zhenying, state)
	return self:new(game_obj.aoi_id, sort_id, game_obj.x, game_obj.y, zhenying or game_obj.tmps.zhenying, state)
end

function SmallMapItem:newById(item_id, sort_id, zhenying, state)
	return self:new(item_id, sort_id)
end

function SmallMapItem:newSimple(sort_id, x, y, zhenying, state)
	local aoi_id = SmallMapService:genItemId()
	return self:new(aoi_id, sort_id, x, y, zhenying, state)
end

function SmallMapService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
end

-- 当怪物被杀
-- character 	击杀者
-- arr_kill_monster_id		被杀怪物ID数组
function SmallMapService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
	if not arr_kill_monster_aoi_id or not next(arr_kill_monster_aoi_id) then
		return
	end
	local aoi_scene = GameObjectService:getAoiScene(character)
	if not SceneDefs.small_map_scene_sorts[aoi_scene.scene_base.scene_sort_id] then
		return
	end
	
	for _, aoi_id in pairs(arr_kill_monster_aoi_id) do
		local item = SmallMapService:getItem(aoi_scene, aoi_id)
		if item then
			local game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
			if game_obj and game_obj.monster_base then
				local monster_sort_id = game_obj.monster_base.monster_sort_id
				SmallMapService:delItem(aoi_scene, aoi_id)
			end
		end
	end
end

-- 当角色被杀
-- fighter 		击杀者
-- arr_kill_player_aoi_id 		被杀者AOI数组
function SmallMapService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
	-- 怪物杀人不算
	if not fighter.tmps_ex then 
		return 
	end
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	if not SceneDefs.small_map_scene_sorts[aoi_scene.scene_base.scene_sort_id] then
		return
	end

	-- 如果在野外，且阵营为劫镖
	if self:isInJiebiao(aoi_scene, fighter) then 
		return
	end
	
	-- 如果处于末日战场
	if self:isInFinalwar(aoi_scene) then 
        return
    end

	local sort_id = SmallMapDefs.SMALL_MAP_SORT_ID_CHOU_DI

	local scene_enemy = aoi_scene.scene_enemy
	if not scene_enemy then 
		scene_enemy = {}
		aoi_scene.scene_enemy = scene_enemy
	end

	local fighter_aoi_id = fighter.aoi_id
	for _, aoi_id in pairs(arr_kill_player_aoi_id) do
		local ch_enemy = scene_enemy[aoi_id]
		if not ch_enemy then 
			local killed_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
			ch_enemy = {gpid=killed_obj.gpid, enemies={}}
			scene_enemy[aoi_id] = ch_enemy
		end
		local enemies = ch_enemy.enemies
		local is_exist, exist_pos = false
		for _, item in pairs(enemies) do
			if item.enemy_aoi_id == fighter.aoi_id then 
				is_exist = true
				exist_pos = _
			end
		end

		if not is_exist then 
			if #enemies >= 3 then 
				-- 把第一个放最后面
				local item = enemies[1]
				table.remove(enemies, 1)
				item.enemy_aoi_id = fighter_aoi_id
				tableInsert(enemies, item)
				for index, item in pairs(enemies) do
					item.aoi_id = self:getItemByEnemyIndex(index)
				end

			else
				-- 添加小地图
				local new_item = SmallMapItem:newById(#ch_enemy, sort_id)
				local game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, fighter_aoi_id)
				new_item.enemy_aoi_id = fighter.aoi_id
				new_item.x = game_obj.x
				new_item.y = game_obj.y
				tableInsert(enemies, new_item)
				new_item.aoi_id = self:getItemByEnemyIndex(#enemies)

				self:sendItemUpdate(aoi_scene, new_item, ch_enemy.gpid)
			end

		else
			-- 把此敌人设置为最新的敌人
			local item = enemies[exist_pos]
			table.remove(enemies, exist_pos)
			tableInsert(enemies, item)
		end
	end	
end

-- 当参加劫镖活动
function SmallMapService:onJoinJiebiao( aoi_scene, character )
	local scene_enemy = aoi_scene.scene_enemy
	if scene_enemy then 
		aoi_scene.scene_enemy_bak = aoi_scene.scene_enemy_bak or {}
		local scene_enemy_bak = aoi_scene.scene_enemy_bak
		local ch_aoi_id = character.aoi_obj.obj_id
		local ch_enemy = scene_enemy[ch_aoi_id]
		if ch_enemy then 
			-- 发送小地图删除
			scene_enemy_bak[ch_aoi_id] = ch_enemy
			scene_enemy[ch_aoi_id] = nil

			local enemies = ch_enemy.enemies
			local arr_item_aoids = {}
			for _, item in pairs(enemies) do
				table.insert(arr_item_aoids, item.aoi_id)
			end

			self:delSmallMapItems(aoi_scene, arr_item_aoids, ch_enemy.gpid)
		end
	end
end

function SmallMapService:isInJiebiao( aoi_scene, character )
	local zhenying = character.tmps.zhenying
	return OutdoorService:isInOutdoor( aoi_scene.scene_base.id ) and (zhenying == Statics.DEFAULT_ZHENYING_SHOU or zhenying == Statics.DEFAULT_ZHENYING_GONG)
end

function SmallMapService:isInFinalwar(aoi_scene)
    return aoi_scene.scene_id == FinalWarDefs.war_scene_id1 or 
        aoi_scene.scene_id == FinalWarDefs.war_scene_id2
end

-- 当完成劫镖任务时
function SmallMapService:onFinJiebiao( aoi_scene, character )
	local scene_enemy_bak = aoi_scene.scene_enemy_bak
	local ch_aoi_id = character.aoi_obj.obj_id
	if scene_enemy_bak and scene_enemy_bak[ch_aoi_id] then 
		aoi_scene.scene_enemy[ch_aoi_id] = scene_enemy_bak[ch_aoi_id]
		scene_enemy_bak[ch_aoi_id] = nil

		local ch_enemy = aoi_scene.scene_enemy[ch_aoi_id]
		local enemies = ch_enemy.enemies
		SmallMapService:sendItemsUpdate(aoi_scene, enemies, {character.gpid})
	end
end

-- 响应进入场景事件
function SmallMapService.afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	if not SceneDefs.small_map_scene_sorts[aoi_scene.scene_base.scene_sort_id] then
		return
	end
	
	-- 初始化玩家可见的小地图ITEM对象列表
	SmallMapService:initPlayerViewItems(aoi_scene, character)
	
	local items = SmallMapService:getMyViewItems(character, aoi_scene)
	if items and next(items) then
		-- 把小地图对象返回给自己
		SmallMapService:sendItems(items, character.gpid)
	end
end

-- 响应离开场景事件
function SmallMapService:afterLeaveScene(character, aoi_scene )
	-- 清除角色场景敌人数据
	local scene_enemy = aoi_scene.scene_enemy
	if scene_enemy then 
		scene_enemy[character.aoi_id] = nil
	end
	local scene_enemy_bak = aoi_scene.scene_enemy_bak
	if scene_enemy_bak then 
		scene_enemy_bak[character.aoi_id] = nil
	end
end

-- 每秒帧更新事件
function SmallMapService:update(time_now, aoi_scene)
	if not SceneDefs.small_map_scene_sorts[aoi_scene.scene_base.scene_sort_id] then
		return
	end
	
	local small_map_items_bc_ltimes = aoi_scene.small_map_items_bc_ltimes or {}
	aoi_scene.small_map_items_bc_ltimes = small_map_items_bc_ltimes
	
	-- 队员
	SmallMapService:bcTeamItemOnTimer(time_now, aoi_scene, small_map_items_bc_ltimes)
	
	-- BOSS
	SmallMapService:bcCommItemOnTimer(time_now, aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_BOSS, small_map_items_bc_ltimes)

	-- MONSTER普通
	SmallMapService:bcCommItemOnTimer(time_now, aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_MONSTER_NORMAL, small_map_items_bc_ltimes)
	
	-- 激光塔
	SmallMapService:bcCommItemOnTimer(time_now, aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_TOWER_LASER, small_map_items_bc_ltimes)

	-- 场景仇敌
	SmallMapService:bcSceneEnemyItemOnTimer(time_now, aoi_scene, small_map_items_bc_ltimes)
end

-- 定时广播队员小地图ITEM信息
function SmallMapService:bcTeamItemOnTimer(time_now, aoi_scene, small_map_items_bc_ltimes)
	local sort_id = SmallMapDefs.SMALL_MAP_SORT_ID_TEAM
	local interval = SmallMapDefs.sort2item_bc_interval[sort_id]

	-- 爱情圣殿0.5秒同步一次
	if LoverTempleService and LoverTempleService:isInLoverTemple( aoi_scene.scene_id ) then 
		interval = 500
	end

	if ShengcunService:isInShengcun( aoi_scene.scene_id ) then
		if aoi_scene.shengcun then 
			local bc_ltime = small_map_items_bc_ltimes and small_map_items_bc_ltimes[sort_id] or nil
			if not bc_ltime then
				small_map_items_bc_ltimes[sort_id] = time_now
				
			elseif bc_ltime + interval < time_now then
				local camp_id_2_camp = aoi_scene.shengcun.camp_id_2_camp
				for camp_id, camp_info in pairs(camp_id_2_camp) do
					local items, gpids = self:addItemsByShengcunCamp(aoi_scene, camp_info)
					self:updateItemsPos(aoi_scene, items)
					if aoi_scene.is_small_map_dirty then
						self:sendItemsUpdate(aoi_scene, items, gpids)
					end					
				end
				small_map_items_bc_ltimes[sort_id] = time_now
			end			
		end
	else
		local bc_ltime = small_map_items_bc_ltimes and small_map_items_bc_ltimes[sort_id] or nil
		if not bc_ltime then
			small_map_items_bc_ltimes[sort_id] = time_now
			
		elseif bc_ltime + interval < time_now then
			local teamid_2_team = TeamDao.teamid_2_team
			
			for _, team in pairs(teamid_2_team) do
				local items, gpids = self:addItemsByTeam(aoi_scene, team)
				self:updateItemsPos(aoi_scene, items)
				if aoi_scene.is_small_map_dirty then
					self:sendItemsUpdate(aoi_scene, items, gpids)
				end
			end
			
			small_map_items_bc_ltimes[sort_id] = time_now
		end
	end
end

-- 定时广播仇敌小地图ITEM信息
function SmallMapService:bcSceneEnemyItemOnTimer(time_now, aoi_scene, small_map_items_bc_ltimes)
	local sort_id = SmallMapDefs.SMALL_MAP_SORT_ID_CHOU_DI
	local interval = SmallMapDefs.sort2item_bc_interval[sort_id]
	
	local bc_ltime = small_map_items_bc_ltimes and small_map_items_bc_ltimes[sort_id] or nil
	if not bc_ltime then
		small_map_items_bc_ltimes[sort_id] = time_now
		
	elseif bc_ltime + interval < time_now then
		local scene_enemy = aoi_scene.scene_enemy
		if scene_enemy then 
			for ch_aoi_id, ch_enemy in pairs(scene_enemy) do
				local enemies = ch_enemy.enemies
				local items = {}
				
				for k, item in pairs(enemies) do
					local enemy_aoi_id = item.enemy_aoi_id
					if enemy_aoi_id > 0 then
						local enemy_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, enemy_aoi_id)
						if not enemy_obj then 
							-- 发送删除小地图
							self:delSmallMapItems(aoi_scene, {[1] = item.aoi_id}, ch_enemy.gpid)						
							item.enemy_aoi_id = 0

						else
							item.x = enemy_obj.x
							item.y = enemy_obj.y
							tableInsert(items, item)
						end
					end
				end
				if next(items) then
					SmallMapService:sendItemsUpdate(aoi_scene, items, {ch_enemy.gpid})
				end
			end
		end
		small_map_items_bc_ltimes[sort_id] = time_now
	end
end

-- 定时广播小地图ITEM信息
function SmallMapService:bcCommItemOnTimer(time_now, aoi_scene, sort_id, small_map_items_bc_ltimes)
	local interval = SmallMapDefs.sort2item_bc_interval[sort_id]
	
	local bc_ltimes = small_map_items_bc_ltimes and small_map_items_bc_ltimes[sort_id] or nil
	if not bc_ltimes then
		small_map_items_bc_ltimes[sort_id] = time_now
		
	elseif bc_ltimes + interval < time_now then
		local small_map_sort2items = aoi_scene.small_map_sort2items
		local items = small_map_sort2items[sort_id]
		if items and next(items) then
			items = table.values(items)
			self:updateItemsPos(aoi_scene, items)
			if aoi_scene.is_small_map_dirty then
				self:sendItemsUpdate(aoi_scene, items)
			end
		end
		
		small_map_items_bc_ltimes[sort_id] = time_now
	end
end

function SmallMapService:updateItemsPos(aoi_scene, items)
	local is_small_map_dirty = false
	
	for _, item in pairs(items) do
		local aoi_obj = aoi_scene:getObj(item.aoi_id)
		if aoi_obj then
			local x, y = aoi_obj.x, aoi_obj.y
			if x ~= item.x or y ~= item.y then
				item.x = x
				item.y = y
				is_small_map_dirty = true
			end
		end
	end
	
	aoi_scene.is_small_map_dirty = is_small_map_dirty
end

function SmallMapService:_addItem(aoi_scene, item)
	local small_map_items = aoi_scene.small_map_items
	local small_map_sort2items = aoi_scene.small_map_sort2items
	local sort_id = item.sort_id
	
	small_map_items[item.aoi_id] = item
	
	local items = small_map_sort2items[sort_id] or {}
	small_map_sort2items[sort_id] = items
	items[item.aoi_id] = item
end

function SmallMapService:_delItem(aoi_scene, item_id)
	local small_map_items = aoi_scene.small_map_items
	local small_map_sort2items = aoi_scene.small_map_sort2items
	
	local item = small_map_items[item_id]
	if item then
		local sort_id = item.sort_id
		small_map_items[item_id] = nil
		
		local items = small_map_sort2items[sort_id]
		if items then
			items[item_id] = nil
			return true
		end
	end
end

-------------------------- 非AOI对象的小地图ITEM管理 start ----------------------
-- 添加一个小地图ITEM对象 (非AOI对象)
-- sort_id		小地图对象类型
-- x 			坐标
-- y 			坐标
-- zhenying		阵营(可nil)
-- state 		状态(可nil)
-- return int:小地图ITEM对象ID
function SmallMapService:addItem(aoi_scene, sort_id, x, y, zhenying, state)
	local item = SmallMapItem:newSimple(sort_id, x, y, zhenying, state)
	self:_addItem(aoi_scene, item)
	
	-- RSP
	self:sendItemUpdate(aoi_scene, item)
	
	return item.aoi_id
end

-- 删除一个ITEM (非AOI对象)
function SmallMapService:delItem(aoi_scene, item_id)
	self:_delItem(aoi_scene, item_id)
	
	-- RSP
	self:delSmallMapItem(aoi_scene, item_id)
end

-------------------------- 非AOI对象的小地图ITEM管理 end ----------------------

function SmallMapService:addItemsByTeam(aoi_scene, team)
	local small_map_items = aoi_scene.small_map_items or {}
	aoi_scene.small_map_items = small_map_items
	local items = {}	
	local gpids = {}
	local getCharacterByGcid = CharacterService.getCharacterByGcid
	
	for _, member in pairs(team.members) do
		local ch_obj = getCharacterByGcid(CharacterService, member.gcid)
		if ch_obj and ch_obj.space_id == aoi_scene.space_id then
			local aoi_id = ch_obj.aoi_id
			local item = small_map_items[aoi_id]
			if not item then
				item = SmallMapItem:newByGameObj(ch_obj, SmallMapDefs.SMALL_MAP_SORT_ID_TEAM)
				item.team_id = team.id
				item.x = item.x - 0.0001  --有一点小偏移，才会广播给先进入的玩家
				self:_addItem(aoi_scene, item)
			end
			items[#items+1] = item
			if ch_obj.aoi_type == aoi_type_player then
				gpids[#gpids+1] = ch_obj.gpid
			end
		end
	end
	
	return items, gpids
end

function SmallMapService:addItemsByShengcunCamp(aoi_scene, camp_info)
	local small_map_items = aoi_scene.small_map_items or {}
	aoi_scene.small_map_items = small_map_items
	local items = {}	
	local gpids = {}
	local getCharacterByGcid = CharacterService.getCharacterByGcid
	
	for _, member in pairs(camp_info.members) do
		local ch_obj = getCharacterByGcid(CharacterService, member.gcid)
		if ch_obj and ch_obj.space_id == aoi_scene.space_id then
			local aoi_id = ch_obj.aoi_id
			local item = small_map_items[aoi_id]
			if not item then
				item = SmallMapItem:newByGameObj(ch_obj, SmallMapDefs.SMALL_MAP_SORT_ID_TEAM)
				item.team_id = camp_info.camp_id
				self:_addItem(aoi_scene, item)
			end
			items[#items+1] = item
			if ch_obj.aoi_type == aoi_type_player then
				gpids[#gpids+1] = ch_obj.gpid
			end
		end
	end
	return items, gpids
end

function SmallMapService:addFilterItem(aoi_scene, sort_id, filters, x, y, zhenying, state)
    local item = SmallMapItem:newSimple(sort_id, x, y, zhenying, state)
    self:_addItem(aoi_scene, item)
    item.filters = filters
    local gpids = GameObjectService:getGPids(aoi_scene)
    
    local resgpids = {}
    if filters and not table.isTableEmpty(filters) then
        for k,v in pairs(gpids) do
            local r = table.find2(filters, v)
            if not r then
                resgpids = resgpids or {}
                resgpids[#resgpids+1] = v
            end
        end
    end
    self:sendItemUpdate(aoi_scene, item, resgpids)
    return item.aoi_id
end

-- 更新小地图对象位置(非AOI对象)
function SmallMapService:updateItemPos(aoi_scene, item_id, x, y)
	local small_map_items = aoi_scene.small_map_items
	if not small_map_items then
		return
	end
	local item = small_map_items[item_id]
	if not item then
		return
	end
	
	item.x = x
	item.y = y
	
	local up_item = {sort_id=item.sort_id, x = x, y = y, aoi_id = item.aoi_id}
	self:sendItemUpdate(aoi_scene, up_item)
end

-- 更新小地图对象位置(非AOI对象)带gpids
function SmallMapService:updateItemPos2Gpids(aoi_scene, item_id,gpids, x, y)
    local small_map_items = aoi_scene.small_map_items
    if not small_map_items then
        return
    end
    local item = small_map_items[item_id]
    if not item then
        return
    end
    
    item.x = x
    item.y = y
    local resgpids = {}
    if item.filters and not table.isTableEmpty(item.filters) then
        for k,v in pairs(gpids) do
            local r = table.find2(item.filters, v)
            if not r then
                resgpids[#resgpids+1] = v
            end
        end
    end
    
    local up_item = {sort_id=item.sort_id, x = x, y = y, aoi_id = item.aoi_id}
    self:sendItemUpdate(aoi_scene, up_item,resgpids)
end

-- 更新小地图对象
function SmallMapService:updateItemOne(aoi_scene, item_id, key, value)
	local small_map_items = aoi_scene.small_map_items
	if not small_map_items then
		return
	end
	local item = small_map_items[item_id]
	if not item then
		return
	end
	
	-- 检查KEY
	if not SmallMapItem[key] then
		Logger:fatal('[SmallMapService:updateItemOne] key is not exist', key, value)
	end
	item[key] = value
	
	local up_item = {sort_id= item.sort_id, x = item.x, y = item.y, aoi_id = item.aoi_id, [key] = value}
	self:sendItemUpdate(aoi_scene, up_item)
end

-- 更新小地图对象
-- item_id	ITEM对象ID/AOI ID
-- up_data	eg:{x = 23, y = 33, state = 22}
function SmallMapService:updateItem(aoi_scene, item_id, up_data)
	local small_map_items = aoi_scene.small_map_items
	if not small_map_items then
		return
	end
	local item = small_map_items[item_id]
	if not item then
		return
	end
	
	for key, value in pairs(up_data) do
		-- 检查KEY
		if not SmallMapItem[key] then
			Logger:fatal('[SmallMapService:updateItem] key is not exist', key, value)
		end
		
		item[key] = value
	end
	
	self:sendItemUpdate(aoi_scene, item)
end

do
	local obj_type_2_scene_sortids = {
		[MonsterDefs.MONSTER_SORT_ID_FOR_BOSS] = { -- BOSS怪(客户端未添加相关逻辑，若使用，需要客户端添加)
			small_map_type = SmallMapDefs.SMALL_MAP_SORT_ID_BOSS,
			scene_sortids = {
			},
		},
		[MonsterDefs.MONSTER_SORT_ID_FOR_TOWER_LASER] = { 	--激光塔(客户端未添加相关逻辑，若使用，需要客户端添加)
			small_map_type = SmallMapDefs.SMALL_MAP_SORT_ID_TOWER_LASER,
			scene_sortids = {
				[SceneDefs.SCENE_SORT_ID_SUBLINE] = true,
				[SceneDefs.SCENE_SORT_ID_SUBLINE_EMENG] = true,
			},			
		},
		[MonsterDefs.MONSTER_SORT_ID_FOR_NORMAL] = { 	--普通小怪
			small_map_type = SmallMapDefs.SMALL_MAP_SORT_ID_MONSTER_NORMAL,
			scene_sortids = {
				[SceneDefs.SCENE_SORT_ID_DAOJJ_WAR] = true,  --帝国争锋
			},			
		},
	}
	-- 响应添加一个AOI对象
	function SmallMapService:onAddAoiObj(aoi_scene, game_obj)
		local aoi_type = game_obj.aoi_type

		if aoi_type == aoi_type_monster then
			local monster_sort_id = game_obj.monster_base.monster_sort_id
			local conf = obj_type_2_scene_sortids[monster_sort_id] 
			local scene_sortids = conf and conf.scene_sortids
			local small_map_type = conf and conf.small_map_type
			if scene_sortids and scene_sortids[aoi_scene.scene_base.scene_sort_id] and small_map_type then 
				local item = SmallMapItem:newByGameObj(game_obj, small_map_type)
				self:_addItem(aoi_scene, item)
				SmallMapService:sendItemUpdate(aoi_scene, item)						
			end
		end
	end

	-- 响应删除一个AOI对象
	function SmallMapService:onDelAoiObj(aoi_scene, game_obj)
		local small_map_items = aoi_scene.small_map_items
		local aoi_id = game_obj.aoi_id
		if small_map_items and small_map_items[aoi_id] then
			Logger:debug('[SmallMapService:onDelAoiObj] into', game_obj.aoi_id)
			self:_delItem(aoi_scene, aoi_id)
			SmallMapService:delSmallMapItem(aoi_scene, game_obj.aoi_id)
		end
	end
end

-- 通过仇敌偏移获得小地图ITEM ID
function SmallMapService:getItemByEnemyIndex( index )
	return SmallMapDao.small_map_enemy_id_beg + index - 1
end

-- 生成小地图ITEM ID
function SmallMapService:genItemId()
	local small_map_item_next_id = SmallMapDao.small_map_item_next_id
	SmallMapDao.small_map_item_next_id = small_map_item_next_id - 1
	return small_map_item_next_id
end

-- 初始化玩家可见的小地图ITEM对象列表
function SmallMapService:initPlayerViewItems(aoi_scene, character)
	local small_map_items = aoi_scene.small_map_items or {}
	aoi_scene.small_map_items = small_map_items
	
	-- 队员
	local team = TeamService:getTeamByCid(character.gcid)
	if team then
		SmallMapService:addItemsByTeam(aoi_scene, team)
	end
	
	-- 情侣
end

function SmallMapService:getItem(aoi_scene, item_id)
	local small_map_items = aoi_scene.small_map_items
	if not small_map_items then
		return 
	end
	return small_map_items[item_id]
end

function SmallMapService:getMyViewItems(character, aoi_scene)
	local items = aoi_scene.small_map_items
	local view_items = {}
	
	if items then
		for _, item in pairs(items) do
			local sort_id = item.sort_id
			if sort_id == SmallMapDefs.SMALL_MAP_SORT_ID_TEAM then
				local team = TeamService:getTeamByCid(character.gcid)
				if team and item.team_id == team.id then
					view_items[#view_items+1] = item
				end
			elseif sort_id == SmallMapDefs.SMALL_MAP_SORT_ID_LOVER then
				--
			elseif sort_id == SmallMapDefs.SMALL_MAP_SORT_ID_CHOU_DI then
				--
			else
				view_items[#view_items+1] = item
			end
		end
	end
	
	return view_items
end

do
	local rsp_opcode = opCodes.M2C_SMALL_MAP_ITEMS_ALL
	local msg_name = "PackSmallMap.M2C_SMALL_MAP_ITEMS_ALL"
	local msg_proto = {}
	function SmallMapService:sendItems(items, gpid)
		msg_proto.arr_items = table.values(items)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_SMALL_MAP_ITEMS_UPDATE
	local msg_name = "PackSmallMap.M2C_SMALL_MAP_ITEMS_UPDATE"
	local msg_proto = {}
	function SmallMapService:sendItemsUpdate(aoi_scene, arr_item, gpids)
		local gpids = gpids or GameObjectService:getGPids(aoi_scene)
		msg_proto.arr_items = arr_item
		if gpids and #gpids > 0 then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
		else
			--Logger:debug("[sendItemsUpdate] gpids is empty ", aoi_scene.scene_id, gpids)
		end
	end
	
	local msg_proto2 = {}
	function SmallMapService:sendItemUpdate(aoi_scene, item, gpids)
		local gpids = gpids or GameObjectService:getGPids(aoi_scene)
		msg_proto2.arr_items = {item}
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto2, nil, gpids)
	end
end

do
	local rsp_opcode = opCodes.M2C_SMALL_MAP_ITEMS_DEL
	local msg_name = "PackSmallMap.M2C_SMALL_MAP_ITEMS_DEL"
	local msg_proto = {}
	function SmallMapService:delSmallMapItems(aoi_scene, item_ids, gpids)
		local gpids = gpids or GameObjectService:getGPids(aoi_scene)
		msg_proto.aoi_ids = item_ids
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
	end
	
	local msg_proto2 = {}
	function SmallMapService:delSmallMapItem(aoi_scene, item_id, gpids)
		local gpids = gpids or GameObjectService:getGPids(aoi_scene)
		msg_proto2.aoi_ids = {item_id}
		if gpids and #gpids > 0 then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto2, nil, gpids)
		end
	end
end
