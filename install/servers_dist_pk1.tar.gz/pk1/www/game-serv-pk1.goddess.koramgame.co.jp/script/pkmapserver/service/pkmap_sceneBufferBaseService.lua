--[[
场景BUFFER基础servuce
author : xingzeng
date : 2012-03-27
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local table = table
local tableInsert = table.insert
local SceneBufferBaseDao = SceneBufferBaseDao
local SceneBufferRefBaseDao = SceneBufferRefBaseDao

SceneBufferBaseService = SceneBufferBaseService or {}

function SceneBufferBaseService:getSceneBufferRefBase(scene_base, scene_buffer_id)
	local scene_id = scene_base.id
	local scene_buffer_refs = SceneBufferRefBaseDao.data[scene_id]
	
	if table.isTableEmpty(scene_buffer_refs) then
		return
	end
	
	if scene_buffer_id then
		for _, scene_buffer_ref in pairs(scene_buffer_refs) do
			local scene_buffer_ids = scene_buffer_ref.scene_buffer_ids
			if array.indexof(scene_buffer_ids, scene_buffer_id) then
				return scene_buffer_ref
			end
		end
	else
		return scene_buffer_refs
	end
end

function SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
	return SceneBufferBaseDao.data[scene_buffer_id]
end

