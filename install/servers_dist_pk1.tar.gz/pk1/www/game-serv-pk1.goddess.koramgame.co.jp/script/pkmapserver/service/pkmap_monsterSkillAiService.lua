--[[
怪物技能aii系统service
author : suwin zhong
date : 2015-04-24
--]]

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local tableInsert = table.insert
local random = math.random
local ceil = math.ceil
local abs = math.abs
local cos =  math.cos
local sin = math.sin
local isTable = table.isTable
local externalCombineBit = external.combine_bit

local AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER		-- 角色
local AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT		-- 机器人

local EFFECT_SORT_ID_NORMAL = SkillDefs.EFFECT_SORT_ID_NORMAL		-- 攻击类技能
local EFFECT_SORT_ID_CONJURE = SkillDefs.EFFECT_SORT_ID_CONJURE		-- 召唤技能
local EFFECT_SORT_ID_BUFFER = SkillDefs.EFFECT_SORT_ID_BUFFER		-- buff技能
local EFFECT_SORT_ID_SPECIAL = SkillDefs.EFFECT_SORT_ID_SPECIAL		-- 特殊技能

local MOVE_TYPE_SPRINT = SkillDefs.MOVE_TYPE_SPRINT -- 冲刺 1
local MOVE_TYPE_JUMP = SkillDefs.MOVE_TYPE_JUMP		-- 跳跃 3

local EffectType_biansheng = EffectType.biansheng   -- 变身类BUFFER

local MonsterSkillAiDefs_TRIGGER_ID_FOR_HP_PERCENT = MonsterSkillAiDefs.TRIGGER_ID_FOR_HP_PERCENT	-- 血的百分比触发
local MonsterSkillAiDefs_TRIGGER_ID_FOR_DEAD = MonsterSkillAiDefs.TRIGGER_ID_FOR_DEAD				-- 死亡触发
local MonsterSkillAiDefs_TRIGGER_ID_FOR_DISTANCE = MonsterSkillAiDefs.TRIGGER_ID_FOR_DISTANCE		-- 距离触发
local MonsterSkillAiDefs_TRIGGER_ID_FOR_STUN = MonsterSkillAiDefs.TRIGGER_ID_FOR_STUN				-- 晕眩触发(沛然保证一个场景里，只有BOSS能让玩家晕眩，不会出现其他能导致玩家晕眩的情况，也就是肯定在攻击范围内)
local MonsterSkillAiDefs_TRIGGER_ID_FOR_HAS_MONSTER = MonsterSkillAiDefs.TRIGGER_ID_FOR_HAS_MONSTER -- 场景里有某些怪触发


MonsterSkillAiService = MonsterSkillAiService or {}

local MonsterAiService
local GameObjectService
local MonsterBaseService
local FightService
local BufferBaseService
local BufferService
local TrapService
function MonsterSkillAiService:onAfterLoadLua()
	MonsterAiService = _G.MonsterAiService
	GameObjectService = _G.GameObjectService
	MonsterBaseService = _G.MonsterBaseService
	FightService = _G.FightService
	BufferBaseService = _G.BufferBaseService
	BufferService = _G.BufferService
	TrapService = _G.TrapService
end


-- 触发技能(该接口在monsterAiService中有两处地方会调用，小心)
-- aoiScene : 场景对象
-- monster : 怪物
-- now_unix_time : 当前系统的秒数
-- return : boolean 是否有ai被激活, cd time
function MonsterSkillAiService:playMyAi(aoiScene, monster, now_unix_time)
	-- local
	local arr_monster_ai = monster.monster_ai
	local flg_played_ai = false -- 是否已经激活过一个ai
	local cool_msec = 0			-- 激活成功的ai要冷却的时间

	if isTable(arr_monster_ai) then
		-- 如果怪物处于变身状态，则跳过所有ai
		if BufferService:isInStatus(monster, EffectType_biansheng) then
			return flg_played_ai, cool_msec
		end

		-- value
		if not aoiScene then
			aoiScene = assert(GameObjectService:getAoiScene(monster))
		end
		if not now_unix_time then
			now_unix_time = Time:getSecondsNow()
		end

		local ai_id
		local ai_time_key
		local ai_nums_key
		local title = ''
		for _, now_monster_ai in pairs(arr_monster_ai) do
			-- 循环尝试触发身上的ai
			if not flg_played_ai then
				ai_id = now_monster_ai.id
				ai_time_key = 'time_' .. ai_id
				ai_nums_key = 'nums_' .. ai_id

				flg_played_ai, cool_msec = self:playPrepare(aoiScene, monster, now_monster_ai, now_unix_time, ai_time_key, ai_nums_key)

				if flg_played_ai then
					break
				end
			end
		end
	end

	return flg_played_ai, cool_msec
end


---------------------------------------------------------- 预备+触发 start -------------------------------------------------------------
do
	-- 做出蓄力动作
	-- aoiScene : 场景对象
	-- monster : 怪物
	-- monster_ai : ai对象
	-- now_unix_time : 当前系统的秒数
	-- key_time : ai触发时间对应的key
	-- key_nums : ai触发次数对应的key
	-- return boolean : AI是否被激活
	function MonsterSkillAiService:playPrepare(aoiScene, monster, monster_ai, now_unix_time, key_time, key_nums)
		-- local
		local monster_tmps = monster.tmps
		local ai_nums = monster_tmps.ai_datas[key_nums] -- 已经使用的次数
		local ai_time = monster_tmps.ai_datas[key_time] -- 可触发时间

		-- value
		local is_can_play, ai_targeter = self:isAiCanPlay(aoiScene, monster, monster_ai, now_unix_time, ai_nums, ai_time)

		-- 开始使用ai
		if is_can_play then
			-- 修改已触发次数和下一次允许使用的时间
			monster_tmps.ai_datas[key_nums] = ai_nums + 1
			monster_tmps.ai_datas[key_time] = now_unix_time + monster_ai.trigger_interval

			-- 是否概率触发成功
			local probas = monster_ai.trigger_percent or 0
			if self:isAiHit(probas) then
				-- 变成ai准备状态
				MonsterAiService:toAiPrepareState(monster, monster_ai, now_unix_time)

				-- 更新ai公共cd
				monster_tmps.ai_can_play_expire = Time:getSecondsNow() + (monster_ai.ai_cool_msec / 1000)

				-- 记录目标的位置
				if 1 == monster_ai.prepare_target_pos then
					self:saveAiTargeterPos(aoiScene, monster, monster_ai)
				end

				-- 有预备动作的才通知客户端
				-- (必须放在 "记录目标的位置" 的后面，不然里面给客户端的位置会出错)
				if 0 < monster_ai.prepare_msec then
					-- 通知客户端播放蓄力动作
					self:sendToClientPlayMonsterSkillAi(aoiScene, monster, monster_ai)
				end

				-- 返回给怪物系统，将怪物的行为延迟
				return true, monster_ai.play_cool_msec
			end
		end

		return false, 0
	end
end


do
	-- 怪物一次AI攻击效果
	-- aoiScene : 场景实例对象
	-- monster : 杀死玩家的怪物
	-- monster_ai : 本次要触发的ai
	function MonsterSkillAiService:playAiAttack(aoiScene, monster, monster_ai)
		-- local
		local monster_tmps = monster.tmps

		if 1 == monster_ai.play_skill_times then
			-- 只触发一次的
			monster_tmps.ai_playing_time = Time:getDelayMsTime(50 * 1000)
		else
			-- 需要触发多次的，准备下一次的时间
			monster_tmps.ai_playing_time = Time:getDelayMsTime(monster_ai.play_skill_interval * 1000)
		end

		-- 获取技能信息
		local skill_id = monster_ai.play_skill_id
		local skill = SkillBaseService:getDetailSkillInfoById(skill_id)
		local skillBase = skill.skill_base

		-- 技能播放前需要先瞬移(德古拉伯爵的血影星芒)
		-- need_shunyi = 1 : 预备结束后，客户端根据prepare包里面的位置信息模拟跳跃到指定位置
		-- 跳跃类技能(不朽之王的跳跃攻击) 跳劈的，将怪物瞬移到某个位置，然后在新位置进行攻击(客户端根据战斗包里的fighter.x，fighter.y参数模拟跳跃过程)
		if (1 == monster_ai.need_shunyi) or (MOVE_TYPE_JUMP == skillBase.move_type) then -- MOVE_TYPE_JUMP : 2
			FightService:moveToPos(monster, monster_tmps.ai_targeter_pos_x, monster_tmps.ai_targeter_pos_y)
		end

		-- 被攻击者
		local targeter = self:getTargeter(monster_ai, monster, skill, aoiScene)

		-- 检查是否可以攻击
		local is_can_attack = self:isCanAttackTargeter(monster, targeter, skill)
		if not is_can_attack then
			return
		end
	
		-- 获取攻击的位置信息
		local arr_pos
		arr_pos = self:getFightPos(monster_ai, monster, targeter, skill, aoiScene)

		-- 技能效果调度
		local skill_effect_sort_id = skillBase.effect_sort_id
		-- 攻击类技能
		if EFFECT_SORT_ID_NORMAL == skill_effect_sort_id then --------------------- 攻击
			-- 战斗
			local keep_on, error_id, arr_targeter = FightService:doFight(aoiScene, monster, targeter, arr_pos, skill)

			-- 如果是连击技能，则还需要加技能锁定，避免怪物在连击中被其他人攻击
			if FightService:isLianJiSkill(skillBase) then
				local monster_tmps = monster.tmps
				local is_lianji_hit = monster_tmps.fight_info.is_lianji_hit or 1 -- 是否连击命中
				if 1 == is_lianji_hit then -- 必须连击命中
					-- 技能播放结束时间
					monster_tmps.fight_expire = Time.time_now + skillBase.duration
					local is_fighter = true
					FightService:updateSkillLock(is_fighter, monster, skill)
				else
					print("怪物AI，对玩家使用连击被miss")
				end
			end

			-- 技能攻击事后处理
			FightService:doAfterFight(aoiScene, monster, targeter, arr_targeter)

			-- 正确的响应
			local ret_packet = FightService:buildBinPacket(aoiScene, monster, targeter, skill, arr_targeter, arr_pos, 0)
			if ret_packet then
				WorldPacket:m2cSendPacket(ret_packet)
			end

		elseif EFFECT_SORT_ID_CONJURE == skill_effect_sort_id then ---------------- 召唤
			-- 召唤
			local skillDetail = skill.skill_detail
			local call_traps = skillDetail.traps -- 召唤的是陷阱
			local call_monsters = skillDetail.monsters -- 召唤的是怪物
			local call_scene_event = skillDetail.scene_event -- 召唤的场景事件

			if call_traps then
				-- 召唤陷阱
				FightService:callTraps(aoiScene, monster, skill, arr_pos, 0)
			elseif call_monsters then
				-- 召唤怪物
				self:callMonsters(aoiScene, monster, call_monsters)
			elseif call_scene_event then
				-- 召唤场景事件
				-- 不需要做事，只需要通知客户端，其他的客户端去处理场景事件
			else
				print("MonsterSkillAiService:playAiAttack，未知的召唤类型，技能id：" .. skill_id .. "，策划没有录入要召唤什么")
				return
			end

			-- 非攻击类的战斗响应
			local ret_packet = FightService:buildNoAttackBinPacket(aoiScene, monster, nil, skill, arr_pos, 0)
			if ret_packet then
				WorldPacket:m2cSendPacket(ret_packet)
			end

		elseif EFFECT_SORT_ID_BUFFER == skill_effect_sort_id then ---------------- buffer
			-- local
			local arr_buffer_id = FightService:addBufferForFighter(aoiScene, monster, skill, false)

			-- 非攻击类的战斗响应
			local ret_packet = FightService:buildNoAttackBinPacket(aoiScene, monster, nil, skill, arr_pos, 0)
			if ret_packet then
				WorldPacket:m2cSendPacket(ret_packet)
			end

		elseif EFFECT_SORT_ID_SPECIAL == skill_effect_sort_id then ---------------- 特殊技能
			self:doSpecialAiSkill(aoiScene, monster, monster_ai, skill, arr_pos)

		else
			print("MonsterSkillAiService:playAiAttack，未知技能类型，技能id：" .. skill_id .. "，技能effect_sort_id：" .. skill_effect_sort_id)
		end

		-- 技能使用后处理(技能使用后，怪物需要死亡)(自爆 : 召唤一个陷阱，然后自己死掉)
		if 1 == skillBase.is_dead_when_use then
			self:monsterMustDead(aoiScene, monster)
		end

		-- 如果是多次触发的AI
		if 1 < monster_ai.play_skill_times then
			-- 检查ai目标是否还活着，如果死亡，则停止掉ai
			local ai_targeter = GameObjectService:getGameObjectByAoiId(aoiScene, monster_tmps.ai_targeter_aoi_id)
			local is_cancel_ai = false -- 是否取消ai
			if ai_targeter then
				if FightService:isDead(ai_targeter) then
					-- 目标已经死亡
					is_cancel_ai = true
				end
			else
				-- 目标对象已经不在该场景里了
				is_cancel_ai = true
			end

			-- 需要取消ai
			if is_cancel_ai then
				monster_tmps.ai_playing_expire = 0 -- 其实就是变成过期
			else
				-- 需要记住蓄力时候攻击位置的，需要更新目标的新位置点
				if (1 == monster_ai.prepare_target_pos) then
					self:saveAiTargeterPos(aoiScene, monster, monster_ai)
				end
			end
		end
	end


	-- 召唤怪物
	-- aoiScene : 场景实例对象
	-- monster : 召唤怪的父亲
	-- call_monsters : 要召唤的怪物
	function MonsterSkillAiService:callMonsters(aoiScene, monster, call_monsters)
		local call_monster_id  -- 要召唤的怪物id
		local call_monster_num -- 要召唤的怪物数量
		local parent_x = monster.x
		local parent_y = monster.y
		local init_x, init_y
		local scene_id = monster.scene_id -- 所在的场景id

		local parentMonsterTmps = monster.tmps.ai_child_monster_aoi_id
		for _, now_call_monster in pairs(call_monsters) do
			call_monster_id = now_call_monster.monster_id
			call_monster_num = now_call_monster.num

			for i = 1, call_monster_num do
				init_x, init_y = aoiScene:roundPos(parent_x, parent_y, 2) -- 随机2米内找个位置
				local theMonster = MonsterService:dymCreateMonster(aoiScene, call_monster_id, scene_id, init_x, init_y)
				tableInsert(parentMonsterTmps, theMonster.aoi_id)
			end
		end
	end


	-- 触发特殊ai技能
	-- aoiScene : 场景实例对象
	-- monster : 召唤怪的父亲
	-- monstar_ai : ai对象
	-- skill : 技能对象
	-- arr_pos : 位置信息
	local SkillDefs_SPECIAL_SORT_ID_FOR_DEL_MONSTER_HP_ADD_BUFF = SkillDefs.SPECIAL_SORT_ID_FOR_DEL_MONSTER_HP_ADD_BUFF
	local SkillDefs_SPECIAL_SORT_ID_FOR_ADD_TRAP_ROUND_ME = SkillDefs.SPECIAL_SORT_ID_FOR_ADD_TRAP_ROUND_ME
	function MonsterSkillAiService:doSpecialAiSkill(aoiScene, monster, monster_ai, skill, arr_pos)
		local spec_params = skill.skill_detail.spec_params
		local special_sort_id = spec_params.special_sort_id

		if SkillDefs_SPECIAL_SORT_ID_FOR_DEL_MONSTER_HP_ADD_BUFF == special_sort_id then
			-- 把某些怪物的血降低到某个程度，同时根据怪物的数量增加buff(AI参数)
			local monster_base_id = spec_params.monster_base_id
			local hp_percent = spec_params.hp_percent
			local add_buffer_id = spec_params.add_buffer_id
			
			local arr_monster = GameObjectService:getGameObjsByType(aoiScene, AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER)
			local monster_num = 0
			for _, now_monster in pairs(arr_monster) do
				if monster_base_id == now_monster.monster_base.id then
					if not FightService:isDead(now_monster) then
						-- 记录怪物数量
						monster_num = monster_num + 1

						-- 把怪物血量变成某个值
						if not self:isHpPercentOK(now_monster, hp_percent) then
							-- 变成百分比
							local max_hp = MonsterBaseService:getMonsterBaseVal(now_monster, 'max_hp')
							local target_hp = ceil(max_hp * hp_percent / 100)
							local add_hp = -(now_monster.hp - target_hp)
							FightService:addObjectHp(now_monster, add_hp, 0, true, aoiScene)
						end
					end
				end
			end

			if 0 < monster_num then
				-- 添加buffer到自己身上
				local ai_kill_monster_num = monster.tmps.ai_kill_monster_num or 0
				ai_kill_monster_num = ai_kill_monster_num + monster_num
				monster.tmps.ai_kill_monster_num = ai_kill_monster_num

				-- 加上buffer
				local now_bufferBase = BufferBaseService:getBufferBaseById(add_buffer_id)
				local new_buffer_value = ai_kill_monster_num * now_bufferBase.effect_value
				local is_add_buffer_sucess, is_need_bc = BufferService:addTmpBuffer(monster, now_bufferBase, new_buffer_value)
				BufferService:bcBuffers(aoiScene, monster)
			end

		elseif SkillDefs_SPECIAL_SORT_ID_FOR_ADD_TRAP_ROUND_ME == special_sort_id then
			-- 攻击者为的圆心，周围按角度召唤出陷阱，还有目标者的脚底下也出现陷阱
			-- {special_sort_id = 2, trap_id = 0, num = 0, angle = 0, radius = 0} 
			local trap_id = spec_params.trap_id -- 陷阱id
			local num = spec_params.num			-- 陷阱的数量
			local angle = spec_params.angle		-- 每个陷阱的角度
			local radius = spec_params.radius	-- 半径

			-- 循环召唤出身边的陷阱
			local trap
			local circle_x, circle_y = monster.x, monster.y
			local target_x, target_y
			local circle_angle
			for i = 1, num do
				circle_angle = i * angle
				target_x, target_y = self:getCirclePoint(circle_x, circle_y, radius, circle_angle)
				-- 非阻挡位置
				if aoiScene:canPass(target_x, target_y) then
					trap = TrapService:createTrap(aoiScene, trap_id, target_x, target_y, monster)
				end
			end

			-- 召唤出目标脚下的陷阱
			target_x, target_y = arr_pos.target_x, arr_pos.target_y
			trap = TrapService:createTrap(aoiScene, trap_id, target_x, target_y, monster)

		else
			print("MonsterSkillAiService:doSpecialAiSkill，未知的特殊技能类型子类型")
		end
	end
end
---------------------------------------------------------- 预备+触发 end ---------------------------------------------------------------


--------------------------------------------- 辅助方法 start --------------------------------------------------------
-- 是否ai的前提条件能满足
-- aoiScene : 场景实例对象
-- monster : 怪物
-- monster_ai : ai对象
-- now_unix_time : 当前系统时间(秒)
-- ai_used_nums : 该ai已经触发次数
-- ai_use_time : 该ai能触发的时间点
-- ai_percent_key : 该ai使用的剩余血百分比key
function MonsterSkillAiService:isAiCanPlay(aoiScene, monster, monster_ai, now_unix_time, ai_used_nums, ai_use_time, ai_percent_key)
	-- local
	local monster_tmps = monster.tmps
	local ai_targeter -- 本次ai针对的目标对象

	-- value
	local is_can_play = false

	-- 先走公共cd判断
	local ai_can_play_expire = monster_tmps.ai_can_play_expire
	if now_unix_time < ai_can_play_expire then
		return is_can_play
	end

	-- 判断怪物本身是否被连击中
	-- 这里不需要判断，因为外层的调用哪里已经判断过了

	-- 触发次数上限
	local trigger_num = monster_ai.trigger_num

	-- 还可以触发
	if trigger_num > ai_used_nums then
		-- 已经到时间可以触发
		if now_unix_time >= ai_use_time then
			-- local
			local MonsterSkillAiDefs = MonsterSkillAiDefs
			local trigger_id = monster_ai.trigger_id	   -- 触发条件
			local trigger_params = monster_ai.trigger_params -- 触发条件参数

			if MonsterSkillAiDefs_TRIGGER_ID_FOR_HP_PERCENT == trigger_id then
				-- 按hp百分比触发
				if self:isHpPercentOK(monster, trigger_params.hp_perc) then
					is_can_play = true

					-- 默认当前攻击目标
					monster_tmps.ai_targeter_aoi_id = monster_tmps.target_aoi_id
				end

			elseif MonsterSkillAiDefs_TRIGGER_ID_FOR_DEAD == trigger_id then
				-- 死亡触发
				if 0 == monster.hp then
					is_can_play = true

					-- 默认当前攻击目标
					monster_tmps.ai_targeter_aoi_id = monster_tmps.target_aoi_id
				end

			elseif MonsterSkillAiDefs_TRIGGER_ID_FOR_DISTANCE == trigger_id then
				-- 距离的判断(圆)
				local min_dis = trigger_params['min'] -- 最小距离
				local max_dis = trigger_params['max'] -- 最大距离

				-- 只找玩家或者机器人
				local monster_x = monster.x
				local monster_y = monster.y
				local dest_type = externalCombineBit(AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER, AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT)
				local arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(monster.aoi_obj, monster_x, monster_y, max_dis, dest_type)
				if 0 < aoiObj_num then
					local now_aoi_id
					for _, now_aoiObj in pairs (arr_aoiObj) do
						now_aoi_id = now_aoiObj.obj_id
						local now_targter = GameObjectService:getGameObjectByAoiId(aoiScene, now_aoi_id)
						if FightService:isCanAttack(monster, now_targter) then -- 可以被攻击
							if 0 == min_dis then
								is_can_play = true
								ai_targeter = now_targter
								break
							else
								-- 判断最小距离
								if not Formula:isNearbyDistance(monster_x, monster_y, now_targter.x, now_targter.y, min_dis) then
									is_can_play = true
									ai_targeter = now_targter
									break
								end
							end
						end
					end
				end

				if is_can_play then
					-- 记录怪物ai要攻击的对象
					monster_tmps.ai_targeter_aoi_id = ai_targeter.aoi_id
				end

			elseif MonsterSkillAiDefs_TRIGGER_ID_FOR_STUN == trigger_id then
				-- 查找我视野里的玩家，有没有是晕眩的
				local arr_character = GameObjectService:getGameObjsByType(aoiScene, AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER)
				for _, now_character in pairs(arr_character) do
					if BufferService:isInStatus(now_character, EffectType.giddiness) then
						is_can_play = true

						-- 默认当前攻击目标
						monster_tmps.ai_targeter_aoi_id = monster_tmps.target_aoi_id
						break
					end
				end


			elseif MonsterSkillAiDefs_TRIGGER_ID_FOR_HAS_MONSTER == trigger_id then
				-- trigger
				local trigger_monster_base_id = trigger_params.monster_base_id or 1
				-- 场景里存在某些特殊的怪物
				local arr_monster = GameObjectService:getGameObjsByType(aoiScene, AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER)
				for _, now_monster in pairs(arr_monster) do
					if trigger_monster_base_id == now_monster.monster_base.id then
						is_can_play = true

						-- 默认当前攻击目标
						monster_tmps.ai_targeter_aoi_id = monster_tmps.target_aoi_id
						break
					end
				end
			end
		end
	end

	return is_can_play
end


-- 获取被攻击者
-- return is_can_do, object / nil
function MonsterSkillAiService:getTargeter(monster_ai, monster, skill, aoiScene)
	local targeter = nil
	local is_need_targeter = false

	---------------------------------- 是否需要目标 start -------------------------------------------
	-- 需要实时根据玩家位置的
	if 0 == monster_ai.prepare_target_pos then
		is_need_targeter = true
	end

	-- 如果怪物攻击的技能是连击
	if FightService:isLianJiSkill(skill.skill_base) then
		is_need_targeter = true
	end
	---------------------------------- 是否需要目标 end ---------------------------------------------

	-- 获取目标者
	if is_need_targeter then
		local ai_targeter_aoi_id = monster.tmps.ai_targeter_aoi_id
		if 0 < ai_targeter_aoi_id then
			targeter = GameObjectService:getGameObjectByAoiId(aoiScene, ai_targeter_aoi_id)
		end
	end

	return targeter
end


-- 记录蓄力时候，ai目标的位置
function MonsterSkillAiService:saveAiTargeterPos(aoiScene, monster, monster_ai)
	local monster_tmps = monster.tmps
	local ai_targeter = GameObjectService:getGameObjectByAoiId(aoiScene, monster_tmps.ai_targeter_aoi_id)
	if ai_targeter then
		monster_tmps.ai_targeter_pos_x = ai_targeter.x
		monster_tmps.ai_targeter_pos_y = ai_targeter.y
	end
end


-- 获取攻击的位置信息
function MonsterSkillAiService:getFightPos(monster_ai, monster, targeter, skill, aoiScene)
	-- local
	local monster_tmps = monster.tmps
	local skillBase = skill.skill_base

	local arr_pos = FightService:getDefaultPos()
	-- 记录攻击者攻击时候的位置(为了与陷阱攻击统一起来)
	arr_pos.fighter_attack_x = monster.x
	arr_pos.fighter_attack_y = monster.y

	local prepare_target_pos = monster_ai.prepare_target_pos
	-- 实时更新玩家的位置
	if 0 == prepare_target_pos then
		arr_pos.target_x = targeter and targeter.x or monster_tmps.ai_targeter_pos_x
		arr_pos.target_y = targeter and targeter.y or monster_tmps.ai_targeter_pos_y
	elseif 1 == prepare_target_pos then
		-- 保留蓄力时候记录的位置
		arr_pos.target_x = monster_tmps.ai_targeter_pos_x
		arr_pos.target_y = monster_tmps.ai_targeter_pos_y
	else
		-- 以攻击者本身位置来触发 -- 2 == prepare_target_pos
		arr_pos.target_x = monster.x
		arr_pos.target_y = monster.y
	end

	-- 冲刺(群攻)
	-- (客户端模拟冲刺的时候，战斗包里面的targeter.aoi_id必须是0，不然没法模拟冲刺，会导致仅仅冲刺到targeter.aoi_id那里就停止)
	if FightService:isChongCiSkill(skillBase) then
		-- 冲刺的最大距离
		local self_slow_move_dist = skillBase.self_slow_move_dist

		-- 获取冲刺的结果位置(小蒋提供接口)(需要考虑阻挡)
		local chongci_x, chongci_y = aoiScene:getChongFengPos(monster.x, monster.y, arr_pos.target_x, arr_pos.target_y, self_slow_move_dist)

		-- 用于矩形选取攻击范围
		arr_pos.target_x = chongci_x
		arr_pos.target_y = chongci_y

		-- 怪物在攻击完成后需要停留的位置
		arr_pos.fighter_new_x = chongci_x
		arr_pos.fighter_new_y = chongci_y

	-- 除了冲刺技能外(其他的前方矩形攻击技能(要找出最大的范围)，冲刺可能因为阻挡而半路停下，其他的则不会
	elseif FightService:isRectAreaTypeSkill(skillBase) then
		local dist = skillBase.area_length
		-- 忽略阻挡，取最远距离
		local farthest_x, farthest_y = aoiScene:getAttackFarthestPos(monster.x, monster.y, arr_pos.target_x, arr_pos.target_y, dist)

		-- 用于矩形选取攻击范围
		arr_pos.target_x = farthest_x
		arr_pos.target_y = farthest_y
	end

	return arr_pos
end


-- 是否允许攻击被攻击者(连击，需要判断对手是否在可攻击范围里)
-- return boolean
function MonsterSkillAiService:isCanAttackTargeter(monster, targeter, skill)
	-- 默认可以攻击
	local is_can_attack_targeter = true
	local skillBase = skill.skill_base

	-- 连击的需要特殊处理
	if FightService:isLianJiSkill(skillBase) then
		-- 连击，先默认不能攻击
		is_can_attack_targeter = false

		-- 严格条件判断
		if targeter then
			local is_can_attack, is_can_follow, error_text = FightService:isCanAttack(monster, targeter) -- 非死亡/非锁定/非保护
			if is_can_attack then
				-- 检查攻击者和被攻击者之间的距离
				local skill_distance = skillBase.distance or 0 -- 技能作用距离
				-- 距离足够近
				if Formula:isNearbyDistance(monster.x, monster.y, targeter.x, targeter.y, skill_distance) then
					is_can_attack_targeter = true
				else
					print("连击无法攻击的原因 : 距离太远", monster.x, monster.y, targeter.x, targeter.y, skill_distance)
				end
			else
				print("连击无法攻击的原因 : ", error_text)
			end
		else
			print("连击无法攻击的原因 : 找不到攻击目标")
		end
	end

	return is_can_attack_targeter
end


-- 生命值百分比是否ok
-- monster : 怪物
-- percent : 生命百分比
function MonsterSkillAiService:isHpPercentOK(monster, percent)
	local hp = monster.hp

	if 0 < hp then
		local max_hp = MonsterBaseService:getMonsterBaseVal(monster, 'max_hp')
		if 0 < max_hp then
			local now_percent = (hp / max_hp) * 100
			if now_percent <= percent then
				return true
			end
		end
	end

	return false
end


-- 丢失生命值百分比是否ok
-- monster : 怪物
-- percent : 降低的生命百分比
-- percent_key : 记录百分比的key
function MonsterSkillAiService:isLostHpPercentOK(monster, percent, percent_key)
	local hp = monster.hp

	if 0 < hp then
		local max_hp = MonsterBaseService:getMonsterBaseVal(monster, 'max_hp')
		if 0 < max_hp then
			local monster_tmps = monster.tmps
			local now_percent = hp / max_hp * 100
			local last_trigger_percent = monster_tmps[percent_key]
			local new_trigger_percent = last_trigger_percent - percent
			if new_trigger_percent > now_percent then
				monster_tmps[percent_key] = new_trigger_percent
				return true
			end
		end
	end

	return false
end


-- 是否在距离范围条件里
-- monster : 怪物
-- targeter : 目标对象
-- dis_type : 判断的条件(1 : 在距离范围内， 2 : 在距离的范围外)
-- trigger_param : 触发参数
function MonsterSkillAiService:isDistanceOK(monster, targeter, dis_type, trigger_param)

	-- 计算两者距离
	local distance = Formula:distance(monster.x, monster.y, targeter.x, targeter.y)
	-- 范围内
	if MonsterSkillAiDefs.DISTANCE_TYPE_FOR_INSIDE == dis_type then
		if distance <= trigger_param then
			return true
		end
	else
		-- 范围外
		if distance > trigger_param then
			return true
		end
	end

	return false
end


-- AI是否可以概率触发
-- probas : 概率(0 - 1的范围)
-- return true/false
function MonsterSkillAiService:isAiHit(probas)
	probas = probas * 100
	local compare = random(1, 100)
	if probas >= compare then
		return true
	else
		return true
		-- return false
	end
end


do
	-- 强制让怪物死亡
	function MonsterSkillAiService:monsterMustDead(aoiScene, monster)
		-- 血条
		local hp_index = FightService:getHpInfo(monster)

		-- 把怪物的血清空
		local add_hp = -monster.hp
		monster.hp = 0

		-- 发送血量更新
		local arr_aoi_change_hp = {FightService:newObjChangeHp(monster.aoi_id, hp_index, add_hp, monster.hp)}
		FightService:sendObjsChangeHp(aoiScene, monster, arr_aoi_change_hp)

		-- 怪物变成死亡状态(保留尸体)
		MonsterAiService:toPreDeadState(monster)

		-- 停止怪物移动(小蒋提供接口)
		MotionService:stop(monster)
	end
end


do
	-- 根据圆心，半径，角度获取一个点
	-- circle_x : 圆心x
	-- circle_y : 圆心y
	-- circle_r : 半径
	-- circle_angle : 角度
	-- return new_x, new_y
	function MonsterSkillAiService:getCirclePoint(circle_x, circle_y, circle_r, circle_angle)
		local new_x = circle_x + circle_r * cos(circle_angle * 3.14 / 180)
		local new_y = circle_y + circle_r * sin(circle_angle * 3.14 / 180)

		return new_x, new_y
	end
end


do
	-- 发送怪物触发技能ai的包给客户端
	-- aoiScene : 场景实例
	-- monster : 怪物对象
	-- monster_ai : 怪物ai对象
	local msg_name = "PackMonsterSkillAi.M2C_FIGHT_MONSTER_SKILL_AI_PREPARE"
	function MonsterSkillAiService:sendToClientPlayMonsterSkillAi(aoiScene, monster, monster_ai)
		-- local
		local ret = {}
		local monster_tmps = monster.tmps

		-- 响应给客户端
		local opcode = opCodes.M2C_FIGHT_MONSTER_SKILL_AI_PREPARE
		local ret_data = {}
		-- 包结构
		ret_data.aoi_id = monster.aoi_id -- 怪物的aoi_id
		ret_data.ai_id = monster_ai.id -- ai的id
		ret_data.play_time = Time.time_now -- 触发时间
		ret_data.ai_targeter_aoi_id = monster_tmps.ai_targeter_aoi_id -- 本次ai作用的对象的aoi_id
		ret_data.scene_ins_id = monster.space_id -- 场景实例id
		ret_data.prepare_x = monster_tmps.ai_targeter_pos_x -- 记录的目标的x坐标(prepare_target_pos = 1 的时候客户端才会用)
		ret_data.prepare_y = monster_tmps.ai_targeter_pos_y -- 记录的目标的y坐标(prepare_target_pos = 1 的时候客户端才会用)
		-- print("准备通知...", monster_tmps.ai_targeter_pos_x, monster_tmps.ai_targeter_pos_y)

		local arr_bc_gpid = GameObjectService:getFovGPids(monster, aoiScene)
		WorldPacket:m2cSendOKProtoBuf(opcode, msg_name, ret_data, 0, arr_bc_gpid)
	end
end
--------------------------------------------- 辅助方法 end ----------------------------------------------------------