--[[
摇骰子奖励系统servuce
author : xingzeng
date : 2014-08-15
]]--

local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local type = type
local opCodes = opCodes
local string_len = string.len
local math_random = math.random
local RewardShaiziDao = RewardShaiziDao

RewardShaiziService = RewardShaiziService or {}

-- 随机生成个玩家的骰子点数,并发奖
function RewardShaiziService:genShaiziDianshu(arr_character, reward_equips, reward_module_id)
	Logger:info('[RewardShaiziService:genShaiziDianshu] into')
	local jie_id = RewardShaiziService:genJieId()
	local jie_id2reward_shaizis = RewardShaiziDao.jie_id2reward_shaizis
	local reward_shaizis = {}
	jie_id2reward_shaizis[jie_id] = reward_shaizis
	
	local max_dianshu = 0
	
	-- 随机每个人的点数
	for _, character in pairs(arr_character) do
		local gcid = character.id
		local dianshu = tonumber(math_random(1, 6) .. math_random(1, 6))
		reward_shaizis[gcid] = RewardShaizi:new(jie_id, reward_module_id, gcid, character.nick, dianshu, reward_equips)
		if max_dianshu < dianshu then
			max_dianshu = dianshu
		end
	end
	
	for _, character in pairs(arr_character) do
		local reward_shaizi = reward_shaizis[character.gcid]
		
		-- 标志最高点数的玩家
		if reward_shaizi.dianshu >= max_dianshu then
			reward_shaizi.is_first = true
		end
		
		-- RSP
		self:sendRewardShaiziInfo(character, reward_shaizi)
		
		-- 发奖
		local pack_data = {
			gpid = character.gpid,
			gcid = character.gcid,
			reward_shaizi = reward_shaizi,
		}
		ServerCall:addTimer('RewardShaiziService:assignReward', 0, pack_data, RewardShaiziDefs.YAO_SHAIZI_TIME * 1000, 1)
	end
	
	-- 广播
	ServerCall:addTimer('RewardShaiziService:bc', 0, {jie_id=jie_id}, RewardShaiziDefs.YAO_SHAIZI_TIME * 1000, 1)
end

-- 发骰子奖励
function RewardShaiziService:assignReward(_, pack_data)
	local reward_shaizi = pack_data.reward_shaizi
	
	-- 已经发放
	assert(not reward_shaizi.is_assigned_reward)
	
	-- 发放奖励
	reward_shaizi.is_assigned_reward = true
	local arr_datas = reward_shaizi
	RewardService:reward(Statics.PK_GAME_TYPE_ID_REWARD_SHAIZI, 0, pack_data.gpid, pack_data.gcid, arr_datas)
	
end

-- 广播
function RewardShaiziService:bc(_, data)
	local jie_id = data.jie_id
	local reward_shaizis = RewardShaiziDao.jie_id2reward_shaizis[jie_id]
	if not reward_shaizis then
		Logger:fatal('参数错误：没有该骰子奖励.' .. jie_id)
	end
	
	-- 场景广播点数
	for _, reward_shaizi in pairs(reward_shaizis) do
		
	end
	
	-- 获得奖励的广播
	for _, reward_shaizi in pairs(reward_shaizis) do
		if reward_shaizi.is_first then
			
		end
	end
end

-- 获取届ID
function RewardShaiziService:genJieId()
	RewardShaiziDao.max_jie_id = RewardShaiziDao.max_jie_id + 1
	return RewardShaiziDao.max_jie_id
end

-- 通知摇骰子奖励
do
	local rsp_opcode = opCodes.PKM2C_REWARD_SHAIZI_INFO
	local msg_name = "PackRewardShaizi.PKM2C_REWARD_SHAIZI_INFO"
	local msg_proto = {}
	function RewardShaiziService:sendRewardShaiziInfo(character, reward_shaizi)
		msg_proto.jie_id = reward_shaizi.jie_id
		msg_proto.dianshu = reward_shaizi.dianshu
		msg_proto.is_first = reward_shaizi.is_first
		msg_proto.reward_equips = reward_shaizi.reward_equips
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end
