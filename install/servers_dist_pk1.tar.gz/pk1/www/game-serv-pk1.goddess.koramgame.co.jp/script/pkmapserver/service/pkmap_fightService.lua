--[[
战斗系统 service
author : shuyi.zhong
date : 2014-10-27
--]]

local WorldPacket = WorldPacket

local Statics = Statics
local SkillDefs = SkillDefs
local FightDefs = FightDefs
local EffectType = EffectType
local CharacterDefs = CharacterDefs
local PetDefs = PetDefs

local Time = Time
local ceil = math.ceil
local table = table
local floor = math.floor
local min = math.min
local max = math.max
local abs = math.abs
local EffectType = EffectType
local type = type
local tableInsert = table.insert
local random = math.random
local isTable = table.isTable
local sizeTable = table.sizeTable
local inArray = array.in_array
local externalCombineBit = external.combine_bit

local writeInt = FastPacket.writeInt
local writeIntWithSignBit = FastPacket.writeIntWithSignBit -- 是用于有可能出现负数的数值。用于优化传输，如果确认只有正数的数值传输就用writeInt
local writeUInt = FastPacket.writeUInt
local writeByte = FastPacket.writeByte
local writeUShort = FastPacket.writeUShort
local writeCoord = FastPacket.writeCoord	
local writeLong = FastPacket.writeLong -- U64
local ext_set_bit = external.set_bit

local AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER		-- 角色
local AoiObjectType_AOI_OBJECT_TYPE_ID_PET = AoiObjectType.AOI_OBJECT_TYPE_ID_PET			-- 幻兽
local AoiObjectType_AOI_OBJECT_TYPE_ID_MONSTER = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER	-- 怪物
local AoiObjectType_AOI_OBJECT_TYPE_ID_TRAP = AoiObjectType.AOI_OBJECT_TYPE_ID_TRAP			-- 陷阱
local AoiObjectType_AOI_OBJECT_TYPE_ID_BEAST = AoiObjectType.AOI_OBJECT_TYPE_ID_BEAST		-- 召唤兽
local AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT		-- 机器人
local AoiObjectType_AOI_OBJECT_TYPE_ID_GUARD_NPC = AoiObjectType.AOI_OBJECT_TYPE_ID_GUARD_NPC -- 守护NPC

local CharacterDefs_PROF_ID_FOR_ZHAOHUANSHI = CharacterDefs.PROF_ID_FOR_ZHAOHUANSHI -- 召唤师
local PetDefs_PET_SORT_ID_HP = PetDefs.PET_SORT_ID_HP -- 生命型幻兽

-- 获取当前要被攻击的血条和血条拥有者(内层幻兽/外层幻兽/角色/怪物/等等)
local CharacterDefs_CHARACTER_HP_INDEX_MAX_HP = CharacterDefs.CHARACTER_HP_INDEX_MAX_HP
local CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_2 = CharacterDefs.CHARACTER_HP_INDEX_MAX_HP_2
local CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_3 = CharacterDefs.CHARACTER_HP_INDEX_MAX_HP_3

local PetDefs_HETI_POS_IN = PetDefs.HETI_POS_IN   -- 合体内层幻兽
local PetDefs_HETI_POS_OUT = PetDefs.HETI_POS_OUT -- 合体外层幻兽

local ResultTypeHit = FightDefs.ResultTypeHit -- 命中
local ResultTypeMiss = FightDefs.ResultTypeMiss -- 闪避
local ResultTypeParry = FightDefs.ResultTypeParry -- 格挡
local ResultTypeCrit = FightDefs.ResultTypeCrit -- 暴击

local SKILL_EFFECT_SORT_ID_NORMAL = SkillDefs.EFFECT_SORT_ID_NORMAL -- 攻击类的技能
local AREA_TYPE_ID_SELF_CIRCLE = SkillDefs.AREA_TYPE_ID_SELF_CIRCLE -- 自己为圆心的圆形
local AREA_TYPE_ID_DEST_CIRCLE = SkillDefs.AREA_TYPE_ID_DEST_CIRCLE -- 目标为圆心的圆形
local AREA_TYPE_ID_SPRINT_RECT_CIRCLE = SkillDefs.AREA_TYPE_ID_SPRINT_RECT_CIRCLE -- 冲刺 路上矩形 加 目标点圆形
local AREA_TYPE_ID_SPRINT_RECT = SkillDefs.AREA_TYPE_ID_SPRINT_RECT -- 冲刺 路上矩形
local AREA_TYPE_ID_FRONT_RECT = SkillDefs.AREA_TYPE_ID_FRONT_RECT   -- 前方矩形

local SkillDefs_SKILL_PROF_FACTION_WULI = SkillDefs.SKILL_PROF_FACTION_WULI -- 物理攻击技能


FightService = FightService or {}


local CharacterService
local GameObjectService
local ChPetService
local BufferService
local ChSkillService
local SkillBaseService
local BeastService
local MonsterBaseService
local MotionService
local MonsterAiService
local MonsterService
local FightHelperService
local SafeModeService
function FightService:onAfterLoadLua()
	CharacterService = _G.CharacterService
	GameObjectService = _G.GameObjectService
	ChPetService = _G.ChPetService
	BufferService = _G.BufferService
	ChSkillService = _G.ChSkillService
	SkillBaseService = _G.SkillBaseService
	BeastService = _G.BeastService
	MonsterBaseService = _G.MonsterBaseService
	MotionService = _G.MotionService
	MonsterAiService = _G.MonsterAiService
	MonsterService = _G.MonsterService
	FightHelperService = _G.FightHelperService
	SafeModeService = _G.SafeModeService
end


-- 进行一次攻击
local g_is_this_attack_pvp = true -- 本次攻击是否是pvp攻击
local g_do_fight_mark_id = 1 -- 攻击记号id
local g_arr_helper_del_hp_object -- 本次攻击帮助抵扣血的对象列表

do
	function FightService:doFight(aoiScene, fighter, targeter, arr_pos, skill, arr_targeter, outside_known_lost_hp)
		-- 一次攻击的全局信息
		g_do_fight_mark_id = g_do_fight_mark_id + 1
		g_arr_helper_del_hp_object = {}

		-- 是否是已知扣血的(陷阱等)
		local outside_known_lost_hp = outside_known_lost_hp or 0

		-- local
		local skillBase, skillDetail
		local skill_xixue_percent = 0 -- 技能吸血百分比
		if 0 == outside_known_lost_hp then
			-- 必须是经过技能计算的
			skillBase = skill.skill_base
			skillDetail = skill.skill_detail

			-- 技能吸血百分比
			local skillDetail_extraSelfEffect = skillDetail.extra_self_effect
			if skillDetail_extraSelfEffect then
				skill_xixue_percent = skillDetail_extraSelfEffect.extra_xixue_percent or 0
			end
		end

		local targeter_num = 0
		if not arr_targeter then
			-- 获取目标对象列表
			arr_targeter, targeter_num = self:getTargets(aoiScene, fighter, targeter, arr_pos, skill)
		else
			-- 已知目标列表(角色战斗现在都是信任客户端的，这个才是常态)
			targeter_num = sizeTable(arr_targeter)
		end

		-- 初始化攻击者的战斗参数
		self:initFighterFightTmps(fighter)
		local fighter_tmps_fight_info = fighter.tmps.fight_info
		
		------------------------------------ 开始扣血计算 start ---------------------------------------
		local is_need_move = true -- 是否需要移动位置(连击被闪避，则不移动攻击方和被攻击方位置/冲刺的miss则还是要移动)

		-- 神兵技能(召唤师) : 玩家中了沉默不能使用技能，具体为3秒以下的CD变成3秒，普通攻击不受影响
		local sb_chenmo_fast_obj_rate = 0
		if self:isCharacter(fighter) then
			if self:isZhaoHuanShi(fighter) then
				sb_chenmo_fast_obj_rate = self:getShengBingSkill(fighter, 'sb_chenmo_fast_obj_rate')
			end
		end

		-- 释放技能效果
		for i = 1, targeter_num do
			local now_targeter = arr_targeter[i]

			if now_targeter then
				-- 初始化被攻击者战斗参数
				self:initTargeterFightTmps(now_targeter)

				-- 初始化被攻击者幻兽天赋
				self:initTargeterPetTianFu(aoiScene, now_targeter)

				-- 初始化本次攻击的类型(pvp/pve等)，每次攻击分别判断
				self:setAttackIsPvp(fighter, now_targeter)

				local now_targeter_tmps_fight_info = now_targeter.tmps.fight_info
				now_targeter_tmps_fight_info.targeter_is_real_targeter = 1 -- 是真实的被攻击者(不是只帮忙抵扣血的而已)

				local harm_total = 0 -- 伤害值总数
				local harm_radix = 1 -- 伤害倍数
				local is_miss = false -- 是否被闪避
				local action_id = ResultTypeHit
				local known_lost_hp = 0 -- 已知扣血对象扣血的值
				local now_fight_result = ResultTypeHit -- 默认普通命中
				local pet_tianfu_parry_fanji_attack = 0 -- 格挡反击伤害值

				-- 是否是已知扣血的
				if 0 < outside_known_lost_hp then
					known_lost_hp = FightHelperService:isKnownLostHpObject(fighter, now_targeter)
					if 0 == known_lost_hp then -- 优先使用固定扣血者的
						known_lost_hp = outside_known_lost_hp
					end
				else
					if SceneDefs:isInShengcun(aoiScene) then
					-- if true then
						-- 丧尸危机，逻辑特殊
						known_lost_hp = FightHelperService:getShengCunLostHp(fighter, now_targeter)
					else
						-- 某些攻击也是属于已知扣血额的
						known_lost_hp = FightHelperService:isKnownLostHpObject(fighter, now_targeter)
					end
				end

				if 0 == known_lost_hp then -- 走圆桌理论
					local true_targeter = self:getNowTrueTargeter(now_targeter)
					now_fight_result = self:getFightResult(fighter, true_targeter, skill)
				end

				-- 闪避
				if now_fight_result == ResultTypeMiss then
					action_id = ResultTypeMiss

					if self:isLianJiSkill(skillBase) then -- 连击miss，则不移动
						is_need_move = false

						fighter_tmps_fight_info.is_lianji_hit = 0 -- 连击miss，不锁定角色等
					end

					is_miss = true
				else
					-- 暴击
					if now_fight_result == ResultTypeCrit then
						harm_radix = 1.5 -- 暴击是1.5倍伤害
						action_id = ResultTypeCrit

						-- 幻兽天赋额外暴击伤害(屠戮成性)
						local pet_tianfu_bj_harm_radix = self:getPetTianFuValue(fighter, 'bj_harm_perc_target')
						harm_radix = harm_radix * (1 + pet_tianfu_bj_harm_radix)

					elseif now_fight_result == ResultTypeParry then
						harm_radix = 0.5 -- 格挡是0.5倍伤害
						action_id = ResultTypeParry

						-- 格挡的幻兽天赋额外逻辑(例如反戈一击)
						pet_tianfu_parry_fanji_attack = self:getPetTianFuForParryFanjiAttack(now_targeter)
					end

					-- 攻击次数
					local hit_times = skillBase and skillBase.lianji_num or 1
					if 0 == known_lost_hp then
						-- 伤害系数额外加成：例如幻兽天赋额外等等
						harm_radix = self:extraHarmRadix(harm_radix, fighter, now_targeter, skill)
					end

					-- 循环计算伤害
					local true_targeter
					local harm = 0 -- 伤害值
					for hit_index = 1, hit_times do
						harm = 0

						-- 找到真实的受击者
						true_targeter = self:getNowTrueTargeter(now_targeter)

						if 0 < known_lost_hp then
							-- 固定扣血的
							harm = known_lost_hp
						else
							-- 公式计算的
							harm = self:calcHarm(fighter, true_targeter, skill, harm_radix, action_id) * 1
						end

						-- if self:isCharacter(fighter) or self:isPet(fighter) then
						--	harm = 1 --- test
						-- end

						-- 扣不同的血
						local targeter_hp_index, targeter_del_hp, targeter_new_hp = self:delHp(now_targeter, true, harm, 0)
						self:logTargeterDelHp(now_targeter, targeter_hp_index, -targeter_del_hp, targeter_new_hp)

						-- 累计总值
						harm_total = harm_total + harm

						-- 格挡反击扣血
						if (0 == known_lost_hp) and (0 < pet_tianfu_parry_fanji_attack) then
							-- 确保陷阱，防御塔等不会被格挡反击，免得出现莫名其妙的问题
							-- 攻击者可以被反击，但不能被反击死亡，不然群攻的情况很难区分是谁杀了他，同时对其他系统的通知也会变得很复杂
							local fighter_hp_index, fighter_del_hp, fighter_new_hp = self:delHp(fighter, false, pet_tianfu_parry_fanji_attack, 0)
							self:logTargeterDelFighterHp(now_targeter, fighter_hp_index, -fighter_del_hp, fighter_new_hp)
							-- 特别注意，这里填入now_targeter是正确的，因为谁产生的反戈是记录在反击者身上的
						end

						-- 合体幻兽被攻击，有的合体幻兽死亡会触发幻兽天赋，替主人添加有益的buff
						self:onHetiPetAttacked(targeter_hp_index, targeter_new_hp, true_targeter)

					end -- for hit_index = 1, hit_times do
				end

				-- 扣血
				now_targeter_tmps_fight_info.targeter_total_del_hp = -harm_total -- 记录总的血的变化
				now_targeter_tmps_fight_info.action_id = action_id
				-- table.dump(now_targeter_tmps_fight_info, 3)
				
				if not is_miss then
					-------------- 替攻击者加血 start -------------
					local fighter_add_hp = 0		-- 任意加层次的血
					local fighter_add_inpet_hp = 0  -- 指定加内层幻兽血
					local fighter_add_outpet_hp = 0 -- 指定加外层幻兽血
					-- 吸血技能
					if 0 < skill_xixue_percent then
						fighter_add_hp = fighter_add_hp + ceil(harm_total * skill_xixue_percent)
					end
					-- 幻兽天赋
					local pet_tianfu_add_hp, pet_tianfu_add_inpet_hp, pet_tianfu_add_outpet_hp = self:getPetTianFuKillAddHpPercOrRelive(fighter, now_targeter)
					if 0 < pet_tianfu_add_hp then
						fighter_add_hp = fighter_add_hp + pet_tianfu_add_hp
					end
					if 0 < pet_tianfu_add_inpet_hp then
						fighter_add_inpet_hp = fighter_add_inpet_hp + pet_tianfu_add_inpet_hp
					end
					if 0 < pet_tianfu_add_outpet_hp then
						fighter_add_outpet_hp = fighter_add_outpet_hp + pet_tianfu_add_outpet_hp
					end

					------ 进行加血
					if (0 < fighter_add_hp) or (0 < fighter_add_inpet_hp) or (0 < fighter_add_outpet_hp) then
						-- 替攻击者加血
						self:addHp(fighter, fighter_add_hp, fighter_add_inpet_hp, fighter_add_outpet_hp)
					end
					-------------- 替攻击者加血 end ---------------

					if 0 == outside_known_lost_hp then
						-- 战斗末 : 加buffer/加锁定时间等等
						self:extraEffectAfterAttack(aoiScene, fighter, now_targeter, skill)
					end

					-- 神兵技能 : 沉默
					self:shengBingChenMo(fighter, now_targeter, sb_chenmo_fast_obj_rate)
				end
			end -- end if now_targeter then
		end -- end for i = 1, targeter_num do
		------------------------------------ 结束扣血计算 end ---------------------------------------

		if 0 == outside_known_lost_hp then
			if is_need_move then
				-- 攻击者需要瞬移的位置(攻击者移动)
				-- isLikeCharacter才走这个流程，怪物不走这个流程
				if (0 < skillBase.self_move_dist) and self:isLikeCharacter(fighter) then
					-- 玩家慢慢移到目标地方
					self:moveToPos(fighter, arr_pos.fighter_new_x, arr_pos.fighter_new_y)
					-- print("the fighter new pos is", fighter.x, fighter.y)
				end

				-- 针对怪物的冲刺
				-- (怪物的冲刺，服务端其实还是用瞬移的方式实现的)
				if self:isChongCiSkill(skillBase) and self:isMonster(fighter) then
					-- 怪物瞬移到目标地方
					self:moveToPos(fighter, arr_pos.fighter_new_x, arr_pos.fighter_new_y)
				end

				-- 被攻击者需要移动位置
				if 0 < skillBase.target_move_dist and self:isLikeCharacter(fighter) then
					-- 被攻击者瞬移到目标地方
					self:moveToPos(targeter, arr_pos.targeter_new_x, arr_pos.targeter_new_y)
					-- print("the targeter new pos is", targeter.x, targeter.y)
				end
			end

			-- 单独针对目标的buffer处理
			local arr_targeter_buff = skillDetail.only_target_buffers or nil
			self:addBuffer(aoiScene, targeter, skill, arr_targeter_buff)
		end

		-- 把帮忙抵扣血的对象补到被攻击者列表里
		self:addHelperToTargeter(arr_targeter)

		-- 神兵技能沉默广播给客户端
		self:BcShengBingChenMo(aoiScene, fighter)

		return true, 0, arr_targeter
	end


	-- 扣血
	-- object : 扣血的对象
	-- is_can_die : true/false，是否可以死亡，不能死亡的会留剩下1点血
	-- del_hp : 要扣的血(填正数)
	-- del_hp_perc : 要扣的血的百分比(这里要注意，是扣当前有效的最外层的百分比)，这里填写小数，例如扣20%，则填写0.2
	function FightService:delHp(object, is_can_die, del_hp, del_hp_perc)
		-- 取出要扣的血条信息
		local hp_index, hp_key, max_hp_key = self:getHpInfo(object)

		if 0 < del_hp_perc then
			del_hp = del_hp + ceil(object[max_hp_key] * del_hp_perc)
		end

		-- 幻兽天赋 : 替身傀儡，具有能帮助主人抵消扣血的能力
		if 0 < del_hp then
			del_hp = self:helperDelHp(object, del_hp)
		end

		-- 扣血
		if (not object[hp_key]) then
			-- 查错用的
			local error_msg = 'FightService:delHp del object hp error; aoi_type: ' .. (object.aoi_type or 'unknow') .. 
																						';object.hp: ' .. (object.hp or 'unknow') .. 
																							';object.hp2: ' .. (object.hp2 or 'unknow') .. 
																								';object.hp3: ' .. (object.hp3 or 'unknow')
			printf(error_msg)
		end
		local new_hp = object[hp_key] - del_hp
		if not is_can_die then
			-- 不允许死亡
			if 1 > new_hp then
				new_hp = 1
			end
		end
		object[hp_key] = new_hp

		-- 血条的索引，血量的变化，最新的剩余血
		return hp_index, del_hp, new_hp
	end


	-- 加血
	-- object : 要加血的对象
	-- add_hp : 加对象当前最外层的血
	-- add_inpet_hp : 指定加内层幻兽血
	-- add_outpet_hp : 指定加外层幻兽血
	function FightService:addHp(object, add_hp, add_inpet_hp, add_outpet_hp)
		-- 先替指定位置的加上血
		if self:isLikeCharacter(object) then
			-- 指定外层幻兽加血
			if (0 < add_outpet_hp) and (0 < object.max_hp3) then
				object.hp3 = object.hp3 + add_outpet_hp
				if object.hp3 > object.max_hp3 then
					object.hp3 = object.max_hp3
				end
				-- 记录日志
				self:logFighterAddHp(object, CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_3, add_outpet_hp, object.hp3)
			end
			-- 指定内层幻兽加血
			if (0 < add_inpet_hp) and (0 < object.max_hp2) then
				object.hp2 = object.hp2 + add_inpet_hp
				if object.hp2 > object.max_hp2 then
					object.hp2 = object.max_hp2
				end
				-- 记录日志
				self:logFighterAddHp(object, CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_2, add_inpet_hp, object.hp2)
			end
		end

		if 0 < add_hp then
			-- 再自由判断在合适的位置加血
			local hp_index, hp_key, max_hp_key = self:getHpInfo(object)
			local object_hp = object[hp_key]
			local object_max_hp = object[max_hp_key]

			object_hp = object_hp + add_hp
			if object_hp > object_max_hp then
				object_hp = object_max_hp
			end
			-- 加上血
			object[hp_key] = object_hp

			-- 记录日志
			self:logFighterAddHp(object, hp_index, add_hp, object_hp)
		end
	end


	-- 记录攻击者血液变化(只能用于攻击者加血的记录)
	function FightService:logFighterAddHp(fighter, update_hp_index, update_hp, new_hp)
		local fighter_tmps_fight_info = fighter.tmps.fight_info
		
		local arr_per_hp = {update_hp_index, update_hp, new_hp}
		tableInsert(fighter_tmps_fight_info.arr_fighter_add_hp, arr_per_hp)
	end


	-- 记录被攻击者血液变化
	function FightService:logTargeterDelHp(targeter, update_hp_index, update_hp, new_hp)
		local targeter_tmps_fight_info = targeter.tmps.fight_info

		local arr_per_hp = {update_hp_index, update_hp, new_hp}
		tableInsert(targeter_tmps_fight_info.arr_targeter_del_hp, arr_per_hp)
	end


	-- 记录帮其他人抵扣血
	function FightService:logTargeterHelpDelHp(targeter, update_hp_index, update_hp, new_hp)
		local targeter_tmps_fight_info = targeter.tmps.fight_info

		local arr_per_hp = {update_hp_index, update_hp, new_hp}
		tableInsert(targeter_tmps_fight_info.arr_targeter_help_del_hp, arr_per_hp)
	end


	-- 记录被攻击者对攻击者的反击
	function FightService:logTargeterDelFighterHp(targeter, fighter_update_hp_index, fighter_update_hp, fighter_new_hp)
		local targeter_tmps_fight_info = targeter.tmps.fight_info

		local arr_per_hp = {fighter_update_hp_index, fighter_update_hp, fighter_new_hp}
		tableInsert(targeter_tmps_fight_info.arr_targeter_del_fighter_hp, arr_per_hp)
	end
end


do
	-- 替攻击者添加基本buffer
	function FightService:addBufferForFighter(aoiScene, fighter, skill, is_send)
		local skillDetail = skill.skill_detail
		local arr_buffers = skillDetail.self_buffers
		local arr_buffer_id = self:addBuffer(aoiScene, fighter, skill, arr_buffers)
		
		if is_send then
			-- 返回给自己buff列表(小蒋提供接口)
			BufferService:sendBuffers(aoiScene, fighter, arr_buffer_id)
		end

		return arr_buffer_id
	end


	-- 每次攻击后额外的处理(加buffer/加锁定等)
	local SKILL_ID_FOR_KONGQICHUANGRAN = SkillDefs.SKILL_ID_FOR_KONGQICHUANGRAN -- 空气传染(丧尸危机)

	function FightService:extraEffectAfterAttack(aoiScene, fighter, targeter, skill)
		-- 被攻击者是否要被锁定
		local is_fighter = false
		self:updateSkillLock(is_fighter, targeter, skill)

		-- 替被攻击者加上buff
		local is_need_add_targter_buffer = true
		local skill_id = skill.skill_base.id
		local is_allow_dead_add_buffer = false -- 是否允许死亡的时候也加上buffer，丧尸危机里有这种需求
		
		if SKILL_ID_FOR_KONGQICHUANGRAN == skill_id then
			-- 这部分其实是取消了的
			-- 丧尸危机里面的空气传播，需要判断攻击者是否在感染状态，在感染状态才会加buffer
			if not ShengcunService:isInfected(fighter) then
				is_need_add_targter_buffer = false
			else
				is_allow_dead_add_buffer = true
			end
		end

		-- 玩家在感染状态下，普通攻击会有15%几率造成敌人感染
		local shengcun_skill_add_target_buffers
		if SceneDefs:isInShengcun(aoiScene) and self:isCharacter(fighter) then
			if not ShengcunService:isInfected(fighter) then
				is_need_add_targter_buffer = false
			else
				-- 85%的概率不会加buffer，也就是15%的会加buffer
				local add_buffer_perc = 85
				if self:isBufferHit(add_buffer_perc) then
					is_need_add_targter_buffer = false
				else
					-- 感染
					shengcun_skill_add_target_buffers = {{buffer_id = 13006111, prob = 100}}
				end
				
				is_allow_dead_add_buffer = true
			end
		end
		
		if is_need_add_targter_buffer then
			local arr_targeter_buff = skill.skill_detail.target_buffers or nil
			if shengcun_skill_add_target_buffers then
				arr_targeter_buff = shengcun_skill_add_target_buffers
			end
			self:addBuffer(aoiScene, targeter, skill, arr_targeter_buff, is_allow_dead_add_buffer)
		end
	end


	-- 替某个对象加上buff
	-- return : 成功添加的buffer_id数组
	local SKILL_ID_FOR_MINGGUOWUNV = SkillDefs.SKILL_ID_FOR_MINGGUOWUNV -- 法师，冥国圣女
	local SKILL_ID_FOR_ZHANSHICHONGFENG = SkillDefs.SKILL_ID_FOR_ZHANSHICHONGFENG -- 战士，冲锋

	function FightService:addBuffer(aoiScene, object, skill, arr_buffers, is_allow_dead_add_buffer)
		local arr_add_ok_buffer_id = {} -- 被成功添加的buffer_id数组，用于后面广播更新
		local is_allow_dead_add_buffer = is_allow_dead_add_buffer or false
		if arr_buffers and object then
			local keep_on = true
			if not is_allow_dead_add_buffer then
				if self:isDead(object) then -- 对象不能死亡
					keep_on = false
				end
			end
			if object and keep_on then
				-- local
				local is_add_buffer = true
				local is_mabi_refuse = false	-- 是否麻痹免疫
				local is_yunxuan_refuse = false -- 是否晕眩免疫
					
				-- 一些特殊技能需要加免疫判断
				local skill_id = skill.skill_base.id
				local time_now = Time.time_now
				if self:isLikeCharacter(object) then
					if (SKILL_ID_FOR_MINGGUOWUNV == skill_id) then
						local refuse_mabi_expire = object.tmps.refuse_mabi_expire or 0
						if refuse_mabi_expire > time_now then
							-- 需要免疫麻痹
							is_add_buffer = false
							object.tmps.fight_info.is_refuse_mabi = 1
						else
							is_mabi_refuse = true
						end
					elseif (SKILL_ID_FOR_ZHANSHICHONGFENG == skill_id) then
						local refuse_yunxuan_expire = object.tmps.refuse_yunxuan_expire or 0
						if refuse_yunxuan_expire > time_now then
							-- 需要免疫晕眩
							is_add_buffer = false
							object.tmps.fight_info.is_refuse_yuanxuan = 1
						else
							is_yunxuan_refuse = true
						end
					end
				elseif self:isMonster(object) then
					-- 怪物
					if (SKILL_ID_FOR_MINGGUOWUNV == skill_id) or (SKILL_ID_FOR_ZHANSHICHONGFENG == skill_id) then
						-- 怪物有免疫麻痹和伤害的属性
						if 1 == object.monster_base.is_no_yun_mabi then
							is_add_buffer = false
						end
					end
				end

				if is_add_buffer then
					local prof, now_buffer_id, now_bufferBase
					local is_add_buffer_sucess, is_need_bc
					local is_need_send = false -- 是否添加buff成功，是否需要广播
					for _, now_buffer in pairs(arr_buffers) do
						prof = now_buffer.prob or 0
						now_buffer_id = now_buffer.buffer_id or 0

						-- buffer是否命中
						if self:isBufferHit(prof) then
							-- 替对象加上buff(小蒋提供接口)
							now_bufferBase = BufferBaseService:getBufferBaseById(now_buffer_id)
							is_add_buffer_sucess, is_need_bc = BufferService:addTmpBuffer(object, now_bufferBase, nil)
							if is_add_buffer_sucess then
								-- print("add buffer ok", now_buffer_id, object.nick)
								tableInsert(arr_add_ok_buffer_id, now_buffer_id)

								if 1 == is_need_bc then
									is_need_send = true -- 需要发送给客户端
								end

								-- 加上免疫cd
								if is_mabi_refuse then -- 麻痹免疫
									object.tmps.refuse_mabi_expire = Time:getDelayMsTime(8000)
								end

								if is_yunxuan_refuse then -- 晕眩免疫
									object.tmps.refuse_yunxuan_expire = Time:getDelayMsTime(8000)
								end
							end
						end
					end

					-- 广播buff
					if is_need_send then
						-- 广播对象的buff(小蒋提供接口)
						BufferService:bcBuffers(aoiScene, object)
					end
				end
			end
		end

		return arr_add_ok_buffer_id
	end
end


do
	-- 获取施法目标对象集合
	function FightService:getTargets(aoiScene, fighter, targeter, arr_pos, skill)
		local skillBase = skill.skill_base
		local skillDetail = skill.skill_detail
		local skill_effect_sort_id = skillBase.effect_sort_id

		-- 攻击类的技能(肯定只会打敌人)
		if SKILL_EFFECT_SORT_ID_NORMAL == skill_effect_sort_id then

			local skill_ch_num = skillBase.ch_num -- 群攻/单攻

			local arr_targeter = {}
			local targeter_num = 0

			-- 本次战斗的类型，战斗类型需要攻击的对象类型
			local dest_type = self:getFightDestTypes(aoiScene, fighter)

			-- 只是攻击一个目标而已
			if 1 == skill_ch_num then
				-- 单攻
				targeter_num = 1
				arr_targeter[1] = targeter

				-- 某些单攻有溅射的效果
				local sputter = skillDetail.sputter
				if sputter then
					local sputter_harm_radius = sputter.radius or 0	-- 半径
					local sputter_harm_num = sputter.harm_num or 0  -- 人数
					local sputter_harm_radix = sputter.harm_radix or 0 -- 伤害系数

					if targeter then
						local arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(fighter.aoi_obj, targeter.x, targeter.y, sputter_harm_radius, dest_type)
						-- 过滤掉不符合条件的对象
						local arr_sputter_targeter, sputter_targeter_num = self:filterTargeter(aoiScene, fighter, arr_aoiObj, aoiObj_num)
						if 1 < sputter_targeter_num then
							local harm_num = 0
							for i = 1, sputter_targeter_num do
								local now_targeter = arr_sputter_targeter[i]
								if now_targeter.aoi_id ~= targeter.aoi_id then
									targeter_num = targeter_num + 1
									now_targeter.tmps.targeter_fight_info.sputter_harm_radix = sputter_harm_radix -- 溅射的伤害系数
									arr_targeter[targeter_num] = now_targeter

									harm_num = harm_num + 1
									if harm_num >= sputter_harm_num then
										break
									end
								end
							end
						end -- if 1 < sputter_targeter_num then
					else
						print("有错误，该技能有溅射效果，但没有攻击目标", skillBase.title, skillBase.id)
					end
				end -- end 某些单攻有溅射的效果
			else
				-- 群攻类技能
				local skill_area_type = skillBase.area_type -- 技能攻击范围(圆形/矩形...)
				local area_radius = skillBase.area_radius	-- 技能范围参数 : 圆的半径
				local area_width = skillBase.area_width		-- 技能范围参数 : 矩形的宽
				local area_length = skillBase.area_length	-- 技能范围参数 : 矩形的长(服务端暂时用不上这个参数)(服务端怪物矩形攻击的时候会用上，在其他地方使用)

				local fighter_aoiObj = fighter.aoi_obj

				-- 群攻 全转化为无目标的群攻
				if targeter then
					arr_pos.target_x = targeter.x
					arr_pos.target_y = targeter.y
				end

				-- 技能选取范围
				local arr_aoiObj, aoiObj_num = nil, 0

				-- 有的技能必须把目标者保留在被攻击列表里
				-- (例如 : 战士冲撞，如果攻击者和被攻击者在同一个位置点上，获取矩形接口那里会获取不出来目标；或者客户端和服务端位置不一致，也导致取不出来)
				local must_has_aoi_id = 0
				local is_must_has_targeter = skillDetail.only_target_buffers or nil
				if is_must_has_targeter then
					must_has_aoi_id = targeter and targeter.aoi_id or 0
				end

				-- 自己为圆心
				if skill_area_type == AREA_TYPE_ID_SELF_CIRCLE then
					-- 攻击者的位置
					arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(fighter_aoiObj, arr_pos.fighter_attack_x, arr_pos.fighter_attack_y, area_radius, dest_type)

				-- 目标为圆心
				elseif skill_area_type == AREA_TYPE_ID_DEST_CIRCLE then
					arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(fighter_aoiObj, arr_pos.target_x, arr_pos.target_y, area_radius, dest_type)

				-- 前方矩形/冲刺矩形
				elseif skill_area_type == AREA_TYPE_ID_FRONT_RECT or skill_area_type == AREA_TYPE_ID_SPRINT_RECT then
					arr_aoiObj, aoiObj_num = aoiScene:getObjsForDestRect(fighter_aoiObj, arr_pos.target_x, arr_pos.target_y, area_width, dest_type, must_has_aoi_id)

				-- 冲刺 路上矩形 加 目标点圆形
				elseif skill_area_type == AREA_TYPE_ID_SPRINT_RECT_CIRCLE then
					arr_aoiObj, aoiObj_num = aoiScene:getObjsForDestRect(fighter_aoiObj, arr_pos.target_x, arr_pos.target_y, area_width, dest_type, must_has_aoi_id)

				else
					error("未知的攻击范围类型" .. skill_area_type)
				end
				
				-- 过滤掉不符合条件的对象
				-- 需要计算伤害的群体，需要添加buffer的群体
				arr_targeter, targeter_num = self:filterTargeter(aoiScene, fighter, arr_aoiObj, aoiObj_num, skill_ch_num)
			end

			return arr_targeter, targeter_num

		else
			-- table.dump(skill, 2)
			error("【找张楠】录入技能表数据错误，该技能类型不能进入这里的逻辑, 技能id：" .. skillBase.id .. "|技能名字：" .. skillBase.title .. "|技能类型" .. skill_effect_sort_id)
		end
	end


	-- 在范围内随机获取一个可以攻击的目标(召唤物(法师的炎龙)/怪物等，用来随机选找一个对手)
	-- aoiScene : 场景实例
	-- fighter : 攻击者
	-- distance : 距离范围
	-- targeter_aoi_id : 要找的目标(如果不传就随机找一个)
	-- return targeter / nil
	function FightService:findOneAttackTargeter(aoiScene, fighter, distance, targeter_aoi_id)
		if 0 < targeter_aoi_id then
			local targeter = GameObjectService:getGameObjectByAoiId(aoiScene, targeter_aoi_id)
			if targeter then
				if self:isCanAttack(fighter, targeter) then -- 可以被攻击
					-- 判断距离
					if Formula:isNearbyDistance(fighter.x, fighter.y, targeter.x, targeter.y, distance) then
						return targeter
					end
				end
			end
		end

		-- 随机寻找一个
		local dest_type = self:getFightDestTypes(aoiScene, fighter)
		local arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(fighter.aoi_obj, fighter.x, fighter.y, distance, dest_type)
		if 0 < aoiObj_num then
			-- 筛选符合条件的对象(可以被攻击等)
			local arr_targeter, targeter_num = self:filterTargeter(aoiScene, fighter, arr_aoiObj, aoiObj_num)
			if 0 < targeter_num then
				return arr_targeter[1]
			end
		end

		return nil
	end


	-- 过滤掉不能攻击的对象(仅适用于攻击的过滤)
	function FightService:filterTargeter(aoiScene, fighter, arr_aoiObj, aoiObj_num, limit_num, is_need_same_zhenying)
		-- 需要计算伤害的群体
		local arr_targeter_harm = {}
		local targeter_harm_num = 0
		local now_aoi_id
		local limit_num = limit_num or 999
		local is_need_same_zhenying = is_need_same_zhenying or 1 -- 是否需要同阵营判断(丧尸危机里有一个感染陷阱，可以感染自己人)
		local getGameObjectByAoiId = GameObjectService.getGameObjectByAoiId
		
		if 0 < aoiObj_num then
			for _, now_aoiObj in pairs (arr_aoiObj) do
				now_aoi_id = now_aoiObj.obj_id
				local now_targter = getGameObjectByAoiId(GameObjectService, aoiScene, now_aoi_id)
				if now_targter and self:isCanAttack(fighter, now_targter, is_need_same_zhenying) then -- 可以被攻击
					tableInsert(arr_targeter_harm, now_targter)
					targeter_harm_num = targeter_harm_num + 1
					if targeter_harm_num >= limit_num then
						break
					end
				end
			end
		end

		return arr_targeter_harm, targeter_harm_num
	end
end


do
	-- 检查对象是不是角色
	function FightService:isCharacter(object)
		return object.aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER
	end

	-- 检查对象是不是幻兽(出战幻兽，合体幻兽不能在这里判断)
	function FightService:isPet(object)
		return object.aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_PET
	end

	-- 检查对象是不是合体幻兽
	function FightService:isHeTiPet(object)
		-- 小蒋提供接口
		if ChPetService:isHetiPetByChPet(object) then
			return true
		else
			return false
		end
	end

	-- 检查对象是不是陷阱
	function FightService:isTrap(object)
		return object.aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_TRAP
	end

	-- 检查对象是不是怪物
	function FightService:isMonster(object)
		return object.aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_MONSTER
	end

	-- 检查对象是不是召唤兽
	function FightService:isBeast(object)
		return object.aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_BEAST
	end

	-- 检查对象是不是守护NPC
	function FightService:isGuardNpc(object)
		return object.aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_GUARD_NPC
	end

	-- 检查对象是不是机器人
	function FightService:isRobot(object)
		return object.aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT
	end

	-- 检查对象是不是类角色的(普通角色+机器人)
	function FightService:isLikeCharacter(object)
		local object_aoi_type = object.aoi_type
		local is_like_character = (object_aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER) or (object_aoi_type == AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT)
		return is_like_character
	end

	-- 判断角色是不是召唤师
	function FightService:isZhaoHuanShi(character)
		return character.prof == CharacterDefs_PROF_ID_FOR_ZHAOHUANSHI
	end
end


do
	-- 判断一个对象是否死亡了(角色/侠客/怪物等)
	-- object : 对象
	-- return true / false
	function FightService:isDead(object)
		local object_hp = object.hp or 0 -- 只检查最底层血条就可以判断是否死亡

		if 0 >= object_hp then
			return true
		else
			return false
		end
	end
end


do
	-- 是否处于引导技能的触发状态中
	function FightService:inFightState(fighter, ahead_sec)
		local ahead_sec = ahead_sec or 0
		local fight_expire = fighter.tmps.fight_expire
		return (fight_expire and (fight_expire - ahead_sec) > Time.time_now) and true or false
	end
end


do
	-- 取消技能触发状态(战士旋风斩期间被连击/切换场景等，会取消掉旋风斩)
	-- 取消怪物ai的播放状态
	function FightService:cancleFightState(object, is_no_stop)
		local objectTmps = object.tmps
		objectTmps.fight_expire = 0

		-- 怪物技能ai取消
		if self:isMonster(object) then
			-- 女神的不停止移动
			if MonsterService:isNvSheng(object) then
				is_no_stop = true
			else
				objectTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_AI_PLAYING
				objectTmps.ai_playing_expire = 0 -- ai播放过期
			end
		end

		-- 广播停止移动(小蒋提供接口)
		if not is_no_stop then
			MotionService:stop(object, true)
		end
	end
end


do
	-- 是否在技能锁定中
	function FightService:isSkillLocked(fighter)
		local lock_expire = fighter.tmps.lock_expire
		
		return (lock_expire and lock_expire > Time.time_now) and true or false
	end


	-- 对象是否可以被连击
	function FightService:isCanLocked(object)
		local is_can_lock = true
		if self:isMonster(object) then
			-- 某些怪不会被锁定
			if 0 == object.monster_base.is_can_lock then
				is_can_lock = false
			end
		end
		return is_can_lock
	end


	-- 是否是连击技能
	function FightService:isLianJiSkill(skillBase)
		return skillBase.lianji_num > 1 -- 是不是连击
	end


	-- 是否是逃脱技能
	local SkillDefs_EFFECT_SORT_ID_DODGE = SkillDefs.EFFECT_SORT_ID_DODGE
	function FightService:isDodgeSkill(skillBase)
		return skillBase.effect_sort_id == SkillDefs_EFFECT_SORT_ID_DODGE
	end


	-- 是否是冲刺技能(采用和客户端一样的判断)
	function FightService:isChongCiSkill(skillBase)
		return skillBase.self_slow_move_dist > 0 -- 是不是冲刺
	end


	-- 是否是矩形群攻技能
	function FightService:isRectAreaTypeSkill(skillBase)
		local skill_area_type = skillBase.area_type

		-- (冲刺矩形/前方矩形)
		if (skill_area_type == AREA_TYPE_ID_FRONT_RECT) or (skill_area_type == AREA_TYPE_ID_SPRINT_RECT) then
			return true
		else
			return false
		end
	end
end


do
	-- 是否在同一个阵营
	function FightService:isSameZhenYing(fighter, targeter)
		local fighter_zhenying = fighter.tmps.zhenying or 9999
		local targeter_zhenying = targeter.tmps.zhenying or 9998
		if fighter_zhenying == targeter_zhenying then
			return true
		end
		
		return false
	end
end


do
	function FightService:getNowTrueTargeter(targeter)
		local true_targeter = targeter

		if self:isLikeCharacter(targeter) then
			if (0 < targeter.max_hp3) and (0 < targeter.hp3) then
				-- 获取外层幻兽属性(小蒋提供接口)
				true_targeter = ChPetService:getHeTiChPetByOrderBy(targeter, PetDefs_HETI_POS_OUT)
			elseif (0 < targeter.max_hp2) and (0 < targeter.hp2) then
				-- 获取内层幻兽属性(小蒋提供接口)
				true_targeter = ChPetService:getHeTiChPetByOrderBy(targeter, PetDefs_HETI_POS_IN)
			end
		end

		return true_targeter
	end


	-- 获取本次攻击真实的攻击者
	function FightService:getNowTrueFighter(fighter, fighter_index)
		if CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_3 == fighter_index then
			-- 外层幻兽
			if (0 < fighter.max_hp3) and (0 < fighter.hp3) then
				return ChPetService:getHeTiChPetByOrderBy(fighter, PetDefs_HETI_POS_OUT)
			end
		elseif CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_2 == fighter_index then
			-- 内层幻兽
			if (0 < fighter.max_hp2) and (0 < fighter.hp2) then
				return ChPetService:getHeTiChPetByOrderBy(fighter, PetDefs_HETI_POS_IN)
			end
		else
			return fighter
		end

		return nil
	end


	-- 获取最外层的对象
	function FightService:getOutestFighter(object)
		if self:isLikeCharacter(object) then
			if (0 < object.max_hp3) and (0 < object.hp3) then
				-- 外层幻兽
				return ChPetService:getHeTiChPetByOrderBy(object, PetDefs_HETI_POS_OUT)

			elseif (0 < object.max_hp2) and (0 < object.hp2) then
				-- 内层幻兽
				return ChPetService:getHeTiChPetByOrderBy(object, PetDefs_HETI_POS_IN)
			end
		end

		return object
	end


	-- 获取我的buffer列表
	-- object : 角色/怪物/幻兽/合体幻兽等等...
	function FightService:getMyBuffers(object)
		local bufferObject = object

		if self:isHeTiPet(object) then -- 合体幻兽的buffer体是取父亲的
			bufferObject = ChPetService:getParentGameObj(object)
		end

		-- 获取身上的buffer列表
		local arr_buffer = BufferService:getEffectValues(bufferObject)
		if arr_buffer and 0 < sizeTable(arr_buffer) then
			return arr_buffer
		end

		return nil
	end


	-- 获取当前有效的血条
	local HP_KEY = 'hp'
	local MAX_HP_KEY = 'max_hp'
	local HP2_KEY = 'hp2'
	local MAX_HP2_KEY = 'max_hp2'
	local HP3_KEY = 'hp3'
	local MAX_HP3_KEY = 'max_hp3'

	function FightService:getHpInfo(object)
		if self:isLikeCharacter(object) then
			-- 优先扣外层幻兽血条
			if (0 < object.max_hp3) and (0 < object.hp3) then
				-- 获取外层幻兽属性(小蒋提供接口)
				return CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_3, HP3_KEY, MAX_HP3_KEY

			elseif (0 < object.max_hp2) and (0 < object.hp2) then
				-- 获取内层幻兽属性(小蒋提供接口)
				return CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_2, HP2_KEY, MAX_HP2_KEY
			end
		end

		-- 最后扣底层角色血条
		return CharacterDefs_CHARACTER_HP_INDEX_MAX_HP, HP_KEY, MAX_HP_KEY
	end
end


do
	-- 检查攻击者
	function FightService:checkFighter(fighter)
		-- 已死亡
		if self:isDead(fighter) then
			return false, errorCodes.FIGHT_SELF_DAED
		end
		
		-- 在眩晕中
		if BufferService:isInStatus(fighter, EffectType.giddiness) then
			return false, errorCodes.FIGHT_CANNOT_GIDDINESS
		end

		-- 是否处于引导技能状态中
		if self:inFightState(fighter, 100) then
			return false, errorCodes.FIGHT_CANNOT_IN_GUIDE_FIGHT
		end

		return true
	end


	-- 检查技能是否过了冷却时间
	function FightService:isSkillCdOk(fighter, skill_id, ahead_mssec)
		-- local
		local ahead_mssec = ahead_mssec or 0 -- 容错的毫秒数
		local fighter_tmps = fighter.tmps
		local play_time = (Time.time_now + ahead_mssec)

		if play_time >= fighter_tmps.play_skill_expire then -- 首先要到了允许触发
			local skill_self_expire = fighter_tmps.self_skill_expires[skill_id] or 0 -- 再看技能本身cd是否已经到了
			if play_time >= skill_self_expire then
				return true
			end
		end

		return false
	end


	-- 更新技能CD时间(注意:总过期时间不能放在这里)
	function FightService:updateSkillCd(fighter, skillBase)
		-- local
		local play_cool_msec = skillBase.play_cool_msec or 500   -- 下个技能的使用cd
		local self_cool_msec = skillBase.self_cool_msec or 10000 -- 技能本身的cd时间

		local fighter_tmps = fighter.tmps
		fighter_tmps.play_skill_expire = Time.time_now + play_cool_msec
		fighter_tmps.self_skill_expires[skillBase.id] = Time.time_now + self_cool_msec
	end


	-- 角色死亡会清除技能CD
	function FightService:cleanSkillCd(character)
		local character_tmps = character.tmps
		character_tmps.play_skill_expire = 0
		character_tmps.self_skill_expires = {}
	end


	-- 更新某个对象被技能锁的时间
	-- is_fighter : 是否是个攻击者(如果是被攻击者的话，需要被取消攻击状态(旋风斩))
	-- object : 对象
	-- skill_duration : 锁定时间(毫秒数)
	function FightService:updateSkillLock(is_fighter, object, skill)
		local skillBase = skill.skill_base
		if self:isLianJiSkill(skillBase) then -- 锁定对象，连击
			if self:isCanLocked(object) then
				object.tmps.lock_expire = Time.time_now + skillBase.duration
			end

			-- 取消被攻击者的攻击状态(旋风斩)
			-- 取消怪物的ai状态
			if not is_fighter then -- 被攻击者
				self:cancleFightState(object)
			end
		end
	end


	-- 更新时间点
	-- time_type : 时间的类型(定义在CharacterDefs.lua)
	-- character : 角色对象
	-- delay_ms : 持续的毫秒
	function FightService:updateSkillTime(fighter, skill)
		-- local
		local skillBase = skill.skill_base

		-- 更新下一招时间和技能本身CD时间
		self:updateSkillCd(fighter, skillBase)

		-- 技能时间
		local skill_duration = skillBase.duration or 0
		if 0 < skill_duration then -- 连击+旋风斩等持续性的
			local fighter_tmps = fighter.tmps
			local is_lianji_hit = fighter_tmps.fight_info.is_lianji_hit or 1 -- 是否连击命中

			if 1 == is_lianji_hit then
				-- 技能播放结束时间
				fighter_tmps.fight_expire = Time.time_now + skill_duration

				-- 技能锁定
				local is_fighter = true
				self:updateSkillLock(is_fighter, fighter, skill)

				-- 服务端触发战斗的(例如:战士旋风斩)
				if 1 == skillBase.is_server_fight then
					-- 将攻击者置于服务端引导状态中
					fighter_tmps.in_server_fight = FightDefs.FIGHT_IN_SERVER_GUIDE_SKILL_YES -- 服务端引导

					-- 缓存引导技能信息
					local arr_server_fight_skill = fighter_tmps.arr_server_fight_skill -- 服务端引导的信息
					local skill_interval = skillBase.interval
					arr_server_fight_skill.skill_id = skillBase.id		-- 触发的技能id
					arr_server_fight_skill.interval = skill_interval	-- 触发的技能的间隔
					arr_server_fight_skill.next_play_time = Time.time_now + skill_interval -- 下一次触发的时间

					-- table.dump(fighter_tmps, -1)
				end
			end
		end
	end
end


do
	-- 获取默认的pos
	-- return arr_pos : 位置信息数组
	function FightService:getDefaultPos()
		local arr_pos = {
				target_x = 0,		-- X坐标，无目标的技能，需要指向在哪里，例如放一个火焰在某个位置
				target_y = 0,		-- Y坐标
				fighter_new_x = 0,	-- 本次攻击后攻击者的新位置X坐标
				fighter_new_y = 0,	-- Y坐标
				targeter_new_x = 0, -- 本次攻击后被攻击者的新位置X坐标
				targeter_new_y = 0, -- Y坐标

				-- (陷阱攻击的时候，属性用的是召唤出陷阱的人，但实际攻击位置是陷阱当前所在位置，不能直接用fighter.x, fighter.y来获取)
				fighter_attack_x = 0, -- 攻击者攻击的时候的x坐标
				fighter_attack_y = 0, -- 攻击者攻击的时候的y坐标
			}
		
		return arr_pos
	end
end


do
	-- 获取一个攻击者的技能对象
	-- fighter : 攻击者
	-- skill_id : 技能id
	-- return skill
	function FightService:getFighterSkill(fighter, skill_id)
		local skill

		if self:isLikeCharacter(fighter) then   -- 角色 / 召唤机器人
			skill = ChSkillService:getChDetailSkillInfoById(fighter, skill_id)
		elseif self:isMonster(fighter) or self:isPet(fighter) or self:isTrap(fighter) then -- 怪物/幻兽/陷阱
			skill = SkillBaseService:getDetailSkillInfoById(skill_id)
		elseif self:isBeast(fighter) then	-- 召唤物
			skill = BeastService:getDetailSkillInfoById(fighter, skill_id)
		else
			print("获取技能，未知对象类型")
			-- TODO...
		end

		return skill
	end
end


do
	-- 获取本次可以攻击的aoi类型
	-- aoiScene : 场景实例
	-- fighter : 攻击者
	-- is_only_character : 是否只选择角色
	-- return dest_type 可攻击目标的aoi类型串
	function FightService:getFightDestTypes(aoiScene, fighter, is_only_character)
		-- local
		local dest_type = 0
		local is_only_character = is_only_character or false

		if not is_only_character then
			local is_monster_fighter = false -- 默认不是怪物
			if self:isMonster(fighter) then
				is_monster_fighter = true
			end

			if is_monster_fighter then
				dest_type = externalCombineBit(AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER, AoiObjectType_AOI_OBJECT_TYPE_ID_PET, AoiObjectType_AOI_OBJECT_TYPE_ID_BEAST, AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT)
			else
				dest_type = externalCombineBit(AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER, AoiObjectType_AOI_OBJECT_TYPE_ID_PET, AoiObjectType_AOI_OBJECT_TYPE_ID_BEAST, AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT, AoiObjectType_AOI_OBJECT_TYPE_ID_MONSTER)
			end
		else
			-- 只选择角色的
			dest_type = externalCombineBit(AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER)
		end
		
		return dest_type
	end
end


do
	-- 检查技能
	-- fighter : 施法者
	-- skill : 技能对象
	-- targeter_aoi_id : 被攻击者的aoi_id
	-- return boolean, error_id
	function FightService:checkSkill(fighter, skill, targeter_aoi_id)
		if not skill then -- 攻击者没有学会这个技能
			return false, errorCodes.FIGHT_SKILL_NOT_EXIST
		end

		local skillBase = skill.skill_base
		local is_lianji = self:isLianJiSkill(skillBase) -- 是不是连击

		-- 检查是不是主动技能
		if skillBase.parent_sort_id ~= SkillDefs.PARENT_SORT_ID_INITIATIVE then
			return false, errorCodes.FIGHT_ERROR_SKILL_ERR
		end

		-- 连击技能必须有攻击目标
		if is_lianji and targeter_aoi_id <= 0 then
			return false, errorCodes.FIGHT_ERROR_HAS_NOT_TARGET
		end

		-- 连击只能攻击一个人
		local ch_num = skillBase.ch_num
		if is_lianji and ch_num ~= 1 then
			return false, errorCodes.FIGHT_ERROR_SKILL_ERR
		end

		-- 检查CD时间是否已经到了
		local ahead_mssec = 100
		if not self:isSkillCdOk(fighter, skillBase.id, ahead_mssec) then
			return false, errorCodes.FIGHT_ERROR_SKLL_COOLING
		end

		-- 检查是否在无敌逃跑状态中，不能攻击(小蒋提供接口)
		if BufferService:isInStatus(fighter, EffectType.wudi_taopao) then
			return false, errorCodes.FIGHT_FIGHTER_IS_IN_WUDI_TAOPAO
		end
		
		return true
	end


	-- 检查是否是安全场景
	function FightService:checkScene(aoiScene)
		local safe_mode = aoiScene.scene_base.safe_mode
		
		if safe_mode == SceneDefs.SCENE_SAFE_MODE_PEACE then
			return false, errorCodes.FIGHT_ERROR_IN_SAFE_SCENE
		end
		
		return true
	end


	-- 检查场景事件
	function FightService:checkSceneEvent(aoiScene, fighter)
		local keep_on = true
		local error_id = 0

		local character
		if self:isCharacter(fighter) then
			character = fighter
		elseif self:isPet(fighter) then
			character = ChPetService:getParentGameObj(fighter)
		elseif self:isBeast(fighter) then
			character = BeastService:getMyParent(aoiScene, fighter)
		else
			-- 未知的
			character = fighter
		end

		-- 检查场景事件(小蒋)
		keep_on, error_id = SceneEventService:checkFight(aoiScene, character)
		
		return keep_on, error_id
	end
end


do
	-- 检查某个对象是否可以被攻击(死亡，保护，是否同一个阵营等.....)
	-- return 是否可以攻击，是否等待跟随，失败原因
	function FightService:isCanAttack(fighter, targeter, skill, is_need_same_zhenying)
		-- 是否需要同阵营判断
		local is_need_same_zhenying = is_need_same_zhenying or 1

		-- 死亡
		if self:isDead(targeter) then
			return false, false, '目标已死亡'
		end

		-- 保护状态
		if CharacterService:isProtected(targeter) then
			return false, false, '目标保护中'
		end

		-- 无敌逃跑状态
		if BufferService:isInStatus(targeter, EffectType.wudi_taopao) then
			return false, false, '无敌逃跑保护中'
		end

		-- 是不是同一个阵营的
		if 1 == is_need_same_zhenying then
			-- 同一个阵营，且攻击者不是屠杀模式
			if self:isSameZhenYing(fighter, targeter) and not SafeModeService:isEnAttackByFreePK(fighter, targeter) then
				return false, false, '攻击者和目标在同一个阵营'
			end
		end

		-- 如果是怪物，检查是否在回放中
		if self:isMonster(targeter) then
			if MonsterAiService:isHoming(targeter.tmps.now_state) then
				-- error_id = errorCodes.FIGHT_MONSTER_IS_HOMING
				return false, false, '怪物回防中'
			end
		end

		-- 安全模式判断(小蒋提供接口)
		local is_safeMode_ok, error_text = SafeModeService:isCanAttack(fighter, targeter)
		if not is_safeMode_ok then
			return false, false, error_text
		end

		-- 使用逃脱技能，不检查被攻击者是否被锁定中
		-- local is_check_lock = true
		-- if skill then
		--	if self:isDodgeSkill(skill.skill_base) then
		--		is_check_lock = false
		--	end
		-- end

		-- if is_check_lock then -- 暂时取消掉这种判断
			-- 是否在技能锁定状态(连击锁定)
			-- if self:isSkillLocked(targeter) then
			--	return false, true, '目标在技能锁定状态'
			-- end
		-- end

		-- 角色的连击技能不能攻击正在是释放ai的怪物，蓄力状态的就可以
		--if self:isLikeCharacter(fighter) then
		--	if self:isLianJiSkill(skill.skill_base) then
		--		if self:isMonster(targeter) then
		--			local state = MonsterAiService:getNowState(targeter)
		--			if MonsterAiService:isAiPlaying(state) then
		--				print("错误的攻击目标原因 : 怪物AI播放中，不能用锁定技能攻击")
		--				return false, errorCodes.FIGHT_MONSTER_IS_AI_PLAYING
		--			end
		--		end
		--	end
		--end

		return true, false
	end


	-- 是否距离攻击目标够近
	-- fighter : 攻击者
	-- targeter : 被攻击者
	-- skill : 技能对象
	-- dist_error : 误差容错
	-- return boolean
	function FightService:isFightDisOk(fighter, targeter, skill, dist_error)
		-- 被攻击者体积
		local body_size = 0

		if self:isMonster(fighter) then
			body_size = MonsterService:getSize(fighter)
		end

		if self:isMonster(targeter) then
			body_size = MonsterService:getSize(targeter)
		end

		-- (技能距离 + 目标身体半径 + 加多0.5的容错误差)
		local dis = skill.skill_base.distance + body_size + dist_error

		local is_near_enough, sqr_dist = Formula:isNearbyDistance(fighter.x, fighter.y, targeter.x, targeter.y, dis)
		return is_near_enough
	end


	-- 判断buffer是否命中
	-- probas : 概率(1-100的范围)
	-- return true/false
	function FightService:isBufferHit(probas)
		local compare = random(1, 100)
		if probas >= compare then
			return true
		else
			-- return true
			return false
		end
	end
end


do
	-- 初始攻击者战斗相关的临时状态
	-- fighter : 攻击者
	function FightService:initFighterFightTmps(fighter)
		local fighter_tmps_fight_info = fighter.tmps.fight_info

		fighter_tmps_fight_info.total_base_harm = 0 -- 总的基础伤害(攻击者基础伤害 + 攻击者合体幻兽1基础伤害 + 攻击者合体幻兽2基础伤害)
		fighter_tmps_fight_info.total_min_harm = 0  -- 总的最低伤害值
		
		fighter_tmps_fight_info.is_lianji_hit = 1 -- 针对连击技能的标志位(是否命中了)(1 : 命中； 0 : 闪避)

		fighter_tmps_fight_info.arr_fighter_add_hp = {} -- 本次攻击攻击者血的变化情况-- 结构{{hp_index, change_hp, now_hp}, {}, ...}
		fighter_tmps_fight_info.is_fighter_kill_add_hp_perc_or_relive = 0 -- 本次攻击攻击者是否已触发天赋回血(浴血奋战)(0 : 没有；1 : 有)

		fighter_tmps_fight_info.arr_chenmo_aoi_id = {} -- 本次攻击导致的沉默列表

		-- 角色的合体幻兽
		if self:isLikeCharacter(fighter) then
			-- 获取攻击者的所有合体幻兽的详细加成信息(小蒋提供接口)
			local all_heti_pet_effect_value, all_heti_pet_num = ChPetService:getAllHeTiEffectValues(fighter)
			fighter_tmps_fight_info.all_heti_pet_effect_value = all_heti_pet_effect_value -- 合体幻兽的加成属性值(存活着的合体幻兽)
			fighter_tmps_fight_info.all_heti_pet_num = all_heti_pet_num or 0 -- 合体幻兽数量(存活着的合体幻兽)
		else
			fighter_tmps_fight_info.all_heti_pet_effect_value = {}
			fighter_tmps_fight_info.all_heti_pet_num = 0
		end

		-- 幻兽天赋(反戈一击)导致攻击者也可能成为被攻击对象
		-- 结构要增加与被攻击者一致的结构
		self:initTargeterFightTmps(fighter)
	end


	-- 初始被攻击者战斗相关的临时状态
	-- targeter_tmps
	function FightService:initTargeterFightTmps(targeter)
		-- local
		local targeter_tmps_fight_info = targeter.tmps.fight_info
		local do_fight_mark_id_for_targeter = targeter_tmps_fight_info.do_fight_mark_id_for_targeter or 0 -- 攻击标记id
		-- 一次攻击可能存在次被伤害(被群攻，同时又替别人抵挡伤害)
		if do_fight_mark_id_for_targeter ~= g_do_fight_mark_id then
			-- 重置所有参数
			targeter_tmps_fight_info.do_fight_mark_id_for_targeter = g_do_fight_mark_id

			targeter_tmps_fight_info.action_id = 0				-- 命中/闪避/格挡/暴击
			targeter_tmps_fight_info.is_refuse_mabi = 0			-- 麻痹免疫
			targeter_tmps_fight_info.is_refuse_yuanxuan = 0		-- 晕眩免疫
			
			targeter_tmps_fight_info.targeter_is_real_targeter = 0	-- 是否是真的被攻击者(用来区分是真的被攻击者/帮忙抵扣血的而已)
			targeter_tmps_fight_info.targeter_total_del_hp = 0	-- 被攻击者总的被扣血值

			targeter_tmps_fight_info.arr_targeter_del_hp = {} -- 被攻击扣血的变化记录 -- 结构{{hp_index, change_hp, now_hp}, {}, ...}
			targeter_tmps_fight_info.arr_targeter_help_del_hp = {} -- 帮其他人扣血的记录 -- 结构{{hp_index, change_hp, now_hp}, {}, ...}
			targeter_tmps_fight_info.arr_targeter_del_fighter_hp = {} -- 受击者反击攻击者的血液值 -- 结构{{hp_index, change_hp, now_hp}, {}, ...}
		end
	end
end


do
	-- 初始攻击者幻兽天赋
	-- aoiScene : 场景实例
	-- fighter : 攻击者(只能是角色/出战幻兽)
	function FightService:initFighterPetTianFu(aoiScene, fighter)

		-- 丧尸危机不需要处理幻兽天赋
		if SceneDefs:isInShengcun(aoiScene) then
			fighter.tmps.pet_tianfu = {} -- 先清空旧有的
			return
		end

		-- local
		local ownerCharacter

		local is_character = self:isCharacter(fighter)
		local is_pet = self:isPet(fighter)
		if is_character or is_pet then
			if is_character then
				-- 角色
				ownerCharacter = fighter
			else
				-- 出战幻兽
				ownerCharacter = ChPetService:getParentGameObj(fighter)
			end

			-- 获取幻兽天赋
			local fight_pet_tianfu_effects, heti_pet_tianfu_effects = ChPetService:getPetTianfuEffects(ownerCharacter)
			-- table.dump(fight_pet_tianfu_effects, -1)
			-- table.dump(heti_pet_tianfu_effects, -1)

			-- 只有某几种天赋需要在战斗中处理
			fighter.tmps.pet_tianfu = {} -- 先清空旧有的
			local fighter_tmps_pet_tianfu = fighter.tmps.pet_tianfu
			if is_pet then
				-- 出战幻兽取自己的
				
				-- 血族幻兽(血之契约是采用buffer方式处理)
				fighter_tmps_pet_tianfu['critical_hit_rate_perc'] = fight_pet_tianfu_effects['critical_hit_rate_perc']		-- (血性激发)暴击率+x%
				fighter_tmps_pet_tianfu['bj_harm_perc_target'] = fight_pet_tianfu_effects['bj_harm_perc_target']			-- (屠戮成性)暴击伤害增加x%
				fighter_tmps_pet_tianfu['hp_more_harm_perc_target'] = fight_pet_tianfu_effects['hp_more_harm_perc_target']	-- (血统压制)当生命%比目标生命%高，伤害加成x%

				-- 战士幻兽
				fighter_tmps_pet_tianfu['kill_add_hp_perc_or_relive'] = fight_pet_tianfu_effects['kill_add_hp_perc_or_relive'] -- (浴血奋战)出战幻兽 : 击杀敌人后回复生命上限+x%；内层合体幻兽 : 击杀敌人后给外层幻兽复活30%，内层满血

				-- 召唤师幻兽
			else
				-- 角色的只能取合体幻兽的

				-- 血族幻兽(血之契约是采用buffer方式处理)
				fighter_tmps_pet_tianfu['critical_hit_rate_perc'] = heti_pet_tianfu_effects['critical_hit_rate_perc']		-- (血性激发)暴击率+x%
				fighter_tmps_pet_tianfu['bj_harm_perc_target'] = heti_pet_tianfu_effects['bj_harm_perc_target']				-- (屠戮成性)暴击伤害增加x%
				fighter_tmps_pet_tianfu['hp_more_harm_perc_target'] = heti_pet_tianfu_effects['hp_more_harm_perc_target']	-- (血统压制)当生命%比目标生命%高，伤害加成x%

				-- 战士幻兽
				fighter_tmps_pet_tianfu['kill_add_hp_perc_or_relive'] = heti_pet_tianfu_effects['kill_add_hp_perc_or_relive'] -- (浴血奋战)出战幻兽 : 击杀敌人后回复生命上限+x%；内层合体幻兽 : 击杀敌人后给外层幻兽复活30%，内层满血

				-- 召唤师幻兽
			end

			------------------ 光环类的幻兽天赋 start -------------------------
			-- (斗争天性)物理伤害增加y%，法术伤害增加x%，自身有增益buff，物理/法术伤害效果翻n倍
			fighter_tmps_pet_tianfu['harm_target_inc_buff_multi'] = fight_pet_tianfu_effects['harm_target_inc_buff_multi'] or heti_pet_tianfu_effects['harm_target_inc_buff_multi']
			------------------ 光环类的幻兽天赋 end ---------------------------

			-- 调试用
			if false then
				if self:isCharacter(fighter) then
					print("攻击者(角色)-----------------------------------")
					table.dump(fighter.tmps.pet_tianfu, -1)
				else
					print("攻击者(出战幻兽)-----------------------------------")
					table.dump(fighter.tmps.pet_tianfu, -1)
				end
			end
		else
			-- 光环类的幻兽天赋
			-- 召唤物
			local is_beast = self:isBeast(fighter)
			if is_beast then
				ownerCharacter = BeastService:getMyParent(aoiScene, fighter)
			end

			if ownerCharacter then
				local fight_pet_tianfu_effects, heti_pet_tianfu_effects = ChPetService:getPetTianfuEffects(ownerCharacter)
				
				-- 只有某几种天赋需要在战斗中处理
				fighter.tmps.pet_tianfu = {} -- 先清空旧有的
				local fighter_tmps_pet_tianfu = fighter.tmps.pet_tianfu

				------------------ 光环类的幻兽天赋 start -------------------------
				-- (斗争天性)物理伤害增加y%，法术伤害增加x%，自身有增益buff，物理/法术伤害效果翻n倍
				fighter_tmps_pet_tianfu['harm_target_inc_buff_multi'] = fight_pet_tianfu_effects['harm_target_inc_buff_multi'] or heti_pet_tianfu_effects['harm_target_inc_buff_multi']
				------------------ 光环类的幻兽天赋 end ---------------------------

				-- 调试用
				if false then
					print("召唤兽：" .. fighter.beast_base.title .. "-----------------------------------")
					table.dump(fighter.tmps.pet_tianfu, -1)
				end
			end
		end
	end


	-- 初始被攻击者幻兽天赋
	-- targeter : 被攻击者(只能是角色/出战幻兽)
	function FightService:initTargeterPetTianFu(aoiScene, targeter)

		-- 丧尸危机不需要处理幻兽天赋
		if SceneDefs:isInShengcun(aoiScene) then
			targeter.tmps.pet_tianfu = {} -- 先清空旧有的
			return
		end

		local is_character = self:isCharacter(targeter)
		local is_pet = self:isPet(targeter)
		if is_character or is_pet then
			local ownerCharacter
			if is_character then
				-- 角色
				ownerCharacter = targeter
			else
				-- 出战幻兽
				ownerCharacter = ChPetService:getParentGameObj(targeter)
			end

			-- 获取幻兽天赋
			local fight_pet_tianfu_effects, heti_pet_tianfu_effects = ChPetService:getPetTianfuEffects(ownerCharacter)

			-- 只有某几种天赋需要在战斗中处理
			targeter.tmps.pet_tianfu = {} -- 先清空旧有的
			local targeter_tmps_pet_tianfu = targeter.tmps.pet_tianfu
			if is_pet then
				-- 出战幻兽取自己的
				targeter_tmps_pet_tianfu['dodge_rate_perc'] = fight_pet_tianfu_effects['dodge_rate_perc'] -- 闪避率+x%
				targeter_tmps_pet_tianfu['parry_rate_perc'] = fight_pet_tianfu_effects['parry_rate_perc'] -- 格挡率+x%

				targeter_tmps_pet_tianfu['parry_fanji_attack_perc'] = fight_pet_tianfu_effects['parry_fanji_attack_perc'] -- (反戈一击)格挡后反击敌人，反击伤害为<受击者最外层攻击力*x%>

				targeter_tmps_pet_tianfu['harm_perc_in_beast'] = fight_pet_tianfu_effects['harm_perc_in_beast'] -- (灵体升华)免伤x%，如果在自己召唤的柱子召唤物攻击范围内，免伤效果翻2倍
			else
				-- 角色的只能取合体幻兽的(共享给合体幻兽)
				targeter_tmps_pet_tianfu['dodge_rate_perc'] = heti_pet_tianfu_effects['dodge_rate_perc'] -- 闪避率+x%
				targeter_tmps_pet_tianfu['parry_rate_perc'] = heti_pet_tianfu_effects['parry_rate_perc'] -- 格挡率+x%

				targeter_tmps_pet_tianfu['parry_fanji_attack_perc'] = heti_pet_tianfu_effects['parry_fanji_attack_perc'] -- (反戈一击)格挡后反击敌人，反击伤害为<受击者最外层攻击力*x%>

				targeter_tmps_pet_tianfu['harm_perc_in_beast'] = heti_pet_tianfu_effects['harm_perc_in_beast'] -- (灵体升华)免伤x%，如果在自己召唤的柱子召唤物攻击范围内，免伤效果翻2倍

				-- 只针对角色才有效的幻兽天赋光环
				-- (替身傀儡)光环效果，拥有该天赋的幻兽无论在合体还是出战，都会让非合体出战单位(包含蝙蝠和柱子召唤物)概率承受主人受到的部分伤害
				targeter_tmps_pet_tianfu['tf_fendan_harm_perc'] = fight_pet_tianfu_effects['tf_fendan_harm_perc'] or heti_pet_tianfu_effects['tf_fendan_harm_perc']
			end

			-- 调试用
			if false then
				if self:isCharacter(targeter) then
					print("受击者(角色)-----------------------------------")
					table.dump(targeter.tmps.pet_tianfu, -1)
				else
					print("受击者(出战幻兽)-----------------------------------")
					table.dump(targeter.tmps.pet_tianfu, -1)
				end
			end
		end
	end


	-- 是否拥有自爆的幻兽天赋(这个比较特殊，独立出来)
	-- character : 角色
	function FightService:getPetTianFuZiBao(fighter)
		local fight_pet_tianfu_effects, heti_pet_tianfu_effects = ChPetService:getPetTianfuEffects(fighter)

		-- 光环(最终献祭)死亡后对周围x米最多n个敌人造成<死亡单位的攻击力*y%>点伤害，并且蝙蝠自爆威力加强z%
		local arr_values = fight_pet_tianfu_effects['zibao_multi_attack_perc'] or heti_pet_tianfu_effects['zibao_multi_attack_perc']
		if arr_values then
			return (arr_values['effect_value1'] or 0), (arr_values['effect_value2'] or 0), (arr_values['effect_value3'] or 0), (arr_values['effect_value4'] or 0)
		else
			return 0, 0, 0, 0
		end
	end


	-- 获取某个天赋的值
	-- object : 对象
	-- key : 关键字
	-- 返回天赋的值
	function FightService:getPetTianFuValue(object, key)
		local petTianFuOwner = self:getMyPetTianFuOwner(object)
		local petTianFuOwner_tmps_pet_tianfu = petTianFuOwner.tmps.pet_tianfu
		if petTianFuOwner_tmps_pet_tianfu then
			local arr_values = petTianFuOwner_tmps_pet_tianfu[key]
			if arr_values then
				return (arr_values['effect_value1'] or 0), (arr_values['effect_value2'] or 0), (arr_values['effect_value3'] or 0), (arr_values['effect_value4'] or 0)
			end
		end

		return 0, 0, 0, 0
	end


	-- 获取我的幻兽天赋属性主体(角色，出战幻兽取自己/合体幻兽取主人)
	-- targeter : 被攻击者
	function FightService:getMyPetTianFuOwner(object)
		local owner = object
		if self:isHeTiPet(object) then
			owner = ChPetService:getParentGameObj(object) -- 小蒋提供接口
		end
		return owner
	end


	-- 伤害系数加成
	-- harm_radix : 原伤害系数
	-- fighter : 攻击者
	-- targeter : 被攻击者
	-- skill : 技能
	-- return harm_radix
	function FightService:extraHarmRadix(harm_radix, fighter, targeter, skill)
		local fighter_tmps_pet_tianfu = fighter.tmps.pet_tianfu

		-- 幻兽天赋额外伤害(血统压制)
		local extra_add_perc = self:getPetTianFuHpMoreHarmPerc(fighter, targeter)
		if 0 < extra_add_perc then
			harm_radix = harm_radix * (1 + extra_add_perc)
		end

		-- 幻兽天赋额外伤害(斗争天性)
		local pet_tianfi_harm_target_inc_buff_multi_for_wuli, pet_tianfi_harm_target_inc_buff_multi_for_fasu = self:getPetTianFuValue(fighter, 'harm_target_inc_buff_multi')
		if 0 < pet_tianfi_harm_target_inc_buff_multi_for_wuli then
			extra_add_perc = 0
			-- 根据技能类型取不同值
			if skill.skill_base.prof_faction == SkillDefs_SKILL_PROF_FACTION_WULI then
				extra_add_perc = pet_tianfi_harm_target_inc_buff_multi_for_wuli -- 物理
			else
				extra_add_perc = pet_tianfi_harm_target_inc_buff_multi_for_fasu -- 法术
			end
			if 0 < extra_add_perc then
				harm_radix = harm_radix * (1 + extra_add_perc)
			end
		end

		-- 幻兽天赋(灵体升华)，减少扣血百分比的
		local extra_del_perc = self:getPetTianHarmPercInBeast(targeter)
		if 0 < extra_del_perc then
			harm_radix = harm_radix * (1 - extra_del_perc)
		end

		return harm_radix
	end


	-- 幻兽天赋 : 血统压制，额外增加伤害百分比
	-- fighter : 攻击者
	-- targeter : 被攻击者
	function FightService:getPetTianFuHpMoreHarmPerc(fighter, targeter)
		local value = 0

		-- 要有血统压制才处理
		local pet_tianfu_hp_mor_harm_perc = self:getPetTianFuValue(fighter, 'hp_more_harm_perc_target')
		if 0 < pet_tianfu_hp_mor_harm_perc then
			-- 条件判断
			local fighter_hp_perc = self:getMyHpPerc(fighter)
			local targeter_hp_perc = self:getMyHpPerc(targeter)
			if fighter_hp_perc > targeter_hp_perc then
				value = pet_tianfu_hp_mor_harm_perc
			end
		end

		return value
	end


	-- 生命百分比对比判断
	function FightService:getMyHpPerc(object)
		local total_max_hp = 1
		local total_hp = 1

		if self:isLikeCharacter(object) then
			total_max_hp = object.max_hp + object.max_hp2 + object.max_hp3
			total_hp = object.hp + object.hp2 + object.hp3
		else
			total_max_hp = object.max_hp
			total_hp = object.hp
		end

		return total_hp / total_max_hp
	end


	-- 幻兽天赋 : 灵体升华，减少伤害百分比
	-- targeter : 被攻击者
	function FightService:getPetTianHarmPercInBeast(targeter)
		local value = 0

		-- 要有灵体升华才处理
		local del_hp_perc, del_hp_times = self:getPetTianFuValue(targeter, 'harm_perc_in_beast')
		if 0 < del_hp_perc then
			-- 抵消的百分比
			value = del_hp_perc

			-- 条件判断，召唤师的，如果在自己召唤的柱子召唤物攻击范围内，免伤效果翻2倍
			local parent
			if self:isLikeCharacter(targeter) then
				parent = targeter
			elseif self:isPet(targeter) then
				parent = ChPetService:getParentGameObj(targeter) -- 小蒋提供接口
			end

			-- 判断是否存在有召唤出来的柱子
			if parent then
				local aoiScene = GameObjectService:getAoiScene(parent)
				local move_beast, no_move_beast = BeastService:getMyBeast(aoiScene, parent)
				if no_move_beast then
					-- 判断距离，写死6米，因为几个柱子都是6米，再加点容错1米
					local skill_distance = 7
					if Formula:isNearbyDistance(targeter.x, targeter.y, no_move_beast.x, no_move_beast.y, skill_distance) then
						value = value * del_hp_times
					end
				end
			end
		end

		return value
	end


	-- 获取格挡的幻兽天赋额外逻辑
	function FightService:getPetTianFuForParryFanjiAttack(object)
		local attack = 0
		-- 挡后反击敌人，反击伤害为<受击者最外层攻击力*x%>
		local parry_fanji_attack_perc = self:getPetTianFuValue(object, 'parry_fanji_attack_perc')
		if 0 < parry_fanji_attack_perc then
			-- 获取最外层的对象的攻击力
			local outestFighter = self:getOutestFighter(object)
			attack = ceil((outestFighter.min_attack + outestFighter.max_attack) / 2 * parry_fanji_attack_perc)
		end

		return attack
	end


	-- 幻兽天赋 : 出战幻兽 : 击杀敌人后回复生命上限+x%；内层合体幻兽 : 击杀敌人后给外层幻兽复活
	-- fighter : 攻击者
	-- targeter : 被攻击者
	-- return 加任意层次血的绝对值，加内层幻兽血的绝对值，加外层幻兽血的绝对值
	function FightService:getPetTianFuKillAddHpPercOrRelive(fighter, targeter)
		local add_hp = 0		-- 加任意层次的血(出战幻兽)
		local add_inpet_hp = 0  -- 加内层幻兽血
		local add_outpet_hp = 0 -- 加外层幻兽血
		if self:isDead(targeter) then -- 必须是有杀死敌人
			local fighter_tmps_fight_info = fighter.tmps.fight_info
			local is_fighter_kill_add_hp_perc_or_relive = fighter_tmps_fight_info.is_fighter_kill_add_hp_perc_or_relive or 1

			if 0 == is_fighter_kill_add_hp_perc_or_relive then
				-- 必须要有幻兽的浴血奋战天赋
				local pet_tianfu_kill_add_hp_perc_or_relive = self:getPetTianFuValue(fighter, 'kill_add_hp_perc_or_relive')
				if 0 < pet_tianfu_kill_add_hp_perc_or_relive then
					if self:isLikeCharacter(targeter) or self:isMonster(targeter) then -- 必须是击杀角色或者是击杀怪物
						-- 是否需要记录
						local is_need_record = false

						if self:isLikeCharacter(fighter) then
							if ((fighter.hp2 < fighter.max_hp2) and (0 < fighter.hp2)) then
								-- 内层的先满血
								add_inpet_hp = ceil(fighter.max_hp2 - fighter.hp2)
								is_need_record = true
							end

							-- 如果存在有外层幻兽，并且外层幻兽是死的
							if (0 < fighter.max_hp3) then
								if (1 > fighter.hp3) then
									-- 死亡的恢复30%
									fighter.hp3 = 0 -- 因为会出现负数，免得后面加血的时候不是从0开始加
									add_outpet_hp = ceil(pet_tianfu_kill_add_hp_perc_or_relive * fighter.max_hp3)
								else
									-- 没死的，恢复满血
									add_outpet_hp = ceil(fighter.max_hp3 - fighter.hp3)
								end

								is_need_record = true
							end

						elseif self:isPet(fighter) then
							-- 出战幻兽的加自己血
							if (fighter.max_hp > fighter.hp) and (fighter.hp > 0) then
								add_hp = ceil(pet_tianfu_kill_add_hp_perc_or_relive * fighter.max_hp)
								is_need_record = true
							end
						end

						if is_need_record then
							-- 记录该天赋触发(小蒋提供接口)
							ChPetService:recordTianfuTriggered(fighter, 'kill_add_hp_perc_or_relive')

							-- 标志本次攻击已经触发过(避免群攻的时候多次触发)
							fighter_tmps_fight_info.is_fighter_kill_add_hp_perc_or_relive = 1
						end
					end
				end
			end
		end

		return add_hp, add_inpet_hp, add_outpet_hp
	end


	-- 获取一个对象最外层血
	function FightService:getOutestMaxHp(object)
		local value = object.max_hp

		if self:isLikeCharacter(object) then
			if 0 < object.hp3 then
				value = object.max_hp3
			elseif 0 < object.hp2 then
				value = object.max_hp2
			end
		end

		return value
	end


	-- 看看有没有助手能帮忙减少扣血
	function FightService:helperDelHp(object, del_hp)
		-- 能帮忙的对象
		local helperObject

		-- 只有角色被攻击才会出现找人抵挡的情况
		if self:isLikeCharacter(object) then
			-- 是否拥有替身傀儡天赋
			local tf_fendan_harm_perc_prof, tf_fendan_harm_perc_value = self:getPetTianFuValue(object, 'tf_fendan_harm_perc')
			tf_fendan_harm_perc_prof = tf_fendan_harm_perc_prof * 100 -- bufferHit的参数是要*100的
			if (0 < tf_fendan_harm_perc_prof) and (self:isBufferHit(tf_fendan_harm_perc_prof)) and (0 < tf_fendan_harm_perc_value) then
				-- 法师比其他职业多蝙蝠和站桩的幻兽可以帮忙抵血
				local aoiScene = GameObjectService:getAoiScene(object)
				local move_beast, no_move_beast = BeastService:getMyBeast(aoiScene, object)
				-- 蝙蝠
				if move_beast and not self:isDead(move_beast) then
					-- 因为召唤兽被杀会有几秒的延迟才删除，所以这里需要判断是否已死亡
					helperObject = move_beast
				end

				-- 找站桩的
				if not helperObject then
					if no_move_beast and not self:isDead(no_move_beast) then
						helperObject = no_move_beast
					end
				end

				-- 找出战幻兽
				if not helperObject then
					-- 小蒋提供接口
					local fight_pet = ChPetService:getFightChPet(object)
					if fight_pet and not self:isDead(fight_pet) then
						helperObject = fight_pet
					end
				end

				-- 存在可以帮忙抵押扣血的，则进行处理
				if helperObject and (not self:isDead(helperObject)) then
					-- 这里方毅说向下取整，因为有的PVE是保底1点伤害，不向下反而会吃亏
					local helper_del_hp = floor(del_hp * tf_fendan_harm_perc_value)
					if 0 < helper_del_hp then
						del_hp = del_hp - helper_del_hp

						-- 扣血
						self:initTargeterFightTmps(helperObject)
						local targeter_hp_index, targeter_del_hp, targeter_new_hp = self:delHp(helperObject, true, helper_del_hp, 0)
						self:logTargeterHelpDelHp(helperObject, targeter_hp_index, -targeter_del_hp, targeter_new_hp)

						-- 记录帮忙扣血的对象
						g_arr_helper_del_hp_object[helperObject.aoi_id] = helperObject
					end
				end
			end
		end -- end if self:isLikeCharacter(object) then

		return del_hp
	end


	-- 把协助者加入受击者队列里
	function FightService:addHelperToTargeter(arr_targeter)
		for _, now_helper in pairs(g_arr_helper_del_hp_object) do
			if 0 == now_helper.tmps.fight_info.targeter_is_real_targeter then
				-- 本身如果就已经是受击者队列的，就不用再重复加一次
				tableInsert(arr_targeter, now_helper)
			end
		end
	end
end


do
	-- 初始化本次攻击的类型
	-- fighter : 攻击者
	-- targeter : 被攻击者
	function FightService:setAttackIsPvp(fighter, targeter)
		-- 默认是pvp
		g_is_this_attack_pvp = true

		if self:isMonster(fighter) then
			g_is_this_attack_pvp = false
		elseif self:isMonster(targeter) then
			g_is_this_attack_pvp = false
		end
	end
end


-- 把对象移动到某个位置(冲击等这些)
-- objcet : 要移动的对象
-- new_x : 要移动到的x坐标
-- new_y : 要移动到的y坐标
do
	function FightService:moveToPos(object, new_x, new_y)
		local MotionService = MotionService
		MotionService:set2stop(object)
		MotionService:setPos(object, new_x, new_y, false) -- 第4个参数，是否发包给客户端(瞬移)
	end
end
------------------------------------------------------------ suwin辅助检查 end ---------------------------------------------------------------


------------------------------------------------------------ 战斗公式相关 start --------------------------------------------------------------
do
	-- 需要走buffer判断的key
	local upval_arr_buffer_key = {'min_attack', 'max_attack', 'defence_phy', 'defence_magic', 'kill_force'}

	-- 获取一个对象的某个属性值
	function FightService:getObjAttribVal(object, key)
		local value = 0

		if self:isMonster(object) then
			-- 怪物
			value = object.monster_base[key] or 0
		else
			-- 角色/召唤物/幻兽/合体幻兽
			value = object[key] or 0

			-- 幻兽，合体幻兽读取主人身上的属性(斩杀力，等级)(方毅)
			if ('kill_force' == key) or ('level' == key) then
				-- 出战幻兽/合体幻兽
				local isPet = self:isPet(object)
				local isHeTiPet = self:isHeTiPet(object)
				if isPet or isHeTiPet then
					local parent = ChPetService:getParentGameObj(object) -- 小蒋提供接口
					if parent then
						value = parent[key] or 0 -- 换成主人的斩杀力
					end
				end

				-- pve的斩杀力值是0
				if ('kill_force' == key) then
					if not g_is_this_attack_pvp then
						return 0
					end
				end
			end
		end

		-- 斩杀力特有公式
		if 'kill_force' == key then
			value = min(value, 150) * 0.005 + min(max(0, value - 150), 150) * 0.002 + min(max(0, value - 300), 150) * 0.001 + max(0, value - 450) * 0.0005
		end

		-- 增加伤害百分比和抵扣伤害百分比
		if ('addi_harm_perc' == key) or ('reduce_harm_perc' == key) then
			if g_is_this_attack_pvp then -- pvp战斗才生效(方毅确认)
				if 0 ~= value then
					value = value / 10000
				end
			else
				value = 0
			end
		end

		----------------------------------------------------------------------------

		-- buffer对属性的影响
		if inArray(key, upval_arr_buffer_key) then
			local arr_buffer = self:getMyBuffers(object)
			if arr_buffer then
				-- table.dump(arr_buffer, -1)

				-- 低攻，高攻
				if ('min_attack' == key) or ('max_attack' == key) then
					local attack_perc = arr_buffer.attack_perc and arr_buffer.attack_perc.effect_value or 0 -- 所有对象都有效
					if 0 ~= attack_perc then
						value = ceil(value * (1 + attack_perc))
					end

					if self:isLikeCharacter(object) then
						-- 只对主人有效
						local attack_perc_only_character = arr_buffer.attack_perc_only_master and arr_buffer.attack_perc_only_master.effect_value or 0
						if 0 ~= attack_perc_only_character then
							value = ceil(value * (1 + attack_perc_only_character))
						end
					end
				end

				-- 物防
				if 'defence_phy' == key then
					local defence_phy_perc = arr_buffer.defence_phy_perc and arr_buffer.defence_phy_perc.effect_value or 0 -- 物防百分比
					if 0 ~= defence_phy_perc then
						value = ceil(value * (1 + defence_phy_perc))
					end
				end

				-- 法防
				if 'defence_magic' == key then
					local defence_magic_perc = arr_buffer.defence_magic_perc and arr_buffer.defence_magic_perc.effect_value or 0 -- 魔防百分比
					if 0 ~= defence_magic_perc then
						value = ceil(value * (1 + defence_magic_perc))
					end
				end

				-- 斩杀力
				if 'kill_force' == key then
					local kill_force_perc = arr_buffer.kill_force_perc and arr_buffer.kill_force_perc.effect_value or 0 -- 斩杀力百分比
					if 0 ~= kill_force_perc then
						value = ceil(value * (1 + kill_force_perc))
					end
				end
			end
		end

		return value
	end


	-- 获取伤害公式参数
	function FightService:getHarmParams(fighter, targeter, skill)
		local total_base_harm = 0		-- 攻击者伤害基础总值(攻击者基础伤害+攻击者合体幻兽1基础伤害+攻击者合体幻兽2基础伤害)
		local total_min_harm = 0		-- 攻击者最小伤害总值
		local total_harm_percent = 0	-- 攻击者百分比伤害总值
		local total_harm = 0			-- 攻击者绝对伤害总值
		local fighter_live_pet = 0		-- 攻击者存活的幻兽数

		-- 是否触发斗志
		local is_douzhi = self:isDouzhiOk(fighter, targeter)

		if self:isLikeCharacter(fighter) then
			local true_fighter

			for fighter_index = 1, 3 do -- 计算(内层幻兽 + 外层幻兽 + 角色)的3个基础伤害得到总和
				-- 找到真实的攻击者
				true_fighter = self:getNowTrueFighter(fighter, fighter_index)
				if true_fighter then
					local fighter_attack, targeter_defence, fighter_min_harm = self:getAttackDefenceVal(true_fighter, targeter, skill, is_douzhi)
					local now_base_harm = fighter_attack - targeter_defence
					if now_base_harm < 0 then
						now_base_harm = 0
					end
					total_base_harm = total_base_harm + now_base_harm
					total_min_harm = total_min_harm + fighter_min_harm

					total_harm_percent = total_harm_percent + self:getObjAttribVal(true_fighter, 'addi_harm_perc')
					total_harm = total_harm + self:getObjAttribVal(true_fighter, 'addi_harm')

					fighter_live_pet = fighter_live_pet + 1
				end
			end

			-- 扣掉角色本身
			fighter_live_pet = fighter_live_pet - 1
		else
			-- 非玩家类的
			local fighter_attack, targeter_defence, fighter_min_harm = self:getAttackDefenceVal(fighter, targeter, skill, is_douzhi)

			total_base_harm = fighter_attack - targeter_defence
			if total_base_harm < 0 then
				total_base_harm = 0
			end
			total_min_harm = fighter_min_harm
			total_harm_percent = self:getObjAttribVal(fighter, 'addi_harm_perc')
			total_harm = self:getObjAttribVal(fighter, 'addi_harm')
			fighter_live_pet = 0
		end

		-- 受击者免伤百分比
		local targeter_reduce_harm_perc = self:getObjAttribVal(targeter, 'reduce_harm_perc')
		-- 受击者免伤绝对值
		local taregetr_reduce_harm = self:getObjAttribVal(targeter, 'reduce_harm')

		-- 攻击者百分比伤害 = 攻击者附伤百分比 - 受击者免伤百分比
		-- total_harm_percent = total_harm_percent - (fighter_live_pet + 1) * (targeter_reduce_harm_perc or 0)
		total_harm_percent = total_harm_percent - (targeter_reduce_harm_perc or 0)

		-- 攻击者绝对值伤害 = 攻击者加伤 + 合体幻兽1加伤 + 合体幻兽2加伤 - (攻击者存活合体幻兽数量 + 1) * 受击者减伤
		total_harm = total_harm - (fighter_live_pet + 1) * (taregetr_reduce_harm or 0)

		-- pve最小保底伤害变成1
		if not g_is_this_attack_pvp then
			total_min_harm = 1
		end

		return total_base_harm, total_min_harm, total_harm_percent, total_harm
	end


	-- 获取伤害值
	function FightService:calcHarm(fighter, targeter, skill, harm_radix, action_id)
		-- local
		local skillDetail = skill.skill_detail

		local total_base_harm, total_min_harm, total_harm_percent, total_harm = self:getHarmParams(fighter, targeter, skill)

		-- 被攻击者溅射伤害系数
		local targeter_sputter_harm_radix = 1
		local targeter_tmps = targeter.tmps -- 守护幻兽没有tmps
		if targeter_tmps then
			local targeter_targeter_fight_info = targeter_tmps.targeter_fight_info
			if targeter_targeter_fight_info then
				targeter_sputter_harm_radix = targeter_targeter_fight_info.sputter_harm_radix or 1
			end
		end
		
		-- 技能伤害百分比
		local skill_harm_percent = (skillDetail.harm_percent or 0.01) * targeter_sputter_harm_radix
		-- 技能附加伤害绝对值
		local skill_extra_harm = skillDetail.extra_harm or 0
		-- 技能伤害系数2
		local harm_percent2 = (skillDetail.harm_percent2 or 0) * targeter_sputter_harm_radix

		-- 攻击者斩杀力
		local fighter_kill_force = self:getObjAttribVal(fighter, 'kill_force')
		-- 受击者斩杀力
		local targeter_kill_force = self:getObjAttribVal(targeter, 'kill_force')

		-- 伤害加成百分比
		total_harm_percent = (1 + total_harm_percent)
		if 0 > total_harm_percent then
			total_harm_percent = 0
		end

		-- 斩杀力
		local final_kill_force = (1 + fighter_kill_force - targeter_kill_force)
		if 0 > final_kill_force then
			final_kill_force = 0
		end

		-- 公式
		local harm = ((total_base_harm * skill_harm_percent + skill_extra_harm) * total_harm_percent + total_harm * harm_percent2) * final_kill_force

		-- 乘上格挡/暴击
		harm = harm * harm_radix

		-------------------------------------------------------------------------------------------------------------------------------
		-- 额外伤害百分比(例如战士的狂暴)
		local extra_harm = 0 -- 额外伤害绝对值
		local extra_harm_perc = 0 -- 额外伤害百分比

		-- 小蒋提供接口(接口里会考虑攻击者和被攻击者的所有与伤害加成/减少有关的buffer，并合并在一起)
		extra_harm, extra_harm_perc = BufferService:getTargetAddiFinHarm(fighter, targeter)

		if 0 ~= extra_harm then
			harm = harm + extra_harm
		end

		if 0 ~= extra_harm_perc then
			harm = harm * (1 + extra_harm_perc)
		end

		-- 神兵技能(召唤师) : 伤害增加x%(攻击者)
		local sb_jiashang_perc = self:getShengBingSkill(fighter, 'sb_jiashang_perc')
		if 0 < sb_jiashang_perc then
			local sb_jiashang_radix = 1
			-- 小蒋提供接口
			if MotionService:isChangeSpeed(targeter) then
				-- 速度异常的，就2倍
				sb_jiashang_radix = 2
			end
			harm = harm * (1 + sb_jiashang_perc * sb_jiashang_radix)
		end

		-- 神兵技能(战士) : 基础免伤x%(被攻击者)
		local sb_mianshang_perc = self:getShengBingSkill(targeter, 'sb_mianshang_perc')
		if 0 < sb_mianshang_perc then
			harm = harm * (1 - sb_mianshang_perc)
		end

		-- 情侣系统增加伤害值(pve才有效)
		if not g_is_this_attack_pvp then
			if self:isCharacter(fighter) then
				local lover_add_harm_perc = fighter.tmps_ex.lover_fight_radix or 0
				harm = harm * (1 + lover_add_harm_perc)
			end
		end
		-------------------------------------------------------------------------------------------------------------------------------

		-- PVE等级压制规则
		local diff_level = self:getLevelRepressInfo(fighter, targeter)
		if 0 < diff_level then
			local level_repress = 1 + min(9, diff_level) * 0.06
			harm = harm * level_repress
		end

		-- 伤害值修正
		if total_min_harm > harm then
			harm = total_min_harm
		end

		-- 神兵技能(血族) : 每次暴击额外流失对方生命上限的y%(方毅确认 : 不受伤害修正影响)
		if ResultTypeCrit == action_id then -- 暴击
			local sb_bj_extra_kouxue_perc = self:getShengBingSkill(fighter, 'sb_bj_extra_kouxue_perc')
			if 0 < sb_bj_extra_kouxue_perc then
				harm = harm + self:getShengBingBjExtraKouXue(fighter, targeter, sb_bj_extra_kouxue_perc)
			end

		elseif ResultTypeParry == action_id then -- 格挡
			-- 神兵技能(战士) : 格挡后有y%触发无伤
			local sb_gd_wushang_rate = self:getShengBingSkill(targeter, 'sb_gd_wushang_rate')
			if 0 < sb_gd_wushang_rate then
				if self:isBufferHit(sb_gd_wushang_rate * 100) then
					harm = 1
				end
			end
		end

		-- 神兵技能(血族) : 连击中免伤增加x%(被攻击者)
		local sb_lj_mianshang_add_perc = self:getShengBingSkill(targeter, 'sb_lj_mianshang_add_perc')
		if 0 < sb_lj_mianshang_add_perc then
			harm = harm * (1 - sb_lj_mianshang_add_perc)
		end

		return ceil(harm)
	end


	-- 获取攻击者攻击总值(根据技能类型来判断是走物理系技能公式/法术系技能公式)
	-- fighter : 攻击者
	-- targeter : 被攻击者
	-- skill : 技能
	-- is_douzhi : 是否触发斗志
	-- return fighter_attack(攻击者攻击), targeter_defence(被攻击者的防御值), fighter_min_harm(最小伤害值)
	function FightService:getAttackDefenceVal(fighter, targeter, skill, is_douzhi)
		local is_douzhi = is_douzhi or false -- 默认没有触发斗志

		local skill_prof = skill.skill_base.prof_faction -- 技能职业类型(物理/法术)

		local fighter_attack = 0
		local targeter_defence = 0
		local fighter_min_attack = self:getObjAttribVal(fighter, 'min_attack')
		local fighter_max_attack = self:getObjAttribVal(fighter, 'max_attack')

		if is_douzhi then  
			fighter_attack = fighter_max_attack
		else
			fighter_attack = random(fighter_min_attack, fighter_max_attack)
		end

		if self:isMonster(fighter) then
			-- 怪物攻击，取目标的大的防御值
			local targeter_defence_phy = self:getObjAttribVal(targeter, 'defence_phy')
			local targeter_defence_magic = self:getObjAttribVal(targeter, 'defence_magic')
			if targeter_defence_phy > targeter_defence_magic then
				targeter_defence = targeter_defence_phy
			else
				targeter_defence = targeter_defence_magic
			end
		else
			-- 非怪物类的，按技能类型判断
			if skill_prof == SkillDefs_SKILL_PROF_FACTION_WULI then
				-- 物理
				targeter_defence = self:getObjAttribVal(targeter, 'defence_phy')
			else
				-- 法术
				targeter_defence = self:getObjAttribVal(targeter, 'defence_magic')
			end
		end

		-- 技能降低被攻击者防御百分比
		local skill_skill_detail_extra_target_effect = skill.skill_detail.extra_target_effect
		if skill_skill_detail_extra_target_effect then
			local skill_del_defence_percent = skill_skill_detail_extra_target_effect.del_defence_percent or 0
			if 0 ~= skill_del_defence_percent then
				targeter_defence = ceil(targeter_defence * (1 + skill_del_defence_percent))
			end
		end

		local fighter_min_harm = (fighter_min_attack + fighter_max_attack) * 0.5

		return ceil(fighter_attack), ceil(targeter_defence), ceil(fighter_min_harm)
	end


	-- 是否触发斗志
	-- return boolean
	function FightService:isDouzhiOk(fighter, targeter)
		local is_douzhi = false  -- 默认不触发斗志
		local fighter_douzhi = 0 -- 攻击者斗志
		local fighter_all_heti_pet_num = 0 -- 角色身上的合体幻兽数

		--------------------- 获取攻击者斗志 start ------------------
		if self:isLikeCharacter(fighter) then
			-- 获取主角的斗志
			fighter_douzhi = self:getObjAttribVal(fighter, 'douzhi')

			local fighter_tmps_fight_info = fighter.tmps.fight_info

			-- 合体幻兽斗志加成数量
			fighter_all_heti_pet_num = fighter_tmps_fight_info.all_heti_pet_num or 0

			-- 合体幻兽斗志总值
			local all_heti_pet_douzhi = fighter_tmps_fight_info.all_heti_pet_effect_value['douzhi'] or 0
			fighter_douzhi = fighter_douzhi + all_heti_pet_douzhi
		else
			-- 非角色类斗志
			fighter_douzhi  = self:getObjAttribVal(fighter, 'douzhi')
		end
		--------------------- 获取攻击者斗志 end --------------------

		-- 目标者斗志
		local targeter_douzhi = self:getObjAttribVal(targeter, 'douzhi')

		-- 斗志计算公式
		local douzhi_perc = (fighter_douzhi - targeter_douzhi * (fighter_all_heti_pet_num + 1)) / 10000
		if 1 < douzhi_perc then
			douzhi_perc = 1
		end
		if 0 > douzhi_perc then
			douzhi_perc = 0
		end

		local random_perc = random(0, 100) / 100
		if douzhi_perc >= random_perc then -- 触发斗志
			is_douzhi = true
		end

		return is_douzhi
	end


	-- 战斗逻辑使用圆桌理论，属性优先级为：闪避、格挡、暴击、普通命中
	function FightService:getFightResult(fighter, targeter, skill)
		local rand = random(1, 10000) / 10000 -- 概率支持四位小数
		local ret = ResultTypeHit	-- 普通命中

		local dodge = 0
		if not self:isLianJiSkill(skill.skill_base) then
			-- 连击不会被闪避
			dodge = self:calcDodgeRate(fighter, targeter, skill)
		end

		if rand <= dodge then
			return ResultTypeMiss -- 闪避
		end
		
		local parry = dodge + self:calcParryRate(fighter, targeter)
		if rand <= parry then
			return ResultTypeParry -- 格挡
		end
		
		local critical = parry + self:calcCriticalHitRate(fighter, targeter, skill)
		if rand <= critical then
			return ResultTypeCrit -- 暴击
		end

		return ret
	end


	-- 计算闪避的概率
	-- 闪避率 = ((攻击者合体幻兽数量 + 1) * 受击者闪避值 * 2 - 攻击者幸运 - 攻击者合体幻兽1幸运 - 攻击者合体幻兽2幸运) / ((受击者LV * 50 + 150) * 2 * (攻击者存活合体幻兽数量 + 1))
	-- + 亡灵法师先天10%闪避率 + 受击者其他途径附加闪避率
	function FightService:calcDodgeRate(fighter, targeter, skill)
		local dodge_rate = 0

		-- 攻击者合体幻兽数量
		local fighter_tmps_fight_info = fighter.tmps.fight_info
		local fighter_all_heti_pet_effect_value = fighter_tmps_fight_info.all_heti_pet_effect_value
		local fighter_all_heti_pet_num = fighter_tmps_fight_info.all_heti_pet_num or 0

		local targeter_dodge = self:getObjAttribVal(targeter, 'dodge') -- 受击者闪避
		local fighter_luck = self:getObjAttribVal(fighter, 'luck')	   -- 攻击者幸运
		local targeter_level = self:getObjAttribVal(targeter, 'level') -- 受击者等级(合体幻兽读角色的等级)

		-- 额外幸运值
		fighter_luck = fighter_luck + (fighter_all_heti_pet_effect_value['luck'] or 0) -- 合体幻兽额外幸运值(活着的幻兽)

		-- 召唤师额外10%
		local default_dodge_rate = 0
		if self:isLikeCharacter(targeter) then -- 角色/机器人
			if CharacterDefs_PROF_ID_FOR_ZHAOHUANSHI == targeter.prof then
				default_dodge_rate = 0.1
			end
		end

		-- 其他途径附加闪避率
		local targeter_extra_dodge_rate = 0
		-- 幻兽天赋额外闪避率
		local pet_tianfu_add_dodge_rate_perc = self:getPetTianFuValue(targeter, 'dodge_rate_perc')
		targeter_extra_dodge_rate = targeter_extra_dodge_rate + pet_tianfu_add_dodge_rate_perc

		-- PVE等级压制规则
		local diff_level = self:getLevelRepressInfo(targeter, fighter)
		if 0 < diff_level then
			local level_repress = min(9, diff_level) * 0.04
			targeter_extra_dodge_rate = targeter_extra_dodge_rate + level_repress
		end

		-- 最终闪避率计算
		dodge_rate = ((fighter_all_heti_pet_num + 1) * targeter_dodge * 2 - fighter_luck) / ((targeter_level * 50 + 150) * 2 * (fighter_all_heti_pet_num + 1)) + 
											default_dodge_rate + targeter_extra_dodge_rate

		if dodge_rate < 0 then
			dodge_rate = 0
		end
		if dodge_rate > 0.5 then
			dodge_rate = 0.5
		end
		
		return dodge_rate
	end


	-- 受击者格挡率
	-- 格挡率 = ((攻击者合体幻兽数量 + 1) * 受击者格挡值 * 2 - 攻击者幸运 - 攻击者合体幻兽１幸运 - 攻击者合体幻兽２幸运) / ((受击者LV * 25 + 75) * 2 * (攻击者存活合体幻兽数量 + 1))
	-- + 战士先天20%格挡率 + 受击者其他途径附加格挡率
	function FightService:calcParryRate(fighter, targeter)
		local parry_rate = 0

		-- 攻击者合体幻兽数量
		local fighter_tmps_fight_info = fighter.tmps.fight_info
		local fighter_all_heti_pet_effect_value = fighter_tmps_fight_info.all_heti_pet_effect_value
		local fighter_all_heti_pet_num = fighter_tmps_fight_info.all_heti_pet_num or 0

		local targeter_parry = self:getObjAttribVal(targeter, 'parry')	-- 受击者格挡
		local fighter_luck = self:getObjAttribVal(fighter, 'luck')		-- 攻击者幸运
		local targeter_level = self:getObjAttribVal(targeter, 'level')	-- 受击者等级(合体幻兽读角色的等级)

		-- 额外幸运值
		fighter_luck = fighter_luck + (fighter_all_heti_pet_effect_value['luck'] or 0) -- 合体幻兽额外幸运值(活着的幻兽)

		-- 战士先天20%格挡率
		local default_parry_rate = 0
		if self:isLikeCharacter(targeter) then -- 角色/机器人
			if CharacterDefs.PROF_ID_FOR_ZHANSHI == targeter.prof then
				default_parry_rate = 0.2
			end
		end

		-- 其他途径附加格挡率
		local targeter_extra_parry_rate = 0
		-- 幻兽天赋额外格挡率
		local pet_tianfu_add_parry_rate_perc = self:getPetTianFuValue(targeter, 'parry_rate_perc')
		targeter_extra_parry_rate = targeter_extra_parry_rate + pet_tianfu_add_parry_rate_perc

		-- PVE等级压制规则
		local diff_level = self:getLevelRepressInfo(targeter, fighter)
		if 0 < diff_level then
			local level_repress = min(9, diff_level) * 0.08
			targeter_extra_parry_rate = targeter_extra_parry_rate + level_repress
		end

		-- 计算最终格挡率
		parry_rate = ((fighter_all_heti_pet_num + 1) * targeter_parry * 2 - fighter_luck) / ((targeter_level * 25 + 75) * 2 * (fighter_all_heti_pet_num + 1)) + 
											default_parry_rate + targeter_extra_parry_rate


		if parry_rate < 0 then
			parry_rate = 0
		end
		if parry_rate > 1 then
			parry_rate = 1
		end
		
		return parry_rate
	end


	-- 攻击者暴击率
	-- 暴击率 = (攻击者暴击值 + 攻击者合体幻兽１暴击值 + 攻击者合体幻兽２暴击值 * 2 - (攻击者合体幻兽数量 + 1) * 受击者幸运) / ((攻击者LV * 25 + 75) * 2 * (攻击者存活合体幻兽数量 + 1))
	-- + 血族先天20%暴击率 + 攻击者其他途径附加暴击率
	function FightService:calcCriticalHitRate(fighter, targeter, skill)
		local critical_hit_rate = 0

		-- 攻击者合体幻兽数量
		local fighter_tmps_fight_info = fighter.tmps.fight_info
		local fighter_all_heti_pet_effect_value = fighter_tmps_fight_info.all_heti_pet_effect_value
		local fighter_all_heti_pet_num = fighter_tmps_fight_info.all_heti_pet_num or 0
		
		local fighter_critical_hit = self:getObjAttribVal(fighter, 'critical_hit') -- 攻击者暴击
		local targeter_luck = self:getObjAttribVal(targeter, 'luck')			   -- 受击者幸运
		local fighter_level = self:getObjAttribVal(fighter, 'level')			   -- 攻击者等级(合体幻兽读角色的等级)

		-- 额外暴击值
		fighter_critical_hit = fighter_critical_hit + (fighter_all_heti_pet_effect_value['critical_hit'] or 0) -- 合体幻兽额外暴击值(活着的幻兽)

		-- 血族先天20%暴击率
		local default_critical_hit_rate = 0
		if self:isLikeCharacter(fighter) then
			if CharacterDefs.PROF_ID_FOR_XUEZHU == fighter.prof then
				default_critical_hit_rate = 0.2
			end
		end

		-- 其他途径附加暴击率
		local fighter_extra_critical_hit_rate = 0
		-- 技能附加暴击率
		if skill then
			local skill_skill_detail_extra_self_effect = skill.skill_detail.extra_self_effect
			if skill_skill_detail_extra_self_effect then
				local skill_add_critical_hit_percent = skill_skill_detail_extra_self_effect.extra_critical_hit_prob or 0
				fighter_extra_critical_hit_rate = fighter_extra_critical_hit_rate + skill_add_critical_hit_percent
			end
		end
		-- 幻兽天赋额外暴击率
		local pet_tianfu_add_critical_hit_percent = self:getPetTianFuValue(fighter, 'critical_hit_rate_perc')
		fighter_extra_critical_hit_rate = fighter_extra_critical_hit_rate + pet_tianfu_add_critical_hit_percent

		-- PVE等级压制规则
		local diff_level = self:getLevelRepressInfo(fighter, targeter)
		if 0 < diff_level then
			local level_repress = min(9, diff_level) * 0.08
			fighter_extra_critical_hit_rate = fighter_extra_critical_hit_rate + level_repress
		end

		-- 计算最终暴击率
		critical_hit_rate = (fighter_critical_hit * 2 - (fighter_all_heti_pet_num + 1) * targeter_luck) / ((fighter_level * 25 + 75) * 2 * (fighter_all_heti_pet_num + 1)) + 
									default_critical_hit_rate + fighter_extra_critical_hit_rate

		if critical_hit_rate < 0 then
			critical_hit_rate = 0
		end
		if critical_hit_rate > 1 then
			critical_hit_rate = 1
		end
		
		return critical_hit_rate
	end


	-- 获取等级压制参数
	-- return diff_level
	function FightService:getLevelRepressInfo(object1, object2)
		local object1_level, object2_level
		local diff_level = 0

		if not g_is_this_attack_pvp then
			local flg_level_repress = 0
			if self:isMonster(object1) then
				flg_level_repress = object1.monster_base.level_repress or 0
			elseif self:isMonster(object2) then
				flg_level_repress = object2.monster_base.level_repress or 0
			end

			-- 需要等级压制
			if 1 == flg_level_repress then
				object1_level = self:getObjAttribVal(object1, 'level')
				object2_level = self:getObjAttribVal(object2, 'level')
				diff_level = object1_level - object2_level
			end
		end

		return diff_level
	end
end


do
	-- 获取神兵技能效果
	-- object : 对象
	-- shengbing_key : 神兵类型
	-- return value
	function FightService:getShengBingSkill(object, shengbing_key)
		local value = 0

		if self:isCharacter(object) then
			local keep_on = true

			-- 得判断是否在连击中，连击中才能有免伤减少
			if 'sb_lj_mianshang_add_perc' == shengbing_key then
				if not self:inFightState(object) then
					keep_on = false
				end
			end

			if keep_on then
				-- 国印提供接口
				local shengBingSkill = ChSkillService:getShenbingExtraSkillEffect(object)
				if shengBingSkill then
					value = shengBingSkill[shengbing_key] or 0
				end
			end
		end

		return value
	end


	-- 获取神兵技能暴击额外流失对方生命的值
	-- fighter : 攻击者
	-- targeter : 被攻击者
	-- return value
	function FightService:getShengBingBjExtraKouXue(fighter, targeter, perc)
		local lost_hp = 0

		-- 当(人物的最小攻击 + 最大攻击) * 1.5 ≤ 对方生命上限的y%，额外造成的伤害取(人物的最小攻击+最大攻击) * 1.5
		local fighter_max_attack = self:getObjAttribVal(fighter, 'max_attack')
		local fighter_min_attack = self:getObjAttribVal(fighter, 'min_attack')
		local fighter_attack = ceil((fighter_max_attack + fighter_min_attack) * 1.5)

		-- 获取扣血值
		local targeter_max_hp = self:getOutestMaxHp(targeter)
		local lost_hp = ceil(targeter_max_hp * perc)

		if lost_hp > fighter_attack then
			lost_hp = fighter_attack
		end

		return lost_hp
	end

	-- 神兵沉默
	function FightService:shengBingChenMo(fighter, targeter, perc)
		if 0 < perc then
			if self:isCharacter(targeter) then
				local fighter_tmps_fight_info = fighter.tmps.fight_info
				if self:isBufferHit(perc * 100) then
					if self:isCanShengBingChenMo(fighter, targeter) then
						tableInsert(fighter_tmps_fight_info.arr_chenmo_aoi_id, targeter.aoi_id)

						-- targeter记录是被谁命中的
						local targeter_tmps_fight_info = targeter.tmps.fight_info
						targeter_tmps_fight_info.last_chenmo_aoi_id = fighter.aoi_id
						targeter_tmps_fight_info.last_chenmo_expire = Time:getSecondsNow() + 10 -- 10秒免其他玩家的沉默
					end
				end
			end
		end
	end
	

	-- 是否可以沉默
	function FightService:isCanShengBingChenMo(fighter, targeter)
		local targeter_tmps_fight_info = targeter.tmps.fight_info
		local last_chenmo_aoi_id = targeter_tmps_fight_info.last_chenmo_aoi_id or 0
		local last_chenmo_expire = targeter_tmps_fight_info.last_chenmo_expire or 0
		local now_second = Time:getSecondsNow()

		if 0 < last_chenmo_aoi_id then -- 有被别人沉默了
			if last_chenmo_aoi_id ~= fighter.aoi_id then
				if now_second < last_chenmo_expire then -- 沉默还没过期
					return false
				end
			end
		end

		return true
	end


	-- 广播沉默信息给客户端
	local packet = FastPacket()
	function FightService:BcShengBingChenMo(aoiScene, fighter)
		local fighter_tmps_fight_info_arr_chenmo_aoi_id = fighter.tmps.fight_info.arr_chenmo_aoi_id
		local chenmo_aoi_id_num = sizeTable(fighter_tmps_fight_info_arr_chenmo_aoi_id)
		if 0 < chenmo_aoi_id_num then
			-- 广播给所有人(包含自己)
			local arr_bc_player_id = GameObjectService:getFovGPids(fighter, aoiScene)
			if not arr_bc_player_id then
				return nil
			end

			-- 创建包
			WorldPacket:resetWritePacket(packet, opCodes.M2C_FIGHT_DELAY_FIGHT_EXPIRE)
			
			-- 包结构
			writeUInt(packet, fighter.space_id)	 -- 场景实例id
			writeUInt(packet, fighter.aoi_id)	 -- 攻击者aoi_id
			writeUInt(packet, chenmo_aoi_id_num) -- 目标aoi_id数量
			for i = 1, chenmo_aoi_id_num do
				writeInt(packet, fighter_tmps_fight_info_arr_chenmo_aoi_id[i])
			end

			local ret_pack = WorldPacket:newClientPacket(opCodes.M2C_FIGHT_DELAY_FIGHT_EXPIRE, nil, arr_bc_player_id)
			ret_pack:writeVer()	
			ret_pack:writeFastPacketRaw(packet)

			WorldPacket:m2cSendPacket(ret_pack)
		end
	end
end
------------------------------------------------------------ 战斗公式相关 end ----------------------------------------------------------------


------------------------------------------------------------ 战斗后处理 start ----------------------------------------------------------------
-- 攻击后用于通知其他模块做逻辑
do
	function FightService:doAfterFight(aoiScene, fighter, targeter, arr_targeter)
		-- 是否是角色攻击
		local is_character_attack = false

		-- 是否取消所有保护状态
		local is_cancel_all_protected = true
		-- 如果是角色
		if self:isLikeCharacter(fighter) then
			-- 取消掉保护
			CharacterService:cancelProtect(0, fighter, is_cancel_all_protected)

			-- 是角色攻击
			is_character_attack = true
		elseif self:isBeast(fighter) or self:isPet(fighter) or self:isTrap(fighter) then
			-- 幻兽/召唤兽/陷阱，把攻击者变成是主人
			fighter = GameObjectService:getGameObjectByAoiId(aoiScene, fighter.parent_aoi_id)
			-- 取消掉主人的保护
			if fighter then
				CharacterService:cancelProtect(0, fighter, is_cancel_all_protected)
			end
		end
		
		-- 杀死玩家的列表
		local arr_kill_character_aoi_id = {} -- 杀死玩家的aoi_id
		local arr_character_harm = {}		 -- 玩家被伤害的信息，hash = {character.aoi_id => harm_value}
		-- 杀怪id列表
		local arr_kill_monster_id = {}		-- 原始怪物id
		local arr_kill_monster_aoi_id = {}	-- 怪物的aoi_id
		local arr_monster_harm = {}			-- 怪物被伤害的信息，hash = {monster.aoi_id => harm_value}
		-- 杀守护npc列表
		local arr_kill_guard_npc_aoi_id = {} -- 杀死守护npc的aoi_id

		-- 遍历本次攻击牵扯的被攻击者
		local arr_exist_aoi_id = {}
		local now_targeter_aoi_id
		for _, now_targeter in pairs(arr_targeter) do
			-- arr_targeter 存在一个角色同时存在多次的情况，避免多次被调用
			now_targeter_aoi_id = now_targeter.aoi_id or 0
			if (not arr_exist_aoi_id[now_targeter_aoi_id]) then
				-- 标志已处理
				arr_exist_aoi_id[now_targeter_aoi_id] = 1

				if self:isLikeCharacter(now_targeter) then
					-- 角色
					self:doAfterFightForCharacter(fighter, now_targeter, arr_kill_character_aoi_id, arr_character_harm)
				elseif self:isMonster(now_targeter) then
					-- 怪物
					self:doAfterFightForMonster(fighter, now_targeter, arr_kill_monster_id, arr_kill_monster_aoi_id, arr_monster_harm)
				elseif self:isPet(now_targeter) then
					-- 幻兽
					self:doAfterFightForPet(fighter, now_targeter)
				elseif self:isBeast(now_targeter) then
					-- 召唤兽
					self:doAfterFightForBeast(fighter, now_targeter)
				elseif self:isGuardNpc(now_targeter) then
					-- 守护NPC
					self:doAfterFightForGuardNpc(fighter, now_targeter, arr_kill_guard_npc_aoi_id)
				end
			end
		end

		-- 杀玩家通知其他模块
		FightHelperService:notifyModulesForKillCharacter(is_character_attack, fighter, arr_kill_character_aoi_id, arr_character_harm)

		-- 杀怪通知其他模块
		FightHelperService:notifyModulesForKillMonster(fighter, arr_kill_monster_id, arr_kill_monster_aoi_id, arr_monster_harm)

		-- 杀守护npc通知其他模块
		FightHelperService:notifyModulesForKillGuardNpc(fighter, arr_kill_guard_npc_aoi_id)
	end


	-- 处理攻击角色的
	function FightService:doAfterFightForCharacter(fighter, character, arr_kill_character_aoi_id, arr_character_harm)
		local character_aoi_id = character.aoi_id
		local hate_value = abs(character.tmps.fight_info.targeter_total_del_hp or 0) -- 被攻击的伤害值

		-- 记录角色伤害值
		arr_character_harm[character_aoi_id] = hate_value

		-- 角色死亡
		if self:isDead(character) then
			-- 将角色置成死亡
			self:characterDead(character)

			-- 记录杀死的怪物id列表，位置，aoi_id
			tableInsert(arr_kill_character_aoi_id, character_aoi_id) -- 记录aoi_id

			-- 需要走成就系统(国印提供接口)
			if AchieveDefs:isNeedCheckAchieve() then
				local fighter_fc = fighter.fight_capacity or 999999999
				local targeter_fc = character.fight_capacity or 1

				-- 成就类型
				if fighter_fc < targeter_fc then
					AchieveService:onCheckAchieve(fighter, AchieveDefs.ACHIEVE_SORT_ID_DO_KILL_FC_OVER) -- 敌方战力高

					if ((fighter_fc * 1.2) <= targeter_fc) then -- 敌方高20%战力
						AchieveService:onCheckAchieve(fighter, AchieveDefs.ACHIEVE_SORT_ID_DO_KILL_FC_OVER_20)

						if ((fighter_fc * 1.3) <= targeter_fc) then -- 敌方高30%战力
							AchieveService:onCheckAchieve(fighter, AchieveDefs.ACHIEVE_SORT_ID_DO_KILL_FC_OVER_30)
						end
					end
				end
			end -- end 成就
		end
	end


	---- 处理攻击怪物的
	local MonsterDefs_IS_HATE_YES = MonsterDefs.IS_HATE_YES -- 有仇恨的怪物
	local MonsterDefs_IS_CAN_ATTACK_YES = MonsterDefs.IS_CAN_ATTACK_YES -- 会攻击的怪物
	local MonsterDefs_IS_CAN_ATTACK_EXCAPE = MonsterDefs.IS_CAN_ATTACK_EXCAPE -- 会逃跑的怪物
	-- 角色/幻兽/召唤物打怪物
	function FightService:doAfterFightForMonster(fighter, monster, arr_kill_monster_id, arr_kill_monster_aoi_id, arr_monster_harm)
		-- local
		local monsterBase = monster.monster_base
		local monsterTmps = monster.tmps
		local monster_id = monsterBase.id
		local monster_aoi_id = monster.aoi_id
		local monster_tmps_fight_info = monster.tmps.fight_info
		local hate_value = abs(monster_tmps_fight_info.targeter_total_del_hp or 0) -- 仇恨值
		local is_need_drop = true -- 默认需要掉落

		-- 怪物伤害数据
		arr_monster_harm[monster_aoi_id] = hate_value

		-- 怪物死亡
		if self:isDead(monster) then
			-- 怪物变成死亡状态(保留尸体)
			MonsterAiService:toPreDeadState(monster)

			-- 停止怪物移动(小蒋提供接口)
			MotionService:stop(monster)

			-- 记录杀死的怪物id列表，位置，aoi_id
			tableInsert(arr_kill_monster_id, monster_id)		 -- 记录原始id
			tableInsert(arr_kill_monster_aoi_id, monster_aoi_id) -- 记录aoi_id

			-- 需要掉落物品
			if is_need_drop then
			end
		else
			if fighter then
				-- 回防中的怪物不将它激活成战斗状态
				if not MonsterAiService:isHoming(monsterTmps.now_state) then
					-- 如果怪物是有仇恨值，则记录怪物仇恨
					if MonsterDefs_IS_HATE_YES == monsterBase.is_hate then
						-- 更新仇恨值
						MonsterService:add2HateLists(monster, fighter, hate_value)
						MonsterService:updateHatestAoiId(monster, fighter.aoi_id)

						-- 将怪物状态变成战斗
						local is_force_aoto_fight = false
						MonsterAiService:toFightState(monster, fighter, nil, is_force_aoto_fight)
						MonsterAiService:delayAttackCd(monster) -- 被攻击延迟反击
					else
						local is_can_attack = monsterBase.is_can_attack
						if MonsterDefs_IS_CAN_ATTACK_YES == is_can_attack then
							-- 将怪物状态变成战斗
							MonsterAiService:toFightState(monster, fighter)
							MonsterAiService:delayAttackCd(monster) -- 被攻击延迟反击
						else
							if MonsterDefs_IS_CAN_ATTACK_EXCAPE == is_can_attack then
								-- 逃跑状态(猴子等)
								MonsterAiService:toEscapeState(monster, fighter)
							end
						end
					end
				else
					-- 只有被选中的怪物是回防中才有提示
					-- if now_monster.aoi_id == monster.aoi_id then
						-- ok_msg_id = errorCodes.FIGHT_MONSTER_IS_HOMING
					-- end
				end
			end
		end
	end


	-- 幻兽被攻击
	function FightService:doAfterFightForPet(fighter, pet)
		-- 幻兽死亡
		if self:isDead(pet) then
			-- 自爆
			self:petZiBao(pet)

			-- 小蒋提供接口
			ChPetService:onDead(pet)
			-- print("幻兽死亡")
		end
	end


	-- 召唤兽被攻击
	function FightService:doAfterFightForBeast(fighter, beast)
		-- 召唤兽死亡
		if self:isDead(beast) then
			local delay_ms = beast.beast_base.dead_delay_ms
			beast.tmps.delete_time = Time:getDelayMsTime(delay_ms) -- 延迟几秒后删除
			-- print("召唤兽延迟删除", delay_ms)
		end
	end


	-- 守护NPC被攻击
	function FightService:doAfterFightForGuardNpc(fighter, guardNpc, arr_kill_guard_npc_aoi_id)
		-- 守护NPC死亡
		if self:isDead(guardNpc) then
			tableInsert(arr_kill_guard_npc_aoi_id, guardNpc.aoi_id) -- 记录aoi_id
		end
	end


	-- 合体幻兽被攻击触发
	function FightService:onHetiPetAttacked(hp_index, new_hp, hetiPet)
		-- 表示是合体幻兽被攻击
		if (CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_2 == hp_index) or (CharacterDefs_CHARACTER_HP_INDEX_MAX_HP_3 == hp_index) then
			if (1 > new_hp) then
				-- 小蒋提供接口，有的合体幻兽死亡会触发幻兽天赋，替主人添加有益的buff
				ChPetService:onDeadForHeti(hetiPet)
				-- print("触发合体幻兽死亡", hp_index, hetiPet.pet_base.nick)
			end
		end
	end

	
	-- 将一个角色改成死亡状态(buffer生效也会调用该接口)
	-- character : 角色
	-- arr_scene_params : 场景信息
	function FightService:characterDead(character)
		local character_tmps = character.tmps

		-- 停止角色移动(小蒋提供接口)
		MotionService:stop(character)

		-- 取消掉旋风斩这些
		self:cancleFightState(character)

		-- 清除技能cd
		self:cleanSkillCd(character)

		-- 隐藏掉角色的幻兽(小蒋提供接口)
		ChPetService:hideFightPet(character)

		-- (召唤师才走这一步)删除掉召唤出来的召唤兽，陷阱等等(不会攻击的召唤兽除外)
		if self:isZhaoHuanShi(character) then
			-- 删除幻兽
			local is_only_del_attack_beast = true -- 不删除辅助类的
			local aoiScene = GameObjectService:getAoiScene(character)
			BeastService:delAllMyBeast(aoiScene, character, is_only_del_attack_beast)

			-- 删除陷阱
			TrapService:delMyTrap(character, aoiScene)
		end

		-- 清除角色所有负面buff
		-- BufferService:clearDeBuffer(character)

		-- 将角色修改成死亡状态(一定要放在最后面，不然上面调用的接口，有些会将角色变成空闲状态)
		CharacterService:changeState(character, Statics.GAME_OBJECT_STATUS_ID_DEAD)

		-- 修改角色的普通复活时间
		-- character_tmps.normal_relive_expire = Time:getSecondsNow() + ReliveDefs.RELIVE_DELAY_SECOND_FIVE
		ReliveService:addRelivePlayer( character )

		-- (游戏服与PK服不一致的)特殊条件的角色死亡，抽离到这里
		FightHelperService:onCharacterDead(character)
		-- print("角色死亡了。。。")
	end
end
------------------------------------------------------------ 战斗后处理 end ------------------------------------------------------------------


------------------------------------------------------------ 战斗后响应包处理 start ----------------------------------------------------------
-- 组织二进制包
do
	local pairs = pairs
	local packet = FastPacket(1024*8)
	local ret_opcode = opCodes.M2C_FIGHT_FIGHT -- 战斗包
	-- 攻击类的二进制包
	function FightService:buildBinPacket(aoiScene, fighter, targeter, skill, arr_targeter, arr_pos, fight_number_id)
		-- 广播给所有人(包含自己)
		local skillBase = skill.skill_base
		local skill_bc_num = skillBase.broadcast or 999
		-- local arr_bc_player_id = GameObjectService:getFovGPids(fighter, aoiScene)
		local arr_bc_player_id = GameObjectService:getBcGPidsForFight(fighter, aoiScene, skill_bc_num, arr_targeter)
		if not arr_bc_player_id then
			-- 守护npc里面有怪物打怪物的
			return nil
		end

		WorldPacket:resetWritePacket(packet,ret_opcode)--opCodes.M2C_FIGHT_FIGHT
		
		-- local
		local fighter_tmps = fighter.tmps
		local fighter_tmps_fight_info = fighter_tmps.fight_info
		local arr_fighter_add_hp = fighter_tmps_fight_info.arr_fighter_add_hp

		-- 本次攻击的时间
		local fight_expire = fighter_tmps.fight_expire
		-- (裔钊说去掉这个，由客户端自己处理)
		-- local is_lianji_hit = fighter_tmps.fight_info.is_lianji_hit or 1 -- 是否连击命中
		-- if 1 == is_lianji_hit then -- 连击技能
		--	if targeter and not self:isCanLocked(targeter) then -- 某些怪物不能被连击锁定
		--		fight_expire = 0
		--	end
		-- end

		-- 本次攻击玩家的目标位置
		local fighter_x = fighter.x
		local fighter_y = fighter.y
		if (0 < skillBase.self_slow_move_dist) and self:isLikeCharacter(fighter) then
			fighter_x = arr_pos.fighter_new_x
			fighter_y = arr_pos.fighter_new_y
		end

		writeUInt(packet, fight_number_id)					-- 战斗编号
		writeUInt(packet, fighter.space_id)					-- 场景实例id
		writeCoord(packet, arr_pos.target_x)				-- 目标x
		writeCoord(packet, arr_pos.target_y)				-- 目标y
		writeUInt(packet, fighter.aoi_id)					-- 攻击者aoi_id
		writeUInt(packet, targeter and targeter.aoi_id or 0) -- 受击者aoi_id
		writeUInt(packet, skillBase.id)						-- 技能id
		writeLong(packet, fighter.hp3 or 0)					-- 攻击者hp3值
		writeLong(packet, fighter.hp2 or 0)					-- 攻击者hp2值
		writeLong(packet, fighter.hp)						-- 攻击者hp值
		-- 攻击者加血信息
		local fighter_add_hp_num = sizeTable(arr_fighter_add_hp)
		writeByte(packet, fighter_add_hp_num)
		for i = 1, fighter_add_hp_num do
			writeByte(packet, arr_fighter_add_hp[i][1]) -- 血条索引
			writeInt(packet, arr_fighter_add_hp[i][2])  -- 变化的数值
		end
		
		writeCoord(packet, fighter_x)						-- 攻击者x坐标
		writeCoord(packet, fighter_y)						-- 攻击者y坐标
		writeLong(packet, fight_expire)						-- 技能本次攻击的结束时间

		local targeter_num = sizeTable(arr_targeter)
		local now_targeter, now_targeter_fight_info
		local arr_targeter_del_hp

		writeByte(packet, targeter_num)			-- 本次攻击的被攻击者人数
		-- 被攻击者信息
		for i = 1, targeter_num do
			now_targeter = arr_targeter[i]
			local now_targeter_tmps = now_targeter.tmps
			now_targeter_fight_info = now_targeter_tmps.fight_info
			arr_targeter_del_hp = now_targeter_fight_info.arr_targeter_del_hp -- 受击者扣血队列

			-- 受击者的二进制结构
			writeUInt(packet, now_targeter.aoi_id)					-- 受击者aoi_id
			writeCoord(packet, now_targeter.x)						-- 受击者x坐标
			writeCoord(packet, now_targeter.y)						-- 受击者y坐标
			writeByte(packet, now_targeter_fight_info.action_id)	-- 命中/闪避/暴击/格挡

			-- 免疫状态位
			local bits_for_refuse = 0
			local now_targeter_is_refuse_mabi = now_targeter_fight_info.is_refuse_mabi or 0 -- 麻痹免疫
			if 0 < now_targeter_is_refuse_mabi then
				bits_for_refuse = ext_set_bit(bits_for_refuse, 0, 1)
			end
			local now_targeter_is_refuse_yuanxuan = now_targeter_fight_info.is_refuse_yuanxuan or 0 -- 晕眩免疫
			if 0 < now_targeter_is_refuse_yuanxuan then
				bits_for_refuse = ext_set_bit(bits_for_refuse, 1, 1)
			end
			writeByte(packet, bits_for_refuse)

			writeLong(packet, now_targeter.hp3 or 0)				-- 受击者hp3值
			writeLong(packet, now_targeter.hp2 or 0)				-- 受击者hp2值
			writeLong(packet, now_targeter.hp)						-- 受击者hp值

			local targeter_del_hp_times = sizeTable(arr_targeter_del_hp)
			writeByte(packet, targeter_del_hp_times)	-- hp变化次数(连击数)
			for ii = 1, targeter_del_hp_times do
				writeByte(packet, arr_targeter_del_hp[ii][1]) -- 血条索引
				writeInt(packet, arr_targeter_del_hp[ii][2])  -- 变化的数值
			end

			-- 帮抵扣血的
			local arr_targeter_help_del_hp = now_targeter_fight_info.arr_targeter_help_del_hp -- 帮抵扣血的
			local targeter_help_del_hp_num = sizeTable(arr_targeter_help_del_hp)
			writeByte(packet, targeter_help_del_hp_num)
			for ii = 1, targeter_help_del_hp_num do
				writeByte(packet, arr_targeter_help_del_hp[ii][1]) -- 血条索引
				writeInt(packet, arr_targeter_help_del_hp[ii][2])  -- 变化的数值
			end

			-- 反击攻击者的
			local arr_targeter_del_fighter_hp = now_targeter_fight_info.arr_targeter_del_fighter_hp -- 反击攻击者的
			local targeter_del_fighter_hp_num = sizeTable(arr_targeter_del_fighter_hp)
			writeByte(packet, targeter_del_fighter_hp_num)
			for ii = 1, targeter_del_fighter_hp_num do
				writeByte(packet, arr_targeter_del_fighter_hp[ii][1]) -- 血条索引
				writeInt(packet, arr_targeter_del_fighter_hp[ii][2])  -- 变化的数值
			end

			if false and self:isMonster(fighter) then
				print("真实扣血。。。")
				table.dump(arr_targeter_del_hp, -1)
				print("有协助者。。。")
				table.dump(now_targeter_fight_info.arr_targeter_help_del_hp, -1)
				print("反击扣掉攻击者的血。。。")
				table.dump(now_targeter_fight_info.arr_targeter_del_fighter_hp, -1)
			end
		end
		
		-- 创建包
		local ret_pack = WorldPacket:newClientPacket(ret_opcode, nil, arr_bc_player_id)		--opCodes.M2C_FIGHT_FIGHT
		ret_pack:writeVer()	
		ret_pack:writeFastPacketRaw(packet)

		return ret_pack
	end


	-- 非攻击类的二进制包
	function FightService:buildNoAttackBinPacket(aoiScene, fighter, targeter, skill, arr_pos, fight_number_id)
		-- 广播给所有人(包含自己)
		local arr_bc_player_id = GameObjectService:getFovGPids(fighter, aoiScene)
		if not arr_bc_player_id then
			return nil
		end


		-- 没有位置
		if not arr_pos then
			-- 非攻击类的战斗响应
			arr_pos = self:getDefaultPos()
		end

		-- 默认0
		if not fight_number_id then
			fight_number_id = 0
		end

		WorldPacket:resetWritePacket(packet,opCodes.M2C_FIGHT_USE_NOT_ATTACK_SKILL)
		
		writeUInt(packet, fight_number_id)					-- 战斗编号
		writeUInt(packet, fighter.space_id)					-- 场景实例id
		writeCoord(packet, arr_pos.target_x)				-- 目标x
		writeCoord(packet, arr_pos.target_y)				-- 目标y
		writeUInt(packet, fighter.aoi_id)					-- 攻击者aoi_id
		writeUInt(packet, targeter and targeter.aoi_id or 0) -- 受击者aoi_id
		writeUInt(packet, skill.skill_base.id)				-- 技能id

		-- 创建包
		local ret_pack = WorldPacket:newClientPacket(opCodes.M2C_FIGHT_USE_NOT_ATTACK_SKILL, nil, arr_bc_player_id)
		ret_pack:writeVer()	
		ret_pack:writeFastPacketRaw(packet)

		return ret_pack
	end


	-- 闪避类技能的二进制包
	function FightService:buildDodgeBinPacket(aoiScene, fighter, targeter, skill, arr_pos, fight_number_id)
		-- 广播给所有人(包含自己)
		local arr_bc_player_id = GameObjectService:getFovGPids(fighter, aoiScene)
		if not arr_bc_player_id then
			return nil
		end

		-- 创建包
		-- 默认0
		if not fight_number_id then
			fight_number_id = 0
		end

		WorldPacket:resetWritePacket(packet,opCodes.M2C_FIGHT_USE_DODGE_SKILL)
		
		writeUInt(packet, fight_number_id)					-- 战斗编号
		writeUInt(packet, fighter.space_id)					-- 场景实例id
		writeCoord(packet, arr_pos.fighter_new_x)			-- 攻击者新位置x
		writeCoord(packet, arr_pos.fighter_new_y)			-- 攻击者新位置y
		writeUInt(packet, fighter.aoi_id)					-- 攻击者aoi_id
		writeUInt(packet, targeter.aoi_id)					-- 受击者aoi_id
		writeUInt(packet, skill.skill_base.id)				-- 技能id

		local ret_pack = WorldPacket:newClientPacket(opCodes.M2C_FIGHT_USE_DODGE_SKILL, nil, arr_bc_player_id)
		ret_pack:writeVer()	
		ret_pack:writeFastPacketRaw(packet)

		return ret_pack
	end
end


-- 返回战斗错误消息
do
	local packet = FastPacket()
	function FightService:fightError(fighter, error_id, fight_number_id, skill_id, fighter_aoi_id)
		local rsp_opcode = opCodes.M2C_FIGHT_FIGHT_ERROR

		WorldPacket:resetWritePacket(packet,opCodes.M2C_FIGHT_FIGHT_ERROR)
		
		
		writeUInt(packet, fighter_aoi_id or fighter.aoi_id) -- 这里的fighter_aoi_id 和 fighter.aoi_id 不一定是一致的，例如召唤出来的机器人与驱动它的玩家
		writeUInt(packet, error_id)
		writeUInt(packet, fight_number_id)
		writeUInt(packet, skill_id)
		
		local ret_pack = WorldPacket:newClientPacket(rsp_opcode, nil, fighter.gpid, 10)		--opCodes.M2C_FIGHT_FIGHT_ERROR
		ret_pack:writeVer()	
		ret_pack:writeFastPacketRaw(packet)
		
		WorldPacket:m2cSendPacket(ret_pack)
	end
end


do
	-- 替某个对象加血/减血(战斗，buffer系统都会用到)(注意 : 这个接口不会让对象因为流血而死亡，会留下最后1点血)
	-- object : 对象
	-- add_hp : 加/减血绝对值(正负数区分)
	-- add_hp_percent : 加/减血百分比(正负数区分)
	-- is_bc : 是否广播
	-- aoiScene : 场景实例
	-- return add_hp
	function FightService:addObjectHp(object, add_hp, add_hp_percent, is_bc, aoiScene)
		local add_hp = add_hp or 0

		-- 获取要加的血条信息
		local hp_index, hp_key, max_hp_key = self:getHpInfo(object)
		local max_hp = object[max_hp_key]
		local hp = object[hp_key]

		-------------------------- 血加减处理 --------------------------
		if 0 ~= add_hp_percent then -- 加百分比
			add_hp = add_hp + (max_hp * add_hp_percent)
		end
		if 0 ~= add_hp then -- 加绝对值
			hp = hp + add_hp
		end

		if hp > max_hp then
			hp = max_hp
		end
		if hp < 0 then
			hp = 0
		end

		if 'hp' == hp_key then -- 确保不会因为buffer而死亡
			if 0 == hp then
				hp = 1
			end
		end

		object[hp_key] = ceil(hp)

		-------------------------- 广播 --------------------------
		if is_bc then
			local arr_aoi_change_hp = {self:newObjChangeHp(object.aoi_id, hp_index, add_hp, hp)}
			self:sendObjsChangeHp(aoiScene, object, arr_aoi_change_hp)
		end

		return add_hp
	end


	-- 发送单个对象的hp更新包
	local rsp_opcode = opCodes.M2C_FIGHT_HARM
	local packet = FastPacket()
	-- 发送一批对象的hp更新值
	function FightService:sendObjsChangeHp(aoiScene, fighter, arr_aoi_change_hp, arr_gpid, is_zibao)
		local arr_gpid = arr_gpid or GameObjectService:getFovGPids(fighter, aoiScene)
		if not arr_gpid then
			return nil
		end

		WorldPacket:resetWritePacket(packet,opCodes.M2C_FIGHT_HARM)
		
		-- 包结构
		writeUInt(packet, fighter.aoi_id)
		writeByte(packet, fighter.aoi_type)
		local len = #arr_aoi_change_hp
		writeUShort(packet, len)
		for i = 1, len do
			local arr_info = arr_aoi_change_hp[i]
			writeUInt(packet, arr_info.aoi_id)	  -- aoi_id
			writeByte(packet, arr_info.hp_index)  -- 血条索引
			writeIntWithSignBit(packet, arr_info.change_hp)  -- 变化的血量
			writeLong(packet, arr_info.now_hp)	  -- 当前血量
			writeByte(packet, arr_info.action_id) -- 命中/闪避/暴击/格挡
		end
		
		local ret_pack = WorldPacket:newClientPacket(rsp_opcode, nil, arr_gpid, 40)--opCodes.M2C_FIGHT_HARM
		ret_pack:writeVer()	
		ret_pack:writeFastPacketRaw(packet)
		
		WorldPacket:m2cSendPacket(ret_pack)
	end


	-- 创建一个新的普通扣血对象
	-- aoi_id : aoi_id
	-- hp_index : 血条索引
	-- change_hp : 变化的血量
	-- now_hp : 当前血量
	-- action_id : 命中/闪避/暴击/格挡(默认普通命中)
	function FightService:newObjChangeHp(aoi_id, hp_index, change_hp, now_hp, action_id)
		local obj_change_hp = {}
		obj_change_hp.aoi_id = aoi_id
		obj_change_hp.hp_index = hp_index
		obj_change_hp.change_hp = change_hp
		obj_change_hp.now_hp = now_hp
		obj_change_hp.action_id = action_id or ResultTypeHit -- 默认是普通命中

		return obj_change_hp
	end
end


-- 获取战斗包索引
function FightService:genFightNumberId(fighter)
	local tmps = fighter.tmps
	local fight_number_id = tmps.fight_number_id or 0
	fight_number_id = fight_number_id + 1
	tmps.fight_number_id = fight_number_id
	return fight_number_id
end
------------------------------------------------------------ 战斗后响应包处理 end ------------------------------------------------------------


------------------------------------------------------------ 服务端触发战斗包 start ----------------------------------------------------------
do
-- 每帧触发战斗 CharacterService:update 里面调用进来的
	function FightService:serverFight(aoiScene, fighter)
		local time_now = Time.time_now -- 当前时间
		
		local fighter_tmps = fighter.tmps
		local fighter_fight_exipire = fighter_tmps.fight_expire or 0

		if fighter_fight_exipire > time_now then -- 战斗还没结束
			local arr_server_fight_skill = fighter_tmps.arr_server_fight_skill
			if arr_server_fight_skill then
				local next_play_time = arr_server_fight_skill.next_play_time	-- 可以触发的下一次时间
				if next_play_time < time_now then
					local skill_id = arr_server_fight_skill.skill_id or 0			-- 要触发的技能
					-- 触发战斗
					self:doServerFight(aoiScene, fighter, skill_id)

					-- 更新下一次触发事件
					local interval = arr_server_fight_skill.interval or 1000000		-- 要触发的技能间隔
					arr_server_fight_skill.next_play_time = arr_server_fight_skill.next_play_time + interval
				end

				return true
			end
		end

		-- 有任何错误，都取消掉自动战斗状态
		fighter.tmps.in_server_fight = FightDefs.FIGHT_IN_SERVER_GUIDE_SKILL_NO
	end


-- 服务器战斗
-- 如果技能是群攻的，可以不传targeter
	function FightService:doServerFight(aoiScene, fighter, skill_id, targeter)
		-- 获得技能信息
		local skill = self:getFighterSkill(fighter, skill_id)
		local targeter = targeter or nil
		local arr_pos = self:getDefaultPos()
		-- 记录攻击者攻击时候的位置(为了与陷阱攻击统一起来)
		arr_pos.fighter_attack_x = fighter.x
		arr_pos.fighter_attack_y = fighter.y

		-- 幻兽天赋
		self:initFighterPetTianFu(aoiScene, fighter)

		local keep_on, error_id, arr_targeter = self:doFight(aoiScene, fighter, targeter, arr_pos, skill)

		-- 攻击后逻辑处理
		self:doAfterFight(aoiScene, fighter, targeter, arr_targeter)

		-- 正确的响应
		local ret_packet = self:buildBinPacket(aoiScene, fighter, targeter, skill, arr_targeter, arr_pos, 0)
		if ret_packet then
			WorldPacket:m2cSendPacket(ret_packet)
		end
	end
end
------------------------------------------------------------ 服务端触发战斗包 end ------------------------------------------------------------


------------------------------------------------------------ 召唤技能逻辑 start --------------------------------------------------------------
do
	-- 召唤陷阱
	function FightService:callTraps(aoiScene, fighter, skill, arr_pos, fight_number_id)
		-- local
		local skillDetail = skill.skill_detail
		local arr_trap = skillDetail.traps
		local now_trap_id, now_trap_prob, now_trap_dest_type, target_x, target_y

		for _, now_trap_info in pairs(arr_trap) do
			now_trap_prob = now_trap_info.prob or 0 -- 触发概率

			if self:isBufferHit(now_trap_prob) then -- 成功触发
				now_trap_id   = now_trap_info.trap_id		 -- 陷阱id
				now_trap_dest_type = now_trap_info.dest_type -- 陷阱的出现位置类型(自身位置/指定位置)

				if SkillDefs.PLACE_TYPE_SELF == now_trap_dest_type then -- 自身位置
					target_x = fighter.x
					target_y = fighter.y
				else -- 指定的位置
					target_x = arr_pos.target_x
					target_y = arr_pos.target_y
				end

				local trap = TrapService:createTrap(aoiScene, now_trap_id, target_x, target_y, fighter)
			end
		end
	end


	-- 召唤召唤物
	function FightService:callBeast(aoiScene, fighter, skill, arr_pos, fight_number_id)
		-- local
		local skillDetail = skill.skill_detail
		local arr_beast = skillDetail.beasts
		local now_beast_id, now_beast_prob, now_beast_duration, target_x, target_y

		for _, now_beast_info in pairs(arr_beast) do
			now_beast_prob = now_beast_info.prob or 0 -- 触发概率

			if self:isBufferHit(now_beast_prob) then		-- 成功触发
				now_beast_id		= now_beast_info.beast_id	-- 召唤物id
				now_beast_duration	= now_beast_info.duration	-- 召唤物存活时间

				target_x = arr_pos.target_x
				target_y = arr_pos.target_y

				local beast, del_beast_aoi_id = BeastService:createBeast(aoiScene, now_beast_id, target_x, target_y, fighter, now_beast_duration)

				-- 删除掉旧的召唤物(召唤物存在互斥的情况，召唤一只新的，得删除掉一只旧的)
				if 0 < del_beast_aoi_id then
					local delBeast = GameObjectService:getGameObjectByAoiId(aoiScene, del_beast_aoi_id)
					if delBeast then
						-- 蝙蝠的删除等客户端来触发，这里只处理不会动的
						if 0 == delBeast.speed then
							-- 小蒋提供接口(要放在最后面，自爆之后)
							GameObjectService:delObjByAoiId(aoiScene, del_beast_aoi_id)
						end
					end
				end

				-- print("召唤了召唤兽了")
			end
		end
	end


	-- 执行自爆行为(只能用于召唤物/幻兽)
	function FightService:doZiBao(aoiScene, parent, fighter, radius, harm_num, harm, targeter)
		-- 获取可以伤害的列表
		local targeter_x = targeter and targeter.x or fighter.x
		local targeter_y = targeter and targeter.y or fighter.y
		local dest_type = self:getFightDestTypes(aoiScene, parent)
		local arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(fighter.aoi_obj, targeter_x, targeter_y, radius, dest_type)

		-- 过滤掉不能攻击的
		local arr_targeter, targeter_num = self:filterTargeter(aoiScene, parent, arr_aoiObj, aoiObj_num, harm_num)

		-- 存在可攻击对象
		local arr_aoi_change_hp = {}

		if 0 < targeter_num then
			for i = 1, targeter_num do
				local now_targeter = arr_targeter[i]
				self:doFight(aoiScene, parent, now_targeter, nil, nil, {now_targeter}, harm)
				TrapService:addToAoiChangeHp(arr_aoi_change_hp, now_targeter)
			end
		end

		-- 广播血量变化
		self:sendClientZiBao(aoiScene, fighter, targeter, arr_aoi_change_hp)

		-- 攻击后的统一处理
		if 0 < sizeTable(arr_targeter) then
			-- 攻击后逻辑处理(要放在攻击包/血量更新包后面，不然客户端会出错)
			self:doAfterFight(aoiScene, parent, nil, arr_targeter)
		end
	end


	-- 出战幻兽自爆
	function FightService:petZiBao(pet)
		-- 判断是否有天赋
		local parent = ChPetService:getParentGameObj(pet)
		local tf_radius, tf_harm_num, tf_harm_radix, tf_bianfu_add_harm_radix = self:getPetTianFuZiBao(parent)
		-- print('自爆天赋的值', tf_radius, tf_harm_num, tf_harm_radix, tf_bianfu_add_harm_radix)
		
		if 0 < tf_radius then
			local radius = tf_radius
			local harm_radix = tf_harm_radix
			local harm_num = tf_harm_num

			-- 自爆伤害值 = (最大攻击 + 最小攻击) / 2 * 自爆系数
			local harm = ceil((pet.max_attack + pet.min_attack) / 2 * harm_radix * (1 + 0))

			-- 执行自爆
			local aoiScene = GameObjectService:getAoiScene(parent)
			self:doZiBao(aoiScene, parent, pet, radius, harm_num, harm)
		end
	end
end


do
	-- 发送自爆的hp更新包
	local rsp_opcode = opCodes.M2C_FIGHT_CLIENT_ZI_BAO
	local packet = FastPacket()
	function FightService:sendClientZiBao(aoiScene, fighter, targeter, arr_aoi_change_hp, arr_gpid)
		local arr_gpid = arr_gpid or GameObjectService:getFovGPids(fighter, aoiScene)
		if not arr_gpid then
			return nil
		end

		WorldPacket:resetWritePacket(packet, rsp_opcode)
		
		-- 包结构
		writeUInt(packet, fighter.aoi_id)
		writeUInt(packet, targeter and targeter.aoi_id or 0)
		writeCoord(packet, targeter and targeter.x or fighter.x) -- 目标/自爆
		writeCoord(packet, targeter and targeter.y or fighter.y)
		local len = #arr_aoi_change_hp
		writeUShort(packet, len)
		for i = 1, len do
			local arr_info = arr_aoi_change_hp[i]
			writeUInt(packet, arr_info.aoi_id)	  -- aoi_id
			writeByte(packet, arr_info.hp_index)  -- 血条索引
			writeIntWithSignBit(packet, arr_info.change_hp)  -- 变化的血量
			writeLong(packet, arr_info.now_hp)	  -- 当前血量
			writeByte(packet, arr_info.action_id) -- 命中/闪避/暴击/格挡
		end
		
		local ret_pack = WorldPacket:newClientPacket(rsp_opcode, nil, arr_gpid, 40) -- opCodes.M2C_FIGHT_CLIENT_ZI_BAO
		ret_pack:writeVer()	
		ret_pack:writeFastPacketRaw(packet)
		
		WorldPacket:m2cSendPacket(ret_pack)
	end
end
------------------------------------------------------------ 召唤技能逻辑 end ----------------------------------------------------------------