--[[
战斗通知系统
author : suwin zhong
date : 2015-04-10
--]]

-- local 
local sizeTable = table.sizeTable
local inArray = array.in_array
local ceil = math.ceil
local random = math.random

FightHelperService = FightHelperService or {}

local SceneDefs = SceneDefs
local OutdoorService
local OutdoorBossService
local FightService
local G3v3Service
local TianmoService
local DaojianjueService
local GameObjectService
function FightHelperService:onAfterLoadLua()
	OutdoorService = _G.OutdoorService
	FightService = _G.FightService
	G3v3Service = _G.G3v3Service
	TianmoService = _G.TianmoService
	DaojianjueService = _G.DaojianjueService
	GameObjectService = _G.GameObjectService
	OutdoorBossService = _G.OutdoorBossService
end


do
	--------------------------------------------------------- 战斗通知其他模块 start ---------------------------------------------------------
	-- 战斗结果通知其他系统
	-- is_character_attack : 是否是角色攻击
	-- fighter : 攻击者(角色/怪物)
	-- arr_kill_character_aoi_id : 杀死的角色的aoi_id
	-- arr_character_harm : 玩家被伤害信息 hash = {character.aoi_id => harm}
	function FightHelperService:notifyModulesForKillCharacter(is_character_attack, fighter, arr_kill_character_aoi_id, arr_character_harm)
		-- 获取场景基本id
		local scene_id = self:getObjectSceneId(fighter)

		if 0 < sizeTable(arr_character_harm) then
			-- g3v3
			if G3v3Service and G3v3Service.onPlayerHarm and G3v3Service:isIn3v3(scene_id) then
				G3v3Service:onPlayerHarm(fighter, arr_character_harm, is_character_attack)
			end
		end

		if 0 < sizeTable(arr_kill_character_aoi_id) then
			-- 死亡通知(通用)
			self:bcDead(fighter, arr_kill_character_aoi_id)

			-- 野外
			if OutdoorService and OutdoorService.onPlayerKilled and OutdoorService:isInOutdoor(scene_id) then
				-- 国印提供接口
				OutdoorService:onPlayerKilled(fighter, arr_kill_character_aoi_id)
			end

			-- 野外BOSS
			if OutdoorBossService and OutdoorBossService.onPlayerKilled and OutdoorBossService:isInOutdoorBoss(scene_id) then
				-- 国印提供接口
				OutdoorBossService:onPlayerKilled(fighter, arr_kill_character_aoi_id)
			end


			-- g3v3
			if G3v3Service and G3v3Service.onPlayerKilled and G3v3Service:isIn3v3(scene_id) then
				-- 国印提供接口
				G3v3Service:onPlayerKilled(fighter, arr_kill_character_aoi_id)
			end
			
			-- 天魔(BOSS之家)
			if TianmoService and TianmoService:isTianmo(scene_id) then
				TianmoService:onPlayerKilled(fighter, arr_kill_character_aoi_id)
			end

			-- 刀剑绝(帝国争霸)
			if DaojianjueService and DaojianjueService:isInDaojj(scene_id) then
				DaojianjueService:onPlayerKilled(fighter, arr_kill_character_aoi_id)
			end
			
			-- 末日之战
            if FinalWarService and FinalWarService:isInFinalWar(scene_id) then
                FinalWarService:onPlayerKilled(fighter, arr_kill_character_aoi_id)
            end
			
			-- 军团战
			if GangBattleNewService and GangBattleNewService.isInGangBattle and GangBattleNewService:isInGangBattle(scene_id) then
				GangBattleNewService:onPlayerKilled( fighter, arr_kill_character_aoi_id )
			end

			-- 生存
			if ShengcunService:isInShengcun( scene_id ) then 
				ShengcunService:onPlayerKilled( fighter, arr_kill_character_aoi_id )
			end
			
			-- 杀人表现(连杀，首杀等)
			if WanfaKillService then
				WanfaKillService:onPlayerKilled(scene_id, fighter, arr_kill_character_aoi_id )
			end

			-- 小地图
			if SmallMapService and SmallMapService.onPlayerKilled then
				SmallMapService:onPlayerKilled( fighter, arr_kill_character_aoi_id )
			end
		end
		
		if 0 < sizeTable(arr_character_harm) then
			-- 野外
			if OutdoorService and OutdoorService:isInOutdoor(scene_id) then
				OutdoorService:onPlayerHarm(fighter, arr_character_harm)
			end

			-- 野外BOSS
			if OutdoorBossService and OutdoorBossService:isInOutdoorBoss(scene_id) then
				OutdoorBossService:onPlayerHarm(fighter, arr_character_harm)
			end			
		end
	end


	-- 战斗结果通知其他系统
	-- character : 角色
	-- arr_kill_monster_id : 杀死的怪物基础id数组
	-- arr_kill_monster_aoi_id : 杀死的怪物aoi_id数组
	-- arr_monster_harm : 怪物被伤害信息 hash = {monster.aoi_id => harm}
	function FightHelperService:notifyModulesForKillMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id, arr_monster_harm)
		-- 角色所在场景id
		local scene_id = self:getObjectSceneId(character)

		-- 伤害怪物
		if 0 < sizeTable(arr_monster_harm) then
			-- 野外(国印提供接口)
			if OutdoorService and OutdoorService.isInOutdoor and OutdoorService:isInOutdoor(scene_id) then
				OutdoorService:onMonsterHarm(character, arr_monster_harm)
			end

			-- 野外BOSS(国印提供接口)
			if OutdoorBossService and OutdoorBossService.isInOutdoorBoss and OutdoorBossService:isInOutdoorBoss(scene_id) then
				OutdoorBossService:onMonsterHarm(character, arr_monster_harm)
			end			
			
			-- BOSS之家
			if TianmoService:isTianmo(scene_id) then
				TianmoService:onMonsterHarm(character, arr_monster_harm)
			end
			
			-- 副本
			if SublineService:isSubline(scene_id) then
				SublineService:onMonsterHarm(character, arr_monster_harm)
			end
		end
		
		-- 杀死怪物
		if 0 < sizeTable(arr_kill_monster_aoi_id) then
			-- 死亡通知(通用)
			self:bcDead(character, arr_kill_monster_aoi_id)

			if OutdoorService and OutdoorService.isInOutdoor and OutdoorService:isInOutdoor(scene_id) then
				-- 野外(国印提供接口)
				OutdoorService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
			end

			if OutdoorBossService and OutdoorBossService.isInOutdoorBoss and OutdoorBossService:isInOutdoorBoss(scene_id) then
				-- 野外(国印提供接口)
				OutdoorBossService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
			end			
			
			-- 剧情系统
			ScenarioService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
			
			-- 小地图
			SmallMapService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
			
			-- BOSS之家
			if TianmoService:isTianmo(scene_id) then
				TianmoService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
			end
			
			-- 帝国（刀剑）
			if DaojianjueService:isInDaojj(scene_id) then 
				DaojianjueService:onKilledMonster( character, arr_kill_monster_id, arr_kill_monster_aoi_id )
			end

			-- 军团战
			if GangBattleNewService:isInGangBattle( scene_id )then 
				GangBattleNewService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
			end

			-- 生存
			if ShengcunService:isInShengcun( scene_id )then 
				ShengcunService:onKilledMonster( character, arr_kill_monster_id, arr_kill_monster_aoi_id )
			end

			-- 爱情圣殿
			if LoverTempleService:isInLoverTemple( scene_id )then 
				LoverTempleService:onKilledMonster( character, arr_kill_monster_id, arr_kill_monster_aoi_id )
			end

			-- 掉落系统
			DropItemsService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
		end
	end


	-- 战斗结果通知其他系统
	-- fighter : 攻击者(角色/怪物)
	-- arr_kill_guard_npc_aoi_id : 杀死的守护npc的aoi_id数组
	function FightHelperService:notifyModulesForKillGuardNpc(fighter, arr_kill_guard_npc_aoi_id)
		if 0 < sizeTable(arr_kill_guard_npc_aoi_id) then
			-- 野外
			if OutdoorService and OutdoorService.onNpcKilled then
				-- 警告：onNpcKilled 事件里面不能进行怪物的添加、删除操作
				-- 国印提供接口
				OutdoorService:onNpcKilled(fighter, arr_kill_guard_npc_aoi_id)
			end
		end
	end


	-- 获取对象的基础场景id
	-- object : 暂时只支持角色和怪物
	function FightHelperService:getObjectSceneId(object)
		local scene_id = 0

		if FightService:isMonster(object) then
			scene_id = object.monster_aoi.scene_id
		else
			scene_id = object.scene_id or 0
		end

		if 0 == scene_id then
			error("FightHelperService:getObjectSceneId 对象身上没有scene_id 字段")
		end

		return scene_id
	end


	-- 广播死亡
	-- fighter : 攻击者
	-- arr_dead_aoi_id : 死亡的aoi_id数组
	local MONSTER_SORT_ID_FOR_BOSS = MonsterDefs.MONSTER_SORT_ID_FOR_BOSS
	local MONSTER_SORT_ID_FOR_WORLD_BOSS = MonsterDefs.MONSTER_SORT_ID_FOR_WORLD_BOSS
	function FightHelperService:bcDead(fighter, arr_dead_aoi_id)
		-- 广播通知死亡接口(通用)
		local aoiScene = GameObjectService:getAoiScene(fighter)
		for _, now_dead_aoi_id in pairs(arr_dead_aoi_id) do
			local deadObject = GameObjectService:getGameObjectByAoiId(aoiScene, now_dead_aoi_id)

			-- 只广播角色和BOSS的死亡
			local monster_sort_id = deadObject.monster_base and deadObject.monster_base.monster_sort_id
			if not monster_sort_id or monster_sort_id == MONSTER_SORT_ID_FOR_BOSS or monster_sort_id == MONSTER_SORT_ID_FOR_WORLD_BOSS  then
				local arr_pid = GameObjectService:getFovGPids(deadObject)
				GameObjectService:sendDead(aoiScene, deadObject, arr_pid)
			end
		end
	end


	-- 角色死亡逻辑处理(用于特殊逻辑的)
	-- character : 死亡的角色
	function FightHelperService:onCharacterDead(character)
		-- 如果是机器人，则调用机器人接口处理死亡逻辑
		if FightService:isRobot(character) then
			SceneRobotService:onFightDead(character)
		end
		
		local scene_base = SceneBaseService:getSceneBaseById(character.scene_id)
		local scene_sort_id = scene_base.scene_sort_id
		if scene_sort_id ==  SceneDefs.SCENE_SORT_ID_FINALWAR or
			scene_sort_id ==  SceneDefs.SCENE_SORT_ID_OUTDOOR or
			scene_sort_id ==  SceneDefs.SCENE_SORT_ID_OUTDOOR_BOSS
			then
			if scene_sort_id ==  SceneDefs.SCENE_SORT_ID_FINALWAR then FinalWarService:addIsBianShen(character) end
			BufferService:clearDeBuffer(character)
		end
	end
	--------------------------------------------------------- 战斗通知其他模块 end -----------------------------------------------------------
end


do
	-- 扣1.5倍伤害的怪物id数组
	local arr_monster_base_id_for_15_lost_hp = {92002, 92012, 92022, 92032, 92042, 92052, 92062, 92072, 92082, 92092, 920102}

	-- 是否是已知扣血数的对象
	-- fighter : 攻击者
	-- targeter : 被攻击者
	-- return lost_hp
	function FightHelperService:isKnownLostHpObject(fighter, targeter)
		-- 要扣的血
		local lost_hp = 0

		-- 守护npc
		if FightService:isGuardNpc(targeter) then
			-- 固定扣血值
			lost_hp = targeter.guard_npc_base.attacked_lost_hp or 1

			if FightService:isMonster(fighter) then
				local monster_base_id = fighter.monster_base.id
				if inArray(monster_base_id, arr_monster_base_id_for_15_lost_hp) then
					lost_hp = ceil(lost_hp * 1.5)
				end
			end

			return lost_hp
		end

		-- 怪物
		if FightService:isMonster(targeter) then
			-- 判断是不是固定扣血的
			local monsterBase = targeter.monster_base
			local min_lost_hp = monsterBase.min_lost_hp or 0
			local max_lost_hp = monsterBase.max_lost_hp or 0
			if (0 < min_lost_hp) or (0 < max_lost_hp) then
				if min_lost_hp == max_lost_hp then
					-- 固定扣血
					lost_hp = min_lost_hp
				else
					-- 随机扣血
					lost_hp = random(min_lost_hp, max_lost_hp)
				end

				return lost_hp
			end
		end

		-- 攻击者
		if FightService:isMonster(fighter) then
			-- 判断是不是固定扣血的
			local attack_lost_hp_perc = fighter.monster_base.attack_lost_hp_perc or 0
			if (0 < attack_lost_hp_perc) then
				local total_max_hp = targeter.max_hp + (targeter.max_hp2 or 0) + (targeter.max_hp3 or 0)
				lost_hp = ceil(total_max_hp * attack_lost_hp_perc / 100)

				return lost_hp
			end
		end

		return lost_hp
	end
end


do
	-- 获取丧尸危机的扣血值
	function FightHelperService:getShengCunLostHp(fighter, targeter)
		local lost_hp = 0

		-- 丧尸危机(返回扣血百分比，国印提供接口)
		local lost_hp_perc = ShengcunService:getDelHpPerc(fighter, targeter) -- 返回格式 0.03 == 百分之三
		if 0 < lost_hp_perc then
			if FightService:isCharacter(targeter) then -- 角色
				-- 丧尸危机里每个角色只有一管血
				lost_hp = ceil(targeter.max_hp * lost_hp_perc)

			elseif FightService:isMonster(targeter) then
				-- 丧尸/精英丧尸
				local monsterBase = targeter.monster_base
				lost_hp = ceil(monsterBase.max_hp * lost_hp_perc)

			else
				print("丧尸危机里不应该出现角色和怪物外的其他对象")
			end
		end

		return lost_hp
	end
end