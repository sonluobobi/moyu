--[[
玩法通用逻辑系统servuce
author : xingzeng
date : 2014-08-15
]]--

local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local type = type
local opCodes = opCodes
local string_len = string.len
local math_random = math.random
local GameObjectService
local math_ceil = math.ceil
local SceneDefs = SceneDefs
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local wanfa_aoi_data_scene_sorts_ht = SceneDefs.wanfa_aoi_data_scene_sorts_ht

WanfaAoiService = WanfaAoiService or {}


function WanfaAoiService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
end

-- 进入场景后
function WanfaAoiService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	local scene_base = aoi_scene.scene_base
	if not self:isSupport(scene_base.scene_sort_id) then
		return
	end
	
	-- 初始化玩法AOI数据
	self:initWanfaAoiData(character, aoi_scene)
	
	local aoi_obj = character.aoi_obj
	
	--[[if aoi_obj.wanfa_aoiobj_data then
		-- 把自己视野内的对象玩法AOI数据发给自己
		local aoi_objs = aoi_scene:getFovObjs(character.aoi_obj, 0)
		self:sendWanfaAoiDatas(aoi_scene, aoi_objs, character.gpid)
		
		-- 把自己广播给其他人
		local gpids = GameObjectService:getGPids(aoi_scene, character.gpid)
		self:sendWanfaAoiData(aoi_scene, character.aoi_obj, gpids)
	end--]]
end

local _wanfa_aoi_data_init_map = nil
function WanfaAoiService:initWanfaAoiData(character, aoi_scene)
	if not _wanfa_aoi_data_init_map then
		_wanfa_aoi_data_init_map = {
			[SceneDefs.SCENE_SORT_ID_3V3] = { G3v3Service, 'initWanfaAoiData' },
			[SceneDefs.SCENE_SORT_ID_OUTDOOR] = { OutdoorService, 'initWanfaAoiData' },
			[SceneDefs.SCENE_SORT_ID_OUTDOOR_BOSS] = { OutdoorBossService, 'initWanfaAoiData' },
			[SceneDefs.SCENE_SORT_ID_GANG_BATTLE] = { GangBattleNewService, 'initWanfaAoiData' },
			[SceneDefs.SCENE_SORT_ID_SHENGCUN_WAR] = { ShengcunService, 'initWanfaAoiData' },
		}
	end
	
	local sort_id = aoi_scene.scene_base.scene_sort_id
	local arr = _wanfa_aoi_data_init_map[sort_id]
	if not arr then 
		return
	end
	local service, handle_name = arr[1], arr[2]
	local handle = service[handle_name]
	if handle then
		handle(service, character, aoi_scene)
	end
end

function WanfaAoiService:createWanfaAoiData(game_obj)
	if game_obj.aoi_type ~= aoi_type_player then
		return
	end
	
	local aoi_obj = game_obj.aoi_obj
	local wanfa_aoiobj_data = {aoi_id = aoi_obj.obj_id}
	aoi_obj.wanfa_aoiobj_data = wanfa_aoiobj_data
end

function WanfaAoiService:setWanfaAoiData(game_obj, key, value, is_send)
	local aoi_scene = GameObjectService:getAoiScene(game_obj)
	if not self:isSupport(aoi_scene.scene_base.scene_sort_id) then
		return
	end
	
	local aoi_obj = game_obj.aoi_obj
	local wanfa_aoiobj_data = assert(aoi_obj.wanfa_aoiobj_data, game_obj.aoi_id)
	
	-- 检查KEY
	if not WanfaAoiObjData[key] then
		Logger:fatal('[WanfaAoiService:setWanfaAoiData] key is not exist', key, value)
	end
	
	wanfa_aoiobj_data[key] = value
	wanfa_aoiobj_data.update_mtime = Time.time_now
	
	-- 全场景广播
	if is_send then
		local gpids = GameObjectService:getGPids(aoi_scene)
		local wanfa_aoiobj_data2 = {aoi_id = aoi_obj.obj_id, [key] = wanfa_aoiobj_data[key]}
		self:sendWanfaAoiDataUp(aoi_scene, wanfa_aoiobj_data2, gpids)
	end
end

-- 是否为支持的玩法场景
function WanfaAoiService:isSupport(scene_sort_id)
	return wanfa_aoi_data_scene_sorts_ht[scene_sort_id] and true or false
end

-- RSP玩法AOI数据更新
do
	local rsp_opcode = opCodes.M2C_SCENE_WANFA_AOI_DATA_UPDATE
	local msg_name = "PackAoi.M2C_SCENE_WANFA_AOI_DATA_UPDATE"
	local msg_proto = {}
	local up_aoi_objs = {}
	function WanfaAoiService:sendWanfaAoiDataUp(aoi_scene, wanfa_aoiobj_data, gpids)
		if not self:isSupport(aoi_scene.scene_base.scene_sort_id) then
			return
		end
		
		if wanfa_aoiobj_data then
			up_aoi_objs[1] = wanfa_aoiobj_data
			msg_proto.aoi_objs = up_aoi_objs
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
		end
	end
end


-- RSP玩法AOI数据
do
	local rsp_opcode = opCodes.M2C_SCENE_WANFA_AOI_DATA_GET
	local msg_name = "PackAoi.M2C_SCENE_WANFA_AOI_DATA_GET"
	local msg_proto = {}
	function WanfaAoiService:sendWanfaAoiDatas(aoi_scene, aoi_objs, gpids)
		if not self:isSupport(aoi_scene.scene_base.scene_sort_id) then
			if type(gpids) == 'number' then WorldPacket:m2cSendCommEmpty(gpids) end
			return
		end
		
		local wanfa_aoi_objs = {}
		for _, aoi_obj in pairs(aoi_objs) do
			if aoi_obj.wanfa_aoiobj_data then
				wanfa_aoi_objs[#wanfa_aoi_objs+1] = aoi_obj.wanfa_aoiobj_data
			end
		end
		
		if #wanfa_aoi_objs > 0 then
			msg_proto.aoi_objs = wanfa_aoi_objs
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
		end
	end
	
	local msg_proto2 = {}
	function WanfaAoiService:sendWanfaAoiData(aoi_scene, aoi_obj, gpids)
		if not self:isSupport(aoi_scene.scene_base.scene_sort_id) then
			return
		end
		
		if aoi_obj.wanfa_aoiobj_data and gpids and next(gpids) then
			msg_proto2.aoi_objs = {aoi_obj.wanfa_aoiobj_data}
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto2, nil, gpids)
		end
	end
end

