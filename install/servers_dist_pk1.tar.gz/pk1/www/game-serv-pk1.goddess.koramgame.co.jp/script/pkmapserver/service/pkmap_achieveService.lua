--[[
成就系统Service，用于数据加工，逻辑处理
author : guoyin.huang
date : 2016-03-29
]]--
AchieveService = AchieveService or {}

function AchieveService:init( character, is_login )
	local achieves = character.achieves
	if not achieves or type(achieves) == 'string' and string.len(achieves) > 3 then 
		achieves = WorldPacket:decodeData(achieves)
	else
		achieves = nil
	end
	
	achieves = self:new(achieves)

	character.achieves = achieves
end


function AchieveService:new( o )
	o = o or {}
	o.achieve = o.achieve or {}
	o.cnt = o.cnt or {}
	return o
end

-- 打包
function AchieveService:pack(character)
	return WorldPacket:encodeData(character.achieves)
end

function AchieveService:onCheckAchieve( character, achieve_type, now_value )
	if not character.tmps_ex then return end

	if not AchieveDefs:isNeedCheckAchieve() then 
		return 
	end	
	local achieve_list = TargetBaseDao:getAchieveListBySortId( achieve_type )
	if not achieve_list then return end
	
	local achieve = character.achieves.achieve
	local is_send = false
	for _, achieve_base in pairs(achieve_list) do
		local achieve_id = achieve_base.id
		if not achieve[achieve_id] then 
			is_send = true
		end
	end

	-- 只要当前类型尚有未完成的，发送到游戏服
	if is_send then 
		local data = {}
		data.achieve_type = achieve_type
		data.now_value = now_value
		WorldPacket:pkServer2GameSendPack(opCodes.PKM2M_ACHIEVE_UPDATE,character.gpid, data)
	end
end
