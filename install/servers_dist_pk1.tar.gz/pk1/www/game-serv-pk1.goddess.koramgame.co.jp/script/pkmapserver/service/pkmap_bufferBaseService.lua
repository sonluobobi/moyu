--[[
基础BUFFER系统servuce
author : xingzeng
date : 2012-03-27
]]--

local external = external
local table = table

BufferBaseService = BufferBaseService or {}

local BufferBaseDao = BufferBaseDao

-------------------------------- GET类函数 start ------------------------------
-- 根据id获取BUFFER基础数据
-- buffer_baseid : BUFFER_id
-- return obj / nil
function BufferBaseService:getBufferBaseById(buffer_baseid)
	return BufferBaseDao[buffer_baseid]
end

-- 获取一批buffer基本信息  (注意：返回的是一个临时TABLE)
-- arr_buffer_baseid : BUFFER_id数组
-- return array:table
function BufferBaseService:getBufferBaseByIds(arr_buffer_baseid)
   if not arr_buffer_baseid then return end
	local arr_buffer = {}
	for _, buffer_baseid in pairs(arr_buffer_baseid) do
		if table.isTable(BufferBaseDao[buffer_baseid]) then
			arr_buffer[#arr_buffer+1] = BufferBaseDao[buffer_baseid]
		end
	end
	return arr_buffer
end

-- 根据技能等级获取技能BFFER(技能BUFFER的VALUE是公式，这里会计算出公式的值)
function BufferBaseService:getSkillBufferByLev(buffer_baseid, skill_level)
	
end
-------------------------------- GET类函数 end ------------------------------

-- 是否瞬发的BUFFER
function BufferBaseService:isInstantBuffer(buffer_baseid, buffer_base)
	local buffer_base = buffer_base or self:getBufferBaseById(buffer_baseid)
	
	return buffer_base.duration == 0
end
-------------------------------- 打包函数 start ------------------------------

-------------------------------- 打包函数 end ------------------------------
