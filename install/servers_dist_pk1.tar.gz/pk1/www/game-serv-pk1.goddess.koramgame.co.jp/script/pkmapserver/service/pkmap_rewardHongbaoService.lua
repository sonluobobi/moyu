--[[
抽红包奖励系统servuce
author : xingzeng
date : 2014-08-15
]]--

local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local type = type
local opCodes = opCodes
local string_len = string.len
local math_random = math.random
local math_ceil = math.ceil
local RewardHongbaoDao = RewardHongbaoDao
local table_remove = table.remove

RewardHongbaoService = RewardHongbaoService or {}

local GameObjectService

function RewardHongbaoService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
end

-- 随机生成个玩家的红包点数,并发奖
function RewardHongbaoService:genHongbaos(aoi_scene, gpids, equip_id, equip_num, hongbao_num, reward_module_id)
	local jie_id = RewardHongbaoService:genJieId()
	local hongbao_acts = RewardHongbaoDao.hongbao_acts
	local reward_hongbaos = {
			jie_id = jie_id,
			equip_id = equip_id,
			equip_num = equip_num,
			hongbao_num = hongbao_num,
			reward_module_id = reward_module_id,
			gpids = gpids,
			hongbaos = nil,
			en_chou_idxs = nil,
			rob_stime = Time:getTimeNow() + 5000,
			choued_gcids = {},
			best_value = 0,	--手气最佳的红包数（add by guoyin)
		}
	hongbao_acts[jie_id] = reward_hongbaos
	
	local en_chou_idxs = {}
	for i = 1, hongbao_num do
		en_chou_idxs[i] = i
	end
	reward_hongbaos.hongbaos = self:randomHongbaos(equip_id, equip_num, hongbao_num)
	reward_hongbaos.en_chou_idxs = en_chou_idxs

	-- 手气最佳的值
	local best_value = 0
	for _, num in pairs(reward_hongbaos.hongbaos) do
		if num > best_value then best_value = num end
	end	
	reward_hongbaos.best_value = best_value

	-- BC
	self:bcHongbaoInfo(aoi_scene, reward_hongbaos)
end

-- 随机出各份红包
function RewardHongbaoService:randomHongbaos(equip_id, equip_num, hongbao_num)
	assert(equip_num >= hongbao_num, equip_id)
	
	local hongbaos = {}
	
	-- 初始每份1个
	for i = 1, hongbao_num do
		hongbaos[i] = 1
	end
	
	local leave_equip_num = equip_num - hongbao_num
	local rate
	local j = 0
	
	while leave_equip_num > 0 do
		local max_num = math_ceil((4/10) * leave_equip_num)
		local num = math_random(1, max_num)
		assert(num <= leave_equip_num)
		
		j = j + 1
		if j > hongbao_num then j = math_ceil(hongbao_num/2) end
		hongbaos[j] = hongbaos[j] + num
		leave_equip_num = leave_equip_num - num
	end
	
	return hongbaos
end

-- 抽红包
function RewardHongbaoService:chouHongbao(character, jie_id)
	local reward_hongbaos = RewardHongbaoDao.hongbao_acts[jie_id]
	if not reward_hongbaos then
		Logger:error('[RewardHongbaoService:chouHongbao] The reward_hongbaos is nil. ', jie_id, RewardHongbaoDao.max_jie_id, character.id, character.nick, character.scene_id, g_mapserver_id)
	end
	local en_chou_idxs = reward_hongbaos.en_chou_idxs
	local leave_hongbao_num = #en_chou_idxs
	if leave_hongbao_num == 0 then
		return false, errorCodes.REWARD_HONGBAO_CHOU_FINISH
	end
	
	if Time:getTimeNow() < reward_hongbaos.rob_stime - 500 then
		return false, errorCodes.REWARD_HONGBAO_CHOU_NO_START
	end
	
	if reward_hongbaos.choued_gcids[character.gcid] then
		return false, errorCodes.REWARD_HONGBAO_CHOUED
	end
	
	local idx = math_random(1, leave_hongbao_num)
	local hongbao_idx = en_chou_idxs[idx]
	
	table_remove(en_chou_idxs, idx)
	
	local hongbaos = reward_hongbaos.hongbaos
	local hongbao = hongbaos[hongbao_idx]
	local reward_equips = {[reward_hongbaos.equip_id]=hongbao}
	
	-- 发放奖励
	local arr_datas = {reward_equips = reward_equips, reward_module_id = reward_hongbaos.reward_module_id}
	-- 记录是否手气最佳
	arr_datas.is_best = reward_hongbaos.best_value == hongbao

	RewardService:reward(Statics.PK_GAME_TYPE_ID_REWARD_HONGBAO, 0, character.gpid, character.gcid, arr_datas)
	
	-- 记录已抽
	reward_hongbaos.choued_gcids[character.gcid] = 1
	
	self:bcHongbaoChou(character, reward_hongbaos, hongbao)
	
	if hongbao > 100 then
		AchieveService:onCheckAchieve(character, AchieveDefs.ACHIEVE_SORT_ID_DO_HONGBGAO_300, hongbao)
	end
	if hongbao >= 100 then
		ScorePopupService:openScorePopup(character, ScorePopupDefs.SCOREPOPUP_NODE_LINWEI)
	end
end



-- 获取届ID
function RewardHongbaoService:genJieId()
	RewardHongbaoDao.max_jie_id = RewardHongbaoDao.max_jie_id + 1
	return RewardHongbaoDao.max_jie_id
end

-- 红包奖励信息 (广播)
do
	local rsp_opcode = opCodes.M2C_REWARD_HONGBAO_INFO
	local msg_name = "PackRewardHongbao.M2C_REWARD_HONGBAO_INFO"
	local msg_proto = {}
	function RewardHongbaoService:bcHongbaoInfo(aoi_scene, reward_hongbaos)
		msg_proto.jie_id = reward_hongbaos.jie_id
		msg_proto.total_num = reward_hongbaos.hongbao_num
		msg_proto.equip_id = reward_hongbaos.equip_id
		msg_proto.total_equip_num = reward_hongbaos.equip_num
		msg_proto.rob_stime = reward_hongbaos.rob_stime
		
		local gpids = reward_hongbaos.gpids or GameObjectService:getGPids(aoi_scene)
		if #gpids > 0 then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
		end
	end
end

-- 广播XX抽中了红包 (广播)
do
	local rsp_opcode = opCodes.M2C_REWARD_HONGBAO_FETCH
	local msg_name = "PackRewardHongbao.M2C_REWARD_HONGBAO_FETCH"
	local msg_proto = {}
	function RewardHongbaoService:bcHongbaoChou(character, reward_hongbaos, hongbao_num)
		msg_proto.jie_id = reward_hongbaos.jie_id
		msg_proto.gcid = character.gcid
		msg_proto.nick = character.nick
		msg_proto.equip_id = reward_hongbaos.equip_id
		msg_proto.equip_num = hongbao_num
		local gpids = reward_hongbaos.gpids or GameObjectService:getGPids(aoi_scene)
		if #gpids > 0 then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
		end
	end
end