--[[
活动时间 
author : guoyin.huang
date : 2015-01-05
]]--



ActiveService = ActiveService or {}


-- 添加参与本服玩法的信息
local game_type_id_2_title = {
	[Statics.PK_GAME_TYPE_ID_DAOJJ] = '帝国争锋',
	[Statics.PK_GAME_TYPE_ID_GANG_BATTLE] = '军团战',
}
function ActiveService:addJoinGameInfo( character, game_type_id, child_game_type_id )
	if game_type_id_2_title[game_type_id] then 
		local data = {}
		data.cid = character.id
		data.game_type_id = game_type_id
		data.child_game_type_id = child_game_type_id or 0
		data.game_title = game_type_id_2_title[game_type_id]
		data.child_game_title = ''
		data.play_start_time = '00:00:00'
		data.area_id = character.area_id
		ServerCall:m2dCall('StatActiveService:m2d_addLog', nil, data)
	end
end
-------------------------------- 玩法参与统计 【END】 -----------------------
-- base同步过来的时间数据
function ActiveService:b2m_sycnActiveInfo(_, data )
	ActiveDao.gametypeid_2_activetime = data.gametypeid_2_activetime
	ActiveDao.game_active_time = data.game_active_time
end

-- 获取玩法的时间
function ActiveService:getActiveTime( game_type_id )
	local gametypeid_2_activetime = ActiveDao.gametypeid_2_activetime
	local active_time_obj = gametypeid_2_activetime[game_type_id]
	return active_time_obj
end

