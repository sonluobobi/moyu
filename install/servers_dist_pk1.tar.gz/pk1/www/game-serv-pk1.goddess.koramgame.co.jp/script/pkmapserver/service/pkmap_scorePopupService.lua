--[[
商店评分弹窗 Service
author : jianzhu
date : 2016-10-19
--]]

ScorePopupService = ScorePopupService or {}

--判断是否开启
function ScorePopupService:checkOpen(level)
	local ID_2_VALUE = OpenFuncDefs.ID_2_VALUE or {}
	local open_func_id = OpenFuncDefs.ID_FOR_SCORE or nil
	local value = 0
	local is_open = false

	if open_func_id and ID_2_VALUE[open_func_id] then value = ID_2_VALUE[open_func_id] end

	if value == ScorePopupDefs.POPUP_OPEN_VALUE then is_open = true end
	if Language:isTestServ() then is_open = true end

	return is_open,value
end

--其他玩法接口，直接调用评分弹窗  node 玩法达成节点，定义参考 ScorePopupDefs中 SCOREPOPUP_NODE_
function ScorePopupService:openScorePopup(character, node)
	--检查功能是否开启
	local level = character and character.level or 0
	local is_open, open_min_level = self:checkOpen(level)

	if not is_open or not node then return end

	--下发数据包，给客户端
	--客户端回包
	local msg_proto = {}
	msg_proto.node = node

	self:sendOpenPopupToClient(character, msg_proto)

	--测试代码
	--local tmp_str = "node【" .. node  .. "】open score popup -- pkmap"
	--WorldPacket:m2cSendErr(nil, nil, character.gpid, errorCodes.COMMON_ERROR_DIY, {[1] = tmp_str})
end

do	-- 条件达成，下发弹窗协议
	local rsp_opcode = opCodes.B2C_SCOREPOPUP_NODE_TRIGGER
	local msg_name = "PackScorePopup.B2C_SCOREPOPUP_NODE_TRIGGER"
	function ScorePopupService:sendOpenPopupToClient(character, data)
		local msg_proto = data or {}
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end
