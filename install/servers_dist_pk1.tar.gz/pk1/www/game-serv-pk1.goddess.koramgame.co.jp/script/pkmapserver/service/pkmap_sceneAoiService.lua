--[[
场景实例初的对象初始化 SERVICE
author : xingzeng.jiang
date : 2014-07-15
--]]


SceneAoiService = SceneAoiService or {}

local SceneAoiDao = SceneAoiDao
local AoiObjs = SceneAoiObjsDao
local SceneDefs  = SceneDefs
local AoiObjectType = AoiObjectType
local math_random = math.random
local SceneAoiDao_data = SceneAoiDao.data

function SceneAoiService:getInitObjs(scene_id)
	return SceneAoiDao_data[scene_id]
end


function SceneAoiService:getInitObjsByType(scene_id,aoi_type)
	local type_objs = SceneAoiDao_data[scene_id]	
	return type_objs and type_objs[aoi_type]
end


function SceneAoiService:getInitObjsById(id)
	return AoiObjs[id]
end

--- 获取某一波怪物
-- @return table:[SceneAoi]
function SceneAoiService:getSceneAoisByPhaseId(scene_id, aoi_type, phase_id)
	local arr_scene_aoi = {}
	local objs = SceneAoiDao_data[scene_id][aoi_type]
	for id, obj in pairs(objs) do
		if obj.phase_id == phase_id then
			arr_scene_aoi[#arr_scene_aoi+1] = obj
		end
	end
	return arr_scene_aoi
end

--- 根据 base_id 查找场景内的对象
-- @return [SceneAoi]
function SceneAoiService:findObjectsByBaseId( scene_id, aoi_type, base_id )
	local data = {}
	local objs = SceneAoiDao_data[scene_id][aoi_type]
	for id,obj in pairs(objs) do
		if obj.class_id == base_id then
			data[#data+1] = obj
		end
	end
	return data
end

do
	local TRANSFER_SORT_ID_IN_RELIVE = TransferDotDefs.TRANSFER_SORT_ID_IN_RELIVE
	local TRANSFER_SORT_ID_IN_NORMAL = TransferDotDefs.TRANSFER_SORT_ID_IN_NORMAL
	local AOI_OBJECT_TYPE_ID_TRANSMIT = AoiObjectType.AOI_OBJECT_TYPE_ID_TRANSMIT
	local TransferDotBaseDao = TransferDotBaseDao
	
	--- 获取特定类型的传送点
	-- @return array:SceneAoi, n
	local _tmp_get_transfers_for_sort_id_arr = {}
	function SceneAoiService:getTransfersForSortId(scene_id, transfer_sort_id)
		local all_transferbase = TransferDotBaseDao.sort_id2entity[transfer_sort_id]
		local all_transfer = SceneAoiDao_data[scene_id][AOI_OBJECT_TYPE_ID_TRANSMIT]
		local arr, n = _tmp_get_transfers_for_sort_id_arr, 0
		for _,sceneaoi in pairs(all_transfer) do
			local transferdotbase = all_transferbase[sceneaoi.class_id]
			if transferdotbase and transferdotbase.sort_id == transfer_sort_id then
				n = n + 1
				arr[n] = sceneaoi
			end
		end
		return arr, n
	end
	
	--- 随机一个特定类型的传送点
	-- @return SceneAoi/nil
	function SceneAoiService:getRandomTransferForSortId(scene_id, transfer_sort_id)
		local arr, n = self:getTransfersForSortId(scene_id, transfer_sort_id)
		if n == 1 then return arr[1] end
		if n > 0 then
			local i = math_random(1, n)
			return arr[i]
		end
	end

	--- 随机一个普通传入点
	-- @return SceneAoi/nil
	function SceneAoiService:getRandomTransferInForNormal(scene_id)
		local sceneaoi = self:getRandomTransferForSortId(scene_id, TRANSFER_SORT_ID_IN_NORMAL)
		return sceneaoi.x, sceneaoi.y, sceneaoi
	end
	
	
	--- 随机一个复活点
	-- @return SceneAoi/nil
	function SceneAoiService:getRandomTransferInForRelife( scene_id )
		return self:getRandomTransferForSortId( scene_id, TRANSFER_SORT_ID_IN_RELIVE )
	end
	
	--- 根据传入点基础ID 随机一个传入点
	-- @return SceneAoi/nil
	function SceneAoiService:getRandomTransferIn( scene_id, transfer_base_id )
		local arr = self:findObjectsByBaseId( scene_id, AOI_OBJECT_TYPE_ID_TRANSMIT, transfer_base_id )
		if arr and #arr > 0 then
			local sceneaoi = arr[math.random(1, #arr)]
			return sceneaoi.x, sceneaoi.y, sceneaoi
		end
	end
		
	--- 根据复活点基础ID 随机一个复活点
	-- @return SceneAoi/nil
	function SceneAoiService:getRandomReliveByBaseId( scene_id, transfer_base_id )
		local arr = self:findObjectsByBaseId( scene_id, TRANSFER_SORT_ID_IN_RELIVE, transfer_base_id )
		if arr and #arr > 0 then
			local sceneaoi = arr[math.random(1, #arr)]
			return sceneaoi.x, sceneaoi.y, sceneaoi
		end
	end
end

-- 生成 动态的SceneAoi对象的实例id
function SceneAoiService:genDySceneAoiInsId()
	local next_dy_sceneaoi_id = SceneAoiDao.next_dy_sceneaoi_id
	next_dy_sceneaoi_id = next_dy_sceneaoi_id + 1
	SceneAoiDao.next_dy_sceneaoi_id = next_dy_sceneaoi_id
	return next_dy_sceneaoi_id
end

