--[[
跨服通用逻辑
author : suwin zhong
date : 2015-04-01
--]]

PkServerService = PkServerService or {}

-- 跨服PK信息字段打包
function PkServerService:init(character) 
	local global_pk = character.global_pk
	if type(global_pk) == 'string' and string.len(global_pk) > 5 then
		character.global_pk = WorldPacket:decodeData(character.global_pk)
	else
		character.global_pk = {}
	end
end

-- 跨服PK字段解包
function PkServerService:pack( character )
	return WorldPacket:encodeData(character.global_pk)
end

-- pkbase发来的角色属性变更
function PkServerService:b2m_updateChAttrib(character, data)
	-- 只有诸神需要此数据
	if data.gang_uk then 
		if g_mapserver_id == GlobalArenaDefs.ARENA_MAP_ID then 
			local unique_key = data.unique_key
			local gang_uk = data.gang_uk
			local badge_id = data.badge_id
			local gang_title = data.gang_title
			local gcid = data.gcid
			GlobalArenaService:updateChGangUk( unique_key, gang_uk, badge_id, gang_title, gcid )
		end
	end

	if not character then return end

	for key, value in pairs(data) do
		if key == 'gang_id' then
			character.gang_id = value
			--发送角色属性更新包
			local update_ch = {}
			update_ch.gang_id = value
			CharacterService:sendCharacterUpdate2(character, update_ch)	

			-- 设置脏
			GameObjectService:appearDirty(character)
			-- 广播给视野内其他玩家
			local aoi_scene = GameObjectService:getAoiScene(character)
			local appear_data_update = {}
			appear_data_update.gang_id = value
			SceneService:sendAppearDetailUpdate(aoi_scene, character, appear_data_update)
		elseif key == 'counter' then 
			local counter_base_id = value.counter_base_id
			local cnt = value.cnt
			local en_count, counter = CounterService:getEnUseCount(character, counter_base_id)
			CounterService:increaseTotalCount(character, counter, cnt)
		end
	end
end

do 	-- 通知玩家退出PK服
	local rsp_opcode = opCodes.PKM2C_NOTICE_LEAVE_PK_SERVER
	local msg_name = "PackPKServer.PKM2C_NOTICE_LEAVE_PK_SERVER"
	local msg_proto = {}	
	function PkServerService:noticeLeavePkServer( character )
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

