--[[
坐骑系统servuce
author : xingzeng
date : 2014-08-15
]]--

local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local type = type
local opCodes = opCodes
local string_len = string.len
local math_random = math.random
local ChHorse = ChHorse
local ChHorseInfo = ChHorseInfo
local HorseBaseDao = HorseBaseDao
local GameObjectService
local DbLogDefs = DbLogDefs
local ChEquipTraceLogDefs = ChEquipTraceLogDefs
local EquipDefs = EquipDefs
local HorseDefs = HorseDefs
local math_ceil = math.ceil

ChHorseService = ChHorseService or {}

function ChHorseService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
end

-- 初始化角色装备栏
function ChHorseService:init(character, is_login)
	local horses_info = character.horses
	
	if (type(horses_info) == "string" and string_len(horses_info) > 1) then
		horses_info = WorldPacket:decodeData(horses_info)
	else
		horses_info = ChHorseInfo:new(character)
	end
	
	character.horses = horses_info
	
	-- INIT
	local ch_horse = horses_info.ch_horse
	if ch_horse then
		ch_horse.cid = character.id
		ch_horse.horse_base = HorseBaseDao.data[ch_horse.id]
	end
	
	return true
end

function ChHorseService:initForRobot(character)
	local horses_info = character.horses
	if (type(horses_info) == "string" and string.len(horses_info) > 1) then
		horses_info = WorldPacket:decodeData(horses_info)
	end
	
	character.ride_horse_id = 0
	if type(horses_info) == 'table' then
		character.ride_horse_id = horses_info.ride_horse_id or 0
	end
	
	character.horses_info = nil
end

-- 乘骑
function ChHorseService:ride(character, is_ride, is_send)
	local horses_info = character.horses
	if not horses_info.ride_horse_id or horses_info.ride_horse_id == 0 then
		horses_info.ride_horse_id = horses_info.ch_horse.id
	end
	horses_info.is_ride = is_ride
	
	-- 设置脏
	GameObjectService:appearDirty(character)
	
	if is_send then
		self:sendRideInfo(character)
	end
	
	return true
end

-- 获取当前的角色坐骑对象
function ChHorseService:getChHorse(character)
	local horses_info = character.horses
	return horses_info.ch_horse
end

-- 获取当前乘骑的坐骑ID
function ChHorseService:getRideHorseId(character)
	return character.horses.ride_horse_id or 0
end

-- 获取当前坐骑ID
function ChHorseService:getHorseId(character)
	local ch_horse = character.horses.ch_horse
	return ch_horse and ch_horse.id or 0
end

-- 打包角色坐骑数据
do
	local ChHorseSaveDbField = ChHorseSaveDbField
	function ChHorseService:_formatChHorseForPack(ch_horse)
		if not ch_horse then
			return
		end
		
		local ch_horse_new = {}
		for field, _ in pairs(ChHorseSaveDbField) do
			ch_horse_new[field] = ch_horse[field]
		end
		return ch_horse_new
	end
	
	local pack_data = {}
	function ChHorseService:pack(character)
		local horses_info = character.horses
		
		-- 注意是upvalue,别随意新增添加字段，然后热更新
		pack_data.ch_horse = self:_formatChHorseForPack(horses_info.ch_horse)
		pack_data.ride_horse_id = horses_info.ride_horse_id
		
		local str = WorldPacket:encodeData(pack_data)
		return str
	end
end

-- 发送乘骑回包
do
	local rsp_opcode = opCodes.M2C_CH_HORSE_RIDE
	local msg_name = "PackHorse.M2C_CH_HORSE_RIDE"
	local msg_proto = {}
	local appear_data_update = {}
	function ChHorseService:sendRideInfo(character)
		local horses_info = character.horses
		msg_proto.ride_horse_id = horses_info.ride_horse_id or 0
		msg_proto.is_ride = horses_info.is_ride or 0
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
		
		-- 广播给视野内其他玩家
		local aoi_scene = GameObjectService:getAoiScene(character)
		appear_data_update.ride_horse_id = msg_proto.is_ride == 1 and msg_proto.ride_horse_id or 0
		appear_data_update.horse_skin_equip_id = msg_proto.is_ride == 1 and (horses_info.skin_equip_id or 0) or 0
		SceneService:sendAppearDetailUpdate(aoi_scene, character, appear_data_update)
	end
end

-- 返回角色坐骑信息
do
	local rsp_opcode = opCodes.M2C_CH_HORSE_GET_INFO
	local msg_name = "PackHorse.M2C_CH_HORSE_GET_INFO"
	local msg_proto = {}
	function ChHorseService:sendChHorsesInfo(character)
		local horses_info = character.horses
		msg_proto.ride_horse_id = horses_info.ride_horse_id or 0
		msg_proto.is_ride = horses_info.is_ride or 0
		msg_proto.ch_horse = horses_info.ch_horse
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end
