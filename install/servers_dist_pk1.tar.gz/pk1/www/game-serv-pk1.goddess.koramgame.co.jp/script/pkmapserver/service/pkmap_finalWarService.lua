--[[
末日战场玩法service
author : jinlin.liu
date : 2016-07-05
]]--

local FinalWarDefs = FinalWarDefs
local FinalWarConfig = FinalWarConfig
local EffectType = EffectType
local externalSplitUInt=external.splitUInt
local Time = Time
FinalWarService = FinalWarService or {}
setmetatable(FinalWarService, SceneServiceInterface)

local SceneService = SceneService
function FinalWarService:onAfterLoadLua()
	SceneService = _G.SceneService
	FinalWarConfig = _G.FinalWarConfig
	FinalWarDefs = _G.FinalWarDefs
end

function FinalWarService:checkEnterScene(character, aoi_scene, dst_scene_base)
	return true
end

function FinalWarService:checkLeaveScene(character, aoi_scene)    
	return true
end

function FinalWarService:beforeEnterScene(character, aoi_scene)
    --print("FinalWarService:beforeEnterScene:",character.nick)
    --character.scene_id = aoi_scene.scene_id
    --local camp = FinalWarService:getCamp( aoi_scene, character )
    --local pos = FinalWarService:getRandomCampTransforIn(aoi_scene.scene_id, camp)
    --character.x = pos.x
    --character.y = pos.y
    return true
end

-- 进入场景之后
--如果是再次进入且是前哨则删除之前房间的
function FinalWarService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
    local fwar = aoi_scene.fwar
    --Logger:error("afterEnterScene",character.nick,prev_scene_id,aoi_scene.scene_id,aoi_scene.space_id)
    if not fwar.fighttype then
        if not character.tmps_ex.fighttype then
            Logger:error("角色不带fighttype有误 ！",character.nick)
        else
            fwar.fighttype = character.tmps_ex.fighttype
        end
    else
        if fwar.fighttype ~= character.tmps_ex.fighttype then
            character.tmps_ex.fighttype = fwar.fighttype
        end        
    end   
    
    if not fwar.group_id then
        local group_id=PkserverMappingService:getGroupId(character.area_id,Statics.PK_GAME_TYPE_ID_FINALWAR) 
        if not group_id then
            Logger:error("玩法无groupid，默认放到group1!!!",character.area_id,Statics.PK_GAME_TYPE_ID_FINALWAR)
            group_id = 1000
        end
        fwar.group_id = group_id
    end 
    
    
    local gcid_2_ch_info = fwar.gcid_2_ch_info
    if not is_reconnect then --非重连删除buffer
        SceneBufferService:delSceneBuffer(character, FinalWarDefs.GOD_BUFFER_ID)
    end
    
    if not is_reconnect and not gcid_2_ch_info[character.gcid] then
        -- 计算阵营
        local camp = FinalWarService:getCamp( aoi_scene, character )
        character.tmps_ex.fwar_camp = nil       
        
        
        --print("增加buffer")
        local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(SceneBufferDefs.SCENE_BUFFER_ID_GUWU_SUPER)
        SceneBufferService:addSceneBuffer(character, scene_buffer_base, 1, false)     

        -- 新建角色数据(均使用新的数据)
        local ch_info = self:newChInfo(character, camp)
        
        gcid_2_ch_info[character.gcid] = ch_info    

        -- 更新阵营
        GameObjectService:updateZhenying(aoi_scene, character, camp)

        -- 重新生成排行榜 
        self:rank(character.gcid, aoi_scene)
        self:sendChInfo(character, aoi_scene)

        -- 保存参与信息到DB
        ActiveService:addJoinGameInfo( character, Statics.PK_GAME_TYPE_ID_FINALWAR )
        
        local godlist = fwar.godlist
        godlist[#godlist+1] = character.gcid

        local log_type = '角色' .. character.nick .. '进入'
        FinalWarService:printCamp(aoi_scene, log_type)
        
    else
        -- 发送排名信息
        self:sendVsInfo( aoi_scene, character.gpid)
        
        -- 发送角色信息
        self:sendChInfo(character, aoi_scene)       
    end

end

-- 场景初始化
function FinalWarService:onInitScene(character, aoi_scene)
    Logger:error("FinalWarService:onInitScene")
    -- 默认场景初始化
    SceneService:onInitSceneDefault(character, aoi_scene)    
    FinalWarService:resetSene(aoi_scene)
    return true
end


function FinalWarService:resetSene(aoi_scene)    
    -- 场景末日之战相关数据
    aoi_scene.fwar = {}    
    local fwar = aoi_scene.fwar
    
    fwar.interval_refresh = 0 --3秒 6
    fwar.interval_addscore= 0  --1秒 2
    fwar.interval_addgod= 0  --75秒 90+60 --45秒，30秒的时候加一次buf,接下来75秒后加一次，+45秒后加一次
    fwar.interval_savedb= 0  --3分钟一次 
    fwar.addscoretemp = 0
    
    fwar.fighttype = FinalWarService:getInitFightType(aoi_scene)
    -- 角色相关信息
    fwar.gcid_2_ch_info = {}    
    fwar.group_id = nil
    -- 排名 
    fwar.top_list = {}

    -- 离开的玩家列表
    fwar.leave_ch_hash = {} --gcid->true   
    
    -- 进入场景时生成godlist
    fwar.godlist = {}    
    fwar.current_godpos = 1
    
    -- 状态控制
    fwar.addgcids = {}
    fwar.addhg_gcids = {}
    
    
    
    -- 陈容
    fwar.camp = {num=0}  --{num=0,[aid]={军团id=}}
    
    -- 小地图aoi
    if fwar.little then
        for k,v in pairs(fwar.little) do
            SmallMapService:delItem(aoi_scene, v)
        end 
    end    
    
    fwar.little = {}
end


function FinalWarService:getInitFightType(aoi_scene)
    if aoi_scene and aoi_scene.scene_id then
        if FinalWarDao.scene_id_2_data[aoi_scene.scene_id] then
            return FinalWarDao.scene_id_2_data[aoi_scene.scene_id].fighttype
        else
            Logger:error("场景数据有误!!") 
            if aoi_scene.scene_id == FinalWarDefs.war_scene_id1 then
                return FinalWarDefs.SUBID_FINALWAR1
            end
            
            if aoi_scene.scene_id == FinalWarDefs.war_scene_id2 then
                return FinalWarDefs.SUBID_FINALWAR2
            end
        end 
    else
        Logger:error("场景无scene_id!!")
    end
end

-- 离开场景时
function FinalWarService:afterLeaveScene(character, aoi_scene, leave_type)
    local fwar = aoi_scene.fwar
    local godlist = fwar.godlist

    -- 将角色积分信息删除
    local ch_info = self:getFinalWarChInfo(aoi_scene, character)
    ch_info.is_online = false  
    --ch_info.score = 0  
    
    for k,v in pairs(godlist) do
        if v == ch_info.gcid then
            table.remove(godlist,k)
            if fwar.current_godpos > k then
                fwar.current_godpos = fwar.current_godpos - 1                
            end
            break
        end
    end
    
    fwar.godlist[#godlist+1] = character.gcid
    --local log_type = '角色' .. character.nick .. '离开 末日之战场景，' .. character.tmps_ex.fighttype
    --FinalWarService:printCamp(aoi_scene, log_type)
    FinalWarService:deleteSmallMapItem(aoi_scene,character,character.gcid)
    FinalWarService:deleteSmallMapItem(aoi_scene,character,"hg"..character.gcid)    
end


function FinalWarService:update500ms(now_time_msec, aoi_scene)   
    --print("update500ms") 
    local fwar = aoi_scene.fwar	
    if not fwar then
        Logger:error("战场未初始化忽略",aoi_scene.scene_id,aoi_scene.space_id)
        return 
    end
	if self:isFinish(aoi_scene) then
		if fwar and not fwar.is_kickout and (fwar.finish_time + 300)*1000 < now_time_msec then
			-- 将所有玩家从PK服中剔出
			local chs = GameObjectService:getPlayerGameObjs(aoi_scene)
			for _, character in pairs(chs) do	
				ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
			end
			fwar.is_kickout = true
		end
		return
	end
	--定期给人物加分，但不排名
	fwar.interval_addscore = fwar.interval_addscore + 1 
	if fwar.interval_addscore >= 2 then
	   FinalWarService:updateScore(aoi_scene)
	   fwar.interval_addscore = 0
	end
	--定期刷新女神玩家
	   --30秒的时候
	--interval_addgod = interval_addgod + 1
	--if interval_addgod == 60 then
	--   FinalWarService:updateGod(aoi_scene)
	--end
	   --75或者循环45秒的时候
	--if interval_addgod > 150 then
    --   FinalWarService:updateGod(aoi_scene)
    --   interval_addgod = 61
    --end
    
    --定期生成榜单并下发
    fwar.interval_refresh =  fwar.interval_refresh + 1
    if fwar.interval_refresh > 6 then
       FinalWarService:updateRank(aoi_scene)
       fwar.interval_refresh = 0
    end   
    
    -- 定时存db
    fwar.interval_savedb = fwar.interval_savedb +1 
    if fwar.interval_savedb >= 61 then
        FinalWarService:autosavedb(aoi_scene)
        fwar.interval_savedb = 0  
    end 
end


do
    --local addscoretemp = 0
    --给有buff的玩家加分
    function FinalWarService:updateScore(aoi_scene)
        local chracters = GameObjectService:getPlayerGameObjs(aoi_scene)
        local gpids = GameObjectService:getGPids(aoi_scene)
        local fwar = aoi_scene.fwar 
	local addscoretemp = fwar.addscoretemp or 0
        if not fwar or not fwar.addhg_gcids then return end
        local addhg_gcids = fwar.addhg_gcids  
        local status = 0
        local newlittle = {}  
        --print("innnnnnnn")
        --table.dump("fwar.addhg_gcids  ",fwar.addhg_gcids ,-1)
        for k,ch in pairs(chracters) do        
            local canget_score = 0
            local hgname = "hg"..ch.gcid
            
            if #addhg_gcids<1 then
                Logger:error("需要增加皇冠的gicd太少****",#addhg_gcids,aoi_scene.space_id)
            end
            
            for k1,v1 in pairs(addhg_gcids) do
                if v1 == ch.gcid then 
                    local curpos = FinalWarService:getCurPos(ch)
                    if curpos then
                        local chaoi = fwar.little[hgname]
                        --table.dump("fwar.little",fwar.little,-1)
                        if not chaoi then     
                            --print("+++++++++++",chaoi)
                            local it = SmallMapService:addFilterItem(aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_FINALWAR_HG,{ch.gpid}, curpos.x, curpos.y)
                            --print("addddd:",it,curpos.x, curpos.y)
                            newlittle[hgname] = it
                            --fwar.little[ch.gcid] = nil
                            chaoi = it
                            --Logger:info("增加小地图皇冠****",ch.nick,hgname)
                        else
                            newlittle[hgname] = chaoi    
                            --Logger:info("不增加小地图皇冠****",ch.nick,hgname)
                        end 
                        if newlittle[hgname] then
                            SmallMapService:updateItemPos2Gpids(aoi_scene, chaoi,gpids, curpos.x, curpos.y)
                            --Logger:info("更新小地图皇冠位置****",ch.nick,hgname,chaoi)
                        end
                    else
                        Logger:error("当前末日角色无位置!",ch.nick)         
                    end
                    break
                end
            end
            
            if BufferService:isInStatus(ch, EffectType.biansheng) then
                if fwar.addscoretemp>=FinalWarConfig.add_score_time then
                    fwar.addscoretemp=0
                    status = FinalWarDefs.STATUS_GOD
                    --local v = table.find2(addhg_gcids, ch.gcid)
                    --if v then
                    --    status = status + FinalWarDefs.STATUS_HUANGGUANG
                    --end
                    local gcid_2_ch_info =  aoi_scene.fwar.gcid_2_ch_info
                    local curescore = 0
                    if gcid_2_ch_info[ch.gcid] then
                        curescore = gcid_2_ch_info[ch.gcid].score
                    end
                    canget_score = FinalWarService:getScore(false,status,curescore) 
                    --FinalWarService:addScore( ch, canget_score )
                else
                    fwar.addscoretemp =  fwar.addscoretemp + 1
                end    
                --print("addscoretemp:",fwar.addscoretemp,canget_score)
                local curpos = FinalWarService:getCurPos(ch)
                if curpos then
                    local chaoi = fwar.little[ch.gcid]
                    if not chaoi and not newlittle[hgname] then --之前不在小地图，且这次也没加到皇冠中      
                        local it = SmallMapService:addFilterItem(aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_FINALWAR_GOD, {ch.gpid},curpos.x, curpos.y)
                        Logger:info("增加女神状态****",ch.nick,ch.gcid)
                        newlittle[ch.gcid] = it
                        --fwar.little[ch.gcid] = nil
                        chaoi = it
                    else --之前在小地图，或者 这次加入了皇冠
                        --不是皇冠才需要显示
                        if not newlittle[hgname] then --
                            newlittle[ch.gcid] = chaoi   
                        end 
                    end 
                    if newlittle[ch.gcid] then
                        SmallMapService:updateItemPos2Gpids(aoi_scene, chaoi,gpids, curpos.x, curpos.y)
                    end    
                else
                    Logger:error("当前角色无位置!",ch.nick)         
                end
            end
               
            
            if canget_score>0 then
                FinalWarService:addScore( ch, canget_score )
            end       
        end
        
        for k2,v2 in pairs(fwar.little) do
            if not newlittle[k2] then
                SmallMapService:delItem(aoi_scene, v2)
            end    
        end
        fwar.little = newlittle
    end
end

function FinalWarService:getScore(iskill,status,curescore)
    local canget_score = 0
    if iskill then
        --
        local v = (FinalWarConfig.status_2_rewad_score)[status]
        if v then
           canget_score =math.floor(v[1]+v[2]*curescore)
        end
    else
        local v = (FinalWarConfig.status_2_auto_score)[status]
        if v then
           canget_score =math.floor(v[1]+v[2]*curescore)
        end
    end
    return canget_score
end

--取当前角色的位置信息
function FinalWarService:getCurPos(ch)
  local curpos = nil
  
  if ch and ch.aoi_obj then
    curpos={x=ch.aoi_obj.x,y=ch.aoi_obj.y}           
  end
  return curpos
end

--刷新女神
do    
    local nsnum = 3 --一次增加女神buff的玩家数
    function FinalWarService:updateGod(aoi_scene)
        --增加女神buff
        local fwar = aoi_scene.fwar 
        local godlist = fwar.godlist
        fwar.addgcids = {}
        local addgcids = fwar.addgcids
        for i=1,nsnum,1 do
            local onegcid = nil;
            if fwar.current_godpos > #godlist then
                fwar.current_godpos = 1
                onegcid = godlist[fwar.current_godpos]
                local v = table.find2(addgcids, onegcid) 
                if v then return end
                FinalWarService:addGodBuff(aoi_scene,onegcid)
                addgcids[#addgcids+1] = onegcid
            else    
                onegcid = godlist[fwar.current_godpos]
                local v = table.find2(addgcids, onegcid) 
                if v then return end
                FinalWarService:addGodBuff(aoi_scene,onegcid)
                addgcids[#addgcids+1] = onegcid
            end
            fwar.current_godpos = fwar.current_godpos + 1
        end
        table.dump("addgod:",addgcids,-1)
        print("current_godpos:",fwar.current_godpos)
    end
end

do 
    local hgnum = 3 --一次增加黄冠buff的玩家数
    function FinalWarService:updateRank(aoi_scene)    
        self:rank(-1, aoi_scene)
        --对toplist的前几个玩家加皇冠buff
        local fwar = aoi_scene.fwar 
        local godlist = fwar.top_list
        fwar.addhg_gcids = {}
        local addhg_gcids=fwar.addhg_gcids
        for i=1,hgnum,1 do
            if godlist[i] then
                --FinalWarService:addHgBuff(aoi_scene,(godlist[i]).gcid)
                addhg_gcids[#addhg_gcids+1] = (godlist[i]).gcid
            else
                break
            end    
        end        
    end
end

function FinalWarService:addGodBuff(aoi_scene,gcid)
    ---****
    --print("+++++++addgodBuff:",gcid)
    local buffer_base = BufferBaseService:getBufferBaseById(FinalWarDefs.FW_BUFFERID_GOD)
    local ch_obj = CharacterService:getCharacterByGcid(gcid)
    if ch_obj then
        local is_ok, is_need_bc = BufferService:addTmpBuffer(ch_obj, buffer_base)
        if is_ok and is_need_bc then
            BufferService:bcBuffers(aoi_scene, ch_obj)
        end
    end    
end

function FinalWarService:addHgBuff(aoi_scene,gcid)
    return 
    ---****
    --local buffer_base = BufferBaseService:getBufferBaseById(FinalWarDefs.FW_BUFFERID_HG)
    --local ch_obj = CharacterService:getCharacterByGcid(gcid)
    --if ch_obj then
    --    local is_ok, is_need_bc = BufferService:addTmpBuffer(ch_obj, buffer_base)
    --    if is_ok and is_need_bc then
    --        BufferService:bcBuffers(aoi_scene, ch_obj)
    --    end
    --end
end
  

function FinalWarService:checkFight(aoi_scene, attacker, target)
	return true
end



-- 设置头顶文字
function FinalWarService:initWanfaAoiData( character, aoi_scene )
	return true
end


-- 当玩家被杀
do
    function FinalWarService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
        -- 怪物杀人不算
        if not fighter.tmps_ex then 
            return 
        end

        -- 游戏结束后不再进行计算
        local aoi_scene = GameObjectService:getAoiScene(fighter)
        if aoi_scene.fwar.is_finish then 
            return 
        end 
        
        local fwar = aoi_scene.fwar
        local killer_info = self:getFinalWarChInfo(aoi_scene, fighter)

        -- 总共获得的积分数
        local total_get_score = 0        
        
        -- 被杀方，增加被杀次数
        -- 击杀方，增加杀人总数，及相应的类型次数，分数，连杀数
            --需要判断是否有buff
        for _, killed_aoi_id in pairs(arr_kill_player_aoi_id) do
------------------------------- 受击方 ---------------------------------------------------------
            local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, killed_aoi_id) 
            local killed_info = self:getFinalWarChInfo(aoi_scene, killed_player)
            
            
            -- 增加被杀次数
            killed_info.cont_be_kill_cnt = killed_info.cont_be_kill_cnt + 1

            -- 连续击杀次数清零
            killed_info.cont_kill_notice = 0
            
---------------------------------- 攻击方 -----------------------------------
            local canget_score = 0
            killer_info.cont_kill_notice = killer_info.cont_kill_notice + 1
            if killer_info.cont_kill_notice> killer_info.max_cont_kill then
                killer_info.max_cont_kill = killer_info.cont_kill_notice
            end
            
            local iscommon = true
            local status = 0
            -- 被攻击方处于变身状态
            if FinalWarService:isBianShenBeforeDie(aoi_scene,killed_player) then
                Logger:info("处于变身状态",killed_player.nick)
                status = status + FinalWarDefs.STATUS_GOD
                --canget_score = FinalWarConfig.status_2_rewad_score[FinalWarDefs.STATUS_GOD]  
                iscommon = false    
                killer_info.cont_kill_god = killer_info.cont_kill_god + 1  
                FinalWarService:resetIsBianShenBeforeDie(aoi_scene,killed_player)
                
                --被杀方删除buff
                FinalWarService:deleteSmallMapItem(aoi_scene,killed_player,killed_player.gcid)
            end
            -- 皇冠状态
            if killed_info.rank>0 and killed_info.rank<=3 then
                Logger:info("处于皇冠状态",killed_player.nick)
                --canget_score = FinalWarConfig.status_2_rewad_score[FinalWarDefs.STATUS_HUANGGUANG]
                status = status + FinalWarDefs.STATUS_HUANGGUANG
                if not iscommon then                    
                    killer_info.cont_kill_god = killer_info.cont_kill_god -1
                end
                iscommon = false
                killer_info.cont_kill_hg = killer_info.cont_kill_hg + 1    
                        
                FinalWarService:deleteSmallMapItem(aoi_scene,killed_player,"hg"..killed_player.gcid)
            end
            
            if iscommon then 
                killer_info.cont_kill_common = killer_info.cont_kill_common + 1
                status = FinalWarDefs.STATUS_COMMON 
            end
            --killer_info.score = killer_info.score + canget_score
            local gcid_2_ch_info =  aoi_scene.fwar.gcid_2_ch_info
            local curescore = 0
            if gcid_2_ch_info[killed_info.gcid] then
                curescore = gcid_2_ch_info[killed_info.gcid].score or 0
            end
            canget_score = FinalWarService:getScore(true,status,curescore) 
            --print("prr",canget_score)
            if BufferService:isInStatus(fighter, EffectType.score_multi) then
                --print("pr2r",canget_score)
                local arr_buffer = FightService:getMyBuffers(fighter)
                local buffer = arr_buffer.score_multi
                if buffer then
                    canget_score = math.floor(canget_score*buffer.effect_value)
                    --print("pr3r",canget_score)
                end
            end
            
            FinalWarService:addScore( fighter, canget_score )

            -- 增加总杀人数
            killer_info.total_kill_cnt = killer_info.total_kill_cnt + 1
        end

        -- 攻击者更新积分
        self:sendChInfo(fighter, aoi_scene)
    end
end



function FinalWarService:deleteSmallMapItem(aoi_scene,character,key)
    local fwar = aoi_scene.fwar
    --print("ddddddsmallmapitem!!")
    if fwar and fwar.little then
        --print("ddddddsmallmapitem2!!",key)
        local chaoi = fwar.little[key]
        if chaoi then
            --print("ddddddsmallmapitem23!!",chaoi)
            --Logger:info("删除小地图状态****",character.nick,key)
            SmallMapService:delItem(aoi_scene, chaoi)
            fwar.little[key] = nil   
            --if character.gcid == key then
            --    BufferService:delBuffer(character, FinalWarConfig.god_change_buffer, true)
            --end
        end
    end    
end

function FinalWarService:addIsBianShen(killed_player)
    if BufferService:isInStatus(killed_player, EffectType.biansheng) then
        local aoi_scene = GameObjectService:getAoiScene(killed_player)
        if aoi_scene.fwar then
            if not aoi_scene.fwar.isBianShen then
                aoi_scene.fwar.isBianShen = {}
            end
            aoi_scene.fwar.isBianShen[killed_player.gcid] = true
        end 
    end
end

function FinalWarService:isBianShenBeforeDie(aoi_scene,killed_player)
    if aoi_scene and killed_player and aoi_scene.fwar and aoi_scene.fwar.isBianShen then
        return aoi_scene.fwar.isBianShen[killed_player.gcid]
    end
    return false    
end

function FinalWarService:resetIsBianShenBeforeDie(aoi_scene,killed_player)
    if aoi_scene and killed_player and aoi_scene.fwar and aoi_scene.fwar.isBianShen then
        aoi_scene.fwar.isBianShen[killed_player.gcid] = nil 
    end
end

-- 当玩家捡到积分BUFFER时
function FinalWarService:addScore( character, score )
    local aoi_scene = GameObjectService:getAoiScene(character)
    local fwar = aoi_scene.fwar
    if not fwar or fwar.is_finish then 
        return 
    end 

    local player_info = self:getFinalWarChInfo(aoi_scene, character)
    player_info.score = player_info.score + score
    -- 重新排名
    --self:rank(character.gcid, aoi_scene)

    -- 发送角色的积分信息
    self:sendChInfo(character, aoi_scene)

    -- 发送得分特效
    GameObjectService:addAoiInstantTexiao( aoi_scene, character, AoiTexiaoDefs.SORT_SCORE_ADD_PIAOZI, score )
end


function FinalWarService:getBirthPos(aoi_scene, character)
	if not self:isInFinalWar(aoi_scene.scene_id) then 
		return false
	end
	local camp = FinalWarService:getCamp( aoi_scene, character )
	local pos = FinalWarService:getRandomCampTransforIn(aoi_scene.scene_id, camp, true)
	return true, pos.x, pos.y
end

-- 设置阵营
function FinalWarService:setZhenying(aoi_scene, character)
	local camp = FinalWarService:getCamp( aoi_scene, character )
	GameObjectService:updateZhenying(aoi_scene, character, camp)
end

-- 获取阵营
function FinalWarService:getCamp( aoi_scene, character )	
    local aid, cid = externalSplitUInt(character.gcid)
    local fwar = aoi_scene.fwar
    local camp = fwar.camp
    local appear = character.appear
    if false and appear.badge_id and appear.badge_id > 0 then
        if camp[aid] then
            if camp[aid][appear.badge_id] then
                return camp[aid][appear.badge_id]
            else
                camp.num = camp.num + 1
                local campid = Utils.getZhenYingId(camp.num,1)
                camp[aid][appear.badge_id] = campid
                return campid
            end
        else            
            camp.num = camp.num + 1
            local campid = Utils.getZhenYingId(camp.num,1)
            camp[aid] = {[appear.badge_id]=campid}
            return campid
        end
    else --无军团就用aoiid
        return Utils.getZhenYingId(character.aoi_id, 0)    
    end 
end





function FinalWarService:printCamp(aoi_scene, notice)
    if true then return end
	if self:isFinish(aoi_scene) then return end

	local fwar = aoi_scene.fwar

	local log_str = '---------------' .. aoi_scene.space_id .. ' ' .. notice .. '\n'	
	
	local filename = "finalwar_" .. os.date('%Y%m%d', os.time()) .. ".log"
	external.log(log_str, filename)
end




-- 生成排名
function FinalWarService:rank( gcid, aoi_scene,num )
    local toplistnum = num or 5
	-- 更新排名数据
	self:genToplist(aoi_scene, toplistnum)

	-- 发送新的排名信息
	local gpids = GameObjectService:getGPids(aoi_scene)
	self:sendVsInfo(aoi_scene, gpids)	
	
	-- 发送角色排名给排名有变化的玩家
    local gcid_2_ch_info =  aoi_scene.fwar.gcid_2_ch_info
    for _, ch_info in pairs(gcid_2_ch_info) do
        if ch_info.rank ~= ch_info.old_rank  then 
            local need_send_ch = CharacterService:getCharacterByGcid(ch_info.gcid)
            if need_send_ch then 
                self:sendChInfo(need_send_ch, aoi_scene)
            end
        end
    end
end


-- 获取角色信息
function FinalWarService:getFinalWarChInfo( aoi_scene, character,simple)
	local ch_info = aoi_scene.fwar.gcid_2_ch_info[character.gcid]
	if simple then
	   return {rank=ch_info.rank,score=ch_info.score}
	else
	   return ch_info
	end   
end

-- 新建角色对象
function FinalWarService:newChInfo( character, camp )
	local ch_info = {}
	local appear = character.appear
	ch_info.gcid = character.gcid
	ch_info.gpid = character.gpid  	
	ch_info.camp = camp 			--所在阵营
	ch_info.score = 0				--积分
	ch_info.cont_kill_god = 0	--杀女神数
	ch_info.cont_kill_common = 0  --杀普通人数
	ch_info.cont_kill_hg = 0  --杀皇冠数
	ch_info.cont_kill_notice = 0	--广播用的连续杀人数
	ch_info.cont_be_kill_cnt = 0	--连续被杀数
	ch_info.total_kill_cnt = 0		--总杀人数
	ch_info.status = 1			--状态(初始为1,普通状态,2女神，3皇冠)
	ch_info.nick = character.nick 	--
	ch_info.is_online = true
	ch_info.max_cont_kill = 0		--最高连杀数
	ch_info.prof = character.prof
	ch_info.rank = 0
	ch_info.unique_key = character.unique_key
	ch_info.gangname =  character.gang_title or ""
	ch_info.badge_id =  appear.badge_id
	ch_info.viplv = appear.gang_type 
	ch_info.aoi_id = character.aoi_id
	ch_info.unique_key=character.unique_key
	ch_info.servname = character.area_name--FinalWarService:getServname(character)	
	local app = CharacterService:getAppearBaseData(character)
	app.full_jl_lev = nil 
    ch_info.appear = WorldPacket:encodeData(app)
	return ch_info
end


function FinalWarService:getServname(character)
    local aid, cid = externalSplitUInt(character.gcid)  
    if Language:isCN() then
        --中文的前10都是测试机，名字为t加上数字
        if aid < 10 then
            return "T"..aid
        else
            return "S"..aid
        end
    else
        return "S"..aid 
    end
end

-- 获取复活点
-- return 	bool:is_back_to_mcity,	true:回到主城，false:本场景复活
--			x, y					本场景复活的X，Y坐标点
function FinalWarService:getRelivePos(character, aoi_scene)
	local ch_info = aoi_scene.fwar.gcid_2_ch_info[character.gcid]
	local pos = FinalWarService:getRandomCampTransforIn(aoi_scene.scene_id, ch_info.camp)
	return false, pos.x, pos.y
end

-- 获取排行榜
function FinalWarService:genToplist( aoi_scene, limit_num)
	local fwar = aoi_scene.fwar
	
	local gcid_2_ch_info =  fwar.gcid_2_ch_info
	local tmp = {}
	
	for _, ch_info in pairs(gcid_2_ch_info) do	tmp[#tmp + 1] = ch_info	end

	table.sort( tmp, function ( a, b ) return a.score > b.score end)

	-- 更新排名
	local size = #tmp 
	for i=1, size do 
		tmp[i].old_rank = tmp[i].rank or 0
		tmp[i].rank = i 
	end

	-- 只保留前limit_num名
	for i=limit_num+1,size do 
	   if tmp[i] then
	      tmp[i]  = nil 
	   end
	end       
    
	fwar.top_list = tmp
	--table.dump("tplist:",fwar.top_list,-1)
end

function FinalWarService:topListSimple(aoi_scene,num)
    local fwar = aoi_scene.fwar
    local top_list = fwar.top_list
    local ret = {}
    for k,v in pairs(top_list) do
        ret[#ret+1] = {rank=v.rank,nick=v.nick,score=v.score,aoi_id=v.aoi_id}
        if num <= 1 then break end
        num = num -1
    end
    return ret
end

-- 活动结束，发奖
function FinalWarService:finish(aoi_scene)
	local fwar = aoi_scene.fwar
	if fwar.is_finish then return end
    
    FinalWarService:rank( -1, aoi_scene)
	-- 设置完成时间
	fwar.finish_time = os.time()
	fwar.is_finish = true	
	
	do 	-- 计算要发送给玩家的战斗结果
		local fwar_result = {}	--结果数据
		local o = nil
		local old_top = fwar.top_list
		FinalWarService:rank( -1, aoi_scene,FinalWarConfig.war_room_max_num )
		for k,v in pairs(fwar.top_list) do
		   o = {gcid=v.gcid,rank=v.rank,prof=v.prof,nick=v.nick,score=v.score,
		        killedtotal=v.total_kill_cnt,killcommon=v.cont_kill_common,
		        killgod=v.cont_kill_god,killhuangguang=v.cont_kill_hg,
		        continuekill=v.max_cont_kill,gangname=v.gangname,badge_id=v.badge_id,
		        viplv=v.viplv}
		   fwar_result[#fwar_result+1] = o     
		end
		self:sendFinish(aoi_scene, fwar_result)
		fwar.top_list = old_top
	end
	
	local savlist = {}
	-- 发奖
	for _, ch_info in pairs(fwar.gcid_2_ch_info) do
		local data = {}		
		data.subid = fwar.fighttype
		data.rank = ch_info.rank or 0
		
		local data2 = {}
		--gpid rank,active_id score killedtotal killhuangguang killgod killcommon
        data2.unique_key = ch_info.unique_key
        data2.nick = ch_info.nick
        data2.gpid = ch_info.gpid
        data2.gcid = ch_info.gcid
        data2.servname = ch_info.servname
        data2.rank = ch_info.rank or 0
        data2.active_id = fwar.fighttype
        data2.score = ch_info.score
        data2.killedtotal = ch_info.total_kill_cnt
        data2.killhuangguang = ch_info.cont_kill_hg
        data2.killgod = ch_info.cont_kill_god
        data2.killcommon = ch_info.cont_kill_common
        data2.appear = ""
        data2.continuekill = ch_info.max_cont_kill
        data2.gangname=ch_info.gangname
        data2.badge_id=ch_info.badge_id
        data2.viplv=ch_info.viplv
		savlist[#savlist+1] = data2
		RewardService:reward(Statics.PK_GAME_TYPE_ID_FINALWAR, data.subid, ch_info.gpid, ch_info.gcid, data)
	end
	-- 存db
	FinalWarService:save2Db( aoi_scene,savlist,true )
	FinalWarService:printCamp(aoi_scene, "战斗结束")
end

-- 判断玩家是否在野外
function FinalWarService:isInFinalWar( scene_base_id )
	return scene_base_id == FinalWarDefs.war_scene_id1 or scene_base_id == FinalWarDefs.war_scene_id2
end

-- 是否已经结束
function FinalWarService:isFinish( aoi_scene )
	local fwar = aoi_scene.fwar
	return fwar and fwar.is_finish
end

-- 获取出生点与复活点
function FinalWarService:getRandomCampTransforIn(scene_id, camp_id,isRelive)
	local transfer_base_id = nil
	if camp_id == 1 then 
		transfer_base_id = FinalWarConfig.camp_a_transfer_dot
	else
		transfer_base_id = FinalWarConfig.camp_b_transfer_dot
	end
	
	if isRelive then transfer_base_id=FinalWarConfig.camp_b_transfer_dot end
	local pos = {}
	pos.x, pos.y = SceneAoiService:getRandomTransferIn( scene_id, transfer_base_id )
	--print("relieve pos !!",pos.x,pos.y)
	return pos
end


do  -- base传来的移动角色到战场	
	function FinalWarService:b2m_entryBattle( character, data )
	   
		-- 玩家可能已经不在了
		if not character then return end

		local space_id = data.space_id
		local line_id = data.line_id
		local type = data.type --战场类型
		local rank = data.rank
		character.tmps_ex.fighttype = type
		--print("b2mentrrrrrbttt:",type,character.tmps_ex.fighttype)

		local space_id = data.space_id
		local line_id = data.line_id
		local sceneid = nil
		if data.type == FinalWarDefs.SUBID_FINALWAR1 then
		  sceneid = FinalWarDefs.war_scene_id1
		else
		  sceneid = FinalWarDefs.war_scene_id2
		end  
		--Logger:error("++++b2m_entryBattle",character.nick,data.type,sceneid)
		--local pos = FinalWarService:getRandomCampTransforIn(sceneid, math.random(1,2))
		SceneService:moveScene(character, sceneid, space_id, line_id)	
	end
	
	function FinalWarService:b2m_syncdata(_, data)
	   --print("data.sssssb2m_syncdata",data.sceneid)
	   FinalWarDao.scene_id_2_data[data.sceneid] = data
	end
end

-- base 发来的活动结束
function FinalWarService:b2m_finish(_, data )
	local space_id = data.space_id
	local type = data.type
	--print("tttttt",type,space_id)
	local aoi_scene = AoiSceneService:getAoiScene(space_id)
	if aoi_scene then 
		self:finish(aoi_scene)
	end
end

-- base 发来的玩家退出后进入了其他的场景实例 
function FinalWarService:b2m_chEntryOtherScene(_, data)
	local space_id = data.space_id
	local gcid = data.gcid
	local aoi_scene = AoiSceneService:getAoiScene(space_id)
	print("b2m_chEntryOtherScene",gcid,space_id,aoi_scene)
	if aoi_scene and aoi_scene.fwar and aoi_scene.fwar.gcid_2_ch_info then 
		local gcid_2_ch_info = aoi_scene.fwar.gcid_2_ch_info
		print("b2mchenos:",gcid)
		if aoi_scene.fwar.fighttype then
		  if data.type ~= aoi_scene.fwar.fighttype then
		      Logger:error("再次进入时传入参数有误 ！")
		  end
		  --character.tmps_ex.fighttype = aoi_scene.fwar.fighttype
		end
		gcid_2_ch_info[gcid] = nil
		self:rank(gcid, aoi_scene)
	end
end

function FinalWarService:autosavedb(aoi_scene)    
    local fwar = aoi_scene.fwar
    local savlist = {}
    --table.dump("autosavedb========",fwar.gcid_2_ch_info,-1)
    
    if not fwar.is_finish then
        for _, ch_info in pairs(fwar.gcid_2_ch_info) do
            local data2 = {}
            --gpid rank,active_id score killedtotal killhuangguang killgod killcommon
            data2.unique_key = ch_info.unique_key
            data2.nick = ch_info.nick
            data2.gpid = ch_info.gpid
            data2.gcid = ch_info.gcid
            data2.servname = ch_info.servname
            data2.rank = ch_info.rank or 0
            data2.active_id = fwar.fighttype
            data2.score = ch_info.score
            data2.killedtotal = ch_info.total_kill_cnt
            data2.killhuangguang = ch_info.cont_kill_hg
            data2.killgod = ch_info.cont_kill_god
            data2.killcommon = ch_info.cont_kill_common
            data2.appear = ""
            data2.continuekill = ch_info.max_cont_kill
            data2.gangname=ch_info.gangname
            data2.badge_id=ch_info.badge_id
            data2.viplv=ch_info.viplv
            savlist[#savlist+1] = data2
        end
        -- 存db
        --print("fwar.is_finish:",#savlist)
        --table.dump("savlist=======",savlist,-1)
        FinalWarService:save2Db(aoi_scene, savlist ,false)
    end    
end

--存入db
--所有数据从map过来的gpid rank,active_id score killedtotal killhuangguang killgod
function FinalWarService:save2Db( aoi_scene,mapwarlist,isover )  
    local datas = {}  
    local tobase = {}
    local time_now = Time.time_now/1000
    for k,v in pairs(mapwarlist) do        
        if v and v.rank > 0 and v.gcid then
            local gcid_2_ch_info =  aoi_scene.fwar.gcid_2_ch_info
            local ch_info = nil
            if gcid_2_ch_info and gcid_2_ch_info[v.gcid] then
                ch_info = gcid_2_ch_info[v.gcid]
            end
            if  ch_info then   
                local data2 = {}
                data2.unique_key = ch_info.unique_key
                data2.nick = ch_info.nick
                data2.servname = ch_info.servname
                data2.rank = ch_info.rank or 0
                data2.active_id = aoi_scene.fwar.fighttype
                data2.score = ch_info.score
                data2.killedtotal = ch_info.total_kill_cnt
                data2.killhuangguang = ch_info.cont_kill_hg
                data2.killgod = ch_info.cont_kill_god
                data2.killcommon = ch_info.cont_kill_common
                data2.continuekill = ch_info.max_cont_kill
                data2.gangname=ch_info.gangname
                data2.badge_id=ch_info.badge_id
                data2.viplv=ch_info.viplv
                data2.prof = ch_info.prof
                data2.group_id = aoi_scene.fwar.group_id
                
                if v.rank >= 1 and v.rank<= 3 then                      
                    tobase[v.rank] = {rank=v.rank,nick=v.nick,server_name=v.servname,
                                        appear=ch_info.appear,gangname=v.gangname,badge_id=v.badge_id,
                                        viplv=v.viplv,
                                        updated=Time:getDateTimeStrBySeconds(time_now)}
                    data2.appear = ch_info.appear                    
                else
                    data2.appear = ""
                end
                datas[#datas+1]=data2
           else
                Logger:error("无角色数据，但有排名")     
           end     
        end
    end
    --print("isover:",isover)
   -- table.dump("datas:",datas,-1)
    if #datas>0 then
        ServerCall:m2dCall('FinalWarService:m2d_saveData', 0, {isover=isover,data=datas})
        if isover  then
            if aoi_scene.fwar.fighttype == FinalWarDefs.SUBID_FINALWAR1 then
                ServerCall:m2bCall('FinalWarService:m2b_saveData', 0, {data=tobase,group_id=aoi_scene.fwar.group_id})
            end
        end
    end        
end



------------------------------------- 广播 【BEG】 -----------------------------------

------------------------------------- 广播 【END】 -----------------------------------


------------------------------------- 与客户端交互 【BEG】 ---------------------------

do  -- 发送角色积分信息
    local rsp_opcode = opCodes.PKM2C_FINALWAR_SELF_SCORE
    local msg_name = "PackFinalWar.PKM2C_FINALWAR_SELF_SCORE"
    function FinalWarService:sendChInfo(character, aoi_scene)
        local ch_info = self:getFinalWarChInfo(aoi_scene, character,true)
       -- table.dump("PKM2C_FINALWAR_SELF_SCORE:",ch_info,-1)
        WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, ch_info, nil, character.gpid)
    end
end


do	-- 发送排名信息
	local rsp_opcode = opCodes.PKM2C_FINALWAR_TOP5_SCORE
	local msg_name = "PackFinalWar.PKM2C_FINALWAR_TOP5_SCORE"
	local data = {}
	function FinalWarService:sendVsInfo(aoi_scene, gpids)
		data.top5score = FinalWarService:topListSimple(aoi_scene,5)	
--		--Logger:info(data)
--table.dump("PKM2C_FINALWAR_TOP5_SCORE:",data,-1)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end
end

do	-- 发送结束信息
	local rsp_opcode = opCodes.PKM2C_FINALWAR_END_RANKS
	local msg_name = "PackFinalWar.PKM2C_FINALWAR_END_RANKS"
	function FinalWarService:sendFinish(aoi_scene, result)
		local gpids = GameObjectService:getGPids(aoi_scene)
		table.dump("PKM2C_FINALWAR_END_RANKS:",result,-1)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, {ranks=result}, nil, gpids)
	end
end

------------------------------------- 与客户端交互 【END】 ---------------------------
