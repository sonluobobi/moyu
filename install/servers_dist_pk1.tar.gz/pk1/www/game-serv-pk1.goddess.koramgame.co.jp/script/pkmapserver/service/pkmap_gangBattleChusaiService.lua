
--[[
MAP 3V3 service
author : guoyin.huang
date : 2015年04月20日

]]--

local GangBattleChusaiDao = GangBattleChusaiDao

GangBattleChusaiService = GangBattleChusaiService or {}
setmetatable(GangBattleChusaiService, SceneServiceInterface)

local SceneService = SceneService
function GangBattleChusaiService:onAfterLoadLua()
	SceneService = _G.SceneService
end

--------------------------- 场景相关 [BEG] -------------------------------------
-- 场景初始化
function GangBattleChusaiService:onInitScene(character, aoi_scene)
	-- 场景对战信息
	local space_id = aoi_scene.space_id
	local vs_info = GangBattleChusaiDao.scene_insid_2_vs_info[space_id]
	GangBattleChusaiDao.scene_insid_2_vs_info[space_id] = nil

	if vs_info then 
		-- 初始化战斗信息
		local camp1 = vs_info.camp1
		local camp2 = vs_info.camp2
		local team1 = TeamService:getTeamById( camp1.team_id )
		local team2 = TeamService:getTeamById( camp2.team_id )
		local member_num1 = team1 and #team1.members
		local member_num2 = team2 and #team2.members

		local gang_nick1 = camp1.gang_title
		local gang_nick2 = camp2.gang_title

		local gang_battle_chusai = {}
		aoi_scene.gang_battle_chusai = gang_battle_chusai

		gang_battle_chusai.area_id = external.splitUInt(character.gcid)

		-- 双方总生命数
		gang_battle_chusai.camps = {
			[1] = {
				gang_title = gang_nick1,
				lifes = 0,
				camp = 1,
				team_id = camp1.team_id,
				members = {}
			},
			[2] = {
				gang_title = gang_nick2,
				lifes = 0,
				camp = 2,	
				team_id = camp2.team_id,
				members = {}	
			},
		}

		-- 初始化成员信息
		for _, camp_info in pairs(gang_battle_chusai.camps) do
			local team_id = camp_info.team_id
			local team = TeamService:getTeamById(team_id)
			local members = team and team.members
			if members then 
				for _, member in pairs(members) do
					local battle_member = {}
					battle_member.gcid = member.gcid
					battle_member.nick = member.nick
					battle_member.level = member.level
					battle_member.fight_fc = member.total_fc
					battle_member.gender = member.appear_base_data.gender or 0
					battle_member.prof = member.appear_base_data.prof or 0
					battle_member.kill_num = 0
					table.insert(camp_info.members, battle_member)
				end
			end
		end

		-- 队伍到阵营
		gang_battle_chusai.teamid_2_camp = {
			[camp1.team_id] = 1,
			[camp2.team_id] = 2,
		}
		-- 结束时间
		gang_battle_chusai.end_time = os.time() + GangBattleConfig.chusai_battle_long
		-- 开始检测战斗结束的阈值(如果5秒后有一方仍然有玩家，则结束)
		gang_battle_chusai.start_check_finish = os.time() + 5
		-- 每个玩家的战斗信息
		gang_battle_chusai.gcid_2_info = {}
		-- 是否结束
		gang_battle_chusai.is_finish = false
	else
		aoi_scene.gang_battle_chusai = nil
	end

	return true
end

function GangBattleChusaiService:checkFight(aoi_scene, attacker)
	return self:isFighting(aoi_scene)
end

-- 场景更新
function GangBattleChusaiService:update500ms(now_time_msec, aoi_scene)
	if GangBattleChusaiService:isFighting( aoi_scene ) then 

		local gang_battle_chusai = aoi_scene.gang_battle_chusai
		local now_time = now_time_msec/1000

		-- 检测是否有一方生命数为0
		if now_time > gang_battle_chusai.start_check_finish then 
			local camps = gang_battle_chusai.camps
			for _, camp in pairs(camps) do
				if camp.lifes <= 0 then 
					return self:finish(aoi_scene)
				end
			end
		end
		-- 检测是否已经结束
		if now_time > gang_battle_chusai.end_time then 
			self:finish(aoi_scene)
		end
	end
end

-- 获取复活点
-- @character 复活的角色
-- @aoi_scene 场景
function GangBattleChusaiService:getRelivePos(character, aoi_scene)
	if GangBattleChusaiService:isFighting( aoi_scene ) then 
		local ch_info = self:getChBattleInfo(character, aoi_scene)
		local pos = self:getRandomCampTransforIn(GangBattleConfig.chusai_scene_id, ch_info.camp)
		return false, pos.x, pos.y
	else
		return false, character.x, character.y
	end
end

-- 判断玩家是否可复活
-- 战斗状态，而且生命为0，则不让复活
function GangBattleChusaiService:isCanRelive(character)
	local aoi_scene = GameObjectService:getAoiScene(character)
	if self:isFighting(aoi_scene) then
		local ch_info = self:getChBattleInfo(character, aoi_scene)
		return ch_info.lifes > 0
	end
	return true
end

-- 设置头顶文字
function GangBattleChusaiService:initWanfaAoiData( character, aoi_scene )
	return true
end

-- 设置阵营
function GangBattleChusaiService:setZhenying(aoi_scene, character)
	if self:isFighting(aoi_scene) then 
		-- 设置阵营,阵营ID统一获取接口
		local zhenying = self:getChCamp(character, aoi_scene)
		GameObjectService:updateZhenying(aoi_scene, character, zhenying)
	else
		GameObjectService:updateZhenying(aoi_scene, character, 1)
	end
end

-- 进入场景
function GangBattleChusaiService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	if self:isFighting(aoi_scene) then 
		local gang_battle_chusai = aoi_scene.gang_battle_chusai

		if not is_reconnect then 
			-- 增加生命数
			local gcid_2_info = gang_battle_chusai.gcid_2_info
			local camps = gang_battle_chusai.camps
			local gcid = character.gcid

			assert(not gcid_2_info[gcid])

			local team = assert(TeamService:getTeamByCid(gcid))
			local camp = gang_battle_chusai.teamid_2_camp[team.id]

			local ch_info = self:newChInfo(character, camp)
			gcid_2_info[gcid] = ch_info
			camps[camp].lifes = camps[camp].lifes + ch_info.lifes

			self:sendChBattleInfo(character, aoi_scene)
			-- 发送战斗信息
			self:sendBattleInfo(character.gpid, aoi_scene)
			-- 发送玩家数据包
			self:sendBattleInfoUpdate(aoi_scene)

			local en_counter, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_GANG_BATTLE_CHUSAI)
			if en_counter > 0 then 
				CounterService:addcount(character, counter)
			end
		else
			self:sendChBattleInfo(character, aoi_scene)
			self:sendBattleInfo(character.gpid, aoi_scene)
		end

	else
		ServerCall:m2bCall('GangBattleChusaiService:c2b_match', character.gcid, nil)
	end
end

-- 获取玩家进入后的阵营
function GangBattleChusaiService:getChCamp(character, aoi_scene)
	if self:isFighting(aoi_scene) then
		local team = assert(TeamService:getTeamByCid(character.gcid))
		local gang_battle_chusai = aoi_scene.gang_battle_chusai
		local camp = gang_battle_chusai.teamid_2_camp[team.id]	
		return camp
	else
		return 1
	end
end
-- 离开场景
-- 查看是否需要结束
function GangBattleChusaiService:afterLeaveScene(character, aoi_scene)
	if self:isFighting(aoi_scene) then 
		local ch_info = assert(self:getChBattleInfo(character, aoi_scene))
		if ch_info.lifes > 0 then 
			local camp = self:getCampBattleInfo(ch_info.camp, aoi_scene)
			camp.lifes = camp.lifes - ch_info.lifes
			self:sendBattleInfoUpdate(aoi_scene)
		end
	end
	-- 玩家满血
	ReliveService:characterFullHp(character)
	return true
end


--------------------------- 场景相关 [END] -------------------------------------

function GangBattleChusaiService:newChInfo(character, camp)
	local o = {}
	o.lifes = GangBattleConfig.chusai_player_life_num
	o.kill_num = 0
	o.camp = camp
	o.gang_id = character.gang_id
	o.gcid = character.gcid
	return o
end

-- 当玩家被杀
function GangBattleChusaiService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	if not self:isFighting( aoi_scene ) then 
		return 
	end	

	local killer_info = self:getChBattleInfo(fighter, aoi_scene)
	local killed_camp_info
	-- 减少被杀方的积分
	for _, player_aoi_id in pairs(arr_kill_player_aoi_id) do
		local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, player_aoi_id) 
		local killed_info = self:getChBattleInfo(killed_player, aoi_scene)
		killed_camp_info = killed_camp_info or self:getCampBattleInfo(killed_info.camp, aoi_scene)

		if killed_info.lifes > 0 then 
			killed_info.lifes = killed_info.lifes - 1
			killed_camp_info.lifes = killed_camp_info.lifes - 1
			killer_info.kill_num = killer_info.kill_num + 1
			self:sendChBattleInfo(killed_player, aoi_scene)
		else
			Logger:error('不应该有的生命', killed_player.nick)
		end
	end

	self:sendBattleInfoUpdate(aoi_scene)

	if killed_camp_info.lifes <= 0 then 
		self:finish(aoi_scene)
	end
end

--比赛结束
function GangBattleChusaiService:finish( aoi_scene )
	Logger:info('GangBattleChusaiService:finish>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
	local gang_battle_chusai = aoi_scene.gang_battle_chusai
	local camps = gang_battle_chusai.camps
	local gcid_2_info = gang_battle_chusai.gcid_2_info

	-- 计算胜利方阵营
	local win_camp = 0
	if camps[1].lifes ~= camps[2].lifes then 
		win_camp = camps[1].lifes > camps[2].lifes and 1 or 2
	end

	local finish_data = {}
	finish_data.win_camp = win_camp
	finish_data.camps = camps
	local team_ids = {}
	local team_nicks = {}
	for _, camp_info in pairs(camps) do
		-- 计算得分
		local chusai_reward = camp_info.camp == win_camp and GangBattleConfig.chusai_win_reward or GangBattleConfig.chusai_fail_reward
		local score = chusai_reward.score 
		camp_info.score = score

		-- 次数
		local team_id = camp_info.team_id
		team_ids[camp_info.team_id] = 2

		for _, member in pairs(camp_info.members) do
			local character = CharacterService:getCharacterByGcid(member.gcid)
			if character then 
				local en_count = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_GANG_BATTLE_CHUSAI)
				if team_ids[team_id] > en_count then 
					team_nicks[team_id] = character.nick
					team_ids[team_id] = en_count
				end
			else
				team_ids[team_id] = 0
			end

			-- 获取杀人数
			local ch_battle_info = gcid_2_info[member.gcid]
			if ch_battle_info then 
				member.kill_num = ch_battle_info.kill_num
			end
		end
	end
	do
		-- 通知base，活动结束
		ServerCall:m2bCall('GangBattleChusaiService:m2b_finish', 0, {team_ids = team_ids, nicks = team_nicks})	
	end

	local gpids = GameObjectService:getGPids(aoi_scene)
	self:sendFinish(gpids, finish_data)

	-- 到游戏服发奖
	do
		local reward_data = {}
		for _, ch_info in pairs(gcid_2_info) do
			local reward_item = {}
			reward_item.gcid = ch_info.gcid
			reward_item.gpid = ch_info.gpid
			reward_item.gang_id = ch_info.gang_id
			reward_item.is_win = win_camp == ch_info.camp
			table.insert(reward_data, reward_item)
		end

		local send_gpid = external.mergeUInt(gang_battle_chusai.area_id, 0)
		RewardService:reward(Statics.PK_GAME_TYPE_ID_GANG_BATTLE_CHUSAI, 0, send_gpid, nil, reward_data)
	end

	-- 清空数据
	aoi_scene.gang_battle_chusai = nil

	-- 设置所有玩家的阵营
	local characters = GameObjectService:getPlayerGameObjs(aoi_scene)
	for _, character in pairs(characters) do
		GameObjectService:updateZhenying(aoi_scene, character, 1, true)
	end

end

do
	local camp_2_tranfer_sortid = {
		[Statics.DEFAULT_ZHENYING_PLAYER] = 711004,
		[Statics.DEFAULT_ZHENYING_PLAYER_2] = 711005,
	}
	function GangBattleChusaiService:getRandomCampTransforIn(scene_id, camp)
		local transfer_base_id = camp_2_tranfer_sortid[camp]
		local pos = {}
		pos.x, pos.y = SceneAoiService:getRandomTransferIn( scene_id, transfer_base_id )
		return pos
	end
end
------------------------------- 数据相关 【BEG】 -----------------------------------

-- 查看是否还在战斗中
function GangBattleChusaiService:isFighting( aoi_scene )
	local gang_battle_chusai = aoi_scene.gang_battle_chusai
	if not gang_battle_chusai or gang_battle_chusai.is_finish then 
		return false
	end	
	return true
end

-- 是否在帮战初赛中
function GangBattleChusaiService:isInGangChusai( scene_id )
	return scene_id == GangBattleConfig.chusai_scene_id
end

-- base传来的对战信息
function GangBattleChusaiService:b2m_syncVsInfo(_, data)
	GangBattleChusaiDao.scene_insid_2_vs_info[data.space_id] = data
end

-- 
function GangBattleChusaiService:b2m_entryBattle(character, data)
	local space_id = data.space_id
	local line_id = data.line_id
	local camp = data.camp
	local pos = GangBattleChusaiService:getRandomCampTransforIn(GangBattleConfig.chusai_scene_id, camp)
	SceneService:moveScene(character, GangBattleConfig.chusai_scene_id, space_id, line_id, pos.x, pos.y)	
end

function GangBattleChusaiService:getChBattleInfo(character, aoi_scene)
	local gang_battle_chusai = aoi_scene.gang_battle_chusai
	return gang_battle_chusai.gcid_2_info[character.gcid]
end
function GangBattleChusaiService:getCampBattleInfo(camp, aoi_scene)
	local gang_battle_chusai = aoi_scene.gang_battle_chusai
	return gang_battle_chusai.camps[camp]
end
------------------------------- 数据相关 【END】 -----------------------------------------
------------------------------------------------------------------------------------------
-------------------------------------- 发送消息[BEG] -------------------------------------


do  -- 发送个人战斗信息
	local rsp_opcode = opCodes.PKM2C_GANG_CHUSAI_CH_BATTLE_INFO
	local msg_name = "PackGangBattleChusai.PKM2C_GANG_CHUSAI_CH_BATTLE_INFO"
	function GangBattleChusaiService:sendChBattleInfo(character, aoi_scene)
		local data = GangBattleChusaiService:getChBattleInfo(character, aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do  -- 发送完整战斗信息
	local rsp_opcode = opCodes.PKM2C_GANG_CHUSAI_FIGHT_INFO
	local msg_name = "PackGangBattleChusai.PKM2C_GANG_CHUSAI_FIGHT_INFO"
	function GangBattleChusaiService:sendBattleInfo(gpids, aoi_scene)
		local gang_battle_chusai = aoi_scene.gang_battle_chusai
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, gang_battle_chusai, nil, gpids)
	end
end

do -- 发送战斗信息更新
	local rsp_opcode = opCodes.PKM2C_GANG_CHUSAI_FIGHT_UPDATE
	local msg_name = "PackGangBattleChusai.PKM2C_GANG_CHUSAI_FIGHT_UPDATE"
	local data = {}
	function GangBattleChusaiService:sendBattleInfoUpdate(aoi_scene)
		local gpids = GameObjectService:getGPids(aoi_scene)
		local gang_battle_chusai = aoi_scene.gang_battle_chusai
		local camps = gang_battle_chusai.camps
		data.camp_1_lifes = camps[1].lifes
		data.camp_2_lifes = camps[2].lifes
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end	
end

do -- 发送战斗结果
	local rsp_opcode = opCodes.PKM2C_GANG_CHUSAI_FINISH
	local msg_name = "PackGangBattleChusai.PKM2C_GANG_CHUSAI_FINISH"
	function GangBattleChusaiService:sendFinish(gpids, data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end	
end