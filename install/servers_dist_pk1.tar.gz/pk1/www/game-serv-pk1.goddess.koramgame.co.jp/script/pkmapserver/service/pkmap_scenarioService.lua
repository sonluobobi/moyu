--[[
剧情系统servuce
author : xingzeng
date : 2014-08-15
]]--

local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local type = type
local opCodes = opCodes
local string_len = string.len
local math_random = math.random
local GameObjectService
local math_ceil = math.ceil
local AoiObjectType = AoiObjectType
local ScenarioDefs = ScenarioDefs
local next = next
local Time = Time

ScenarioService = ScenarioService or {}

function ScenarioService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
end

-- 初始化剧情状态
function ScenarioService:initScenarioState(aoi_scene, scenario_state_qe)
	-- 已经初始化过
	if type(aoi_scene.scenario_state_qe) == 'table' then
		return
	end
	
	aoi_scene.scenario_state_qe = scenario_state_qe
	
	local now_mtime = Time:getTimeNow()
	
	local scenario_time_qe = {}
	aoi_scene.scenario_time_qe = scenario_time_qe
	for idx, state in pairs(scenario_state_qe) do
		scenario_time_qe[idx] = now_mtime
	end
end

-- 设置状态
function ScenarioService:setScenarioState(aoi_scene, state_idx, state_from, state_to)
	local scenario_state_qe = aoi_scene.scenario_state_qe
	local scenario_time_qe = aoi_scene.scenario_time_qe
	local now_mtime = Time:getTimeNow()
	
	-- 未初始化
	if not scenario_state_qe or not scenario_time_qe then
		Logger:warn('[ScenarioService:setScenarioState] scenario_state_qe is nil', aoi_scene.scene_id, state_idx, state_from, state_to)
		return WorldPacket:m2cSendCommEmpty()
	end
	
	-- 检查开始状态是否一致
	if state_from ~= scenario_state_qe[state_idx] then
		return WorldPacket:m2cSendCommEmpty()
	end
	
	-- 设置状态
	scenario_state_qe[state_idx] = state_to
	scenario_time_qe[state_idx] = now_mtime
	
	-- RSP
	self:sendStateUpdate(aoi_scene, state_idx)
	
end

do
	local timer_pack_data = {}
	function ScenarioService:setScenarioTimer(character, aoi_scene, timer_id, state_idx, duration, can_add_time)
		local scenario_timers = aoi_scene.scenario_timers or {}
		local scenario_noend_timer_ids = aoi_scene.scenario_noend_timer_ids or {}
		aoi_scene.scenario_timers = scenario_timers
		aoi_scene.scenario_noend_timer_ids = scenario_noend_timer_ids
		assert(duration > 0)
		
		--不能重复设置
		if scenario_timers[timer_id] then
			return WorldPacket:m2cSendCommEmpty(character.gpid)
		end
		
		scenario_timer = {
			id = timer_id,
			is_end = 0,
			time_start = Time.time_now,
			time_end = Time.time_now + duration * 1000,
			
			state_idx = state_idx,
			can_add_time = can_add_time,
		}
		
		scenario_timers[timer_id] = scenario_timer
		scenario_noend_timer_ids[timer_id] = 1
		
		-- timer
		timer_pack_data.timer_id = timer_id
		timer_pack_data.space_id = aoi_scene.space_id
		ServerCall:addTimer('ScenarioService:onScenarioTimer', 0, timer_pack_data, duration * 1000, 1)
	
		-- RSP
		self:sendScenarioTimerUp(aoi_scene, scenario_timer)
	end
	
	function ScenarioService:onScenarioTimer(_, pack_data)
		local timer_id = pack_data.timer_id
		local aoi_scene = GameObjectService:getAoiSceneBySpaceId(pack_data.space_id)
		local scenario_timers = aoi_scene.scenario_timers
		local now_mtime = Time:getTimeNow()
		
		-- 未初始化
		if not scenario_timers then
			return Logger:warn('[ScenarioService:onScenarioTimer] scenario_timers is nil', pack_data)
		end
		
		local scenario_timer = scenario_timers[timer_id]
		
		-- 因结束时间已修改，尚未到结束，则重新设置定时器
		if scenario_timer.time_end > now_mtime+1 then
			timer_pack_data.timer_id = timer_id
			timer_pack_data.space_id = aoi_scene.space_id
			ServerCall:addTimer('ScenarioService:onScenarioTimer', 0, timer_pack_data, scenario_timer.time_end - Time.time_now, 1)
			return
		end
		
		-- 设置状态
		local state_idx = scenario_timer.state_idx
		if state_idx and state_idx > 0 then
			local scenario_state_qe = aoi_scene.scenario_state_qe
			local scenario_time_qe = aoi_scene.scenario_time_qe
	
			if scenario_state_qe[state_idx] == 0 then
				scenario_state_qe[state_idx] = 1
				scenario_time_qe[state_idx] = now_mtime
				self:sendStateUpdate(aoi_scene, state_idx)
			end
		end
		
		scenario_timer.is_end = 1
		aoi_scene.scenario_noend_timer_ids[timer_id] = nil
		
		-- RSP
		--self:sendScenarioTimerUp(aoi_scene, scenario_timer)
	end
end

function ScenarioService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(character)
	local scenario_state_qe = aoi_scene.scenario_state_qe
	if not scenario_state_qe or not next(scenario_state_qe) then
		return
	end
	
	if not arr_kill_monster_aoi_id or not next(arr_kill_monster_aoi_id) then
		return
	end
	
	local monsters = GameObjectService:getGameObjsByType(aoi_scene, AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER)
	local has_monster_phase_ids = {}
	for _, monster in pairs(monsters) do
		if monster.hp > 0 then
			local phase_id = monster.monster_aoi.phase_id
			if phase_id then
				has_monster_phase_ids[phase_id] = 1
			end
		end
	end
	
	local dead_add_ms_total = 0
	local finished_phase_ids = {}
	local finished_phases = aoi_scene.scenario_finished_phases or {}
	aoi_scene.scenario_finished_phases = finished_phases
	
	for _, aoi_id in pairs(arr_kill_monster_aoi_id) do
		local monster = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
		if monster then
			local phase_id = monster.monster_aoi.phase_id
			if not phase_id then
				Logger:debug('[ScenarioService:onKilledMonster]', character.id, character.nick, aoi_scene.scene_id, monster.monster_aoi)
			end
			-- 场景内已经没有该波怪物
			if phase_id and not has_monster_phase_ids[phase_id] then
				finished_phases[phase_id] = 1
				finished_phase_ids[#finished_phase_ids+1] = phase_id
			end
			
			dead_add_ms_total = dead_add_ms_total + (monster.monster_base.dead_add_ms or 0)
		end
	end
	
	if next(finished_phase_ids) then
		-- rsp
		ScenarioService:sendFinishPhases(aoi_scene, finished_phase_ids)
	end
	
	-- 如果怪物有延长定时器时间
	if dead_add_ms_total > 0 then
		local scenario_noend_timer_ids = aoi_scene.scenario_noend_timer_ids
		if scenario_noend_timer_ids then
			local scenario_timers = aoi_scene.scenario_timers
			for timer_id, _ in pairs(scenario_noend_timer_ids) do
				local timer = scenario_timers[timer_id]
				if timer and timer.can_add_time == 1 then
					timer.time_end = timer.time_end + dead_add_ms_total
					-- RSP
					self:sendScenarioTimerUp(aoi_scene, timer)
				end
			end
		end
	end
end

-- 获取波次信息
function ScenarioService:getPhaseInfo(aoi_scene, phase_id)
	local scenario_done_phases = aoi_scene.scenario_done_phases
	if not scenario_done_phases then
		return
	end
	return scenario_done_phases[phase_id]
end

-- 记录已触发的波次
function ScenarioService:recordPhaseInfo(aoi_scene, phase_id, phase_type_id, called_scene_aoi_infos, total_num)
	local scenario_done_phases = aoi_scene.scenario_done_phases or {}
	aoi_scene.scenario_done_phases = scenario_done_phases
	scenario_done_phases[phase_id] = {phase_id=phase_id, phase_type_id=phase_type_id, total_num = total_num, 
										called_scene_aoi_infos = called_scene_aoi_infos, called_num = table.sizeTable(called_scene_aoi_infos)}
end

-- 检查是否已触发过
function ScenarioService:isTriggered(aoi_scene, phase_id, phase_type_id)
	local scenario_done_phases = aoi_scene.scenario_done_phases
	if not scenario_done_phases or not scenario_done_phases[phase_id] then
		return false
	end
	
	local phase_info = scenario_done_phases[phase_id]
	if phase_type_id == ScenarioDefs.CALL_M_PHASE_TYPE_NORMAL then
		return phase_info and true or false
	elseif phase_type_id == ScenarioDefs.CALL_M_PHASE_TYPE_CIRCLE then
		return false
	elseif phase_type_id == ScenarioDefs.CALL_M_PHASE_TYPE_SIT_RAND then
		return (phase_info and phase_info.total_num <= phase_info.called_num) and true or false
	else
		error('[ScenarioService:isTriggered] phase_type_id is error.' .. phase_type_id)
	end
end

-- 发送当前剧情状态给客户端
do
	local rsp_opcode = opCodes.M2C_SCENARIO_INIT_STATES
	local msg_name = "PackScenario.M2C_SCENARIO_INIT_STATES"
	local msg_proto = {}
	function ScenarioService:sendScenarioState(character, aoi_scene)
		msg_proto.scene_ins_id = aoi_scene.space_id
		msg_proto.states = aoi_scene.scenario_state_qe
		msg_proto.times = aoi_scene.scenario_time_qe
		local scenario_finished_phases = aoi_scene.scenario_finished_phases
		msg_proto.finished_phase_ids = scenario_finished_phases and table.keys(scenario_finished_phases) or nil
		msg_proto.timer_infos = aoi_scene.scenario_timers or {}
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

-- 返回状态更新
do
	local rsp_opcode = opCodes.M2C_SCENARIO_UPDATE_STATE
	local msg_name = "PackScenario.M2C_SCENARIO_UPDATE_STATE"
	local msg_proto = {}
	function ScenarioService:sendStateUpdate(aoi_scene, state_idx)
		msg_proto.scene_ins_id = aoi_scene.space_id
		msg_proto.state_idx = state_idx - 1
		msg_proto.state = aoi_scene.scenario_state_qe[state_idx]
		local arr_gpids = GameObjectService:getGPids(aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, arr_gpids)
	end
end

do
	local rsp_opcode = opCodes.M2C_SCENARIO_FINISH_PHASE
	local msg_name = "PackScenario.M2C_SCENARIO_FINISH_PHASE"
	local msg_proto = {}
	function ScenarioService:sendFinishPhases(aoi_scene, phase_ids)
		msg_proto.scene_ins_id = aoi_scene.space_id
		msg_proto.phase_ids = phase_ids
		local arr_gpids = GameObjectService:getGPids(aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, arr_gpids)
	end
end

do
	local rsp_opcode = opCodes.M2C_SCENARIO_UPDATE_TIMER
	local msg_name = "PackScenario.M2C_SCENARIO_UPDATE_TIMER"
	local msg_proto = {}
	function ScenarioService:sendScenarioTimerUp(aoi_scene, scenario_timer)
		msg_proto.scene_ins_id = aoi_scene.space_id
		msg_proto.scenario_timer = scenario_timer
		local arr_gpids = GameObjectService:getGPids(aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, arr_gpids)
	end
end