--[[
角色幻兽系统 SERVICE
author : xingzeng.jiang
date : 2014-07-30
--]]

ChPetService = ChPetService or {}

local WorldPacket = WorldPacket
local Time = Time
local ext_getNowUnixMsTime = external.getNowUnixMsTime
local table = table
local ipairs = ipairs
local pairs = pairs
local obj_type_pet = AoiObjectType.AOI_OBJECT_TYPE_ID_PET
local ObjFightData = ObjFightData
local PetBaseDao = PetBaseDao
local EffectNamesForFight = EffectNamesForFight
local ChPet = ChPet
local ChPetSaveDbField = ChPetSaveDbField
local random = math.random
local next = next
local ceil = math.ceil
local PetDefs = PetDefs
local round = math.round
local in_table = table.find2
local HETI_POS_START = PetDefs.HETI_POS_START
local HETI_POS_END = PetDefs.HETI_POS_END
local EffectType = EffectType
local PetTianfuBaseDao = PetTianfuBaseDao

local HETI_POS_IN = PetDefs.HETI_POS_IN
local HETI_POS_OUT = PetDefs.HETI_POS_OUT

local AoiSceneService, AoiObject, MotionService
local GameObjectService, BufferService
function ChPetService:onAfterLoadLua()
	AoiSceneService = _G.AoiSceneService
	AoiObject = _G.AoiObject
	MotionService = _G.MotionService
	GameObjectService = _G.GameObjectService
	BufferService = _G.BufferService
end

function ChPetService:_genChPetId(character)
	local pets_info = character.pets
	pets_info.ch_petid_inc_start = pets_info.ch_petid_inc_start + 1
	return pets_info.ch_petid_inc_start
end

function ChPetService:init(character)
	local pets_info = character.pets
	if pets_info and pets_info ~= '' then
		pets_info = WorldPacket:decodeData(pets_info)
	else
		pets_info = ChPetsInfo:new()
	end
	
	character.pets = pets_info
	local PetBaseDao_data = PetBaseDao.data
	
	local ch_pets = pets_info.ch_pets
	if next(ch_pets) then
		local cid = character.id
		local gcid = character.gcid
		local gpid = character.gpid
		for _, ch_pet in pairs(ch_pets) do
			ch_pet.cid = cid
			ch_pet.gcid = gcid
			ch_pet.parent_gpid = gpid
			ch_pet.pet_base = assert(PetBaseDao_data[ch_pet.pet_id])
			ch_pet.star = ch_pet.huanhua_num * ch_pet.pet_base.add_star
		end
	end
	
	if not pets_info.en_own_pet_num then pets_info.en_own_pet_num = PetDefs.INIT_MAX_OWN_PET_NUM end
end

function ChPetService:setRobotAoiInfo(robot)
	local pets_info = robot.pets
	local ch_pets = pets_info.ch_pets
	if next(ch_pets) then
		local aoi_id = robot.aoi_id
		local space_id = robot.space_id
		for _, ch_pet in pairs(ch_pets) do
			ch_pet.robot_aoi_id = aoi_id
			ch_pet.robot_in_space_id = space_id
		end
	end
end

-- 初始化机器人角色幻兽数据
function ChPetService:initForRobot(character)
	local pets_info = character.pets
	if (type(pets_info) == "string" and string.len(pets_info) > 1) then
		pets_info = WorldPacket:decodeData(pets_info)
	end
	
	if type(pets_info) == 'table' then
		local fight_ch_pet_id = pets_info.fight_ch_pet_id
		local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
		local ch_pets = pets_info.ch_pets
		local arena_fight_ch_pet = fight_ch_pet_id and ch_pets[fight_ch_pet_id] or nil
		
		for _, ch_pet_t in pairs(ch_pets) do
			local pet_base = assert(PetBaseDao.data[ch_pet_t.pet_id])
			ch_pet_t.star = ch_pet_t.huanhua_num * pet_base.add_star
		end
		
		character.arena_fight_ch_pet = arena_fight_ch_pet
		character.fight_pet_id = arena_fight_ch_pet and arena_fight_ch_pet.pet_id or 0
		local heti_pet_ids = {}
		local heti_ch_pets = {}
		if heti_ch_pet_ids then
			for _, ch_pet_id in pairs(heti_ch_pet_ids) do
				if ch_pet_id > 0 then
					heti_pet_ids[#heti_pet_ids+1] = ch_pets[ch_pet_id].pet_id
					heti_ch_pets[#heti_ch_pets+1] = ch_pets[ch_pet_id]
				end
			end
		end
		character.heti_ch_pets = heti_ch_pets
		character.heti_pet_ids = heti_pet_ids
	elseif pets_info and pets_info ~= '' then
		Logger:fatal('[ChPetService:initForArena] pets_info is not table', type(pets_info), pets_info)
	end
	
	character.pets = nil
end

-- 获取角色幻兽对象
function ChPetService:getChPet(character, ch_pet_id)
	local pets_info = character.pets
	local ch_pets = pets_info.ch_pets
	local ch_pet = ch_pets[ch_pet_id]
	return ch_pet
end

-- 获取角色幻兽对象
function ChPetService:getChPetByPetId(character, pet_id)
	local pets_info = character.pets
	local ch_pets = pets_info.ch_pets
	for _, ch_pet in pairs(ch_pets) do
		if ch_pet.pet_id == pet_id then
			return ch_pet
		end
	end
end

-- 获取角色幻兽对象列表
function ChPetService:getChPetByIds(character, arr_ch_pet_id)
	local pets_info = character.pets
	local ch_pets = pets_info.ch_pets
	
	local arr_ch_pet = {}
	for _, ch_pet_id in pairs(arr_ch_pet_id) do
		local ch_pet = ch_pets[ch_pet_id]
		if ch_pet then
			arr_ch_pet[#arr_ch_pet+1] = ch_pet
		end
	end
	return arr_ch_pet
end

function ChPetService:getFightHetiCPets(character)
	local ch_pet_fight = self:getFightChPet(character)
	local ch_pet_hetis = self:getHeTiChPets(character)
	if ch_pet_hetis and ch_pet_fight then
		ch_pet_hetis[#ch_pet_hetis+1] = ch_pet_fight
	elseif ch_pet_fight then
		return {ch_pet_fight}
	end
	
	return ch_pet_hetis
end

function ChPetService:getFightChPet(character)
	local pets_info = character.pets
	local fight_ch_pet_id = pets_info.fight_ch_pet_id
	if fight_ch_pet_id and fight_ch_pet_id > 0 then
		return self:getChPet(character, fight_ch_pet_id)
	end
end

function ChPetService:getHeTiChPets(character)
	local pets_info = character.pets
	local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
	if heti_ch_pet_ids then
		local ch_pets = pets_info.ch_pets
		local heti_ch_pets = {}
		for _, ch_pet_id in pairs(heti_ch_pet_ids) do
			heti_ch_pets[#heti_ch_pets+1] = ch_pets[ch_pet_id]
		end
		return heti_ch_pets
	end
end

function ChPetService:getHeTiChPetIdByOrderBy(character, order_by)
	local pets_info = character.pets
	local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
	if heti_ch_pet_ids then
		local ch_pet = heti_ch_pet_ids[order_by]
		return ch_pet
	end
end

-- 获取合体的幻兽对象
-- order_by 合体位置ID 定义见  PetDefs.lua
-- return table:ChPet对象 / nil(没有合体幻兽返回为空)
function ChPetService:getHeTiChPetByOrderBy(character, order_by)
	local pets_info = character.pets
	local ch_pets = pets_info.ch_pets
	local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
	local heti_cpid = heti_ch_pet_ids and heti_ch_pet_ids[order_by] or 0
	if heti_cpid > 0 then
		return ch_pets[heti_cpid]
	end
end

-- 获取给角色的加成效果
function ChPetService:getEffectValuesForCharacter(character)
	local pets_info = character.pets
	local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
	local fight_ch_pet_id = pets_info.fight_ch_pet_id
	local ch_pets = pets_info.ch_pets
	local effect_values = {}
	
	local kill_force = 0
	if heti_ch_pet_ids then
		for _, ch_pet_id in pairs(heti_ch_pet_ids) do
			if ch_pet_id > 0 then
				local ch_pet = ch_pets[ch_pet_id]
				kill_force = kill_force + ch_pet.huanhua_num * ch_pet.pet_base.add_star
			end
		end
	end
	if fight_ch_pet_id and fight_ch_pet_id > 0 then
		local ch_pet = ch_pets[fight_ch_pet_id]
		kill_force = kill_force + ch_pet.huanhua_num * ch_pet.pet_base.add_star
	end
	effect_values.kill_force = kill_force
	
	return effect_values
end

function ChPetService:getOwnPetNum(character)
	local pets_info = character.pets
	local ch_pets = pets_info.ch_pets
	local size = 0
	for _, ch_pet in pairs(ch_pets) do
		size = size + 1
	end
	return size
end

-- 获取所有合体幻兽的总属性
-- return table  (eg: {max_attack=10,defence_magic=10,...})
--		  int : heti_pet_num
function ChPetService:getAllHeTiEffectValues(character)
	local pets_info = character.pets
	local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
	local effect_values = {}
	local heti_pet_num = 0
	
	if not heti_ch_pet_ids then
		return effect_values, heti_pet_num
	end
	
	for order_by, heti_cpid in pairs(heti_ch_pet_ids) do
		if heti_cpid > 0 then
			heti_pet_num = heti_pet_num + 1
			
			if order_by == HETI_POS_IN and character.hp2 > 0 then
				EffectType:sum(effect_values, pets_info.ch_pets[heti_cpid])
			elseif order_by == HETI_POS_OUT and character.hp3 > 0 then
				EffectType:sum(effect_values, pets_info.ch_pets[heti_cpid])
			end
		end
	end
	
	return effect_values, heti_pet_num
end

do
	local INIT_MAX_OWN_PET_NUM = PetDefs.INIT_MAX_OWN_PET_NUM
	-- 拥有幻兽数量是否已满
	function ChPetService:isOwnPetNumFull(character)
		local pets_info = character.pets
		local ch_pets = pets_info.ch_pets
		local size = 0
		for _, ch_pet in pairs(ch_pets) do
			size = size + 1
		end
		return size >= pets_info.en_own_pet_num, size
	end
end

-- 是否出战幻兽
function ChPetService:isFightPet(character, ch_pet_id)
	local pets_info = character.pets
	return ch_pet_id > 0 and pets_info.fight_ch_pet_id == ch_pet_id
end

-- 是否里、外合体幻兽
function ChPetService:isHetiPet(character, heti_order_by, ch_pet_id)
	local heti_ch_pet_ids = character.pets.heti_ch_pet_ids
	return heti_ch_pet_ids and ch_pet_id > 0 and ch_pet_id == heti_ch_pet_ids[heti_order_by]
end

function ChPetService:isHetiPetByChPet(game_obj)
	-- 不是幻兽对象
	if not game_obj.pet_base then
		return false
	end
	
	local character = self:getParentGameObj(game_obj)
	
	local heti_ch_pet_ids = character.pets.heti_ch_pet_ids
	local ch_pet_id = game_obj.id
	return heti_ch_pet_ids and ch_pet_id > 0 and 
		(ch_pet_id == heti_ch_pet_ids[HETI_POS_OUT] or ch_pet_id == heti_ch_pet_ids[HETI_POS_IN])
end

-- 获取幻兽的父game_obj对象
function ChPetService:getParentGameObj(game_obj)
	local character
	
	if game_obj.robot_aoi_id then
		local aoi_scene = GameObjectService:getAoiSceneBySpaceId(game_obj.robot_in_space_id)
		character = GameObjectService:getGameObjectByAoiId(aoi_scene, game_obj.robot_aoi_id)
	else
		character = CharacterService:getCharacterByGcid(game_obj.gcid)
	end
	
	return character
end

-- 获取幻兽天赋列表
function ChPetService:getTianfuIds(ch_pet)
	local tianfu_ids = {}
	local huanhua_tianfu_ids = ch_pet.pet_base.huanhua_tianfu_ids
	if huanhua_tianfu_ids then
		for huanhua_num, tianfu_ids_t in pairs(huanhua_tianfu_ids) do
			if ch_pet.huanhua_num >= huanhua_num then
				if type(tianfu_ids_t) == 'number' then
					tianfu_ids[#tianfu_ids+1] = tianfu_ids_t
				else
					for _, tianfu_id in ipairs(tianfu_ids_t) do
						tianfu_ids[#tianfu_ids+1] = tianfu_id
					end
				end
			end
		end
	end
	return tianfu_ids
end

-- 幻兽死亡触发的天赋加成
--[[ return pet_tianfu_effects = {
				[effect_type] = {effect_value1=xx, effect_value2=xx, effect_value3=xx},--注：该效果值的table不可以修改
				...
				}
--]]
function ChPetService:getTianfuEffectsForDead(ch_pet)
	local effect_values = ChPetService:getTianfuEffectsByChPet(ch_pet, nil, false, true, true)
	return effect_values
end

-- 获取合体幻兽的天赋加成
--[[ return fight_pet_tianfu_effects = {
				[effect_type] = {effect_value1=xx, effect_value2=xx, effect_value3=xx},--注：该效果值的table不可以修改
				...
				},
			heti_pet_tianfu_effects = {
				[effect_type] = {effect_value1=xx, effect_value2=xx, effect_value3=xx},--注：该效果值的table不可以修改
				...
				},
--]]
function ChPetService:getPetTianfuEffects(character)
	local pets_info = character.pets
	local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
	local ch_pets = pets_info.ch_pets
	local fight_pet_tianfu_effects, ht_pet_tianfu_effects = {}, {}
	
	-- 外层合体
	if heti_ch_pet_ids and character.hp3 > 0 then
		local ch_pet = ch_pets[heti_ch_pet_ids[PetDefs.HETI_POS_OUT] or 0]
		if ch_pet then
			self:getTianfuEffectsByChPet(ch_pet, ht_pet_tianfu_effects, false, true)
		end
	end
	
	-- 内层合体
	if heti_ch_pet_ids and character.hp2 > 0 then
		local ch_pet = ch_pets[heti_ch_pet_ids[PetDefs.HETI_POS_IN] or 0]
		if ch_pet then
			self:getTianfuEffectsByChPet(ch_pet, ht_pet_tianfu_effects, false, character.hp3 <= 0)
		end
	end
	
	-- 出战幻兽
	local ch_pet_fight = ch_pets[pets_info.fight_ch_pet_id or 0]
	if ch_pet_fight and ch_pet_fight.hp > 0 then
		self:getTianfuEffectsByChPet(ch_pet_fight, fight_pet_tianfu_effects, false, true)
	end
	
	-- 出战幻兽、与合体幻兽天赋替换
	local fight_pet_effect_master_types = PetConfig.fight_pet_effect_master_types
	for effect_type, effect_params in pairs(fight_pet_tianfu_effects) do
		if fight_pet_effect_master_types[effect_type] then
			local heti_effect_params = ht_pet_tianfu_effects[effect_type]
			if heti_effect_params then
				if heti_effect_params.effect_value1 >= effect_params.effect_value1 then
					fight_pet_tianfu_effects[effect_type] = nil
				else
					ht_pet_tianfu_effects[effect_type] = nil
				end
			end
		end
	end
	
	-- 物理伤害增加3x%，法术伤害增加x%，自身有增益buff，对物理伤害、法术伤害翻n倍
	local is_has_inc_buffer = BufferService:isHasIncBuffer(character)
	local f_harm_target_inc_buff_multi = fight_pet_tianfu_effects.harm_target_inc_buff_multi
	if f_harm_target_inc_buff_multi and is_has_inc_buffer then
		f_harm_target_inc_buff_multi.effect_value1 = f_harm_target_inc_buff_multi.effect_value1 * f_harm_target_inc_buff_multi.effect_value3
		f_harm_target_inc_buff_multi.effect_value2 = f_harm_target_inc_buff_multi.effect_value2 * f_harm_target_inc_buff_multi.effect_value3
	end
	local ht_harm_target_inc_buff_multi = ht_pet_tianfu_effects.harm_target_inc_buff_multi
	if ht_harm_target_inc_buff_multi and is_has_inc_buffer then
		ht_harm_target_inc_buff_multi.effect_value1 = ht_harm_target_inc_buff_multi.effect_value1 * ht_harm_target_inc_buff_multi.effect_value3
		ht_harm_target_inc_buff_multi.effect_value2 = ht_harm_target_inc_buff_multi.effect_value2 * ht_harm_target_inc_buff_multi.effect_value3
	end
	
	-- 删除天赋触发次数已满的效果
	self:_delTianfuTriggeredFull(character, ht_pet_tianfu_effects)
	self:_delTianfuTriggeredFull(ch_pet_fight, fight_pet_tianfu_effects)
	
	return fight_pet_tianfu_effects, ht_pet_tianfu_effects
end

function ChPetService:getTianfuEffectsByChPet(ch_pet, effect_values, is_yiji_effect, is_shouji, is_dead)
	local tianfu_ids = self:getTianfuIds(ch_pet)
	local PetTianfuBaseDao_data = PetTianfuBaseDao.data
	local effect_values = effect_values or {}
	local PET_HT_TIANFU_EFFECT_SORT_SHOUJI = PetDefs.PET_HT_TIANFU_EFFECT_SORT_SHOUJI
	local PET_HT_TIANFU_ACTIVE_SORT_LIVE = PetDefs.PET_HT_TIANFU_ACTIVE_SORT_LIVE
	local PET_TIANFU_SORT_ID_NORMAL = PetDefs.PET_TIANFU_SORT_ID_NORMAL
	local special_effects_fc_total = 0
	
	if tianfu_ids and next(tianfu_ids) then
		for _, tianfu_id in ipairs(tianfu_ids) do
			if tianfu_id > 0 then
				local tianfu_base = PetTianfuBaseDao_data[tianfu_id]
				if tianfu_base.sort_id == PET_TIANFU_SORT_ID_NORMAL then
					local effect_id, effect_type = EffectType[tianfu_base.effect_type], tianfu_base.effect_type
					-- 基础效果 (叠加处理)
					if is_yiji_effect then
						if effect_type == 'attack' then
							effect_values.min_attack = (effect_values.min_attack or 0) + tianfu_base.effect_value1
							effect_values.max_attack = (effect_values.max_attack or 0) + tianfu_base.effect_value2
						elseif EffectType:isYiJiEffect(effect_id) or effect_type == 'attack_perc' then
							local effect_value = effect_values[effect_type] or 0
							effect_values[effect_type] = effect_value + tianfu_base.effect_value1
						end
						
					-- 特殊效果tianfus_used_times
					elseif effect_type ~= 'attack' then
						if not EffectType:isYiJiEffect(effect_id) then
							local is_ok = false
							if is_dead then
								if tianfu_base.is_dead_trigger == 1 then
									is_ok = true
								end
							elseif tianfu_base.is_dead_trigger ~= 1 then
								if (is_shouji and tianfu_base.heti_active_sort == PET_HT_TIANFU_EFFECT_SORT_SHOUJI) or 
									tianfu_base.heti_active_sort == PET_HT_TIANFU_ACTIVE_SORT_LIVE then
									is_ok = true
								end
							end
							
							if is_ok then
								local effect_params = effect_values[effect_type] or {}
								effect_values[effect_type] = effect_params
								local effect_value = effect_params.effect_value1 or 0
								
								-- 效果叠加
								if tianfu_base.is_leijia_effect_value1 == 1 then
									effect_params.effect_value1 = (effect_params.effect_value1 or 0) + tianfu_base.effect_value1 
								-- 取最大值
								else
									if effect_value < tianfu_base.effect_value1 then
										effect_params.effect_value1 = tianfu_base.effect_value1
									end
								end
								effect_params.effect_value2 = tianfu_base.effect_value2
								effect_params.effect_value3 = tianfu_base.effect_value3
								effect_params.effect_value4 = tianfu_base.effect_value4
							end
						end
					end
				end
				
				special_effects_fc_total = special_effects_fc_total + tianfu_base.fight_capacity
			end
		end
	end
	
	return effect_values, special_effects_fc_total
end

-- 删除天赋触发次数已满的效果
function ChPetService:_delTianfuTriggeredFull(character, tianfu_effect_values)
	if tianfu_effect_values.kill_add_hp_perc_or_relive then
		local tianfus_triggered_times = character.tmps.tianfus_triggered_times
		if tianfus_triggered_times then
			local kill_add_hp_perc_or_relive = tianfus_triggered_times.kill_add_hp_perc_or_relive or 0
			if kill_add_hp_perc_or_relive >= PetConfig.tf_trigger_times_limit then
				tianfu_effect_values.kill_add_hp_perc_or_relive = nil
			end
		end
	end
end

-- 是否合同或出战幻兽
function ChPetService:isHetiOrFightPet(character, ch_pet_id)
	local pets_info = character.pets
	if ch_pet_id <= 0 then
		return false
	end
	
	if pets_info.fight_ch_pet_id == ch_pet_id then
		return true
	end
	
	local heti_ch_pet_ids = character.pets.heti_ch_pet_ids
	if heti_ch_pet_ids then
		for _, cpid in pairs(heti_ch_pet_ids) do
			if cpid == ch_pet_id then
				return true
			end
		end
	end
	
	return false
end

-- 更新侠客属性 : 增加侠客数值
-- ch_pet			侠客对象
-- key				字段名
-- add_value		增加的值
-- is_send			是否发更新侠客属性包给客户端
function ChPetService:incPetAttrib(character, ch_pet, key, add_value, is_send)
	if 'number' ~= type(add_value) then
		error("错误，调用incPetAttrib方法的参数不是数值类型 : " .. add_value)
	end
	
	-- 检查键名是否存在
	if not ChPet[key] then
		error("错误，不存在的幻兽属性名 : " .. tostring(key))
	end
	
	-- 如果已死亡，不能回血
	if key == 'hp' and ch_pet.hp <= 0 then
		return
	end
	
	local old_exp = ch_pet.exp
	
	local value = ch_pet[key]
	if value then
		if 'number' ~= type(value) then
			error("错误，调用incPetAttrib方法的键值不是数值类型 : [" .. key .. "] = " .. value)
		end

		local new_value = value + add_value
		
		if new_value < 0 then
			new_value = 0
		end
		
		-- 赋新值(强制变成整数)
		ch_pet[key] = ceil(new_value)
		
		-- 幻兽星数联动修改
		if key == 'huanhua_num' then
			ch_pet.star = ch_pet.huanhua_num * ch_pet.pet_base.add_star
		end
	else
		error("错误，角色不存在该属性 : " .. key)
	end
	
	-- 侠客获得经验满值限制
	if key == 'exp' then
		if ch_pet.level >= ch_pet.max_level then
			Logger:error('[ChPetService:incPetAttrib] cannot add exp.', character.id, character.player_id, ch_pet.id, ch_pet.level)
			error("错误：幻兽已满级，不能加经验")
			
		end
	end
	
	if is_send then
		self:sendChPetUpdate(character, ch_pet, key)
	end
	
	if ChPetSaveDbField[key] then
		if key == 'exp' and add_value <= 5000 then
			return
		end
		CharacterService:key2Dirty(character, 'pets')
	end
end

-- 更新角色对象上的合体幻兽的最大/当前血量
do
	local up_keys = {'hp2', 'max_hp2', 'hp3', 'max_hp3'}
	function ChPetService:updateHetiPetHpInCh(character, is_full_hp, is_send)
		local heti_ch_pet_ids = character.pets.heti_ch_pet_ids
		if heti_ch_pet_ids then
			local ch_pet_id_in = heti_ch_pet_ids[HETI_POS_IN]
			local ch_pet_id_out = heti_ch_pet_ids[HETI_POS_OUT]
			if ch_pet_id_in and ch_pet_id_in > 0 then
				local ch_pet = self:getChPet(character, ch_pet_id_in)
				character.max_hp2 = ch_pet.max_hp
				if is_full_hp or character.hp2 > character.max_hp2 then
					character.hp2 = character.max_hp2 
				end
			else
				character.hp2 = 0
				character.max_hp2 = 0
			end
			
			if ch_pet_id_out and ch_pet_id_out > 0 then
				local ch_pet = self:getChPet(character, ch_pet_id_out)
				character.max_hp3 = ch_pet.max_hp
				if is_full_hp or character.hp3 > character.max_hp3 then
					character.hp3 = character.max_hp3
				end
			else
				character.hp3 = 0
				character.max_hp3 = 0
			end
			
			CharacterService:key2Dirty(character, up_keys)
			if is_send then
				CharacterService:sendCharacterUpdate(character, up_keys)
			end
		end
	end
end

-- 响应出战幻兽的死亡处理
-- 注：调用该接口时，可能在之前有调用过 hideFightPet
function ChPetService:onDead(ch_pet)
	local aoi_scene = GameObjectService:getAoiScene(ch_pet)
		
	-- 预备死亡
	self:preDead(ch_pet, aoi_scene, 4)
	
	self:clearTianfuTriggered(ch_pet)
	
	-- 触发天赋
	self:triggerTianfuByDead(ch_pet, aoi_scene)
end

-- 响应合体幻兽死亡
function ChPetService:onDeadForHeti(ch_pet)
	-- 触发天赋
	self:triggerTianfuByDead(ch_pet)
end

-- 将出战幻兽从场景中删除
-- is_reset_fight_pet 是否重置出战幻兽为空
function ChPetService:hideFightPet(character, aoi_scene, is_reset_fight_pet)
	local pets_info = character.pets
	local fight_ch_pet_id = pets_info.fight_ch_pet_id
	if fight_ch_pet_id and fight_ch_pet_id > 0 then
		local ch_pet = pets_info.ch_pets[fight_ch_pet_id]
		if ch_pet and ch_pet.aoi_obj then
			if not aoi_scene then aoi_scene = AoiSceneService:getAoiScene(character.space_id) end
			if aoi_scene:getObj(ch_pet.aoi_obj.obj_id) then
				GameObjectService:delObj(ch_pet, aoi_scene)
			end
		end
	end
	
	-- 重置出战幻兽为空
	if is_reset_fight_pet then
		pets_info.fight_ch_pet_id = 0
	end
end

function ChPetService:showFightPet(character, aoi_scene)
	local pets_info = character.pets
	local fight_ch_pet_id = pets_info.fight_ch_pet_id
	if fight_ch_pet_id and fight_ch_pet_id > 0 then
		local ch_pet = pets_info.ch_pets[fight_ch_pet_id]
		if ch_pet then
			local aoi_id = ch_pet.aoi_id
			aoi_scene = aoi_scene or AoiSceneService:getAoiScene(character.space_id)
			if not aoi_id or aoi_id <= 0 or not GameObjectService:isVisible(ch_pet, aoi_scene) then
				-- 初始化侠客
				ChPet:init(character, ch_pet, ch_pet.pet_base)
				
				-- 阵营设置
				GameObjectService:updateZhenying(aoi_scene, ch_pet, character.tmps.zhenying)
				
				-- 加入AOI
				local ch_aoi_obj = character.aoi_obj
				local x, y = aoi_scene:randPos(ch_aoi_obj.x, ch_aoi_obj.y, 2)
				local aoi_obj = AoiObject:new(obj_type_pet, x, y, ch_aoi_obj.direction, ch_pet, aoi_scene)					
				GameObjectService:addObj(ch_pet, aoi_obj, aoi_scene)
				
			end
		end
	end
end

do
	local Effectid2name = Effectid2name
	function ChPetService:_getHuanhuaAddiEffects(ch_pet)
		local star = ch_pet.huanhua_num * ch_pet.pet_base.add_star
		local huanhua_addi_effects = ch_pet.pet_base.huanhua_addi_effects
		if huanhua_addi_effects then
			local effect_values = {}
			
			for _, huanhua_addi_effect in pairs(huanhua_addi_effects) do
				if huanhua_addi_effect.star <= star then
					local effect_type, effect_value = huanhua_addi_effect.effect_type, huanhua_addi_effect.effect_value
					effect_values[effect_type] = (effect_values[effect_type] or 0) + effect_value
				end
			end
			
			return effect_values
		end
	end
end

do
	function ChPetService:setHetiPet(character, order_by, ch_pet_id)
		local pets_info = character.pets
		
		-- 非主城场景不能合体
		if not SceneBaseService:isMainCity(character.scene_id) then
			return false, errorCodes.CH_PET_HETI_NEED_IN_MCITY
		end
		
		if ch_pet_id > 0 then
			-- 检查合体侠客是否拥有
			local ch_pet = self:getChPet(character, ch_pet_id)
			if not ch_pet then
				return false, errorCodes.CH_PET_NO_OWN
			end
		end
		
		if order_by < HETI_POS_START or order_by > HETI_POS_END then
			return false, '[ChPetService:setHetiPet] param order_by err.' .. order_by
		end
		
		-- 检查该侠客是否在出战
		if ch_pet_id > 0 and ch_pet_id == pets_info.fight_ch_pet_id then
			-- 收回旧出战幻兽
			self:hideFightPet(character)
			pets_info.fight_ch_pet_id = 0
			ChPetService:sendPetFightSet(character, 0)
		end
		
		local heti_ch_pet_ids = pets_info.heti_ch_pet_ids or {}
		pets_info.heti_ch_pet_ids = heti_ch_pet_ids
		
		-- 检查该侠客已经合体
		if ch_pet_id > 0 then
			for order_by_t, ch_pet_id_t in pairs(heti_ch_pet_ids) do
				if order_by_t ~= order_by and ch_pet_id_t == ch_pet_id then
					-- 取消合体
					heti_ch_pet_ids[order_by_t] = 0
					self:sendPetHeTiSet(character, order_by_t, 0)
					break
				end
			end
		end
		
		local old_heti_ch_pet_id = heti_ch_pet_ids[order_by]
		heti_ch_pet_ids[order_by] = ch_pet_id
		
		self:updateHetiPetHpInCh(character, true, true)
		
		CharacterService:key2Dirty(character, 'pets')
		
		self:sendPetHeTiSet(character, order_by, ch_pet_id)
		
		return true
	end
end

function ChPetService:setFightPet(character, ch_pet_id)
	local pets_info = character.pets
	local ch_pet
	
	local old_fight_ch_pet_id = pets_info.fight_ch_pet_id or 0
	
	-- 出战
	if ch_pet_id > 0 then
		-- 检查合体侠客是否拥有
		ch_pet = self:getChPet(character, ch_pet_id)
		if not ch_pet then
			return false, errorCodes.CH_PET_NO_OWN
		end
	
		-- 防御型幻兽不能出战
		if not PetDefs.enable_fight_pet_sort_ids[ch_pet.pet_base.sort_id] then
			return false, errorCodes.CH_PET_FIGHT_PET_SORT_ERR
		end
	
		-- 判断是否已合体
		local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
		if heti_ch_pet_ids then
			-- 检查该侠客已经合体
			for order_by_t, ch_pet_id_t in pairs(heti_ch_pet_ids) do
				if ch_pet_id_t == ch_pet_id then
					-- 合体下阵
					heti_ch_pet_ids[order_by_t] = 0
					self:sendPetHeTiSet(character, order_by_t, 0)
					break
				end
			end
		end
		
		-- 收回旧出战幻兽
		self:hideFightPet(character)
		
		-- 设置新的出战幻兽
		pets_info.fight_ch_pet_id = ch_pet_id
		
		-- 幻兽加入AOI
		self:showFightPet(character)
		
		-- 计算新出战幻兽属性
		ChPetService:calcChPetEffectValues(character, ch_pet)
		
	-- 回收出战
	else
		-- 收回旧出战幻兽
		self:hideFightPet(character)
		pets_info.fight_ch_pet_id = 0
	end
	
	-- 重算旧的出战幻兽属性
	if old_fight_ch_pet_id > 0 then
		local ch_pet = self:getChPet(character, old_fight_ch_pet_id)
		ChPetService:calcChPetEffectValues(character, ch_pet)
	end
	
	CharacterService:key2Dirty(character, 'pets')
	
	-- RSP
	self:sendPetFightSet(character, ch_pet_id)
	
		
	return true
end

function ChPetService:update(time_now, aoi_scene, objs_pets)
	for _, game_obj in pairs(objs_pets) do
		local aoi_obj = game_obj.aoi_obj
		
		-- 移动中
		if MotionService:isMoving(game_obj) then
			-- 移动更新
			MotionService:updateObject(aoi_scene, game_obj)
		end
		
		-- 删除已死亡的
		if Time.is_second_start then
			local pre_dead_cpets = aoi_scene.pre_dead_cpets
			if pre_dead_cpets then
				for gcid, cpet_info in pairs(pre_dead_cpets) do
					if cpet_info.dead_mtime <= time_now then
						local ch_pet = GameObjectService:getGameObjectByAoiId(aoi_scene, cpet_info.aoi_id)
						if ch_pet then GameObjectService:delObj(ch_pet, aoi_scene) end
						pre_dead_cpets[gcid] = nil
					end
				end
			end
		end
	end
end

-- aoi_scene	可传空
-- delay_dead_sec	延迟死亡删除的时间(秒)
function ChPetService:preDead(ch_pet, aoi_scene, delay_dead_sec)
	local aoi_scene = aoi_scene or GameObjectService:getAoiScene(ch_pet)
	local pre_dead_cpets = aoi_scene.pre_dead_cpets or {}
	aoi_scene.pre_dead_cpets = pre_dead_cpets
	
	local old_cpet_info = pre_dead_cpets[ch_pet.gcid]
	if old_cpet_info then
		local ch_pet = GameObjectService:getGameObjectByAoiId(aoi_scene, old_cpet_info.aoi_id)
		if ch_pet then GameObjectService:delObj(ch_pet, aoi_scene) end
	end
	
	pre_dead_cpets[ch_pet.gcid] = {id=ch_pet.id, aoi_id=ch_pet.aoi_id, parent_aoi_id=ch_pet.parent_aoi_id,
				dead_mtime=Time.time_now + delay_dead_sec * 1000}
end

-- 记录天赋已触发次数
function ChPetService:recordTianfuTriggered(game_obj, tianfu_effect_type)
	if tianfu_effect_type == 'kill_add_hp_perc_or_relive' then
		local tmps = game_obj.tmps
		local tianfus_triggered_times = tmps.tianfus_triggered_times or {}
		tmps.tianfus_triggered_times = tianfus_triggered_times
		tianfus_triggered_times.kill_add_hp_perc_or_relive = (tianfus_triggered_times.kill_add_hp_perc_or_relive or 0) + 1
	end
end

-- 清空天赋已触发次数(主角死亡的时候调用)
function ChPetService:clearTianfuTriggered(game_obj)
	local tianfus_triggered_times = game_obj.tmps.tianfus_triggered_times
	if tianfus_triggered_times then
		tianfus_triggered_times.kill_add_hp_perc_or_relive = 0
	end
end

-- 触发天赋
function ChPetService:triggerTianfuByDead(ch_pet, aoi_scene)
	-- BUFFER类天赋
	local tianfu_ids = self:getTianfuIds(ch_pet)
	if tianfu_ids then
		local PetTianfuBaseDao_data = PetTianfuBaseDao.data
		local PET_TIANFU_SORT_ID_BUFFER = PetDefs.PET_TIANFU_SORT_ID_BUFFER
		local character = self:getParentGameObj(ch_pet)
		if not character then Logger:error('[triggerTianfuByDead] character is nil', ch_pet, ch_pet.gcid) end
		local aoi_scene = aoi_scene or GameObjectService:getAoiScene(character)
		
		for _, tianfu_id in ipairs(tianfu_ids) do
			local tianfu_base = PetTianfuBaseDao_data[tianfu_id]
			if tianfu_base.sort_id == PET_TIANFU_SORT_ID_BUFFER then
				local buffer_base = BufferBaseService:getBufferBaseById(tianfu_base.buffer_id)
				local is_ok, is_bc_other = BufferService:addTmpBuffer(character, buffer_base)
				if not is_ok then
					Logger:debug('[ChPetService:triggerTianfu] add buffer fail', character.id, character.gpid, character.nick, buffer_base.id)
				end
				if is_bc_other then
					BufferService:bcBuffers(aoi_scene, character)
				end
			end
		end
	end
end

do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort
	local writeCoord = FastPacket.writeCoord	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	local math_floor = math.floor
	
	-- 写入基础外观
	function ChPetService:writeObjAppear(ch_pet, fast_packet)
		writeByte(fast_packet, math_floor((ch_pet.speed or 0) * 10))
		writeLong(fast_packet, ch_pet.hp)
		writeUInt(fast_packet, ch_pet.pet_base.id)				-- base_id
		writeUInt(fast_packet, ch_pet.parent_aoi_id or 0)		-- parent_aoi_id
	end
	
	-- 写入详细外观
	function ChPetService:writeObjAppearDetail(ch_pet, fast_packet)
		
		writeLong(fast_packet, ch_pet.max_hp)
		writeUInt(fast_packet, ch_pet.star or 0)
		writeByte(fast_packet, ch_pet.jieshu or 0)
	end
end

do
	function ChPetService:_formatChPetForPack(ch_pets)
		local ch_pets_new = {}
		for _, ch_pet in pairs(ch_pets) do
			local ch_pet_new = {}
			for field, _ in pairs(ChPetSaveDbField) do
				ch_pet_new[field] = ch_pet[field]
			end
			ch_pets_new[ch_pet.id] = ch_pet_new
		end
		return ch_pets_new
	end
	
	local pack_data = {}
	function ChPetService:pack(character)
		local pets_info = character.pets
		
		-- 注意是upvalue,别随意新增添加字段，然后热更新
		pack_data.ch_pets = self:_formatChPetForPack(pets_info.ch_pets)
		pack_data.fight_ch_pet_id = pets_info.fight_ch_pet_id
		pack_data.heti_ch_pet_ids = pets_info.heti_ch_pet_ids
		pack_data.ch_petid_inc_start = pets_info.ch_petid_inc_start
		pack_data.itembars = pets_info.itembars
		pack_data.troop_chpet_ids = pets_info.troop_chpet_ids
		
		local str = WorldPacket:encodeData(pack_data)
		return str
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_ALLINFO_GET
	local msg_name = "PackChPet.M2C_CH_PET_ALLINFO_GET"
	local msg_proto = {}
	function ChPetService:sendPetAllInfo(character)
		local pets_info = character.pets
		local ch_pets = pets_info.ch_pets
		
		local msg_proto = msg_proto
		msg_proto.arr_ch_pet = table.values(ch_pets)
		msg_proto.fight_ch_pet_id = pets_info.fight_ch_pet_id
		msg_proto.heti_ch_pet_ids = pets_info.heti_ch_pet_ids
		msg_proto.en_own_pet_num = pets_info.en_own_pet_num
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_ADD
	local msg_name = "PackChPet.M2C_CH_PET_ADD"
	local msg_proto = {}
	function ChPetService:sendPetAdd(character, ch_pet)
		msg_proto.ch_pet = ch_pet
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_UPDATE
	local msg_name = 'PackChPet.M2C_CH_PET_UPDATE'
	local msg_proto = {}
	
	function ChPetService:sendChPetUpdate(character, ch_pet, keys)
		local ch_pet_new = {}
		msg_proto.ch_pet = ch_pet_new
		ch_pet_new.id = ch_pet.id
		ch_pet_new.pet_id = ch_pet.pet_id
		
		if type(keys) == 'string' then
			local key = keys
			ch_pet_new[key] = ch_pet[key]
			if key == 'huanhua_num' then ch_pet_new.star = ch_pet.star end
		else			
			for _, key in ipairs(keys) do
				ch_pet_new[key] = ch_pet[key]
				if key == 'huanhua_num' then ch_pet_new.star = ch_pet.star end
			end
		end
		
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_OTHER_INFO_UPDATE
	local msg_name = 'PackChPet.M2C_CH_PET_OTHER_INFO_UPDATE'
	local msg_proto = {}
	
	function ChPetService:sendChPetsOtherInfoUpdate(character, keys)
		local msg_proto = msg_proto
		local pets_info = character.pets
		
		if type(keys) == 'string' then
			msg_proto[keys] = pets_info[keys]
		else			
			for _, key in ipairs(keys) do
				msg_proto[key] = pets_info[key]
			end
		end
		--Logger:debug("aaaaaaaaaaaaa msg_proto", msg_proto)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_EAT
	local msg_name = "PackChPet.M2C_CH_PET_EAT"
	local msg_proto = {}
	function ChPetService:sendPetEat(character, ch_pet_id)
		msg_proto.ch_pet_id = ch_pet_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_BREAK_LEVEL
	local msg_name = "PackChPet.M2C_CH_PET_BREAK_LEVEL"
	local msg_proto = {}
	function ChPetService:sendPetBreakLevel(character, ch_pet_id)
		msg_proto.ch_pet_id = ch_pet_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_UPGRADE
	local msg_name = "PackChPet.M2C_CH_PET_UPGRADE"
	local msg_proto = {}
	function ChPetService:sendPetUpgrade(character, ch_pet_id)
		msg_proto.ch_pet_id = ch_pet_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_CHAOS_CONFIRM
	local msg_name = "PackChPet.M2C_CH_PET_CHAOS_CONFIRM"
	local msg_proto = {}
	function ChPetService:sendPetChaosConfirm(character, ch_pet_id, is_replace)
		msg_proto.ch_pet_id = ch_pet_id
		msg_proto.is_replace = is_replace
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_CHAOS
	local msg_name = "PackChPet.M2C_CH_PET_CHAOS"
	local msg_proto = {}
	function ChPetService:sendPetChaos(character, ch_pet_id, chaos_num)
		msg_proto.ch_pet_id = ch_pet_id
		msg_proto.chaos_num = chaos_num
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_HUANHUA
	local msg_name = "PackChPet.M2C_CH_PET_HUANHUA"
	local msg_proto = {}
	function ChPetService:sendPetHuanhua(character, ch_pet_id, huanhua_type, cl_ch_pet_id)
		msg_proto.ch_pet_id = ch_pet_id
		msg_proto.huanhua_type = huanhua_type
		msg_proto.cl_ch_pet_id = cl_ch_pet_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end


do
	local rsp_opcode = opCodes.M2C_CH_PET_SET_HETI_PET
	local msg_name = "PackChPet.M2C_CH_PET_SET_HETI_PET"
	local msg_proto = {}
	function ChPetService:sendPetHeTiSet(character, order_by, ch_pet_id)
		msg_proto.order_by = order_by
		msg_proto.ch_pet_id = ch_pet_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_SET_FIGHT_PET
	local msg_name = "PackChPet.M2C_CH_PET_SET_FIGHT_PET"
	local msg_proto = {}
	function ChPetService:sendPetFightSet(character, ch_pet_id)
		msg_proto.ch_pet_id = ch_pet_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_FIGHT_HETI_PETS
	local msg_name = "PackChPet.M2C_CH_PET_FIGHT_HETI_PETS"
	local msg_proto = {}
	
	function ChPetService:sendGetFightHetiPets(character)
		local fight_ch_pet = self:getFightChPet(character)
		local heti_ch_pets = self:getHeTiChPets(character)
				
		msg_proto.fight_ch_pet = fight_ch_pet
		msg_proto.heti_ch_pets = heti_ch_pets
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_DETAIL_GET
	local msg_name = "PackChPet.M2C_CH_PET_DETAIL_GET"
	local msg_proto = {}
	function ChPetService:sendGetChPetDetail(character, ch_pet)
		msg_proto.ch_pet = ch_pet
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_FREE
	local msg_name = "PackChPet.M2C_CH_PET_FREE"
	local msg_proto = {}
	function ChPetService:sendPetsFree(character, arr_ch_pet_id, fanhuan_equips, free_op_id)
		msg_proto.arr_ch_pet_id = arr_ch_pet_id
		msg_proto.free_op_id = free_op_id and free_op_id or PetDefs.FREE_PET_OP_ID_JITAN_XIANJI
		msg_proto.fanhuan_equips = (fanhuan_equips and next(fanhuan_equips)) and fanhuan_equips or nil
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_FREE_GET_FANHUAN
	local msg_name = "PackChPet.M2C_CH_PET_FREE_GET_FANHUAN"
	local msg_proto = {}
	function ChPetService:sendPetsFreeFanhuan(character, arr_ch_pet_id, fanhuan_equips)
		msg_proto.arr_ch_pet_id = arr_ch_pet_id
		msg_proto.fanhuan_equips = fanhuan_equips
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_PET_FREE_GET_FANHUAN_SHOUHUN
	local msg_name = "PackChPet.M2C_CH_PET_FREE_GET_FANHUAN_SHOUHUN"
	local msg_proto = {}
	function ChPetService:sendFreePetsFanhuanShouhun(character, cpid2shouhun)
		msg_proto.cpid2shouhun = cpid2shouhun
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end