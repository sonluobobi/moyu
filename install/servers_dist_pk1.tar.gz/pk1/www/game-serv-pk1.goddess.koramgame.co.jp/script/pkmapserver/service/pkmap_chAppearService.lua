--[[
衣厨系统 SERVICE
author : guoyin.huang	
date : 2015-12-1
--]]

ChAppearService = ChAppearService or {}

function ChAppearService:init( character )
	local appear = character.appear
	if type(appear) == 'string' and string.len(appear) > 3 then
		appear = WorldPacket:decodeData(appear)
	else
		appear = nil
	end

	appear = appear or {}

	character.appear = appear
	return true	
end

-- 打包
function ChAppearService:pack( character )
	return WorldPacket:encodeData(character.appear)
end

-- 获取需要显示的衣服或者时装eid
function ChAppearService:getYifuOrAvatarEid(character)
	local aoi_scene = GameObjectService:getAoiScene(character)
	local scene_base = aoi_scene.scene_base
	
	-- 已经在主城
	local ch_appear = character.appear
	if SceneDefs:isNormalScene(scene_base) then	
		return ch_appear.avatar or 0
	end
	return self:getYifuOrAvatarForFight(ch_appear)
end

-- 获取战斗状态下的时装或衣服eid
function ChAppearService:getYifuOrAvatarForFight( appear )
	local equip_base = EquipBaseService:getEquipBaseById(appear.avatar)
	if appear.avatar then
		-- 战斗场景，不显示婚纱时装
		local equip_base = EquipBaseDao.data[appear.avatar]
		local equip_sort_id = equip_base and equip_base.equip_sort_id or 0
		local sub_sort_id = equip_base and equip_base.sub_sort_id or 0
		if sub_sort_id == EquipDefs.EQUIP_SUB_SORT_ID_LOVERS and equip_sort_id == EquipDefs.EQUIP_SORT_ID_AVATAR then
			return appear.yifu_id or 0
		end
	end
	return appear.avatar or 0
end