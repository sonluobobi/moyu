--[[
角色系统
author : suwin zhong
date : 2014-10-22
--]]

local WorldPacket = WorldPacket
local Time = Time

local ostime = os.time
local pairs = pairs
local type = type
local Character = Character
local assert = assert
local next = next
local EffectType = EffectType
local CharacterDefs = CharacterDefs
local errorCodes = errorCodes
local Logger = Logger
local ceil = math.ceil

CharacterService = CharacterService or {}


local FightService

-- 加载完所有lua文件后执行
function CharacterService:onAfterLoadLua()
	FightService = _G.FightService
end


-- 初始化数据
function CharacterService:init(character)
	local tmps_ex = character.tmps_ex
	if tmps_ex and 'string' == type(tmps_ex) then
		character.tmps_ex = WorldPacket:decodeData(tmps_ex)
	end
end


-- 初始化对象
function CharacterService:initObject(character, is_login)
	-- 角色数据
	self:init(character)
	
	-- 技能
	ChSkillService:init(character)
	
	-- 场景信息
	SceneService:init(character)
	
	-- 需要带到跨服的计数器信息
	CounterService:init(character)

	-- 坐骑
	ChHorseService:init(character, is_login)
	
	-- 幻兽
	ChPetService:init(character)

	-- 跨服PK
	PkServerService:init(character) 
	
	-- 安全模式、红名
	SafeModeService:init(character)

	-- 角色外观
	ChAppearService:init( character )

	-- 成就系统
	AchieveService:init( character, is_login )
	
	-- 杀人广播init
	WanfaKillService:init( character, is_login )
end


-- 离开场景的时候要做的事
function CharacterService:afterLeaveScene(character, aoiScene)
	-- 删除掉召唤物
	BeastService:delAllMyBeast(aoiScene, character)

	-- 删除掉陷阱
	TrapService:delMyTrap(character, aoiScene)
end


do
	-- 获取角色 by gcid
	local externalGetCharacterByGcid = external.getCharacterByGcid
	function CharacterService:getCharacterByGcid(gcid)
		return externalGetCharacterByGcid(gcid)
	end
	
	local mergeUInt = external.mergeUInt
	function CharacterService:getCharacterByCidAreaId(cid, area_id)
		local gcid = mergeUInt(area_id, cid)
		return externalGetCharacterByGcid(gcid)
	end

	-- 获取角色 by nick
	-- local externalGetCharacterByNick = external.getCharacterByNick
	function CharacterService:getCharacterByNick(nick)
		error("CharacterService:getCharacterByNick，跨服环境下不能用该接口，因为不同服存在同名字的玩家")
		if type(nick) ~= 'string' then
			return
		end
		return externalGetCharacterByNick(nick)
	end
end


do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort
	local writeCoord = FastPacket.writeCoord	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	local math_floor = math.floor
	local ext_set_bit = external.set_bit
	
	-- 写入基础外观
	function CharacterService:writeObjAppear(character, fast_packet)
		writeByte(fast_packet, math_floor((character.speed or 0) * 10))
		writeLong(fast_packet, character.hp)
		writeUInt(fast_packet, 0)				-- base_id
		writeUInt(fast_packet, 0)				-- parent_aoi_id
		writeLong(fast_packet, character.hp2)	-- 合体里位的幻兽 当前血量
		writeLong(fast_packet, character.hp3)	-- 合体外位的幻兽 当前血量
	end
	
	-- 写入详细外观
	function CharacterService:writeObjAppearDetail(character, fast_packet)
		local appear = character.appear
		writeLong(fast_packet, character.max_hp)
		writeString(fast_packet, character.nick)
		writeByte(fast_packet, character.prof)	-- prof
		writeByte(fast_packet, character.gender)				-- gender
		writeUInt(fast_packet, appear.weaponid) -- weaponid
		writeUInt(fast_packet, ChAppearService:getYifuOrAvatarForFight( appear ))	-- avatar
		
		local horses_info = character.horses
		writeUInt(fast_packet, horses_info.is_ride == 1 and (horses_info.ride_horse_id or 0) or 0)
		writeLong(fast_packet, character.max_hp2)	-- 合体里位的幻兽 最大血量
		writeLong(fast_packet, character.max_hp3)	-- 合体外位的幻兽 最大血量
		writeByte(fast_packet, character.level)
		writeUInt(fast_packet, appear.wing_base_id)	--翅膀
		writeLong(fast_packet, character.gcid)
		
		local sys_protect_expire = character.tmps.sys_protect_expire or 0
		local relive_protect_expire = character.tmps.relive_protect_expire or 0
		local now_skin_equip_id = horses_info.is_ride == 1 and (horses_info.skin_equip_id or 0) or 0
		
		local bits = 0
		if sys_protect_expire > 0 then
			bits = ext_set_bit(bits, 0, 1)
		end
		if relive_protect_expire > 0 then
			bits = ext_set_bit(bits, 1, 1)
		end
		if now_skin_equip_id > 0 then
			bits = ext_set_bit(bits, 2, 1)
		end
		writeByte(fast_packet, bits)
		if sys_protect_expire > 0 then
			writeLong(fast_packet, sys_protect_expire)
		end
		if relive_protect_expire > 0 then
			writeLong(fast_packet, relive_protect_expire)
		end
		if now_skin_equip_id > 0 then
			writeUInt(fast_packet, now_skin_equip_id)
		end
		
		writeUInt(fast_packet, appear.title_id)					-- 称号
		writeUInt(fast_packet, character.gang_id)	-- 帮会
		writeUInt(fast_packet, character.area_id)	-- 大区ID
		writeUInt(fast_packet, appear.qihun_wuqi)	-- 器魂武器
		writeUInt(fast_packet, appear.qihun_yifu)	-- 器魂衣服
		writeUShort(fast_packet, appear.ns_id or 0)		-- 跟随女神ID
		writeUShort(fast_packet, appear.ns_lv or 0)		-- 跟随女神等级		
		writeString(fast_packet, character.gang_title or '')-- 军团名称
		writeUShort(fast_packet, character.gang_job or 0)	--军团职业
		writeByte(fast_packet, character.vip or 0)			--VIP
		writeUShort(fast_packet, appear.badge_id or 0)		--军团微章
		writeByte(fast_packet, appear.gang_type or 0)		--是否VIP军团
		writeUInt(fast_packet, appear.shenbing or 0) 		--神兵
		writeString(fast_packet, LoversService:getLoverNick(character) or '')	--情侣
		writeUInt(fast_packet, 0)		-- 精灵
	end
	
	
	-- 获取外观基础数据(不含血量、等级、昵称)
    function CharacterService:getAppearBaseData(character)
        local appear_base_data = {}
        local appear = character.appear
        appear_base_data.prof = character.prof
        appear_base_data.gender = character.gender
        appear_base_data.weaponid = appear.weaponid
        appear_base_data.avatar = appear.avatar
        appear_base_data.ride_horse_id = character.horses.ride_horse_id or 0
        appear_base_data.wing_base_id = appear.wing_base_id
        appear_base_data.full_jl_lev = 0
        appear_base_data.qihun_wuqi = appear.qihun_wuqi or 0
        appear_base_data.qihun_yifu = appear.qihun_yifu or 0
        appear_base_data.shenbing = appear.shenbing or 0
        return appear_base_data
    end
end


-- 角色数据迁移(地图服务器切换时角色数据的迁移)
do
	local empty = {}
	local arr_params = {}
	function CharacterService:buildInitData(character, initData)
		-- 打包角色属性
		arr_params.character = self:builtMoveCharacter(character)

		-- initData的内存结构
		initData:writeTable(arr_params)
		initData:writeTable(empty)

		return initData
	end
end


-- 角色数据打包
do
	local type = type
	function CharacterService:packKey(character, key)

		local val = character[key] or nil
		local type_v = type(val)
		
		if type_v == 'number' or type_v == 'string' then
			return val
		end
		
		if type_v == 'table' then
			if 'skills' == key then				-- 技能打包(国印)
				val = ChSkillService:pack(character)
			elseif 'packages' == key then		-- 角色包裹打包(小蒋)
				val = ChItemPackageService:pack(character)
			elseif 'items' == key then			-- 角色装备栏打包(小蒋)
				val = ChItemBarService:pack(character)
			elseif 'ch_equips' == key then		-- 角色道具打包(小蒋)
				val = ChEquipService:pack(character)
			elseif 'item_strongs_info' == key then	-- 装备栏强化信息(富千)
				val = ChItemBarStrongService:pack(character)
			elseif 'horses' == key then			-- 坐骑打包
				val = ChHorseService:pack(character)
			elseif 'pets' == key then			-- 幻兽打包
				val = ChPetService:pack(character)
			elseif 'scenes' == key then			-- 场景(小蒋)
				val = SceneService:pack(character)
			elseif 'tollgates' == key then		-- 关卡(小蒋)
				val = TollgateService:pack(character)
			elseif 'rewards' == key then 		-- 奖励(国印)
				val = RewardService:pack(character)
			elseif 'pet_refresh' == key then 	-- 幻兽刷新(富千)
				val = ChPetRefreshService:pack(character)
			elseif 'pets_equip' == key then		-- 幻兽装备(国印)
				val = ChPetEquipService:pack(character)
			elseif 'counters' == key then		-- 计数器(国印)
				val = CounterService:pack(character)
			elseif 'tasks' == key then 			-- 任务系统(国印)
				val = ChTaskService:pack(character)		
			elseif 'gangs' == key then			-- 军团(富千)
				val = GangService:pack(character)
			elseif 'titles' == key then 
				val = ChTitleService:pack(character)
			elseif 'appear' == key then 		-- 衣厨（国印）
				val = ChAppearService:pack( character )
			elseif 'global_pk' == key then 		-- 跨服PK字段
				val = PkServerService:pack( character )
			elseif 'tmps_ex' == key then
				val = WorldPacket:encodeData(val)
			elseif 'kill_notice' == key then
                val = WanfaKillService:pack( character )
			elseif 'safe_mode_info' == key then
				val = SafeModeService:pack(character)
			elseif 'achieves' == key then 		-- 目标系统（国印）
				val = AchieveService:pack(character)
			else
				Logger:warn("谁忘记打包了 : ", key, debug_traceback(2, 6))
				return nil
			end
			
			return val
		end
		
		if type_v == 'nil' then
			return ''
		end
				
		error("error key type:[" .. key .. ']|[' .. type_v ..']')
	end


	-- 打包mapserver之间迁移的角色数据
	function CharacterService:builtMoveCharacter(character)
		character.tmps_ex.appear_dirty = character.tmps.appear_dirty
		
		local pack_character = {}
		for k, v in pairs(character) do
			if self:canPackToMove(k) then
				pack_character[k] = self:packKey(character, k)
			end
		end
		return pack_character
	end


	-- mapserver切换不需要打包的字段
	local no_need_pack_move_fields = 
	{
		c_obj = true,
		tmps = true,
		aoi_obj = true,
		aoi_id = true,
		aoi_type = true,	
		gcid = true,
		gpid = true,
		space_id = true,
	}

	-- 判断 属性 是否可以场景迁移
	function CharacterService:canPackToMove(key)
		if no_need_pack_move_fields[key] then return false end
		return true
	end
end


-- 角色属性置脏
do
	-- key : 可以是数组或者是单个字符串
	function CharacterService:key2Dirty(character, key)
		print("跨服的不要调用该接口，请删除掉调用：CharacterService:key2Dirty", key)
		traceback()
	end

	function CharacterService:saveDirtyToDB(character, save_type)
		print("跨服的不要调用该接口，请删除掉调用：CharacterService:saveDirtyToDB")
		traceback()
	end
end
------------------------------------------------------------------------- to check

do
	--判断角色时候可以进行某个操作/行为
	function CharacterService:canDo(character, do_type)
		-- 场景移动或走路
		if do_type == CharacterDefs.DO_TYPE_FOR_MOVE then
			-- 已死亡
			if character.hp <= 0 then
				return false, errorCodes.SCENE_ERROR_OBJ_DAED
			end
			
			-- 眩晕中不能移动
			if BufferService:isInStatus(character, EffectType.giddiness) then
				return false, errorCodes.SCENE_MOVE_CANNOT_GIDDINESS
			end

			-- 被锁定过程中不能移动
			if FightService:isSkillLocked(character) then
				return false, errorCodes.SCENE_MOVE_CANNOT_LIANJI
			end
		end

		return true
	end
end


do
	-- 角色是否在保护中
	function CharacterService:isProtected(object)
		-- local
		local objectTmps = object.tmps
		local time_now = Time.time_now

		local relive_protect_expire = objectTmps.relive_protect_expire or 0
		local sys_protect_expire = objectTmps.sys_protect_expire or 0

		if relive_protect_expire > time_now then
			return true
		elseif sys_protect_expire > time_now then
			return true
		end

		return false
	end

	-- 保护角色
	-- second : 保护多少秒
	local CharacterDefs_PROTECT_TYPE_ID_FOR_RELIVE = CharacterDefs.PROTECT_TYPE_ID_FOR_RELIVE
	local CharacterDefs_PROTECT_TYPE_ID_FOR_ENTER_SCENE = CharacterDefs.PROTECT_TYPE_ID_FOR_ENTER_SCENE
	function CharacterService:protect(protect_type_id, character, second)
		local second = second or 0

		-- 死亡复活
		if CharacterDefs_PROTECT_TYPE_ID_FOR_RELIVE == protect_type_id then
			character.tmps.relive_protect_expire = Time.time_now + (second * 1000)
		-- 进入场景
		elseif CharacterDefs_PROTECT_TYPE_ID_FOR_ENTER_SCENE == protect_type_id then
			character.tmps.sys_protect_expire = Time.time_now + (second * 1000)
		else
			print("CharacterService:isProtected 有错误，未知的保护类型")
		end

		GameObjectService:appearDirty(character)
	end
	
	-- 取消保护
	function CharacterService:cancelProtect(protect_type_id, character, is_all_cancel)
		-- 必须本身是在保护状态的
		if self:isProtected(character) then
			local is_all_cancel = is_all_cancel or false
			local characterTmps = character.tmps
			if is_all_cancel then
				characterTmps.relive_protect_expire = 0 -- 复活保护
				characterTmps.sys_protect_expire = 0	 -- 移动保护
			else
				if CharacterDefs_PROTECT_TYPE_ID_FOR_ENTER_SCENE == protect_type_id then
					characterTmps.sys_protect_expire = 0 -- 移动保护
				else
					print("CharacterService:cancelProtect 有错误，未知的取消保护类型")
				end
			end

			GameObjectService:appearDirty(character)
		end
	end
end


do
	local GAME_OBJECT_STATUS_ID_DEAD = Statics.GAME_OBJECT_STATUS_ID_DEAD

	-- 改变角色状态
	function CharacterService:changeState(character, state)
		local character_tmps = character.tmps
		
		-- 更新状态
		character_tmps.now_state = state
		
		if state == GAME_OBJECT_STATUS_ID_DEAD then
			-- 普通复活需要10秒
			character_tmps.now_state_expire = (CharacterDefs.RELIVE_CD_SECONDS - 1) * 1000

			-- 取消掉服务端触发战斗状态
			character_tmps.in_server_fight = FightDefs.FIGHT_IN_SERVER_GUIDE_SKILL_NO
		else
			character_tmps.now_state_expire = 0
		end
	end


	-- 让角色直接死亡
	local to_dead_keys = {'hp', 'hp2', 'hp3'}
	function CharacterService:toDead(character)
		-- 血变0
		character.hp = 0
		character.hp2 = 0
		character.hp3 = 0

		-- 调用死亡通知
		FightService:characterDead(character)

		-- 通知客户端血变0
		local aoiScene = GameObjectService:getAoiScene(character)
		local arr_pid = GameObjectService:getFovGPids(character)
		GameObjectService:sendDead(aoiScene, character, arr_pid)
	end
end


-- 发送角色基本数据到客户端
do
	local rsp_opcode = opCodes.M2C_CHARACTER_GET_CHARACTER_BASE
	local msg_name = 'PackCharacter.M2C_CHARACTER_GET_CHARACTER_BASE'
	local rsp_msg = {ch = {}}
	local msg_ch = rsp_msg.ch
	
	function CharacterService:sendCharacterBase(character)
		-- 注意：如果减少字段赋值，需要重启游戏，热更新会有问题，因为是同享table
		msg_ch.gcid = character.gcid
		msg_ch.id = character.id
		msg_ch.aoi_id = character.aoi_id
		msg_ch.now_state = character.tmps.now_state
		msg_ch.now_state_expire = character.hp <= 0 and character.tmps.now_state_expire or nil
		msg_ch.protect_expire = character.tmps.protect_expire
		
		msg_ch.nick = character.nick				-- 昵称
		msg_ch.gender = character.gender			-- 性别
		msg_ch.prof = character.prof
		msg_ch.level = character.level				-- 等级
		
		-- msg_ch.exp = character.exp					-- 经验值(跨服里不发这个，因为没迁移数据)
		-- msg_ch.upgrade_exp = character.upgrade_exp	-- 升级到下一级需要的经验值(跨服里不发这个，因为没迁移数据)

		msg_ch.vip = character.vip
		msg_ch.valid = character.valid				-- 角色是否有效(有效1，删除0)	
		
		-- msg_ch.ban_type = character.ban_type		-- 是否被封停(0 : 正常，1 : 封停, 2：禁言)(跨服里不发这个，因为没迁移数据)
		-- msg_ch.ban_expire = character.ban_expire	-- 封停的过期时间(跨服里不发这个)

		msg_ch.picture = character.picture			-- 头像
		msg_ch.res_id = character.res_id			-- 角色外形部件(发型，肤色.....)		
		msg_ch.body_size = character.body_size		-- 角色尺寸(坐骑可以修改该值)
		msg_ch.model_times = character.model_times	-- 角色身体大小的基数(默认1)
		msg_ch.model_times_expire = character.model_times_expire	-- 当角色身体大小的基数不等于1的时候的过期时间

		-- msg_ch.gold = self:getGold(character)	-- (跨服里不发这个，因为没迁移数据)
		-- msg_ch.game_gold = character.game_gold	-- (跨服里不发这个，因为没迁移数据)
		-- msg_ch.silver = character.silver			-- 银两(跨服里不发这个，因为没迁移数据)
		-- msg_ch.vit = character.vit				-- 体力(跨服里不发这个，因为没迁移数据)
		-- msg_ch.endurance = character.endurance	-- 耐力(跨服里不发这个，因为没迁移数据)

		msg_ch.gang_id = character.gang_id
		msg_ch.shouhun = character.shouhun          -- 兽魂
		msg_ch.contribute = character.contribute 	-- 军功

		msg_ch.speed = character.speed				-- 速度
		
		msg_ch.hp = character.hp					-- 生命值
		msg_ch.max_hp = character.max_hp			-- 最大生命值
		msg_ch.hp2 = character.hp2					-- 生命值2
		msg_ch.max_hp2 = character.max_hp2			-- 最大生命值2
		msg_ch.hp3 = character.hp3					-- 生命值3
		msg_ch.max_hp3 = character.max_hp3			-- 最大生命值3
		
		msg_ch.max_attack = character.max_attack				-- 最大攻击
		msg_ch.min_attack = character.min_attack				-- 最小攻击
		msg_ch.defence_phy = character.defence_phy				-- 物理防御
		msg_ch.defence_magic = character.defence_magic			-- 魔法防御
		msg_ch.douzhi = character.douzhi						-- 斗志
		msg_ch.critical_hit = character.critical_hit			-- 暴击
		msg_ch.dodge = character.dodge							-- 闪避
		msg_ch.parry = character.parry							-- 格挡
		msg_ch.addi_harm = character.addi_harm					-- 附伤 附加伤害绝对值
		msg_ch.addi_harm_perc = character.addi_harm_perc		-- 加伤 增加百分比伤害
		msg_ch.reduce_harm = character.reduce_harm				-- 减伤：降低伤害绝对值
		msg_ch.reduce_harm_perc = character.reduce_harm_perc	-- 免伤：降低百分比伤害
		msg_ch.kill_force = character.kill_force				-- 斩杀力
		msg_ch.luck = character.luck							-- 幸运
		
		msg_ch.fight_capacity = character.fight_capacity		 -- 战力
		msg_ch.top_fight_capacity = character.top_fight_capacity -- 历史最高战力

		-- table.dump(msg_ch, -1)
		
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, rsp_msg, nil, character.gpid)
	end
end


-- 发送角色属性变更到客户端
do	
	local rsp_opcode = opCodes.M2C_CHARACTER_UPDATE_ATTRIB
	local msg_name = 'PackCharacter.M2C_CHARACTER_UPDATE_ATTRIB'
	local rsp_msg = {}
	function CharacterService:sendCharacterUpdate(character, keys)
		local msg_ch = {}
		rsp_msg.ch = msg_ch
		msg_ch.gcid = character.gcid
		if type(keys) == 'string' then
			if keys == 'gold' then
				msg_ch[keys] = self:getGold(character)
			else
				msg_ch[keys] = character[keys]
			end
		else			
			for _, key in pairs(keys) do
				if key == 'gold' then
					msg_ch[key] = self:getGold(character)
				else
					msg_ch[key] = character[key]
				end
			end
		end
		table.dump(msg_ch,-1)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, rsp_msg, nil, character.gpid)
	end
	
	
	-- 发送传进来的属性更新
	function CharacterService:sendCharacterUpdate2(character, up_params)
		rsp_msg.ch = up_params
		up_params.gcid = character.gcid
		
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, rsp_msg, nil, character.gpid)
	end
end


-- 更新角色属性
do
	-- character
	-- key : 角色属性
	-- add_value : 增量值
	-- is_send : 是否更新到客户端
	function CharacterService:incCharacterAttrib(character, key, add_value, is_send)
		if key == 'gold' then
			error('不能修改gold字段')
		end
	
		if 'number' ~= type(add_value) then
			error("传进来的不是数值类型 :" .. key ..'='.. type(add_value))
		end
	
		if add_value == 0 then
			Logger:debug('[CharacterService:incCharacterAttrib] add_value == 0', character.player_id, character.id, key, add_value)
			return
		end
	
		local value = character[key]
		if not value then
			error("不是角色身上的属性 :" .. key)
		end
			
		if 'number' ~= type(value) then
			error("角色身上该属性不是数值型的 :" .. key .. "=" .. type(value))
		end
	
		local new_value = value + add_value
		local max_limit_value = new_value
	
		if 'exp' == key then max_limit_value = CharacterDefs.MAX_LIMIT_EXP end
		if 'silver' == key then max_limit_value = CharacterDefs.MAX_LIMIT_SILVER end
		if 'game_gold' == key then max_limit_value = CharacterDefs.MAX_LIMIT_GOLD end
		if 'contribute' == key then max_limit_value = CharacterDefs.MAX_LIMIT_CONTRIBUTE end

		if new_value > max_limit_value then
			new_value = max_limit_value
		end
	
		if new_value < 0 then
			new_value = 0
		end
	
		-- 赋新值(强制变成整数)(跨服取消)
		-- self:key2Dirty(character,key)
		
		if is_send then
			self:sendCharacterUpdate(character,key)
		end
	end
end


do
	-- 获取角色元宝数(充值元宝数+游戏内赠送的元宝数)
	function CharacterService:getGold(character)
		local gold = character.game_gold + character.gold
		return gold
	end


	-- 获取角色充值元宝数
	function CharacterService:getVoucherGold(character)
		local gold = character.gold
		return gold
	end
end

---------------------------------------------- 帧更新 start ------------------------------------------------------------
-- 帧更新
do
	-- now_time : 当前系统时间
	-- aoiScene : 场景实例对象
	-- arr_character : 场景实例里的角色对象
	local next = next
	local floor = math.floor
	local CHARACTER_VIT_RESTORE_INTERVAL = CharacterDefs.CHARACTER_VIT_RESTORE_INTERVAL
	local CHARACTER_ENDURANCE_RESTORE_INTERVAL = CharacterDefs.CHARACTER_ENDURANCE_RESTORE_INTERVAL
	local MAX_LIMIT_VIT = CharacterDefs.MAX_LIMIT_VIT
	local MAX_LIMIT_ENDURANCE = CharacterDefs.MAX_LIMIT_ENDURANCE
	function CharacterService:update(now_time, aoiScene, arr_character)
		-- local
		local MotionService = MotionService
		
		local update_character_num = 0 -- 本次更新了多少人
		local is_200ms_start = Time.is_second_start -- 距离上一次调用是否过了200毫秒
		local is_second_start = Time.is_second_start -- 距离上一次调用是否过了1秒
		local is_10s_start = Time.is_10s_start		 -- 距离上一次调用是否过了10秒
		local is_minute_start = Time.is_minute_start -- 距离上一次调用是否过了1分钟
		local now_second = Time.time_second          -- 当前时间(秒)
		
		for _, now_character in pairs(arr_character) do
			update_character_num = update_character_num + 1

			-- local
			local now_character_tmps = now_character.tmps
			local now_character_tmps_ex = now_character.tmps_ex

			-- 帧更新
			------------------------------- 角色状态机处理 start -----------------------------------
			-- 移动中(移动和攻击是可以同时存在的)
			if MotionService:isMoving(now_character) then
				-- 移动更新
				MotionService:updateObject(aoiScene, now_character)
			end

			if self:inServerFightState(now_character) then
				-- 角色处于服务端触发的战斗状态中
				FightService:serverFight(aoiScene, now_character)
			end
			------------------------------- 角色状态机处理 end -------------------------------------

			-- 200毫秒更新
			if is_200ms_start then
			end

			-- 秒更新
			if is_second_start then
				if not SceneDefs:isInShengcun(aoiScene) then
					-- 角色定时自动回血
					self:autoRestoreHp(aoiScene, now_character, now_second)
				end
			end

			-- 10s更新
			if is_10s_start then
			end
			
			-- 1分更新
			if is_minute_start then
			end
		end
		
		return update_character_num
	end


	-- 判断角色是否在战斗状态中(由服务端触发的引导类技能中)
	local FIGHT_IN_SERVER_GUIDE_SKILL_YES = FightDefs.FIGHT_IN_SERVER_GUIDE_SKILL_YES
	function CharacterService:inServerFightState(character)
		-- local
		local in_server_fight = character.tmps.in_server_fight or 0
		if FIGHT_IN_SERVER_GUIDE_SKILL_YES == in_server_fight then
			return true
		end

		return false
	end


	-- 角色定时自动回血
	function CharacterService:autoRestoreHp(aoiScene, character, now_second)
		-- 不能是死亡状态
		if not FightService:isDead(character) then
			-- 角色回血技能
			local restoreHpSkill = ChSkillService:getChDetailAutoSkillInfo(character)
			if restoreHpSkill then
				local character_tmps_ex = character.tmps_ex
				local next_hp_resotre_second = character_tmps_ex.next_hp_resotre_second or 0
				-- 时间到了
				if next_hp_resotre_second < now_second then
					-- 先更新下一次时间
					local auto_restore_hp_second = 5 -- (方毅确认 : 5秒自动恢复一次)
					character_tmps_ex.next_hp_resotre_second = now_second + auto_restore_hp_second

					-- 替角色加血
					local hp_index, hp_key, max_hp_key = FightService:getHpInfo(character)
					local character_now_hp = character[hp_key]
					local character_now_max_hp = character[max_hp_key]
					if character_now_hp < character_now_max_hp then
						-- 没有满血，则帮忙加血
						local skillDetail = restoreHpSkill.skill_detail
						local auto_add_hp_rate = skillDetail.extra_target_effect and skillDetail.extra_target_effect.auto_add_hp_rate or 1
						local add_hp = ceil(auto_add_hp_rate * character.level)
						character_now_hp = character_now_hp + add_hp
						if character_now_hp > character_now_max_hp then
							character_now_hp = character_now_max_hp
						end
						character[hp_key] = character_now_hp

						local arr_aoi_change_hp = {FightService:newObjChangeHp(character.aoi_id, hp_index, add_hp, character_now_hp)}
						-- local arr_gpid = {character.gpid}
						-- FightService:sendObjsChangeHp(aoiScene, character, arr_aoi_change_hp, arr_gpid)
						FightService:sendObjsChangeHp(aoiScene, character, arr_aoi_change_hp)
					end
				end
			end
		end
	end
end
---------------------------------------------- 帧更新 end --------------------------------------------------------------
