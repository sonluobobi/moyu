--[[
公告系统service层
author : guoyin.huang
date : 2015-05-08
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local Statics = Statics
local Utils = Utils
local table = table
local Logger = Logger
local WorldPacket = WorldPacket
local externalSplitUInt=external.splitUInt
local seceneid_2_killconfig = WanfaKillDefs.seceneid_2_killconfig

local E_FC_CONT_KILL_TIME = 'cont_time_num'
local E_FC_CONTINUE_KILL  = 'continue_num'
local E_FC_KILL_NUM  = 'kill_num'


WanfaKillService = WanfaKillService or {}

function WanfaKillService:init( character, is_login )
    local kill_noticestr = character.kill_notice
    local kill_notice
    if not kill_noticestr or type(kill_noticestr) == 'string' and string.len(kill_noticestr) > 3 then 
        kill_notice = WorldPacket:decodeData(kill_noticestr) or {}
    else
        kill_notice = {}
    end 
   
    character.kill_notice = kill_notice
end


function WanfaKillService:pack( character )
    if character.kill_notice then
        return WorldPacket:encodeData(character.kill_notice)
    end
    return ""
end

-- 当玩家被杀时，计算是否需要杀人广播
function WanfaKillService:onPlayerKilled(scene_id, fighter, arr_kill_player_aoi_id )
	-- 非角色杀人，不广播
	local is_player = fighter.tmps_ex
	if not is_player then 
		return
	end
	
	-- 只处理部分场景
	local killconfig = seceneid_2_killconfig[scene_id]
	if not killconfig then return end

	local aoi_scene = GameObjectService:getAoiScene(fighter)
	-- 检查杀字
	self:checkShowKill( aoi_scene, fighter )

	-- 先出击杀广播
	self:checkNormalKill( aoi_scene, fighter, arr_kill_player_aoi_id )

	-- 检查首杀
	self:checkFirstKill(aoi_scene, fighter)

	-- 检查终结连杀
	self:checkEndContinueKill(aoi_scene, fighter, arr_kill_player_aoi_id)

	-- 检查连杀
	self:checkContinueKill(aoi_scene, fighter, arr_kill_player_aoi_id)
	
	-- 检查总杀人数
	self:checkTotalKill( aoi_scene, fighter, arr_kill_player_aoi_id )
	
	-- 检查军团杀人广播
	self:checkGangKill( aoi_scene, fighter, arr_kill_player_aoi_id )
	
	-- 排行榜上的玩家被杀广播
	self:checkRankKill( aoi_scene, fighter, arr_kill_player_aoi_id )
end

-- 检查首杀
function WanfaKillService:checkFirstKill( aoi_scene, fighter )
	if not self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_FIRST) then 
		return 
	end

	local wanfa_kill_info = aoi_scene.wanfa_kill_info
	if not wanfa_kill_info then 
		wanfa_kill_info = {}
		aoi_scene.wanfa_kill_info = wanfa_kill_info
	end	

	if not wanfa_kill_info.first_kill then 
		wanfa_kill_info.first_kill = true
		-- 广播首杀
		NoticeService:KillNoticeScene(aoi_scene, WanfaKillDefs.KILL_NOTICE_TYPE_FIRST, 1, fighter.tmps.zhenying, fighter.nick, nil,fighter.gcid)
	end
end

-- 检查终结连杀
function WanfaKillService:checkEndContinueKill( aoi_scene, fighter, arr_kill_player_aoi_id )

	local space_id = aoi_scene.space_id
	
	local is_surport_end_kill = self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT)

	for _, player_aoi_id in pairs(arr_kill_player_aoi_id) do

		-- 被杀者信息
		local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, player_aoi_id) 
		local killed_tmps = killed_player.tmps
		local ch_wanfa_kill_info = killed_tmps.ch_wanfa_kill_info

		-- 若场景切换，则重置数据
		if not ch_wanfa_kill_info or space_id ~= ch_wanfa_kill_info.space_id then 
			ch_wanfa_kill_info = self:newWanfaKillInfo(aoi_scene)
			killed_tmps.ch_wanfa_kill_info = ch_wanfa_kill_info
		end

		-- 查看是否终结连杀
		local continue_num = ch_wanfa_kill_info[E_FC_CONTINUE_KILL]
		local show_kill_num = self:getContinueKill(continue_num)
		if is_surport_end_kill and show_kill_num > 0 then 
			NoticeService:KillNoticeScene(aoi_scene, WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT, show_kill_num, fighter.tmps.zhenying, fighter.nick, killed_player.nick, fighter.gcid)
			
			-- 终结连杀成就
			AchieveService:onCheckAchieve( fighter, AchieveDefs.ACHIEVE_SORT_ID_DO_STOP_KILLER_DSTS )
		end

		-- 重置连杀数与连续击杀数
		ch_wanfa_kill_info[E_FC_CONTINUE_KILL] = 0
		ch_wanfa_kill_info[E_FC_CONT_KILL_TIME] = 0
	end	
end

-- 检查普通杀人
function WanfaKillService:checkNormalKill( aoi_scene, fighter, arr_kill_player_aoi_id )

	local space_id = aoi_scene.space_id
	
	local is_surport_to_err_msg = self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_TO_ERR_MSG)
	local is_surport_kill = self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_KILL)

	if not is_surport_to_err_msg and not is_surport_kill then 
		return 
	end

	for _, player_aoi_id in pairs(arr_kill_player_aoi_id) do

		-- 被杀者信息
		local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, player_aoi_id) 

		-- 通过错误消息,通知杀人者杀了谁
		if is_surport_to_err_msg then 
			WorldPacket:m2cSendErr(nil, nil, fighter.gpid, errorCodes.FIGHT_NOTICE_KILL_SOMEONE, {killed_player.nick})
		end

		-- 通过广播，通知所有人谁杀了谁
		if is_surport_kill then 
			NoticeService:KillNoticeScene(aoi_scene, WanfaKillDefs.KILL_NOTICE_TYPE_KILL, 1, fighter.tmps.zhenying, fighter.nick, killed_player.nick, fighter.gcid)
		end
	end	
end

-- 检查连续击杀与连杀
function WanfaKillService:checkContinueKill( aoi_scene, fighter, arr_kill_player_aoi_id )
	local space_id = aoi_scene.space_id

	local is_surport_cont_time = self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME)
	local is_surport_continue = self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE)

	local killer_tmps = fighter.tmps
	local ch_wanfa_kill_info = killer_tmps.ch_wanfa_kill_info

	-- 叵场景切换，重置数据
	if not ch_wanfa_kill_info or space_id ~= ch_wanfa_kill_info.space_id then 
		ch_wanfa_kill_info = self:newWanfaKillInfo(aoi_scene)
		killer_tmps.ch_wanfa_kill_info = ch_wanfa_kill_info
	end	


	-- 清空过期的连续击杀
	local last_kill_timestamp = ch_wanfa_kill_info.last_kill_timestamp
	local continue_kill_timelong = WanfaKillDefs.continue_kill_timelong
	local now_time = os.time()
	if now_time - last_kill_timestamp > continue_kill_timelong then
		ch_wanfa_kill_info[E_FC_CONT_KILL_TIME] = 0
	end

	-- 设置上次杀人时间为当前时间
	ch_wanfa_kill_info.last_kill_timestamp = now_time 


	for i=1, #arr_kill_player_aoi_id do 
		
		-- 增加连续击杀数
		local cont_time_num = ch_wanfa_kill_info[E_FC_CONT_KILL_TIME] + 1
		ch_wanfa_kill_info[E_FC_CONT_KILL_TIME] = cont_time_num

		-- 检查连续击杀(叵设置为30秒，每杀人后30秒以后再次杀人，数值加1，否则数值清零)
		local cont_time_num_show = self:getContinueTimeKill( cont_time_num )
		if is_surport_cont_time and cont_time_num_show > 0 then 
			NoticeService:KillNoticeScene(aoi_scene, WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME, 
				cont_time_num_show, fighter.tmps.zhenying, fighter.nick, nil,fighter.gcid)
		end

		-- 增加连杀数
		local continue_num = ch_wanfa_kill_info[E_FC_CONTINUE_KILL]
		ch_wanfa_kill_info[E_FC_CONTINUE_KILL] = continue_num + 1

		-- 检查连杀广播
		local continue_num_show = self:getContinueKill(continue_num)
		if is_surport_continue and continue_num_show > 0 then 
			NoticeService:KillNoticeScene(aoi_scene, WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE, 
				continue_num_show, fighter.tmps.zhenying, fighter.nick, nil,fighter.gcid)
			if continue_num_show >= 3 then 
				AchieveService:onCheckAchieve( fighter, AchieveDefs.ACHIEVE_SORT_ID_DO_KILLER_DSTS )
				ScorePopupService:openScorePopup(fighter, ScorePopupDefs.SCOREPOPUP_NODE_DASHATESHA)
			end
		end		
	end
end

-- 检查总击杀数
function WanfaKillService:checkTotalKill( aoi_scene, fighter, arr_kill_player_aoi_id )
    local space_id = aoi_scene.space_id

    local is_surport_cont_time = self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_TOTAL_KILL)
    
    if not is_surport_cont_time then return end
    
    local killer_tmps = fighter.tmps
    local ch_wanfa_kill_info = killer_tmps.ch_wanfa_kill_info

    -- 叵场景切换，重置数据
    if not ch_wanfa_kill_info or space_id ~= ch_wanfa_kill_info.space_id then 
        ch_wanfa_kill_info = self:newWanfaKillInfo(aoi_scene)
        killer_tmps.ch_wanfa_kill_info = ch_wanfa_kill_info
    end

    --根据类型发广播
    local total_killconfig = WanfaKillDefs.total_kill
    if not total_killconfig or not total_killconfig[1] then return end
    
    local rate = total_killconfig[1]
    
    for i=1, #arr_kill_player_aoi_id do 
        -- 增加击杀数
        ch_wanfa_kill_info[E_FC_KILL_NUM] = ch_wanfa_kill_info[E_FC_KILL_NUM] +1
        local cont_time_num = ch_wanfa_kill_info[E_FC_KILL_NUM]

        --广播累积连杀,主城的飘字去掉
        if cont_time_num>0 and cont_time_num % rate == 0 then
            --需要广播
            local area_id = externalSplitUInt(fighter.gcid)    
            local msg_params = {fighter.nick,cont_time_num}
            NoticeService:noticeSceneZhucenChat(aoi_scene,area_id,OKMsgCodes.OUTDOOR_KILL_NOTICE,msg_params,nil,true)
        end 
    end
end

--如果有军团成员被杀
function WanfaKillService:checkGangKill( aoi_scene, fighter, arr_kill_player_aoi_id )
    --Logger:debug("检查军团杀人")
    if not OutdoorDao.gangkill_time then
	OutdoorDao.gangkill_time = {}
    end
    local space_id = aoi_scene.space_id
    local is_surport_cont_time = self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_GANG_KILL)
    if not is_surport_cont_time then return end
    --Logger:debug("检查军团杀人开始:")
    local killer_tmps = fighter.tmps
    local ch_wanfa_kill_info = killer_tmps.ch_wanfa_kill_info

    -- 叵场景切换，重置数据
    if not ch_wanfa_kill_info or space_id ~= ch_wanfa_kill_info.space_id then 
        ch_wanfa_kill_info = self:newWanfaKillInfo(aoi_scene)
        killer_tmps.ch_wanfa_kill_info = ch_wanfa_kill_info
    end
    
    local killer_gangid,killer_gangtitle,killer_nick 
    killer_nick = fighter.nick
    if fighter.gang_id and fighter.gang_id>0 then
        killer_gangid = fighter.gang_id
        killer_gangtitle = fighter.gang_title
    end
    local area_id_killer = externalSplitUInt(fighter.gcid)   
    
    for _, player_aoi_id in pairs(arr_kill_player_aoi_id) do
        --广播到军团频道 被杀者信息
        local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, player_aoi_id) 
        --Logger:debug("检查军团killed_player:",killed_player.gang_id)
        if killed_player then
            --需要广播
            local area_id = externalSplitUInt(killed_player.gcid)   
            --Logger:debug("检查军团killer_gangid:",area_id,killer_gangid,killed_player.gang_id)
            if killer_gangid then --杀人的玩家有军团id，被杀有无军团 
                if killed_player.gang_id and killed_player.gang_id>0                    
                then
                    --被杀的也有军团
                    --被 杀的发消息 
                    if not (killed_player.area_id and area_id_killer==area_id 
                    and killer_gangid == killed_player.gang_id) then --同服同军团不广播
                        --去掉被杀的人的军团消息
                        local msg_params = {killed_player.nick,killer_gangtitle,killer_nick}
                        --NoticeService:noticeGangChat(aoi_scene,area_id,OKMsgCodes.OUTDOOR_KILL_NOTICE_DIE_HASGANG,msg_params,killed_player.gang_id)
                        
                        --发消息到杀人的
                        if not OutdoorDao.gangkill_time[fighter.gcid] then
                            OutdoorDao.gangkill_time[fighter.gcid] = {}
                        end
                        
                        local fighterkill_t = OutdoorDao.gangkill_time[fighter.gcid]
                        --Logger:error("有人被杀",fighter.nick,killed_player.nick)
                        if not fighterkill_t[killed_player.gcid]  or
                           Time.time_second - fighterkill_t[killed_player.gcid] > 3600  then
                            --未杀过人，或者杀人时间大于1小时,否则忽略
                            --Logger:error("有人被杀发消息",fighter.nick,killed_player.nick)
                            msg_params = {killer_nick,killed_player.gang_title,killed_player.nick}
                            NoticeService:noticeGangChat(aoi_scene,area_id_killer,OKMsgCodes.OUTDOOR_KILL_NOTICE_KILL_HASGANG,msg_params,killer_gangid)
                            fighterkill_t[killed_player.gcid] = Time.time_second
                        end
                    end
                else
                    --被杀的无军团，只发给杀人者的军团
                    --Logger:error("被杀的无军团，只发给杀人者的军团",killer_gangid)
                    if not OutdoorDao.gangkill_time[fighter.gcid] then
                        OutdoorDao.gangkill_time[fighter.gcid] = {}
                    end
                    local fighterkill_t = OutdoorDao.gangkill_time[fighter.gcid]
                    if not fighterkill_t[killed_player.gcid]  or
                       Time.time_second - fighterkill_t[killed_player.gcid] > 3600  then
                       local msg_params = {killer_nick,killed_player.nick}
                       NoticeService:noticeGangChat(aoi_scene,area_id_killer,OKMsgCodes.OUTDOOR_KILL_NOTICE_KILL_NOGANG,msg_params,killer_gangid)
                       fighterkill_t[killed_player.gcid] = Time.time_second
                    end    
                end
            else --杀人的玩家无军团id
                --Logger:debug("检查军团killer_gangid2:",killed_player.gang_id)
                if killed_player.gang_id and killed_player.gang_id>0 then
                    --杀人者无军团，被杀有军团，发到被杀军团
                    --给被 杀的军团发消息  关闭 
                    --local msg_params = {killed_player.nick,killer_nick}
                    --NoticeService:noticeGangChat(aoi_scene,area_id,OKMsgCodes.OUTDOOR_KILL_NOTICE_DIE_NOGANG,msg_params,killed_player.gang_id)
                end                
                --都无军团忽略
            end    
        end 
    end
end

function WanfaKillService:checkRankKill( aoi_scene, fighter, arr_kill_player_aoi_id )
    local space_id = aoi_scene.space_id

    local is_surport_cont_time = self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_RANK_KILL)
    
    if not is_surport_cont_time then return end
    local killer_gangid
    if fighter.gang_id and fighter.gang_id>0 then
        killer_gangid = fighter.gang_id
    end
    
    for _, player_aoi_id in pairs(arr_kill_player_aoi_id) do
        local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, player_aoi_id) 
        local area_id = externalSplitUInt(killed_player.gcid)  
        
        --同区同军团不广播
        if killed_player and not (area_id and fighter.area_id==area_id
                    and killer_gangid and killer_gangid == killed_player.gang_id ) then
            local has_notice = false
            --Logger:error("pk服kill_notice为:",killed_player.nick,killed_player.kill_notice)
            if killed_player.kill_notice then
                local kill_notice = killed_player.kill_notice
                if  kill_notice.gang3 and kill_notice.gang3<4 then
                    --发主城、附近世界广播
                    has_notice = true
                    
                    if WanfaKillService:rankNoticeCtrl(fighter.gcid,killed_player.gcid) then
                        local msg_params = {killed_player.gang_title,killed_player.nick,fighter.nick}
                        NoticeService:noticeSceneZhucenChat(aoi_scene,area_id,OKMsgCodes.OUTDOOR_KILL_NOTICE_GANGLEADER,msg_params)
                    end    
                end
                
                if not has_notice and kill_notice and kill_notice.fc10 and kill_notice.fc10<11 then
                    has_notice = true
                    
                    if WanfaKillService:rankNoticeCtrl(fighter.gcid,killed_player.gcid) then
                        local area_id = externalSplitUInt(killed_player.gcid)    
                        local msg_params = {killed_player.nick,fighter.nick}
                        local fcstr = WanfaKillService:getRankTuBiao(kill_notice.fc10,1)
                        --Logger:error("111111111111",kill_notice.fc10,fcstr)
                        local msg_params2 = {fcstr..killed_player.nick,fighter.nick}
                        NoticeService:noticeSceneZhucenChat(aoi_scene,area_id,OKMsgCodes.OUTDOOR_KILL_NOTICE_FORCE_TOP10,msg_params,msg_params2)
                    end    
                end
                
                if not has_notice and kill_notice and kill_notice.slice10 and kill_notice.slice10<11 then
                    has_notice = true
                    
                    if WanfaKillService:rankNoticeCtrl(fighter.gcid,killed_player.gcid) then
                        local area_id = externalSplitUInt(killed_player.gcid)    
                        local msg_params = {killed_player.nick,fighter.nick}
                        local fcstr = WanfaKillService:getRankTuBiao(kill_notice.slice10,2)
                        --Logger:error("1111111111112222:",kill_notice.slice10,fcstr)
                        local msg_params2 = {fcstr..killed_player.nick,fighter.nick}
                        NoticeService:noticeSceneZhucenChat(aoi_scene,area_id,OKMsgCodes.OUTDOOR_KILL_NOTICE_FORCE_TOP10,msg_params,msg_params2)
                    end    
                end                
                
            else
                Logger:error("killnotice传错！！",killed_player.nick,killed_player.gcid,killed_player.kill_notice)
            end
        end
    end
end

-- 显示杀字
function WanfaKillService:checkShowKill( aoi_scene, fighter )
	local killer_tmps = fighter.tmps
	if not killer_tmps then 
		return 
	end
	if self:isTypeSurport(aoi_scene.scene_id, WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL) then
		NoticeService:sendKillNotice(fighter.gpid, WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL, 0, fighter.tmps.zhenying, '')
	end
end

-- 排行飘字提示
function WanfaKillService:rankNoticeCtrl(fighter_gcid,killed_player_gcid)
    if not OutdoorDao.rankkill_time[fighter_gcid] then
        OutdoorDao.rankkill_time[fighter_gcid] = {}       
    end
    local fighterkill_t = OutdoorDao.rankkill_time[fighter_gcid]
    if not fighterkill_t[killed_player_gcid]  or
       Time.time_second - fighterkill_t[killed_player_gcid] > 3600  then
       OutdoorDao.rankkill_time[fighter_gcid][killed_player_gcid] = Time.time_second
       return true
    end   
    return false
end

-- 查看某个场景是否支持某个功能
function WanfaKillService:isTypeSurport( scene_id, sort_id )
	return WanfaKillDefs.seceneid_2_killconfig[scene_id][sort_id]
end

function WanfaKillService:newWanfaKillInfo( aoi_scene )
	local ch_wanfa_kill_info = {}
	ch_wanfa_kill_info.last_kill_timestamp = 0	-- 上次杀人时间
	ch_wanfa_kill_info[E_FC_CONT_KILL_TIME] = 0		-- 连续杀人数
	ch_wanfa_kill_info[E_FC_CONTINUE_KILL] = 0		-- 连杀数
	ch_wanfa_kill_info[E_FC_KILL_NUM] = 0		-- 杀人数
	ch_wanfa_kill_info.space_id = aoi_scene.space_id 	
	return ch_wanfa_kill_info
end

-- 获取连杀最终表现的连杀数
function WanfaKillService:getContinueKill( continue_kill_num )
	local continue_kill = WanfaKillDefs.continue_kill
	local num = continue_kill[continue_kill_num]
	if not num then 
		num = continue_kill.other
	end
	return num
end


-- 获取连续击杀最终表现的连续击杀数
function WanfaKillService:getContinueTimeKill( cont_time_kill_num )
	local cont_time_kill = WanfaKillDefs.cont_time_kill
	local num = cont_time_kill[cont_time_kill_num]
	if not num then 
		num = cont_time_kill.other
	end
	return num
end

--1战力,2斩杀力
function WanfaKillService:getRankTuBiao(rank,rank_type)
    local ret_str=""
    if rank_type == 1 then
        if rank == 1 then ret_str = ChatDefs.CHAT_FC_1 end
        if rank >= 2 and rank <= 10 then ret_str = ChatDefs.CHAT_FC_2_10 end
    elseif rank_type == 2 then
        if rank == 1 then ret_str = ChatDefs.CHAT_SLICE_1 end
        if rank >= 2 and rank <= 10 then ret_str = ChatDefs.CHAT_SLICE_2_10 end
    end    
    return ret_str
end
