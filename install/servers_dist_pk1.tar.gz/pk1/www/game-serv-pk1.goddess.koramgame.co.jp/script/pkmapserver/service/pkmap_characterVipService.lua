--[[
角色VIP系统service
author : xingzeng
date : 2012-03-27
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local Logger = Logger
local tableInsert = table.insert
local table = table

CharacterVipService = CharacterVipService or {}

-- 获取角色的VIP等级
function CharacterVipService:getVip(character)
	return character.vip
end

-- 是否是指定等级的VIP
-- lev = 1 : VIP等级 (传空时代表1级VIP)
--		当lev = 3时，如果玩家是VIP4，则也返回true
-- return boolean
function CharacterVipService:isVipByLev(character, lev)
	if not lev or lev <= 0 then lev = 1 end
	local vip = character.vip
	return vip >= lev
end

-- 获取角色VIP功能(包含VIP0的数据,每个VIP都包含从VIP0-VIP12的数据
-- @return is_open, value, gold, value2
function CharacterVipService:isOwnVipFuncWith0(character, vip_func_id)
	local vip = character.vip or 0
	
	local vip_base = VipBaseService:getVipBaseByLev(vip)
	if not vip_base then return false end
	
	local funcs = vip_base.funcs
	local vip_func_base = funcs[vip_func_id]
	local is_open = vip_func_base and true or false
	if not is_open then return is_open end
	return vip_func_base.is_open == 1, vip_func_base.value, vip_func_base.gold, vip_func_base.value2
end

-- 到达某个VIP等级需要再充值的魔石数
function CharacterVipService:getNeedVoucherGold2Vip( character, vip )
	assert(vip > 0 and vip <= VipDefs.VIP_MAX_LEVEL)
	local pay_gold_total = character.pay_gold_total
	local vip_func_base = VipBaseService:getVipFuncBase(vip, VipDefs.VIP_FUNC_ID_VIP_UPGRADE)
	return pay_gold_total - vip_func_base.gold
end

-- 获取功能开启等级（开启类有效）
function CharacterVipService:getOpenVipLv( character, vip_func_id )
	for i=0, VipDefs.VIP_MAX_LEVEL do
		local vip_base = VipBaseService:getVipFuncBase(i, vip_func_id)
		if vip_base and vip_base.is_open and vip_base.is_open == 1 then 
			return i
		end
	end
	assert(false)
end

-- 获取下一个更好的VIP等级
function CharacterVipService:getNextBetterVipLv( character, vip_func_id )
	local vip_base = VipBaseService:getVipFuncBase(character.vip, vip_func_id)
	return vip_base.next_better_vip
end
