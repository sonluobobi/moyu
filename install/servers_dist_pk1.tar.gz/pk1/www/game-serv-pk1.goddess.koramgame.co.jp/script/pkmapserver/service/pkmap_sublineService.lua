--[[
多人副本 service
author : xingzeng.jiang
date : 2014-07-15
--]]


SublineService = SublineService or {}
setmetatable(SublineService, SceneServiceInterface)

local SceneService = SceneService
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local aoi_type_robot = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT
local math = math
local Time = Time
local Utils = Utils
local SceneDefs = SceneDefs
local string_format = string.format

-- 初始化副本实例
function SublineService:initSublineIns(aoi_scene)
	local subline = {is_pass = false, is_rewarded = false}
	aoi_scene.subline = subline

	--- 伤害值信息
	subline.gcid2harm_total = {}
end

local OpeActivityService
function SublineService:onAfterLoadLua()
	SceneService = _G.SceneService
	OpeActivityService = _G.OpeActivityService
end

function SublineService:checkEnterScene(character, aoi_scene, dst_scene_base)
	return true
end

function SublineService:checkLeaveScene(character, aoi_scene)
	return true
end

function SublineService:onInitScene(character, aoi_scene)
	-- 初始化副本实例
	SublineService:initSublineIns(aoi_scene)
	
	--[[ TEST
	local monster_base_id = 2099001
	local direction = 60, 150
	local scene_id = aoi_scene.scene_id
	local x = 21
	local y = 12
	MonsterService:dymCreateMonster(aoi_scene, monster_base_id, scene_id, x, y, direction, nil, 250)
	SceneService:onInitSceneDefault(character, aoi_scene)
	--]]
	return true
end

-- 当怪物被杀
-- character 	击杀者
-- arr_kill_monster_id		被杀怪物ID数组
function SublineService:onKilledMonster(character, arr_kill_monster_id)
	
end

function SublineService:onMonsterHarm(character, arr_monster_harm)
	local aoi_scene = GameObjectService:getAoiScene(character)
	local subline = aoi_scene.subline
	local gcid2harm_total = subline.gcid2harm_total
	local gcid = character.gcid
	if arr_monster_harm then
		for _, harm in pairs(arr_monster_harm) do
			gcid2harm_total[gcid] = gcid2harm_total[gcid] or {gcid = gcid, aoi_id = character.aoi_id, harm = 0}
			gcid2harm_total[gcid].harm = gcid2harm_total[gcid].harm + harm
		end
	end
end

function SublineService:update(now_time_msec, aoi_scene)
	local subline = aoi_scene.subline
	if subline then
		if not subline.bc_harm_total_time or subline.bc_harm_total_time + 3000 <= Time.time_now then
			self:bcHarm(aoi_scene)
		end
	end
end

function SublineService:checkFight(aoi_scene, attacker, target)
	if target and attacker.aoi_type == aoi_type_player and attacker.aoi_type == target.aoi_type then
		return false, errorCodes.FIGHT_ERROR_TARGET_IS_SAME_ZHENYING
	end
	
	return true
end

function SublineService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	if is_reconnect then
		local robots = GameObjectService:getGameObjsByType(aoi_scene, aoi_type_robot)
		if robots and next(robots) then
			for _, robot in pairs(robots) do
				SceneRobotService:sendSceneRobotInfo(character, robot)
			end
		end
	end

	character.tmps.is_reconnect_into_subline = is_reconnect
	
	-- 存储队伍ID
	local subline = aoi_scene.subline
	if not subline.team_id then 
		local team = TeamService:getTeamByCid(character.gcid)
		subline.team_id = team and team.id
	end

	local gcid = character.gcid
	local gcid2harm_total = subline.gcid2harm_total
	gcid2harm_total[gcid] = gcid2harm_total[gcid] or {gcid = gcid, aoi_id = character.aoi_id, harm = 0}
	SublineService:bcHarm(aoi_scene)
end

-- 客户端进入场景之后
function SublineService:afterClientEnterScene(character, aoi_scene)
	-- 通知队长已扣副本令
	local team = TeamService:getTeamByCid(character.gcid)
	if not character.tmps.is_reconnect_into_subline and team.no1_cpt_gcid == character.gcid then
		if aoi_scene.scene_base.scene_sort_id == SceneDefs.SCENE_SORT_ID_SUBLINE_EMENG then
			local active_sub_base = ActiveBaseDao:getActiveBaseById(team.child_game_type_id)
			local sub_counter_equip_id = active_sub_base.sub_counter_equip_id or 0
			WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SUBLINE_EMENG_ENTER_OK, {string_format('{scene_title:%d}', aoi_scene.scene_id), 1, string_format('{equip_title:%d}', sub_counter_equip_id)})
		end
	end
end

-- 设置阵营
function SublineService:setZhenying(aoi_scene, character)
	local team = TeamService:getTeamByCid(character.gcid)
	local zhenying = Utils.getZhenYingId(team.id)
	GameObjectService:updateZhenying(aoi_scene, character, zhenying)
end

-- 副本通关
do
	local notice_scene_sort_ids = {SceneDefs.SCENE_SORT_ID_SUBLINE_EMENG,SceneDefs.SCENE_SORT_ID_NORMAL_MCITY}
	local reward_datas = {}
	local PK_GAME_TYPE_ID_SUBLINE = Statics.PK_GAME_TYPE_ID_SUBLINE
	local PK_GAME_TYPE_ID_SUBLINE_EMENG = Statics.PK_GAME_TYPE_ID_SUBLINE_EMENG
	function SublineService:pass(aoi_scene, is_win)
		-- 通关
		if is_win == true then
			-- 已通关
			local subline_ins = aoi_scene.subline
			if subline_ins.is_pass then
				-- RSP
				local ch_objs = GameObjectService:getPlayerGameObjs(aoi_scene)
				for _, ch_obj in pairs(ch_objs) do
					local rewards = subline_ins.gcid2rewards[ch_obj.gcid]
					SublineService:sendSublinePass(ch_obj.gpid, true, rewards, subline_ins.passed_use_time)
				end
				return
			end
			
			-- 记录已通关
			subline_ins.is_pass = true
			
			-- 获取副本内所有玩家
			local ch_objs = GameObjectService:getPlayerGameObjs(aoi_scene)
			local active_base = ActiveBaseDao:getActiveBaseBySceneId(aoi_scene.scene_id)
			local drop_pack_ids = active_base.drop_pack_ids
			
			local is_emeng = SceneDefs.SCENE_SORT_ID_SUBLINE_EMENG == aoi_scene.scene_base.scene_sort_id and true or false
			local team = nil
			
			local passed_use_time = Time:getSecondsNow() - aoi_scene.created
			subline_ins.passed_use_time = passed_use_time
			
			-- 发放奖励
			local gcid2rewards = subline_ins.gcid2rewards or {}
			subline_ins.gcid2rewards = gcid2rewards
			for _, ch_obj in pairs(ch_objs) do
				-- 随机奖励
				local rewards = DropItemsService:getDropEquips(drop_pack_ids, ch_obj.prof)
				reward_datas.rewards = rewards
				reward_datas.scene_id = aoi_scene.scene_id
				gcid2rewards[ch_obj.gcid] = reward_datas.rewards
				
				-- 活动掉落奖励
				local opeact_rewards = OpeActivityService:getDropEquips(ch_obj.area_id, aoi_scene)
				for equip_id, equip_num in pairs(opeact_rewards) do
					rewards[equip_id] = (rewards[equip_id] or 0) + equip_num
				end
				
				-- 噩梦副本队长加成
				if is_emeng then
					if not team then
						team = TeamService:getTeamByCid(ch_obj.gcid)
					end
					reward_datas.no1_cpt_gcid = team.no1_cpt_gcid
					
					-- 首任队长
					if team.no1_cpt_gcid == ch_obj.gcid then
						local captain_income_multi = team and (team.captain_income_multi or 1) or 1
						for equip_id_t, equip_num_t in pairs(rewards) do
							rewards[equip_id_t] = math.round(equip_num_t * captain_income_multi)
						end
					end
				end
				
				local gpid = ch_obj.gpid
				local game_type_id = is_emeng and PK_GAME_TYPE_ID_SUBLINE_EMENG or PK_GAME_TYPE_ID_SUBLINE
				RewardService:reward(game_type_id, 0, gpid, ch_obj.gcid, reward_datas)
				
				-- RSP
				SublineService:sendSublinePass(gpid, is_win, reward_datas.rewards, passed_use_time)
			end
			
			-- 记录已发奖
			subline_ins.is_rewarded = true
			
			local gcids = table.keys(gcid2rewards)
			FriendService:onJoinAcitivty(gcids, FriendDefs.FRIEND_ACT_TYPE_ID_SUBLINE)

			-- BC
			if is_emeng then
				--NoticeService:sysMsgWorld2AllSrv(OKMsgCodes.SUBLINE_EMENG_PASS, {team.captain_nick, string_format('{scene_title:%d}', aoi_scene.scene_id)}, notice_scene_sort_ids)
			end
		else
			local active_base = ActiveBaseDao:getActiveBaseBySceneId(aoi_scene.scene_id)
			local drop_pack_ids = active_base.drop_pack_ids
			
			local ch_objs = GameObjectService:getPlayerGameObjs(aoi_scene)
			for _, ch_obj in pairs(ch_objs) do
				local rewards = DropItemsService:getDropEquips(drop_pack_ids, ch_obj.prof)
				SublineService:sendSublinePass(ch_obj.gpid, false, rewards)
			end
		end
		
	end
end

function SublineService:isSubline(scene_id, scene_base)
	local scene_base = scene_base or SceneBaseDao[scene_id]
	local scene_sort_id = scene_base.scene_sort_id
	return (scene_sort_id == SceneDefs.SCENE_SORT_ID_SUBLINE or 
			scene_sort_id == SceneDefs.SCENE_SORT_ID_SUBLINE_EMENG) and true or false
end

-- 广播已通关
do
	local rsp_opcode = opCodes.M2C_SUBLINE_FINISH
	local msg_name = "PackSubline.M2C_SUBLINE_FINISH"
	local msg_proto = {}
	function SublineService:sendSublinePass(gpids, is_win, rewards, passed_use_time)
		msg_proto.rewards = rewards
		msg_proto.is_win = is_win
		msg_proto.passed_use_time = passed_use_time
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
	end
end

-- 广播伤害
do
	function SublineService:bcHarm(aoi_scene)
		local subline = aoi_scene.subline
		subline.bc_harm_total_time = Time.time_now
		TeamService:updateTeamRealInfoByAoiId( subline.team_id, 'harm', subline.gcid2harm_total or {})
	end
end
