--[[
场景BUFFER系统servuce
author : xingzeng
date : 2012-03-27
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local table = table
local tableInsert = table.insert
local random = math.random
local Time = Time
local SceneBufferDefs = SceneBufferDefs

SceneBufferService = SceneBufferService or {}

local SceneService, GameObjectService, BufferBaseService, SceneBufferBaseService

function SceneBufferService:onAfterLoadLua()
	SceneService = _G.SceneService
	GameObjectService = _G.GameObjectService
	BufferBaseService = _G.BufferBaseService
	SceneBufferBaseService = _G.SceneBufferBaseService
end

-- 创建场景BUFFER对象
function SceneBufferService:createSceneBuffer(aoi_scene)
	local scene_buffer = aoi_scene.scene_buffer
	if not scene_buffer then
		scene_buffer = {}
		scene_buffer.gcid2ch_scene_buffers = {}
		scene_buffer.ref_last_times = {}
		scene_buffer.gather_items = {}
		scene_buffer.gcid2comm_cd_expire = {}
		
		aoi_scene.scene_buffer = scene_buffer
	end
	
	return scene_buffer
end

-- 创建角色场景BUFFER
function SceneBufferService:createChSceneBuffer(character, scene_buffer_id, buffer_num, gather_item_id)
	local ch_scene_buffer = ChSceneBuffer:new(character, scene_buffer_id, buffer_num, gather_item_id)
	return ch_scene_buffer
end

-- 添加场景BUFFER到角色身上
function SceneBufferService:addSceneBuffer(character, scene_buffer_base, buffer_num, is_bc_attach, gather_item_id)
	local ch_scene_buffers, gcid2ch_scene_buffers, scene_buffer = self:getChSceneBuffers(character)
	if not ch_scene_buffers then
		ch_scene_buffers = {}
		gcid2ch_scene_buffers[character.gcid] = ch_scene_buffers
	end
	
	local scene_buffer_id = scene_buffer_base.id
	local ch_scene_buffer = ch_scene_buffers[scene_buffer_id]
	if not ch_scene_buffer then
		ch_scene_buffer = self:createChSceneBuffer(character, scene_buffer_id, buffer_num, gather_item_id)
		ch_scene_buffers[scene_buffer_id] = ch_scene_buffer
	else
		ch_scene_buffer.num = ch_scene_buffer.num + buffer_num
	end
	
	-- 通知客户端更新
	self:sendSceneBufferUp(character, ch_scene_buffer)
	
	-- 广播场景BUFF附着状态
	if is_bc_attach then
		SceneBufferService:sendAppearChSceneBuffers(character, scene_buffer_id, buffer_base)
	end
	
	return ch_scene_buffer
end

-- 添加场景BUFFER掉落物
function SceneBufferService:addSceneBufferDropItem(aoi_scene, scene_buffer_base, pos_area, life_expire)
	local pos1 = pos_area[1]
	local pos2 = pos_area[2]
	local x1, x2, y1, y2 = pos1[1], pos2[1], pos1[2], pos2[2]
	
	local x = random(math.min(x1, x2), math.max(x1, x2))
	local y = random(math.min(y1, y2), math.max(y1, y2))
	
	local itemobj = DropItemsService:dropSceneBuffer(aoi_scene, scene_buffer_base, x, y, life_expire)
	return itemobj
end

-- 拾取场景BUFFER掉落物
function SceneBufferService:pickup(character, itemobj)
	assert( character and itemobj)
	assert( itemobj.func_id == ItemDefs.ITEM_FUNC_ID_SCENE_BUFFER )
	assert( itemobj.sort_id == ItemDefs.ITEM_SORT_ID_SCENE_BUFFER )
	
	local scene_buffer_base = itemobj.item_base
	local buffer_ids = scene_buffer_base.buffer_ids
	local scene_buffer_id = scene_buffer_base.id
	
	local scene_base = SceneBaseService:getSceneBaseById(character.scene_id)
	local scene_buffer_ref = SceneBufferBaseService:getSceneBufferRefBase(scene_base, scene_buffer_id)
	local tmps = itemobj.tmps
	
	-- 检查阵营
	if tmps.zhenying > 0 and tmps.zhenying ~= character.tmps.zhenying then
		return false, errorCodes.SCENE_BUFFER_ENEMY_ZHENYING
	end

	local aoi_scene = GameObjectService:getAoiScene(character)
	
	-- 血清为丧尸危机使用，只有非丧尸玩家可以捡
	if scene_buffer_base.sort_id == SceneBufferDefs.SCENE_BUFFER_SORT_BUFFER_ZOMBIE_XUEQING then 
		if SceneDefs:isInShengcun( aoi_scene ) then 
			if ShengcunService:isZombie( aoi_scene, character ) then 
				return false, errorCodes.SCENE_BUFFER_ZOMBIE_CANNOT_PICKUP
			end
		end		
	end

	if scene_buffer_ref then
		-- 检查身上捡的已满上限
		local ch_scene_buffer = SceneBufferService:getChSceneBuffer(character, scene_buffer_id)
		if ch_scene_buffer then
			-- 如果是立即使用的BUFFER，删除身上的
			if itemobj.item_base.is_pickup_use == 1 then
				ch_scene_buffer.num = 0
			elseif ch_scene_buffer.num >= scene_buffer_ref.max_pickup_num then
				return false, errorCodes.SCENE_BUFFER_PICKUP_FULL
			end
		end
	end
	
	-- 删除掉落物
	GameObjectService:delObj(itemobj, aoi_scene)
	
	-- 添加到角色身上
	self:addSceneBuffer(character, scene_buffer_base, 1)
	
	return true
end

-- 使用场景BUFFER
function SceneBufferService:useSceneBuffer(character, scene_buffer_id, targeter_aoi_id, use_num)
	local ch_scene_buffer, ch_scene_buffers, scene_buffer = self:getChSceneBuffer(character, scene_buffer_id)
	if not ch_scene_buffer or ch_scene_buffer.num < 1 then
		return false, errorCodes.SCENE_BUFFER_USE_EMPTY
	end
	
	-- 判断主角是否已死亡
	if FightService:isDead(character) then
		return false, errorCodes.FIGHT_SELF_DAED
	end
	
	local use_num = use_num or 1
	local gcid = character.gcid
	local scene_ins_id = character.space_id
	local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
	local gcid2comm_cd_expire = scene_buffer.gcid2comm_cd_expire
	local comm_cd_expire = gcid2comm_cd_expire[gcid] and gcid2comm_cd_expire[gcid].cd_expire or 0
	
	-- 检查CD时间
	-- modify:考虑立即使用BUFFER，去掉公共CD
	local cur_mtime = Time:getTimeNow()
	if ch_scene_buffer.cd_expire > cur_mtime then
		return false, errorCodes.SCENE_BUFFER_USE_IN_COOL
	end
	
	local sort_id = scene_buffer_base.sort_id
	-- 如果是血清buffer，检查是否可以使用
	if sort_id == SceneBufferDefs.SCENE_BUFFER_SORT_BUFFER_ZOMBIE_XUEQING then
		if ShengcunService:isInShengcun( character.scene_id ) then
			local aoi_scene = GameObjectService:getAoiScene(character)
			if not ShengcunService:isInfected( character ) then 
				return false, errorCodes.SCENE_BUFFER_XUEQING_NOT_INFECTED
			end
		end
	end


	-- 扣除1个
	ch_scene_buffer.num = ch_scene_buffer.num - use_num
	
	-- 设置CD时间
	ch_scene_buffer.cd_stime = cur_mtime
	ch_scene_buffer.cd_expire = cur_mtime + scene_buffer_base.cd_time * use_num
	--gcid2comm_cd_expire[gcid] = {cd_stime = cur_mtime, cd_expire = ch_scene_buffer.cd_expire}
	
	-- BUFFER类
	if sort_id == SceneBufferDefs.SCENE_BUFFER_SORT_BUFFER then
		local buffer_ids = scene_buffer_base.buffer_ids
		for _, buffer_id in pairs(buffer_ids) do
			local buffer_base = BufferBaseService:getBufferBaseById(buffer_id)
			SceneBufferService:dealBuffer(character, buffer_base, targeter_aoi_id, ch_scene_buffer, use_num)
		end
		
	-- 女神变身类
	elseif sort_id == SceneBufferDefs.SCENE_BUFFER_SORT_BUFFER_NS_BIANSHEN then
		local buffer_ids = scene_buffer_base.buffer_ids
		local buffer_id = character.gender == CharacterDefs.CHARACTER_GENDER_MAN and buffer_ids[1] or buffer_ids[2]
		local buffer_base = BufferBaseService:getBufferBaseById(buffer_id)
		SceneBufferService:dealBuffer(character, buffer_base, targeter_aoi_id, ch_scene_buffer, use_num)
		
	-- 加积分类
	elseif sort_id == SceneBufferDefs.SCENE_BUFFER_SORT_SCORE then
		local scene_id = character.scene_id
		
		-- 刀剑决
		if GangBattleNewService:isInGangBattle(scene_id) then
			GangBattleNewService:addBufferScore(character, scene_buffer_base.score)
		end
		
	-- TODO:陷阱类
	elseif sort_id == SceneBufferDefs.SCENE_BUFFER_SORT_TRAP then
		--
	elseif sort_id == SceneBufferDefs.SCENE_BUFFER_SORT_BUFFER_ZOMBIE_XUEQING then
		if ShengcunService:isInShengcun( character.scene_id ) then
			local aoi_scene = GameObjectService:getAoiScene(character)
			ShengcunService:onUseXueqingBuffer( aoi_scene, character )
		end
	end


	if scene_buffer_base.id  == SceneBufferDefs.SHENGJIAN_SCENE_BUFFER_ID then 
		GangBattleNewService:onPickupShengjian( character,  ch_scene_buffer)
	end
	
	-- RSP 更新
	SceneBufferService:sendSceneBufferUp(character, ch_scene_buffer, gcid2comm_cd_expire[gcid])
	
	-- 广播场景BUFF附着状态
	SceneBufferService:sendAppearChSceneBuffers(character, scene_buffer_id)
	
	if scene_buffer_id == SceneBufferDefs.SCENE_BUFFER_ID_GUWU_FREE or scene_buffer_id == SceneBufferDefs.SCENE_BUFFER_ID_GUWU_SUPER then
		AchieveService:onCheckAchieve(character, AchieveDefs.ACHIEVE_SORT_ID_CNT_TIANMO_GUWU, use_num)
	end
	
	return true
end

-- 处理BUFFER类的场景BUFF使用
function SceneBufferService:dealBuffer(character, buffer_base, targeter_aoi_id, ch_scene_buffer, use_num)
	local aoi_scene = GameObjectService:getAoiScene(character)
	
	-- 加血类BUFF，检查玩家是否已死亡
	if GameObjectService:isDead(character) and EffectType:isAddHpEffectType(buffer_base.effect_id) then
		return
	end
	
	-- 瞬时BUFF
	if BufferBaseService:isInstantBuffer(nil, buffer_base) then
		-- 瞬时BUFF支持一次使用1个
		assert(use_num == 1)
		BufferService:useInstantBuffer(character, buffer_base, targeter_aoi_id, ch_scene_buffer)
		
	-- 时效BUFF
	else
		local is_ok, is_bc_other = BufferService:addTmpBuffer(character, buffer_base, nil, use_num)
		if not is_ok then
			Logger:warn('[SceneBufferService:dealBuffer] add buffer fail', character.id, character.gpid, character.nick, buffer_base.id)
		end
		
		if is_bc_other then
			BufferService:bcBuffers(aoi_scene, character)
		end
	end
end

-- 获取场景BUFFER对象
function SceneBufferService:getSceneBuffer(character, aoi_scene)
	local aoi_scene = aoi_scene or GameObjectService:getAoiScene(character)
	local scene_buffer = aoi_scene.scene_buffer
	
	if not scene_buffer then
		scene_buffer = self:createSceneBuffer(aoi_scene)
	end
	
	return scene_buffer, aoi_scene
end

-- 获取角色的场景BUFFER信息
function SceneBufferService:getChSceneBuffers(character)
	local scene_buffer = self:getSceneBuffer(character)
	local gcid2ch_scene_buffers = scene_buffer.gcid2ch_scene_buffers
	return gcid2ch_scene_buffers[character.gcid], gcid2ch_scene_buffers, scene_buffer
end

-- 获取角色的场景BUFFER信息
function SceneBufferService:getChSceneBuffer(character, scene_buffer_id)
	local scene_buffer = self:getSceneBuffer(character)
	local ch_scene_buffers = scene_buffer.gcid2ch_scene_buffers[character.gcid]
	if not ch_scene_buffers then return end
	
	return ch_scene_buffers[scene_buffer_id], ch_scene_buffers, scene_buffer
end

-- 获取角色身上拥有的个数
function SceneBufferService:getChSceneBufferNum(character)
	local ch_scene_buffers = self:getChSceneBuffers(character)
	local total_num = 0
	if ch_scene_buffers then
		for _, ch_scene_buffer in pairs(ch_scene_buffers) do
			total_num = total_num + ch_scene_buffer.num
		end
	end
	
	return total_num
end

-- 响应切换场景完成
function SceneBufferService.onAfterEnterScene(character, scene_base, aoi_scene)
	
end

-- 场景帧事件
function SceneBufferService:update(time_now, aoi_scene)
	local scene_buffer = self:getSceneBuffer(nil, aoi_scene)
	local scene_base = aoi_scene.scene_base
	
	-- 获取场景内的BUFFER信息
	local scene_buffer_ref_bases = SceneBufferBaseService:getSceneBufferRefBase(scene_base)
	if not scene_buffer_ref_bases then
		return
	end
	
	for _, scene_buffer_ref in pairs(scene_buffer_ref_bases) do
		self:refSceneBuffer(aoi_scene, scene_buffer, scene_base, scene_buffer_ref)
	end
	
end

-- 500ms更新事件
function SceneBufferService:update500ms(time_now, aoi_scene)
	
end

function SceneBufferService:refSceneBuffer(aoi_scene, scene_buffer, scene_base, scene_buffer_ref)
	local scene_id = aoi_scene.scene_id
	local ref_per_num = scene_buffer_ref.ref_per_num
	if ref_per_num < 1 then
		return
	end
	
	-- 不刷出BUFF的类型，过滤掉
	if scene_buffer_ref.drop_type == SceneBufferDefs.SCENE_BUFFER_DROP_TYPE_NO_REF then
		return
	end
	
	-- 检查各种场景玩法条件
	if not self:enableRefSceneBuffer(aoi_scene, scene_base, scene_buffer_ref) then
		return
	end
	
	local is_need_ref = false
	local drop_type = scene_buffer_ref.drop_type
	local ref_last_times = scene_buffer.ref_last_times
	local cur_time = Time:getSecondsNow()
	local is_brith_buff = false
	
	local ref_last_time = ref_last_times[scene_buffer_ref.id] or cur_time
	ref_last_times[scene_buffer_ref.id] = ref_last_time
	
	-- 刷新场景内BUFFER掉落物
	if ref_last_time + scene_buffer_ref.ref_frequency < cur_time then
		is_need_ref = true
	end

	if is_need_ref and drop_type == SceneBufferDefs.SCENE_BUFFER_DROP_TYPE_DROP_ITEM then
		local scene_buffer_ids = table.lightCopyTableEx(scene_buffer_ref.scene_buffer_ids, {})
		if ref_per_num > #scene_buffer_ids then ref_per_num = #scene_buffer_ids end
		if ref_per_num < 1 then
			return
		end
		
		local drop_poss = scene_buffer_ref.drop_poss
		if #drop_poss < 1 then
			return
		end
		
		-- 固定一个区域里面
		local fix_pos_area
		if scene_buffer_ref.is_in_one_area == 1 then
			fix_pos_area = drop_poss[random(1, #drop_poss)]
		end
		
		for i = 1, ref_per_num do
			-- 随机一个BUFFER ID
			local idx = random(1, #scene_buffer_ids)
			
			local scene_buffer_id = scene_buffer_ids[idx]
			table.remove(scene_buffer_ids, idx)
			
			-- 随机一个范围矩形
			local pos_area = fix_pos_area or drop_poss[random(1, #drop_poss)]
			
			-- 添加掉落物
			local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
			self:addSceneBufferDropItem(aoi_scene, scene_buffer_base, pos_area)
		end
		
		ref_last_times[scene_buffer_ref.id] = Time:getSecondsNow()
		is_brith_buff = true
		
	elseif is_need_ref and drop_type == SceneBufferDefs.SCENE_BUFFER_DROP_TYPE_DROP_POSS_SIT_RAND then
		local scene_buffer_ids = table.lightCopyTableEx(scene_buffer_ref.scene_buffer_ids, {})
		if ref_per_num < 1 or #scene_buffer_ids < 1 then
			return
		end
		local drop_poss = table.lightCopyTableEx(scene_buffer_ref.drop_poss)
		if #drop_poss < 1 then
			return
		end
		
		for i = 1, ref_per_num do
			-- 随机一个BUFFER ID
			local idx = random(1, #scene_buffer_ids)
			local scene_buffer_id = scene_buffer_ids[idx]
			--table.remove(scene_buffer_ids, idx)
			
			-- 随机一个范围矩形
			local pos_idx = random(1, #drop_poss)
			local pos_area = drop_poss[pos_idx]
			table.remove(drop_poss, pos_idx)
			-- 添加掉落物
			local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
			self:addSceneBufferDropItem(aoi_scene, scene_buffer_base, pos_area)
		end
		
		ref_last_times[scene_buffer_ref.id] = Time:getSecondsNow()
		is_brith_buff = true
		
	-- 刷新场景内BUFFER采集物
	elseif is_need_ref and drop_type == SceneBufferDefs.SCENE_BUFFER_DROP_TYPE_GATHER then
				
		ref_last_times[scene_buffer_ref.id] = Time:getSecondsNow()
		is_brith_buff = true
	end

	--广播
	if is_brith_buff and scene_buffer_ref.is_bc == 1 then
		NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.SCENE_BUFFER_RAND_REF_VIEW)
	end

end

-- 初始化场景BUFFER采集物
-- aoi_scene:table					场景实例对象
-- item_func_id:int default:nil		采集物功能类型 定义见 entity/map_itemObj.lua 默认不填
function SceneBufferService:initSceneBufferGather(aoi_scene, item_func_id, base_name)
	assert(aoi_scene)
	local item_func_id = item_func_id or ItemDefs.ITEM_FUNC_ID_SCENE_BUFFER_GATHER
	local base_name = base_name or 'SceneBufferGatherBase'
	
	-- 建立场景BUFFER采集物, 并添加到场景
	local posses = SceneAoiService:getInitObjsByType(aoi_scene.scene_id, AoiObjectType.AOI_OBJECT_TYPE_ID_POSITION)
	if not posses then return end
	
	local getGatherBaseById = GatherBaseService.getGatherBaseById
	local scene_buffer = self:getSceneBuffer(nil, aoi_scene)
	
	for _, sceneaoi in pairs( posses ) do
		local orebase = getGatherBaseById(GatherBaseService, sceneaoi.class_id)
		
		if orebase then
			local gather_items = scene_buffer.gather_items
			if not gather_items then
				gather_items = {}
				scene_buffer.gather_items = gather_items
			end
			
			-- itemobj
			local itemobj = ItemObjService:createItemObj(aoi_scene, 
											ItemDefs.ITEM_SORT_ID_GATHER, 
											item_func_id,
											ItemDefs.ITEM_PICKUP_MODE_FREE,
											nil,
											nil,
											sceneaoi.x,
											sceneaoi.y,
											orebase)
			
			gather_items[itemobj.id] = itemobj
		end
	end
end

-- 添加场景采集物
-- aoi_scene:table						场景实例对象
-- sceneaoi:table						场景AOI基础对象 从 SceneAoiBase.csv读取出来
-- gather_item_func_id:int default:nil	采集物功能类型 定义见 entity/map_itemObj.lua 默认不填
function SceneBufferService:addSceneBufferGather(aoi_scene, sceneaoi, gather_item_func_id)
	local scene_buffer = self:getSceneBuffer(nil, aoi_scene)
	local gather_item_func_id = gather_item_func_id or ItemDefs.ITEM_FUNC_ID_SCENE_BUFFER_GATHER
	
	local orebase = GatherBaseService:getGatherBaseById(sceneaoi.class_id)
	local gather_items_hidden = scene_buffer.gather_items_hidden
	local gather_items = scene_buffer.gather_items
	if not gather_items then
		gather_items = {}
		scene_buffer.gather_items = gather_items
	end
	local item_id = sceneaoi.id
	
	if orebase and not gather_items[item_id] then
		local sort_id = orebase.sort_id
		if sort_id == SceneBufferDefs.SCENE_BUFF_GATHER_SORT_ID_SCENE_REWARDBOX then
			gather_item_func_id = ItemDefs.ITEM_FUNC_ID_SCENE_REWARD_BOX
		end
		
		local itemobj = gather_items_hidden and gather_items_hidden[item_id] or nil
		if itemobj then
			GameObjectService:showObject(itemobj)
			gather_items_hidden[itemobj.id] = nil
		else
			itemobj = ItemObjService:createItemObj(aoi_scene, 
											ItemDefs.ITEM_SORT_ID_GATHER, 
											gather_item_func_id,
											ItemDefs.ITEM_PICKUP_MODE_FREE,
											nil,
											nil,
											sceneaoi.x,
											sceneaoi.y,
											orebase)
		end
		
		gather_items[itemobj.id] = itemobj
	end
end

--- 开始采集
-- @return ok, err, time_cost
function SceneBufferService:onStartGather( character, aoi_scene, itemobj )
	local orebase = itemobj.item_base
		
	-- 是否是场景BUFF采集物
	local scene_buffer = self:getSceneBuffer(nil, aoi_scene)
	local gather_items = scene_buffer.gather_items
	if not gather_items or not gather_items[itemobj.id] then
		return false, errorCodes.GATHER_ERROR_TARGET
	end
	
	-- 检查是否是同阵营的采集物
	if orebase.powers_id > 0 and orebase.powers_id ~= character.tmps.powers_id then
		return false, {errorCodes.GATHER_CANNOT_GATHER_ENEMY, orebase.nick}
	end
	
	-- 检查是否已经在采集中
	local now_msec = Time:getTimeNowExact()
	local src_cid, src_finish_time, src_nick = GatherService:getNowGatherer(aoi_scene, itemobj)
	if src_cid and src_finish_time then
		-- 别人已在采集会提示错误
		-- 注：如果是自己重复采集是允许的
		if src_cid ~= character.gcid then
			if src_finish_time >= now_msec then
				return false, {errorCodes.GATHER_OTHER_CH_GATHERING, src_nick, orebase.nick}
			end
		end
	end
		
	-- 检查是否可以采集
	local is_ok, err_id = SceneBufferService:isEnableGather(character, orebase)
	if not is_ok then
		return false, err_id
	end
	
	-- 允许采集
	return true, nil, orebase.gather_time or SceneBufferDefs.GATHER_TIME
end

--- 完成采集
-- @return ok, err
function SceneBufferService:onFinishGather( character, aoi_scene, itemobj )
	local scene_buffer = self:getSceneBuffer(nil, aoi_scene)
	
	-- 添加到隐藏对象列表
	local gather_items_hidden = scene_buffer.gather_items_hidden
	if not gather_items_hidden then
		gather_items_hidden = {}
		scene_buffer.gather_items_hidden = gather_items_hidden
	end
	gather_items_hidden[itemobj.id] = itemobj
	
	-- 删除对象
	local gather_items = scene_buffer.gather_items
	if gather_items then
		gather_items[itemobj.id] = nil
	end
	
	-- 隐藏对象
	GameObjectService:hideObject( itemobj )
	
	local orebase = itemobj.item_base
	
	-- 添加场景BUFFER到角色身上
	assert(orebase.buffer_id > 0)
	assert(orebase.buffer_num > 0)
	self:addSceneBuffer(character, orebase.buffer_id, orebase.buffer_num, nil, nil, itemobj.id)
	
	-- 广播场景BUFF附着状态
	SceneBufferService:sendAppearChSceneBuffers(character, orebase.buffer_id)
	
	-- 记录玩家采集场景BUFF
	SceneBufferService:recordChGather(character, orebase)
	
	-- ok
	return true
end

-- 记录玩家采集场景BUFF
function SceneBufferService:recordChGather(character, orebase)
	local scene_buffer = self:getSceneBuffer(character)
	local ch_gathers = scene_buffer.ch_gathers
	if not ch_gathers then
		ch_gathers = {}
		scene_buffer.ch_gathers = ch_gathers
	end
	local ch_gather = ch_gathers[character.gcid]
	if not ch_gather then
		ch_gather = {}
		ch_gathers[character.gcid] = ch_gather
	end
	ch_gather[orebase.id] = orebase
end

-- 获取玩家采集场景BUFF记录
function SceneBufferService:getChGather(character)
	local scene_buffer = self:getSceneBuffer(character)
	local ch_gathers = scene_buffer.ch_gathers
	if not ch_gathers then return end
	
	local ch_gather = ch_gathers[character.gcid]
	return ch_gather
end

-- 判断玩家是否可以采集
function SceneBufferService:isEnableGather(character, orebase)
	local ch_gather = self:getChGather(character)
	--if not ch_gather then return true end
	
	local is_ok, err_id = true
	
	if is_ok then
		local buffer_id = orebase.buffer_id
		local buffer_num = orebase.buffer_num
		local ch_scene_buffer = self:getChSceneBuffer(character, buffer_id)
		
		if ch_scene_buffer then
			-- 检查身上捡的已满上限
			local scene_base = SceneBaseService:getSceneBaseById(character.scene_id)
			local scene_buffer_base = SceneBufferBaseService:getSceneBufferBaseByScene(scene_base, buffer_id)
			if scene_buffer_base and ch_scene_buffer.num + buffer_num > scene_buffer_base.max_pickup_num then
				is_ok, err_id = false, errorCodes.SCENE_BUFFER_GATHER_FULL
			end
		end
	end
	
	return is_ok, err_id
end

-- 检查身上指定场景BUFFER已满
function SceneBufferService:isSceneBufferFull(character, buffer_id)
	local scene_base = SceneBaseService:getSceneBaseById(character.scene_id)
	local scene_buffer_base = SceneBufferBaseService:getSceneBufferBaseByScene(scene_base, buffer_id)
	if scene_buffer_base then
		-- 检查身上捡的已满上限
		local ch_scene_buffer = SceneBufferService:getChSceneBuffer(character, buffer_id)
		if ch_scene_buffer and ch_scene_buffer.num >= scene_buffer_base.max_pickup_num then
			return true
		end
	end
	
	return false
end

-- 检查该场景目前是否有场景BUFF
function SceneBufferService:hasSceneBuffer(character, aoi_scene)
	local aoi_scene = aoi_scene or GameObjectService:getAoiScene(character)
	local scene_buffer = aoi_scene.scene_buffer
	
	if not scene_buffer then
		return false
	end
	
	return true
end

-- 删除已拾取的BUFF掉落物
function SceneBufferService:delSceneBuffer(character, buffer_id, del_num, is_bc_appear)
	local ch_scene_buffer, ch_scene_buffers = self:getChSceneBuffer(character, buffer_id)
	if ch_scene_buffer then
		local now_num = del_num and ch_scene_buffer.num - del_num or 0
		if now_num < 0 then now_num = 0 end
		ch_scene_buffer.num = now_num
		SceneBufferService:sendSceneBufferUp(character, ch_scene_buffer)
		
		-- 广播场景BUFF附着状态
		if is_bc_appear then
			SceneBufferService:sendAppearChSceneBuffers(character, buffer_id)
		end
		
		if buffer_id == SceneBufferDefs.SCENE_BUFFER_BUFF_ID_SHENJIANHUN then
			ch_scene_buffers[buffer_id] = nil
		end
	end
	
	return ch_scene_buffer
end

function SceneBufferService:enableRefSceneBuffer(aoi_scene, scene_base, scene_buffer_base)
	local is_ok = true
	local scene_id = scene_base.id
	if G3v3Service:isIn3v3( scene_id ) and not G3v3Service:isFighting( aoi_scene ) then 
		is_ok = false
	elseif DaojianjueService:isInDaojj( scene_id ) and DaojianjueService:isFinish( aoi_scene ) then
		is_ok = false
	end
	return is_ok
end

-- 获取有外观的角色场景BUFF ID列表
function SceneBufferService:getAppearChSceneBuffIds(character)
	local ch_scene_buffers = self:getChSceneBuffers(character)
	local arr_scene_buffer_id = {}
	local attach_scene_appear_buffer_ids = Statics.attach_scene_appear_buffer_ids
	for scene_buffer_id, ch_scene_buffer in pairs(ch_scene_buffers) do
		if ch_scene_buffer.num > 0 then
			local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
			if scene_buffer_base.attach_res_id > 0 or attach_scene_appear_buffer_ids[scene_buffer_base.id] then
				arr_scene_buffer_id[#arr_scene_buffer_id+1] = {scene_buffer_id=scene_buffer_id}
			end
		end
	end
	
	return arr_scene_buffer_id
end

do
	local rsp_opcode = opCodes.M2C_SCENE_BUFFER_UPDATE
	local msg_name = "PackSceneBuffer.M2C_SCENE_BUFFER_UPDATE"
	local msg_proto = {}
	function SceneBufferService:sendSceneBufferUp(character, ch_scene_buffer, comm_cd_expire_info)
		msg_proto.buffers = {ch_scene_buffer}
		if comm_cd_expire_info then
			msg_proto.cd_expire_comm = comm_cd_expire_info and comm_cd_expire_info.cd_expire or 0
			msg_proto.cd_stime_comm = comm_cd_expire_info and comm_cd_expire_info.cd_stime or 0
		else
			msg_proto.cd_expire_comm = nil
			msg_proto.cd_stime_comm = nil
		end
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_SCENE_BUFFER_GET
	local msg_name = "PackSceneBuffer.M2C_SCENE_BUFFER_GET"
	local msg_proto = {}
	function SceneBufferService:sendSceneBuffers(character)
		local ch_scene_buffers, _, scene_buffer = SceneBufferService:getChSceneBuffers(character)
		local comm_cd_expire_info = scene_buffer.gcid2comm_cd_expire[character.gcid]
		msg_proto.buffers = table.values(ch_scene_buffers)
		msg_proto.cd_expire_comm = comm_cd_expire_info and comm_cd_expire_info.cd_expire or 0
		msg_proto.cd_stime_comm = comm_cd_expire_info and comm_cd_expire_info.cd_stime or 0
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

-- RSP 有外观的角色场景BUFF列表
function SceneBufferService:sendAppearChSceneBuffers(character, use_buffer_id, buffer_base)
	--[[
	-- 如果使用的BUFFER ID没有附加效果，不需要广播
	local buffer_base = buffer_base or BufferBaseService:getBufferBaseById(use_buffer_id)
	local attach_scene_appear_buffer_ids = Statics.attach_scene_appear_buffer_ids
	if buffer_base.attach_res_id <= 0 and not attach_scene_appear_buffer_ids[buffer_base.id] then
		return
	end
	
	-- 广播角色身上所有的有附加效果的BUFF给场景内所有玩家
	local rsp_data = {}
	rsp_data.opcode = opCodes.M2C_SCENE_BUFFER_APPEAR_BUFFERS
	
	local appear_ch_scene_buffs = {}
	appear_ch_scene_buffs[character.aoi_id] = self:getAppearChSceneBuffIds(character)
	rsp_data.ch_scene_buffs = appear_ch_scene_buffs
	
	local arr_gpid = GameObjectService:getGPids(character.space_id)
	WorldPacket:m2cSendOK(rsp_data, g_packet_id, arr_gpid)
	--]]
end

-- 返回所有有附加效果给客户端
-- 上线的时候通知客户端
function SceneBufferService:sendAppearAllChSceneBuffers(character)
--[[
	local _, gcid2ch_scene_buffers = self:getChSceneBuffers(character)
	
	local rsp_data = {}
	rsp_data.opcode = opCodes.M2C_SCENE_BUFFER_APPEAR_BUFFERS
	local appear_ch_scene_buffs = {}
	local attach_scene_appear_buffer_ids = Statics.attach_scene_appear_buffer_ids
	
	for cid, ch_scene_buffers in pairs(gcid2ch_scene_buffers) do
		local ch_obj = CharacterService:getCharacterById(cid)
		if ch_obj then
			local arr_buffer_id = {}
			for buffer_id, ch_scene_buffer in pairs(ch_scene_buffers) do
				if ch_scene_buffer.num > 0 then
					local buffer_base = BufferBaseService:getBufferBaseById(buffer_id)
					if buffer_base.attach_res_id > 0 or attach_scene_appear_buffer_ids[buffer_base.id]  then
						arr_buffer_id[#arr_buffer_id+1] = {buffer_base.id, ch_scene_buffer.bomb_mtime or 0}
					end
				end
			end
			
			appear_ch_scene_buffs[ch_obj.aoi_id] = arr_buffer_id
		end
	end
	
	if not table.isTableEmpty(appear_ch_scene_buffs) then
		rsp_data.ch_scene_buffs = appear_ch_scene_buffs
		WorldPacket:m2cSendOK(rsp_data, g_packet_id, character.gpid)
	end
	--]]
end

