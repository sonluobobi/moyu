--[[
天魔灭心系统service
author : xingzeng
date : 2015-05-06
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local tableInsert = table.insert
local math_ceil = math.ceil
local random = math.random
local TianmoDefs = TianmoDefs
local TianmoConfig = TianmoConfig
local AoiObjectType = AoiObjectType
local table = table
local tableSort = table.sort
local Statics = Statics
local TianmosDao = TianmosDao
local OKMsgCodes = OKMsgCodes
local mergeUInt = external.mergeUInt
local SplitUInt = external.splitUInt
local ActiveDefs = ActiveDefs
local OpenFuncDefs = OpenFuncDefs

TianmoService = TianmoService or {}
setmetatable(TianmoService, SceneServiceInterface)

local TianmoService = TianmoService

local SceneService, GameObjectService, TeamService, MonsterService, CharacterVipService, CharacterService

function TianmoService:onAfterLoadLua()
	MonsterService = _G.MonsterService
	SceneService = _G.SceneService
	GameObjectService = _G.GameObjectService
	TeamService = _G.TeamService
	CharacterVipService = _G.CharacterVipService
	CharacterService = _G.CharacterService
end

-- 创建房间对象
function TianmoService:createRoom(character, aoi_scene)
	local aoi_scene = aoi_scene or GameObjectService:getAoiScene(character)
	if aoi_scene.tianmo_room then
		return
	end
	
	local lay = self:getLayBySid(character.scene_id)
	local tianmo_room = {}
	tianmo_room.scene_ins_id = aoi_scene.space_id
	tianmo_room.scene_id = character.scene_id
	tianmo_room.status = TianmoDefs.TIANMO_ROOM_STATUS_MATCHING
	tianmo_room.status_expire = TianmoDefs.tianmo_status_durationmatching[lay] + Time:getSecondsNow()
	tianmo_room.lay = lay
	tianmo_room.teams = {}
	tianmo_room.win_team_id = 0
	tianmo_room.gcid2teamid = {}
	tianmo_room.group_id = self:getGroupId(character)
	
	aoi_scene.tianmo_room = tianmo_room
	
	return tianmo_room
end

-- 生成新的天魔实列
function TianmoService:reNewTianmoIns(group_id)
	local dao = table.structure_clone(TianmoDao)
	TianmosDao.daos[group_id] = dao
	
	local tianmo_ins = {}
	dao.tianmo_ins = tianmo_ins
	
	return tianmo_ins, dao
end

-- 创建天魔灭心实列
function TianmoService:createTianmoIns(b2m_tianmo_ins)
	local tianmo_ins = self:getTianmoIns(b2m_tianmo_ins.group_id)
	tianmo_ins.id = b2m_tianmo_ins.id
	tianmo_ins.pass_time = b2m_tianmo_ins.pass_time
	tianmo_ins.open_time = b2m_tianmo_ins.open_time
	tianmo_ins.etime = b2m_tianmo_ins.etime
	tianmo_ins.created = b2m_tianmo_ins.created
	tianmo_ins.nowtop_room = {}
	tianmo_ins.is_win = false
	tianmo_ins.is_rewarded = false
end

-- 创建BOSS房间
function TianmoService:createBossRoom(b2m_tianmo_ins)
	local group_id = b2m_tianmo_ins.group_id
	local tianmo_ins, tianmo_dao = self:getTianmoIns(group_id)
	
	if tianmo_dao.boss_room_ins then
		tianmo_dao.old_boss_room_ins = tianmo_dao.boss_room_ins
		tianmo_dao.old_ch_reach_lays = tianmo_dao.ch_reach_lays
	end
	local boss_room_ins = {}
	boss_room_ins.scene_ins_id = b2m_tianmo_ins.boss_room_sinsid
	boss_room_ins.status = TianmoDefs.TIANMO_BOSS_ROOM_STATUS_OPEN
	boss_room_ins.status_expire = tianmo_ins.open_time + 3600
	boss_room_ins.history_team_ids = {}
	boss_room_ins.history_team_num = 0
	boss_room_ins.teams = {}
	boss_room_ins.disbanded_teams = {}
	boss_room_ins.lay = TianmoDefs.TIANMO_LAY_TOTAL_NUM
	boss_room_ins.kill_boss_gcid = 0
	boss_room_ins.kill_boss_gpid = 0
	boss_room_ins.gcid2teamid = {}			--注意：该列表是不会删，队员离开不会删
	boss_room_ins.group_id = group_id
	boss_room_ins.harm_list = {}
	boss_room_ins.toplist = {}
	boss_room_ins.tianshen_opened_ids = {}
	boss_room_ins.ts_cur_opened_info = {id=0}
	tianmo_dao.boss_room_ins = boss_room_ins
	
	tianmo_dao.ch_reach_lays = {}
end

-- 结束、发奖
function TianmoService:finish(group_id, is_win)
	local tianmo_ins, tianmo_dao = self:getTianmoIns(group_id)
	local boss_room_ins = tianmo_dao.boss_room_ins
	
	-- 已经结束了
	if tianmo_ins.pass_time > 0 then
		return 
	end
	
	tianmo_ins.pass_time = Time:getSecondsNow()
	tianmo_ins.is_win = is_win
	local aoi_scene = GameObjectService:getAoiSceneBySpaceId(boss_room_ins.scene_ins_id)
	
	-- 更新排行榜
	if not is_win and aoi_scene then
		self:_upToplist(aoi_scene, boss_room_ins, nil, true)
	end
	
	-- 派发奖励
	self:_rewardCalcSend(tianmo_dao, is_win)
	
	-- 全服广播已结束
	-- TODO
	
	if aoi_scene then
		-- BOSS怪物删除
		local boss_aoi_id = boss_room_ins.boss_aoi_id
		if boss_aoi_id and GameObjectService:getGameObjectByAoiId(aoi_scene, boss_aoi_id) then
			GameObjectService:delObjByAoiId(aoi_scene, boss_aoi_id)
			Logger:warn("------------ tianmo finsih. del boss:", boss_aoi_id, g_mapserver_id)
		end
		
		-- RSP
		TianmoService:sendTianmoEnd(aoi_scene, boss_room_ins)
	end
	
end

function TianmoService:_formatRewardEquips(reward_equips)
	local ID_2_VALUE = OpenFuncDefs.ID_2_VALUE
	local baoxiangs_ver_conf = TianmoConfig.baoxiangs_ver_conf
	local reward_equips_new = {}
	for equip_id, equip_num in pairs(reward_equips) do
		local confs = baoxiangs_ver_conf[equip_id]
		if confs then
			local new_baox_eid = equip_id
			for i = #confs, 1, -1 do
				local conf = confs[i]
				if ID_2_VALUE[conf.open_func_id] ~= 999 then
					new_baox_eid = conf.baox_eid
					break
				end
			end
			reward_equips_new[new_baox_eid] = equip_num
		else
			reward_equips_new[equip_id] = equip_num
		end
	end
	return reward_equips_new
end

function TianmoService:_rewardCalcSend(tianmo_dao, is_win)
	local ch_reach_lays = tianmo_dao.ch_reach_lays
	local boss_room_ins = tianmo_dao.boss_room_ins
	local reward_config = TianmoConfig.reward_config
	local tianmo_ins = tianmo_dao.tianmo_ins
	
	if tianmo_ins.is_rewarded then
		return 
	end
	
	-- 标志已经发奖
	tianmo_ins.is_rewarded = true
	
	local game_type_id = Statics.PK_GAME_TYPE_ID_TIANMO
	local child_game_type_id = self:getChildGameTypeIdByGid(boss_room_ins.group_id)
	local rewarded_gcids = {}		-- 记录已发奖的角色ID，避免重复发奖
	local rewards_conf = TianmoConfig.reward_config[child_game_type_id]
	
	local kill_boss_gcid, kill_boss_gpid = boss_room_ins.kill_boss_gcid, boss_room_ins.kill_boss_gpid
	local is_kill_boss = kill_boss_gcid > 0 and true or false
	
	-- 击杀BOSS奖励
	if is_kill_boss then
		local reward_equips = self:_formatRewardEquips(rewards_conf.kill_boss_rewards)
		RewardService:reward(game_type_id, child_game_type_id, kill_boss_gpid, kill_boss_gcid, {is_killboss_reward=1,is_kill_boss=is_kill_boss,reward_equips=reward_equips})
	end
	
	-- 排名奖励
	local toplist = boss_room_ins.toplist
	for _, top in pairs(toplist) do
		local gcid2gpids = top.gcid2gpids
		local reward_equips = self:_formatRewardEquips(rewards_conf.rank_rewards[top.rank])
		for gcid, gpid in pairs(gcid2gpids) do
			if not rewarded_gcids[gcid] then
				rewarded_gcids[gcid] = true
				RewardService:reward(game_type_id, child_game_type_id, gpid, gcid, {rank=top.rank,is_rank_reward=1,is_kill_boss=is_kill_boss,reward_equips=reward_equips})
			end
		end
	end
	
	-- 1-6层奖励
	local gcid = 0
	for gcid, reach_lay_info in pairs(ch_reach_lays) do
		local lay = reach_lay_info.lay
		if not rewarded_gcids[gcid] and lay >= 1 then
			local reward_equips = self:_formatRewardEquips(rewards_conf.lay_rewards[lay])
			rewarded_gcids[gcid] = true
			RewardService:reward(game_type_id, child_game_type_id, reach_lay_info.gpid, gcid, {lay=lay,is_lay_reward=1,is_kill_boss=is_kill_boss,reward_equips=reward_equips})
		end
	end
	
	-- 成就系统
	if kill_boss_gcid > 0 then
		local character = CharacterService:getCharacterByGcid(kill_boss_gcid)
		if character then
			AchieveService:onCheckAchieve(character, AchieveDefs.ACHIEVE_SORT_ID_DO_TIANMO_KILLER)
		end
	end
	for _, top in pairs(toplist) do
		local gcid2gpids = top.gcid2gpids
		for gcid, gpid in pairs(gcid2gpids) do
			local character = CharacterService:getCharacterByGcid(gcid)
			if character then
				AchieveService:onCheckAchieve(character, AchieveDefs.ACHIEVE_SORT_ID_CNT_TIANMO_WIN)
			end
		end
	end
end

-- 获取房间信息
function TianmoService:getRoom(character, aoi_scene)
	local aoi_scene = aoi_scene or GameObjectService:getAoiScene(character)
	if aoi_scene.scene_id == TianmoConfig.boss_room_scene_id then
		local tianmo_dao = self:getDao(aoi_scene.tianmo_group_id)
		return tianmo_dao.boss_room_ins, aoi_scene, true
	end
	return aoi_scene.tianmo_room, aoi_scene, false
end

-- 获取BOSS房间
function TianmoService:getBossRoom(group_id)
	local tianmo_dao = self:getDao(group_id)
	return tianmo_dao and tianmo_dao.boss_room_ins or nil
end

-- 获取可以前往的层数
function TianmoService:getGotoLay(character)
	local room = self:getRoom(character)
	local goto_lay = nil
	
	if not room then
		goto_lay = 1
	end
	
	-- 已经到达了BOSS房间
	if not goto_lay and room.lay >= TianmoDefs.TIANMO_LAY_TOTAL_NUM then
		goto_lay = room.lay
	end
	
	-- 已通关某一层
	if not goto_lay and (room.status == TianmoDefs.TIANMO_ROOM_STATUS_PASS or 
		room.status == TianmoDefs.TIANMO_ROOM_STATUS_LUNKONG) then
		local my_team_id = room.gcid2teamid[character.gcid]
		if room.win_team_id ~= my_team_id then
			goto_lay = room.lay
		else
			goto_lay = room.lay + (room.go_lay_num or 1)
		end
	end
	
	if goto_lay and goto_lay > TianmoDefs.TIANMO_LAY_TOTAL_NUM then
		goto_lay = TianmoDefs.TIANMO_LAY_TOTAL_NUM
	end
	
	-- 未通关某一层
	if not goto_lay then goto_lay = room.lay end
	
	-- TEST
	--if goto_lay < 6 then goto_lay = 6 end
	
	return goto_lay, TianmoConfig.lay2scene_id[goto_lay]
end

--获取下一层场景ID
function TianmoService:getGotoSceneId(character, lay, door_type)
	assert(lay > 0)
	door_type = 1
	
	local dst_scene_id = TianmoConfig.lay2scene_id[door_type][lay]
	return dst_scene_id
end

-- 获取当前所在的层
function TianmoService:getLayBySid(scene_id)
	local lay2scene_id = TianmoConfig.lay2scene_id
	
	for door_type, scene_ids in pairs(lay2scene_id) do
		for lay_t, scene_id_t in pairs (scene_ids) do
			if scene_id == scene_id_t then
				return lay_t
			end
		end
	end
end

function TianmoService:getRoomTeamNum(room)
	local teams, gcid2teamid, scene_ins_id = room.teams, room.gcid2teamid, room.scene_ins_id
	local team_num = 0
	
	for _, team_t in pairs(teams) do team_num = team_num + 1 end
	if team_num <= 0 then
		return team_num
	end
	
	team_num = 0
	local teams_t = {}
	for gcid_t, team_id_t in pairs(gcid2teamid) do
		local ch_obj = CharacterService:getCharacterByGcid(gcid_t)
		if ch_obj and ch_obj.space_id == scene_ins_id then
			if not teams_t[team_id_t] then
				teams_t[team_id_t] = 1
				team_num = team_num + 1
			end
		end
	end
	
	return team_num
end

--获取当前存活的队伍数
function TianmoService:getRoomTeamNumLive(room)
	local teams, gcid2teamid, scene_ins_id = room.teams, room.gcid2teamid, room.scene_ins_id
	local team_num = 0
	
	for _, team_t in pairs(teams) do team_num = team_num + 1 end
	if team_num <= 0 then
		return team_num
	end
	
	team_num = 0
	local teams_t = {}
	for gcid_t, team_id_t in pairs(gcid2teamid) do
		local ch_obj = CharacterService:getCharacterByGcid(gcid_t)
		if ch_obj and ch_obj.space_id == scene_ins_id then
			local team_info = teams[team_id_t]
			if team_info and team_info.score > 0 and not teams_t[team_id_t] then
				teams_t[team_id_t] = team_info
				team_num = team_num + 1
			end
		end
	end
	
	return team_num, teams_t
end

function TianmoService:getDao(group_id, is_new)
	local dao = TianmosDao.daos[group_id]
	if is_new and not dao then
		dao = table.lightCopyTable(TianmoDao)
		TianmosDao.daos[group_id] = dao
	end
	return dao
end

function TianmoService:getTianmoIns(group_id, is_new)
	local dao = TianmoService:getDao(group_id, is_new)
	local tianmo_ins = dao and dao.tianmo_ins or nil
	if is_new and not tianmo_ins then
		tianmo_ins = {}
		dao.tianmo_ins = tianmo_ins
	end
	return tianmo_ins, dao
end

function TianmoService:getGroupIdByAoiScene(aoi_scene)
	local tianmo_room = self:getRoom(nil, aoi_scene)
	return tianmo_room and tianmo_room.group_id or nil
end

function TianmoService:getGroupId(character, child_game_type_id, big_group_id, area_id)
	if not child_game_type_id then
		local team = TeamService:getTeamByCid(character.gcid)
		child_game_type_id = team.child_game_type_id
	end
	
	-- 50级BOSS 单服化
	if child_game_type_id == ActiveDefs.ACTIVE_SUB_ID_TIANMO_50 and 999 == OpenFuncDefs.ID_2_VALUE[OpenFuncDefs.ID_FOR_BOSS50] then
		big_group_id = character and character.area_id or area_id
	-- 65级BOSS 单服化
	elseif child_game_type_id == ActiveDefs.ACTIVE_SUB_ID_TIANMO_65 and 999 == OpenFuncDefs.ID_2_VALUE[OpenFuncDefs.ID_FOR_BOSS65] then
		big_group_id = character and character.area_id or area_id
	end
	
	-- 按运营的配置分组
	if not big_group_id then
		big_group_id = PkserverMappingService:getGroupId(character, Statics.PK_GAME_TYPE_ID_TIANMO)
	end
	
	local group_id = mergeUInt(big_group_id, child_game_type_id)
	return group_id, child_game_type_id
end

function TianmoService:getChildGameTypeIdByGid(group_id)
	local big_group_id, child_game_type_id = SplitUInt(group_id)
	return child_game_type_id
end

function TianmoService:createRoomTeamInfo(character)
	local team = TeamService:getTeamByCid(character.gcid)
	assert(team)
	local tianmo_team_info = self:_createTianmoTeamInfo(team, self:getLayBySid(character.scene_id))
	return tianmo_team_info, team
end

-- 检查是否可以进入BOSS房间
function TianmoService:checkEntryBossRoom(group_id)
	local tianmo_dao = self:getDao(group_id)
	local boss_room_ins = tianmo_dao.boss_room_ins
	if not boss_room_ins then
		return false, errorCodes.TIANMO_BOSSROOM_NOOPEN
	end
	
	if boss_room_ins.status == TianmoDefs.TIANMO_BOSS_ROOM_STATUS_CLOSE then
		return false, errorCodes.TIANMO_BOSSROOM_CLOSE
	end
	
	if boss_room_ins.history_team_num >= TianmoDefs.TIANMO_BOSS_ROOM_TEAM_NUM_MAX then
		return false, errorCodes.TIANMO_BOSSROOM_CLOSE
	end
	
	local cur_time = Time:getSecondsNow()
	
	if boss_room_ins.status == TianmoDefs.TIANMO_BOSS_ROOM_STATUS_OPEN then
		return true
	end
	
	return false, errorCodes.TIANMO_ALREADY_END
end

function TianmoService:isTianmo(scene_id)
	local lay2scene_id = TianmoConfig.lay2scene_id
	for _, scene_ids in pairs(lay2scene_id) do
		for _, scene_id_t in pairs(scene_ids) do
			if scene_id_t == scene_id then
				return true
			end
		end
	end
	
	return false
end

function TianmoService:isBossScene(scene_id)
	 return scene_id == TianmoConfig.lay2scene_id[1][TianmoDefs.TIANMO_LAY_TOTAL_NUM]
end

-- 活动是否已经结束
function TianmoService:isEnd(delay_sec, group_id)
	assert(group_id)
	
	local delay_sec = delay_sec or 0
	local tianmo_ins, tianmo_dao = self:getTianmoIns(group_id)
	local boss_room_ins = tianmo_dao.boss_room_ins
	local etime = tianmo_ins.etime
	local pass_time = tianmo_ins.pass_time
	local cur_time = Time:getSecondsNow()
	if pass_time > 0 then etime = pass_time end
	
	return etime + delay_sec <= cur_time
end

-- BOSS房间是否已经关闭
function TianmoService:isBossRoomClose(group_id)
	local boss_room_ins = self:getBossRoom(group_id)
	
	if boss_room_ins.history_team_num >= TianmoDefs.TIANMO_BOSS_ROOM_TEAM_NUM_MAX then
		return true
	end
	
	return boss_room_ins.status ~= TianmoDefs.TIANMO_BOSS_ROOM_STATUS_OPEN
end

--判断传送点是否已经开启
function TianmoService:isRoomTransferOpen(character)
	local aoi_scene = GameObjectService:getAoiScene(character)
	local tianmo_room = aoi_scene.tianmo_room
	if tianmo_room and tianmo_room.status ~= TianmoDefs.TIANMO_ROOM_STATUS_PASS then
		return false, errorCodes.TIANMO_TRANSFER_NO_OPEN
	end
	
	return true
end

--记录进入BOSS房间
function TianmoService:recordTeam2BossRoom(character, group_id)
	local team = TeamService:getTeamByCid(character.gcid)
	local team_id = team.id
	
	local tianmo_team_info = self:_createTianmoTeamInfo(team, TianmoDefs.TIANMO_LAY_TOTAL_NUM)
	local group_id = group_id or self:getGroupId(character)
	local boss_room_ins = self:getBossRoom(group_id)
	local teams, gcid2teamid = boss_room_ins.teams, boss_room_ins.gcid2teamid
	teams[team_id] = tianmo_team_info
	
	for _, member in pairs(team.members) do
		gcid2teamid[member.gcid] = team_id
	end
	
	boss_room_ins.history_team_ids[team_id] = 1
	boss_room_ins.history_team_num = boss_room_ins.history_team_num + 1
	team.order_by = boss_room_ins.history_team_num
end

function TianmoService:recordTeam2Room(tianmo_room, character, group_id)
	local tianmo_team_info, team = self:createRoomTeamInfo(character)
	local team_id = team.id
	if tianmo_team_info then
		if not tianmo_room.teams[team_id] then
			tianmo_room.teams[team_id] = tianmo_team_info
		end
		
		local members = team.members
		local gcid2teamid = tianmo_room.gcid2teamid
		for _, member in pairs(members) do
			gcid2teamid[member.gcid] = team_id
		end
	end
end

-- 记录当前到达最高层的队伍数
function TianmoService:recordTopLayTeamNum(dst_scene_id, team_id, group_id)
	local tianmo_ins = self:getTianmoIns(group_id)
	local nowtop_room = tianmo_ins.nowtop_room
	
	-- 记录当前打到的最高层的房间信息
	local nowtop_lay = nowtop_room.lay or 0
	local now_lay = self:getLayBySid(dst_scene_id)
	if now_lay > nowtop_lay then
		nowtop_room.lay = now_lay
		nowtop_room.scene_id = dst_scene_id
		nowtop_room.team_num = 1
		nowtop_room.first_team_id = team_id
		
	elseif now_lay == nowtop_lay then
		nowtop_room.team_num = nowtop_room.team_num + 1
	end		
end

-- 通知普通房间的玩家玩法已结束
function TianmoService:bcTianmoEnd(aoi_scene, group_id)
	if not self:isEnd(nil, group_id) then
		return
	end
	
	local boss_room_ins = TianmoService:getBossRoom(group_id)
	local is_bc_tianmo_end = aoi_scene.is_bc_tianmo_end or 0
	if is_bc_tianmo_end == 0 then
		TianmoService:sendTianmoEnd(aoi_scene, boss_room_ins)
		aoi_scene.is_bc_tianmo_end = 1
	end
end

-- 获取在同一房间的队伍成员列表
-- 房间的状态更新
function TianmoService:roomStatusUpdate(aoi_scene)
	local tianmo_room = self:getRoom(nil, aoi_scene)
	if not tianmo_room then return end
	
	if self:isEnd(nil, tianmo_room.group_id) then
		if aoi_scene.scene_id ~= TianmoConfig.boss_room_scene_id then
			TianmoService:bcTianmoEnd(aoi_scene, tianmo_room.group_id)
		end
		return
	end
	
	if self:isBossRoomClose(tianmo_room.group_id) then
		return
	end
	
	local status, status_expire = tianmo_room.status, tianmo_room.status_expire
	local cur_time = Time:getSecondsNow()
	
	if aoi_scene.scene_id == TianmoConfig.boss_room_scene_id then
		return TianmoService:bossRoomStatusUpdate(aoi_scene, tianmo_room)
	end
	
	-- 等待匹配中
	if status == TianmoDefs.TIANMO_ROOM_STATUS_MATCHING then
		-- 检查是否已经有2个队伍， 如果有，则状态切换到已匹配状态
		local team_num = self:getRoomTeamNum(tianmo_room)
		if team_num >= 2 then
			tianmo_room.status = TianmoDefs.TIANMO_ROOM_STATUS_MATCHED
			tianmo_room.status_expire = cur_time + TianmoDefs.TIANMO_STATUS_DURATION_MATCHED
			return TianmoService:sendRoomStatusUp(aoi_scene, tianmo_room)
		end
		
		-- 超时进入轮空状态
		if status_expire <= cur_time then
			tianmo_room.status = TianmoDefs.TIANMO_ROOM_STATUS_LUNKONG
			tianmo_room.status_expire = cur_time + TianmoDefs.TIANMO_STATUS_DURATION_LUNKONG
			return TianmoService:sendRoomStatusUp(aoi_scene, tianmo_room)
		end
		
	-- 已经匹配完成
	elseif status == TianmoDefs.TIANMO_ROOM_STATUS_MATCHED then
		-- 只剩1方队伍
		local team_num = self:getRoomTeamNum(tianmo_room)
		if team_num == 1 then
			self:roomPass(aoi_scene)
			return --TianmoService:sendRoomStatusUp(aoi_scene, tianmo_room)
		end
		
		-- 超时进入战斗状态
		if status_expire <= cur_time then
			tianmo_room.status = TianmoDefs.TIANMO_ROOM_STATUS_FIGHTING
			tianmo_room.status_expire = cur_time + TianmoDefs.TIANMO_STATUS_DURATION_FIGHTING
			return TianmoService:sendRoomStatusUp(aoi_scene, tianmo_room)
		end
		
	elseif status == TianmoDefs.TIANMO_ROOM_STATUS_FIGHTING then
		-- 只剩1方队伍
		local team_num = self:getRoomTeamNum(tianmo_room)
		if team_num == 1 then
			self:roomPass(aoi_scene)
			return --TianmoService:sendRoomStatusUp(aoi_scene, tianmo_room)
		end
		
		-- 超时进入通关状态
		if status_expire <= cur_time then
			self:roomPass(aoi_scene)
			return --TianmoService:sendRoomStatusUp(aoi_scene, tianmo_room)
		end
		
		-- 重新计算积分
		if status == TianmoDefs.TIANMO_ROOM_STATUS_FIGHTING then
			local teams = tianmo_room.teams
			for _, team in pairs(teams) do
				local team_id = team.id
				local team_member_num = TeamService:getTeamMemberNum(team_id)
				local now_score = self:_getTeamScoreDefault(team_member_num)
				
				local old_score = team.score
				if now_score > 0 and old_score > now_score then
					team.score = now_score
					TianmoService:sendTeamsScores(aoi_scene, tianmo_room, team_id)
				end
			end
		end
		
	-- 轮空
	elseif status == TianmoDefs.TIANMO_ROOM_STATUS_LUNKONG then
		-- 超时进入通关状态
		if status_expire <= cur_time then
			self:roomPass(aoi_scene, nil, true)
			return --TianmoService:sendRoomStatusUp(aoi_scene, tianmo_room)
		end
		
	-- 结束
	elseif status == TianmoDefs.TIANMO_ROOM_STATUS_PASS then
		--
	end
	
	return tianmo_room
end

-- BOSS房间的状态更新
function TianmoService:bossRoomStatusUpdate(aoi_scene, room)
	local group_id = room.group_id
	local boss_room_ins = self:getBossRoom(group_id)
	if self:isEnd(nil, group_id) then
		return
	end
	
	local status, status_expire = boss_room_ins.status, boss_room_ins.status_expire
	local cur_time = Time:getSecondsNow()
	
	-- 广播BOSS伤害加成
	if Time.is_5s_start then	
		self:bcBossHarmAddi(aoi_scene, group_id, boss_room_ins)
	end
	
	if status == TianmoDefs.TIANMO_BOSS_ROOM_STATUS_OPEN then
		-- 进入人数已满
		if boss_room_ins.history_team_num >= TianmoDefs.TIANMO_BOSS_ROOM_TEAM_NUM_MAX then
			boss_room_ins.status = TianmoDefs.TIANMO_BOSS_ROOM_STATUS_CLOSE
			boss_room_ins.status_expire = cur_time + 3600
			TianmoService:sendBossRoomStatusUp(aoi_scene, boss_room_ins)
			
			-- 通知PKBASE 关闭玩家进入
			local pack_data = {group_id = boss_room_ins.group_id}
			ServerCall:m2bCall('TianmoCtrl.m2b_bossRoomFull', 0, pack_data)
			return
		end
		
	elseif status == TianmoDefs.TIANMO_BOSS_ROOM_STATUS_CLOSE then
	
	end
	
end

function TianmoService:roomPass(aoi_scene, win_team_id, b_timeout)
	local tianmo_room = aoi_scene.tianmo_room
	local cur_time = Time:getSecondsNow()
	
	if self:isBossRoomClose(tianmo_room.group_id) then
		return
	end
	
	-- 如果已经PASS，直接返回
	if tianmo_room.status == TianmoDefs.TIANMO_ROOM_STATUS_PASS then
		Logger:info('[TianmoService:roomPass] already pass', aoi_scene.scene_id, aoi_scene.space_id, win_team_id)
		return
	end
	
	if not win_team_id then
		local teams = tianmo_room.teams
		local team_id1, team_id2
		for _, team in pairs(teams) do
			if not team_id1 then team_id1 = team.id
			else team_id2 = team.id end
		end
		if not team_id2 then
			win_team_id = team_id1
		else
			local team1, team2 = teams[team_id1], teams[team_id2]
			local team1_id, team2_id = team1.id, team2.id
			
			-- 对比积分
			if team1.score > team2.score then
				win_team_id = team1_id
			elseif team1.score < team2.score then
				win_team_id = team2_id
			else
				-- 对比总战力
				if team1.fc >= team2.fc then
					win_team_id = team1_id
				elseif team1.fc < team2.fc then
					win_team_id = team2_id
				end
			end
		end
	end
	
	-- 场景内没有玩家了
	if not win_team_id then
		tianmo_room.status = TianmoDefs.TIANMO_ROOM_STATUS_PASS
		tianmo_room.status_expire = cur_time + 900
		tianmo_room.pass_time = cur_time
		tianmo_room.win_team_id = 0
		tianmo_room.is_timeout = true
		return
	end
	
	-- 进入通关状态
	tianmo_room.status = TianmoDefs.TIANMO_ROOM_STATUS_PASS
	tianmo_room.status_expire = cur_time + 900
	tianmo_room.pass_time = cur_time
	tianmo_room.win_team_id = win_team_id
	tianmo_room.is_timeout = b_timeout and true or false
	
	-- 随机前进层数
	tianmo_room.go_lay_num = 1
	if tianmo_room.lay < TianmoDefs.TIANMO_LAY_TOTAL_NUM - 1 then
		if random(1, 100) <= TianmoDefs.GO_NEXT_LAY_BAOJI_PROBA then
			tianmo_room.go_lay_num = 2
		end
	end
	
	-- 通知客户端已经通关
	self:sendRoomPass(aoi_scene, tianmo_room)
end

function TianmoService:finishTianshen(aoi_scene, team, ts_cur_opened_info)
	-- 天神已完成
	ts_cur_opened_info.win_team_id = team.id
	
	-- 给队伍成员加BUFFER
	local buffer_base = BufferBaseService:getBufferBaseById(TianmoConfig.tianshen_buffer_id)
	local chs = TeamService:getTeamCharacters(team)
	for _, ch in pairs(chs) do
		local is_ok, is_need_bc = BufferService:addTmpBuffer(ch, buffer_base)
		if is_ok and is_need_bc then
			BufferService:bcBuffers(aoi_scene, ch)
		end
	end
	
	-- RSP
	self:sendTianshenFinish(aoi_scene, ts_cur_opened_info)
	
	-- BC
	local msg_params = {team.captain_nick, buffer_base.duration/1000, buffer_base.effect_value*100}
	NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.NOTICE_TIANMO_TIANSHEN, msg_params)
end

function TianmoService:openTianShen(aoi_scene, boss_room_ins, boss_game_obj, tianshen_id, ts_cur_opened_info)
	local tianshen_opened_ids = boss_room_ins.tianshen_opened_ids
	
	ts_cur_opened_info.id = tianshen_id
	ts_cur_opened_info.stime = Time.time_now
	ts_cur_opened_info.win_team_id = nil
	ts_cur_opened_info.boss_mid = boss_game_obj.monster_base.id
	
	-- 记录该天神活动ID已开启过
	tianshen_opened_ids[tianshen_id] = 1
	
	-- 清空所有人的天神伤害
	for _, harm_info in pairs(boss_room_ins.harm_list) do
		harm_info.tianshen_harm_total = 0
	end
	
	-- RSP
	self:sendTianshenStart(aoi_scene, ts_cur_opened_info, boss_room_ins)
end

function TianmoService:isTianshenOpen(aoi_scene, boss_room_ins)
	local tianshen_opened_ids = boss_room_ins.tianshen_opened_ids
	local ts_cur_opened_info = boss_room_ins.ts_cur_opened_info
	
	-- 检查已开启
	if ts_cur_opened_info.id > 0 and not ts_cur_opened_info.win_team_id then
		return true
	else
		return false
	end
end

-- 检查天神下凡是否已开启
-- return nil/int  已开启的天神下凡ID
function TianmoService:checkTianshenOpen(aoi_scene, boss_room_ins)
	local tianshen_opened_ids = boss_room_ins.tianshen_opened_ids
	local ts_cur_opened_info = boss_room_ins.ts_cur_opened_info
	
	-- 检查已开启
	if ts_cur_opened_info.id > 0 and not ts_cur_opened_info.win_team_id then
		return ts_cur_opened_info.id
	end
	
	-- 获取BOSS对象
	local tianshen_open_boss_hp_percs = TianmoConfig.tianshen_open_boss_hp_percs
	local boss_game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, boss_room_ins.boss_aoi_id)
	if not boss_game_obj then
		return
	end
	
	for id, perc in pairs(tianshen_open_boss_hp_percs) do
		if not tianshen_opened_ids[id] then
			-- 天神下凡开启
			if boss_game_obj.max_hp * perc >= boss_game_obj.hp then
				self:openTianShen(aoi_scene, boss_room_ins, boss_game_obj, id, ts_cur_opened_info)
				return id
			end
		end
	end
end

-- 响应进入副本前检查
function TianmoService:checkEnterScene(character, aoi_scene, dst_scene_base)
	return false, 'dony access'
end

-- 场景定时器响应处理函数
function TianmoService:update(time_now, aoi_scene)
	local scene_id = aoi_scene.scene_id
	local scene_ins_id = aoi_scene.space_id
	
	if not TianmoService:isTianmo(scene_id) then
		return
	end
	
	self:roomStatusUpdate(aoi_scene)
	
	local room = self:getRoom(nil, aoi_scene)
	if not room then
		return
	end
	
	if not room.is_kickout and self:isEnd(50, room.group_id) then
		-- 将所有玩家从PK服中剔出
		local chs = GameObjectService:getPlayerGameObjs(aoi_scene)
		for _, character in pairs(chs) do	
			ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
		end
		room.is_kickout = true
	end
	
	
	-- 每5秒
	if Time.is_5s_start then	
		-- BOSS房间
		if scene_id == TianmoConfig.boss_room_scene_id then
			local boss_room_ins = room
			--广播BOSS血量
			local boss_aoi_id = boss_room_ins.boss_aoi_id
			if boss_aoi_id then
				local boss_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, boss_aoi_id)
				if boss_obj then
					local update_data = {
						hp = boss_obj.hp
					}
					SceneService:sendAppearUpdate(aoi_scene, boss_obj, update_data)
				end
			end
		end
	end
	
end

function TianmoService:beforeEnterScene(character, aoi_scene, is_reconnect)
	if is_reconnect then
		return
	end
	
	-- 满血
	ReliveService:characterFullHp(character)
end

function TianmoService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	local scene_id = aoi_scene.scene_id
	if not TianmoService:isTianmo(scene_id) then
		Logger:debug('[TianmoService:onPlayerEnterScene] is not in Tiammo', character.nick)
		return
	end
	
	local gpid = character.gpid
	local gcid = character.gcid
	local group_id = self:getGroupId(character)
	aoi_scene.tianmo_group_id = group_id
	
	local tianmo_room = aoi_scene.tianmo_room
	local boss_room_ins = self:getBossRoom(group_id)
	local team = TeamService:getTeamByCid(gcid)
	local team_id = team.id
	
	if is_reconnect then 
		TianmoService:reconnectRsp(character, aoi_scene, tianmo_room, boss_room_ins)
		return
	end
	
	-- 如果已经结束
	if self:isEnd(nil, group_id) then
		Logger:debug('[TianmoService:onPlayerEnterScene] is end', character.nick)
		return
	end
	
	local now_lay = self:getLayBySid(scene_id)
	
	-- 创建房间
	if not tianmo_room and now_lay < TianmoDefs.TIANMO_LAY_TOTAL_NUM then
		tianmo_room = TianmoService:createRoom(character, aoi_scene)
	end
	
	local tianmo_dao = self:getDao(group_id)
	local is_boss_room = scene_id == TianmoConfig.boss_room_scene_id
	
	-- 记录角色进入的最高层数
	local ch_reach_lays = tianmo_dao.ch_reach_lays
	local reach_lay = ch_reach_lays[gcid]
	if not reach_lay then
		reach_lay = {lay = now_lay, gpid = gpid}
		ch_reach_lays[gcid] = reach_lay
	else
		if reach_lay.lay < now_lay then
			reach_lay.lay = now_lay
		end
	end
	
	local is_myteam_first_entry = false
	
	-- 进入普通房间
	if not is_boss_room then
		is_myteam_first_entry = (not tianmo_room.teams[team_id]) and true or false
		TianmoService:recordTeam2Room(tianmo_room, character, group_id)
		
		-- 状态更新
		self:roomStatusUpdate(aoi_scene)
		
	-- 进入BOSS房间
	else
		TianmoService:bossRoomStatusUpdate(aoi_scene, boss_room_ins)
		
		local _, value = CharacterVipService:isOwnVipFuncWith0(character, VipDefs.VIP_FUNC_ID_BOSS_GUWU)
		if value > 0 then
			local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(SceneBufferDefs.SCENE_BUFFER_ID_GUWU_FREE)
			SceneBufferService:addSceneBuffer(character, scene_buffer_base, value, false)
		end	

		-- 初始化对BOSS伤害信息
		local harm_list = boss_room_ins.harm_list
		local toplist = boss_room_ins.toplist
		local ch_own_harm = harm_list[team_id]
		if ch_own_harm == nil then
			ch_own_harm = {team_id=team_id, harm = 0, rank=99, nicks=TeamService:getTeamNicks(team), gcid2gpids=TeamService:getTeamGcid2Gpids(team)}
			harm_list[team_id] = ch_own_harm
			toplist[#toplist+1] = ch_own_harm
			ch_own_harm.rank = #toplist
		end
	end
	
	-- RSP
	TianmoService:entrySceneRsp(character, team_id, aoi_scene, tianmo_room, boss_room_ins, is_myteam_first_entry)
end

function TianmoService:reconnectRsp(character, aoi_scene, tianmo_room, boss_room_ins)
	local gpid = character.gpid
	self:sendTianmoInfo(character)
	
	if aoi_scene.scene_id ~= TianmoConfig.boss_room_scene_id then
		self:sendTeamsScores(aoi_scene, tianmo_room, nil, gpid)
		self:sendTeamsSimpleInfo(character, tianmo_room, nil, gpid)
		
		-- 已经通关
		if tianmo_room.status == TianmoDefs.TIANMO_ROOM_STATUS_PASS and 
			not self:isBossRoomClose(tianmo_room.group_id)
			then
			self:sendRoomPass(aoi_scene, tianmo_room)
		end
		
		local boss_room_ins = boss_room_ins or TianmoService:getBossRoom(tianmo_room.group_id)
		if boss_room_ins.history_team_num == 0 then
			TianmoService:sendFirstEnterBc(gpid, boss_room_ins.now_enter_max_lay or 1)
		end
	else
		self:sendTeamsSimpleInfo(character, boss_room_ins, nil, gpid)
		self:sendToplist(boss_room_ins, gpid)
		
		if self:isTianshenOpen(aoi_scene, boss_room_ins) then
			local ts_cur_opened_info = boss_room_ins.ts_cur_opened_info
			self:sendTianshenStart(aoi_scene, ts_cur_opened_info, boss_room_ins, gpid)
		end
	end
	
end
	
function TianmoService:entrySceneRsp(character, team_id, aoi_scene, tianmo_room, boss_room_ins, is_myteam_first_entry)
	local gpid = character.gpid
	TianmoService:sendTianmoInfo(character)
	
	if aoi_scene.scene_id ~= TianmoConfig.boss_room_scene_id then
		if is_myteam_first_entry then
			local gpids = GameObjectService:getGPids(aoi_scene, gpid)
			self:sendTeamsSimpleInfo(character, tianmo_room, team_id, gpids)
			self:sendTeamsScores(aoi_scene, tianmo_room, team_id, gpids)
		end
		self:sendTeamsSimpleInfo(character, tianmo_room, nil, gpid)
		self:sendTeamsScores(aoi_scene, tianmo_room, nil, gpid)
		
		local boss_room_ins = boss_room_ins or TianmoService:getBossRoom(tianmo_room.group_id)
		if boss_room_ins.history_team_num == 0 and tianmo_room.lay == 1 then
			self:sendFirstEnterBc(gpid, boss_room_ins.now_enter_max_lay or 1)
		end
	else
		self:sendTeamsSimpleInfo(character, boss_room_ins, nil, gpid)
		local gpids = GameObjectService:getGPids(aoi_scene, gpid)
		self:sendTeamsSimpleInfo(character, boss_room_ins, team_id, gpids)
		self:sendToplist(boss_room_ins, gpid)
		
		if self:isTianshenOpen(aoi_scene, boss_room_ins) then
			local ts_cur_opened_info = boss_room_ins.ts_cur_opened_info
			self:sendTianshenStart(aoi_scene, ts_cur_opened_info, boss_room_ins, gpid)
		end
	end
end
	
function TianmoService:afterLeaveScene(character, aoi_scene, leave_type)
	if not TianmoService:isTianmo(aoi_scene.scene_id) then
		return
	end
	
	-- 如果已经结束
	if self:isEnd(nil, self:getGroupId(character)) then
		return
	end
	
	local gcid = character.gcid
	local room, aoi_scene = TianmoService:getRoom(nil, aoi_scene)
	local scene_ins_id = room.scene_ins_id
	
	local gcid2teamid, teams = room.gcid2teamid, room.teams
	
	-- 整个队伍是否已离开
	local is_in_room = false
	local team_id = gcid2teamid[gcid]
	for gcid_t, team_id_t in pairs(gcid2teamid) do
		if gcid_t ~= gcid and team_id_t == team_id then
			local ch_obj = CharacterService:getCharacterByGcid(gcid_t)
			if ch_obj and ch_obj.space_id == scene_ins_id then
				is_in_room = true
				break
			end
		end
	end
	
	-- 已离开
	if not is_in_room then
		if aoi_scene.scene_id == TianmoConfig.boss_room_scene_id then
			room.disbanded_teams[team_id] = teams[team_id]
		end
		
		if team_id and teams[team_id] then
			teams[team_id] = nil
		end
	end
end

-- 响应杀死敌人
function TianmoService:onPlayerKilled(killer_obj, dead_aoi_ids)
	local aoi_scene = GameObjectService:getAoiScene(killer_obj)
	if not TianmoService:isTianmo(aoi_scene.scene_id) then
		return
	end
	
	local room = self:getRoom(nil, aoi_scene)
	local gcid2teamid, teams = room.gcid2teamid, room.teams
	local scene_id = aoi_scene.scene_id
	local live_team_num = scene_id == TianmoConfig.boss_room_scene_id and TianmoService:getRoomTeamNumLive(room) or nil
	local dead_team_id
	
	local gcid = killer_obj.gcid
	for _, aoi_id in pairs(dead_aoi_ids) do
		local game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
		if game_obj.aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER then
			if scene_id ~= TianmoConfig.boss_room_scene_id then
				local team_id = gcid2teamid[game_obj.gcid]
				local team = teams[team_id]
				assert(team)
				local score = team.score
				score = score - 1
				team.score = score > 0 and score or 0
				
				-- 积分为0， 该队伍失败, 状态为通关
				if score <= 0 then
					local win_team_id = gcid2teamid[gcid]
					self:roomPass(aoi_scene, win_team_id)
					self:sendTeamsScores(aoi_scene, room, team_id)
					--self:sendRoomStatusUp(aoi_scene, room)
					return 
				end
				
				dead_team_id = team_id
			end
			
			-- BC
			if killer_obj.aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER then
				local msg_params = {killer_obj.nick, game_obj.nick}
--				NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.TIANMO_KILL_ENEMY, msg_params)
			end
		end
	end
	
	if dead_team_id then
		self:sendTeamsScores(aoi_scene, room, dead_team_id)
	end
end

function TianmoService:getRelivePos(character)
	local scene_id = character.scene_id
	-- 复活点复活
	if scene_id == TianmoConfig.boss_room_scene_id then
		local sceneaoi = SceneAoiService:getRandomTransferInForRelife(scene_id)
		local dst_x, dst_y = sceneaoi.x, sceneaoi.y
		return false, dst_x, dst_y
	else
		local aoi_scene = GameObjectService:getAoiScene(character)
		local team = TeamService:getTeamByCid(character.gcid)
		local is_first_team = aoi_scene.first_enter_teamid == team.id and true or false
		local tdot_into_id = TianmoConfig.lay2tdot_into_id[scene_id][is_first_team and 1 or 2]
		local scene_aoi = SceneAoiService:getInitObjsById(tdot_into_id)
		return false, scene_aoi.x, scene_aoi.y
	end
end

function TianmoService:getBirthPos(aoi_scene, character)
	local team = TeamService:getTeamByCid(character.gcid)
	assert(team, character.nick)
	local scene_id = aoi_scene.scene_id
	local scene_aoi
	
	if scene_id ~= TianmoConfig.boss_room_scene_id then
		local is_first_team = (aoi_scene.first_enter_teamid == 0 or aoi_scene.first_enter_teamid == team.id) and true or false
		local tdot_into_id = TianmoConfig.lay2tdot_into_id[scene_id][is_first_team and 1 or 2]
		scene_aoi = SceneAoiService:getInitObjsById(tdot_into_id)
		
		if not scene_aoi then
			Logger:error('TianmoService:getBirthPos error:', character.id, character.nick, scene_id, tdot_into_id)
			error('b2m_entryRoomAssign scene_aoi is empty')
		end
		
		if is_first_team then
			aoi_scene.first_enter_teamid = team.id
		end
		
		return true, scene_aoi.x, scene_aoi.y
	end
	
	return false
end

-- 检测是否可发起战斗
function TianmoService:checkFight(aoi_scene, attacker)
	if not TianmoService:isTianmo(aoi_scene.scene_id) then
		return
	end
	
	local group_id = self:getGroupIdByAoiScene(aoi_scene)
	
	if self:isEnd(nil, group_id) then
		return false, errorCodes.TIANMO_ALREADY_END
	end
	
	if aoi_scene.scene_id == TianmoConfig.boss_room_scene_id then
		return true
		
	else
		local tianmo_room = self:getRoom(nil, aoi_scene)
		local boss_room = self:getBossRoom(group_id)
		
		if tianmo_room.status == TianmoDefs.TIANMO_ROOM_STATUS_PASS then
			return false, errorCodes.TIANMO_PASS_CANNOT_PK
		elseif tianmo_room.status == TianmoDefs.TIANMO_ROOM_STATUS_LUNKONG then
			return false, errorCodes.TIANMO_PASS_CANNOT_PK
		elseif tianmo_room.status ~= TianmoDefs.TIANMO_ROOM_STATUS_FIGHTING then
			return false, errorCodes.TIANMO_MATCHED_CANNOT_PK
		elseif boss_room.status ~= TianmoDefs.TIANMO_BOSS_ROOM_STATUS_OPEN then
			return false, errorCodes.TIANMO_BROOM_FULL_CANNOT_PK
		end
	end
	
	return true
end

--- 设置阵营
function TianmoService:setZhenying(aoi_scene, character)
	local zhenying = 0
	
	-- 如是第七层，全部同阵营
	if self:isBossScene(aoi_scene.scene_id) then
		zhenying = Statics.DEFAULT_ZHENYING_PLAYER
	else
		local team = TeamService:getTeamByCid(character.gcid)
		zhenying = aoi_scene.first_enter_teamid == team.id and Utils.getZhenYingId(1) or Utils.getZhenYingId(2)
	end
	
	GameObjectService:updateZhenying(aoi_scene, character, zhenying)
end

function TianmoService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(character)
	if not TianmoService:isTianmo(aoi_scene.scene_id) then
		return
	end
	
	local cur_time = Time:getSecondsNow()
	local group_id, child_game_type_id = self:getGroupId(character)
	local boss_sceneaoi_id = TianmoConfig.child_game_id2boss_sceneaoi[child_game_type_id]
	local scene_aoi = SceneAoiService:getInitObjsById(boss_sceneaoi_id)
	assert(scene_aoi)
	
	for _, mid in pairs(arr_kill_monster_id) do
		if mid == scene_aoi.class_id then
			-- 记录击杀BOSS角色
			local boss_room_ins = self:getBossRoom(group_id)
			
			-- 注：这里由于之前未定义TIANMO_BOSS_ROOM_STATUS_PASS 导致报错，暂先改成用 TIANMO_BOSS_ROOM_STATUS_CLOSE
			--boss_room_ins.status = TianmoDefs.TIANMO_BOSS_ROOM_STATUS_PASS
			boss_room_ins.status = TianmoDefs.TIANMO_BOSS_ROOM_STATUS_CLOSE
			boss_room_ins.status_expire = cur_time + 3600
			
			boss_room_ins.kill_boss_gcid = character.gcid
			boss_room_ins.kill_boss_gpid = character.gpid
			boss_room_ins.kill_boss_nick = character.nick
			
			-- 更新排行榜
			self:_upToplist(aoi_scene, boss_room_ins, nil, true)
			
			--通关
			local tianmo_ins = self:getTianmoIns(group_id)
			local pack_data = {}
			pack_data.toplist = boss_room_ins.toplist
			pack_data.is_win = true
			pack_data.tianmo_ins_id = tianmo_ins.id
			pack_data.group_id = group_id
			pack_data.killer_gcid = boss_room_ins.kill_boss_gcid
			pack_data.killer_nick = boss_room_ins.kill_boss_nick
			ServerCall:m2bCall('TianmoCtrl.m2b_finish', character.gcid, pack_data)
			Logger:warn('[TianmoService:onKilledMonster] notice base finish', character.nick, pack_data)
			
			-- 广播
			--NoticeService:sysMsgBcMap(OKMsgCodes.TIANMO_BOSS_KILLED_BC, nicks, monster_base.nick)
			
			local team = TeamService:getTeamByCid(character.gcid)
			self:sendBossRoomMyInfo(aoi_scene, boss_room_ins, team, true)
			
			--BOSS房间，广播BOSS已死亡
--			FightHelperService:bcDead(character, arr_kill_monster_id)
		
			break
		end
		
	end
end

function TianmoService:onMonsterHarm(character, arr_monster_harm)
	if not self:isBossScene(character.scene_id) or not arr_monster_harm or not next(arr_monster_harm) then
		return
	end
	local group_id, child_game_type_id = self:getGroupId(character)
	local boss_room_ins = self:getBossRoom(group_id)
	local team = TeamService:getTeamByCid(character.gcid)
	local team_id = team.id
	local aoi_scene = GameObjectService:getAoiScene(character)
	local ts_opened_id = self:checkTianshenOpen(aoi_scene, boss_room_ins)
	local ts_cur_opened_info = boss_room_ins.ts_cur_opened_info
	local tianshen_need_harm = TianmoConfig.tianshen_bossid2need_harms[boss_room_ins.boss_sceneaoi_id]
	local boss_harm = 0
	
	for aoi_id, harm in pairs(arr_monster_harm) do
		if boss_room_ins.boss_aoi_id == aoi_id then
			local harm_list = boss_room_ins.harm_list
			local toplist = boss_room_ins.toplist
			local ch_own_harm = harm_list[team_id]
			ch_own_harm.harm = ch_own_harm.harm + harm
			boss_harm = harm
			
			if ts_opened_id and ts_opened_id > 0 then
				ch_own_harm.tianshen_harm_total = (ch_own_harm.tianshen_harm_total or 0) + harm
				
				-- 检查天神是否已达成条件
				if ch_own_harm.tianshen_harm_total >= tianshen_need_harm then
					TianmoService:finishTianshen(aoi_scene, team, ts_cur_opened_info)
				end
				
				-- RSP
				self:sendBossRoomMyTianShen(aoi_scene, boss_room_ins, team)
			end
		end
	end
	
	-- 更新排行榜
	self:_upToplist(aoi_scene, boss_room_ins)
	
	-- 通知自己信息更新
	local team = TeamService:getTeamByCid(character.gcid)
	self:sendBossRoomMyInfo(aoi_scene, boss_room_ins, team)
	
	-- BOSS额外附加伤害
	if boss_harm > 0 then
		local tianmo_ins = self:getTianmoIns(group_id)
		local now_minute = math_ceil((Time.time_second - tianmo_ins.open_time)/60)
		local conf_t = TianmoConfig.boss_harm_add_conf[now_minute]
		if conf_t then
			local add_harm = boss_harm * conf_t.harm_add_perc
			local boss_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, boss_room_ins.boss_aoi_id)
			-- 保底留10000血
			if boss_obj and boss_obj.hp > 10000 then
				-- 扣了add_harm之后，血不够10000，重置 add_harm
				if boss_obj.hp - add_harm < 10000 then add_harm = boss_obj.hp - 10000 end
				-- 扣BOSS血
				FightService:addObjectHp(boss_obj, -1*add_harm, 0, false, aoi_scene)
			end
		end
	end
end

-- 初始化世界BOSS入口场景
function TianmoService:onInitScene(character, aoi_scene)
	if aoi_scene.scene_id ~= TianmoConfig.boss_room_scene_id then
		return
	end
	
	local group_id, child_game_type_id = self:getGroupId(character)
	local boss_sceneaoi_id = TianmoConfig.child_game_id2boss_sceneaoi[child_game_type_id]
	local scene_aoi = SceneAoiService:getInitObjsById(boss_sceneaoi_id)
	assert(scene_aoi)
	
	local boss_room_ins = self:getBossRoom(group_id)
	
	local base_id = scene_aoi.class_id
	local monster_base = MonsterBaseService:getMonsterBaseById(base_id)
	if monster_base then
		local monster = MonsterService:createMonster(aoi_scene, base_id, scene_aoi)
		boss_room_ins.boss_aoi_id = monster.aoi_id
		boss_room_ins.boss_sceneaoi_id = boss_sceneaoi_id
	end
end

-- 响应队伍退队消息
function TianmoService:onTeamQuit(scene_ins_id, team_id, gcid, nick)
	local aoi_scene = GameObjectService:getAoiSceneBySpaceId(scene_ins_id)
	if not aoi_scene then return end
	
	local team = TeamService:getTeamById(team_id)
	
	-- BOSS房间
	local scene_id = aoi_scene.scene_id
	if scene_id == TianmoConfig.boss_room_scene_id or scene_id == TianmoConfig.pre_scene_id then
		return
	end
	
	local room = TianmoService:getRoom(nil, aoi_scene)
	local gcid2teamid, teams = room.gcid2teamid, room.teams
	
	-- 扣除积分
	local team_member_num = TeamService:getTeamMemberNum(team_id)
	if team_member_num == 0 then
		return
	end
	local now_score = self:_getTeamScoreDefault(team_member_num)
	
	local team = teams[team_id]
	if not team then
		return
	end
	
	local old_score = team.score
	
	if now_score >0 and old_score > now_score then
		team.score = now_score
		
		TianmoService:sendTeamsScores(aoi_scene, room, team_id)
		
		-- 广播给队员
		local ok_id = OKMsgCodes.TIANMO_LEAVE_SCORE_DEC
		local ok_params = {}
		ok_params[1] = nick
		ok_params[2] = team.score
		local arr_gpid = TeamService:getTeamGPids(TeamService:getTeamById(team_id))
		if #arr_gpid > 0 then
			WorldPacket:m2cSendCommOkMsg(ok_id, ok_params, arr_gpid)
		end
	end
end

-- 设置首支到达这层的队伍
function TianmoService:setFirstEnter(character, pack_data, lay)
	local bossroom_en_in_team_num = 0
	local is_boss_room = pack_data.scene_id == TianmoConfig.boss_room_scene_id
	
	local boss_room_ins = TianmoService:getBossRoom(pack_data.group_id)
	boss_room_ins.now_enter_max_lay = lay
	
	if is_boss_room then
		bossroom_en_in_team_num = TianmoDefs.TIANMO_BOSS_ROOM_TEAM_NUM_MAX - boss_room_ins.history_team_num
	end
	local msg_id = is_boss_room and OKMsgCodes.TIANMO_ENTRY_BOSSROOM or OKMsgCodes.TIANMO_FIRST_ENTRY_LAY
	local msg_params = is_boss_room and {pack_data.team_nicks, bossroom_en_in_team_num} or {pack_data.team_nicks, pack_data.lay}
	NoticeService:sysMsgScenePlayers(pack_data.gpids, msg_id, msg_params)

	self:sendFirstEnterBc(pack_data.gpids, lay)
end

function TianmoService:_createTianmoTeamInfo(team, lay)
	local team_tianmo = {}
	team_tianmo.id = team.id
	team_tianmo.team_id = team.id
	team_tianmo.score = self:_getTeamScoreDefault(TeamService:getTeamMemberNum(team.id))
	team_tianmo.order_by = 0
	team_tianmo.caption_nick = team.captain_nick
	team_tianmo.captain_gcid = team.captain_gcid
	team_tianmo.fc = team.total_fc
	team_tianmo.lay = lay
	return team_tianmo
end

function TianmoService:_getTeamScoreDefault(team_member_num)
	if team_member_num == 1 then
		return 2
	elseif team_member_num == 2 then
		return 5
	elseif team_member_num == 3 then
		return 10
	else
		return 0
	end
end

---------------------------- 排行榜相关 start ------------------------

-- 更新排行榜 (每3秒更新一次，未过期不更新)
function TianmoService._toplistCmp(a, b)
	if a.harm > b.harm then
		return true
	else
		return false
	end
end
function TianmoService:_upToplist(aoi_scene, boss_room_ins, notice_ch_obj, is_must_bc)
	local toplist = boss_room_ins.toplist
	
	tableSort(toplist, TianmoService._toplistCmp)
	
	local i = 1
	for rank, top in pairs(toplist) do
		top.rank = i
		i = i + 1
	end
	
	-- 广播通知
	local last_bc_time = boss_room_ins.last_bc_time or 0
	local cur_time = Time.time_second
	if is_must_bc or last_bc_time + TianmoDefs.HARM_TOPLIST_UP_TIME < cur_time then
		boss_room_ins.last_bc_time = cur_time
		self:sendToplist(boss_room_ins)
	
	-- 仅通知自己
	elseif notice_ch_obj then
		self:sendToplist(boss_room_ins, notice_ch_obj.gpid)
	end
end

-- 重新生成排行榜
function TianmoService:_genToplist(boss_room_ins)
	local harm_list = boss_room_ins.harm_list
	local toplist = table.values(harm_list)
	tableSort(toplist, TianmoService._toplistCmp)
	boss_room_ins.toplist = toplist
end

---------------------------- 排行榜相关 start ------------------------

-- 发送排行榜更新包给客户端
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_TOPLIST
	local msg_name = 'PackTianmo.PKM2C_TIANMO_TOPLIST'
	local msg_proto = {}
	function TianmoService:sendToplist(boss_room_ins, gpid)
		local toplist = boss_room_ins.toplist
		local aoi_scene = GameObjectService:getAoiSceneBySpaceId(boss_room_ins.scene_ins_id)
		msg_proto.arr_team = toplist
		local gpids = gpid or GameObjectService:getGPids(aoi_scene)
		if type(gpids) ~= 'table' or next(gpids) then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
		end
	end
end

-- 返回天魔场景相关信息
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_INFO_GET
	local msg_name = 'PackTianmo.PKM2C_TIANMO_INFO_GET'
	local msg_proto = {}
	function TianmoService:sendTianmoInfo(character)
		local team = TeamService:getTeamByCid(character.gcid)
		local room = self:getRoom(character)
		local is_boss_room = room.lay == TianmoDefs.TIANMO_LAY_TOTAL_NUM
		local boss_room = is_boss_room and room or self:getBossRoom(room.group_id)
		local team_id = team.id
		local harm_info = boss_room.harm_list[team_id]
		
		msg_proto.team_id = team_id
		msg_proto.cur_lay = room.lay
		msg_proto.status = not is_boss_room and room.status or 0
		msg_proto.status_expire = not is_boss_room and room.status_expire or 0
		msg_proto.boss_room_team_num = boss_room.history_team_num
		msg_proto.boss_room_status = boss_room.status
		msg_proto.boss_room_rank = harm_info and harm_info.rank or 99
		msg_proto.boss_room_harm = harm_info and harm_info.harm or 0
		
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

-- 更新天魔场景相关信息
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_INFO_UPDATE
	local msg_name = 'PackTianmo.PKM2C_TIANMO_INFO_UPDATE'
	local msg_proto = {}
	function TianmoService:sendTianmoInfoUpdate(aoi_scene, rsp_data, gpids)
		msg_proto = rsp_data
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids or GameObjectService:getGPids(aoi_scene))
	end
	
	-- 普通房间状态更新
	function TianmoService:sendRoomStatusUp(aoi_scene, tianmo_room)
		local rsp_data = {}
		rsp_data.status = tianmo_room.status
		rsp_data.status_expire = tianmo_room.status_expire
		self:sendTianmoInfoUpdate(aoi_scene, rsp_data)
	end

	-- BOSS房间状态更新
	function TianmoService:sendBossRoomStatusUp(aoi_scene, boss_room)
		local rsp_data = {}
		rsp_data.boss_room_status = boss_room.boss_room_status
		self:sendTianmoInfoUpdate(aoi_scene, rsp_data)
	end
	
	-- 更新我队伍在BOSS房间伤害和排名
	function TianmoService:sendBossRoomMyInfo(aoi_scene, boss_room, team, is_must_rsp)
		local rsp_data = {}
		local harm_info = boss_room.harm_list[team.id]
		
		if not is_must_rsp and (harm_info.last_rsp_mtime or 0) + 2000 > Time.time_now then
			return
		end
		
		harm_info.last_rsp_mtime = Time.time_now
		rsp_data.team_id = team.id
		rsp_data.boss_room_rank = harm_info and harm_info.rank or 99
		rsp_data.boss_room_harm = harm_info and harm_info.harm or 0
		self:sendTianmoInfoUpdate(aoi_scene, rsp_data, TeamService:getTeamGPids(team))
	end
	
	-- BOSS人数广播
	function TianmoService:bcBossRoomTeamNumUp(boss_room, gpids)
		local rsp_data = {}
		rsp_data.boss_room_team_num = boss_room.history_team_num
		self:sendTianmoInfoUpdate(nil, rsp_data, gpids)
	end
	
	-- 更新我队伍在BOSS房间天神伤害
	function TianmoService:sendBossRoomMyTianShen(aoi_scene, boss_room, team)
		local rsp_data = {}
		local harm_info = boss_room.harm_list[team.id]
		
		rsp_data.team_id = team.id
		rsp_data.tianshen_harm_total = harm_info and harm_info.tianshen_harm_total or 0
		self:sendTianmoInfoUpdate(aoi_scene, rsp_data, TeamService:getTeamGPids(team))
	end
end

-- 广播BOSS伤害加成
function TianmoService:bcBossHarmAddi(aoi_scene, group_id, boss_room_ins)
	local tianmo_ins = self:getTianmoIns(group_id)
	local now_minute = math_ceil((Time.time_second - tianmo_ins.open_time)/60)
	
	local boss_harm_add_bc_minutes = boss_room_ins.boss_harm_add_bc_minutes or {}
	boss_room_ins.boss_harm_add_bc_minutes = boss_harm_add_bc_minutes
	
	local boss_harm_add_conf = TianmoConfig.boss_harm_add_conf
	local conf_t = boss_harm_add_conf[now_minute]
	
	if conf_t and not boss_harm_add_bc_minutes[now_minute] and not conf_t.is_no_bc then
		local gpids = GameObjectService:getGPids(aoi_scene)
		if gpids and #gpids > 0 then
			WorldPacket:m2cSendCommOkMsg(OKMsgCodes.TIANMO_BOSS_HARM_ADD_BC, {conf_t.lev,conf_t.harm_add_perc*100}, gpids)
			boss_harm_add_bc_minutes[now_minute] = 1
		end
	end
end
	
-- 玩法已结束
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_END
	local msg_name = 'PackTianmo.PKM2C_TIANMO_END'
	local msg_proto = {}
	function TianmoService:sendTianmoEnd(aoi_scene, boss_room_ins)
		msg_proto.kill_boss_gcid = boss_room_ins.kill_boss_gcid or 0
		msg_proto.killer_nick = boss_room_ins.kill_boss_nick or nil
		local gpids = GameObjectService:getGPids(aoi_scene)
		if gpids and #gpids > 0 then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
		end
	end
end

-- 返回客户端积分列表
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_SCORES_UPDATE
	local msg_name = 'PackTianmo.PKM2C_TIANMO_SCORES_UPDATE'
	local msg_proto = {}
	function TianmoService:sendTeamsScores(aoi_scene, room, team_id, gpid)
		local teams = room.teams
		local team_scores
		
		if not team_id then
			team_scores = table.values(teams)
		else
			team_scores = {teams[team_id]}
		end
		
		msg_proto.team_scores = team_scores
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpid or GameObjectService:getGPids(aoi_scene))
	end
end

-- 广播队伍简要信息
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_TEAM_SIMPLE_INFO
	local msg_name = 'PackTianmo.PKM2C_TIANMO_TEAM_SIMPLE_INFO'
	local msg_proto = {}
	function TianmoService:sendTeamsSimpleInfo(character, room, team_id, gpid)
		local arr_team_simple = {}
		local tianmo_teams, disbanded_teams = room.teams, room.disbanded_teams
		
		if not team_id then
			for team_id, tianmo_team in pairs(tianmo_teams) do
				arr_team_simple[#arr_team_simple+1] = tianmo_team
			end
			if disbanded_teams then
				for team_id, tianmo_team in pairs(disbanded_teams) do
					arr_team_simple[#arr_team_simple+1] = tianmo_team
				end
			end
		else
			arr_team_simple[1] = tianmo_teams[team_id]
		end
		
		local aoi_scene = GameObjectService:getAoiScene(character)
		msg_proto.arr_team_simple = arr_team_simple
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpid or GameObjectService:getGPids(aoi_scene))
	end
end

--通关协议(1-6关通关协议,胜利、失败都会通知)
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_PASS_GATE
	local msg_name = 'PackTianmo.PKM2C_TIANMO_PASS_GATE'
	local msg_proto = {}
	
	function TianmoService:sendRoomPass(aoi_scene, room, gpid)
		msg_proto.win_team_id = room.win_team_id
		msg_proto.lay = room.lay
		msg_proto.go_lay_num = room.go_lay_num
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpid or GameObjectService:getGPids(aoi_scene))
	end
end

-- 天神下凡开始
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_TIANSHEN_START
	local msg_name = 'PackTianmo.PKM2C_TIANMO_TIANSHEN_START'
	local msg_proto = {}
	function TianmoService:sendTianshenStart(aoi_scene, ts_cur_opened_info, boss_room_ins, gpid)
		msg_proto.stime = ts_cur_opened_info.stime
		msg_proto.duration = TianmoConfig.tianshen_duration_sec * 1000
		msg_proto.harm_total = TianmoConfig.tianshen_bossid2need_harms[boss_room_ins.boss_sceneaoi_id]
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpid or GameObjectService:getGPids(aoi_scene))
	end
end

-- 天神下凡结束
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_TIANSHEN_FINISH
	local msg_name = 'PackTianmo.PKM2C_TIANMO_TIANSHEN_FINISH'
	local msg_proto = {}
	function TianmoService:sendTianshenFinish(aoi_scene, ts_cur_opened_info)
		msg_proto.win_team_id = ts_cur_opened_info.win_team_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, GameObjectService:getGPids(aoi_scene))
	end
end

-- 广播首只到达X层的队伍
do
	local rsp_opcode = opCodes.PKM2C_TIANMO_FIRST_ENTRY_BC
	local msg_name = 'PackTianmo.PKM2C_TIANMO_FIRST_ENTRY_BC'
	local msg_proto = {}
	function TianmoService:sendFirstEnterBc(gpids, lay)
		msg_proto.lay = lay
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
	end
end