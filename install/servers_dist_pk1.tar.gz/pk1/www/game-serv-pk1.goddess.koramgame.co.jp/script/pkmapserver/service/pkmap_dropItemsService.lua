--[[
掉落系统 service
author : xingzeng
date : 2015-05-06
]]--



local ItemDefs = ItemDefs
local math_random = math.random
local math_floor = math.floor
local Statics = Statics
local EquipDefs = EquipDefs
local next = next
local DropPackDefs = DropPackDefs
local array = array
local SublineConfig = SublineConfig

DropItemsService = DropItemsService or {}
local DropItemsService = DropItemsService

local EquipBaseService, GameObjectService, SceneService, OpeActivityService

function DropItemsService:onAfterLoadLua()
	SceneService = _G.SceneService
	GameObjectService = _G.GameObjectService
	EquipBaseService = _G.EquipBaseService
	OpeActivityService = _G.OpeActivityService
end

function DropItemsService:getMonsterDropEquips(monster_id)
	local monster_base = MonsterBaseService:getMonsterBaseById(monster_id)
	local drop_pack_ids = monster_base.drop_pack_ids
	local drop_equips = {}
	local ID_2_VALUE = OpenFuncDefs.ID_2_VALUE
	
	if drop_pack_ids then
		for _, drop_pack_id in pairs(drop_pack_ids) do
			local drop_pack = DropPackBaseDao[drop_pack_id]
			if not drop_pack then
				Logger:error('[DropItemsService:getMonsterDropEquips] The drop_pack is nil', monster_id, drop_pack_id, DropPackBaseDao)
			elseif not drop_pack.func_open_id or ID_2_VALUE[drop_pack.func_open_id] ~= 999 then
				local drop_equips_t = self:_calcDrop(drop_pack, monster_base)
				if drop_equips_t then
					for equip_id, equip_num in pairs(drop_equips_t) do
						drop_equips[equip_id] = (drop_equips[equip_id] or 0) + equip_num
					end
				end
			end
		end
	end
	
	return drop_equips
end

function DropItemsService:getDropEquips(drop_pack_ids, prof)
	local drop_equips = {}
	local ID_2_VALUE = OpenFuncDefs.ID_2_VALUE
	
	if drop_pack_ids then
		local PROF_ID_FOR_NONE = CharacterDefs.PROF_ID_FOR_NONE
		for _, drop_pack_id in pairs(drop_pack_ids) do
			local drop_pack = DropPackBaseDao[drop_pack_id]
			if not drop_pack then
				Logger:error('[DropItemsService:getDropEquips] The drop_pack is nil', drop_pack_id, DropPackBaseDao)
				error('[DropItemsService:getDropEquips] The drop_pack is nil.' .. drop_pack_id)
			end
			local prof_t = drop_pack.prof
			local is_open_pack = (not drop_pack.func_open_id or ID_2_VALUE[drop_pack.func_open_id] ~= 999) and true or false
			if is_open_pack and (prof_t == 0 or prof_t == PROF_ID_FOR_NONE or prof == prof_t) then
				local drop_equips_t = self:_calcDrop(drop_pack)
				if drop_equips_t then
					for equip_id, equip_num in pairs(drop_equips_t) do
						drop_equips[equip_id] = (drop_equips[equip_id] or 0) + equip_num
					end
				end
			end
		end
	end
	
	return drop_equips
end

function DropItemsService:_calcDrop(drop_pack, monster_base)
	local proba = drop_pack.pack_proba
	local equip_ids = drop_pack.equip_ids
	local equip_num_conf
	
	local drop_pack_id = drop_pack.id
	local guojia = Language:getGuojia()
	local emeng_ling_drop_confs, emeng_reward_confs = SublineConfig.emeng_ling_drop_confs, SublineConfig.emeng_reward_confs
	if emeng_ling_drop_confs[guojia][drop_pack_id] then 
		proba = emeng_ling_drop_confs[guojia][drop_pack_id]
	elseif emeng_reward_confs[guojia][drop_pack_id] then
		equip_num_conf = emeng_reward_confs[guojia][drop_pack_id]
	end
	
	local n = math_random(1, DropPackDefs.DROP_PACK_PROBA_RADIX)
	if n <= proba then
		local equip_ids, equip_probas, equip_nums = drop_pack.equip_ids, drop_pack.equip_probas, drop_pack.equip_nums
		local drop_silvers_data = drop_pack.silvers
		local drop_equips = {}
		local drop_silver = 0
		
		-- 掉落道具
		if equip_ids then
			local idx = math.randomIndex(equip_probas)
			local equip_id = assert(equip_ids[idx], idx)
			local equip_num = equip_num_conf or 1
			if not equip_num_conf and equip_nums then 
				equip_num = equip_nums[idx]
				if not equip_num then
					error('掉落包配置错误. ' .. drop_pack.id .. ',' .. idx)
				end
			end
			drop_equips = {[equip_id]=equip_num}
		end
		
		-- 随机掉落银两
		if drop_silvers_data then
			drop_silver = math_random(drop_silvers_data[1], drop_silvers_data[2])
		end
		
		-- 掉落经验(drop_pack.exp * character.level 才是玩家最终获得经验)
		if drop_pack.exp > 0 then
			local monster_level = monster_base and monster_base.level or 1
			drop_equips[EquipDefs.FUNCTION_EQUIP_ID_EXP] = drop_pack.exp * monster_level
		end
		
		-- 掉落银两
		if drop_silver > 0 then
			drop_equips[EquipDefs.FUNCTION_EQUIP_ID_SILVER] = drop_silver
		end
		
		return drop_equips
	end
end

--- 掉落场景BUFFER
-- @param baddscene=true
-- @return itemobj
function DropItemsService:dropSceneBuffer(aoi_scene, scene_buffer_base, x, y, life_expire, pickup_mode, own_gcids, drop_num)
	local itemobj = ItemObjService:createItemObj(aoi_scene, 
		ItemDefs.ITEM_SORT_ID_SCENE_BUFFER,
		ItemDefs.ITEM_FUNC_ID_SCENE_BUFFER,
		pickup_mode or ItemDefs.ITEM_PICKUP_MODE_FREE,
		own_gcids,
		life_expire or (Time:getTimeNow() + scene_buffer_base.life_mtime or ItemDefs.SCENE_BUFFER_LIVE_TIME),
		x,
		y,
		scene_buffer_base,
		drop_num)
	return itemobj
end

--- 掉落道具
-- @param baddscene=true
-- @return itemobj
function DropItemsService:dropEquip(aoi_scene, equip_base, x, y, life_expire, pickup_mode, own_gcids, drop_num, master_aoi_id)
	local itemobj = ItemObjService:createItemObj(aoi_scene, 
		ItemDefs.ITEM_SORT_ID_EQUIP,
		ItemDefs.ITEM_FUNC_ID_EQUIP,
		pickup_mode or ItemDefs.ITEM_PICKUP_MODE_FREE,
		own_gcids,
		life_expire or (Time:getTimeNow() + ItemDefs.DROP_PACK_LIFE_DURATION),
		x,
		y,
		equip_base,
		drop_num,
		master_aoi_id
		)
	return itemobj
end

--- 拾取物体
-- @return ok, err
function DropItemsService:pickup(character, itemobj)
	assert(character)
	
	-- 检查掉落物是否已经过期
	if itemobj.life_expire + 4000 < Time:getTimeNow() then
		return false, errorCodes.SCENE_DROP_ITEM_EXPIRE
	end
	
	-- 检查拾取方式
	if not self:canPickupMode(character, itemobj) then
		return false, errorCodes.SCENE_DROP_ITEM_NOT_OWN
	end
	
	-- 根据功能类型调用
	local func_id = itemobj.func_id
	local ok, err, err_params = true
	
	-- 道具掉落物
	if func_id == ItemDefs.ITEM_FUNC_ID_EQUIP then
		ok, err, err_params = DropItemsService:pickupEquip(character, itemobj)
	
	-- 场景BUFFER掉落物
	elseif func_id == ItemDefs.ITEM_FUNC_ID_SCENE_BUFFER then
		ok, err = SceneBufferService:pickup(character, itemobj)
		
	else
		ok, err = false, errorCodes.SCENE_DROP_ISNOT
	end
	
	return ok, err, err_params
end

--- 判断是否可拾取
function DropItemsService:canPickupMode(character, itemobj)
	local pickup_mode, own_gcids = itemobj.pickup_mode, itemobj.own_gcids
	
	-- 自由拾取
	if pickup_mode == ItemDefs.ITEM_PICKUP_MODE_FREE then
		return true
	end
	
	-- 拥有者拾取
	if pickup_mode == ItemDefs.ITEM_PICKUP_MODE_OWN then
		return array.contains( own_gcids, character.gcid )
	end
end

-- 拾取道具掉落物
function DropItemsService:pickupEquip(character, itemobj)
	assert( character and itemobj)
	assert( itemobj.func_id == ItemDefs.ITEM_SORT_ID_EQUIP )
	assert( itemobj.sort_id == ItemDefs.ITEM_FUNC_ID_EQUIP )
	
	-- 如果是巨岩魔宝箱，查看是否已经到达上限
	if OutdoorConfig:isBigBossBaoxiang( itemobj.item_base.id )  then 
		local equip_num = itemobj.item_num
		local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_RWD)
		if not en_count or en_count <= 0 then 
			return false, errorCodes.OUTDOOR_BIG_BOSS_BAOXIANG, {counter.now_storeup_count}
		end
		CounterService:addcount(character, counter, nil, en_count > equip_num and equip_num or en_count)
	end

	-- 发奖到游戏服
	local reward_equips = {equip_id = itemobj.item_base.id, equip_num = itemobj.item_num}
	RewardService:reward(Statics.PK_GAME_TYPE_ID_DROP_ITEM_PICKUP, 0, character.gpid, character.gcid, reward_equips)
	
	-- 删除掉落物
	local aoi_scene = GameObjectService:getAoiScene(character)
	GameObjectService:delObj(itemobj, aoi_scene)
	
	-- RSP
	local equip_base = EquipBaseService:getEquipBaseById(reward_equips.equip_id)
	if not equip_base then
		Logger:error('[DropItemsService:pickupEquip] equip_base is nil.', character.id, character.nick, reward_equips.equip_id)
	end
	WorldPacket:m2cSendCommOkMsg(OKMsgCodes.EQUIP_GET_NOTICE, {EquipDefs:getEquipFmtByEid( equip_base.id ), reward_equips.equip_num}, character.gpid)
	
	return true
end

-- 怪物掉落
function DropItemsService:monsterDrop(aoi_scene, monster, drop_equips, character)
	local getEquipBaseById = EquipBaseService.getEquipBaseById
	
	-- 掉落的是经验，则之家发放到玩家身上，不走掉落
	local get_exp_coeff = drop_equips[EquipDefs.FUNCTION_EQUIP_ID_EXP]
	if character and get_exp_coeff then
		drop_equips[EquipDefs.FUNCTION_EQUIP_ID_EXP] = nil
		
		-- 发奖到游戏服
		RewardService:onlineRewardBin(Statics.PK_GAME_TYPE_ID_DROP_ITEM_PICKUP, character.gpid, character.gcid, EquipDefs.FUNCTION_EQUIP_ID_EXP, get_exp_coeff)
		
	end
	
	if not next(drop_equips) then
		return
	end
	
	local dropitem_aoi_ids = {}
	
	local len = 0
	for equip_id, equip_num in pairs(drop_equips) do
		if equip_id == EquipDefs.FUNCTION_EQUIP_ID_EXP or equip_id == EquipDefs.FUNCTION_EQUIP_ID_SILVER then
			len = len + 1
		else
			len = len + equip_num
		end
	end
	
	local monster_base = monster.monster_base
	local drop_r = (monster_base.monster_sort_id == MonsterDefs.MONSTER_SORT_ID_FOR_BOSS and 8 or 2) + monster_base.model_times * monster_base.body_size
	local poss = DropItemsService:getDropPoss(aoi_scene, monster.x, monster.y, drop_r, len)
	local idx, x, y = 1
	local killer_gcid, monster_aoi_id = character.gcid, monster.aoi_id
	local drop_pickup_mode = monster_base.drop_pickup_mode or ItemDefs.ITEM_PICKUP_MODE_OWN
	if drop_pickup_mode ~= ItemDefs.ITEM_PICKUP_MODE_OWN then
		killer_gcid = nil
	end
	for equip_id, equip_num in pairs(drop_equips) do
		local for_maxi, num = equip_num, 1
		if equip_id == EquipDefs.FUNCTION_EQUIP_ID_EXP or equip_id == EquipDefs.FUNCTION_EQUIP_ID_SILVER then
			for_maxi = 1
			num = equip_num
		end
		for i = 1, for_maxi do
			x, y, idx = poss[idx], poss[idx+1], idx+2
			if x and y then
				local equip_base = getEquipBaseById(EquipBaseService, equip_id)
				local itemobj = DropItemsService:dropEquip(aoi_scene, equip_base, x, y, nil, drop_pickup_mode, killer_gcid, num, monster_aoi_id)
				dropitem_aoi_ids[#dropitem_aoi_ids+1] = itemobj.aoi_id
			end
		end
	end
	
	--self:bcDropItems(aoi_scene, monster, dropitem_aoi_ids)
end

function DropItemsService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(character)
	local scene_sort_id = aoi_scene.scene_base.scene_sort_id
	local SCENE_SORT_ID_OUTDOOR = SceneDefs.SCENE_SORT_ID_OUTDOOR
	local SCENE_SORT_ID_OUTDOOR_BOSS = SceneDefs.SCENE_SORT_ID_OUTDOOR_BOSS
	
	if arr_kill_monster_aoi_id then
		for _, aoi_id in pairs(arr_kill_monster_aoi_id) do
			local monster = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id, true)
			if monster then
				local monster_id = monster.monster_base.id
				local drop_equips = DropItemsService:getMonsterDropEquips(monster_id)
				
				-- 活动掉落奖励 (暂仅支持野外杀怪掉落)
				if scene_sort_id == SCENE_SORT_ID_OUTDOOR or scene_sort_id == SCENE_SORT_ID_OUTDOOR_BOSS then
					local opeact_rewards = OpeActivityService:getDropEquips(character.area_id, aoi_scene, monster_id)
					for equip_id, equip_num in pairs(opeact_rewards) do
						drop_equips[equip_id] = (drop_equips[equip_id] or 0) + equip_num
					end
				end
				
				if next(drop_equips) then
					DropItemsService:monsterDrop(aoi_scene, monster, drop_equips, character)
				end
			end
		end
	end
end

--- 获取 N 个掉落位置
-- @param x/y/r				起始坐标, 半径
-- @param num					个数
-- @return pos_arr=[x,y,x,y,...]/nil
local _drop_pos_map = {1,1,2,2,4,6,7,8,4,1}		-- 表示不同距离处掉落的概率
local _drop_pos_map_sum = math.sum(_drop_pos_map)
function DropItemsService:getDropPoss(aoi_scene, x, y, r, num, recv_buf)
	-- 获取范围内的所有可通行格子
	local all_grids, len_grids, num_grids
	if aoi_scene then
		all_grids, len_grids = aoi_scene:getPassablePoses(x, y, r)	-- c++ 接口
		if not all_grids then return end
		num_grids = len_grids / 2
		if num_grids < 1 then return end
		assert( num_grids == math_floor(num_grids) )
	end
	
	-- 在格子内, 随机 num 个坐标
	local ret = recv_buf or {}
	
	local r2 = (r * 1.5) ^ 2				-- 改为使用 外接圆
	local _drop_pos_map_len = #_drop_pos_map
	local n = 1
	local times = 0
	while n < num*2 do
		-- 检测死循环
		times = times + 1
		if times >= 1000 then break end

		-- 获得随机坐标 xx/yy, 精确到格子内部坐标
		local idx = math_random(num_grids)
		local idx2 = idx * 2 - 1
		local xx, yy = all_grids[idx2], all_grids[idx2+1]
		xx = xx + (math_random(256) - 1) / 256			-- [0,255] / 256 = [0, 1)
		yy = yy + (math_random(256) - 1) / 256
		-- 计算距离因子 dd = distance / r
		local dist2 = (x-xx)^2 + (y-yy)^2
		local dd = dist2 / r2
		if dd > 0 and dd < 1 then
			-- 根据 dd 计算该位置的概率 prob
			local idx = math_floor(dd * _drop_pos_map_len) + 1		-- idx = [1, #_drop_pos_map]
			local prob = _drop_pos_map[ idx ]
			-- 根据概率, 决定是否选择该位置
			local prob_sum = math_random( _drop_pos_map_sum )	-- [1, _drop_pos_map_sum]
			if prob <= prob_sum then
				ret[n], ret[n+1] = xx, yy
				n = n + 2
			end
		end
	end

	-- 如果获取失败, 则剩余位置填充为 (x, y)
	while n < num*2 do
		ret[n], ret[n+1] = x, y
		n = n + 2
	end
	
	return ret
end

-- 广播客户端 怪物掉落 客户端会播放掉落动画
do
	local rsp_opcode = opCodes.M2C_SCENE_DROP_ITEM_BC
	local msg_name = "PackDropItem.M2C_SCENE_DROP_ITEM_BC"
	local msg_proto = {}
	function DropItemsService:bcDropItems(aoi_scene, monster, dropitem_aoi_ids)
		msg_proto.aoi_id = monster.aoi_id
		msg_proto.dropitem_aoi_ids = dropitem_aoi_ids
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, GameObjectService:getFovGPids(monster, aoi_scene))
	end
end

