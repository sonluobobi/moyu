--[[
召唤物系统 SERVICE
author : shuyi.zhong
date : 2014-10-31
--]]

BeastService = BeastService or {}

local WorldPacket = WorldPacket
local Statics = Statics
local Time = Time
local random = math.random
local ceil = math.ceil
local table = table
local tableInsert = table.insert
local sizeTable = table.sizeTable
local ext_getNowUnixMsTime = external.getNowUnixMsTime
local DEFAULT_ZHENYING_BEAST = Statics.DEFAULT_ZHENYING_BEAST

local FightService
local GameObjectService
function BeastService:onAfterLoadLua()
	FightService = _G.FightService
	GameObjectService = _G.GameObjectService
end


do
	-- 召唤物每帧更新入口
	function BeastService:update(time_now, aoiScene, arr_beast)
		local is_del -- 是否删除
		for aoi_id, now_beast in pairs(arr_beast) do
			is_del = false
			if time_now < now_beast.expire_time then
				if not FightService:isDead(now_beast) then -- 不是死亡
					if not FightService:isSkillLocked(now_beast) then -- 不是被连击中
						-- 移动中(移动和攻击是可以同时存在的)
						if MotionService:isMoving(now_beast) then
							-- 移动更新
							MotionService:updateObject(aoiScene, now_beast)
						end

						-- 不能移动的召唤物还需要处理战斗状态
						if 0 == now_beast.speed then
							-- 检查当前场景是否可以攻击
							local keep_on, error_id = FightService:checkSceneEvent(aoiScene, now_beast)
							if keep_on then
								self:beastDoFight(time_now, aoiScene, now_beast)
							end
						end
					end
				else
					-- 死亡的，看看是否到时间要删除
					if now_beast.tmps.delete_time < time_now then
						is_del = true

						-- 蝙蝠的自爆等客户端处理
						if 0 == now_beast.speed then
							-- 自爆
							self:beastZiBao(aoiScene, now_beast)
						end
					end
				end
			else
				-- 已经过期，要删除掉
				is_del = true
			end

			if is_del then
				-- 删除掉召唤物
				self:delBeast(now_beast, aoiScene)

				print("召唤物存活时间到期，删除召唤物......", now_beast.nick)
			end
		end
	end
end


do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort
	local writeCoord = FastPacket.writeCoord	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	local math_floor = math.floor
	
	-- 写入基础外观
	function BeastService:writeObjAppear(beast, fast_packet)
		writeByte(fast_packet, math_floor((beast.speed or 0) * 10))
		writeLong(fast_packet, beast.hp)
		writeUInt(fast_packet, beast.beast_base.id)			-- base_id
		writeUInt(fast_packet, beast.parent_aoi_id or 0)	-- parent_aoi_id
	end
	
	-- 写入详细外观
	function BeastService:writeObjAppearDetail(beast, fast_packet)		
		writeLong(fast_packet, beast.max_hp)
	end
end


do
	-- 创建一个新的召唤物，并添加到场景实例中去，广播给客户端
	-- aoiScene : 场景实例id
	-- beast_id : 召唤物id
	-- x : 创建的x坐标
	-- y : 创建的y坐标
	-- fighter : 创建者(可以为nil)
	local AoiObject_new = AoiObject.new
	function BeastService:createBeast(aoiScene, beast_id, x, y, fighter, duration)
		local beast_base = assert(BeastBaseDao[beast_id], beast_id)

		local beast = self:newBeast(beast_base, fighter, duration)

		local aoi_obj = AoiObject_new(AoiObject, AoiObjectType.AOI_OBJECT_TYPE_ID_BEAST, x, y, 0, beast, aoiScene)
		GameObjectService:addObj(beast, aoi_obj, aoiScene)

		local del_beast_aoi_id = BeastService:addBeastToParent(beast, fighter)
		
		return beast, del_beast_aoi_id
	end


	-- new一个召唤物实体
	-- beast_base : 召唤物基本信息
	-- fighter : 放出召唤物的人
	-- duration : 存活时间
	function BeastService:newBeast(beast_base, fighter, duration)
		local beast = {}

		beast.nick = beast_base.title  -- 规范命名
		beast.level = fighter.level    -- 角色等级
		if 0 < beast_base.speed then
			beast.speed = fighter.speed -- 赋予召唤者的速度
		else
			beast.speed = 0
		end
		
		beast.expire_time = ext_getNowUnixMsTime() + duration -- 过期时间
		beast.parent_aoi_id = fighter.aoi_id -- 主人的AOI ID

		---------------- 战斗相关属性 start ------------------
		beast.hp			 = ceil(fighter.max_hp * beast_base.hp_radix)					-- 当前hp值
		beast.max_hp 		 = ceil(fighter.max_hp * beast_base.hp_radix)					-- 最大HP值
		
		beast.min_attack	= ceil(fighter.min_attack * beast_base.attack_radix)			-- 最小攻击
		beast.max_attack	= ceil(fighter.max_attack * beast_base.attack_radix)			-- 最大攻击

		beast.defence_phy	= ceil(fighter.defence_phy * beast_base.defence_phy_radix)		-- 物理防御
		beast.defence_magic = ceil(fighter.defence_magic * beast_base.defence_magic_radix)	-- 魔法防御
		
		beast.dodge			= ceil(fighter.dodge * beast_base.dodge_radix)					-- 闪避
		beast.critical_hit	= ceil(fighter.critical_hit * beast_base.critical_hit_radix)	-- 暴击
		beast.parry			= ceil(fighter.parry * beast_base.parry_radix)					-- 格挡

		beast.addi_harm_perc	= fighter.addi_harm_perc * beast_base.addi_harm_perc_radix		-- 加伤百分比
		beast.addi_harm			= ceil(fighter.addi_harm * beast_base.addi_harm_radix)			-- 加伤绝对值
		beast.reduce_harm_perc	= fighter.reduce_harm_perc * beast_base.reduce_harm_perc_radix	-- 减伤百分比
		beast.reduce_harm		= ceil(fighter.reduce_harm * beast_base.reduce_harm_radix)		-- 减伤绝对值

		beast.douzhi		= ceil(fighter.douzhi * beast_base.douzhi_radix)		-- 幸运
		beast.luck			= ceil(fighter.luck * beast_base.luck_radix)			-- 斗志
		beast.kill_force	= ceil(fighter.kill_force * beast_base.kill_force_radix)-- 斩杀力
		---------------- 战斗相关属性 end --------------------

		local my_zhenying = fighter and fighter.tmps.zhenying or DEFAULT_ZHENYING_BEAST -- 所在阵营
		beast.tmps = Beast:createTmps(my_zhenying) -- 创建tmps

		beast.beast_base = beast_base
		beast.model_times = beast_base.model_times or 1
		beast.body_size = beast_base.body_size or 0

		return beast
	end


	-- 把新召唤物与主人绑定在一起
	-- beast : 召唤物
	-- fighter : 放出召唤物的人
	-- return : del_old_beast_aoi_id 返回需要删除的旧的
	function BeastService:addBeastToParent(beast, fighter)
		local fighter_tmps_child_beast = fighter.tmps.child_beast
		local old_beast_aoi_id = 0
		if 0 < beast.speed then -- 移动类的召唤物
			old_beast_aoi_id = fighter_tmps_child_beast.move_aoi_id or 0
			fighter_tmps_child_beast.move_aoi_id = beast.aoi_id
		else -- 不可移动的召唤物
			old_beast_aoi_id = fighter_tmps_child_beast.not_move_aoi_id or 0
			fighter_tmps_child_beast.not_move_aoi_id = beast.aoi_id
		end

		return old_beast_aoi_id
	end


	-- 获取我的主人
	-- aoiScene : 场景实例
	-- beast : 召唤物
	-- return : parent / nil
	function BeastService:getMyParent(aoiScene, beast)
		return GameObjectService:getGameObjectByAoiId(aoiScene, beast.parent_aoi_id)
	end


	-- 获取一个人身上的召唤兽
	-- aoiScene : 场景实例
	-- character : 角色
	-- return : 会移动的召唤兽，不会移动的召唤兽
	function BeastService:getMyBeast(aoiScene, character)
		local move_beast, no_move_beast = nil, nil

		if FightService:isZhaoHuanShi(character) then
			local character_tmps_child_beast = character.tmps.child_beast
			local move_beast_aoi_id = character_tmps_child_beast.move_aoi_id or 0
			local no_move_beast_aoi_id = character_tmps_child_beast.not_move_aoi_id or 0

			if 0 < move_beast_aoi_id then
				move_beast = GameObjectService:getGameObjectByAoiId(aoiScene, move_beast_aoi_id)
			end

			if 0 < no_move_beast_aoi_id then
				no_move_beast = GameObjectService:getGameObjectByAoiId(aoiScene, no_move_beast_aoi_id)
			end
		end

		return move_beast, no_move_beast
	end


	-- 解除绑定(例如召唤时间到了，系统自动删除/或者被杀掉的时候调用)
	-- aoiScene : 场景实例
	-- beast : 召唤物
	function BeastService:delBeastFromParent(aoiScene, beast)
		local fighter = self:getMyParent(aoiScene, beast)

		if fighter then
			local fighter_tmps_child_beast = fighter.tmps.child_beast
			if 0 < beast.speed then -- 移动类的召唤物
				fighter_tmps_child_beast.move_aoi_id = 0
			else -- 不可移动的召唤物
				fighter_tmps_child_beast.not_move_aoi_id = 0
			end
		end

		return true
	end


	-- 删除掉召唤物
	-- beast : 召唤物
	-- aoiScene : 场景对象
	function BeastService:delBeast(beast, aoiScene)
		-- 先取消与召唤者的关联
		self:delBeastFromParent(aoiScene, beast)

		-- 从场景实例中删除
		GameObjectService:delObj(beast, aoiScene)
	end


	-- 删除掉角色的所有召唤物
	-- aoiScene : 场景实例
	-- fighter : 召唤者
	-- is_only_del_attack_beast : 是否只删除攻击类的召唤物(默认未false)
	local BeastDefs_SORT_ID_FOR_HELPER = BeastDefs.SORT_ID_FOR_HELPER
	function BeastService:delAllMyBeast(aoiScene, fighter, is_only_del_attack_beast)
		local fighter_tmps_child_beast = fighter.tmps.child_beast

		local move_aoi_id = fighter_tmps_child_beast.move_aoi_id or 0
		local not_move_aoi_id = fighter_tmps_child_beast.not_move_aoi_id or 0

		-- 会移动的召唤物(蝙蝠)
		if 0 < move_aoi_id then
			-- 删除掉
			GameObjectService:delObjByAoiId(aoiScene, move_aoi_id)
			
			-- 取消关联
			fighter_tmps_child_beast.move_aoi_id = 0
		end

		-- 不会移动的召唤物(邪龙，巫灵等)
		if 0 < not_move_aoi_id then
			local is_del_not_move_aoi_id = true -- 默认删除

			if is_only_del_attack_beast then
				local not_move_beast = GameObjectService:getGameObjectByAoiId(aoiScene, not_move_aoi_id)
				if not_move_beast then
					if BeastDefs_SORT_ID_FOR_HELPER == not_move_beast.beast_base.sort_id then
						is_del_not_move_aoi_id = false -- 辅助类的不删除
					end
				end
			end

			if is_del_not_move_aoi_id then
				-- 删除掉
				GameObjectService:delObjByAoiId(aoiScene, not_move_aoi_id)
				
				-- 取消关联
				fighter_tmps_child_beast.not_move_aoi_id = 0
			end
		end

		--[[
		if 0 < move_aoi_id or 0 < not_move_aoi_id then
			print("离开场景，删除召唤物......")
		end
		--]]
	end


	-- 获取我的召唤兽aoi_id列表
	-- character : 角色
	-- arr_filter_aoi_id : 要填充进去的数组
	function BeastService:setMyBeastAoiId(character, arr_filter_aoi_id)
		local character_tmps_child_beast = character.tmps.child_beast
		local move_aoi_id = character_tmps_child_beast.move_aoi_id or 0 -- 能移动的召唤兽(蝙蝠)
		local not_move_aoi_id = character_tmps_child_beast.not_move_aoi_id or 0 -- 不能移动的召唤兽(龙等...)
		if 0 < move_aoi_id then
			arr_filter_aoi_id[move_aoi_id] = true
		end
		if 0 < not_move_aoi_id then
			arr_filter_aoi_id[not_move_aoi_id] = true
		end
	end


	-- 获取召唤兽技能信息
	-- fighter : 召唤兽
	-- skill_id
	-- return skill / nil
	function BeastService:getDetailSkillInfoById(fighter, skill_id)
		local skill
		local beastBase = fighter.beast_base
		if beastBase then
			if (skill_id == beastBase.skill_id1) or (skill_id == beastBase.skill_id2) then -- 确实是召唤兽的技能
				-- 获取技能详细信息(国印提供接口)
				skill = SkillBaseService:getDetailSkillInfoById(skill_id)
			end
		end

		return skill
	end
end


------------------------------------------ 战斗攻击 --------------------------------------------------

do
	local BEAST_SORT_ID_FOR_ATTACK = BeastDefs.SORT_ID_FOR_ATTACK   -- 攻击类召唤物
	local BEAST_SORT_ID_FOR_HELPER = BeastDefs.SORT_ID_FOR_HELPER   -- 辅助类召唤物

	local EFFECT_SORT_ID_NORMAL = SkillDefs.EFFECT_SORT_ID_NORMAL	-- 攻击类技能
	local EFFECT_SORT_ID_RESTORE = SkillDefs.EFFECT_SORT_ID_RESTORE -- 回复类技能
	local EFFECT_SORT_ID_RELIVE = SkillDefs.EFFECT_SORT_ID_RELIVE	-- 复活类技能

	-- time_now : 当前时间
	-- aoiScene : 当前场景实例
	-- fighter : 召唤物
	function BeastService:beastDoFight(time_now, aoiScene, fighter)
		-- local
		local beastBase = fighter.beast_base
		local skill_id1 = beastBase.skill_id1 -- 召唤物技能1
		local skill_id2 = beastBase.skill_id2 or 0 -- 召唤物技能2
		local ahead_mssec = 100 -- 容错100毫秒
		local play_skill_id = 0 -- 本次要触发的技能
		local is_cd_ok = false  -- 是否检查过cd
		local parent -- 召唤物的主人

		local beast_sort_id = beastBase.sort_id -- 召唤物类型(加血/复活)
		if BEAST_SORT_ID_FOR_ATTACK == beast_sort_id then
			-- 攻击类召唤物
			play_skill_id = skill_id1 -- 普通攻击
			if 0 < skill_id2 then -- 有第2个技能
				if FightService:isSkillCdOk(fighter, skill_id2, ahead_mssec) then
					play_skill_id = skill_id2 -- 大招攻击
					is_cd_ok = true
				end
			end

		elseif BEAST_SORT_ID_FOR_HELPER == beast_sort_id then
			-- 辅助类召唤物(通过角色状态，来判断使用什么技能)
			parent = self:getMyParent(aoiScene, fighter)
			if parent and FightService:isLikeCharacter(parent) then
				if not FightService:isDead(parent) then
					play_skill_id = skill_id1 -- 第一个技能写死是回血技能
				else
					play_skill_id = skill_id2 -- 第二个技能写死是复活技能
				end
			end
		else
			error("未知召唤物类型，类型id : " .. beast_sort_id)
		end

		if 0 < play_skill_id then
			-- 检查CD是否OK
			if not is_cd_ok then
				if FightService:isSkillCdOk(fighter, play_skill_id, ahead_mssec) then
					is_cd_ok = true
				end
			end

			if is_cd_ok then
				-- 检查和父亲的距离(距离太远，自动删除)
				if not parent then
					parent = BeastService:getMyParent(aoiScene, fighter)
				end

				local distance_del = fighter.beast_base.distance_del or 0
				if 0 < distance_del then
					if not Formula:isNearbyDistance(fighter.x, fighter.y, parent.x, parent.y, distance_del) then
						-- 距离召唤人太远，需要删除
						self:delBeast(fighter, aoiScene)
						print("距离主人太远，删除掉召唤物。。。。。。。。")
						return
					end
				end
			end

			-- 到时间可以触发攻击了
			if is_cd_ok then
				local skill = FightService:getFighterSkill(fighter, play_skill_id)
				local skillBase = skill.skill_base
				local skill_effect_sort_id = skillBase.effect_sort_id -- 技能类型(攻击/回复/复活)
				local skill_distance = skillBase.distance
				local fighter_tmps = fighter.tmps

				-- 优先更新cd时间，免得后面出错更新不了造成死循环
				FightService:updateSkillCd(fighter, skillBase)

				-- 攻击类技能
				if EFFECT_SORT_ID_NORMAL == skill_effect_sort_id then
					local now_targeter_aoi_id = fighter_tmps.my_targeter_aoi_id or 0
					local targeter = FightService:findOneAttackTargeter(aoiScene, fighter, skill_distance, now_targeter_aoi_id)
					if targeter then -- 需要有可攻击的对象才能打
						FightService:doServerFight(aoiScene, fighter, play_skill_id, targeter)
					end

				elseif EFFECT_SORT_ID_RESTORE == skill_effect_sort_id then
				-- 回复血技能(只能回主人的，不回复其他的，包括队友等等)
					-- 先判断是否需要回血
					local hp_index, hp_key, max_hp_key = FightService:getHpInfo(parent)
					-- test
					-- parent.hp = ceil(parent_max_hp / 2)

					if parent[hp_key] < parent[max_hp_key] then
						local skill_distance = skillBase.area_radius or 0
						-- 距离判断
						if Formula:isNearbyDistance(fighter.x, fighter.y, parent.x, parent.y, skill_distance) then
							local is_bc = true
							local skill_restore_hp_percent = skill.skill_detail.extra_target_effect.add_hp_percent
							FightService:addObjectHp(parent, 0, skill_restore_hp_percent, is_bc, aoiScene)

							local ret_packet = FightService:buildNoAttackBinPacket(aoiScene, fighter, parent, skill)
							if ret_packet then
								WorldPacket:m2cSendPacket(ret_packet)
							end
						end
					end

				elseif EFFECT_SORT_ID_RELIVE == skill_effect_sort_id then
				-- 复活类技能
					if Formula:isNearbyDistance(fighter.x, fighter.y, parent.x, parent.y, skill_distance) then
						ReliveService:characterRelive(parent)

						local ret_packet = FightService:buildNoAttackBinPacket(aoiScene, fighter, parent, skill)
						if ret_packet then
							WorldPacket:m2cSendPacket(ret_packet)
						end
					end
				end
			end
			-- end cd ok
		end
	end


	-- 召唤物自爆
	function BeastService:beastZiBao(aoiScene, beast, parent)
		-- 获取自爆的参数
		local beastBase = beast.beast_base

		-- 蝙蝠默认就可以自爆，但蝙蝠的自爆改成用客户端触发，不采用服务端触发
		if 0 < beastBase.speed then
			return
		end

		-- 判断是否有天赋
		local parent = parent or self:getMyParent(aoiScene, beast)
		if parent then
			-- 是否需要自爆
			local is_need_zibao = false

			local tf_radius, tf_harm_num, tf_harm_radix, tf_bianfu_add_harm_radix = FightService:getPetTianFuZiBao(parent)
			-- print('自爆天赋的值', tf_radius, tf_harm_num, tf_harm_radix, tf_bianfu_add_harm_radix)
			if 0 < tf_radius then
				is_need_zibao = true

				-- 注意 : 上面的值都只用在出战幻兽上，召唤物读取的是自身的自爆参数里面的参数
			end

			if is_need_zibao then
				local arr_params = beastBase.zibao_params
				local radius = arr_params.radius			-- 半径
				local harm_radix = arr_params.harm_radix	-- 自爆系数
				local harm_num = arr_params.harm_num		-- 伤害人数
				-- print("自爆参数", radius, harm_radix, harm_num)

				-- 蝙蝠自爆伤害值 = (蝙蝠最大攻击 + 蝙蝠最小攻击) / 2 * 自爆系数
				local harm = ceil((beast.max_attack + beast.min_attack) / 2 * harm_radix * (1 + tf_bianfu_add_harm_radix))

				-- 执行自爆
				FightService:doZiBao(aoiScene, parent, beast, radius, harm_num, harm)
			end
		end
	end
end