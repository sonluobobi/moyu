--[[
军团战 service
author : guoyin.huang
date : 2016年04月05日
]]--

GangBattleNewService = GangBattleNewService or {}
local ext_createSpace = external.createSpace
local ext_setKeepInstanceSpace = external.setKeepInstanceSpace
local FIGHT_STATUS_PRE = GangBattleNewDefs.FIGHT_STATUS_PRE
local FIGHT_STATUS_WAR = GangBattleNewDefs.FIGHT_STATUS_WAR
local FIGHT_STATUS_FIN = GangBattleNewDefs.FIGHT_STATUS_FIN

local BATTLE_CAMP_UP = GangBattleNewDefs.BATTLE_CAMP_UP
local BATTLE_CAMP_LD = GangBattleNewDefs.BATTLE_CAMP_LD
local BATTLE_CAMP_RD = GangBattleNewDefs.BATTLE_CAMP_RD

setmetatable(GangBattleNewService, SceneServiceInterface)

local SceneService
local center_x
local center_y
local shengjian_area_r
local shengjian_drop_r
local roll_r_beg
local roll_r_end

function GangBattleNewService:onAfterLoadLua()
	SceneService = _G.SceneService

	center_x = GangBattleNewConfig.center_x
	center_y = GangBattleNewConfig.center_y
	shengjian_area_r = GangBattleNewConfig.shengjian_area_r
	roll_r_beg = GangBattleNewConfig.roll_r_beg
	roll_r_end = GangBattleNewConfig.roll_r_end	
	shengjian_drop_r = GangBattleNewConfig.shengjian_drop_r	
end


function GangBattleNewService:b2m_entryBattle(character, arr_params)
	local space_id = arr_params.space_id
	local line_id = nil
	SceneService:moveScene(character, GangBattleNewConfig.scene_id, space_id, line_id)	
end

-- BASE同步过来的场景对应的对阵信息
function GangBattleNewService:b2m_syncBattleInfo(_, arr_params)
	-- 清空表
	local vs_info = arr_params
	local space_id = arr_params.space_id
	GangBattleNewDao.sceneid_2_vsinfo[space_id] = vs_info
end

-- BASE同步过来的玩法时间
function GangBattleNewService:b2m_synBattleTime( _, arr_params )
	GangBattleNewDao.start_time = arr_params.start_time
	GangBattleNewDao.prepare_time = arr_params.prepare_time
	GangBattleNewDao.end_time = arr_params.end_time
end

--------------------------- 场景相关 [BEG] -------------------------------------
-- 场景初始化
function GangBattleNewService:onInitScene(character, aoi_scene)
	local gang_battle = {}
	aoi_scene.gang_battle = gang_battle

	local vs_info = assert(GangBattleNewDao.sceneid_2_vsinfo[aoi_scene.space_id])
	gang_battle.prepare_time = vs_info.prepare_time
	gang_battle.start_time = vs_info.start_time
	gang_battle.end_time = vs_info.end_time

	-- 对阵信息
	gang_battle.vs_info = vs_info

	-- 阵营到阵营信息
	gang_battle.camp_infos = {}
	gang_battle.gang_id_2_camp_info = {}
	
	-- gcid到角色数据信息
	gang_battle.gcid_2_info = {}

	-- gcid到离开的玩家数据
	gang_battle.gcid_2_leaved_info = {}

	-- 下次广播排名的时间
	gang_battle.next_broadcast_time = 0

	-- 怪物复活列表
	gang_battle.need_relive_monsters = {}

	--设置状态为准备阶段
	gang_battle.status = FIGHT_STATUS_PRE

	-- 场景积分总量
	gang_battle.scene_totle_score = 0

	-- 场景实时排名
	gang_battle.score_ranks = {}

	-- 圣剑与BUFFER刷出时间
	gang_battle.next_refresh_buffer_time = 0
	gang_battle.next_sj_create_time = gang_battle.start_time + GangBattleNewConfig.shenjian_dispear_time
	gang_battle.next_sj_dispeare_time = gang_battle.start_time + GangBattleNewConfig.shenjian_dispear_time + GangBattleNewConfig.shenjian_exist_time
	gang_battle.next_sj_score_time = 0

	gang_battle.sj_gcid = 0
	gang_battle.sj_player_nick = ''

	-- 阵营到
	gang_battle.enemy_small_map = {}

	local camp = 0
	for _, gang_info in pairs(vs_info.vs_gangs) do
		camp = camp + 1

		local camp_info = {}
		camp_info.gang_id = gang_info.gang_id
		camp_info.gang_title = gang_info.gt_short or gang_info.gang_title
		camp_info.area_id = gang_info.area_id
		camp_info.old_score = gang_info.score
		camp_info.unique_key = gang_info.unique_key
		camp_info.camp = camp
		camp_info.bind_score = 0	-- 军团绑定的积分
		camp_info.total_score = 0	-- 军团总积分
		local g_gang_id = gang_info.unique_key-- external.mergeUInt(camp_info.area_id, camp_info.gang_id)

		table.insert(gang_battle.camp_infos, camp_info)			-- 数组，用于发送
		gang_battle.gang_id_2_camp_info[g_gang_id] = camp_info  -- HASH，用于查找

		-- 场景积分总量		
--[[		local del_score = camp_info.old_score * GangBattleNewConfig.score_from_gang_radis
		camp_info.old_score = math.floor((camp_info.old_score - del_score) * GangBattleNewConfig.score_from_gang_radis)

		gang_battle.scene_totle_score = gang_battle.scene_totle_score + del_score
		gang_battle.scene_totle_score = gang_battle.scene_totle_score + GangBattleNewConfig.score_per_gang
]]--
	end
	gang_battle.scene_totle_score_const = GangBattleNewConfig.result_score_per_gang * #gang_battle.camp_infos
	-- 记录一个永远不变的总积分
--	gang_battle.scene_totle_score_const = gang_battle.scene_totle_score

	return true
end

function  GangBattleNewService:getZhengyinByCamp( camp )
	return camp
end

function GangBattleNewService:checkFight(aoi_scene, attacker)
	return self:isFighting(aoi_scene)
end

function GangBattleNewService:updateForNoPlayer( now_time_msec, aoi_scene )
	self:update500ms(now_time_msec, aoi_scene)
end

local monster_id_2_score = GangBattleNewConfig.monster_id_2_score
function GangBattleNewService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(character)
	if self:isFinish(aoi_scene) then 
		return 
	end		

	local gang_battle = aoi_scene.gang_battle

	local timer = {
		time=os.time() + GangBattleNewConfig.buffer_interval,
		monster_ids = {},
	}
	local monster_ids = timer.monster_ids
	local total_score = 0
	
	for _, monster_id in pairs(arr_kill_monster_id) do
		local add_score = monster_id_2_score[monster_id]

		if add_score then
			monster_ids[#monster_ids + 1] = monster_id
			total_score = total_score + add_score
		end
	end
	if total_score > 0 then 
		self:addBufferScore( character, total_score )
		table.insert(gang_battle.need_relive_monsters, timer)
	end
end

function GangBattleNewService:checkReliveMonster( aoi_scene )
	local gang_battle = aoi_scene.gang_battle
	local need_relive_monsters = gang_battle.need_relive_monsters
	local now_time = os.time()
	while #need_relive_monsters > 0 and need_relive_monsters[1].time <= now_time do
		for _, monster_id in pairs(need_relive_monsters[1].monster_ids) do
			local x, y = self:randomCircularPos( center_x, center_y, roll_r_beg, roll_r_end)
			MonsterService:dymCreateMonster(aoi_scene, monster_id, nil, x, y, 120)
		end
		table.remove(need_relive_monsters, 1)
	end
end

-- 场景更新
function GangBattleNewService:update500ms(now_time_msec, aoi_scene)
	local now_time = math.floor(now_time_msec/1000)
	local gang_battle = aoi_scene.gang_battle
	-- 状态变更
	if gang_battle.status == FIGHT_STATUS_PRE and now_time >= gang_battle.start_time then 
		gang_battle.status = FIGHT_STATUS_WAR
		
		-- 初始化积分
		self:initMemberScore(aoi_scene)

		-- 创建防御塔
		GangBattleNewService:createSaveMonster( aoi_scene )

		-- 初始化积分怪
		self:refreshScoreBuffer(aoi_scene)
	end

	if gang_battle.status == FIGHT_STATUS_WAR and now_time >= gang_battle.end_time then 
		self:finish(aoi_scene)
	end

	-- 战斗过程中的状态更新
	if self:isFighting(aoi_scene) then

		-- 圣剑创建
		if gang_battle.next_sj_create_time and gang_battle.next_sj_create_time <= now_time then 
			gang_battle.next_sj_create_time = now_time + GangBattleNewConfig.shenjian_dispear_time + GangBattleNewConfig.shenjian_exist_time
			gang_battle.next_sj_dispeare_time = now_time + GangBattleNewConfig.shenjian_exist_time
			self:createShengjian(aoi_scene)

			-- 圣剑出现广播
			NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.GANG_BATTLE_SJ_APPEAR, {})
		end

		-- 圣剑消失
		if gang_battle.next_sj_dispeare_time and gang_battle.next_sj_dispeare_time <= now_time then 
			gang_battle.next_sj_create_time = now_time + GangBattleNewConfig.shenjian_dispear_time
			gang_battle.next_sj_dispeare_time = now_time + GangBattleNewConfig.shenjian_dispear_time + GangBattleNewConfig.shenjian_exist_time
			self:removeShengjian(aoi_scene)
			-- 圣剑消失出现广播
			NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.GANG_BATTLE_SJ_DISAPPEAR, {[1] = GangBattleNewConfig.shenjian_dispear_time})			
		end

		-- 圣剑定期给持有者加积分
		if gang_battle.sj_gcid ~= 0 and gang_battle.next_sj_score_time <= now_time then 
			gang_battle.next_sj_score_time = now_time + GangBattleNewConfig.shendjian_add_scorer_interval
			self:addShengjianScore(aoi_scene)
		end

		-- 刷新场景积分BUFFER
		if gang_battle.next_refresh_buffer_time <= now_time then 
			gang_battle.next_refresh_buffer_time = now_time + GangBattleNewConfig.buffer_interval
			self:refreshFightBuffer( aoi_scene )

--			-- 战斗与积分BUFFER广播
--			NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.GANG_BATTLE_BUFFER, {})
		end

		
		if Time.is_second_start then 
			-- 检查结束
			self:checkFin(aoi_scene, now_time)

			-- 每秒检查怪物重生
			GangBattleNewService:checkReliveMonster( aoi_scene )
		end

-- 		-- 不检查掉落区域
--		-- 检查圣剑掉落
--		self:checkDropShengjian( aoi_scene )
	end
	
	-- 每一秒进行一次排序，每五秒同步一次
	if self:isFighting(aoi_scene) then 
		if Time.is_second_start then
			-- 排序
			self:sortChScore(aoi_scene)
			-- 回血
			self:checkAddSaveAreaHp( aoi_scene )		
		end

		-- 每5秒同步一次
		if gang_battle.status == FIGHT_STATUS_WAR and now_time >= gang_battle.next_broadcast_time then
			gang_battle.next_broadcast_time = now_time + 5
			
			-- 更新给玩家
			self:sendBattleInfoUpdate(aoi_scene)

			-- 同步所有玩家的排名
			for gcid, ch_info in pairs(gang_battle.gcid_2_info) do
				local character = CharacterService:getCharacterByGcid(gcid)
				if character then 
					-- 排名不一致才发送
					if ch_info.rank ~= ch_info.old_rank then
						self:sendChBattleInfo(character, aoi_scene)
					end
				end
			end
		end		

		-- 小地图
		if not gang_battle.small_map_update_time or now_time >= gang_battle.small_map_update_time then
			gang_battle.small_map_update_time = now_time + 3
			-- 更新小地图
			if gang_battle.sj_small_map_item then 
				if gang_battle.sj_gcid ~= 0 then 
					local character = CharacterService:getCharacterByGcid(gang_battle.sj_gcid)
					SmallMapService:updateItemPos(aoi_scene, gang_battle.sj_small_map_item, character.x, character.y)
				end
			end

			-- 更新敌方携带分数最高者小地图
			self:updateSmallMap(aoi_scene)
		end
	end
end

-- 创建守卫怪
do
	function GangBattleNewService:createSaveMonster( aoi_scene )
		local camp_2_save_monsters = GangBattleNewConfig.camp_2_save_monsters
		for camp, poses in pairs(camp_2_save_monsters) do
			for _, pos in pairs(poses) do
				local monster = assert(MonsterService:dymCreateMonster(aoi_scene, pos.monster_id,nil , pos.x, pos.y,pos.direction))
				GameObjectService:updateZhenying(aoi_scene, monster, camp, true)
			end
		end
	end
end

-- 检查是否提前结束
-- 检查是否提前结束
function GangBattleNewService:checkFin( aoi_scene, now_time )
	local gang_battle = aoi_scene.gang_battle

	local camp_infos = gang_battle.camp_infos	
	
	if gang_battle.status ~= FIGHT_STATUS_FIN then 
		-- 过了五分钟后，如果第一名积分为第二名的2倍以上，提交结束
		if now_time - gang_battle.start_time > 5 * 60 then 
			local total_score = 0
			for _, camp_info in ipairs(camp_infos) do
				total_score = total_score + camp_info.total_score
			end
			if total_score <= 0 then 
				return 
			end
			for _, camp_info in ipairs(camp_infos) do
				if camp_info.total_score / total_score >= 0.75 then 
					self:finish(aoi_scene)
				end
			end			
		end
	end
end


-- 开始的时候分配积分
function GangBattleNewService:initMemberScore(aoi_scene)
	local gang_battle = aoi_scene.gang_battle
	local gcid_2_info = gang_battle.gcid_2_info
	local g_gang_id_2_chs = {}
	for _, ch_info in pairs(gcid_2_info) do
		g_gang_id_2_chs[ch_info.g_gang_id] = g_gang_id_2_chs[ch_info.g_gang_id] or {}
		table.insert(g_gang_id_2_chs[ch_info.g_gang_id], ch_info)
	end

	-- 每个军团的总分一样，将总分平均分给每个成员
	for g_gang_id, ch_infos in pairs(g_gang_id_2_chs) do
		
		local gang_member_num = #ch_infos
		local score_2_members_when_start = GangBattleNewConfig.score_2_members_when_start
		local one_member_score = math.floor(score_2_members_when_start/gang_member_num)

		for i=1, gang_member_num do
			local ch_info = ch_infos[i]
			local character = CharacterService:getCharacterByGcid(ch_info.gcid)
			if i == 1 then 
				ch_info.stream_score = one_member_score + score_2_members_when_start - one_member_score*gang_member_num
				ch_info.total_score = ch_info.stream_score
				GangBattleNewService:onScoreChange( character, ch_info.stream_score )
			else
				ch_info.stream_score = one_member_score
				ch_info.total_score = ch_info.stream_score
				GangBattleNewService:onScoreChange( character, ch_info.stream_score )
			end
		end

		-- 增加阵营的总积分
		local camp_info = self:getCampInfoByGangid(g_gang_id, aoi_scene)
		camp_info.total_score = camp_info.total_score + score_2_members_when_start

		-- 将这部分积分从场景中删除
		self:addSceneScore(aoi_scene, -score_2_members_when_start)
	end

	local players = GameObjectService:getPlayerGameObjs(aoi_scene)
	for _, character in pairs(players) do
		self:sendChBattleInfo(character, aoi_scene)
	end
	self:sortChScore(aoi_scene)
	self:sendBattleInfoUpdate(aoi_scene)

	gang_battle.buffer_score_one_time = math.floor(gang_battle.scene_totle_score * 0.5 / (GangBattleNewConfig.war_time_long/GangBattleNewConfig.buffer_interval*10)) * 10
	gang_battle.buffer_30_num =math.floor((gang_battle.buffer_score_one_time - 100) / 50 ) + 1
	gang_battle.buffer_30_num = gang_battle.buffer_30_num < 0 and 0 or gang_battle.buffer_30_num
	gang_battle.buffer_20_num =math.floor((gang_battle.buffer_score_one_time - 100) / 50 ) + 1
	gang_battle.buffer_20_num = gang_battle.buffer_20_num < 0 and 0 or gang_battle.buffer_20_num
	gang_battle.buffer_10_num =math.floor((gang_battle.buffer_score_one_time - gang_battle.buffer_30_num * 30 - gang_battle.buffer_20_num * 20)/10)
	gang_battle.shengjian_score_one_time_b = GangBattleNewConfig.shenjian_add_score_2_gang
	gang_battle.shengjian_score_one_time_s = GangBattleNewConfig.shenjian_add_score_2_ch

	gang_battle.buffer_30_num = GangBattleNewConfig.monster_num_30 or gang_battle.buffer_30_num
	gang_battle.buffer_20_num = GangBattleNewConfig.monster_num_20 or gang_battle.buffer_20_num
	gang_battle.buffer_10_num = GangBattleNewConfig.monster_num_10 or gang_battle.buffer_10_num

	-- 更新对剑信息
	self:sendShenjianUpdate(aoi_scene)
end

-- 生成积分怪
function GangBattleNewService:refreshScoreBuffer( aoi_scene )
	local gang_battle = aoi_scene.gang_battle

	-- BUFFER ID
	local monster_id_10 = GangBattleNewConfig.monster_id_10
	local monster_id_20 = GangBattleNewConfig.monster_id_20
	local monster_id_30 = GangBattleNewConfig.monster_id_30

	for i=1, gang_battle.buffer_30_num do
		local x, y = self:randomCircularPos( center_x, center_y, roll_r_beg, roll_r_end)
		MonsterService:dymCreateMonster(aoi_scene, monster_id_10, nil, x, y, 120)
	end

	for i=1, gang_battle.buffer_20_num do
		local x, y = self:randomCircularPos( center_x, center_y, roll_r_beg, roll_r_end)
		MonsterService:dymCreateMonster(aoi_scene, monster_id_20, nil, x, y, 120)
	end

	for i=1, gang_battle.buffer_10_num do
		local x, y = self:randomCircularPos( center_x, center_y, roll_r_beg, roll_r_end)
		MonsterService:dymCreateMonster(aoi_scene, monster_id_30, nil, x, y, 120)
	end
end


-- 刷新点半buffer
function GangBattleNewService:refreshFightBuffer( aoi_scene )
	for i = 1, GangBattleNewConfig.fight_buffer_num do
		local buffer_id_pos = math.random(1, #GangBattleNewConfig.fight_buffer_list)
		local buffer_id = GangBattleNewConfig.fight_buffer_list[buffer_id_pos]
		local x, y = GangBattleNewService:randomCircularPos( center_x, center_y, roll_r_beg, roll_r_end)
		local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(buffer_id)
		local pos = {x, y}
		local pos_area = {pos, pos}	
		SceneBufferService:addSceneBufferDropItem(aoi_scene, scene_buffer_base, pos_area)		
	end
end

-- 以x,y为中心点，边长一半为size随机一个坐标点
function GangBattleNewService:randomCircularPos( x, y, size_in, size_out )
	local jiaodu = math.rad(math.random(1, 360))	-- 随机角度

	 -- 随机半径（取半径的平方，随机后再取平方根, 使得怪物不会集中在中心区域）
	local radius = (math.random(size_in * size_in, size_out * size_out))^(0.5)
	local x_pos = x + radius * math.cos(jiaodu)
	local y_pos = y + radius * math.sin(jiaodu)
	return x_pos, y_pos
end

-- 圣剑逻辑
do
	local x_pos = center_x	-- 圣剑BUFFER X坐标
	local y_pos = center_y	-- 圣剑BUFFER Y坐标
	function GangBattleNewService:createShengjian( aoi_scene, x, y )
		x = x or center_x
		y = y or center_y
		local pos = {x, y}
		local pos_area = {pos, pos}

		local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(GangBattleNewConfig.buffer_id_shengjian)
		local life_exp = aoi_scene.gang_battle.next_sj_dispeare_time * 1000
		local item = SceneBufferService:addSceneBufferDropItem(aoi_scene, scene_buffer_base, pos_area, life_exp)		
		local gang_battle = aoi_scene.gang_battle
		gang_battle.sj_item = item

		-- 圣剑小地图
		if not gang_battle.sj_small_map_item then
			gang_battle.sj_small_map_item = SmallMapService:addItem(aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_TOWE, x, y)
		else
			SmallMapService:updateItemPos(aoi_scene, gang_battle.sj_small_map_item, x, y)
		end
		self:sendShenjianUpdate(aoi_scene)
	end

	-- 捡起圣剑
	function GangBattleNewService:onPickupShengjian( character,  ch_scene_buffer)
		local aoi_scene = GameObjectService:getAoiScene(character)
		local gang_battle = aoi_scene.gang_battle
		if not gang_battle then return end
		-- 设置过期时间为圣剑对应的过期时间
		ch_scene_buffer.cd_expire = gang_battle.next_sj_dispeare_time * 1000
		gang_battle.sj_ch_buffer = ch_scene_buffer
		gang_battle.sj_pick_time = Time.time_now
		gang_battle.sj_gcid = character.gcid
		gang_battle.sj_player_nick = character.nick
		gang_battle.sj_item = nil

		-- 战斗中发送圣剑信息
		GangBattleNewService:sendShenjianUpdate(aoi_scene)
	end

	-- 从场景删除圣剑
	function GangBattleNewService:removeShengjian( aoi_scene )
		local gang_battle = aoi_scene.gang_battle
		local gang_battle = aoi_scene.gang_battle
		if gang_battle.sj_gcid ~= 0 then
			local character = assert(CharacterService:getCharacterByGcid(gang_battle.sj_gcid))
			if character then 
				GangBattleNewService:delChShengjianBuffer( character, aoi_scene )
			end
		
		else
			if gang_battle.sj_item.aoi_obj then
				GameObjectService:delObj(gang_battle.sj_item, aoi_scene)
			end
		end		
		gang_battle.sj_ch_buffer = nil
		gang_battle.sj_gcid = 0
		gang_battle.sj_player_nick = ''
		gang_battle.sj_item = nil
		if gang_battle.sj_small_map_item then 
			SmallMapService:delItem(aoi_scene, gang_battle.sj_small_map_item)
			gang_battle.sj_small_map_item = nil
		end

		-- 战斗中发送圣剑信息
		GangBattleNewService:sendShenjianUpdate(aoi_scene)
	end	

	-- 增加圣剑积分
	function GangBattleNewService:addShengjianScore( aoi_scene )
		local gang_battle = aoi_scene.gang_battle
		local character = CharacterService:getCharacterByGcid(gang_battle.sj_gcid)
		if character then 
			self:addChScore(character, gang_battle.shengjian_score_one_time_b, gang_battle.shengjian_score_one_time_s, aoi_scene)
			self:addSceneScore(aoi_scene, -gang_battle.shengjian_score_one_time_b - gang_battle.shengjian_score_one_time_s)
		end

		-- 战斗中发送圣剑信息
		GangBattleNewService:sendShenjianUpdate(aoi_scene)			
	end

	-- 将圣剑赋予某个玩家
	function GangBattleNewService:addShengjian2Player( character, aoi_scene )
		aoi_scene.gang_battle.sj_gcid = character.gcid
		aoi_scene.gang_battle.sj_player_nick = character.nick
		aoi_scene.gang_battle.sj_pick_time = Time.now_time
		local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(GangBattleNewConfig.buffer_id_shengjian)
		SceneBufferService:addSceneBuffer(character, scene_buffer_base, 1)
		SceneBufferService:useSceneBuffer(character, GangBattleNewConfig.buffer_id_shengjian, nil, 1)

		-- 战斗中发送圣剑信息
		GangBattleNewService:sendShenjianUpdate(aoi_scene)
	end

	--
	function GangBattleNewService:dropShengjian( character, aoi_scene )
		aoi_scene = aoi_scene or GameObjectService:getAoiScene(character)
		local gang_battle = aoi_scene.gang_battle
		if gang_battle.sj_gcid == character.gcid then

			GangBattleNewService:delChShengjianBuffer( character, aoi_scene )
			gang_battle.sj_gcid = 0
			gang_battle.sj_player_nick = ''
		end

		-- 战斗中发送圣剑信息
		GangBattleNewService:sendShenjianUpdate(aoi_scene)			
	end

	-- 删除圣剑 
	function GangBattleNewService:delChShengjianBuffer( character, aoi_scene )
		-- 删除角色身上的BUFFER
		local gang_battle = aoi_scene.gang_battle
		gang_battle.sj_ch_buffer.cd_expire = os.time() * 1000 - 1
		local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(GangBattleNewConfig.buffer_id_shengjian)
		local buffer_ids = scene_buffer_base.buffer_ids
		for _, buffer_id in pairs(buffer_ids) do
			BufferService:delBuffer(character, buffer_id, true)
		end
		MotionService:resumeSpeed( character )
		GameObjectService:appearDirty(character)

		-- 战斗中发送圣剑信息
		GangBattleNewService:sendShenjianUpdate(aoi_scene)			
	end

	-- 检查离开圣剑区域圣剑掉落
	function GangBattleNewService:checkDropShengjian( aoi_scene )
		local gang_battle = aoi_scene.gang_battle
		local sj_gcid = gang_battle.sj_gcid
		if sj_gcid and gang_battle.sj_pick_time and Time.time_now - gang_battle.sj_pick_time > 500 then 
			local character = CharacterService:getCharacterByGcid(sj_gcid)
			if character and (character.x - center_x) ^ 2 + (character.y - center_y) ^ 2 >= shengjian_drop_r ^ 2 then 

				self:dropShengjian( character, aoi_scene )
				local x = character.x
				local y = character.y
				while (x - center_x) ^ 2 + (y - center_y) ^ 2 > (shengjian_drop_r - 6) ^ 2 do
				 	x = x - (x - center_x) / 30
					y = y - (y - center_y) / 30
				end
				self:createShengjian(aoi_scene, x, y)
				
			end
		end
	end
end

-- 敌方前三小地图
function GangBattleNewService:updateSmallMap( aoi_scene )
	local gang_battle = aoi_scene.gang_battle
	local enemy_small_map = gang_battle.enemy_small_map 
	if not enemy_small_map then 
		enemy_small_map = {}
		gang_battle.enemy_small_map = enemy_small_map
	end

	-- 对所有的参与者进行排序
	local tmp = GangBattleNewService:sortChScore( aoi_scene )
	local camp_2_top3_enemy = {
	}
	for rank, ch_info in ipairs(tmp) do

	end

end

-- 按流动积分进行排序
function GangBattleNewService:sortChScore( aoi_scene )
	local gang_battle = aoi_scene.gang_battle
	local tmp = {}
	for _, ch_info in pairs(gang_battle.gcid_2_info) do
		tmp[#tmp + 1] = ch_info
	end
	table.sort(tmp, function ( l, r )
		return l.stream_score > r.stream_score
	end)
	for _, ch_info in pairs(tmp) do
		ch_info.old_rank = ch_info.rank
		ch_info.rank = _
	end	
	gang_battle.score_ranks = {}
	for index, ch_info in ipairs(tmp) do
		if index > 3 then break end
		gang_battle.score_ranks[index] = ch_info
	end

	return tmp
end

do
	-- 获取复活位置
	function GangBattleNewService:getRelivePos(character, aoi_scene)
		if GangBattleNewService:isFighting( aoi_scene ) then 
			local _, x, y = self:getBirthPos(aoi_scene, character)
			return false, x, y
		else
			return false, character.x, character.y
		end
	end

	-- 获取出生位置
	function GangBattleNewService:getBirthPos(aoi_scene, character )
		local camp_2_birth_dot = GangBattleNewConfig.camp_2_birth_dot
		local g_gang_id = self:getChGlobalGangId(character)
		local camp = self:getCampByGangId(g_gang_id, aoi_scene)
		local transfer_base_id = camp and camp_2_birth_dot[camp] or nil
		local x, y = SceneAoiService:getRandomTransferIn( GangBattleNewConfig.scene_id, transfer_base_id )
		return true, x, y
	end
end

function GangBattleNewService:getCampByGangId(g_gang_id, aoi_scene)
	local gang_battle = aoi_scene.gang_battle
	local camp_info = gang_battle.gang_id_2_camp_info[g_gang_id]
	return camp_info and camp_info.camp
end


-- 设置阵营
function GangBattleNewService:setZhenying(aoi_scene, character)
	if not self:isFinish(aoi_scene) then 
		-- 设置阵营,阵营ID统一获取接口
		local g_gang_id = self:getChGlobalGangId(character)
		local camp_info = assert(self:getCampInfoByGangid(g_gang_id, aoi_scene))
		local zhenying = self:getZhengyinByCamp(camp_info.camp)
		GameObjectService:updateZhenying(aoi_scene, character, zhenying)
	else
		GameObjectService:updateZhenying(aoi_scene, character, 1)
	end
end

-- 进入场景前
function GangBattleNewService:beforeEnterScene(character, aoi_scene, is_reconnect)

end

-- 进入场景
function GangBattleNewService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	if not self:isFinish(aoi_scene) then
		local gang_battle = aoi_scene.gang_battle
		if not is_reconnect then 
			if not gang_battle.gcid_2_leaved_info[character.gcid]  then 
				local ch_info = self:newChInfo(character, aoi_scene)
				self:addChBattleInfo(ch_info, aoi_scene)
			else
				local ch_info = gang_battle.gcid_2_leaved_info[character.gcid]
				self:addChBattleInfo(ch_info, aoi_scene)
				if ch_info.stream_score > 0 then 
					self:onScoreChange( character, ch_info.stream_score )
				end				
			end
		end
		-- 发送个人战斗信息
		self:sendChBattleInfo(character, aoi_scene)
		self:sendBattleInfo(character.gpid, aoi_scene)

		-- 战斗中发送圣剑信息
		if self:isFighting(aoi_scene) then 
			GangBattleNewService:sendShenjianUpdate(aoi_scene, character)
		end
	else	
		self:sendHasFinish(character)
	end
	
	-- 清空离开信息
	aoi_scene.gang_battle.gcid_2_leaved_info[character.gcid] = nil

	if character.horses.ch_horse then 
		ChHorseService:ride(character, false, true)
	end
end

-- 离开场景
-- 查看是否需要结束
function GangBattleNewService:afterLeaveScene(character, aoi_scene)
	if self:isFighting(aoi_scene) then 
		-- 将玩家从场景中删除
		local ch_info = self:getChBattleInfo(character, aoi_scene)
		
		local ch_stream_score = ch_info.stream_score
		-- 将流动积分从角色身上扣除,并添加到场景积分中
--		self:addChScore(character, 0, -ch_stream_score, aoi_scene)
--		self:addSceneScore(aoi_scene, ch_stream_score)
		
		-- 删除角色的数据
		self:eraseChBattleInfo(character, aoi_scene)

		aoi_scene.gang_battle.gcid_2_leaved_info[character.gcid] = ch_info
	else
		self:eraseChBattleInfo(character, aoi_scene)		
	end
	return true
end

function GangBattleNewService:beforeLeaveScene(character, aoi_scene)
	if self:isFighting(aoi_scene) then 
		-- 如果角色带着圣剑,掉落
		if aoi_scene.gang_battle.sj_gcid == character.gcid then 
			self:dropShengjian(character, aoi_scene)
			self:createShengjian(aoi_scene, character.x, character.y)
		end
	end
	return true
end

--------------------------- 场景相关 [END] -------------------------------------

function GangBattleNewService:newChInfo(character, aoi_scene)
	local o = {}
	o.gcid = character.gcid
	o.gang_id = character.gang_id
	o.gpid = character.gpid
	o.g_gang_id = self:getChGlobalGangId(character)
	o.camp = self:getCampInfoByGangid(o.g_gang_id, aoi_scene).camp
	o.total_score = 0	-- 总积分（包含贡献给军团的积分
	o.stream_score = 0	-- 流程积分（会被抢的积分）
	o.rank = #GameObjectService:getPlayerGameObjs(aoi_scene) + 1
	o.old_rank = o.rank
	o.cid = character.id
	o.pid = character.player_id
	o.nick = character.nick
	o.gang_title = character.gang_title
	o.prof = character.prof
	o.area_id = character.area_id
	o.del_score = 0
	o.kill_num = 0
	return o
end


-- 增加与删除场景积分
function GangBattleNewService:addSceneScore( aoi_scene, score )
	aoi_scene.gang_battle.scene_totle_score = aoi_scene.gang_battle.scene_totle_score + score
end

function GangBattleNewService:addBufferScore( character, score )
	local aoi_scene = GameObjectService:getAoiScene(character)
	if self:isFighting(aoi_scene) then
		self:addChScore(character, score * GangBattleNewConfig.score_radius_gang, score * GangBattleNewConfig.score_radius_ch, aoi_scene)
		self:addSceneScore(aoi_scene, -score)
	end
end

function GangBattleNewService:addChScore( character, bind_score, stream_score, aoi_scene)
	-- 绑定积分不能为负值
	assert(not bind_score or bind_score >= 0)

	local g_gang_id = self:getChGlobalGangId(character)
	local camp_info = self:getCampInfoByGangid(g_gang_id, aoi_scene)
	local ch_info = self:getChBattleInfo(character, aoi_scene)

	ch_info.stream_score = ch_info.stream_score + stream_score 
	ch_info.total_score = ch_info.total_score + bind_score + stream_score

	-- 绑定积分
	camp_info.bind_score = camp_info.bind_score + bind_score
	-- 总积分
	camp_info.total_score = camp_info.total_score + bind_score + stream_score

	-- 杀人积分特效
	if bind_score > 0 or stream_score > 0 then
		GameObjectService:addAoiInstantTexiao( aoi_scene, character, AoiTexiaoDefs.SORT_SCORE_ADD_PIAOZI, stream_score + bind_score )
	end

	-- 角色积分更新
	self:sendChBattleInfo(character, aoi_scene)

	-- 更新头顶文字
	if ch_info.stream_score > 0  then
		self:onScoreChange(character, ch_info.stream_score)
	end
end

do
	score_2_redname = {
		[1] = {score=1000, redname=RedNameDefs.RED_NAME_STATUS_SERIOUS},
		[2] = {score=500, redname=RedNameDefs.RED_NAME_STATUS_MIDDLE},
		[3] = {score=100, redname=RedNameDefs.RED_NAME_STATUS_LIGHT},
		[4] = {score=0, redname=RedNameDefs.RED_NAME_STATUS_NORMAL},
	}
	function GangBattleNewService:onScoreChange( character, stream_score )
		local redname = RedNameDefs.RED_NAME_STATUS_NORMAL
		for _, score_conf in ipairs(score_2_redname) do
			if stream_score >= score_conf.score then 
				redname = score_conf.redname
				break
			end
		end
		local aoi_obj = character.aoi_obj
		local wanfa_aoiobj_data = aoi_obj.wanfa_aoiobj_data
		if not wanfa_aoiobj_data['redname_status'] or wanfa_aoiobj_data['redname_status']  ~= redname then 
			WanfaAoiService:setWanfaAoiData(character, 'redname_status', redname, true)
		end
		WanfaAoiService:setWanfaAoiData(character, 'score', stream_score, true)
	end
end

do
	function GangBattleNewService:checkAddSaveAreaHp( aoi_scene )
		local auto_hp_2_center_radius = GangBattleNewConfig.auto_hp_2_center_radius
		local center_x = center_x
		local center_y = center_y
		local all_players = GameObjectService:getGameObjsByType(aoi_scene, AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER)
		if all_players then 
			for _, object in pairs(all_players) do
				-- 回复血量
				local zhengying = object.tmps.zhenying
				local center = GangBattleNewConfig.camp_2_auto_add_hp[zhengying]
				if (object.x - center.x)^2 + (object.y - center.y)^2 < center.radius^2 and 
				   (object.x - center_x)^2 + (object.y - center_y)^2 > auto_hp_2_center_radius^2 then 
					self:addHp(object)	
				end
			end
		end

		local all_pets = GameObjectService:getGameObjsByType(aoi_scene, AoiObjectType.AOI_OBJECT_TYPE_ID_PET)
		if all_pets then 
			for _, object in pairs(all_pets) do
				-- 回复血量
				local zhengying = object.tmps.zhenying
				local center = GangBattleNewConfig.camp_2_auto_add_hp[zhengying]
				if (object.x - center.x)^2 + (object.y - center.y)^2 < center.radius^2 and 
				   (object.x - center_x)^2 + (object.y - center_y)^2 > auto_hp_2_center_radius^2 then 
					self:addHp(object)	
				end
			end
		end
	end

	-- 获取当前有效的血条
	local ch_add_hp_list = {
		[1] = {max_key = 'max_hp',  hp_key='hp'},
		[2] = {max_key = 'max_hp2', hp_key='hp2'},
		[3] = {max_key = 'max_hp3', hp_key='hp3'}
	}
	local pet_add_hp_list = {
		[1] = {max_key = 'max_hp',  hp_key='hp'},
	}	
	function GangBattleNewService:addHp(object, aoi_scene)
		-- 死亡的不回血
		if FightService:isDead(object) then 
			return 
		end

		local add_hp_list = nil
		if FightService:isLikeCharacter(object) then
			add_hp_list = ch_add_hp_list
		else
			add_hp_list = pet_add_hp_list
		end
		local total_hp =object.max_hp + (object.max_hp2 or 0) + (object.max_hp3 or 0)
		
		local add_hp = math.floor(total_hp * 0.1)

		for _, info in ipairs(add_hp_list) do
			local max_key = info.max_key
			local hp_key = info.hp_key

			local max_hp = object[max_key]
			local hp = object[hp_key] 
			hp = hp > 0 and hp or 0

			if max_hp > hp then 
				if max_hp - hp >= add_hp then 
					-- 加满后不剩
					object[hp_key] = hp + add_hp
					add_hp = 0
				else
					-- 加满后有剩
					object[hp_key] = max_hp
					add_hp = add_hp - (max_hp - hp)
				end
				local index = FightService:getHpInfo(object)
				local arr_aoi_change_hp = {FightService:newObjChangeHp(object.aoi_id, index, max_hp - hp, object[hp_key])}
				FightService:sendObjsChangeHp(aoi_scene, object, arr_aoi_change_hp)
			end

			if add_hp <= 0 then 
				break 
			end
		end
	end
end


function GangBattleNewService:getChGlobalGangId( character )
	return character.gang_uk
end

-- 当玩家被杀
function GangBattleNewService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	if not self:isFighting( aoi_scene ) then 
		return 
	end	

	if not FightService:isLikeCharacter(fighter) then 
		local gang_battle = aoi_scene.gang_battle
		local sj_gcid = gang_battle.sj_gcid
		if not sj_gcid or sj_gcid == 0 then 
			return 
		end

		for _, killed_aoi_id in pairs(arr_kill_player_aoi_id) do
			local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, killed_aoi_id)

			-- 如果被杀者持有对剑，圣剑转移到杀人者身上
			if killed_player.gcid == sj_gcid then 
				self:dropShengjian(killed_player, aoi_scene)
				self:createShengjian(aoi_scene, killed_player.x, killed_player.y)
			end
		end
		return 
	end

	local gang_battle = aoi_scene.gang_battle
	local killer_info = self:getChBattleInfo(fighter, aoi_scene)

	local total_add_score = 0
	for _, killed_aoi_id in pairs(arr_kill_player_aoi_id) do

		-- 杀人数
		killer_info.kill_num = killer_info.kill_num + #arr_kill_player_aoi_id

		local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, killed_aoi_id)
		local ch_info = self:getChBattleInfo(killed_player, aoi_scene)
		local del_score = math.floor(ch_info.stream_score * GangBattleNewConfig.score_from_kill_radis)
		if del_score > 0 then
			-- 设置被杀减少的积分
			ch_info.del_score = del_score
			-- 被杀者减积分
			self:addChScore(killed_player, 0, -del_score, aoi_scene)
		else
			if ch_info.del_score > 0 then
				ch_info.del_score = 0
				GangBattleNewService:sendChBattleInfo(killed_player, aoi_scene)		
			end	
		end
		
		total_add_score = total_add_score + del_score + GangBattleNewConfig.score_from_kill_const

		-- 如果被杀者持有对剑，圣剑转移到杀人者身上
		if killed_player.gcid == gang_battle.sj_gcid then 
			self:dropShengjian(killed_player, aoi_scene)
			self:addShengjian2Player(fighter, aoi_scene)
		end
	end

	if total_add_score > 0 then
		-- 杀人者加积分
		self:addChScore(fighter, 0, total_add_score, aoi_scene)
	end
end

--比赛结束
function GangBattleNewService:finish( aoi_scene )
	local gang_battle = aoi_scene.gang_battle
	if gang_battle.status == FIGHT_STATUS_FIN then 
		return
	end

	local gang_battle = aoi_scene.gang_battle
	gang_battle.status = FIGHT_STATUS_FIN

	-- 计算获得的威望
	-- 计算总得分
	local total_score = 0
	for _, camp_info in pairs(gang_battle.camp_infos) do
		total_score = total_score + camp_info.total_score
	end

	local scene_totle_score_const = gang_battle.scene_totle_score_const
	if total_score > 0 then 
		for _, camp_info in pairs(gang_battle.camp_infos) do
			camp_info.weiwang = math.round(camp_info.total_score * scene_totle_score_const/total_score)
		end
	else
		for _, camp_info in pairs(gang_battle.camp_infos) do
			camp_info.weiwang = scene_totle_score_const / #gang_battle.camp_infos
		end		
	end

	-- 将剩余的积分分给各军团
--[[	if gang_battle.scene_totle_score > 0 then 
		local score_of_gang = gang_battle.scene_totle_score_const - gang_battle.scene_totle_score
		if score_of_gang > 0 then
			local scene_totle_score = gang_battle.scene_totle_score
			for _, camp_info in pairs(gang_battle.camp_infos) do
				local add_score = math.floor(scene_totle_score * camp_info.total_score /score_of_gang)
				camp_info.total_score = camp_info.total_score + add_score
				gang_battle.scene_totle_score = gang_battle.scene_totle_score - add_score
			end
			for _, camp_info in pairs(gang_battle.camp_infos) do
				camp_info.total_score = camp_info.total_score +  gang_battle.scene_totle_score
				gang_battle.scene_totle_score = 0
			end
		else
			local scene_totle_score = gang_battle.scene_totle_score
			local add_score = math.floor(scene_totle_score /#gang_battle.camp_infos)
			for _, camp_info in pairs(gang_battle.camp_infos) do
				camp_info.total_score = camp_info.total_score + add_score
				gang_battle.scene_totle_score = gang_battle.scene_totle_score - add_score
			end
			for _, camp_info in pairs(gang_battle.camp_infos) do
				camp_info.total_score = camp_info.total_score +  gang_battle.scene_totle_score
				gang_battle.scene_totle_score = 0
			end				
		end
	end
]]--
	-- 重新生成一次排名，以防止最终积分与左边的积分不一致
--	self:sortChScore(aoi_scene)
--	self:sendBattleInfoUpdate(aoi_scene)	

	-- 排名
	local ranked_camp_infos = {}
	for _, camp_info in pairs(gang_battle.camp_infos) do
		table.insert(ranked_camp_infos, camp_info)
	end

	table.sort(ranked_camp_infos, function ( l, r )
		return l.total_score > r.total_score
	end)

	-- 同步到base
	local m2b_data = {}
	m2b_data.camp_infos = {}
	for rank, camp_info in pairs(ranked_camp_infos) do
		camp_info.rank = rank

		m2b_data.camp_infos[rank] = {}
		local finish_camp_info = m2b_data.camp_infos[rank]
		finish_camp_info.gang_id = camp_info.gang_id
		finish_camp_info.area_id = camp_info.area_id
		finish_camp_info.add_score = camp_info.weiwang
		finish_camp_info.gang_title = camp_info.gang_title
		finish_camp_info.rank = camp_info.rank
		finish_camp_info.camp = camp_info.camp
		finish_camp_info.unique_key = camp_info.unique_key
	end

	-- 通知base，胜利的军团ID
	ServerCall:m2bCall('GangBattleNewService:m2b_finish', 0, m2b_data)

	-- 按积分排名
	local ch_infos = {}
	for _, ch_info in pairs(gang_battle.gcid_2_info) do
		table.insert(ch_infos, ch_info)
	end
	table.sort(ch_infos, function ( l, r )
		return l.total_score > r.total_score
	end)


	------------------------------------ 军团主力-----------------------------------	
	-- 军团前6
	local gangid_2_top6 = {}

	for rank, ch_info in ipairs(ch_infos) do 
		-- 设置角色排名
		ch_info.rank = rank 
		
		-- 保存贡献前6玩家的cid
		local gang_id = ch_info.gang_id
		local g_gang_id = ch_info.g_gang_id
		gangid_2_top6[g_gang_id] = gangid_2_top6[g_gang_id] or {area_id=ch_info.area_id,gang_id=gang_id, cids = {}}
		if #gangid_2_top6[g_gang_id].cids < 6 then 
			table.insert(gangid_2_top6[g_gang_id].cids, ch_info.cid)
		end
	end

	ServerCall:m2bCall('GangBattleNewService:m2b_sendTopMembers', 0, gangid_2_top6)


	------------------------------------ 结算，奖励-----------------------------------
	-- 结算界面用于展示个人排名
	gang_battle.final_score_ranks = {}
	for i=1, #ch_infos do
		if i > 10 then break end
		table.insert(gang_battle.final_score_ranks, ch_infos[i])
	end

	-- 用于发奖
	local arr_reward = {}
	local juesai_rank_2_rewards = GangBattleConfig.juesai_rank_2_rewards

	-- 用于到游戏服发奖
	local areaid_2_rankinfos = {}

	-- 用于发送到客户端
	local finish_data = {}
	finish_data.camp_infos = ranked_camp_infos
	finish_data.final_score_ranks = gang_battle.final_score_ranks
	for rank, ch_info in pairs(ch_infos) do
		local incomes = {}
		incomes.rank = rank
		local camp_info = gang_battle.camp_infos[ch_info.camp]
		local reward_equips = GangBattleNewConfig:getReward(ch_info.rank, camp_info.rank)
		local reward = RewardDefs:formatRewardParams(ch_info.cid, ch_info.player_id, incomes, reward_equips)
		arr_reward[#arr_reward + 1] = reward

		-- 发结算消息
		local equips = {}
		for equip_id , equip_num in pairs(reward_equips) do
			equips[#equips + 1] = {equip_id = equip_id, equip_num = equip_num}
		end
		finish_data.equips = equips
		finish_data.ch_info = ch_info
		local character = CharacterService:getCharacterByGcid(ch_info.gcid)
		if character then
			self:sendFinish(character, finish_data)
		end

		local ch_rank_info = {ch_info.cid,ch_info.player_id,ch_info.rank, camp_info.rank, camp_info.gang_id}
		areaid_2_rankinfos[ch_info.area_id] = areaid_2_rankinfos[ch_info.area_id] or {}
		table.insert(areaid_2_rankinfos[ch_info.area_id], ch_rank_info)
	end	

	for gcid, ch_info in pairs(aoi_scene.gang_battle.gcid_2_leaved_info) do
		ch_info.rank = 999
		local incomes = {}
		incomes.rank = 999
		local camp_info = gang_battle.camp_infos[ch_info.camp]
		local reward_equips = GangBattleNewConfig:getReward(ch_info.rank, camp_info.rank)
		local reward = RewardDefs:formatRewardParams(ch_info.cid, ch_info.player_id, incomes, reward_equips)
		arr_reward[#arr_reward + 1] = reward

		local ch_rank_info = {ch_info.cid,ch_info.player_id,ch_info.rank, camp_info.rank, camp_info.gang_id}
		areaid_2_rankinfos[ch_info.area_id] = areaid_2_rankinfos[ch_info.area_id] or {}
		table.insert(areaid_2_rankinfos[ch_info.area_id], ch_rank_info)
	end	

	for area_id, ch_rank_infos in pairs(areaid_2_rankinfos) do
		local send_gpid = external.mergeUInt(area_id, 0)
		RewardService:reward(Statics.PK_GAME_TYPE_ID_GANG_BATTLE, 0, send_gpid, 0, ch_rank_infos)
	end
end

------------------------------- 数据相关 【BEG】 -----------------------------------

-- 查看是否还在战斗中
function GangBattleNewService:isFighting( aoi_scene )
	local gang_battle = aoi_scene.gang_battle
	return gang_battle.status == FIGHT_STATUS_WAR
end

-- 查看是否已经结束
function GangBattleNewService:isFinish( aoi_scene)
	return aoi_scene.gang_battle.status == FIGHT_STATUS_FIN
end


-- 是否在帮战初赛中
function GangBattleNewService:isInGangBattle( scene_id )
	return scene_id == GangBattleNewConfig.scene_id
end

function GangBattleNewService:getChBattleInfo(character, aoi_scene)
	local gang_battle = aoi_scene.gang_battle
	return gang_battle.gcid_2_info[character.gcid]
end
function GangBattleNewService:addChBattleInfo(ch_info, aoi_scene)
	local gang_battle = aoi_scene.gang_battle
	gang_battle.gcid_2_info[ch_info.gcid] = ch_info
end

function GangBattleNewService:eraseChBattleInfo(character, aoi_scene)
	local gang_battle = aoi_scene.gang_battle
	gang_battle.gcid_2_info[character.gcid] = nil
end

-- 通过军团ID获取阵营数据
function GangBattleNewService:getCampInfoByGangid(g_gang_id, aoi_scene)
	return aoi_scene.gang_battle.gang_id_2_camp_info[g_gang_id]
end

function GangBattleNewService:getCampBattleInfo(camp, aoi_scene)
	local gang_battle = aoi_scene.gang_battle
	return gang_battle.camp_infos[camp]
end



------------------------------- 数据相关 【END】 -----------------------------------------
------------------------------------------------------------------------------------------
-------------------------------------- 发送消息[BEG] -------------------------------------


do  -- 发送个人战斗信息
	local rsp_opcode = opCodes.M2C_NEW_GANG_BATTLE_CH_INFO
	local msg_name = "PackGangBattleNew.M2C_NEW_GANG_BATTLE_CH_INFO"
	function GangBattleNewService:sendChBattleInfo(character, aoi_scene)
		local ch_info = GangBattleNewService:getChBattleInfo(character, aoi_scene)
		ch_info.old_rank = ch_info.rank
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, ch_info, nil, character.gpid)
	end
end

do  -- 发送完整战斗信息
	local rsp_opcode = opCodes.M2C_NEW_GANG_BATTLE_VS_INFO
	local msg_name = "PackGangBattleNew.M2C_NEW_GANG_BATTLE_VS_INFO"
	function GangBattleNewService:sendBattleInfo(gpids, aoi_scene)
		local gang_battle = aoi_scene.gang_battle
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, gang_battle, nil, gpids)
	end
end

do -- 发送战斗信息更新
	local rsp_opcode = opCodes.M2C_NEW_GANG_BATTLE_UPDATE
	local msg_name = "PackGangBattleNew.M2C_NEW_GANG_BATTLE_UPDATE"
	local data = {}
	function GangBattleNewService:sendBattleInfoUpdate(aoi_scene)

		local gpids = GameObjectService:getGPids(aoi_scene)
		if gpids and #gpids > 0 then 
			local gang_battle = aoi_scene.gang_battle
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, gang_battle, nil, gpids)
		end
	end	
end

do -- 发送战斗结果
	local rsp_opcode = opCodes.M2C_NEW_GANG_BATTLE_FINISH
	local msg_name = "PackGangBattleNew.M2C_NEW_GANG_BATTLE_FINISH"
	function GangBattleNewService:sendFinish(character, data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do -- 发送玩法已结束
	local rsp_opcode = opCodes.M2C_NEW_GANG_BATTLE_HAS_FIN
	local msg_name = "PackGangBattleNew.M2C_NEW_GANG_BATTLE_HAS_FIN"
	local data = {}
	function GangBattleNewService:sendHasFinish(character)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do -- 发送圣剑信息更新
	local rsp_opcode = opCodes.M2C_NEW_GANG_BATTLE_SHENJIAN
	local msg_name = "PackGangBattleNew.M2C_NEW_GANG_BATTLE_SHENJIAN"
	local data = {}
	function GangBattleNewService:sendShenjianUpdate(aoi_scene, character)
		local gang_battle = aoi_scene.gang_battle
		if character then 
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, gang_battle, nil, character.gpid)
		else
			local gpids = GameObjectService:getGPids(aoi_scene)
			if gpids and #gpids > 0 then 
				local gang_battle = aoi_scene.gang_battle
				WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, gang_battle, nil, gpids)
			end
		end
	end
end