--[[
BUFFER系统servuce
author : xingzeng.jiang
date : 2014-08-26
]]--

local external = external
local opCodes = opCodes
local table = table
local next = next
local pairs = pairs
local ipairs = ipairs
local math_abs = math.abs
local ext_getNowUnixMsTime = external.getNowUnixMsTime
local table = table
local BufferDefs = BufferDefs
local EffectType = EffectType
local Effectid2name = Effectid2name
local math_round = math.round
local BufferBaseDao = BufferBaseDao
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER

local obj_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local obj_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
local obj_type_pet = AoiObjectType.AOI_OBJECT_TYPE_ID_PET

function Buffer:new(game_obj, buffer_base, calced_effect_value, use_num)
	local buffer = {}
	local cur_time = ext_getNowUnixMsTime()
	local effect_id = buffer_base.effect_id
	
	buffer.aoi_id = game_obj.aoi_id
	buffer.id = buffer_base.id
	buffer.expire_time = cur_time + buffer_base.duration * (use_num or 1)
	buffer.add_time = cur_time
	buffer.effect_type = assert(Effectid2name[effect_id], effect_id)
	buffer.effect_id = effect_id
	buffer.buffer_base = buffer_base
	buffer.effect_value = calced_effect_value or buffer_base.effect_value
	buffer.effect_value2 = buffer_base.effect_value2
	return buffer
end

BufferService = BufferService or {}

local MotionService, GameObjectService, BufferBaseService

function BufferService:onAfterLoadLua()
	BufferBaseService = _G.BufferBaseService
	MotionService = _G.MotionService
	GameObjectService = _G.GameObjectService
end

-- 检查BUFFER是过期，如果过期则删除掉该BUFFER
function BufferService:_delExpireBuffers(bufobjs)
	local cur_time = ext_getNowUnixMsTime()
	for effect_type, buffer in pairs(bufobjs) do
		if buffer.expire_time < cur_time then
			bufobjs[effect_type] = nil
		end
	end
end

-- 获取剩余时间最短的buffer
function BufferService:_getBufferFirstExpire(bufobjs, is_debuffer)
	local buffer_firstexpire
	
	if bufobjs ~= nil then
		for _, buffer in pairs(bufobjs) do
			if buffer.buffer_base.is_debuffer == is_debuffer and (buffer_firstexpire == nil or 
				buffer.expire_time < buffer_firstexpire.expire_time) then
				buffer_firstexpire = buffer
			end
		end
	end
	
	return buffer_firstexpire
end

function BufferService:_getBufferCnt(bufobjs)
	local buffer_cnt = 0
	if bufobjs ~= nil then
		for _, buffer in pairs(bufobjs) do
			buffer_cnt = buffer_cnt + 1
		end
	end
	return buffer_cnt
end

do
	local pack_data = {}
	local timer_opcode = opCodes.T2M_BUFFER_EXPIRE
	
	-- 发送过期的事件给TIMER
	function BufferService:_addExpireTimer(scenegameobj, buffer, duration_msec, is_tmp_buffer)
		pack_data.opcode = timer_opcode
		pack_data.buffer_id = buffer.id
		pack_data.space_id = scenegameobj.space_id
		pack_data.aoi_id = scenegameobj.aoi_id
		pack_data.is_tmp_buffer = is_tmp_buffer
		pack_data.id = scenegameobj.id
		pack_data.aoi_type = scenegameobj.aoi_type
		pack_data.character_id = scenegameobj.character_id
		
		WorldPacket:addTimer(pack_data, duration_msec, 1)
	end
end

-- 通过BUFFER类型获取BUFFER
function BufferService:getBufferByType(game_obj, buffer_type)
	local buffers = game_obj.tmps.fight_buffers
	if buffers == nil then
		return false
	end
	
	local bufobjs = buffers.bufobjs
	if not bufobjs then return false end
	
	local buffer = bufobjs[buffer_type]
	return (buffer and buffer.expire_time >= Time.time_now) and buffer or nil
end

-- 获取怪物、侠客、角色的BUFFER对象列表 (包含BUFFER对象和临时性BUFFER对象)
-- scenegameobj	怪物、侠客、角色对象
-- return table:BUFFER列表
function BufferService:getBufobjs(scenegameobj)
	local bufobjs, bufobjs_tmp
	
	local buffers = scenegameobj.buffers
	if buffers ~= nil then
		bufobjs = buffers.bufobjs
	end
	
	local buffers_tmp = scenegameobj.tmps and scenegameobj.tmps.fight_buffers or nil
	if buffers_tmp ~= nil then
		bufobjs_tmp = buffers_tmp.bufobjs
	end
	
	return bufobjs, bufobjs_tmp
end

do
	local bufobjs_list = {}
			
	function BufferService:getBcBufObjs(game_obj)
		local buffers = game_obj.buffers
		local buffers_tmp = game_obj.tmps.fight_buffers
		bufobjs_list[1] = buffers and buffers.bufobjs or nil
		bufobjs_list[2] = buffers_tmp and buffers_tmp.bufobjs or nil
		local bufobjs_bc = {}
		
		for _, bufobjs in pairs(bufobjs_list) do
			for _, buffer in pairs(bufobjs) do
				if buffer.buffer_base.is_bc_other == 1 then
					bufobjs_bc[#bufobjs_bc+1] = buffer
				end
			end
		end
		
		return bufobjs_bc
	end
end

-- 获取临时BUFFER效果值(战斗相关属性)
-- return nil/table:baseeffectvalues ( eg: {attack_max=xx,defence=xx})
function BufferService:getEffectValues(scenegameobj)
	local buffers_tmp = scenegameobj.tmps and scenegameobj.tmps.fight_buffers or nil
	return buffers_tmp and buffers_tmp.bufobjs or nil
end

-- 获取BUFF给目标附加的最终伤害、伤害百分比
-- attacker	发起攻击者对象(Character,Monster,ChPet等对象)
-- targeter 受攻击者对象(Character,Monster,ChPet等对象)
-- return harm:int      目标的附加伤害绝对值
--		  harm_perc:int 目标的附加伤害百分比
function BufferService:getTargetAddiFinHarm(attacker, targeter)
	local buffers_attacker = attacker.tmps and attacker.tmps.fight_buffers or nil
	local buffers_targeter = targeter.tmps and targeter.tmps.fight_buffers or nil
	local bufobjs_attacker = buffers_attacker and buffers_attacker.bufobjs or nil
	local bufobjs_targeter = buffers_targeter and buffers_targeter.bufobjs or nil
	local addi_harm, addi_harm_perc = 0, 0
	local time_now = Time.time_now
	
	-- 对目标加伤
	if bufobjs_attacker then
		if bufobjs_attacker.harm_target then
			local buffer = bufobjs_attacker.harm_target
			if buffer.expire_time and buffer.expire_time >= time_now then
				addi_harm = addi_harm + buffer.effect_value
			end
		elseif bufobjs_attacker.harm_perc_target then
			local buffer = bufobjs_attacker.harm_perc_target
			if buffer.expire_time and buffer.expire_time >= time_now then
				addi_harm_perc = addi_harm_perc + buffer.effect_value
			end
		elseif bufobjs_attacker.harm_perc_target_super then
			local buffer = bufobjs_attacker.harm_perc_target_super
			if buffer.expire_time and buffer.expire_time >= time_now then
				addi_harm_perc = addi_harm_perc + buffer.effect_value
			end
		elseif bufobjs_attacker.rd_harm_perc_target then
			local buffer = bufobjs_attacker.rd_harm_perc_target
			if buffer.expire_time and buffer.expire_time >= time_now then
				addi_harm_perc = addi_harm_perc + buffer.effect_value
			end
		elseif bufobjs_attacker.ts_harm_perc_target then
			local buffer = bufobjs_attacker.ts_harm_perc_target
			if buffer.expire_time and buffer.expire_time >= time_now then
				addi_harm_perc = addi_harm_perc + buffer.effect_value
			end
		end
	end
	
	-- 受击者加伤
	if bufobjs_targeter then
		if bufobjs_targeter.harm then
			local buffer = bufobjs_targeter.harm
			if buffer.expire_time and buffer.expire_time >= time_now then
				addi_harm = addi_harm + buffer.effect_value
			end
		elseif bufobjs_targeter.harm_perc then
			local buffer = bufobjs_targeter.harm_perc
			if buffer.expire_time and buffer.expire_time >= time_now then
				addi_harm_perc = addi_harm_perc + buffer.effect_value
			end
		elseif bufobjs_targeter.rd_harm_perc then
			local buffer = bufobjs_targeter.rd_harm_perc
			if buffer.expire_time and buffer.expire_time >= time_now then
				addi_harm_perc = addi_harm_perc + buffer.effect_value
			end
		end
	end
	
	return addi_harm, addi_harm_perc
end

-- 判断是否存在帧触发临时BUFFER
-- 		注：如果一个类型同时存在多个特殊BUFFER，只会返回第一个（策划填表上也不会出现这种情况）
-- scenegameobj			侠客、角色对象
-- effect_type		BUFFER效果类型(定义见include/defs/EffectType.lua)
-- return boolean, nil/table:buffer
function BufferService:hasTmpBufferForFrame(scenegameobj, effect_type)
	local buffers_tmp = scenegameobj.tmps and scenegameobj.tmps.fight_buffers or nil
	local buffer = buffers_tmp and buffers_tmp[effect_type] or nil
	return (buffer and buffer.expire_time and buffer.expire_time >= Time.time_now) and true or false
end

-- 获取帧触发临时BUFFER列表
function BufferService:getTmpBufferForFrame(scenegameobj)
	local perframework_buffers = self:getHuancun(scenegameobj)
	if not perframework_buffers then return end
	return next(perframework_buffers) and perframework_buffers or nil
end

-- 判断是否在指定状态效果中
-- scenegameobj			侠客、角色对象
-- effect_id		效果ID
-- eg: BufferService:isInStatus(character, EffectType.confusion)
-- return boolean
function BufferService:isInStatus(scenegameobj, effect_id)
	local effect_type = assert(Effectid2name[effect_id], effect_id)
	local buffers = scenegameobj.tmps.fight_buffers
	if buffers == nil then
		return false
	end
	
	local bufobjs = buffers.bufobjs
	if not bufobjs then return false end
	
	local buffer = bufobjs[effect_type]
	return (buffer and buffer.expire_time >= Time.time_now) and true or false
end

-- 判断是否拥有指定技能效果
-- scenegameobj			侠客、角色、怪物对象
-- return boolean
function BufferService:isHasSkill(scenegameobj, skill_id)
	local buffers = scenegameobj.tmps.fight_buffers
	if buffers == nil then
		return false
	end
	
	local bufobjs = buffers.bufobjs
	if not bufobjs then return false end
	
	for effect_type, buffer in pairs(bufobjs) do
		local effect_value_ext = buffer.buffer_base.effect_value_ext
		if effect_value_ext and effect_value_ext.skill_id == skill_id and
			buffer.expire_time >= Time.time_now then
			return true
		end
	end
	
	return false
end

-- 判断是否在定身中
function BufferService:isInHalt(scenegameobj)
	local buffers = scenegameobj.tmps.fight_buffers
	if buffers == nil then
		return false
	end
	
	local bufobjs = buffers.bufobjs
	if not bufobjs then return false end
	
	local buffer = bufobjs['dingshen']
	return (buffer and buffer.expire_time >= Time.time_now) and true or false
end

-- 判断是否定身BUFF
function BufferService:isHaltBuff(buffer_base)
	return buffer_base.effect_id == EffectType.dingshen and buffer_base.effect_value <= -1
end

-- 判断BUFF是否已经过期
function BufferService:isExpire(buffer)
	return not buffer or not buffer.expire_time or buffer.expire_time < Time.time_now
end

-- 是否有增益BUFFER
function BufferService:isHasIncBuffer(game_obj)
	local buffers = game_obj.tmps.fight_buffers
	if buffers then
		local bufobjs = buffers.bufobjs
		for _, buffer in pairs(bufobjs) do
			local buffer_base = BufferBaseDao[buffer.id]
			if buffer_base.is_debuffer == 0 and buffer.expire_time >= Time.time_now then
				return true
			end
		end
	end
	
	return false
end

-- 获取道具BUFFER的加成数值 (临时BUFFER)
-- scenegameobj	怪物、角色对象
-- return table:effect_values (tmp table, 在“c_mainIndex”执行完成之后会release)
-- (注：目前道具	BUFFER 没有影响角色战斗属性的)
function BufferService:getHuancun(scenegameobj)
	local buffers_tmp = scenegameobj.tmps and scenegameobj.tmps.fight_buffers or nil
	
	if buffers_tmp == nil then
		return
	end
	
	if buffers_tmp._is_dirty then
		BufferService:_genHuancun(scenegameobj, buffers_tmp)
	end
	
	return buffers_tmp._perframework_buffers, buffers_tmp._baseeffectvalues, buffers_tmp._special_buffers
end

do
	local frame_trigger_buffer_effects = EffectTypeDefs.frame_trigger_buffer_effects
	local isSpecialEffect = EffectType.isSpecialEffect
	local isBaseEffect = EffectType.isBaseEffect
	
	-- 生成缓存
	function BufferService:_genHuancun(scenegameobj, buffers)
		if buffers == nil then
			return
		end
		
		local bufobjs = buffers.bufobjs
		
		-- 清理过期的缓存
		self:_delExpireBuffers(bufobjs)
		
		-------------- 生成 perframework_buffers 缓存 start -----------------
		local _perframework_buffers = buffers._perframework_buffers
		if _perframework_buffers == nil then
			_perframework_buffers = {}
			buffers._perframework_buffers = _perframework_buffers
		else
			table.clearTable(_perframework_buffers)
		end
		
		local aoi_scene
		for _, buffer in pairs(bufobjs) do
			local effect_id = buffer.effect_id
			if frame_trigger_buffer_effects[effect_id] then
				_perframework_buffers[effect_id] = buffer
				if not aoi_scene then aoi_scene = AoiSceneService:getAoiScene(scenegameobj.space_id) end
				aoi_scene.is_need_buffer_update = true
			end
		end
		-------------- 生成 perframework_buffers 缓存 end -----------------
		
		buffers._is_dirty = false
	end

	function BufferService:_clearHuancun(scenegameobj)
		local buffers_tmp = scenegameobj.tmps.fight_buffers
		
		if buffers_tmp == nil then
			return
		end
		
		buffers_tmp._is_dirty = true
	end
end

-- 设置BUFFER的效果值
function BufferService:setBufferEffectValue(game_obj, buffer_id, effect_value)
	local buffer_base = BufferBaseService:getBufferBaseById(buffer_id)
	local buffers = game_obj.tmps.fight_buffers
	if not buffers then
		return
	end
	local bufobjs = buffers.bufobjs
	local buffer = bufobjs[buffer_base.effect_type]
	if not BufferService:isExpire(buffer) then
		buffer.effect_value = effect_value
	end
end

do
	local frame_trigger_buffer_effects = EffectTypeDefs.frame_trigger_buffer_effects
	local BUFFER_TMP_OWN_SAME_TYPE_MAX_COUNT = BufferDefs.BUFFER_TMP_OWN_SAME_TYPE_MAX_COUNT
	
	-- 添加一个临时BUFFER到怪物、侠客、角色身上 
	--	(用于战斗技能BUFFER, 离线不持久化)
	-- game_obj			怪物、侠客、角色对象
	-- buffer_base			buffer基础对象 (里面的value等字段需要是计算过结果值)
	-- calced_effect_value	BUFFER 的效果值(外部计算好传入)(可以为空)
	-- use_num				使用BUFFER数量(缺省为1)
	-- return true/false   BUFFER是否添加成功
	--        is_need_bc   是否需要广播给客户端
	function BufferService:addTmpBuffer(game_obj, buffer_base, calced_effect_value, use_num, is_no_jia_expire)
		local buffers = game_obj.tmps.fight_buffers
		if buffers == nil then
			buffers = Buffers:new()
			game_obj.tmps.fight_buffers = buffers
		end
		Logger:debug('[BufferService:addTmpBuffer]', game_obj.id, game_obj.nick, game_obj.aoi_id, buffer_base.id, buffer_base.effect_type, buffer_base.effect_value, buffer_base.duration, calced_effect_value)
		
		if buffer_base.is_formula == 1 and not calced_effect_value then
			Logger:fatal('[BufferService:addTmpBuffer] calced_effect_value不能为空', game_obj.aoi_id, buffer_base.id, calced_effect_value)
		end
		
		local aoi_type = game_obj.aoi_type
		local effect_id = buffer_base.effect_id
		local effect_type = assert(Effectid2name[effect_id], effect_id)
		local bufobjs = buffers.bufobjs
		local buffer = bufobjs[effect_type]
		local cur_time = ext_getNowUnixMsTime()
		local buffer_base_old = buffer and buffer.buffer_base or nil
		-- 对减速BUFFER的处特殊理  
		-- 定身中 、减速会无效
		if effect_type == 'speed_perc' and not self:isHaltBuff(buffer_base) then
			-- 检查是否存在 定身中
			if self:isInHalt(game_obj) then
				return false
			end
		end
		
		-- 未找到同ID的BUFFER
		if buffer == nil then
			local buf_count = BufferService:_getBufferCnt(bufobjs)
			local is_beyond = buf_count >= BUFFER_TMP_OWN_SAME_TYPE_MAX_COUNT and true or false
			local buffer_firstadd
			if is_beyond then
				buffer_firstadd = self:_getBufferFirstExpire(bufobjs, buffer_base.is_debuffer)
				if not buffer_firstadd then
					is_beyond = false
				end
			end
			
			-- 替换最早过期的那个Buffer
			if is_beyond then
				bufobjs[buffer_firstadd.effect_type] = nil
			end
			
			-- 添加BUFFER
			bufobjs[effect_type] = Buffer:new(game_obj, buffer_base, calced_effect_value, use_num)
		
		-- 同ID时间累加
		elseif not is_no_jia_expire and buffer.id == buffer_base.id and not calced_effect_value and buffer.expire_time > cur_time then
			buffer.expire_time = buffer_base.duration + buffer.expire_time
			
		-- 同类型的BUFFER，直接替换
		-- 条件：这个BUFF的等级比原BUFF等级高，或原BUFF已过期
		elseif buffer_base_old and (buffer_base_old.level <= buffer_base.level or buffer.expire_time <= cur_time) then
			bufobjs[effect_type] = Buffer:new(game_obj, buffer_base, calced_effect_value, use_num)
		
		else
			return false
		end
		
		buffer = bufobjs[effect_type]
		local duration = buffer.expire_time - cur_time
		self:_addExpireTimer(game_obj, buffer, duration, true)
		-- 定身
		if effect_type == 'dingshen' then
			MotionService:changeSpeed(game_obj, 0, Time.time_now + buffer_base.duration)
			
		-- 对加速BUFFER的处理
		elseif effect_type == 'speed_perc' then
			MotionService:addSpeedByPercForBase(game_obj, buffer.effect_value, buffer_base.duration)
			
		elseif effect_type == 'speed' then
			-- 修改速度
			local speed_t = buffer.effect_value + game_obj.speed
			MotionService:changeSpeed(game_obj, speed_t, Time.time_now + buffer_base.duration)
		
		-- 眩晕
		elseif effect_type == 'giddiness' then
			MotionService:stop(game_obj, true)
			FightService:cancleFightState(game_obj)
			-- 暂停怪物AI
			if aoi_type == obj_type_monster then
				game_obj.tmps.is_pause = true
				game_obj.tmps.pause_expire = buffer.expire_time
			end
		-- 感染病毒
		elseif effect_type == 'virus_ganran' then 
			-- 只在生存挑战中有效
			if ShengcunService:isInShengcun( game_obj.scene_id ) then
				local aoi_scene = AoiSceneService:getAoiScene(game_obj.space_id)
				ShengcunService:onVirusBufferAdd( aoi_scene, game_obj )
			end
		-- 病毒抑制
		elseif effect_type == 'virus_yizhi' then
			-- 只在生存挑战中有效
			if ShengcunService:isInShengcun( game_obj.scene_id ) then
				local aoi_scene = AoiSceneService:getAoiScene(game_obj.space_id)
				ShengcunService:onUseYizhiBuffer( aoi_scene, game_obj )
			end	
		end
		
		BufferService:_clearHuancun(game_obj)
		
		if frame_trigger_buffer_effects[effect_id] then
			local aoi_scene = AoiSceneService:getAoiScene(game_obj.space_id)
			aoi_scene.is_need_buffer_update = true
		end
		
		-- 更新appear bin 数据的版本
		if buffer.buffer_base.is_bc_other == 1 then
			GameObjectService:appearDirty(game_obj)
		end
		
		return true, buffer.buffer_base.is_bc_other
	end
end

function BufferService:delBuffer(game_obj, buffer_id, is_send)
	local buffers = game_obj.tmps.fight_buffers
	if buffers == nil then
		return false
	end
	
	local bufobjs = buffers.bufobjs
	if not bufobjs then return false end
	
	local buffer_base = BufferBaseDao[buffer_id]
	local buffer = bufobjs[buffer_base.effect_type]
	
	if not buffer or buffer.buffer_base.id ~= buffer_id then return false end
	
	bufobjs[buffer_base.effect_type] = nil
	
	self:_clearHuancun(game_obj)
	
	if is_send then
		self:sendDelBuffers(nil, game_obj, {buffer_id})
	end
	
	return true
end


-- 使用瞬间BUFFER
function BufferService:useInstantBuffer(scenegameobj, buffer_base, targeter_aoi_id)
	if not BufferBaseService:isInstantBuffer(nil, buffer_base) then
		return
	end
	
	--瞬间BUFFER， 进支持玩家使用
	if scenegameobj.aoi_type ~= obj_type_player then
		return
	end
	
	local character = scenegameobj
	local effect_id = buffer_base.effect_id
	local bc_update_data = {}
	local is_need_bc = false
	local aoi_scene = GameObjectService:getAoiScene(scenegameobj)
	if not aoi_scene then
		return
	end
	
	-- 加/扣血量百分比
	if effect_id == EffectType.max_hp_perc then
		local hp_index, hp_key, max_hp_key = FightService:getHpInfo(scenegameobj)
		local now_hp, max_hp = scenegameobj[hp_key], scenegameobj[max_hp_key]
		if now_hp > 0 then
			local effect_value = buffer_base.effect_value
			if effect_value < 0 or now_hp < max_hp then
				FightService:addObjectHp(scenegameobj, 0, effect_value, true, aoi_scene)
			end
		end
		
	-- 触发一个陷阱
	elseif effect_id == EffectType.trap_add then
		--
		
	-- 回复所有层的血
	elseif effect_id == EffectType.restore_hp_full_all_cen then
		if scenegameobj.hp > 0 then
			scenegameobj.hp = scenegameobj.max_hp
			
			-- 如果有合体幻兽
			local character_max_hp2 = scenegameobj.max_hp2 -- 内层幻兽
			if 0 < character_max_hp2 then
				scenegameobj.hp2 = character_max_hp2
			end
			local character_max_hp3 = scenegameobj.max_hp3 -- 外层幻兽
			if 0 < character_max_hp3 then
				scenegameobj.hp3 = character_max_hp3
			end
			
			is_need_bc = true
			bc_update_data.hp = scenegameobj.hp
			bc_update_data.hp2 = scenegameobj.hp2
			bc_update_data.hp3 = scenegameobj.hp3
		end
	
	end
	
	-- 广播给视野内玩家
	if is_need_bc then
		SceneService:sendAppearUpdate(nil, character, bc_update_data)
	end
end

-- 判断是否可以使用该瞬即BUFF
function BufferService:isEnableUseBuffer(character, buffer_base, targeter_aoi_id)
	local effect_id = buffer_base.effect_id
	local aoi_scene = GameObjectService:getAoiScene(character)
	
	-- 加血量百分比
	if effect_id == EffectType.max_hp_perc then
		-- 如果玩家是血为0状态，不能使用痊愈
		if character.hp <= 0 then
			return false, errorCodes.SCENE_BUFFER_DEAD_NO_USE
		end
		
		-- 血已满
		if character.hp >= character.max_hp then
			return false, errorCodes.SCENE_BUFFER_HP_FULL_NO_USE
		end
	
	end
	
	return true
end

-- 响应切换场景完成
function BufferService.afterEnterScene(character, aoiscene, prev_scene_id, is_reconnect, is_login)
	
end

-- 响应离开场景
function BufferService.afterLeaveScene(character, aoiscene, leave_type)
	-- 清空BUFFER
	if character.tmps then
		character.tmps.fight_buffers = Buffers:new()
	end
end

-- 清理所有的负面BUFFER
function BufferService:clearDeBuffer(scenegameobj)
	local _, bufobjs_tmp = BufferService:getBufobjs(scenegameobj)
	local buffers = scenegameobj.tmps.fight_buffers
	local is_cleard = false
	
	if not buffers or not bufobjs_tmp then
		return
	end
	
	local arr_del_buffer_id = {}
	for effect_type, buffer in pairs(bufobjs_tmp) do
		if buffer.buffer_base.is_debuffer == 1 or buffer.buffer_base.is_dead_del == 1 then
			bufobjs_tmp[effect_type] = nil
			is_cleard = true
			arr_del_buffer_id[#arr_del_buffer_id+1] = buffer.id
		end
	end
	
	if is_cleard then
		self:_clearHuancun(scenegameobj)
	end
	
	if scenegameobj.aoi_type == obj_type_player and #arr_del_buffer_id > 0 then
		-- RSP
	end
end

-- BUFFER过期处理(timer 回调)
function BufferService:expire(scenegameobj, buffer_id, is_tmp_buffer)
	local bufobjs, bufobjs_tmp = BufferService:getBufobjs(scenegameobj)
	local buffers = scenegameobj.buffers
	if is_tmp_buffer then
		bufobjs = bufobjs_tmp
		buffers = scenegameobj.tmps and scenegameobj.tmps.fight_buffers or nil
	end
	
	local buffer_base = BufferBaseDao[buffer_id]
	local effect_type = assert(Effectid2name[buffer_base.effect_id], buffer_base.effect_id)
	if buffers ~= nil and bufobjs ~= nil then
		local buffer = bufobjs[effect_type]
		if buffer ~= nil then
			-- 提前80MS调用过期，认为是允许的
			if buffer.expire_time - 80 <= ext_getNowUnixMsTime() then
				bufobjs[effect_type] = nil
				
				BufferService:_clearHuancun(scenegameobj)
			end
		end
	end
end

-- 初始化
function BufferService:init(character)
	
	return true
end

-- 持久化
function BufferService:key2Dirty(character)
	CharacterService:key2Dirty(character, 'buffers')
end


do
	local game_objss = {false, false, false, false}
	local Time = Time
	
	function BufferService:updateBuffer(time_now, aoi_scene, objs_player, objs_robot, objs_monster, objs_pets)
		local is_500ms_start = Time.is_500ms_start
		if not is_500ms_start then
			return
		end
		
		game_objss[1] = objs_player or false
		game_objss[2] = objs_robot or false
		game_objss[3] = objs_monster or false
		game_objss[4] = objs_pets or false
		
		local is_need_buffer_update = aoi_scene.is_need_buffer_update
		
		-- 是否需要更新战斗事件
		if not is_need_buffer_update then
			return 
		end
		
		local is_no_need_update = true
		
		for _, game_objs in ipairs(game_objss) do
			if game_objs then
				for _, game_obj in pairs(game_objs) do
					-- 处理定时BUFFER
					local perframework_buffers = self:getHuancun(game_obj)
					if perframework_buffers and next(perframework_buffers) then
						self:_dealFrameBuffers(aoi_scene, game_obj, perframework_buffers, time_now)
						is_no_need_update = false
					end
				end
			end
		end
		
		if is_no_need_update then
			aoi_scene.is_need_buffer_update = false
		end
	end
	
	local FightService
	local ceil = math.ceil
	function BufferService:_dealFrameBuffers(aoi_scene, game_obj, buffers, time_now)
		if not FightService then FightService = _G.FightService end
		local arr_gpid
		local tmps = game_obj.tmps
		local frame_buffers_up_ltime = tmps.frame_buffers_up_ltime or {}
		tmps.frame_buffers_up_ltime = frame_buffers_up_ltime
		
		for _, buffer in pairs(buffers) do
			local buffer_id = buffer.id
			local ltime = frame_buffers_up_ltime[buffer_id] or 0
			if buffer.expire_time >= time_now and ltime + buffer.buffer_base.freq_msec <= time_now then
				local effect_type = buffer.effect_type
				
				local hp_index, hp_key, max_hp_key = FightService:getHpInfo(game_obj)
				local now_hp, max_hp = game_obj[hp_key], game_obj[max_hp_key]
				
				if now_hp > 0 then
					-- 每X秒流失最大血量x%
					if effect_type == 'lost_max_hp_perc' then
						if now_hp < max_hp then
							FightService:addObjectHp(game_obj, 0, -1*buffer.effect_value, true, aoi_scene)
						end
						frame_buffers_up_ltime[buffer_id] = time_now
						
					-- 每X秒回复最大血量x%
					elseif now_hp > 0 and effect_type == 'restore_max_hp_perc' then
						if now_hp < max_hp then
							FightService:addObjectHp(game_obj, 0, buffer.effect_value, true, aoi_scene)
						end
						frame_buffers_up_ltime[buffer_id] = time_now
					end
				end
			end
		end
	end

end

do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort
	local writeCoord = FastPacket.writeCoord	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	
	function BufferService:writeAppearDetail(game_obj, fast_packet)	    
		
		local bufobjs_bc = self:getBcBufObjs(game_obj)
		local buffer_len = #bufobjs_bc
		writeUShort(fast_packet, buffer_len)
		for _, buffer in pairs(bufobjs_bc) do
			local effect_id = buffer.effect_id
			writeUInt(fast_packet, buffer.id)
			writeLong(fast_packet, buffer.expire_time)
		end
		
	end
end

do
	local buffers_info = {}
	
	function BufferService:pack(character)
		local buffers = character.buffers
		buffers_info.bufobjs = buffers.bufobjs
		local data = WorldPacket:encodeData(buffers_info)
		return data
	end
end

do
	local rsp_opcode = opCodes.M2C_BUFFER_UPDATE
	local msg_name = 'PackBuffer.M2C_BUFFER_UPDATE'
	local msg_proto = {}
	local TianmoConfig = TianmoConfig
	function BufferService:bcBuffers(aoi_scene, game_obj, arr_bc_pid)
		local arr_bc_pid = arr_bc_pid
		if not arr_bc_pid then
			if game_obj.aoi_type ~= aoi_type_monster and game_obj.aoi_type ~= aoi_type_player and aoi_scene.scene_id == TianmoConfig.boss_room_scene_id then
				arr_bc_pid = GameObjectService:getBcGPidsForFight(game_obj, aoi_scene, 5)
			else
				arr_bc_pid = GameObjectService:getFovGPids(game_obj, aoi_scene)
			end
		end
		local arr_buffer = self:getBcBufObjs(game_obj)
		if arr_buffer and #arr_buffer > 0 then
			msg_proto.arr_buffer = arr_buffer
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, arr_bc_pid)
		end
	end
	
	local msg_proto2 = {}
	function BufferService:sendBuffers(aoi_scene, game_obj, arr_buffer_id)
		local fight_buffers = game_obj.tmps.fight_buffers
		if not fight_buffers then
			return
		end
		local bufobjs = fight_buffers.bufobjs
		
		local arr_buffer = {}
		msg_proto2.arr_buffer = arr_buffer
		for _, buffer_id in pairs(arr_buffer_id) do
			local buffer_base = BufferBaseDao[buffer_id]
			local effect_type = assert(Effectid2name[buffer_base.effect_id], buffer_base.effect_id)
			if bufobjs[effect_type] then
				arr_buffer[#arr_buffer+1] = bufobjs[effect_type]
			end
		end
		if #arr_buffer > 0 then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto2, nil, game_obj.gpid)
		end
	end
end

do
	local rsp_opcode = opCodes.M2C_BUFFER_DEL
	local msg_name = 'PackBuffer.M2C_BUFFER_DEL'
	local msg_proto = {}
	local arr_buffer_del = {}
	function BufferService:sendDelBuffers(aoi_scene, game_obj, arr_buffer_id, arr_bc_pid)
		local arr_bc_pid = arr_bc_pid or GameObjectService:getFovGPids(game_obj, aoi_scene)
		arr_buffer_del[1] = {aoi_id = game_obj.aoi_id, arr_buffer_id=arr_buffer_id}
		msg_proto.arr_buffer_del = arr_buffer_del
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, arr_bc_pid)
	end
end
