AoiSceneService = AoiSceneService or {}

local error = error
local pairs = pairs
local next = next
local AoiDao = AoiDao
local aoi_scenes = AoiDao.aoi_scenes
local AoiScene = AoiScene
local Time = Time

local external = external
local externalGetFovNew = external.getFovNew
local externalGetFov = external.getFov
local random = math.random
local floor = math.floor
local Formula = Formula
local Time = Time
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
local AoiObjectType = AoiObjectType
local AoiObject = AoiObject
local LOG_LEVEL = Config.LOG_LEVEL
local LOG_LEVEL_DEBUG = LOG_LEV.DEBUG
local WorldPacket = WorldPacket

local GameObjectService
local g_bEnableLuaTimeoutGuard=OptimizeDbg.g_bEnableLuaTimeoutGuard

local getShieldLevel=external.getShieldLevel
local printSceneData=external.printSceneData

function AoiSceneService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
end

do
	local AoiSceneDataService	
	function AoiSceneService:newAoiScene(space_id,scene_base)
		if not AoiSceneDataService then AoiSceneDataService = _G.AoiSceneDataService end
		
		if aoi_scenes[space_id] then
			error("space_id is exists " .. space_id)
		end
		
		local res_id = scene_base.res_id
		local aoi_scene_data = AoiSceneDataService:getAoiSceneData(res_id)	
		local aoi_scene = AoiScene:new(space_id,scene_base,aoi_scene_data)	
		aoi_scenes[space_id] = aoi_scene	
		return aoi_scene
	end
end

function AoiSceneService:getAoiScene(space_id)	
	return aoi_scenes[space_id]
end

function AoiSceneService:getAoiScenes()	
	return aoi_scenes
end

function AoiSceneService:getAoiScenesBySceneId(scene_id)		
	local num = 0
	local aoi_scenes_new = {}
	for _, aoi_scene in pairs(aoi_scenes) do		
		if aoi_scene and aoi_scene.scene_id == scene_id then
			num = num + 1
			aoi_scenes_new[num] = aoi_scene
		end		
	end
	
	return aoi_scenes_new, num
end

do
	local assert = assert
	local external_delAOIScene = external.delAOIScene
	local pairs = pairs
	function AoiSceneService:delAoiScene(space_id, is_instance_space)
		-- 检查场景是否已删除
		local aoi_scene = aoi_scenes[space_id]
		if not aoi_scene then
			error("aoi scene is deleted, space_id = " .. space_id)
		end
		
		-- 所有玩家都已离开了场景，才能删除该场景实例
		assert(aoi_scene.player_num == 0)
		
		-- 调用C++等的删除场景函数
		-- 从delInstanceSpace函数调用过来的不能调用此函数
		if not is_instance_space then 
			external_delAOIScene(space_id)
		end
		
		-- 删除场景内非玩家的其他AOI对象
		GameObjectService:onDelAoiScene(aoi_scene, aoi_scene.aoi_id2game_objs)
		
		-- 将场景实例 删除掉
		aoi_scenes[space_id] = nil
	end
end

function AoiSceneService:beforeFrame()
	if AoiDao.is_dirty then
		AoiDao.is_dirty = false
	end
end

local g_FrameIdx=0

do
	local MonsterAiService
	local MotionService
	local CharacterService
	local FightService, TrapService, BufferService
	
	local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
	local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
	local aoi_type_item = AoiObjectType.AOI_OBJECT_TYPE_ID_ITEM
	local aoi_type_robot = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT
	local aoi_type_trap = AoiObjectType.AOI_OBJECT_TYPE_ID_TRAP
	local aoi_type_pet = AoiObjectType.AOI_OBJECT_TYPE_ID_PET
	local aoi_type_beast = AoiObjectType.AOI_OBJECT_TYPE_ID_BEAST
	local aoi_type_guard_npc = AoiObjectType.AOI_OBJECT_TYPE_ID_GUARD_NPC
	local getNowUnixMsTime = external.getNowUnixMsTime	
	local getNowUnixUsTime = external.getNowUnixUsTime
	
	-- AOI 帧更新
	function AoiSceneService:updateAoiScene(time_now, aoi_scene, scene_base,FrameIdx)
	       g_FrameIdx=FrameIdx
		if not BufferService then
			MonsterAiService = _G.MonsterAiService
			MotionService = _G.MotionService
			CharacterService = _G.CharacterService
			FightService = _G.FightService
			TrapService = _G.TrapService
			BufferService = _G.BufferService
		end
		
		-- 场景中没有玩家，跳过	
		if aoi_scene.player_num <= 0 then					
			return
		end
		
		-- 场景暂停中
		local is_pause = aoi_scene.is_pause
		if is_pause then
			-- 暂停已过期，恢复场景帧更新
			if (aoi_scene.is_pause_expire or 0) <= time_now then
				is_pause = false
				aoi_scene.is_pause = false
			end
		end
		if is_pause then
			return
		end
		
		local aoi_type2game_objs = aoi_scene.aoi_type2game_objs
		local objs_monster = aoi_type2game_objs[aoi_type_monster] -- 场景实例中的怪物队列
		local objs_player = aoi_type2game_objs[aoi_type_player]	 -- 场景实例中的角色队列
		local objs_item = aoi_type2game_objs[aoi_type_item]		 -- 场景实例中的ITEM队列
		local objs_robot = aoi_type2game_objs[aoi_type_robot]	 -- 场景实例中的机器人队列
		local objs_pets = aoi_type2game_objs[aoi_type_pet]		 -- 场景实例中的幻兽队列
		local objs_trap = aoi_type2game_objs[aoi_type_trap]		 -- 场景实例中的陷阱队列
		local objs_beast = aoi_type2game_objs[aoi_type_beast]	 -- 场景实例中的召唤兽队列
		local objs_guard_npc = aoi_type2game_objs[aoi_type_guard_npc]-- 场景实例中的守护NPC队列
		local update_obj_num = 0 -- 本次update处理的数量
		
		-- 注：所有的update帧更新函数里面，如果要在遍历game_objs里面添加同aoi_type对象，需要启动定时器来添加
		--     是为了避免破坏game_objs，导致遍历game_objs报错
		
		-- BUFFER更新
		BufferService:updateBuffer(time_now, aoi_scene, objs_player, objs_robot, objs_monster, objs_pets)
		
		-- 角色对象更新
		if next(objs_player) then
			update_obj_num = update_obj_num + (CharacterService:update(time_now, aoi_scene, objs_player) or 0)
		end
		
		-- 侠客更新
		if next(objs_pets) then
			update_obj_num = update_obj_num + (ChPetService:update(time_now, aoi_scene, objs_pets) or 0)
		end

		-- 召唤兽更新
		if next(objs_beast) then
			update_obj_num = update_obj_num + (BeastService:update(time_now, aoi_scene, objs_beast) or 0)
		end
		
		-- 守护NPC
		if next(objs_guard_npc) then
			update_obj_num = update_obj_num + (GuardNpcService:update(time_now, aoi_scene, objs_guard_npc) or 0)
		end
		
		-- 怪物更新
		if next(objs_monster) then
		
			local stime2 
			if g_bEnableLuaTimeoutGuard then 
			   stime2 = getNowUnixUsTime()			
			end
			MonsterAiService:update(time_now, aoi_scene, objs_monster,g_FrameIdx)
			if g_bEnableLuaTimeoutGuard then
			  local etime2 = getNowUnixUsTime()	
			  if etime2 - stime2 >= 1000 then
			    printf('space_id:%d [MonsterAiService:update] use time(us) :%d.',aoi_scene.space_id,etime2 - stime2)
			  end
			end
		end

		-- 陷阱更新
		if next(objs_trap) then
			update_obj_num = update_obj_num + (TrapService:update(time_now, aoi_scene, objs_trap) or 0)
		end
		
		-- 机器人更新
		if next(objs_robot) then
			update_obj_num = update_obj_num + (SceneRobotService:update(time_now, aoi_scene, objs_robot) or 0)
		end
		
		-- ITEM 更新
		if next(objs_item) then
			update_obj_num = update_obj_num + (GameObjectService:updateItem(time_now, aoi_scene, objs_item) or 0)
		end
		
		return update_obj_num
	end
end

-----------------------------------------------------------------------------------
---------------------------- AoiScene start ---------------------------------------
-----------------------------------------------------------------------------------

--- 产生aoi对象id，递增
function AoiScene:nextObjId()
	local obj_id = self.next_obj_id
	self.next_obj_id = obj_id + 1
	
	local rang_id = nil	
	local next_rang_ids = self.next_rang_ids
	if next_rang_ids then
		local n = #next_rang_ids
		if n > 0 then
			rang_id = next_rang_ids[n]
			next_rang_ids[n] = nil
		end
	end	
	if not rang_id then
		rang_id = self.next_rang_id
		self.next_rang_id = rang_id + 1
	end
	
	if rang_id > 1000 then
		local msg = self.space_id .. ',' .. self.scene_id .. ',' .. rang_id .. ',' .. (next_rang_ids and #next_rang_ids or 'nil')
		error(msg)
	end
	
	return obj_id, rang_id
end

--- 获取一个AOI对象
function AoiScene:getObj(obj_id)
	return self.objs[obj_id]
end

--- 获取所有AOI对象
function AoiScene:getObjs()
	return self.objs
end

--- 获取AOI对象集合
function AoiScene:getObjsByIds(aoi_ids)
	local ret = {}
	local j = 0

	local objs = self.objs
	for i=1,#aoi_ids do
		local obj_id = aoi_ids[i]
		local obj = objs[obj_id]
		if obj then
			j = j + 1
			ret[j] = obj
		end
	end
	return ret,j
end

local push_laoi_garbage = push_laoi_garbage

--- 添加一个对象
-- 注意，该接口不保留给外面使用，请调用 GameObjectService:addAoiObj()函数
do
	local SceneService
	local CHARACTER_FOV_SIZE = CharacterDefs.CHARACTER_FOV_SIZE
	local createAOIObj = external.createAOIObj
	local externalAddAOIObj = external.addAOIObj
	function AoiScene:addAoiObj(aoi_obj)
		if not SceneService then SceneService = _G.SceneService end
		local obj_id,obj_type = aoi_obj.obj_id, aoi_obj.obj_type
		
		-- 已经添加过
		if self.objs[obj_id] then
			error("aoi_obj is exists " .. obj_id)
		end
		
		local fov_size = CHARACTER_FOV_SIZE
		assert(fov_size > 1)
		
		-- 创建C++ AOI 对象
		local c_obj = createAOIObj()
		c_obj:bind(aoi_obj)		
		if aoi_obj.obj_type ~= aoi_type_monster then aoi_obj.x, aoi_obj.y = self:fixPos(aoi_obj.x , aoi_obj.y) end
		c_obj:setAOIData(obj_type, obj_id, aoi_obj.x, aoi_obj.y, fov_size)
		c_obj:setGameData(self.res_id, self.space_id, aoi_obj.rang_id)	
		
		-- 添加到C++层的AOI对象列表内
		local ret , arr_appeare = externalAddAOIObj(c_obj)
		if ret ~= 0 then
			local msg = 'external.addAOIObj::ret=' .. ret .. ", res_id="  .. self.res_id .. "(" .. aoi_obj.x  .. "," .. aoi_obj.y ..")"
			error(msg)
		end
		
		aoi_obj.c_obj = c_obj

		-- 添加到LUA层的AOI对象列表内
		self.objs[obj_id] = aoi_obj
		
		-- 累计场景实例内的 玩家、怪物数量
		if obj_type == aoi_type_player then			
			self.player_num = self.player_num + 1
		elseif obj_type == aoi_type_monster then
			self.monster_num = self.monster_num + 1
		end
		
		-- 加入到垃圾回收检测器内
		push_laoi_garbage(aoi_obj)
		
		-- 处理 场景 APPEAR 事件
		SceneService:appearAoi(self, aoi_obj, arr_appeare)
		
	end
	
	--- 添加对象列表
	local addAOIObjList = external.addAOIObjList
	function AoiScene:addAoiObjs(arr_aoi_obj)
		if not SceneService then SceneService = _G.SceneService end
		
		local objs = self.objs
		local c_objs = {}
		
		local fov_size = CHARACTER_FOV_SIZE
		assert(fov_size > 1)
		
		local res_id, space_id = self.res_id, self.space_id
		local aoi_obj_cnt = #arr_aoi_obj
		for i = 1, aoi_obj_cnt do
			local aoi_obj = arr_aoi_obj[i]
			local obj_id, obj_type = aoi_obj.obj_id, aoi_obj.obj_type
			
			-- 已经添加过
			if objs[obj_id] then
				error(string.format("[AoiScene:addObjs]aoi_obj is exists.obj_id:%d,scene_id:%d,space_id:%d", obj_id, self.scene_id, self.space_id))
			end
			
			-- 创建C++ AOI 对象
			local c_obj = createAOIObj()
			c_obj:bind(aoi_obj)		
			if aoi_obj.obj_type ~= aoi_type_monster then aoi_obj.x , aoi_obj.y  = self:fixPos(aoi_obj.x , aoi_obj.y) end
			c_obj:setAOIData(obj_type, obj_id, aoi_obj.x, aoi_obj.y, fov_size)
			c_obj:setGameData(self.res_id, self.space_id, aoi_obj.rang_id)	
			c_objs[i] = c_obj
			
			aoi_obj.space_id = self.space_id
			aoi_obj.c_obj = c_obj

			-- 添加到LUA层的AOI对象列表内
			objs[obj_id] = aoi_obj
			
			-- 累计场景实例内的 玩家、怪物数量
			if obj_type == aoi_type_player then			
				self.player_num = self.player_num + 1
			elseif obj_type == aoi_type_monster then
				self.monster_num = self.monster_num + 1
			end
			
			-- 加入到垃圾回收检测器内
			push_laoi_garbage(aoi_obj)
		end
		
		-- 添加到C++层的AOI对象列表内
		local map_appear_objs = addAOIObjList(c_objs)
		
		-- 处理 场景 APPEAR 事件
		for obj_id, appear_objs in pairs(map_appear_objs) do	
			local aoi_obj = objs[obj_id]
			SceneService:appearAoi(self, aoi_obj, appear_objs)
		end
	end
end

--- 更新视野
do
	local externalGetFovChangeObjects= external.getFovChangeObjects
	local SceneService
	
	function AoiScene:updateFov(aoi_obj)
		if not SceneService then SceneService = _G.SceneService end
		
		local ret,arr_appeare, arr_disappeare = externalGetFovChangeObjects(aoi_obj.c_obj,aoi_obj.x,aoi_obj.y)
		if ret == 0 then
			SceneService:appearAoi(self, aoi_obj, arr_appeare, 'updateFov')		
			SceneService:disappearAoi(self, aoi_obj, arr_disappeare, 'updateFov')
		end
		
	end
end


--- 删除对象
do
	local AoiDao = AoiDao
	local externalDelAOIObj = external.delAOIObj
	local releaseAOIObj = external.releaseAOIObj
	local releaseFastPacket  = external.releaseFastPacket
	local SceneService
	function AoiScene:delObj(aoi_obj, game_obj)
		if not SceneService then SceneService = _G.SceneService end
		
		-- 删除c_obj
		local ret_val , arr_disappeare = externalDelAOIObj(aoi_obj.c_obj)
		if ret_val ~= 0 then
			error('external.delAOIObj::ret_val = ' .. ret_val)
		end
		
		local obj_type = aoi_obj.obj_type
		local obj_id = aoi_obj.obj_id
		
		-- 从aoi obj列表删除掉
		self.objs[obj_id] = nil
		
		-- 怪物、玩家数量 减一
		if obj_type == aoi_type_player then			
			self.player_num = self.player_num - 1
		elseif obj_type == aoi_type_monster then
			if game_obj.hp > 0 then
				self.monster_num = self.monster_num - 1
			end
		end
		
		-- AOI disappear 事件处理
		SceneService:disappearAoi(self, aoi_obj, arr_disappeare, 'delObj')
		
		-- 释放APPEAR BIN
		local appear_bin = game_obj.tmps.appear_bin
		if appear_bin and not game_obj.is_keep_appear_bin then 
			game_obj.tmps.appear_bin = nil
			releaseFastPacket(appear_bin)
		end
		
		-- 重置appear bin 版本
		game_obj.tmps.appear_bin_ver = nil
		
		-- 释放C++的AOI对象资源
		releaseAOIObj(aoi_obj.c_obj)
		aoi_obj.c_obj = nil
		
		-- 设置已删标志
		aoi_obj.is_deleted = true
		
		-- 回收 rang_id
		local next_rang_ids = self.next_rang_ids
		if not next_rang_ids then
			next_rang_ids = {}
			self.next_rang_ids = next_rang_ids
		end
		next_rang_ids[ #next_rang_ids + 1] = aoi_obj.rang_id
	end
end

---阻挡信息是一维数组，将二维坐标转换成一维坐标
-- x,y base 0
-- return idx base 1
function AoiScene:posToIndex(x,y)
	
	x ,y = floor(x),floor(y)
	if x<0 or y<0 then return -1 end
	
	local width,height = self.width, self.height
	if x>=width or y>=height then return -1 end
	
	return y*width + x + 1
end

local getNowUnixUsTime = external.getNowUnixUsTime
	
-- 获取圆形范围内的AOI对象列表
-- r	圆形半径	注：必须小于等于视野大小
-- return arr_aoi_obj:table
function AoiScene:getRoundPlayerAoiObjs(aoi_obj_src, r)
	local ret_val, aoi_objs = externalGetFov(aoi_obj_src.c_obj, aoi_type_player)
	if ret_val ~= 0 then error('external.getFov::ret_val = ' .. ret_val) end
	if not aoi_objs then return {} end
	
	local fov_size = self.scene_base.fov_size
	if fov_size == r then
		return aoi_objs
	end
			
	local x, y = aoi_obj_src.x, aoi_obj_src.y
	local idx = 0
	local arr_aoi_obj = {}
	local rr = r * r
	
	for _, aoi_obj in pairs(aoi_objs) do
		if aoi_obj then		
			local tx, ty = aoi_obj.x, aoi_obj.y
			
			-- 比较距离
			local d_tx, d_ty = tx - x, ty - y
			if d_tx * d_tx + d_ty * d_ty <= rr then
				idx = idx + 1
				arr_aoi_obj[idx] = aoi_obj
			end
		end
	end
	
	return arr_aoi_obj
end


do
	-- 获取圆形范围内的AOI对象列表
	-- r	圆形半径	注：必须小于等于视野大小
	function AoiScene:getRoundObjs(aoi_obj_src, x, y, r, aoi_types_mask)
		local ret_val, aoi_objs = externalGetFovNew(aoi_obj_src.c_obj, aoi_types_mask)
		if ret_val ~= 0 then error('external.getFov::ret_val = ' .. ret_val) end
		if not aoi_objs then return {}, 0 end
		
		local fov_size = self.scene_base.fov_size
		if fov_size == r then
			return aoi_objs, #aoi_objs
		end
		
		local idx = 0
		local arr_aoi_obj = {}
		local rr = r * r
		local getGameObjectByAoiId = GameObjectService.getGameObjectByAoiId
		for _, aoi_obj in pairs(aoi_objs) do
			if aoi_obj then		
				local game_obj = getGameObjectByAoiId(GameObjectService, self, aoi_obj.obj_id)
				if game_obj then
				local tx, ty = aoi_obj.x, aoi_obj.y
				
				-- 考虑身体半径
				local body_size = (game_obj.body_size or 0) * (game_obj.model_times or 1)
				local t_r = r + body_size
				local t_rr = body_size > 0 and t_r * t_r or rr
				
				-- 比较距离
				local d_tx, d_ty = tx - x, ty - y
				if d_tx * d_tx + d_ty * d_ty <= t_rr then
					idx = idx + 1
					arr_aoi_obj[idx] = aoi_obj
				end
				end
			end
		end
		
		return arr_aoi_obj, idx
	end
	
	-- 获取矩形的2个顶点
	local function _getRect2Point(x1,y1,x2,y2,long,wide)
		local x,y = x2-x1,y2-y1
		local x1_vertex = ((wide*0.5)/long) * y * -1
		local y1_vertex = ((wide*0.5)/long) * x
		local x2_vertex = -x1_vertex
		local y2_vertex = -y1_vertex
		
		return x1_vertex + x1, y1_vertex + y1, x2_vertex + x1, y2_vertex + y1
	end
	
	-- 计算叉乘 |PP1| × |PP2| 
	local function _mulitpy(x1, y1, x2, y2, x, y)
		return (x1-x)*(y2-y) - (x2-x)*(y1-y)
	end
	
	-- 计算一个点是否在矩形中
	-- |P2P|×|P1P2|*|P3P|×|P3P4|<=0 And |P1P|×|P1P4|*|P2P|×|P2P3|<=0
	local function _getRect4Point(x,y,x1,y1,x2,y2,long,wide,body_size)
		if body_size > 0 then
			wide = wide + body_size * 2
			local x,y = x2-x1,y2-y1
			x2 = (long + body_size) * x/long + x1
			y2 = (long + body_size) * y/long + y1
			long = long + body_size
		end
		
		-- 获取矩形的四个顶点
		local x1v, y1v, x2v, y2v = _getRect2Point(x1,y1,x2,y2,long,wide)
		local x3v, y3v, x4v, y4v = _getRect2Point(x2,y2,x1,y1,long,wide)
		
		-- TODO:为了提给效率，可以展开来，不掉用_mulitpy函数
		if (_mulitpy(x,y,x1v,y1v,x2v,y2v) * _mulitpy(x,y,x4v,y4v,x3v,y3v)) <= 0 and
			(_mulitpy(x,y,x4v,y4v,x1v,y1v) * _mulitpy(x,y,x3v,y3v,x2v,y2v)) <= 0 then
			return true
		end
		
		return false
	end
	
	-- 获取矩形范围内的AOI对象列表
	-- r	圆形半径	注：必须小于等于视野大小
	function AoiScene:getObjsForDestRect(aoi_obj_src, dst_x, dst_y, wide, aoi_types_mask, dst_aoi_id)
		local ret_val, aoi_objs = externalGetFovNew(aoi_obj_src.c_obj, aoi_types_mask)
		if ret_val ~= 0 then error('external.getFov::ret_val = ' .. ret_val) end
		if not aoi_objs then return {}, 0 end
		
		local idx = 0
		local arr_arr_objs = {}
		local src_x, src_y = aoi_obj_src.x, aoi_obj_src.y
		
		-- 计算矩形的长
		local long = Formula:distance(src_x, src_y, dst_x, dst_y)
		--assert(long > 0.1)
		
		local getGameObjectByAoiId = GameObjectService.getGameObjectByAoiId
		local _getRect4Point = _getRect4Point
		for _, aoi_obj in pairs(aoi_objs) do
			if aoi_obj then		
				local game_obj = getGameObjectByAoiId(GameObjectService, self, aoi_obj.obj_id)
				if game_obj then
				
				local aoi_obj_x, aoi_obj_y = aoi_obj.x, aoi_obj.y
				
				-- 考虑身体半径
				local body_size = (game_obj.body_size or 0) * (game_obj.model_times or 1)
				
				local d_tx, d_ty = src_x - aoi_obj_x, src_y - aoi_obj_y
				local is_ok = false
				
				-- 如果是目标
				if dst_aoi_id and dst_aoi_id > 0 and aoi_obj.obj_id == dst_aoi_id then
					is_ok = true
					
				-- 考虑是否在自己是否在目标身体内
				elseif d_tx * d_tx + d_ty * d_ty <= body_size * body_size then
					is_ok = true
				
				-- 矩形非常小
				elseif long < 0.1 then
					if d_tx * d_tx + d_ty * d_ty <= 0.01 then
						is_ok = true
					end
				-- 检查是否在矩形范围内
				elseif _getRect4Point(aoi_obj_x, aoi_obj_y, src_x, src_y, dst_x, dst_y, long, wide, body_size) then
					is_ok = true
				end
				
				if is_ok then
					idx = idx + 1
					arr_arr_objs[idx] = aoi_obj
				end
				
				end
			end
		end
		
		return arr_arr_objs, idx
	end
	
end

do	
	--- 获取视野AOI对象列表, c++做了缓存，高效
	function AoiScene:getFovObjs(aoi_obj, aoi_type)
		local ret_val, objs = externalGetFov(aoi_obj.c_obj, aoi_type)
		if ret_val ~= 0 then
			error('external.getFov::ret_val = ' .. ret_val)
		end
		return objs or {}
	end
	
end

--- 获取本场景内AOI对象总数
function AoiScene:getObjNum()
	local num = 0
	for obj_id, aoi_obj in pairs(self.objs) do
		num = num + 1		
	end
	return num
end


do
	-- 寻径
	-- error_span	容错距离(如：error_span=2 代表寻路到目标点附近2米内任一个地方都可以)
	-- @return [x1,y1,x2,y2,...]
	local externalGetAOIPath = external.getAOIPath
	function AoiScene:getPath(src_x, src_y, dst_x, dst_y, error_span)
		-- 位置边界检查
		local width, height = self.width, self.height
		if src_x<0 or src_x>=width or dst_x<0 or dst_x>=width or src_y<0 or src_y>=height or dst_y<0 or dst_y>=height then
			Logger:error('[AoiScene:getPath] pos err',src_x,src_y,dst_x,dst_y,'|',width,height)
			return 
		end
		
		-- 避免玩家在阻挡内，怪物无法攻击到他，所以这里对目标位置做修正
		local dst_x_t, dst_y_t = self:fixPos(dst_x, dst_y, false, 7)
		if floor(dst_x) ~= floor(dst_x_t) or floor(dst_y) ~= floor(dst_y_t) then
			error_span = 1
		end
		dst_x, dst_y = dst_x_t, dst_y_t
		
		-- 获取路径
		local ret_val,paths,path_len = externalGetAOIPath(self.space_id,src_x,src_y,dst_x,dst_y,error_span,true)
		paths = paths or {}
		
		-- 寻路失败
		if ret_val ~= 0 then
			Logger:error('[AoiScene:getPath] get path fail', ret_val, self.scene_id, src_x, src_y, dst_x, dst_y)
			return 
		
		-- 寻路成功
		else
			-- TEST
			-- externalGetAOIPath 有一个BUG， 开始点有出现重叠
			if path_len > 4 then
				local paths_new = {paths[1], paths[2]}
				for i = 5, path_len do paths_new[#paths_new+1] = paths[i] end
				paths = paths_new
				
				path_len = path_len - 2
			end
		end
		
		return paths, path_len
	end
end

do
	-- 连击时攻击者需要跟随目标对象
	-- 获取跟随位置
	-- attack_x, attack_y		攻击者对象的位置
	-- target_x, target_y		被攻击对象的位置
	function AoiScene:getLianjiPos(attack_x, attack_y, target_x, target_y, dist)
		local symmetry_x = -(attack_x - target_x) + target_x
		local symmetry_y = -(attack_y - target_y) + target_y
		return self:jituiPos(symmetry_x, symmetry_y, target_x, target_y, dist)
	end
end

--- 为怪物就近寻找 一个空闲位置（非阻挡，没有其他静止的活怪物）
-- 用于怪物攻击玩家时 寻找一个停下来攻击的位置
-- return false/true, dest_x, dest_y
do
--  8个位置，16个坐标
--	           1,2
--
--     15,16          3,4
--
--  13,14       *        5,6
--
--     11,12          7,8
--
--             9,10
	local pos_8 = {}
	local function genPos(x,y,r)
		local a = r/1.414
		pos_8[1],  pos_8[2]		= x,   y+r
		pos_8[3],  pos_8[4]		= x+a, y+a
		pos_8[5],  pos_8[6]		= x+r, y
		pos_8[7],  pos_8[8]		= x+a, y-a
		pos_8[9],  pos_8[10]	= x,   y-r
		pos_8[11], pos_8[12]	= x-a, y-a
		pos_8[13], pos_8[14]	= x-r, y
		pos_8[15], pos_8[16]	= x-a, y+a
	end
	
	-- 9种位置编号顺序组合
	local poss_orderby1 = {1,2,3,4,5,6,15,16,7,8,13,14,9,10,11,12}
	local poss_orderby2 = {5,6,3,4,7,8,1,2,9,10,15,16,11,12,13,14}
	local poss_orderby3 = {5,6,7,8,3,4,9,10,1,2,11,12,15,16,13,14}
	local poss_orderby4 = {7,8,9,10,5,6,11,12,3,4,13,14,1,2,15,16}
	local poss_orderby5 = {9,10,11,12,7,8,13,14,5,6,15,16,3,4,1,2}
	local poss_orderby6 = {11,12,13,14,9,10,15,16,7,8,1,2,5,6,3,4}
	local poss_orderby7 = {13,14,15,16,11,12,1,2,9,10,3,4,7,8,5,6}
	local poss_orderby8 = {15,16,1,2,13,14,3,4,11,12,5,6,9,10,7,8}
	local poss_orderby9 = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16}
	
	-- 获取 起始编号离自己最近的 顺序组合
	local function getNearPossOrderbys(relative_x, relative_y)
		local arr_pos_idx
		
		if relative_x >= 0 and relative_y > 0 then
			arr_pos_idx = relative_x<relative_y and poss_orderby1 or poss_orderby2
		elseif relative_x > 0 and relative_y <= 0 then
			arr_pos_idx = relative_x>-relative_y and poss_orderby3 or poss_orderby4
		elseif relative_x <= 0 and relative_y < 0 then
			arr_pos_idx = -relative_x<-relative_y and poss_orderby5 or poss_orderby6
		elseif relative_x < 0 and relative_y >= 0 then
			arr_pos_idx = -relative_x>relative_y and poss_orderby7 or poss_orderby8
		else
			Logger:error('[getNearPoss] err', relative_x, relative_y)
			arr_pos_idx = poss_orderby9
		end
		
		return arr_pos_idx
	end
	
	local sqrt = math.sqrt	
	local posToIndex = AoiScene.posToIndex
	local isMoving, MotionService
	function AoiScene:getIdlePosForMonster(monster_aoi_obj, player_aoi_obj)
		if not MotionService then
			MotionService = _G.MotionService
			isMoving = MotionService.isMoving
		end
		
		local mx,my = monster_aoi_obj.x, monster_aoi_obj.y
		local x,y = player_aoi_obj.x, player_aoi_obj.y
		local getGameObjectByAoiId = GameObjectService.getGameObjectByAoiId
		
		-- 标识视野的非空闲位置
		local busy_poses = {}
		local fov_aoi_objs = self:getFovObjs(player_aoi_obj, aoi_type_monster)
		for i = 1, #fov_aoi_objs do
			local aoi_obj = fov_aoi_objs[i]
			local game_obj = getGameObjectByAoiId(GameObjectService, self, aoi_obj.obj_id)
			-- 不死亡
			if game_obj and aoi_obj ~= monster_aoi_obj and game_obj.hp > 0 then
				local idx = posToIndex(self, aoi_obj.x, aoi_obj.y)
				if not busy_poses[idx] and not isMoving(MotionService, game_obj) then
					busy_poses[idx] = true
				end
			end
		end
		
		-- 原地就是空闲的
		if not busy_poses[posToIndex(self, mx, my)] then
			return false
		end
		
		-- 计算怪物离玩家的距离
		local mr = sqrt((mx-x)^2+(my-y)^2)
		-- 太靠近，修正距离为2米
		if mr < 2 then
			mr = 2
		end
		
		-- 生成16个散列坐标
		genPos(x, y, mr)
		
		-- 从顺时针查找空闲的点
		local poss_orderby = getNearPossOrderbys(mx-x, my-y)
		local cells = self.cells
		for i = 1, 16, 2 do
			local idx, idx2 = poss_orderby[i], poss_orderby[i+1]
			local tox,toy = pos_8[idx], pos_8[idx2]
			local pos_idx = posToIndex(self, tox, toy)
			local cell_xx = cells[pos_idx]
			if cell_xx and cell_xx > 0 and not busy_poses[pos_idx] then
				if tox == mx and toy == my then
					return false
				else
					return true, tox, toy
				end
			end
		end
		
		return false
	end
end

-- 根据 aoi obj 数组获取
-- return nil/arr_gpid, len		nil/返回gpid数组, 数组长度
function AoiScene:getGPidsByAoiObjs(arr_aoi_objs)
	local len = 0
	local gpids = {}
	local num = #arr_aoi_objs
	for i = 1, num do
		local aoi_obj = arr_aoi_objs[i]
		if aoi_obj.obj_type == aoi_type_player then		
			local gpid = aoi_obj.gpid
			if gpid and gpid > 0 then
				len = len + 1
				gpids[len] = gpid
			end
		end		
	end	
	return len>0 and gpids or nil, len
end

-- 判断是否可以跳跃
function AoiScene:canJump(x,y, xx,yy)
	local cells = self.cells
	local idx2 = self:posToIndex(xx,yy)
	local cell2 = cells[idx2]
	if not cell2 or cell2 == 0 then return false end
	return true
end

-- 判断是否可通行
function AoiScene:canPass(xx,yy)
	local cells = self.cells
	local idx2 = self:posToIndex(xx,yy)
	local cell2 = cells[idx2] or 0
	return cell2 >= 1
end


--- 检查客户端上报路径
function AoiScene:checkPath(pos_arr)
	local cells = self.cells
	local posToIndex = self.posToIndex
	local width,height = self.width, self.height
	local len = #pos_arr
	for i=1,len,2 do
		-- 仅仅做边界检查，不做是否可通行检查，提高性能
		local x,y = pos_arr[i] , pos_arr[i+1]
		if x<0 or x>width or y<0 or y> height then
			Logger:error('AoiScene:check_path false',self.res_id,width,height,x,y)
			return false
		end
		
		-- 在调试阶段开启路径点是否在阻挡位置检查(暂不检查)
		if false and LOG_LEVEL <= LOG_LEVEL_DEBUG then
			local idx = posToIndex(self, x, y)
			local cell = cells[idx]
			if not cell or cell == 0 then
				Logger:error('AoiScene:check_path false. mask encountered!',self.res_id, x, y)
				return false
			end
		end
	end
	return true
end

--- 获得最近的一个非阻挡位置
-- xx			X坐标点
-- yy			Y坐标点
-- is_must_find	是否必须找一个可通行位置
function AoiScene:fixPos(xx, yy, is_must_find, fix_radius)
	local cells = self.cells
	local posToIndex = self.posToIndex
	
	local idx_end = posToIndex(self, xx, yy)
	local cell_end = cells[idx_end]
	
	-- 不在阻挡位置，直接返回
	if cell_end and cell_end ~= 0 then
		return xx, yy
	end
	
	local fix_radius = fix_radius or 3
	
	-- 边界限制
	local width,height = self.width , self.height	
	if xx < fix_radius then xx = fix_radius end
	if yy < fix_radius then yy = fix_radius end		
	if xx >= width - fix_radius then xx = width - fix_radius end
	if yy >= height - fix_radius then yy = height - fix_radius end
	
	local idx_end = posToIndex(self,xx,yy)
	local cell_end = cells[idx_end]
	
	-- 是阻挡位置，需要修正
	if not cell_end or cell_end == 0 then
		-- 在附近fix_radius米内找一个非阻挡位置
		for i = -fix_radius, fix_radius do
			local tx = xx + i
			for j = -fix_radius, fix_radius do
				local ty = yy + j
				local idx = posToIndex(self,tx,ty)
				local cell_xx = cells[idx]
				if cell_xx and cell_xx > 0 then
					return tx , ty
				end
			end
		end
		
		-- 使用场景缺省修正位置
		if is_must_find then
			local default_pos = self.scene_base.default_fixed_pos
			if default_pos then			
				local tx,ty = default_pos[1],default_pos[2]
				local idx = posToIndex(self,tx,ty)
				local cell_xx = cells[idx]
				if cell_xx and cell_xx > 0 then
					return tx , ty
				end
				Logger:error('error default pos')
			end		
		end
		
		local g_character = WorldPacket.g_character
		if is_must_find then
			Logger:error(debug_traceback(2,5), type(g_character)=='table' and g_character.cid or 0, self.scene_base.default_fixed_pos, '场景表default_fixed_pos字段在阻挡内，找嘉雯( ' .. self.scene_id .. ', res_id ' .. self.res_id .. ',' .. xx .. ',' .. yy .. ')')
		else
			Logger:error(debug_traceback(2,5), type(g_character)=='table' and g_character.cid or 0, '所在位置是阻挡:', self.scene_id, xx, yy)
		end
	end
	
	return xx,yy
end

---正方形内 随机一个非阻挡位置
function AoiScene:randPos(x,y,r)
	local cells = self.cells
	local posToIndex = self.posToIndex
	for i=1,10 do
		local dx = floor(x + random(-r,r))
		local dy = floor(y + random(-r,r))
		local idx = posToIndex(self,dx,dy)
		local cell_xx = cells[idx]
		if cell_xx and cell_xx > 0 then
			return dx,dy
		end
	end
	
	-- 修正位置(避免x, y在阻挡内)
	return self:fixPos(x,y)
end


---正方形边沿 随机一个非阻挡位置
do
	local dts = {-1,0,1}
	local ii = 2
	function AoiScene:roundPos(x, y, r)
		dts[1], dts[ii] = dts[ii], dts[1]
		if ii == 2 then ii = 3 else ii = 2 end
			
		local cells = self.cells
		local posToIndex = self.posToIndex
		x,y,r = floor(x),floor(y),floor(r)
		for i=1,3 do
			local dtx = dts[i]			
			for j=1,3 do
				local dty = dts[j]	
				if dtx~=0 or dty~=0 then
					local dx,dy = x+dtx*r,y+dty*r
					local idx = posToIndex(self,dx,dy)
					local cell_xx = cells[idx]
					if cell_xx and cell_xx > 0 then
						return dx, dy
					end
				end
			end
		end
		
		-- 修正位置(避免x, y在阻挡内)
		return self:fixPos(x,y)
	end
end

do
	local sqrt = math.sqrt
	local abs = math.abs
	
	-- 获取前方目标点 (不考虑阻挡)
	-- is_target_start false:从攻击者起始的dist长的线段, true:从目标者起始的dist长的线段
	-- return x, y
	function AoiScene:getFrontPos(attack_x, attack_y, target_x, target_y, dist, is_target_start)
		local abs_x,abs_y
		local dtx = target_x - attack_x
		local dty = target_y - attack_y
		if dty >= -0.1 and dty <= 0.1 then
			abs_x = dist
			abs_y = 0
		elseif dtx >= -0.1 and dtx <= 0.1 then
			abs_x = 0
			abs_y = dist
		else
			local t = abs(dtx/dty)
			abs_y = dist/sqrt(1 + t*t)
			abs_x = t * abs_y
		end

		-- 计算击退目的点
		local dst_x = (is_target_start and target_x or attack_x) + ( (dtx>0) and abs_x or -abs_x)
		local dst_y = (is_target_start and target_y or attack_y) + ( (dty>0) and abs_y or -abs_y)		
		
		-- 地图边界修正
		local width,height = self.width, self.height
		if dst_x < 0 then dst_x = 0 end
		if dst_y < 0 then dst_y = 0 end
		if dst_x >= width then dst_x = width-1 end
		if dst_y >= height then dst_y = height-1 end
		
		return dst_x, dst_y
	end
	
	-- 获取前方最远攻击点  (不考虑阻挡)
	function AoiScene:getAttackFarthestPos(attack_x, attack_y, target_x, target_y, dist)
		return self:getFrontPos(attack_x, attack_y, target_x, target_y, dist, false)
	end
	
	-- 获取击退目标位置
	function AoiScene:jituiPos(attack_x, attack_y, target_x, target_y, jitui_dist)
		local dst_x, dst_y = self:getFrontPos(attack_x, attack_y, target_x, target_y, dist, true)
		
		if not self:canPass(dst_x,dst_y) then --阻挡	
			return
		end
		return dst_x, dst_y
	end
	
	-- 冲锋 (如果是阻挡，就冲到目标对象所在点)
	-- chongchi_dist	冲刺距离
	-- chong_guo_dist	冲过目标对象身后距离(如果有填则直接忽略chongchi_dist)
	-- return x, y
	local chongfeng_ignor_err_dots = {5,4,2}
	function AoiScene:getChongFengPos(attack_x, attack_y, target_x, target_y, chongchi_dist, chong_guo_dist)
		local chong_guo_dist = chong_guo_dist or 0
		local dst_x, dst_y
		if chong_guo_dist <= 0 then
			dst_x, dst_y = self:getAttackFarthestPos(attack_x, attack_y, target_x, target_y, chongchi_dist)
		else
			dst_x, dst_y = self:getFrontPos(attack_x, attack_y, target_x, target_y, chong_guo_dist, true)
		end
		
		--目标点是阻挡,直接挺到目标对象所在点
		if not self:canPass(dst_x,dst_y) then
			if chong_guo_dist <= 0 then
				for _, cc_dist in ipairs(chongfeng_ignor_err_dots) do
					dst_x, dst_y = self:getAttackFarthestPos(attack_x, attack_y, target_x, target_y, cc_dist)
									
					if self:canPass(dst_x,dst_y) then
						return dst_x, dst_y
					end
				end
			end
			
			return target_x, target_y
		end
		
		return dst_x, dst_y
	end
	
	--[[
		获取后退位置
		@param px player_x
		@param py player_y
		@param mx monster_x
		@param my monster_y
		@param r  后退格子数

		@return bool,x,y
	--]]
	local tableInsert = table.insert
	local ceil = math.ceil
	function AoiScene:getBackPos(px, py, mx, my, r)
		local ox,oy = mx,my
		local radix_x = mx > px and 1 or -1
		local radix_y = my > py and 1 or -1

		if ceil(px)== ceil(mx) then
			radix_x = 0
			my = my + radix_y * r
		elseif ceil(py)== ceil(my) then
			radix_y =0
			mx = mx + radix_x * r
		else
			local dt = abs((my-py)/(mx-px))
			local dtx = r/(sqrt(1+dt*dt))
			local dty = dtx * dt
			mx = mx + radix_x * dtx
			my = my + radix_y * dty
		end

		local poses = {mx,my}
		if radix_y == 0 then
			tableInsert(poses,mx);tableInsert(poses,my+1);
			tableInsert(poses,mx);tableInsert(poses,my-1);
		elseif radix_x == 0 then
			tableInsert(poses,mx+1);tableInsert(poses,my);
			tableInsert(poses,mx-1);tableInsert(poses,my);
		elseif radix_x == radix_y then
			tableInsert(poses,mx-1);tableInsert(poses,my+1);
			tableInsert(poses,mx+1);tableInsert(poses,my-1);
		else
			tableInsert(poses,mx+1);tableInsert(poses,my+1);
			tableInsert(poses,mx-1);tableInsert(poses,my-1);
		end

		local posToIndex = self.posToIndex
		local cells = self.cells
		local width = self.width
		local height = self.height

		local _idx = random(1,#poses/2)*2 - 1
		if _idx ~= 1 then
			poses[1],poses[_idx] = poses[_idx],poses[1]
			poses[2],poses[_idx+1] = poses[_idx+1],poses[2]
		end

		for i=1,#poses,2 do
			local x ,y = poses[i],poses[i+1]
			if x >= 0 and y >=0 and x<width and y<height then
				local idx = posToIndex(self,x,y)
				local cell = cells[idx]
				--printf("trye (%d,%d) => %d",x,y,idx)
				if cell and cell == 1 then
					--printf("ok")
					return true , x,y
				end
			end
		end

		return false
	end


end


--获取以（x，y）为中点，变长为2r的正方形内的所有可通行格子坐标
--返回 {x1,y1,x2,y2,...} 和 数组长度
local _passable_poses = {}
function AoiScene:getPassablePoses(x,y,r)

	local posToIndex = self.posToIndex
	local width = self.width
	local height = self.height
	local cells = self.cells

	x = floor(x)
	y = floor(y)

	local this_cell = cells[posToIndex(self,x,y) or 0]

	local y1 = y-r
	if y1 < 0 then y1 = 0 end
	local y2 = y+r
	if y2 >=height then y2 = height-1 end

	local x1 = x-r
	if x1 < 0 then x1 = 0 end
	local x2 = x+r
	if x2 >=width then x2 = width-1 end

	--print (x1,x2,y1,y2,r)

	local old_len = #_passable_poses
	local len = 0

	local line_idx = posToIndex(self,x1,y1)
	--local cnt = 0
	for y=y1,y2 do

		local idx = line_idx
		for x=x1,x2 do
			local cell = cells[idx]
			if cell and (cell == 1 or cell == this_cell) then
				_passable_poses[len+1] = x
				_passable_poses[len+2] = y
				--print(x,y,cell.passable)
				len = len + 2
			end
			idx = idx +1
			--cnt = cnt + 1
		end
		line_idx = line_idx + width
	end

	for i=len+1,old_len do
		_passable_poses[i] = nil
	end
	--print (len)
	return _passable_poses , len
end

