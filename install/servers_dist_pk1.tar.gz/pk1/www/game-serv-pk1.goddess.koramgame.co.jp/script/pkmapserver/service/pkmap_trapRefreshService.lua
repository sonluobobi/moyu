--[[
场景陷阱刷新系统servuce
author : xingzeng
date : 2012-03-27
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local table = table
local tableInsert = table.insert
local random = math.random
local Time = Time
local TrapRefreshDefs = TrapRefreshDefs

TrapRefreshService = TrapRefreshService or {}

local SceneService, GameObjectService, BufferBaseService, TrapRefreshBaseService

function TrapRefreshService:onAfterLoadLua()
	SceneService = _G.SceneService
	GameObjectService = _G.GameObjectService
	BufferBaseService = _G.BufferBaseService
	TrapRefreshBaseService = _G.TrapRefreshBaseService
end

function TrapRefreshService:createTrapsRefIns(aoi_scene)
	local traps_ref_ins = aoi_scene.traps_ref_ins
	if not traps_ref_ins then
		traps_ref_ins = {}
		traps_ref_ins.ref_last_times = {}
		aoi_scene.traps_ref_ins = traps_ref_ins
	end
	return traps_ref_ins
end

function TrapRefreshService:getTrapsRefIns(character, aoi_scene)
	local aoi_scene = aoi_scene or GameObjectService:getAoiScene(character)
	local traps_ref_ins = aoi_scene.traps_ref_ins
	
	if not traps_ref_ins then
		traps_ref_ins = self:createTrapsRefIns(aoi_scene)
	end
	
	return traps_ref_ins, aoi_scene
end

-- 响应切换场景完成
function TrapRefreshService.onAfterEnterScene(character, scene_base, aoi_scene)
	
end

-- 场景帧事件
function TrapRefreshService:update(time_now, aoi_scene)
	local traps_ref_ins = self:getTrapsRefIns(nil, aoi_scene)
	local scene_base = aoi_scene.scene_base
	
	-- 获取场景内的BUFFER信息
	local trap_ref_bases = TrapRefreshBaseService:getTrapRefreshBase(scene_base.id)
	if not trap_ref_bases then
		return
	end
	
	for _, trap_ref in pairs(trap_ref_bases) do
		self:refTrapRefresh(aoi_scene, traps_ref_ins, scene_base, trap_ref)
	end
	
end

-- 500ms更新事件
function TrapRefreshService:update500ms(time_now, aoi_scene)
	
end

function TrapRefreshService:refTrapRefresh(aoi_scene, traps_ref_ins, scene_base, trap_ref)
	local scene_id = aoi_scene.scene_id
	local ref_per_num = trap_ref.ref_per_num
	if ref_per_num < 1 then
		return
	end
	
	-- 检查各种场景玩法条件
	if not self:enableRefTrapRefresh(aoi_scene, scene_base, trap_ref) then
		return
	end
	
	local is_need_ref = false
	local ref_last_times = traps_ref_ins.ref_last_times
	local cur_time = Time:getSecondsNow()
	
	local ref_last_time = ref_last_times[trap_ref.id] or cur_time
	ref_last_times[trap_ref.id] = ref_last_time
	
	-- 刷新场景内BUFFER掉落物
	if ref_last_time + trap_ref.ref_frequency < cur_time then
		is_need_ref = true
	end

	if is_need_ref then
		local drop_dots = table.lightCopyTableEx(trap_ref.drop_dots, {})
		local trap_ids = table.lightCopyTableEx(trap_ref.trap_ids, {})
		if ref_per_num < 1 or #drop_dots < 1 or #trap_ids < 1 then
			return
		end
		
		for i = 1, ref_per_num do
			-- 随机一个陷阱
			local idx = random(1, #trap_ids)
			local trap_id = trap_ids[idx]
			table.remove(trap_ids, idx)
			
			-- 随机一个范围矩形
			local pos_idx = random(1, #drop_dots)
			local pos = drop_dots[pos_idx]
			table.remove(drop_dots, pos_idx)
			
			-- 添加陷阱
			local trap_base = TrapRefreshBaseService:getTrapRefreshBase(trap_id)
			TrapService:createTrap(aoi_scene, trap_id, pos[1], pos[2], nil)
		end
		
		ref_last_times[trap_ref.id] = Time:getSecondsNow()
	end
end

function TrapRefreshService:enableRefTrapRefresh(aoi_scene, scene_base, trap_ref_base)
	local is_ok = true
	return is_ok
end


