--[[
运营活动系统servuce
author : xingzeng
date : 2014-08-15
]]--

local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local type = type
local opCodes = opCodes
local string_len = string.len
local math_random = math.random
local math_ceil = math.ceil
local OpeActivityDao = OpeActivityDao
local OpeActivityItemDefs = OpeActivityItemDefs
local OpeActivityConfig = OpeActivityConfig
local array = array
local OpeActivityDefs = OpeActivityDefs
local ostime = os.time
local next = next

OpeActivityService = OpeActivityService or {}

local OpeActivityService = OpeActivityService
local GameObjectService
function OpeActivityService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
end

function OpeActivityService:saveActivityItems(area_id, activity_items)
	local area2data = OpeActivityDao.area2data
	area2data[area_id] = {
		activity_items = activity_items,
		drop_activity_itemss = {}
	}
	local drop_activity_itemss = area2data[area_id].drop_activity_itemss
	local rand_drop_cond_confs = OpeActivityConfig.rand_drop_cond_confs
	
	for _, activity_item in pairs(activity_items) do
		local activity_item_sort_id, exchange_special_cond_sort_id = activity_item.activity_item_sort_id, activity_item.exchange_special_cond_sort_id
		if activity_item_sort_id == OpeActivityItemDefs.ACTIVITY_ITEM_SORT_ID_FOR_SPECIAL_CONDITION and
			exchange_special_cond_sort_id == OpeActivityItemDefs.AES_SORT_ID_FOR_RAND_DROP_EQUIP and
			self:checkExpire(activity_item) then
			local drop_cond_id = activity_item.ext_value1
			local drop_cond_conf = rand_drop_cond_confs[drop_cond_id]
			if drop_cond_conf then
				local drop_activity_items = drop_activity_itemss[drop_cond_conf.scene_sort_id] or {}
				drop_activity_itemss[drop_cond_conf.scene_sort_id] = drop_activity_items
				drop_activity_items[#drop_activity_items+1] = activity_item
			end
		end
	end
end

--检查活动是否过期
function OpeActivityService:checkExpire(activity_item)
	local stime, etime = activity_item.c__stime_sec, activity_item.c__etime_sec
	if stime <= 0 or etime <= 0 then
		Logger:error('OpeActivityService:checkExpire stime or etime is <= 0', activity_item)
		return false, errorCodes.OPE_ACTIVITY_ITEM_EXPIRE
	end
	
	local cur_time = ostime()
	if etime > 0 then
		if cur_time < stime then
			return false, errorCodes.OPE_ACTIVITY_ITEM_NO_START, activity_item.start_datetime
		elseif cur_time > etime then
			return false, errorCodes.OPE_ACTIVITY_ITEM_EXPIRE
		end
	end
	
	return true
end

-- 获取掉落道具列表
function OpeActivityService:getDropEquips(area_id, aoi_scene, monster_id)
	local drop_equips = {}
	local scene_id = aoi_scene.scene_id
	
	local ope_act_data = OpeActivityDao.area2data[area_id]
	local drop_activity_itemss = ope_act_data and ope_act_data.drop_activity_itemss or nil
	if not drop_activity_itemss then
		return drop_equips
	end
	
	local scene_base = aoi_scene.scene_base
	local scene_sort_id = scene_base.scene_sort_id
	local activity_items = drop_activity_itemss[scene_sort_id]
	if not activity_items then
		return drop_equips
	end
	
	local SCENE_SORT_ID_OUTDOOR = SceneDefs.SCENE_SORT_ID_OUTDOOR
	local rand_drop_cond_confs = OpeActivityConfig.rand_drop_cond_confs
	for _, activity_item in pairs(activity_items) do
		if self:checkExpire(activity_item) then
			local drop_cond_id = activity_item.ext_value1
			local drop_cond_conf = rand_drop_cond_confs[drop_cond_id]
			if drop_cond_conf then
				local is_ok = true
				
				-- 条件检查
				if drop_cond_conf.scene_id ~= 0 and drop_cond_conf.scene_id ~= scene_id then
					is_ok = false
				end
				
				local dmonster_ids = drop_cond_conf.monster_ids
				if monster_id then
					-- 在野外，支持所有怪掉落
					if scene_sort_id == SCENE_SORT_ID_OUTDOOR then
						if dmonster_ids and not dmonster_ids[monster_id] then
							is_ok = false
						end
					else
						if not dmonster_ids or not dmonster_ids[monster_id] then
							is_ok = false
						end
					end
				else
					if dmonster_ids and next(dmonster_ids) then
						is_ok = false
					end
				end
				
				-- 掉落道具
				if is_ok then
					local arr_add_equip_num
					if activity_item.exchange_reward_sort_id == OpeActivityItemDefs.AER_SORT_ID_FOR_RAND_EQUIP then
						arr_add_equip_num = self:calcRandEquips(activity_item)
					elseif activity_item.exchange_reward_sort_id == OpeActivityItemDefs.AER_SORT_ID_FOR_FIX_EQUIP then
						arr_add_equip_num = activity_item.arr_add_equip_num
					else
						Logger:error('[OpeActivityService:getDropEquips] activity_item.exchange_reward_sort_id is err', activity_item.id, activity_item.exchange_reward_sort_id)
					end
					
					if arr_add_equip_num then
						for equip_id, equip_num in pairs(arr_add_equip_num) do
							drop_equips[equip_id] = (drop_equips[equip_id] or 0) + equip_num
						end
					end
				end
			else
				Logger:error('[OpeActivityService:getDropEquips] drop_cond_conf is nil', activity_item.id, drop_cond_id)
			end
		end
	end
	
	return drop_equips
end

function OpeActivityService:calcRandEquips(activity_item)
	local arr_rand_reward_equips = activity_item.arr_rand_reward_equips
	local reward_equips_randoms = {}
	
	for _, rand_reward_equips in pairs(arr_rand_reward_equips) do
		local reward_equips_random = {}
		for _, reward_conf in pairs(rand_reward_equips.rand_equips) do
			local reward_rand = {
				reward_conf.equip_id, reward_conf.num, reward_conf.rate
			}
			reward_equips_random[#reward_equips_random+1] = reward_rand
		end
		reward_equips_randoms[#reward_equips_randoms+1] = reward_equips_random
	end
		
	local arr_add_equip_num = math.randRewardEquips(reward_equips_randoms, OpeActivityDefs.RAND_REWARD_PROBA_BASE)
	--if not next(arr_add_equip_num) then
	--	Logger:fatal('[rewardHandleRandEquip] arr_add_equip_num is nil', character.id, character.nick, activity_item)
	--end
	return arr_add_equip_num
end
