--[[
劫镖service
author : jinlin.liu
date : 2016-04-12
]]--
local Character = Character
local Time = Time
local isTableEmpty = table.isTableEmpty
local tableInsert = table.insert
local tableSort = table.sort
local sizeTable = table.sizeTable
local tableValues = table.values
local copyTable = table.lightCopyTable
local strLen = string.len
local mergeUInt = external.mergeUInt
local externalSplitUInt=external.splitUInt
local send_error = WorldPacket.m2cSendDebugError
local table_remove = table.remove
local random = math.random
local JieBiaoConfig = JieBiaoConfig
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER

JieBiaoService = JieBiaoService or {}

local JieBiaoService = JieBiaoService
local JieBiaoDao = JieBiaoDao --csv数据
local JieBiaoDefs = JieBiaoDefs
local CounterDefs = CounterDefs
local OutdoorConfig = OutdoorConfig
local Formula = Formula
local CharacterService = CharacterService
local Statics = Statics
local pos_interval = 0
local shangshou_interval = 0
---注：假设 lv也就是初始任务id
--
--
function JieBiaoService:onAfterLoadLua()
  JieBiaoService = _G.JieBiaoService
  JieBiaoDao = JieBiaoDao --csv数据
  JieBiaoDefs = JieBiaoDefs
  CounterDefs = CounterDefs
  OutdoorConfig = OutdoorConfig
  Formula = Formula
  CharacterService = CharacterService
  Statics = Statics
  JieBiaoConfig = JieBiaoConfig
end

--预备开启时间
function JieBiaoService:outPrepareTask(aoi_scene)
  local ctime = Time:getSecondsNow()
  self:prepare_task(aoi_scene,ctime)
end

--取角色劫镖信息
function JieBiaoService:outGetJieBiaoTask(aoi_scene, gcid)  
  local jb = aoi_scene.jiebiao 
  if not jb then return nil end
  
  local level_tasks = aoi_scene.jiebiao.level_tasks
  local type = 0

  if jb.user_list[gcid] and not isTableEmpty(jb.user_list[gcid]) then
    type = jb.user_list[gcid].type or 0
  end 
  
  local jbinfo,lv = JieBiaoService:getCurJbInfo(aoi_scene)  
  if not jbinfo then return nil end
  
  local goddesses = self:getGoddessesDetail(aoi_scene, jb.godids)
  local jbtask=JBTask:new(lv,jbinfo.monster_pos_id,jbinfo.shou_pos_id,jbinfo.gong_pos_id
      ,jbinfo.start_time,goddesses,table.keys(jb.arrive_ids))
  jbtask.type = type  
  jbtask.status =  jbinfo.status
  --table.dump("tttt===================================================",jbtask,6)
  return jbtask
end



--准备下一场数据
function JieBiaoService:prepare_task(aoi_scene,ctime) --初始化模块相关数据
  self:clean_task(aoi_scene)
  local level_tasks = aoi_scene.jiebiao.level_tasks
  local little_map = aoi_scene.jiebiao.little_map
  local goddess = nil
  local begintime = 0
  local jbtask = nil
  local rand_pos = JieBiaoDefs.JB_POS_UP
  local v = JieBiaoService:setSceneLv(aoi_scene) 
  rand_pos = JieBiaoService:getRandomPos()
  local sposid,gposid = JieBiaoService:get_gs_pos(rand_pos)
  --准备女神
  goddess = JieBiaoService:getRandomGoddess(v,JieBiaoDefs.JB_DEFAULT_GODDESS)
  --准备准备开始时间
  begintime = JieBiaoService:getStartTime(v,ctime)
  --准备任务数据    
  jbtask=JBTask:new(v,rand_pos,sposid,gposid,begintime,{})
  aoi_scene.jiebiao.godids = goddess  
  --table.dump("godids",goddess,3)
  jbtask.status = JieBiaoDefs.JB_STATUS_PREPARE
  level_tasks[v] = jbtask    
  
  --增加item，攻守报名方
  local _bospos,shoupos,gongpos = JieBiaoService:getTaskPosIds(aoi_scene)
  local it=nil
  it = SmallMapService:addItem(aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_JOIN_SHOU, shoupos.x, shoupos.y)
  little_map["shou"] = it
  it = SmallMapService:addItem(aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_JOIN_GONG, gongpos.x, gongpos.y)
  little_map["gong"] = it
end

----------------------------------场景相关操作---------------------------------------------
function JieBiaoService:onInitScene(character, aoi_scene)
  aoi_scene.jiebiao = {little_map={},godids={},aoi_map={},godprestatus={},otherbm={},monsters={},curlev=0,
                       user_list={},level_tasks={},arrive_ids={}} --用户数据  
  JieBiaoService:setSceneLv(aoi_scene) --调用lv
  return true
end

-- 玩家进入场景后 
function JieBiaoService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
  local isover,_,_,need_notify = JieBiaoService:isTaskOver(aoi_scene,Time:getSecondsNow() * 1000)
  if not isover then
    JieBiaoService:goddessUpdate(character, aoi_scene)
    JieBiaoService:goddessUpdate(nil, aoi_scene,true)   
    JieBiaoService:sendGoddessUpdate(character, {aoi_ids=need_notify}) 
  end   
end

-- 离开场景时
function JieBiaoService:afterLeaveScene(character, aoi_scene, leave_type)
  JieBiaoService:erasePlayer( character, aoi_scene )
  return true
end


-- 当女神被杀
function JieBiaoService:onKilledMonster(character, arr_kill_monster_aoi_id)
  local aoi_scene = GameObjectService:getAoiScene(character)
  if not aoi_scene then return end
  local monsters = aoi_scene.jiebiao.monsters
  local little_map = aoi_scene.jiebiao.little_map
  local aoi_map = aoi_scene.jiebiao.aoi_map
  for k,aoi_id in pairs(arr_kill_monster_aoi_id) do
    if monsters and aoi_map[aoi_id] and monsters[aoi_map[aoi_id]] then
      if little_map and little_map[aoi_id] then --删除小地图上的点
        SmallMapService:delItem(aoi_scene, little_map[aoi_id])
        little_map[aoi_id] = nil
      end            
      --GameObjectService:delObjByAoiId(aoi_scene, aoi_id) --这里不删，等结束才删
      JieBiaoService:noticeJoinedPids(aoi_scene,OKMsgCodes.JB_GODDESS_KILLED ,{[1]=monsters[aoi_map[aoi_id]].nick,[2]=JieBiaoService:getLiveMonsterNum(aoi_scene)})
      monsters[aoi_map[aoi_id]] = nil
      aoi_scene.jiebiao.godprestatus[aoi_map[aoi_id]] = nil
    end
    
  end  
end

--取死掉和没死掉的monster的id
function JieBiaoService:getMonsterStatus(aoi_scene)
  local godids = aoi_scene.jiebiao.godids
  local monsters = aoi_scene.jiebiao.monsters
  local notdie = {}
  local die = {}
  if godids and monsters then --在monsters里面基本可以确定是没有死掉的
    for k,v in pairs(godids) do
      if monsters[v] and monsters[v].hp>0 then
         notdie[#notdie+1] = v
      else
        die[#die+1] = v   
      end
    end
  end
  return notdie, die
end


function JieBiaoService:getAllArriveIds(aoi_scene,need_notify)
  local arrive_ids = aoi_scene.jiebiao.arrive_ids
  
  for k,v in pairs(need_notify) do
    arrive_ids[v] = true
  end  
  return arrive_ids
end

--通知参加过活动的玩家
function JieBiaoService:noticeJoinedPids(aoi_scene,msg_id,msg_params)
  local gpids = JieBiaoService:getAllJoinedPids(aoi_scene)
  if gpids then
    NoticeService:sysMsgScenePlayers(gpids, msg_id, msg_params)
  end
end

--取在线且加入过玩法的玩家gpid
function JieBiaoService:getAllJoinedPids(aoi_scene)
  local o = {}
  local gcids = JieBiaoService:getAllJoinedRole(aoi_scene)  
  local ch_obj = nil
  
  for k,v in pairs(gcids) do
    ch_obj = CharacterService:getCharacterByGcid(v)
    if ch_obj then o[#o+1] = ch_obj.gpid end
  end  
  return o
end

function JieBiaoService:broadCastFinish(aoi_scene,need_notify)
  local gcids = JieBiaoService:getAllJoinedRole(aoi_scene)
  local type = 0
  local ch_obj =  nil
  local whoWin = JieBiaoService:getWhoWin(aoi_scene)
  local liveNum = JieBiaoService:getLiveMonsterNum(aoi_scene)
  local rewardNum = 0
  local monsters_info = {}
  
  local notdie,die = JieBiaoService:getMonsterStatus(aoi_scene)
  for k,v in pairs(notdie) do
    monsters_info[#monsters_info+1] = {monster_baseid=v,isdead=false}
  end
  
  for k,v in pairs(die) do
    monsters_info[#monsters_info+1] = {monster_baseid=v,isdead=true}
  end  
  local rate = 0
  local rewards = {}
  local reward_params = nil
  
  local total = 0
  local total_rewards = nil
  local arrive_ids = JieBiaoService:getAllArriveIds(aoi_scene,need_notify)
  
  for k,v in pairs(gcids) do
    rewards = {}
    type = JieBiaoService:getJoinType(aoi_scene,v)
    ch_obj = CharacterService:getCharacterByGcid(v)    
    if ch_obj then  
      JieBiaoService:sendGoddessArrived(ch_obj, {aoi_ids=need_notify})
      OutdoorService:resetZhenying(aoi_scene, ch_obj, true)   
      JieBiaoService:sendTaskUpdate(ch_obj, {type=type,status=JieBiaoDefs.JB_STATUS_END,arrived_ids=table.keys(arrive_ids)})
	  SmallMapService:onFinJiebiao( aoi_scene, ch_obj )	
      if type == JieBiaoDefs.JB_TYPE_GONG then --如果是攻
          rewardNum = JieBiaoDefs.JB_DEFAULT_GODDESS-liveNum
          total,total_rewards = JieBiaoService:getTotalRewardCount(aoi_scene,type)
          rate = JieBiaoConfig.gong_reward_rate[rewardNum]
          total = math.floor(rate * total) 
          --增加次数
          local en_counter, counter = CounterService:getEnUseCount(ch_obj,  CounterDefs.COUNTER_BASE_ID_JIEBIAO_GONG)
          total =  math.min(total, en_counter)   
          
          if  total > 0 then
            reward_params  = JieBiaoService:getReward(rate,total_rewards)
            for k1,v1 in pairs(reward_params) do
              rewards[#rewards+1] = {equip_id = k1, num = v1}
            end
          end     
          
          JieBiaoService:sendFinish(ch_obj, {task_id=JieBiaoService:getScenelv(aoi_scene),task_type=type, is_success = whoWin == type ,
                monsters=monsters_info, reward = rewards})
          --print("ggggtotao",total,rate,en_counter)
          if total>0 then   
            CounterService:addcount(ch_obj, counter, nil, total) 
            --发奖励****  
            if  JieBiaoDefs.JB_DEFAULT_GODDESS-liveNum > 0 then
              reward_params["type"] = RewardDefs.REWARD_FROM_MODULE_ID_JB_JS_SUCCESS
              reward_params["goddesnum"] =  JieBiaoDefs.JB_DEFAULT_GODDESS-liveNum
            else
              reward_params["type"] = RewardDefs.REWARD_FROM_MODULE_ID_JB_JS_FAIL
            end
            JieBiaoService:sendReward(ch_obj,reward_params)  
          end      
      end
      
      if type == JieBiaoDefs.JB_TYPE_SHOU then --如果是守
          rewardNum = liveNum
          total,total_rewards = JieBiaoService:getTotalRewardCount(aoi_scene,type)
          rate = JieBiaoConfig.shou_reward_rate[rewardNum]
          total = math.floor(rate * total) 
          --增加次数
          local en_counter, counter = CounterService:getEnUseCount(ch_obj,  CounterDefs.COUNTER_BASE_ID_JIEBIAO_SHOU)
          total =  math.min(total, en_counter)   
          
          if  total > 0 then
            reward_params  = JieBiaoService:getReward(rate,total_rewards)
            for k1,v1 in pairs(reward_params) do
              rewards[#rewards+1] = {equip_id = k1, num = v1}
            end
          end     
          
          JieBiaoService:sendFinish(ch_obj, {task_id=JieBiaoService:getScenelv(aoi_scene),task_type=type, is_success = whoWin == type ,
                monsters=monsters_info, reward = rewards})
          --print("gggsssstotao",total,rate,en_counter)
          if total>0 then   
            CounterService:addcount(ch_obj, counter, nil, total) 
            --发奖励****  
            if  liveNum > 0 then
              reward_params["type"] = RewardDefs.REWARD_FROM_MODULE_ID_JB_HS_SUCCESS
              reward_params["goddesnum"] =  liveNum
            else
              reward_params["type"] = RewardDefs.REWARD_FROM_MODULE_ID_JB_HS_FAIL
            end
            JieBiaoService:sendReward(ch_obj,reward_params)  
          end   
      end
    end        
  end  
end

--取所有可获得的奖励
function JieBiaoService:getReward(rate,total_rewards)
  local rewards = {}
  local num = 0
  for k,v in pairs(total_rewards) do
    num = math.floor(rate * v)
    if num > 0 then
      rewards[k] = num
    end    
  end
  return rewards
end

function JieBiaoService:sendReward(character,reward_params)
  if isTableEmpty(reward_params) then return end
  RewardService:reward(Statics.PK_GAME_TYPE_ID_OUTDOOR_JB_RWD, 0, character.gpid, character.gcid, reward_params)
end

--update周期广播女神到达信息
function JieBiaoService:updateNotice(aoi_scene,need_notify)
  if not isTableEmpty(need_notify) then
    local monsters = aoi_scene.jiebiao.monsters
    local aoi_map = aoi_scene.jiebiao.aoi_map
    local arrive_keys = table.keys(JieBiaoService:getAllArriveIds(aoi_scene,{}))
    local count = #arrive_keys - #need_notify
    if count < 0 then print("count<0出错",#arrive_keys,#need_notify);count = 0 end;
    
    --table.dump("arrive_keys",arrive_keys,5)
    
    if aoi_map and monsters then
      for k,aoi_id in pairs(need_notify) do
        if monsters[aoi_map[aoi_id]] then
          count = count + 1 
          JieBiaoService:noticeJoinedPids(aoi_scene,OKMsgCodes.JB_GODDESS_ARRIVED ,{[1]=monsters[aoi_map[aoi_id]].nick,[2]=count})
        end
      end
    end  
  end
end

-- 场景周期更新
function JieBiaoService:update500ms(now_time_msec, aoi_scene)  
  --检测是否已经结束
  local isover,intimestatus,prestatus,need_notify=JieBiaoService:isTaskOver(aoi_scene,now_time_msec)
  --if pos_interval == JieBiaoDefs.JB_POS_INTERVAL then
  --print(isover,intimestatus,prestatus)
  --end  
  if isover then
    if intimestatus == JieBiaoDefs.JB_STATUS_END and prestatus == JieBiaoDefs.JB_STATUS_BEGIN then
      --结束后改变状态,发送最后的finish消息消息并发奖励，并重置场景
      JieBiaoService:setCurJbStatus(aoi_scene,JieBiaoDefs.JB_STATUS_END)
      --只对场景中的人！
      JieBiaoService:goddessUpdate(nil, aoi_scene)
      JieBiaoService:updateNotice(aoi_scene,need_notify)
      JieBiaoService:broadCastFinish(aoi_scene,need_notify)
      JieBiaoService:clean_task(aoi_scene)
      OutdoorService:onTaskFinish( aoi_scene, OutdoorDefs.OUTDOOR_TASK_TYPE_JEIBIAO )
      return      
    end
    
    --如果之前 已经prepare而且，当前已经到了时间，则开始
    if prestatus and JieBiaoDefs.JB_STATUS_BEGIN == intimestatus and prestatus == JieBiaoDefs.JB_STATUS_PREPARE then
      --设置状态
      JieBiaoService:setCurJbStatus(aoi_scene,JieBiaoDefs.JB_STATUS_BEGIN)
      JieBiaoService:initMonsters(aoi_scene)
      JieBiaoService:goddessUpdate(nil, aoi_scene)
      JieBiaoService:goddessUpdate(nil, aoi_scene,true)
      local bospos = JieBiaoService:getTaskPosIds(aoi_scene)
      local little_map = aoi_scene.jiebiao.little_map
      local shanshou = SmallMapService:addItem(aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_SHANSHUO, bospos.x, bospos.y)
      little_map["shanshou"] = shanshou
      --发送开启消息      
      JieBiaoService:sendUpdate(aoi_scene,JieBiaoDefs.JB_STATUS_BEGIN,true,need_notify)----只对场景中报名人！
      return
    end 
  end
  
  
  if false == isover then --进行中
    --所有小兵检测当前位置是否到了战斗区
    local monsters = aoi_scene.jiebiao.monsters
    local monstersPre = aoi_scene.jiebiao.godprestatus
    local maoi = nil   
    
    JieBiaoService:sendAllRoleGoddessArrived(aoi_scene, need_notify)
    JieBiaoService:updateNotice(aoi_scene,need_notify)
    
    
    for k,v in pairs(monsters) do
      if v and v.hp>0 then 
        maoi = v.aoi_obj
        if JieBiaoService:isInPkcenter(maoi.x,maoi.y) then
          if not monstersPre[maoi.obj_id] then
            monstersPre[maoi.obj_id] =  true
            --为小兵设置速度***
            JieBiaoService:addBuffer(aoi_scene,v)
          end 
        else
          if monstersPre[maoi.obj_id] then
           monstersPre[maoi.obj_id] =  nil
           --为小兵设置速度***
           JieBiaoService:deleteBuffer(aoi_scene,v)
          end  
        end
      end
    end  
    --一秒钟更新一次女神位置
    if pos_interval == JieBiaoDefs.JB_POS_INTERVAL then
      JieBiaoService:goddessUpdate(nil, aoi_scene) --更新女神位置
      pos_interval = pos_interval + 1
    elseif  pos_interval >= JieBiaoDefs.JB_SMALL_MAP_POS_INTERVAL then
      JieBiaoService:goddessUpdate(nil, aoi_scene, true) --更新小地图
      pos_interval = 0
    else
      pos_interval = pos_interval + 1
    end 
    
    if shangshou_interval > JieBiaoDefs.JB_SMALL_MAP_SHANSHOU_INTERVAL then
      local shanshou = aoi_scene.jiebiao.little_map["shanshou"]
      if shanshou then
        SmallMapService:delItem(aoi_scene, shanshou)
        aoi_scene.jiebiao.little_map["shanshou"] = nil
      end
    else
      shangshou_interval = shangshou_interval + 1
    end
        
  end
end


--给女神增加一个buffer
function JieBiaoService:addBuffer(aoi_scene,monster)
  --local buffer_base = BufferBaseService:getBufferBaseById(JieBiaoDefs.JB_BUFFER_ID)
  --local is_ok, is_need_bc = BufferService:addTmpBuffer(monster, buffer_base)
  --if is_ok and is_need_bc then
  -- BufferService:bcBuffers(aoi_scene, monster)
  --end
  --暂时只做减速效果
  local monsterspeed = MotionService:getObjectSpeed( monster )
  MotionService:addRealSpeedByPercent( monster, -JieBiaoConfig.reduce_speed_percent, 999999999,true )
  if aoi_scene.jiebiao and not aoi_scene.jiebiao.speedctrl then aoi_scene.jiebiao.speedctrl = {} end
  if aoi_scene.jiebiao and aoi_scene.jiebiao.speedctrl then
    aoi_scene.jiebiao.speedctrl[monster.id] = monsterspeed
  end
end

--删除一个buffer
function JieBiaoService:deleteBuffer(aoi_scene,monster)
  --return BufferService:delBuffer(monster, JieBiaoDefs.JB_BUFFER_ID, true)  
  --暂时只减速
  --MotionService:resumeSpeed( monster )
  --print("恢复速度",aoi_scene.jiebiao.speedctrl[monster.id],monster.id)
  if aoi_scene.jiebiao and aoi_scene.jiebiao.speedctrl and aoi_scene.jiebiao.speedctrl[monster.id]  then
    MotionService:changeSpeed( monster, aoi_scene.jiebiao.speedctrl[monster.id], 1 , true )
  end  
end

function JieBiaoService:erasePlayer( character, aoi_scene )
  if not aoi_scene.jiebiao.user_list or not aoi_scene.jiebiao.user_list[character.gcid] then return end
  aoi_scene.jiebiao.user_list[character.gcid] = nil 
end


----------------------------------相关逻辑b---------------------------------------------
--报名
function JieBiaoService:join(character,type)
  local typecounter = 0
  local sendtype = 0
  local zhenying = Statics.DEFAULT_ZHENYING_NEUTRAL
  if type == JieBiaoDefs.JB_TYPE_SHOU then 
    typecounter = CounterDefs.COUNTER_BASE_ID_JIEBIAO_SHOU 
    zhenying = Statics.DEFAULT_ZHENYING_SHOU
    sendtype = OKMsgCodes.JB_JOIN_HUSONG 
  elseif type == JieBiaoDefs.JB_TYPE_GONG then
    typecounter = CounterDefs.COUNTER_BASE_ID_JIEBIAO_GONG 
    zhenying = Statics.DEFAULT_ZHENYING_GONG
    sendtype = OKMsgCodes.JB_JOIN_JIEQU 
  else    
    send_error(errorCodes.JB_JOIN_PARAM_ERROR) 
    return
  end
  
  local openlv = OpenFuncDefs.ID_2_VALUE[OpenFuncDefs.ID_FOR_DUOBIAO]
  if openlv > character.level then
    return WorldPacket:m2cSendErr(nil, nil, character.gpid, 
                    errorCodes.JB_JOIN_NEED_LEVEL, {[1] = openlv }) 
  end
  
  local aoi_scene = GameObjectService:getAoiScene(character)
  
  local curstatus =JieBiaoService:getCurJbStatus(aoi_scene)
  if curstatus ~= JieBiaoDefs.JB_STATUS_BEGIN then ----****
    send_error(errorCodes.JB_JOIN_HAS_NOT_START)
    return 
  end
  
  --判断是否已经报过名,这里会涉及到组的问题
  if JieBiaoService:isJoined(aoi_scene,character.gcid) then
    
    if JieBiaoService:isOtherBm(aoi_scene,character.gcid) then 
      send_error(errorCodes.JB_JOIN_HAS_JOINED_BY_OTHER)
    else
      send_error(errorCodes.JB_JOIN_HAS_JOINED)
    end     
    return
  end
  
  local en_counter, counter = CounterService:getEnUseCount(character, typecounter)
  if en_counter <= 0 then    
    send_error(errorCodes.JB_JOIN_TIMES_LIMIT)
    return 
  end
  local joined_gcids = JieBiaoService:realJoin(aoi_scene,character.gcid,type)
  if isTableEmpty(joined_gcids) then return end
  
  local ch_obj = nil  
  for k,v in pairs(joined_gcids) do
    ch_obj = CharacterService:getCharacterByGcid(v)
    if ch_obj then
      --设置陈容
      GameObjectService:updateZhenying(aoi_scene, ch_obj, zhenying, true) 
      JieBiaoService:sendJoin(ch_obj, {type=type})
      WorldPacket:m2cSendCommOkMsg(sendtype)
      --print("sendcommokmsg",sendtype)
      JieBiaoService:goddessUpdate(ch_obj, aoi_scene)
    end
  end
  SmallMapService:onJoinJiebiao( aoi_scene, character )
end
function JieBiaoService:isCanUpdateZhengYing(character)
  local aoi_scene = GameObjectService:getAoiScene(character)
  if JieBiaoService:isJoined(aoi_scene,character.gcid) then
    return false
  else
    return true  
  end
end
function JieBiaoService:checkFight(aoi_scene, attacker, target)
  return true
end

--更新数据
function JieBiaoService:sendUpdate(aoi_scene,status,is_scene_all,need_notify)
    local gcids = {}
    if is_scene_all then
      local chracters = GameObjectService:getPlayerGameObjs(aoi_scene)
      for k,v in pairs(chracters) do
          gcids[#gcids+1] = v.gcid
      end
    else
      gcids = JieBiaoService:getAllJoinedRole(aoi_scene)
    end  
    local type = 0
    local ch_obj =  nil
    local arrive_ids = JieBiaoService:getAllArriveIds(aoi_scene,need_notify)
    
    for k,v in pairs(gcids) do
      type = JieBiaoService:getJoinType(aoi_scene,v)
      ch_obj = CharacterService:getCharacterByGcid(v)
      if ch_obj then JieBiaoService:sendTaskUpdate(ch_obj, {type=type,status=status,arrived_ids=table.keys(arrive_ids)}) end
    end
end

--更新当前女神位置
function JieBiaoService:goddessUpdate(character, aoi_scene, is_smallmap_update)
    local goddes = JieBiaoService:getCurGoddess(aoi_scene)
    if character then
      if not isTableEmpty(goddes) then
        JieBiaoService:sendGoddessUpdate(character, {monsters=goddes})
      end        
    else
      if not isTableEmpty(goddes) then
        local gcids = JieBiaoService:getAllJoinedRole(aoi_scene)
        local ch_obj =  nil
        local little_map = aoi_scene.jiebiao.little_map
         
        if is_smallmap_update and little_map then
          for k,v in pairs(goddes) do
            if little_map[v.aoi_id] then
              --SmallMapService:updateItem(aoi_scene, little_map[v.aoi_id], {x=v.curpos.x,y=v.curpos.y})
              SmallMapService:updateItemPos(aoi_scene, little_map[v.aoi_id], v.curpos.x, v.curpos.y)
            end
          end
        else
          for k,v in pairs(gcids) do
            --type = JieBiaoService:getJoinType(aoi_scene,v)
            ch_obj = CharacterService:getCharacterByGcid(v)
            if ch_obj then
               JieBiaoService:sendGoddessUpdate(ch_obj, {monsters=goddes})            
            end
          end  
        end
      end  
    end  
end

--取当前女神位置信息
function JieBiaoService:getCurGoddess(aoi_scene)
  local jiebiao = aoi_scene.jiebiao
  local monsters = jiebiao.monsters
  local arr = {}
  local maoi = nil
  
  if monsters then
    for k,v in pairs(monsters) do
      if v.hp>0 then 
        maoi = v.aoi_obj
        if maoi then
          arr[#arr+1] = {aoi_id=v.aoi_id,curpos={x=maoi.x, y=maoi.y}}           
        end           
      end 
    end
  end
  return arr
end

--结束任务，清场
function JieBiaoService:clean_task(aoi_scene)
  local jiebiao = aoi_scene.jiebiao
  --删除aoi数据
  for k,v in pairs(jiebiao.monsters) do
    GameObjectService:delObj(v, aoi_scene)
  end
  
  if jiebiao.little_map["shanshou"] then
    SmallMapService:delItem(aoi_scene, jiebiao.little_map["shanshou"])
    jiebiao.little_map["shanshou"]  = nil
  end
  
  if jiebiao.little_map["shou"] then
    SmallMapService:delItem(aoi_scene, jiebiao.little_map["shou"])
    jiebiao.little_map["shou"]  = nil
  end
  if jiebiao.little_map["gong"] then
    SmallMapService:delItem(aoi_scene, jiebiao.little_map["gong"])
    jiebiao.little_map["gong"]  = nil
  end
  
  for k,v in pairs(jiebiao.little_map) do
    SmallMapService:delItem(aoi_scene, v)
  end
  
  jiebiao.monsters = {}
  jiebiao.godids = {}
  jiebiao.user_list = {}
  jiebiao.level_tasks = {}
  jiebiao.otherbm = {}
  jiebiao.godprestatus = {}
  jiebiao.aoi_map = {}
  jiebiao.little_map = {}
  jiebiao.arrive_ids = {}
  jiebiao.speedctrl = {}
  shangshou_interval = 0
  pos_interval = 0
end

--是否已经参加过
function JieBiaoService:isJoined(aoi_scene,gcid)
  local jiebiao = aoi_scene.jiebiao
  if not jiebiao then return false end
  local user_list = jiebiao.user_list
  if not user_list or not user_list[gcid] or not user_list[gcid].type or user_list[gcid].type <= 0 then return false end 
  return true
end

--是否是其它人报名参加
function JieBiaoService:isOtherBm(aoi_scene,gcid)
  local jiebiao = aoi_scene.jiebiao
  local otherbm = jiebiao.otherbm
  if not otherbm or not otherbm[gcid] then return false end 
  return true
end

--取报名类型
function JieBiaoService:getJoinType(aoi_scene,gcid)
  local jiebiao = aoi_scene.jiebiao
  local user_list = jiebiao.user_list
  if not user_list or not user_list[gcid] or user_list[gcid].type <= 0 then return 0 end 
  return user_list[gcid].type
end

--取加入类型
function JieBiaoService:getJoinType(aoi_scene,gcid)
  local jiebiao = aoi_scene.jiebiao
  local user_list = jiebiao.user_list
  if not user_list or not user_list[gcid] or not user_list[gcid].type or user_list[gcid].type <= 0 then return 0 end 
  return user_list[gcid].type
end

--
function JieBiaoService:getGoddessesDetail(aoi_scene, godids)
  local monsters = aoi_scene.jiebiao.monsters
  local oneaoi = nil
  local arr = {}
  local curstatus = JieBiaoService:getCurJbStatus(aoi_scene)
  if curstatus == JieBiaoDefs.JB_STATUS_BEGIN then
    for k,v in pairs(godids) do
       if monsters[v] then
        oneaoi = monsters[v]
        local x,y=oneaoi.aoi_obj.x,oneaoi.aoi_obj.y
        arr[#arr+1] = {aoi_id=oneaoi.aoi_obj.obj_id,curpos={x=x,y=y}}
       end
    end
  end  
  return arr
end

function JieBiaoService:realJoin(aoi_scene,gcid,type)
  local jiebiao = aoi_scene.jiebiao
  local user_list = jiebiao.user_list
  local otherbm = jiebiao.otherbm
  local team = TeamService:getTeamByCid(gcid)
  local joined_gcids = {}
  if false then
    local gcids2gpid = TeamService:getTeamGcid2Gpids(team)
    for v,v2 in pairs(gcids2gpid) do
      user_list[v]={type=type}
      joined_gcids[#joined_gcids+1]=v 
      if v ~= gcid then 
        otherbm[v] = true;               
      end
    end
  else
    user_list[gcid]={type=type}
    joined_gcids[#joined_gcids+1] = gcid
  end
  return joined_gcids
end

function JieBiaoService:getBloodRate(aoi_scene)
  local arr_players = GameObjectService:getGPids(aoi_scene)
  local num = #arr_players or 0
  local target = 0
  --print("场景人数",num)
  for k,v in pairs(JieBiaoConfig.hp_rate_point) do
    if num >=v then target = v end
  end
  
  return JieBiaoConfig.hp_rate[target] or 0.01,num
end

--增加aoi
function JieBiaoService:initMonsters(aoi_scene)
  --判断是否是开启状态如果是就初始化
  local curstatus = JieBiaoService:getCurJbStatus(aoi_scene)
  if curstatus == JieBiaoDefs.JB_STATUS_BEGIN then
    --初始化所有女神
    local jbinfo,lv = JieBiaoService:getCurJbInfo(aoi_scene)
    if not jbinfo then return end
    local taskinfo = aoi_scene.jiebiao.level_tasks[lv]
    local goddessids = aoi_scene.jiebiao.godids --之后会全部被替换
    local aoi_map = aoi_scene.jiebiao.aoi_map or {}
    local monsters = aoi_scene.jiebiao.monsters
    local mo = nil
    local little_map = aoi_scene.jiebiao.little_map
    local lm = 0
    local index = 0
    
    local bloodRate,num1 = JieBiaoService:getBloodRate(aoi_scene)
    num1 = num1 or 1
    
    --print("goddessids",isTableEmpty(goddessids),jbinfo.monster_pos_id)
    --table.dump("goddessids",goddessids,3)
    for k,v in pairs(goddessids) do
      index = index + 1
      local x,y,path = JieBiaoService:getGoddessInitPos(jbinfo.monster_pos_id,index)
      if  x and y and path then 
        mo = MonsterService:dymCreateMonster(aoi_scene, v, aoi_scene.scene_id, x, y, nil, path)
        mo.max_hp = (math.round(mo.max_hp * bloodRate + 0.5) or 1) * num1
        mo.hp = mo.max_hp
        --print("mmmmmmm",mo.max_hp)
        if mo then
          monsters[v] = mo
          GameObjectService:updateZhenying(aoi_scene, mo, Statics.DEFAULT_ZHENYING_SHOU, true)
          aoi_map[mo.aoi_id] = v
          lm = SmallMapService:addItem(aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_GODDESS_POS, x, y)
          little_map[mo.aoi_id] = lm
        end  
      end  
    end
  end
end

--取所有报过名的玩家
function JieBiaoService:getAllJoinedRole(aoi_scene)
  local joined_users = aoi_scene.jiebiao.user_list
  local arr={}
  for k,v in pairs(joined_users) do
    if v.type and v.type > 0 then arr[#arr+1] = k end
  end
  return arr  
end

function JieBiaoService:sendAllRoleGoddessArrived(aoi_scene, notify_goddes)
  if isTableEmpty(notify_goddes) then return end
  
  local gcids = JieBiaoService:getAllJoinedRole(aoi_scene)
  local ch_obj =  nil
  for k,v in pairs(gcids) do
    ch_obj = CharacterService:getCharacterByGcid(v)
    if ch_obj then JieBiaoService:sendGoddessArrived(ch_obj, {aoi_ids=notify_goddes}) end
  end    
end

--只有结束的时候才能调用
function JieBiaoService:getWhoWin(aoi_scene)
  local jiebiao = aoi_scene.jiebiao
  if JieBiaoService:getLiveMonsterNum(aoi_scene) > 0 then return JieBiaoDefs.JB_TYPE_SHOU end
  return JieBiaoDefs.JB_TYPE_GONG
end

do
  --报名
  local rsp_opcode = opCodes.PKM2C_JB_TASK_ACCEPT
  local msg_name = "PackJb.PKM2C_JB_TASK_ACCEPT"
  function JieBiaoService:sendJoin(character, msg_proto)
    --table.dump("PKM2C_JB_TASK_ACCEPT",msg_proto,3)
    if isTableEmpty(msg_proto) then return end
    WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto,nil,character.gpid)
  end
end

do
  --结束
  local rsp_opcode = opCodes.PKM2C_JB_TASK_FINISH
  local msg_name = "PackJb.PKM2C_JB_TASK_FINISH"
  function JieBiaoService:sendFinish(character, msg_proto)
    --table.dump("PKM2C_JB_TASK_FINISH",msg_proto,5)
    if isTableEmpty(msg_proto) then return end
    WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto,nil,character.gpid)
  end
end

do
  --动态更新任务
  local rsp_opcode = opCodes.PKM2C_JB_TASK_UPDATE
  local msg_name = "PackJb.PKM2C_JB_TASK_UPDATE"
  function JieBiaoService:sendTaskUpdate(character, msg_proto)
    --table.dump("PKM2C_JB_TASK_UPDATE",msg_proto,3)
    if isTableEmpty(msg_proto) then return end
    WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto,nil,character.gpid)
  end
end

do
  --动态更新女神
  local rsp_opcode = opCodes.PKM2C_JB_TASK_MONSTER_UPDATE
  local msg_name = "PackJb.PKM2C_JB_TASK_MONSTER_UPDATE"
  function JieBiaoService:sendGoddessUpdate(character, msg_proto)
    --table.dump("PKM2C_JB_TASK_MONSTER_UPDATE",msg_proto,5)
    if isTableEmpty(msg_proto) then return end    
    WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto,nil,character.gpid)
  end
end


do
  --女神到达终点
  local rsp_opcode = opCodes.PKM2C_JB_MONSTER_ARRIVED
  local msg_name = "PackJb.PKM2C_JB_MONSTER_ARRIVED"
  function JieBiaoService:sendGoddessArrived(character, msg_proto)
    --table.dump("PKM2C_JB_MONSTER_ARRIVED",msg_proto,3)
    if isTableEmpty(msg_proto) then return end
    WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto,nil,character.gpid)
  end
end

----------------------------------相关逻辑e---------------------------------------------



----------------------------------相关工具类b---------------------------------------------

--随机女神起始位置
function JieBiaoService:getRandomPos()
  return random(JieBiaoDefs.JB_POS_DOWN,JieBiaoDefs.JB_POS_LEFT)  
end

--随机几个女神
function JieBiaoService:getRandomGoddess(lev,num)
  local data = JieBiaoDao.data
  if nil == data[lev] or nil == data[lev].monster_ids then return {} end
  local monster_ids=data[lev].monster_ids -- {{},{},{},{},{}}
  local arr = {}
  for k,v in pairs(monster_ids) do
    if num <= 0 then break end
    local d = math.randExtract(v, 1)
    if d and #d>0 then
      arr[#arr+1] = d[1]
      num = num - 1
    else
      break
    end  
  end   
  return arr  
end

--取间隔时间
function JieBiaoService:getStartTime(lev,preparetime)
  local data = JieBiaoDao.data
  if nil == data[lev] or nil == data[lev].interval then return JieBiaoDefs.JB_DEFAULT_PREPARE_TIME+preparetime end
  return data[lev].interval+preparetime
end

--当前场景的等级
function JieBiaoService:setSceneLv(aoi_scene)
  local lay_conf = OutdoorConfig.lay_conf
  local monster_pos_conf = OutdoorConfig.monster_pos_conf

  -- 获取当前所有的层级
  local space_id = aoi_scene.space_id
  local layer = OutdoorDao.spaceid_2_layer[space_id]  
  aoi_scene.jiebiao.curlev = layer
  return layer
end

--取场景等级
function JieBiaoService:getScenelv(aoi_scene)
  return aoi_scene.jiebiao.curlev
end

function JieBiaoService:get_gs_pos(godpos)
  local sposid = 0
  local gposid = 0
  sposid=(godpos+1) % 4
  gposid=(godpos+3) % 4
  if sposid == 0 then 
    sposid = 4
  end
  if  gposid == 0 then
    gposid = 4
  end 
  --print("gggggg",sposid,gposid)
  return sposid,gposid
end

--设置当前状态
function JieBiaoService:setCurJbStatus(aoi_scene,status)
  local lv = self:getScenelv(aoi_scene)
  local level_tasks = aoi_scene.jiebiao.level_tasks
  
  if not level_tasks or not level_tasks[lv] then return  end
  level_tasks[lv].status = status  
end

--取当前状态
function JieBiaoService:getCurJbStatus(aoi_scene)
  local lv = self:getScenelv(aoi_scene)
  local level_tasks = aoi_scene.jiebiao.level_tasks
  
  if not level_tasks or not level_tasks[lv] then return JieBiaoDefs.JB_STATUS_BEFORE_PREPARE,lv end
  if isTableEmpty(level_tasks[lv]) then return JieBiaoDefs.JB_STATUS_BEFORE_PREPARE,lv end
  return level_tasks[lv].status,lv
end

--取当前场景中jb数据
function JieBiaoService:getCurJbInfo(aoi_scene)
  local lv = self:getScenelv(aoi_scene)
  local level_tasks = aoi_scene.jiebiao.level_tasks
  
  if not level_tasks or not level_tasks[lv] then return nil end
  if isTableEmpty(level_tasks[lv]) then return nil end
  return level_tasks[lv],lv
end

--取女神的初始位置信息,
function JieBiaoService:getGoddessInitPos(mappos,index)
  local jiebiao=OutdoorConfig.jiebiao
  local indexn = (index * 0.01) + 1 -- 偏移
  if not jiebiao[mappos] or isTableEmpty(jiebiao[mappos]) then return nil end
  
  --取路径数据
  local onepath = jiebiao[mappos]  
  local newpath = {}
  
  --print("neeeee",index,indexn)
  --table.dump("prepos:",onepath,5)
  
  --处理叠加问题
  for k,v in pairs(onepath) do
    if v and v[1] and v[2] then
      newpath[#newpath + 1] = {v[1]*indexn, v[2]*indexn}
    end
  end
  
  --table.dump("nowpos:",newpath,5)
  
  return newpath[1][1], newpath[1][2],newpath
end

--取女神的终点位置信息
function JieBiaoService:getGoddessEndPos(mappos,index)
  local jiebiao=OutdoorConfig.jiebiao
  if not jiebiao[mappos] or isTableEmpty(jiebiao[mappos]) then return nil end
  local indexn = (index * 0.01) + 1 -- 偏移
  --取路径数据
  local onepath = jiebiao[mappos]  
  local length = #onepath
  return onepath[length][1]*indexn, onepath[length][2]*indexn
end

--判断x,y是否到了pos的 deviation个像素的矩形范围内
function JieBiaoService:isInRectangle(x,y,x2,y2,deviation)
  return x>x2-deviation and x<x2+deviation and y>y2-deviation and y<y2+deviation
end

--当前是可开启时间
function JieBiaoService:isCanJoinTime(Ms,aoi_scene)
  local cursec = Ms / 1000
  local jbinfo=JieBiaoService:getCurJbInfo(aoi_scene)
  if not jbinfo then return false end
  --print("sttt",jbinfo.start_time,cursec)
  if jbinfo.start_time and jbinfo.start_time < cursec then return true end
  return false  
end

--实时状态
--返回是否结束，最新状态，[之前状态]
function JieBiaoService:isTaskOver(aoi_scene,Ms)
  --检测当前状态,
  local curstatus,lv = JieBiaoService:getCurJbStatus(aoi_scene)
  local need_notify_client = {}
  
  if curstatus == JieBiaoDefs.JB_STATUS_BEGIN then
    --检测小兵是不是全死了，或者小兵是不是全到了  monsterBase = monster.monster_base
    local monsters = aoi_scene.jiebiao.monsters
    local godids = aoi_scene.jiebiao.godids
    local liveCount = 0
    local NotArriveCount = 0
    local maoi = nil
    local x,y
    local index = 0
    local one_monster = nil
    local jinfo = JieBiaoService:getCurJbInfo(aoi_scene)
    local arrive_ids = aoi_scene.jiebiao.arrive_ids --索引    
    
    for k,v in pairs(godids) do   
      index = index + 1   
      one_monster =  monsters[v]  
      if one_monster and one_monster.hp>0 then 
        liveCount=liveCount+1 
        maoi = one_monster.aoi_obj
        x, y = JieBiaoService:getGoddessEndPos(jinfo.monster_pos_id,index)
        --print(x,y,maoi.x,maoi.y,0.1*index)
        if not JieBiaoService:isInRectangle(x,y,maoi.x,maoi.y,1) then  -- 1m的范围内
          NotArriveCount = NotArriveCount + 1
        else
          --这里需要暂停小怪
          if not arrive_ids[one_monster.aoi_id] then
            MonsterAiService:toIdleState(one_monster)  
            one_monster.tmps.allow_move_time = 99999999999
            need_notify_client[#need_notify_client+1] = one_monster.aoi_id    
            arrive_ids[one_monster.aoi_id] = true       
          end
        end          
      end     
    end
    local jinfo,lv = JieBiaoService:getCurJbInfo(aoi_scene)
    --print("NotArriveCount",NotArriveCount,lv)
    
    --table.dump("jinfo",jinfo,3)
    if NotArriveCount > 0 then return false,JieBiaoDefs.JB_STATUS_BEGIN,curstatus, need_notify_client end
    return true,JieBiaoDefs.JB_STATUS_END,curstatus,need_notify_client
  else
    --如果curstatus是prepare，而开始时间已经到了，则返回最新状态和之前状态
    if curstatus == JieBiaoDefs.JB_STATUS_PREPARE and JieBiaoService:isCanJoinTime(Ms,aoi_scene) then
      return true,JieBiaoDefs.JB_STATUS_BEGIN,curstatus,need_notify_client
    else
      return true,curstatus,curstatus,need_notify_client
    end
  end
  
end

--看是否要pk中心区域
function JieBiaoService:isInPkcenter(x,y)
  local center_pos=OutdoorConfig.pk_area_circle_center_pos
  local dis = Formula:distance(x, y, center_pos[1], center_pos[2])
  if dis < OutdoorConfig.pk_area_circle_R then return true end
  return false
end

--取活着的女神个数
function JieBiaoService:getLiveMonsterNum(aoi_scene)
  local monsters = aoi_scene.jiebiao.monsters
  local liveCount=0
  for k,v in pairs(monsters) do
    if v.hp>0 then 
      liveCount=liveCount+1               
    end     
  end
  return liveCount
end

--取某个类型的奖励数
function JieBiaoService:getTotalRewardCount(aoi_scene,Type)
  local lv = JieBiaoService:getScenelv(aoi_scene)
  local reward = nil
  local reward_countid = nil
  if Type == JieBiaoDefs.JB_TYPE_SHOU then
    if JieBiaoDao.data[lv] then
      reward = JieBiaoDao.data[lv].reward
      reward_countid = JieBiaoDao.data[lv].shoucount
      if reward and reward_countid and reward[1] then
        return reward[1][reward_countid], reward[1]
      end
    end
  end 
  
  if Type == JieBiaoDefs.JB_TYPE_GONG then
    if JieBiaoDao.data[lv] then
      reward = JieBiaoDao.data[lv].reward
      reward_countid = JieBiaoDao.data[lv].gongcount
      if reward and reward_countid and reward[2] then
        return reward[2][reward_countid], reward[2] 
      end
    end
  end 
  return 0
end

--不保证安全，只能在任务开始后才正确
function JieBiaoService:getTaskPosIds(aoi_scene)
  local jbinfo = JieBiaoService:getCurJbInfo(aoi_scene)
  return JieBiaoService:getSmallMapPos(aoi_scene,jbinfo.monster_pos_id,jbinfo.shou_pos_id,jbinfo.gong_pos_id)
end

--返回boss的位置id，shou的位置id,攻的位置id
function JieBiaoService:getSmallMapPos(aoi_scene, boss_posid, shou_posid,gong_posid)
  return LinweiTaskConfig.CENTER_POS[boss_posid],LinweiTaskConfig.CENTER_POS[shou_posid],LinweiTaskConfig.CENTER_POS[gong_posid]
end

--该场景是否有劫镖任务
function JieBiaoService:isHasJbTask(aoi_scene)
  local lv = JieBiaoService:getScenelv(aoi_scene)
  if JieBiaoDao.data[lv] then return true end
  return false
end

--取运镖攻守位置
function JieBiaoService:getGongShouPosId(aoi_scene)
  local jbinfo = JieBiaoService:getCurJbInfo(aoi_scene)
  if jbinfo then return jbinfo.gong_pos_id,jbinfo.shou_pos_id end
  Logger:info('getCurJbInfo为空出错!,默认返回了1,3，请检查')
  return 1,3
end

--local aoi_scene = GameObjectService:getAoiScene(fighter)
function JieBiaoService:isCanAttack(fighter,targeter)
  local aoi_scene = GameObjectService:getAoiScene(targeter)
  if  (not aoi_scene.outdoor) or (aoi_scene.outdoor.task_type ~= OutdoorDefs.OUTDOOR_TASK_TYPE_JEIBIAO) then return true end
  
  --print("targeter.aoi_type == aoi_type_player",targeter.aoi_type == aoi_type_player,fighter.aoi_type,targeter.aoi_type, aoi_type_player,aoi_type_monster)
  if fighter.aoi_type == aoi_type_monster then --攻击者是怪物
    if targeter.aoi_type == aoi_type_monster then 
      return true 
    end
    --目标不是怪物
    if targeter.aoi_type == aoi_type_player then
      if not JieBiaoService:isCanAttackReal(aoi_scene,fighter,false,targeter,true) then return false end
    elseif targeter.parent_aoi_id and targeter.parent_aoi_id > 0 then
      local character = GameObjectService:getGameObjectByAoiId(aoi_scene, targeter.parent_aoi_id)
      if not JieBiaoService:isCanAttackReal(aoi_scene,fighter,false,character,true) then return false end
    else
      print("其它状态",fighter.aoi_type)
      return true
    end  
    return true    
  else --攻击者不是怪物
    if fighter.aoi_type == aoi_type_player then --攻击者是人类
      local isHumen = false 
      local character = targeter
      if targeter.aoi_type==aoi_type_player then
        isHumen = true
      elseif targeter.parent_aoi_id and targeter.parent_aoi_id > 0 then
        isHumen = true
        character = GameObjectService:getGameObjectByAoiId(aoi_scene, targeter.parent_aoi_id)
      end  
      if not JieBiaoService:isCanAttackReal(aoi_scene,fighter,true,character,isHumen) then return false end
    elseif fighter.parent_aoi_id and fighter.parent_aoi_id > 0 then --攻击者的小兵攻击
      local character = GameObjectService:getGameObjectByAoiId(aoi_scene, fighter.parent_aoi_id)
      local character2 = targeter
      local isHumen = false
      if targeter.aoi_type==aoi_type_player then
        isHumen = true
      elseif targeter.parent_aoi_id and targeter.parent_aoi_id > 0 then
        isHumen = true
        character2 = GameObjectService:getGameObjectByAoiId(aoi_scene, targeter.parent_aoi_id)
      end 
      if not JieBiaoService:isCanAttackReal(aoi_scene,character,true,character2,isHumen) then return false end
    else  -- 攻击者非召唤兽或幻兽、非玩家
      local isHumen = false
      local character = targeter
      if targeter.aoi_type==aoi_type_player then
        isHumen = true
        if not JieBiaoService:isCanAttackReal(aoi_scene,fighter,false,targeter,isHumen) then return false end
      elseif targeter.parent_aoi_id and targeter.parent_aoi_id > 0 then
        isHumen = true
        character = GameObjectService:getGameObjectByAoiId(aoi_scene, targeter.parent_aoi_id)
        if not JieBiaoService:isCanAttackReal(aoi_scene,fighter,false,character,isHumen) then return false end
      end       
      return true
    end      
  end  
  return true
end

--取是否可以被攻击
--按target是女神或者是人
function JieBiaoService:isCanAttackReal(aoi_scene,fighter,fighter_ishumen,target,target_ishumen)
  if not target then
    return true
  end
  --print("isCanAttack=====",fighter_ishumen,fighter.aoi_id,target_ishumen)
  if not aoi_scene.jiebiao or not aoi_scene.jiebiao.monsters then return true end
  local monsters = aoi_scene.jiebiao.monsters
  local monstersPre = aoi_scene.jiebiao.godprestatus
  local aoi_map = aoi_scene.jiebiao.aoi_map
  
  if fighter_ishumen  then
    local fighter_jt = JieBiaoService:getJoinType(aoi_scene,fighter.gcid)
    if target_ishumen then --都是人类，必须是参加活动的人才行
      local target_jt = JieBiaoService:getJoinType(aoi_scene,target.gcid)    
        
      --有一个未参加活动不可攻击
      if math.min(target_jt,fighter_jt)<=0 and math.max(target_jt,fighter_jt)>0 then 
        return false 
      else --两个都参加或者两个都没参加
        if target_jt > 0 and fighter_jt>0  then 
          if target_jt == fighter_jt then
            return false
          else --不同陈容
            return true
          end
        else --两个都没参加返回true
            return true          
        end       
      end
    else 
        --攻击者是人类，但被攻击者不是人类,如果被攻击者是女神且在不在安全区，则return true
        local aoi_id = target.aoi_id
        
        if fighter_jt == JieBiaoDefs.JB_TYPE_GONG then 
          if aoi_map[aoi_id] and monsters[aoi_map[aoi_id]].aoi_obj  then
            local obj = monsters[aoi_map[aoi_id]].aoi_obj 
            if monstersPre[obj.obj_id] then return true end --在pk区则可以攻击
            --print("return fals2e!!!")
            return false
          else                        
            return false
          end  
        else --不是攻 
           if fighter_jt == JieBiaoDefs.JB_TYPE_SHOU then --守状态不允许被攻击
              return false
            else  --普通用户不允许攻击女神
              if aoi_map[aoi_id] and monsters[aoi_map[aoi_id]].aoi_obj  then     
                return false
              else            
                return true
              end
            end   
        end
    end
  else --攻击者非人类，被攻击者可能是人类或者非人类  
    local aoi_id = target.aoi_id
    if target_ishumen then --目标是人类
      local target_jt = JieBiaoService:getJoinType(aoi_scene,target.gcid)
      if target_jt > 0 then 
        --print("return 怪物打人了 false!!!")
        return false
      else --未报名返回true
        --print("return 未报名可以打 true!!!") 
        return true   
      end
    else --目标不是人类
     -- print("target不是人类，默认返回true")
      return true 
    end
  end
  return true  
end




----------------------------------相关工具类e---------------------------------------------

