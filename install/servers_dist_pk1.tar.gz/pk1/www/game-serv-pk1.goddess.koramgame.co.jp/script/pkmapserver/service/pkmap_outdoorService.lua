--[[
野外场景 service
author : xingzeng.jiang
date : 2014-07-15
--]]

local Formula = Formula
local OutdoorConfig = OutdoorConfig
local OutdoorDefs = OutdoorDefs
local Statics = Statics
local AoiObjectType = AoiObjectType
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local TransferDotDefs = TransferDotDefs
local table = table

OutdoorService = OutdoorService or {}
setmetatable(OutdoorService, SceneServiceInterface)

local SceneService = SceneService
function OutdoorService:onAfterLoadLua()
	SceneService = _G.SceneService
	OutdoorConfig = _G.OutdoorConfig
end

function OutdoorService:checkEnterScene(character, aoi_scene, dst_scene_base)
	-- 从普通场景才能进入野外
	--if not SceneDefs:isNormalScene(aoi_scene.scene_base) then
	--	return false, 
	--end
	 
	return true
end

function OutdoorService:checkLeaveScene(character, aoi_scene)
	return true
end

function OutdoorService:onInitScene(character, aoi_scene)
	aoi_scene.outdoor = {}	--与野外相关内容

	-- 默认场景初始化
	SceneService:onInitSceneDefault(character, aoi_scene)
	-- 初始化临危任务
	LinweiTaskService:onInitScene(character, aoi_scene)
	-- 初始化野外怪物
	OutdoorService:initMonster( aoi_scene )
	--初始化劫镖活动场景
	JieBiaoService:onInitScene(character, aoi_scene)

	-- 首先开启临危任务
	aoi_scene.outdoor.task_type = OutdoorDefs.OUTDOOR_TASK_TYPE_LINWEI
	LinweiTaskService:startAfter( aoi_scene, 10 )	
--	self:startJiebiao(aoi_scene)
	return true
end

function OutdoorService:onTaskFinish( aoi_scene, outdoor_task_type )
	local outdoor = aoi_scene.outdoor
	if Config.VOUCH_AREA_CODE == 2078901 and Language:isCN() then 
		local _20dianSec = Time:get02newSec()
		if _20dianSec >= 21 * 60 * 60 and _20dianSec < 23 * 60 * 60 or 
		   _20dianSec >= 15 * 60 * 60 and _20dianSec < 15 * 60 * 60 + 30 * 60 then 
			if JieBiaoService:isHasJbTask(aoi_scene) then 
				OutdoorService:startJiebiao( aoi_scene, true )
			else
				OutdoorService:startLinwei( aoi_scene, true )
			end
			return 
		else
			OutdoorService:startLinwei( aoi_scene, true )
			return 
		end
	end

	if outdoor_task_type == OutdoorDefs.OUTDOOR_TASK_TYPE_LINWEI then 
		if JieBiaoService:isHasJbTask(aoi_scene) and OpenFuncDefs.ID_2_VALUE[OpenFuncDefs.ID_FOR_DUOBIAO] ~= 999 then 
			OutdoorService:startJiebiao( aoi_scene, true )
		else
			OutdoorService:startLinwei( aoi_scene, true )
		end

	elseif outdoor_task_type == OutdoorDefs.OUTDOOR_TASK_TYPE_JEIBIAO then
		OutdoorService:startLinwei( aoi_scene, true )
	else
		assert(false)
	end
end

function OutdoorService:startLinwei( aoi_scene, is_broad_cast )
	local outdoor = aoi_scene.outdoor
	outdoor.task_type = OutdoorDefs.OUTDOOR_TASK_TYPE_LINWEI
	LinweiTaskService:startAfter( aoi_scene, 60 )	
	-- 广播
	if is_broad_cast then
		local task = {}
		task.task_type = outdoor.task_type
		task.linwei = LinweiTaskService:getTask(aoi_scene)  
		self:sendOutdoorTaskInfo(aoi_scene, nil, task)	
	end
end

function OutdoorService:startJiebiao( aoi_scene, is_broad_cast )
	local outdoor = aoi_scene.outdoor
	outdoor.task_type = OutdoorDefs.OUTDOOR_TASK_TYPE_JEIBIAO
	JieBiaoService:outPrepareTask(aoi_scene)
	-- 广播
	if is_broad_cast then
		local task = {}
		task.task_type = outdoor.task_type
		task.jiebiao = JieBiaoService:outGetJieBiaoTask(aoi_scene, 0) 
		self:sendOutdoorTaskInfo(aoi_scene, nil, task)	
	end
end


-- 获取复活点
-- return 	bool:is_back_to_mcity,	true:回到主城，false:本场景复活
--			x, y					本场景复活的X，Y坐标点
do
	local xiangxian_2_transferid = {
		[20005] = {
			[1] = {[1] = 900112, [2] = 900115},	-- 1, 1 左下角, 1, 2 左上角
			[2] = {[1] = 900113, [2] = 900114},	-- 2, 1 右下角, 2, 2 右上角
		},
		[20009] = {
			[1] = {[1] = 900212, [2] = 900215},	-- 1, 1 左下角, 1, 2 左上角
			[2] = {[1] = 900213, [2] = 900214},	-- 2, 1 右下角, 2, 2 右上角			
		},	
	}
	function OutdoorService:getRelivePos(character, aoi_scene)
		local center_pos = OutdoorConfig.center_pos
		local x_dir = character.x > center_pos.x and 2 or 1
		local y_dir = character.y > center_pos.y and 2 or 1
		local transfer_base_id = xiangxian_2_transferid[aoi_scene.scene_id][x_dir][y_dir]
		local x, y  = SceneAoiService:getRandomTransferIn( aoi_scene.scene_id, transfer_base_id )
		return false, x, y
	end
end

-- 当怪物被杀
-- character 	击杀者
-- monsters		被杀怪物数组
do
	function OutdoorService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
		-- 临危怪物被杀的逻辑
		LinweiTaskService:onKilledMonster(character, arr_kill_monster_aoi_id)
		JieBiaoService:onKilledMonster(character, arr_kill_monster_aoi_id)
	end
end

function OutdoorService:onPlayerHarm(fighter, arr_character_harm)
	if fighter.aoi_type == aoi_type_player then
		SafeModeService:onPlayerHarm(fighter, arr_character_harm)
	end
end

-- 当怪物受伤害
-- arr_kill_monster_aoi_id {aoi_id=harm, ....}
function OutdoorService:onMonsterHarm(character, arr_kill_monster_aoi_id)
	LinweiTaskService:onMonsterHarm(character, arr_kill_monster_aoi_id)
end

-- 当NPC被杀
function OutdoorService:onNpcKilled(fighter, arr_kill_guard_npc_aoi_id)
	LinweiTaskService:onNpcKilled(fighter, arr_kill_guard_npc_aoi_id)
end

-- 当玩家被杀
function OutdoorService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
	LinweiTaskService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
	
	-- 红名 
	RednameService:onPlayerKilled(fighter, arr_kill_player_aoi_id)

	-- 通知成就系统
	AchieveService:onCheckAchieve(fighter, AchieveDefs.ACHIEVE_SORT_ID_CNT_KILL, table.sizeTable(arr_kill_player_aoi_id))
end

function OutdoorService:update(now_time_msec, aoi_scene)
end

-- 每500毫秒更新
function OutdoorService:update500ms(now_time_msec, aoi_scene )
	-- 临危任务更新
	LinweiTaskService:update500ms(now_time_msec, aoi_scene)
	JieBiaoService:update500ms(now_time_msec, aoi_scene)

	if Time.is_5s_start then	

		-- 临危BOSS怪
		local linwei_task = LinweiTaskService:getSceneLinweiTask(aoi_scene)
		local boss_aoi_id = linwei_task and linwei_task.base_task and linwei_task.base_task.boss_monster_aoi_id
		if boss_aoi_id then 
			local boss_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, boss_aoi_id)
			if boss_obj then
				local update_data = {
					hp = boss_obj.hp
				}
				SceneService:sendAppearUpdate(aoi_scene, boss_obj, update_data)
			end			
		end
	end	

	-- 任务切换
	local outdoor = aoi_scene.outdoor

end

-- 每500毫秒更新
function OutdoorService:updateForNoPlayer(now_time_msec, aoi_scene )
	LinweiTaskService:update500ms(now_time_msec, aoi_scene)
end

function OutdoorService:beforeEnterScene(character, aoi_scene)
	character.x = 24
	character.y = 25
	return true
end

-- 离开场景时
function OutdoorService:afterLeaveScene(character, aoi_scene, leave_type)
	LinweiTaskService:afterLeaveScene(character, aoi_scene, leave_type)
	JieBiaoService:afterLeaveScene(character, aoi_scene, leave_type)
end

function OutdoorService:checkFight(aoi_scene, attacker, target)
  return true
end

-- 设置阵营
function OutdoorService:setZhenying(aoi_scene, character)
	self:setZhenyingDefault(aoi_scene, character)
end


-- 重置阵营
function OutdoorService:resetZhenying(aoi_scene, character, is_send)
	self:setZhenyingDefault(aoi_scene, character, is_send)
end

function OutdoorService:setZhenyingDefault(aoi_scene, character, is_send)
	local team = TeamService:getTeamByCid(character.gcid)
	local center_pos, r = OutdoorConfig.pk_area_circle_center_pos, OutdoorConfig.pk_area_circle_R
	local zhenying
	
	local aoi_obj = character.aoi_obj
	if Formula:isNearbyDistance(center_pos[1], center_pos[2], aoi_obj.x, aoi_obj.y, r) then
		zhenying = team and Utils.getZhenYingId(team.id) or -1 * aoi_obj.obj_id
	else
		zhenying = Statics.DEFAULT_ZHENYING_NEUTRAL		--中立阵营
	end
	
	GameObjectService:updateZhenying(aoi_scene, character, zhenying, is_send)
end

do
local scene_id_2_pos_2_birth_point = 
{
	[20005] = {[1] =900104, [2] = 900105, [3] = 900106, [4] = 900107},
	[20009] = {[1] =900204, [2] = 900205, [3] = 900206, [4] = 900207},
}
function OutdoorService:getBirthPos(aoi_scene, character)
	local team = TeamService:getTeamByCid(character.gcid)
	local member_num = team and team.member_num or 1
	local outdoor = aoi_scene.outdoor
	local task_type = outdoor.task_type
	if task_type == OutdoorDefs.OUTDOOR_TASK_TYPE_LINWEI then 
		-- 临危任务中
		if member_num <= 1 and LinweiTaskService:isCanJoinTask(character) then 
			local task_pos = nil	
			if LinweiTaskService:isInLinweiTask( aoi_scene ) then
				local linwei_task = LinweiTaskService:getSceneLinweiTask( aoi_scene )
				task_pos = linwei_task.task_pos
			else
				task_pos = LinweiTaskService:genNextTaskPos(aoi_scene)
			end
			local scene_id = aoi_scene.scene_id
			local transfer_base_id = scene_id_2_pos_2_birth_point[scene_id][task_pos]
			local x, y = SceneAoiService:getRandomTransferIn( scene_id, transfer_base_id )
			return true, x, y
		else
			if team then
				local arr, n = SceneAoiService:getTransfersForSortId(aoi_scene.scene_id, TransferDotDefs.TRANSFER_SORT_ID_IN_NORMAL)
				local sceneaoi = arr[team.id%n + 1]
				return true, sceneaoi.x, sceneaoi.y
			end
			return false
		end		

	else
		-- 劫镖任务中
		local jiebiao_pos = JieBiaoService:getGongShouPosId(aoi_scene)
		local jiebiao_pos_radius = (jiebiao_pos+1) % 2
		local random_radius = math.random(1, 2) - 1
		local random_pos = random_radius * 2 + jiebiao_pos_radius
		if random_pos == 0 then random_pos = 4 end
		local scene_id = aoi_scene.scene_id
		local transfer_base_id = scene_id_2_pos_2_birth_point[scene_id][random_pos]
		local x, y = SceneAoiService:getRandomTransferIn( scene_id, transfer_base_id )
		return true, x, y		
	end

end
end

-- 进入场景之后
function OutdoorService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	local task_type = aoi_scene.outdoor.task_type
	if task_type == OutdoorDefs.OUTDOOR_TASK_TYPE_LINWEI then 
		local task = {}
		task.task_type = task_type
		task.linwei = LinweiTaskService:getTask( aoi_scene)
		self:sendOutdoorTaskInfo(aoi_scene, character, task)
	elseif task_type == OutdoorDefs.OUTDOOR_TASK_TYPE_JEIBIAO then
		local task = {}
		task.task_type = task_type
		task.jiebiao = JieBiaoService:outGetJieBiaoTask(aoi_scene, character.gcid)  
		self:sendOutdoorTaskInfo(aoi_scene, character, task)
	else
		assert(false)
	end

	LinweiTaskService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	JieBiaoService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
end

-- 判断玩家是否在野外
function OutdoorService:isInOutdoor( scene_base_id )
	return scene_base_id == 20005 or scene_base_id == 20009
end

-- base发过来的房间列表
function OutdoorService:b2m_syncRoom( _, datas )
	local spaceid_2_layer = {}
	OutdoorDao.spaceid_2_layer = spaceid_2_layer
	OutdoorDao.lays_rooms = datas
	for layer, rooms in pairs(datas) do
		for _, space_id in pairs(rooms) do
			spaceid_2_layer[space_id] = layer
		end
	end
end

-- 设置玩法数据
function OutdoorService:initWanfaAoiData(character, aoi_scene)
	local safe_mode_info = character.safe_mode_info
	local redname_status = RednameService:getRednameStatus(safe_mode_info.redname)
	WanfaAoiService:setWanfaAoiData(character, 'redname_status', redname_status)
	WanfaAoiService:setWanfaAoiData(character, 'safe_mode', safe_mode_info.safe_mode)
end

-- 为野外生成怪物
function OutdoorService:initMonster( aoi_scene )
	local lay_conf = OutdoorConfig.lay_conf
	local monster_pos_conf = OutdoorConfig.monster_pos_conf

	-- 获取当前所有的层级
	local space_id = aoi_scene.space_id
	local layer = OutdoorDao.spaceid_2_layer[space_id]
	local this_layer_conf = lay_conf[layer]
	local monsters = this_layer_conf.monsters
	local positions = ScenePositionDao:getScenePosByType(this_layer_conf.scene_id, ScenePositionDefs.SCENE_POSITION_TYPE_MONSTER)
	if positions then 
		for _, position_base in pairs(positions) do
			local x = position_base.x
			local y = position_base.y
			local direction = position_base.direction
			local value = position_base.value
			local monster_id = monsters[value]
			if monster_id then
				MonsterService:dymCreateMonster(aoi_scene, monster_id, nil, x, y, direction)
			end
		end
	end
end


do -- 发送野外任务信息
	local rsp_opcode = opCodes.M2C_OUTDOOR_GET_TASK_INFO
	local msg_name = "PackOutdoor.M2C_OUTDOOR_GET_TASK_INFO"
	local data = {center_boss_info = {}}
	function OutdoorService:sendOutdoorTaskInfo(aoi_scene, character, task)
		local gpids = character and character.gpid or GameObjectService:getGPids(aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, task, nil, gpids)
	end	
end

----------------------------------- 中间BOSS仇恨值相关 【END】------------------------------------------------------------------------
