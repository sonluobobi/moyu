--[[
野外场景 service
author : xingzeng.jiang
date : 2014-07-15
--]]


DaojianjueService = DaojianjueService or {}
setmetatable(DaojianjueService, SceneServiceInterface)

local SceneService = SceneService
function DaojianjueService:onAfterLoadLua()
	SceneService = _G.SceneService
end

function DaojianjueService:checkEnterScene(character, aoi_scene, dst_scene_base)
	return true
end

function DaojianjueService:checkLeaveScene(character, aoi_scene)
	return true
end

function DaojianjueService:update500ms(now_time_msec, aoi_scene)
	local timestamp = now_time_msec/1000
	if self:isFinish(aoi_scene) then
		local djj = aoi_scene.djj
		if djj and not djj.is_kickout and djj.finish_time + 300 < timestamp then
			-- 将所有玩家从PK服中剔出
			local chs = GameObjectService:getPlayerGameObjs(aoi_scene)
			for _, character in pairs(chs) do	
				ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
			end
			djj.is_kickout = true
		end
		return
	end

	local djj = aoi_scene.djj

	-- 判断是否广播即将创建怪物
	if timestamp > djj.boss_create_time - 30 and not djj.is_noticed then
		djj.is_noticed = true
		NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.DAOJJ_NOTICE_BOSS_WILL_CREATE)
	end

	-- 创建BOSS怪
	if not djj.boss_monster_aoi_id and timestamp > djj.boss_create_time then 
		self:createSuperBossMonster(aoi_scene)
	end

	-- 定期回血
	if Time.is_second_start then
		self:checkAddSaveAreaHp(aoi_scene)
	end

end

function DaojianjueService:checkFight(aoi_scene, attacker, target)
	return true
end

function DaojianjueService:beforeEnterScene(character, aoi_scene)
	character.scene_id = DaojianjueConfig.war_scene_id
	local camp = DaojianjueService:getCamp( aoi_scene, character )
	local pos = DaojianjueService:getRandomCampTransforIn(DaojianjueConfig.war_scene_id, camp)
	character.x = pos.x
	character.y = pos.y
	return true
end

-- 设置头顶文字
function DaojianjueService:initWanfaAoiData( character, aoi_scene )
	return true
end

-- 场景初始化
function DaojianjueService:onInitScene(character, aoi_scene)
	-- 默认场景初始化
	SceneService:onInitSceneDefault(character, aoi_scene)
	
	-- 场景刀剑相关数据
	aoi_scene.djj = {}
	local djj = aoi_scene.djj

	-- 角色相关信息
	djj.gcid_2_ch_info = {}	

	-- 阵营总得分信息
	djj.camp_score = {[1] = 0, [2] = 0}

	-- 阵营人数
	djj.camp_num = {[1] = 0, [2] = 0}

	-- 阵营GPID
	djj.camp_gpids = {[1] = {}, [2] = {}}

	-- 阵营战力
	djj.camp_fc = {[1] = 0, [2] = 0 }

	-- 排名 
	djj.top_list = {}

	-- 离开的玩家列表
	djj.leave_ch_hash = {}	--gcid->true

	-- BOSS怪的等级（初始等级为0）
	djj.boss_monster_lv = 0	
	-- 上一次BOSS怪被杀死用掉的时间
	djj.last_boss_killed_time_long = 0
	-- 下一次BOSS怪出现的时间(初始一分钟后出现BOSS怪)
	djj.boss_create_time = os.time() + DaojianjueConfig.boss_create_time_init 
	-- 已经生成的BOSS怪AOIID
	djj.boss_monster_aoi_id = nil
	-- 是否已经发送怪物即将出现的广播
	djj.is_noticed = false

	-- 创建守卫塔
	DaojianjueService:createSaveMonster( aoi_scene )
	return true
end

-- 创建守卫怪
do
	local camp_2_save_monsters = {
		[1] = {	[1] = {x=11.51, y=11.11, direction=120}},
		[2] = { [1] = {x=84.8,  y=11.1,  direction=240}},
	}

	function DaojianjueService:createSaveMonster( aoi_scene )
		local monster_id = DaojianjueConfig.save_monster_id
		for camp, poses in pairs(camp_2_save_monsters) do
			for _, pos in pairs(poses) do
				local monster = MonsterService:dymCreateMonster(aoi_scene, monster_id,nil , pos.x, pos.y,pos.direction)
				GameObjectService:updateZhenying(aoi_scene, monster, camp, true)
			end
		end
	end
end

function DaojianjueService:getAverageLevelScene( aoi_scene )
	local players = GameObjectService:getPlayerGameObjs(aoi_scene)	
	local player_num = 0
	local sum_level = 0
	
	for _, character in pairs(players) do
		player_num = player_num + 1
		sum_level = sum_level + character.level
	end
	return math.floor(sum_level * 0.1 / player_num) * 10
end

-- 创建BOSS怪
do
	local super_boss_pos = {
		x = DaojianjueConfig.boss_pos_x, 
		y = DaojianjueConfig.boss_pos_y, 
		direction = 270,
	}
	local kill_time_long_2_lv_up = {
		[1] = {kill_time_long = 1, lv_up = 25},
		[2] = {kill_time_long = 2, lv_up = 20},
		[3] = {kill_time_long = 4, lv_up = 12},
		[4] = {kill_time_long = 8, lv_up = 6},
		[5] = {kill_time_long = 15, lv_up = 3},
		[6] = {kill_time_long = 30, lv_up = 2},
	}
	function DaojianjueService:createSuperBossMonster( aoi_scene )
		local djj = aoi_scene.djj
		local boss_monster_lv = djj.boss_monster_lv or 0
		local lvup = 0

		if boss_monster_lv == 0 then 
			-- 如果没有玩家，不继续后面的逻辑
			local gpids = GameObjectService:getGPids(aoi_scene)
			if not gpids or #gpids <= 0 then 
				return 
			end

			-- 计算场景内玩家的平均
			local average_lv = self:getAverageLevelScene(aoi_scene)
			local monster_id = assert(DaojianjueConfig.level_2_monster_id[average_lv])

			boss_monster_lv = 1
			djj.boss_monster_lv = 1	--初始是1级的怪物
			djj.boss_monster_id = monster_id
		else
			-- 计算BOSS的升级情况
			local last_boss_killed_time_long = djj.last_boss_killed_time_long
			for _, lv_up_info in ipairs(kill_time_long_2_lv_up) do
				if last_boss_killed_time_long <= lv_up_info.kill_time_long then 
					lvup = lv_up_info.lv_up
					break
				end
			end

			boss_monster_lv = boss_monster_lv + lvup
			djj.boss_monster_lv = boss_monster_lv			
		end
		local score = DaojianjueConfig:getScoreByMul(boss_monster_lv)
		local monster_id = djj.boss_monster_id
		if lvup > 0 then 
			local params = {}
			params[1] = lvup
			params[2] = score
			NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.DAOJJ_NOTICE_BOSS_CREATE_LVUP, params)
		else
			local params = {}
			params[1] = score
			NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.DAOJJ_NOTICE_BOSS_CREATE, params)
		end

		-- 创建怪物
		local monster = MonsterService:dymCreateMonster(aoi_scene, monster_id,nil , super_boss_pos.x, super_boss_pos.y,super_boss_pos.direction)
		local new_hp = monster.max_hp * boss_monster_lv
		monster.max_hp = new_hp
		monster.hp = new_hp
		local update_data = {
			hp = monster.hp,
			max_hp = monster.max_hp
		}
		SceneService:sendAppearUpdate(aoi_scene, monster, update_data)				
		djj.boss_monster_aoi_id = monster.aoi_obj.obj_id

		-- 通知客户端
		local gpids = GameObjectService:getGPids(aoi_scene)
		self:sendVsInfo(aoi_scene, gpids)
	end
end

do
	local camp_2_center_pos = {
		[1] = {x=11.51, y=11.11, radius = 5.5},
		[2] = {x=84.8,  y=11.1,  radius = 5.5},
	}
	function DaojianjueService:checkAddSaveAreaHp( aoi_scene )
		local all_players = GameObjectService:getGameObjsByType(aoi_scene, AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER)
		if all_players then 
			for _, object in pairs(all_players) do
				-- 回复血量
				local zhengying = object.tmps.zhenying
				local center = camp_2_center_pos[zhengying]
				if (object.x - center.x)^2 + (object.y - center.y)^2 < center.radius^2 then 
					self:addHp(object)	
				end
			end
		end

		local all_pets = GameObjectService:getGameObjsByType(aoi_scene, AoiObjectType.AOI_OBJECT_TYPE_ID_PET)
		if all_pets then 
			for _, object in pairs(all_pets) do
				-- 回复血量
				local zhengying = object.tmps.zhenying
				local center = camp_2_center_pos[zhengying]
				if (object.x - center.x)^2 + (object.y - center.y)^2 < center.radius^2 then 
					self:addHp(object)	
				end
			end
		end
	end

	-- 获取当前有效的血条
	local ch_add_hp_list = {
		[1] = {max_key = 'max_hp',  hp_key='hp'},
		[2] = {max_key = 'max_hp2', hp_key='hp2'},
		[3] = {max_key = 'max_hp3', hp_key='hp3'}
	}
	local pet_add_hp_list = {
		[1] = {max_key = 'max_hp',  hp_key='hp'},
	}	
	function DaojianjueService:addHp(object, aoi_scene)
		-- 死亡的不回血
		if FightService:isDead(object) then 
			return 
		end

		local add_hp_list = nil
		if FightService:isLikeCharacter(object) then
			add_hp_list = ch_add_hp_list
		else
			add_hp_list = pet_add_hp_list
		end
		local total_hp =object.max_hp + (object.max_hp2 or 0) + (object.max_hp3 or 0)
		
		local add_hp = math.floor(total_hp * 0.1)

		for _, info in ipairs(add_hp_list) do
			local max_key = info.max_key
			local hp_key = info.hp_key

			local max_hp = object[max_key]
			local hp = object[hp_key] 
			hp = hp > 0 and hp or 0

			if max_hp > hp then 
				if max_hp - hp >= add_hp then 
					-- 加满后不剩
					object[hp_key] = hp + add_hp
					add_hp = 0
				else
					-- 加满后有剩
					object[hp_key] = max_hp
					add_hp = add_hp - (max_hp - hp)
				end
				local index = FightService:getHpInfo(object)
				local arr_aoi_change_hp = {FightService:newObjChangeHp(object.aoi_id, index, max_hp - hp, object[hp_key])}
				FightService:sendObjsChangeHp(aoi_scene, object, arr_aoi_change_hp)
			end

			if add_hp <= 0 then 
				break 
			end
		end
	end
end


function DaojianjueService:getBirthPos(aoi_scene, character)
	if not self:isInDaojj(aoi_scene.scene_id) then 
		return false
	end
	local camp = DaojianjueService:getCamp( aoi_scene, character )
	local pos = DaojianjueService:getRandomCampTransforIn(DaojianjueConfig.war_scene_id, camp)
	return true, pos.x, pos.y
end

-- 设置阵营
function DaojianjueService:setZhenying(aoi_scene, character)
	local camp = DaojianjueService:getCamp( aoi_scene, character )
	GameObjectService:updateZhenying(aoi_scene, character, camp)
end

-- 获取阵营
function DaojianjueService:getCamp( aoi_scene, character )
	local camp = character.tmps_ex.djj_camp
	if not camp then 
		-- 未预分配的，加入人数较少的阵营
		local camp_num = aoi_scene.djj.camp_num
		camp = camp_num[1] > camp_num[2] and 2 or 1
		if camp_num[1] == camp_num[2] then 
			local djj = aoi_scene.djj
			local camp_fc = djj.camp_fc
			camp = camp_fc[1] > camp_fc[2] and 2 or 1
		end
	end
	return camp
end

-- 进入场景之后
function DaojianjueService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	local djj = aoi_scene.djj

	if not is_reconnect then
		-- 计算阵营
		local camp = DaojianjueService:getCamp( aoi_scene, character )
		character.tmps_ex.djj_camp = nil
		local camp_num = aoi_scene.djj.camp_num
		camp_num[camp] = camp_num[camp] + 1
		local camp_fc = djj.camp_fc
		camp_fc[camp] = camp_fc[camp] + character.fight_capacity

		-- 新建角色数据(均使用新的数据)
		local ch_info = self:newChInfo(character, camp)
		local gcid_2_ch_info = djj.gcid_2_ch_info
		gcid_2_ch_info[character.gcid] = ch_info 	

		-- 更新阵营
		GameObjectService:updateZhenying(aoi_scene, character, camp)

		-- 重新生成排行榜 
		self:rank(character.gcid, aoi_scene)
		self:sendChInfo(character, aoi_scene)

		-- 保存玩家的GPID
		local camp_gpids = djj.camp_gpids
		table.insert(camp_gpids[camp], character.gpid)

		-- 保存参与信息到DB
		ActiveService:addJoinGameInfo( character, Statics.PK_GAME_TYPE_ID_DAOJJ )

		local log_type = '角色' .. character.nick .. '进入'
		DaojianjueService:printCamp(aoi_scene, log_type)
	else
		-- 发送排名信息
		self:sendVsInfo( aoi_scene, character.gpid)

		-- 发送角色信息
		self:sendChInfo(character, aoi_scene)		
	end

end

function DaojianjueService:printCamp(aoi_scene, notice)
	do return end
	if self:isFinish(aoi_scene) then return end

	local djj = aoi_scene.djj

	local log_str = '---------------' .. aoi_scene.space_id .. ' ' .. notice .. '\n'
	local tmp_camp_ch = {[1] = {}, [2] = {}}
	for _, ch_info in pairs(djj.gcid_2_ch_info) do
		if ch_info.is_online then 
			table.insert(tmp_camp_ch[ch_info.camp], ch_info)
		end
	end
	for _, camp_info in pairs(tmp_camp_ch) do
		table.sort(camp_info, function(a, b) return a.fight_capacity > b.fight_capacity end)
		log_str = log_str .. '阵营' .. _ .. '人数:' .. #camp_info .. 
			', 积分:' .. djj.camp_score[_] .. 
			', 战力:' .. djj.camp_fc[_] .. '\n'
		for _, ch_info in pairs(camp_info) do
			local ch_str = ch_info.nick .. '=>战力:' .. ch_info.fight_capacity .. ', 等级:' .. ch_info.level
			log_str = log_str .. '\t\t' .. ch_str .. '\n'
		end
	end
	
	local filename = "daojianjue_" .. os.date('%Y%m%d', os.time()) .. ".log"
	external.log(log_str, filename)
end

-- 离开场景时
function DaojianjueService:afterLeaveScene(character, aoi_scene, leave_type)
	local djj = aoi_scene.djj

	-- 将角色积分信息删除
	local ch_info = self:getDjjChInfo(aoi_scene, character)
	ch_info.is_online = false

	-- 阵营人数减1
	local camp = ch_info.camp
	djj.camp_num[camp] = djj.camp_num[camp] - 1
	djj.camp_fc[camp] = djj.camp_fc[camp] - character.fight_capacity

	-- 从GPID列表中删除
	local camp_gpids = djj.camp_gpids
	local this_camp_gpids = camp_gpids[camp]
	for i=1, #this_camp_gpids do
		if this_camp_gpids[i] == character.gpid then 
			this_camp_gpids[i] = this_camp_gpids[#this_camp_gpids]
			this_camp_gpids[#this_camp_gpids] = nil
			break
		end
	end

	-- 挂机离开且玩法未结束的情况下，发奖励,并将玩家的数据清除
	if ch_info.is_gauji_leave and not self:isFinish(aoi_scene) then 
		local gcid = character.gcid
		local gcid_2_ch_info = aoi_scene.djj.gcid_2_ch_info
		gcid_2_ch_info[gcid] = nil
		self:rank(gcid, aoi_scene)	

		-- 发奖励	
		local data = {}
		data.gcid = ch_info.gcid
		data.gpid = ch_info.gpid
		data.score = ch_info.score
		data.rank = 999
		data.total_kill_cnt = ch_info.total_kill_cnt
		data.is_win = false
		data.is_gauji_leave = 1
		RewardService:reward(Statics.PK_GAME_TYPE_ID_DAOJJ, 0, ch_info.gpid, ch_info.gcid, data)			
	end

	local log_type = '角色' .. character.nick .. '离开，原有阵营:' .. camp
	DaojianjueService:printCamp(aoi_scene, log_type)
end

-- 当玩家捡到积分BUFFER时
function DaojianjueService:addScore( character, score )
	local aoi_scene = GameObjectService:getAoiScene(character)
	local djj = aoi_scene.djj
	if not djj or djj.is_finish then 
		return 
	end	

	local player_info = self:getDjjChInfo(aoi_scene, character)
	local camp = player_info.camp
	player_info.score = player_info.score + score
	djj.camp_score[camp] = djj.camp_score[camp] + score

	-- 重新排名
	self:rank(character.gcid, aoi_scene)

	-- 发送角色的积分信息
	self:sendChInfo(character, aoi_scene)

	-- 发送得分特效
	GameObjectService:addAoiInstantTexiao( aoi_scene, character, AoiTexiaoDefs.SORT_SCORE_ADD_PIAOZI, score )
end

-- 生成排名
function DaojianjueService:rank( gcid, aoi_scene )
	-- 更新排名数据
	self:genToplist(aoi_scene, 5)

	-- 发送新的排名信息
	local gpids = GameObjectService:getGPids(aoi_scene)
	self:sendVsInfo(aoi_scene, gpids)	

	-- 发送角色排名给排名有变化的玩家
	local gcid_2_ch_info =  aoi_scene.djj.gcid_2_ch_info
	for _, ch_info in pairs(gcid_2_ch_info) do
		if ch_info.rank ~= ch_info.old_rank and ch_info.gcid ~= gcid then 
			local need_send_ch = CharacterService:getCharacterByGcid(ch_info.gcid)
			if need_send_ch then 
				self:sendChInfo(need_send_ch, aoi_scene)
			end
		end
	end	
end

-- 当玩家被杀
do
	-- 红名被杀的得分
	local redname_2_score = {
		[RedNameDefs.RED_NAME_STATUS_SAVE] = {score = 10,  percent=0},
		[RedNameDefs.RED_NAME_STATUS_NORMAL] = {score = 10, percent=0},
		[RedNameDefs.RED_NAME_STATUS_LIGHT] = {score = 10, percent=0},
		[RedNameDefs.RED_NAME_STATUS_MIDDLE] = {score = 10, percent=0},
		[RedNameDefs.RED_NAME_STATUS_SERIOUS] = {score = 10, percent=0},
	}
	function DaojianjueService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
		-- 怪物杀人不算
		if not fighter.tmps_ex then 
			return 
		end

		-- 游戏结束后不再进行计算
		local aoi_scene = GameObjectService:getAoiScene(fighter)
		if aoi_scene.djj.is_finish then 
			return 
		end	
		
		local djj = aoi_scene.djj
		local killer_info = self:getDjjChInfo(aoi_scene, fighter)
		local killer_camp = killer_info.camp

		-- 总共获得的积分数
		local total_get_score = 0

		-- 杀人者的连续被杀次数清零
		killer_info.cont_be_kill_cnt = 0

		-- 清除保护状态
		if killer_info.red_name == RedNameDefs.RED_NAME_STATUS_SAVE then 
			killer_info.red_name = RedNameDefs.RED_NAME_STATUS_NORMAL
			self:updateRedname( fighter, killer_info )
		end

		for _, killed_aoi_id in pairs(arr_kill_player_aoi_id) do

------------------------------- 受击方 ---------------------------------------------------------
			local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, killed_aoi_id) 
			local killed_info = self:getDjjChInfo(aoi_scene, killed_player)

			-- 计算得分
			local score_info = redname_2_score[killed_info.red_name]
			local score = score_info.score + killed_info.score * score_info.percent

			-- 增加连续被杀次数
			killed_info.cont_be_kill_cnt = killed_info.cont_be_kill_cnt + 1

			-- 连续击杀次数清零
			killed_info.cont_kill_cnt_for_notice = 0
			killed_info.cont_kill_cnt_for_redname = 0

			-- 被杀者计算红名
			local killed_redname = killed_info.red_name
			if killed_redname == RedNameDefs.RED_NAME_STATUS_NORMAL then
				-- 普通状态下，如果连续被杀次数达到阈值，变为保护状态
				if killed_info.cont_be_kill_cnt >= DaojianjueConfig.save_need_killed then 
					killed_info.red_name = RedNameDefs.RED_NAME_STATUS_SAVE
					self:updateRedname( killed_player, killed_info )
				end
			elseif killed_redname ~= RedNameDefs.RED_NAME_STATUS_SAVE then 
				-- 红名状态下，降级
				killed_info.red_name = killed_info.red_name - 1
				self:updateRedname( killed_player, killed_info )
			end

---------------------------------- 攻击方 -----------------------------------

			-- 计算总共增加的积分
			total_get_score = total_get_score + score

			-- 增加总杀人数
			killer_info.total_kill_cnt = killer_info.total_kill_cnt + 1

			-- 增加连续杀人数
			killer_info.cont_kill_cnt_for_redname = killer_info.cont_kill_cnt_for_redname + 1
			killer_info.cont_kill_cnt_for_notice = killer_info.cont_kill_cnt_for_notice + 1
			if killer_info.max_cont_kill < killer_info.cont_kill_cnt_for_notice then 
				killer_info.max_cont_kill = killer_info.cont_kill_cnt_for_notice
			end

			-- 计算红名
			local killer_redname = killer_info.red_name
			if killer_redname ~= RedNameDefs.RED_NAME_STATUS_SERIOUS and 
			killer_info.cont_kill_cnt_for_redname >= DaojianjueConfig.redname_add_need then 
				-- 红名升级
			   	killer_info.red_name = killer_redname + 1
				self:updateRedname( fighter, killer_info )
				killer_info.cont_kill_cnt_for_redname = 0
			end
		end

		-- 攻击者更新积分
		self:sendChInfo(fighter, aoi_scene)

		-- 显示得分特效
		if total_get_score > 0 then 
			-- 攻击者增加积分
			DaojianjueService:addScore( fighter, total_get_score )
		end
	end
end

-- 当怪物被杀，增加积分
do
	local monster_id_2_score = {
		[90006076] = 15,
	}
	function DaojianjueService:onKilledMonster( character, arr_kill_monster_id, arr_kill_monster_aoi_id )

		local aoi_scene = GameObjectService:getAoiScene(character)
		if aoi_scene.djj.is_finish then 
			return 
		end	

		local total_add_score = 0
		local djj = aoi_scene.djj

		for _, monster_id in pairs(arr_kill_monster_id) do
			-- 超级BOSS怪
			if djj.boss_monster_aoi_id and djj.boss_monster_aoi_id == arr_kill_monster_aoi_id[_] then 
				local lv = djj.boss_monster_lv
				local score = DaojianjueConfig:getScoreByMul(lv)

				djj.is_noticed = false
				djj.boss_monster_aoi_id = false
				djj.last_boss_killed_time_long = os.time() - djj.boss_create_time
				djj.boss_create_time = os.time() + DaojianjueConfig.boss_create_time_next

				-- 广播BOSS被杀
				local params = {}
				params[1] = character.nick
				params[2] = score
				NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.DAOJJ_NOTICE_BOSS_KILLED, params)

				if score then 
					total_add_score = total_add_score + score
				end

				-- 增加BOSS击杀数
				local killer_info = self:getDjjChInfo(aoi_scene, character)		
				killer_info.kill_boss_num = killer_info.kill_boss_num + 1
			else
				local score = monster_id_2_score[monster_id]
				if score then 
					total_add_score = total_add_score + score
				end				
			end
		end
		if total_add_score > 0 then 
			self:addScore(character, total_add_score)
		end
	end
end

-- 获取角色信息
function DaojianjueService:getDjjChInfo( aoi_scene, character )
	return aoi_scene.djj.gcid_2_ch_info[character.gcid]
end

-- 设置红名状态
function DaojianjueService:updateRedname( character, ch_info )
	local red_name = ch_info.red_name
	WanfaAoiService:setWanfaAoiData(character, 'redname_status', red_name, true)
end

-- 新建角色对象
function DaojianjueService:newChInfo( character, camp )
	local ch_info = {}
	ch_info.gcid = character.gcid
	ch_info.gpid = character.gpid  	
	ch_info.camp = camp 			--所在阵营
	ch_info.score = 0				--积分
	ch_info.cont_kill_cnt_for_redname = 0		--红名计算用的连续杀人数
	ch_info.cont_kill_cnt_for_notice = 0	--广播用的连续杀人数
	ch_info.cont_be_kill_cnt = 0	--连续被杀数
	ch_info.total_kill_cnt = 0		--总杀人数
	ch_info.red_name = 0			--红名状态(初始为0,普通状态)
	ch_info.nick = character.nick 	--
	ch_info.is_online = true
	ch_info.max_cont_kill = 0		--最高连杀数
	ch_info.kill_boss_num= 0		--击杀BOSS数
	ch_info.fight_capacity = character.fight_capacity
	ch_info.level = character.level
	ch_info.prof = character.prof
	return ch_info
end

-- 获取复活点
-- return 	bool:is_back_to_mcity,	true:回到主城，false:本场景复活
--			x, y					本场景复活的X，Y坐标点
function DaojianjueService:getRelivePos(character, aoi_scene)
	local ch_info = aoi_scene.djj.gcid_2_ch_info[character.gcid]
	local pos = DaojianjueService:getRandomCampTransforIn(DaojianjueConfig.war_scene_id, ch_info.camp)
	return false, pos.x, pos.y
end

-- 获取排行榜
function DaojianjueService:genToplist( aoi_scene, limit_num)
	local djj = aoi_scene.djj
	
	local gcid_2_ch_info =  djj.gcid_2_ch_info
	local tmp = {}
	
	for _, ch_info in pairs(gcid_2_ch_info) do	tmp[#tmp + 1] = ch_info	end

	table.sort( tmp, function ( a, b ) return a.score > b.score end)

	-- 更新排名
	local size = #tmp 
	for i=1, size do 
		tmp[i].old_rank = tmp[i].rank or 99
		tmp[i].rank = i 
	end

	-- 只保留前5名
	for i=limit_num+1,size do tmp[i] = nil end

	djj.top_list = tmp
end

-- 活动结束，发奖
function DaojianjueService:finish(aoi_scene)
	local djj = aoi_scene.djj
	if djj.is_finish then return end

	-- 设置完成时间
	djj.finish_time = os.time()
	djj.is_finish = true	

	-- 计算胜利阵营
	local camp_score = djj.camp_score
	local win_camp
	win_camp = camp_score[1] > camp_score[2] and 1 or 2
	win_camp = camp_score[1] == camp_score[2] and 0 or win_camp
	djj.win_camp = win_camp

	do 	-- 计算要发送给玩家的战斗结果
		local djj_result = {}	--结果数据
		djj_result.win_camp = win_camp
		djj_result.result = {[1] = {camp = 1, ranked_result = {}}, [2] = {camp = 2, ranked_result = {}}}

		local result = djj_result.result
		result[1].score = camp_score[1]
		result[2].score = camp_score[2]

		-- 将玩家按阵营发送
		for _, ch_info in pairs(djj.gcid_2_ch_info) do
			if ch_info.is_online then 
				table.insert(result[ch_info.camp].ranked_result, ch_info)
			end
		end

		for k, v in pairs(result) do
			table.sort(v.ranked_result, function ( l, r )
				return l.score > r.score
			end)
		end

		self:sendFinish(aoi_scene, djj_result)
	end
	
	-- 发奖
	for _, ch_info in pairs(djj.gcid_2_ch_info) do
		local data = {}
		data.gcid = ch_info.gcid
		data.gpid = ch_info.gpid
		data.score = ch_info.score
		data.rank = ch_info.rank or 999
		data.total_kill_cnt = ch_info.total_kill_cnt
		data.is_win = (ch_info.camp == win_camp or 0 == win_camp) and true or false
		RewardService:reward(Statics.PK_GAME_TYPE_ID_DAOJJ, 0, ch_info.gpid, ch_info.gcid, data)	
	end

	DaojianjueService:printCamp(aoi_scene, "战斗结束")
end

-- 判断玩家是否在野外
function DaojianjueService:isInDaojj( scene_base_id )
	return scene_base_id == DaojianjueConfig.war_scene_id
end

-- 是否已经结束
function DaojianjueService:isFinish( aoi_scene )
	local djj = aoi_scene.djj
	return djj and djj.is_finish
end

-- 获取出生点与复活点
function DaojianjueService:getRandomCampTransforIn(scene_id, camp_id)
	local transfer_base_id = nil
	if camp_id == 1 then 
		transfer_base_id = DaojianjueConfig.camp_a_transfer_dot
	else
		transfer_base_id = DaojianjueConfig.camp_b_transfer_dot
	end
	local pos = {}
	pos.x, pos.y = SceneAoiService:getRandomTransferIn( scene_id, transfer_base_id )
	return pos
end


do  -- base传来的移动角色到战场
	rank_2_camp = {
		[1] = 1, [2] = 2,  [3] = 2,  [4] = 1, 
		[5] = 1, [6] = 2,  [7] = 2,  [8] = 1, 
		[9] = 1, [10] = 2, [11] = 2, [12] = 1, 
		[13] = 1,[14] = 2, [15] = 2, [16] = 1, 
		[17] = 1,[18] = 2, [19] = 2, [20] = 1, 
		[21] = 1,[22] = 2, [23] = 2, [24] = 1, 
		[25] = 1,[26] = 2, [27] = 2, [28] = 1, 
		[29] = 1,[30] = 2
	}
	function DaojianjueService:b2m_entryBattle( character, data )
		-- 玩家可能已经不在了
		if not character then return end

		local space_id = data.space_id
		local line_id = data.line_id
		local rank = data.rank
		character.tmps_ex.djj_camp = rank_2_camp[rank]

		local space_id = data.space_id
		local line_id = data.line_id
		
		local pos = DaojianjueService:getRandomCampTransforIn(DaojianjueConfig.war_scene_id, rank_2_camp[rank])
		SceneService:moveScene(character, DaojianjueConfig.war_scene_id, space_id, line_id, pos.x, pos.y)	
	end
end

-- base 发来的活动结束
function DaojianjueService:b2m_finish(_, data )
	local space_id = data.space_id
	local aoi_scene = AoiSceneService:getAoiScene(space_id)
	if aoi_scene then 
		self:finish(aoi_scene)
	end
end

-- base 发来的玩家退出后进入了其他的场景实例 
function DaojianjueService:b2m_chEntryOtherScene(_, data)
	local space_id = data.space_id
	local gcid = data.gcid
	local aoi_scene = AoiSceneService:getAoiScene(space_id)
	if aoi_scene then 
		local gcid_2_ch_info = aoi_scene.djj.gcid_2_ch_info
		gcid_2_ch_info[gcid] = nil
		self:rank(gcid, aoi_scene)
	end
end

function DaojianjueService:guajiLeave( character )
	local aoi_scene = AoiSceneService:getAoiScene(character.space_id)
	if not self:isInDaojj(aoi_scene.scene_id) then return end

	if self:isFinish(aoi_scene) then 
		return 
	end

	local ch_info = self:getDjjChInfo(aoi_scene, character)
	if ch_info then 
		ch_info.is_gauji_leave = true

		-- 将玩家踢出
		ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
	end
end
------------------------------------- 广播 【BEG】 -----------------------------------

------------------------------------- 广播 【END】 -----------------------------------


------------------------------------- 与客户端交互 【BEG】 ---------------------------

do	-- 发送角色积分信息
	local rsp_opcode = opCodes.M2C_DAJJ_CH_VS_INFO
	local msg_name = "PackDaojianjue.M2C_DAJJ_CH_VS_INFO"
	function DaojianjueService:sendChInfo(character, aoi_scene)
		local ch_info = self:getDjjChInfo(aoi_scene, character)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, ch_info, nil, character.gpid)
	end
end

do	-- 发送排名信息
	local rsp_opcode = opCodes.M2C_DJJ_VS_INFO
	local msg_name = "PackDaojianjue.M2C_DJJ_VS_INFO"
	local data = {}
	function DaojianjueService:sendVsInfo(aoi_scene, gpids)
		local djj = aoi_scene.djj
		data.score_camp_a = djj.camp_score[1]
		data.score_camp_b = djj.camp_score[2]
		data.top_list = djj.top_list
		data.boss_create_time = djj.boss_create_time
		if aoi_scene.djj.boss_monster_aoi_id then 	
			data.is_boss_create = true
		else
			data.is_boss_create = false
		end
--		Logger:info(data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end
end

do	-- 发送结束信息
	local rsp_opcode = opCodes.M2C_DJJ_FINISH
	local msg_name = "PackDaojianjue.M2C_DJJ_FINISH"
	function DaojianjueService:sendFinish(aoi_scene, result)
		local gpids = GameObjectService:getGPids(aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, result, nil, gpids)
	end
end

------------------------------------- 与客户端交互 【END】 ---------------------------
