--[[
组队 service
author : guoyin.huang
date : 2015年03月24日

]]--


TeamService = TeamService or {}

local TeamService = TeamService
local Team = Team
local TeamDao = TeamDao
local gcid_2_team = TeamDao.gcid_2_team
local teamid_2_team = TeamDao.teamid_2_team

-- 判断两个玩家是否在同一队伍中
function TeamService:isTwoChInSameTeam( character1, character2 )
	local team1 = self:getTeamByCid(character1.gcid)
	local team2 = self:getTeamByCid(character2.gcid)
	return (team1 and team2 and team1 == team2) or false
end

-- 判断某个成员是否机器人
function TeamService:isRobot( member )
	return member.is_robot == 1 and true or false
end

-- 判断玩家是否首任队长
function TeamService:isFirstCaptain( team, gcid )
	return team.no1_cpt_gcid == gcid
end

-- 同步base的队伍数据到map
function TeamService:b2m_sync( _, arr_params)
	local team_id = arr_params.team_id
	local team = arr_params.team
	-- 清除旧的队伍数据
	local old_team = teamid_2_team[team_id]
	if old_team then 
		local old_members = old_team.members
		for _, member in pairs(old_members) do
			gcid_2_team[member.gcid] = nil
		end
		teamid_2_team[team_id] = nil
	end
	if team then 
		-- 添加新的队伍数据
		teamid_2_team[team_id] = team
		for _, member in pairs(team.members) do
			-- 有效成员且不是机器人，则存储对应关系
			if 1 ~= member.is_quit then 
				gcid_2_team[member.gcid] = team
			end
		end
	end
end

function TeamService:b2m_syncForLogout( _, arr_params)
	local team_id = arr_params.team_id
	local team = self:getTeamById(team_id)
	if not team then return end

	local gcids_in_team = arr_params.gcids_in_team
	if not gcids_in_team or #gcids_in_team == 0 then 
		for _, member in pairs(team.members) do
			gcid_2_team[member.gcid] = nil
		end
		-- 删除队伍
		teamid_2_team[team_id] = nil
	else
		local old_members = team.members
		team.members = {}
		for _, member in pairs(old_members) do
			local old_gcid = member.gcid
			gcid_2_team[old_gcid] = nil
			for _, gcid in pairs(gcids_in_team) do
				if gcid == old_gcid then 
					gcid_2_team[old_gcid] = team
					table.insert(team.members, member)
					break
				end
			end
		end
		team.member_num = #team.members
	end
end

-- 获取队伍(通过队伍ID)
function TeamService:getTeamById( team_id )
	return teamid_2_team[team_id]
end

-- 获取队伍(通过角色)
function TeamService:getTeamByCid( gcid )
	return gcid_2_team[gcid]
end

-- 获取队伍(通过角色)
function TeamService:getTeamByGCid( gcid )
	return gcid_2_team[gcid]
end

function TeamService:getTeamGPids(team)
	if type(team) == 'number' then
		team = self:getTeamById(team)
	end
	local members = team.members
	local gpids = {}
	for k, member in pairs(members) do
		if not self:isRobot(member) then 
			gpids[#gpids + 1] = member.gpid
		end
	end
	return gpids
end

function TeamService:getTeamGcid2Gpids(team)
	if type(team) == 'number' then
		team = self:getTeamById(team)
	end
	local members = team.members
	local gcid2gpids = {}
	for k, member in pairs(members) do
		if not self:isRobot(member) then 
			gcid2gpids[member.gcid] = member.gpid
		end
	end
	return gcid2gpids
end

function TeamService:getTeamNicks(team)
	if type(team) == 'number' then
		team = self:getTeamById(team)
	end
	local members = team.members
	local nicks, dot = '', ''
	for k, member in pairs(members) do
		if not self:isRobot(member) then 
			nicks = nicks .. dot .. member.nick
			if dot == '' then dot = ',' end
		end
	end
	return nicks
end

function TeamService:getTeamCharacters(team)
	if type(team) == 'number' then
		team = self:getTeamById(team)
	end
	local members = team.members
	local characters = {}
	for k, member in pairs(members) do
		if not self:isRobot(member) then 
			local ch = CharacterService:getCharacterByGcid(member.gcid)
			if ch then characters[#characters+1] = ch end
		end
	end
	return characters
end

function TeamService:getTeamMemberNum(team_id)
	local team = self:getTeamById(team_id)
	if not team then
		return 0
	end
	
	local members = team.members
	local mem_num = 0
	for _, member in pairs(members) do
		mem_num = mem_num + 1
	end
	return mem_num
end

-- 判断某个成员是否机器人
function TeamService:isRobot( member )
	return member.is_robot == 1 and true or false
end

-- 更新队伍实时数据
function TeamService:updateTeamRealInfoByAoiId( team_id, field, gcid_2_valud)
	local data = {}
	local team = self:getTeamById(team_id)
	if team then 
		local gpids = {}
		for _,member in pairs(team.members) do
			local gcid = member.gcid
			if gcid_2_valud[gcid] then 
				table.insert(data, gcid_2_valud[gcid])
				if not TeamService:isRobot( member ) then 
					table.insert(gpids, member.gpid)
				end
			end
		end
		if #gpids > 0 then 
			self:updateTeamRealInfo(data, gpids)
		end
	end
end

do
	local rsp_opcode = opCodes.PKM2C_TEAM_GET_TEAM_REAL_INFO
	local msg_name = "PackTeam.PKM2C_TEAM_GET_TEAM_REAL_INFO"
	local data = {}
	function TeamService:updateTeamRealInfo( arr_params, gpids )
		data.real_info = arr_params
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end
end
--[[ -- 血量下发相关，作废
-- 定时任务，定期下发队伍血量数据
function TeamService:onTimer( )
	for k, team in pairs(teamid_2_team) do
		self:sendTeamRealInfo(team)
	end
end

-- 计算角色的HP
function TeamService:getChHpRate( character )
	local max_hp1 = character.max_hp
	local hp1 = character.hp
	local max_hp2 = character.max_hp2 == 0 and 1 or character.max_hp2
	local hp2 = character.hp2
	local max_hp3 = character.max_hp3 == 0 and 1 or character.max_hp3
	local hp3 = character.hp3
	return hp1/max_hp1 + hp2/max_hp2 + hp3/max_hp3
end

do	-- 发送所有队伍成员的实时信息
	function TeamService:sendChTeamRealInfo( character )
		local team = self:getTeamByCid(character.gcid)
		if team then 
			TeamService:sendTeamRealInfo( team )
		end
	end
end

do	-- 发送所有队伍成员的实时信息
	local rsp_opcode = opCodes.PKM2C_TEAM_GET_TEAM_REAL_INFO
	local msg_name = "PackTeam.PKM2C_TEAM_GET_TEAM_REAL_INFO"
	local data = {real_info = nil}
	function TeamService:sendTeamRealInfo( team )
		local members = team.members
		local gcids = {}
		for _, member in pairs(members) do
			if 1 ~= member.is_quit then 
				gcids[#gcids + 1] = member.gcid
			end
		end
		if #gcids > 0 then 
			local real_info = {}
			local gpids = {}
			for k, gcid in pairs(gcids) do
				local mem_ch = CharacterService:getCharacterByGcid(gcid)
				if mem_ch then 
					real_info[#real_info + 1] = {gcid = gcid, hp_rate = self:getChHpRate(mem_ch), aoi_id = mem_ch.aoi_id}
					gpids[#gpids + 1] = mem_ch.gpid
				end
			end
			
			-- 至少有两个玩家，才需要发送血量信息
			if #gpids > 1 then 
				data.real_info = real_info
				WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
			end
		end
	end
end
]]