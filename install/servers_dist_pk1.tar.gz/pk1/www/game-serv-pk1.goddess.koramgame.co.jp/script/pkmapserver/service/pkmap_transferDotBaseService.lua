---[[
--	传送点管理
--  by mjl
--  at 2013年7月9日
---]]

TransferDotBaseService = TransferDotBaseService or {}
local TransferDotBaseDao = TransferDotBaseDao

