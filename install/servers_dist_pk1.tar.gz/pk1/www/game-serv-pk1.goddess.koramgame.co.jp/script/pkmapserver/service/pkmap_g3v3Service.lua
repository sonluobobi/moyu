--[[
MAP 3V3 service
author : guoyin.huang
date : 2015年04月20日

]]--

local G3v3Dao = G3v3Dao

G3v3Service = G3v3Service or {}
setmetatable(G3v3Service, SceneServiceInterface)

local SceneService = SceneService
function G3v3Service:onAfterLoadLua()
	SceneService = _G.SceneService
end

--------------------------- 场景相关 [BEG] -------------------------------------
-- 场景初始化
function G3v3Service:onInitScene(character, aoi_scene)
	-- 场景对战信息
	local space_id = aoi_scene.space_id
	local vs_info = G3v3Dao.scene_insid_2_vs_info[space_id]
	G3v3Dao.scene_insid_2_vs_info[space_id] = nil

	if vs_info then 
		aoi_scene.g3v3 = {}
		local g3v3 = aoi_scene.g3v3

		-- GCID对应到玩家
		local gcid_2_member = {}
		-- GCID对应到阵营
		local gcid_2_camp = {}
		g3v3.gcid_2_camp = gcid_2_camp
		g3v3.gcid_2_member = gcid_2_member

		-- 对阵信息
		g3v3.vs_info = vs_info

		-- 记录所有场景内的玩家
		g3v3.gpids = {}
		g3v3.camp1_gpids = {}	-- 阵营1玩家PIDS
		g3v3.camp2_gpids = {}	-- 阵营2玩家PIDS

		-- 计算游戏的开始结束时间
		vs_info.start_time = os.time()
		vs_info.end_time = vs_info.start_time + G3v3Config.g3v3_lenth_each_game

		local camps = {vs_info.camp_a, vs_info.camp_b}

		-- 初始化阵营数据
		for _, camp in pairs(camps) do
			camp.total_score = G3v3Config.g3v3_camp_total_score	--总积分
			camp.score = G3v3Config.g3v3_camp_total_score		--剩余积分
			camp.attack_times = 0	--总攻击次数
			camp.harm = 0			--总伤害
			camp.total_fight_fc = 0	--总战力

			-- 计算总战力
			for _, member in pairs(camp.members) do
				member.score = 0		--得分
				member.harm = 0			--总伤害
				member.attack_times = 0	--攻击次数
				member.cont_kill_num = 0  --连杀数
				member.red_name = 0		--红名状态
				member.kill_num = 0		--杀人数
				member.attack_times_perc = 0
				
				-- 存储起来
				gcid_2_member[member.gcid] = member
				gcid_2_camp[member.gcid] = camp	

				-- 增加总战力
				camp.total_fight_fc = camp.total_fight_fc + member.fight_fc
			end
		end
	else
		aoi_scene.g3v3 = nil
	end

	return true
end

function G3v3Service:checkFight(aoi_scene, attacker)
	return self:isFighting(aoi_scene)
end

-- 场景更新
function G3v3Service:update500ms(now_time_msec, aoi_scene)
	local g3v3 = aoi_scene.g3v3
	if g3v3 then 
		local vs_info = g3v3.vs_info
		local now_time = os.time()

		local end_time = vs_info.end_time
		local is_finish = g3v3.is_finish

		-- 时间到，比赛结束
		if end_time < os.time() then 

			self:finish(aoi_scene)

		-- 一方胜利，比赛结束
		elseif is_finish then 

			local account_time = g3v3.account_time
			if account_time <= now_time then 
				self:finish(aoi_scene)
			end

		end
	end
end

-- 获取复活点
-- @character 复活的角色
-- @aoi_scene 场景
function G3v3Service:getRelivePos(character, aoi_scene)
	local g3v3 = aoi_scene.g3v3 
	if g3v3 then 
		local gcid_2_camp = g3v3.gcid_2_camp
		local camp_info = gcid_2_camp[character.gcid]
		local pos = G3v3Service:getRandomCampTransforIn(G3v3Defs.G3V3_SCENE_ID, camp_info.camp)
		return false, pos.x, pos.y
	else
		return false, character.x, character.y
	end
end

-- 根据阵营获取出生点
-- @scene_id 	场景ID
-- @camp_id 	阵营ID
function G3v3Service:getRandomCampTransforIn(scene_id, camp_id)
	local transfer_base_id = camp_id == 1 and G3v3Config.g3v3_camp_a_transfer_dot or G3v3Config.g3v3_camp_b_transfer_dot

	local pos = {}
	pos.x, pos.y = SceneAoiService:getRandomTransferIn( scene_id, transfer_base_id )

	return pos
end

-- 设置头顶文字
function G3v3Service:initWanfaAoiData( character, aoi_scene )
	return true
end

-- 设置阵营
function G3v3Service:setZhenying(aoi_scene, character)
	local g3v3 = aoi_scene.g3v3
	if not g3v3 then 
		-- 设置阵营,阵营ID统一获取接口
		local zhenying = 1
		GameObjectService:updateZhenying(aoi_scene, character, zhenying)
		local ch_pet = ChPetService:getFightChPet(character)
		if ch_pet and ch_pet.tmps then
			GameObjectService:updateZhenying(aoi_scene, ch_pet, zhenying)
		end	
	else
		local gcid = character.gcid
		local gcid_2_camp = g3v3.gcid_2_camp
		local ch_camp = gcid_2_camp[gcid]

		-- 设置阵营,阵营ID统一获取接口
		local zhenying = ch_camp.camp
		GameObjectService:updateZhenying(aoi_scene, character, zhenying)
	end
end

-- 进入场景
function G3v3Service:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)

	local g3v3 = aoi_scene.g3v3
	if not g3v3 then 
		G3v3Service:sendCh3V3Info(character)
		G3v3Ctrl.c2pkm_match(character, nil)
	else
		if not is_reconnect then 
			-- 下马
			if character.horses.ch_horse then 
				ChHorseService:ride(character, false, true)
			end

			-- 存储所有玩家的GPID(方便发送数据)
			local gpids = g3v3.gpids
			table.insert(gpids, character.gpid)

			local gcid_2_camp = g3v3.gcid_2_camp
			local gcid_2_member = g3v3.gcid_2_member
			local gcid = character.gcid

			local member = gcid_2_member[gcid]
			local camp = gcid_2_camp[gcid]

			-- 按阵营存在玩家的GPID
			if camp.camp == 1 then 
				table.insert(g3v3.camp1_gpids, character.gpid)
			else
				table.insert(g3v3.camp2_gpids, character.gpid)
			end

			-- 设置玩家已经进入
			member.is_enter = true
		end
		-- 发送对战信息
		G3v3Service:sendVsInfo(character, g3v3.vs_info)
	end
end

-- 离开场景
-- 查看是否需要结束
function G3v3Service:afterLeaveScene(character, aoi_scene)
	local g3v3 = aoi_scene.g3v3
	local vs_info = g3v3 and g3v3.vs_info

	if vs_info then 
		local gcid_2_camp = g3v3.gcid_2_camp
		local gcid_2_member = g3v3.gcid_2_member
		local camp = gcid_2_camp[character.gcid]
		local member = gcid_2_member[character.gcid]

		-- 删除发送列表中的玩家
		local gpids = g3v3.gpids
		local ch_gpid = character.gpid
		for _, gpid in pairs(gpids) do
			if gpid == ch_gpid then 
				table.remove(gpids, _)
				break
			end
		end

		-- 判断一方是否还有成员
		member.is_enter = false
		local is_sub_in_scene = false
		for _, member in pairs(camp.members) do
			if member.is_enter then 
				is_sub_in_scene = true
			end
		end

		-- 如果是全部退出结束的，则将积分清零
		if not is_sub_in_scene then 
			camp.score = 0
			self:finish(aoi_scene)
		else
			if camp.score > 10 then 
				camp.score = camp.score - 30
				if camp.score < 10 then camp.score = 10 end
				G3v3Service:sendScoreUpdate(aoi_scene)
			end
		end
	end

	-- 玩家满血
	ReliveService:characterFullHp(character)
	-- 幻兽复活
--	ChPetService:showFightPet(character)

	return true
end


--------------------------- 场景相关 [END] -------------------------------------

-- 当玩家被杀
function G3v3Service:onPlayerKilled( fighter, arr_kill_player_aoi_id )
	-- 只有3V3战斗中才计算分数 
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	if not G3v3Service:isFighting( aoi_scene ) then 
		return 
	end

	local g3v3 = aoi_scene.g3v3
	local gcid_2_member = g3v3.gcid_2_member
	local gcid_2_camp = g3v3.gcid_2_camp

	-- 攻击方阵营与攻击者数据
	local killer_member = gcid_2_member[fighter.gcid]	
	local killer_camp = gcid_2_camp[fighter.gcid]		

	-- 攻击方与被攻击方的玩家列表（用于发送广播）
	local killer_gpids, killed_gpids = g3v3.camp1_gpids, g3v3.camp2_gpids
	if killer_camp.camp ~= 1 then 
		killer_gpids, killed_gpids = killed_gpids, killer_gpids
	end

	-- 被攻击者阵营
	local killed_camp = nil
	local total_score = 0

	-- 被杀者列表（用于广播）
	local nick_list = ''

	-- 给攻击者增加积分
	for _, player_aoi_id in pairs(arr_kill_player_aoi_id) do
		local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, player_aoi_id) 
		local killed_member = gcid_2_member[killed_player.gcid]
		killed_camp = gcid_2_camp[killed_player.gcid]

		-- 玩家被杀会损失的分数
		local score = G3v3Service:getKilledScoreByRedName( killed_member.red_name )
		if score > killed_camp.score  then
			score = killed_camp.score
		end

		-- 被杀者取消红名状态
		killed_member.cont_kill_num = 0
		if killed_member.red_name ~= RedNameDefs.RED_NAME_STATUS_NORMAL then 
			killed_member.red_name = RedNameDefs.RED_NAME_STATUS_NORMAL
			
			-- 更新红名
			local killed_obj = CharacterService:getCharacterByGcid(killed_member.gcid)
			WanfaAoiService:setWanfaAoiData(killed_obj, 'redname_status', killed_member.red_name, true)
		end

		-- 杀人者积分增加
		killer_member.score = (killer_member.score or 0) + score
		-- 被杀阵营积分减少
		killed_camp.score = killed_camp.score - score

		total_score = total_score + score

		-- 被杀者列表
		nick_list = nick_list .. killed_member.nick
		if _ ~= #arr_kill_player_aoi_id then 
			nick_list = nick_list .. ',' 
		end

		-- 增加杀人数
		killer_member.cont_kill_num = killer_member.cont_kill_num + 1
		killer_member.kill_num = killer_member.kill_num + 1
	end	

	if killer_member.red_name ~= RedNameDefs.RED_NAME_STATUS_SERIOUS then 
		killer_member.red_name = G3v3Service:getRedNameByContKill(killer_member.cont_kill_num)
		-- 更新红名状态
		WanfaAoiService:setWanfaAoiData(fighter, 'redname_status', killer_member.red_name, true)
	end

	local msg_params = {}
	table.insert(msg_params, killer_member.nick)
	table.insert(msg_params, nick_list)
	table.insert(msg_params, total_score)

	-- 通知玩家积分变化
	G3v3Service:sendScoreUpdate(aoi_scene)

	-- 如果一方积分为0，则结束战斗
	if killed_camp.score <= 0 then 
		g3v3.is_finish = true
		g3v3.account_time = os.time() + 3
	end
end

do
	local redname_2_score = {
		[RedNameDefs.RED_NAME_STATUS_NORMAL] = 10,
		[RedNameDefs.RED_NAME_STATUS_LIGHT] = 15,
		[RedNameDefs.RED_NAME_STATUS_MIDDLE] = 20,
		[RedNameDefs.RED_NAME_STATUS_SERIOUS] = 25,
	}
	function G3v3Service:getKilledScoreByRedName( red_name )
		return redname_2_score[red_name]
	end
end

do
	local contkill_2_redname = {
		[0] = RedNameDefs.RED_NAME_STATUS_NORMAL,
		[1] = RedNameDefs.RED_NAME_STATUS_LIGHT,
		[2] = RedNameDefs.RED_NAME_STATUS_MIDDLE,
		[3] = RedNameDefs.RED_NAME_STATUS_SERIOUS,
		other = RedNameDefs.RED_NAME_STATUS_SERIOUS
	}
	function G3v3Service:getRedNameByContKill( cont_kill_num )
		return contkill_2_redname[cont_kill_num] or contkill_2_redname.other
	end
end

-- 玩家受伤害时
-- @fighter  		攻击者
-- @arr_kill_player_aoi_id	被攻击对象的AOI_ID对应的伤害
function G3v3Service:onPlayerHarm(fighter, arr_kill_player_aoi_id, is_character_attack)
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	-- 不在战斗中，不统计伤害值
	if not self:isFighting(aoi_scene) then 
		return 
	end
	
	local g3v3 = aoi_scene.g3v3
	local gcid_2_camp = g3v3.gcid_2_camp
	local gcid_2_member = g3v3.gcid_2_member

	-- 攻击方阵营
	local fighter_camp = gcid_2_camp[fighter.gcid]
	-- 攻击方成员
	local fighter_mem = gcid_2_member[fighter.gcid]

	-- 增加攻击次数(只计算角色本身的次数)
	if is_character_attack then 
		fighter_mem.attack_times = (fighter_mem.attack_times or 0) + 1
		fighter_camp.attack_times = (fighter_camp.attack_times or 0) + 1
	end

	-- 计算伤害增加值
	local total_harm = 0
	for aoi_id, harm in pairs(arr_kill_player_aoi_id) do
		total_harm = total_harm + harm
	end

	-- 增加阵营与攻击者的总伤害值
	fighter_camp.harm = total_harm + (fighter_camp.harm or 0)
	fighter_mem.harm = total_harm + (fighter_mem.harm or 0)
end

-- 是否在3v3中
function G3v3Service:isIn3v3( scene_id )
	return scene_id == G3v3Defs.G3V3_SCENE_ID
end

--比赛结束
function G3v3Service:finish( aoi_scene )
	local g3v3 = aoi_scene.g3v3

	if g3v3 then 
		g3v3.is_finish = true

		-- 通知base 战斗结束
		self:m2b_noticeFinish(g3v3.vs_info)

		local vs_info = g3v3.vs_info
		local camp_a = vs_info.camp_a
		local camp_b = vs_info.camp_b

		-- 计算胜利方阵营(得分高的一方胜利，若得分相同则为平局)
		local win_camp = nil
		if camp_a.score > camp_b.score then 
			win_camp = G3v3Defs.G3V3_CAMP_A
		elseif camp_a.score < camp_b.score then 
			win_camp = G3v3Defs.G3V3_CAMP_B
		else
			win_camp = 0
		end

		vs_info.win_camp = win_camp

		-- 是否平局(平局均为胜利方)
		local is_draw = win_camp == 0
		local win_camp = vs_info.win_camp == G3v3Defs.G3V3_CAMP_A and camp_a or camp_b
		local los_camp = vs_info.win_camp == G3v3Defs.G3V3_CAMP_B and camp_a or camp_b

		if vs_info.win_camp == 0 then
			win_camp = camp_a
			los_camp = camp_b
		end
		
		assert(win_camp ~= los_camp)

		-- 胜利方结算
		G3v3Service:calcIncome( win_camp, is_draw or true,  vs_info.is_star )
		-- 失败方结算
		G3v3Service:calcIncome( los_camp, is_draw or false, vs_info.is_star )

		-- 发送3V3结束
		self:sendFinish(aoi_scene)

		aoi_scene.g3v3 = nil
	end
end

-- 计算收益，只对在线玩家发放奖励
function G3v3Service:calcIncome( camp, is_win, is_star )
	local harm = camp.harm and camp.harm > 0 and camp.harm or 1
	local attack_times = camp.attack_times
	if attack_times == 0 then attack_times = 1 end
	for _, member in pairs(camp.members) do
		member.attack_times_perc = 0 --member.attack_times/attack_times
		local is_enter = member.is_enter
		local character = CharacterService:getCharacterByGcid(member.gcid)
		-- 没有杀人且攻击次数过低，算消极应战
		if not is_star and member.kill_num <= 0 and member.attack_times < G3v3Config.g3v3_attack_limit or
			member.harm/harm < G3v3Config.g3v3_harm_limit then
			member.honour = 0
			member.honour_multi = 0
		else 
			member.honour_multi = is_star and 2 or 1
			if is_enter and character then 
				member.honour = self:_calcHonour(character, is_win, is_star)
			else
				member.honour = 0
			end
		end
		if character then
			G3v3Service:addTimesAndPoint(character, 1, member.honour, is_win and 1 or 2)
		end
	end
end

-- 计算玩家的荣誉奖励
function G3v3Service:_calcHonour( character, is_win, is_star )
	local g3v3 = character.global_pk.g3v3
	if g3v3.p_point >= 800 then return 0 end 	--已经达到上限，不再发放奖励
	
	local is_low = g3v3.p_num > G3v3Config.g3v3_income_low_limit	
	local rewards = G3v3Config.rewards
	local normal_low = is_low and rewards.low or rewards.normal 
	local star_comm = is_star and normal_low.star or normal_low.comm
	local honour = is_win and star_comm.win or star_comm.lost
	
	return honour
end

-- 获取玩家今日已参加的次数及已经获取的积分
function G3v3Service:getTimesAndPoint( character )
	local g3v3 = assert(character.global_pk.g3v3)
	return g3v3.p_num, g3v3.p_point
end

-- 当匹配失败时，base发过来的增加积分
function G3v3Service:b2m_matchFailReward( character, arr_params )
	local honour = G3v3Service:_calcHonour( character, true )
	if honour > G3v3Config.honour_for_match_fail then 
		honour = G3v3Config.honour_for_match_fail
	end
	-- 增加荣誉
	self:addTimesAndPoint(character, 0, honour, 0)
	-- 通知客户端，玩家获得轮空奖励
	G3v3Service:sendMatchFail(character, honour)
end

-- 增加积分
-- win_type  1胜利，2失败，0平局
function G3v3Service:addTimesAndPoint(character, add_num, add_point, win_type)
	local g3v3 = character.global_pk.g3v3
	
	if add_point and 0 < add_point then 
		g3v3.point = g3v3.point + add_point				--总的荣誉值
		g3v3.p_point = (g3v3.p_point or 0) + add_point	--每天获得的荣誉
	end
	if add_num and 0 < add_num then 
		g3v3.p_num = (g3v3.p_num or 0) + add_num
		g3v3.times = (g3v3.times or 0) + add_num
	end

	if win_type == 1 then 
		g3v3.win = (g3v3.win or 0) + add_num
		g3v3.cont_win = (g3v3.cont_win or 0) + add_num
		g3v3.max_cont_win = g3v3.max_cont_win or 0
		if g3v3.cont_win > g3v3.max_cont_win then 
			g3v3.max_cont_win = g3v3.cont_win
		end
	elseif win_type == 2 then
		g3v3.cont_win = 0
	end

	-- 通知游戏服
	local arr_params = {}
	arr_params.add_num = add_num
	arr_params.add_point = add_point
	arr_params.win_type = win_type

	RewardService:reward(Statics.PK_GAME_TYPE_ID_3V3, 0, character.gpid, character.gcid, arr_params)	

	-- 发送玩家积分数据更新
	G3v3Service:sendCh3V3Info(character)	
end

-- base 传来的对战数据
function G3v3Service:b2m_sync( _, vs_info)
	G3v3Dao.scene_insid_2_vs_info[vs_info.space_id] = vs_info
end

-- 通知base 战斗结束 
function G3v3Service:m2b_noticeFinish( vs_info )
	local data = {}
	data.space_id = vs_info.space_id
	data.gcids = {}
	local camps = {vs_info.camp_a, vs_info.camp_b}
	for _, camp in pairs(camps) do
		for _, member in pairs(camp.members) do
			table.insert(data.gcids, member.gcid)
		end
	end
	ServerCall:m2bCall('G3v3Service:m2b_finish', 0, data)
end

-- base 传来的通知进入战场
function G3v3Service:b2m_entryBattle( character, data )
	local space_id = data.space_id
	local line_id = data.line_id
	local camp = data.camp
	local pos = G3v3Service:getRandomCampTransforIn(G3v3Defs.G3V3_SCENE_ID, camp)
	SceneService:moveScene(character, G3v3Defs.G3V3_SCENE_ID, space_id, line_id, pos.x, pos.y)
end

-- 通过场景ID获取BASE传来的对战信息
function G3v3Service:getVsInfoFromDaoBySpaceId( space_id )
	return G3v3Dao.scene_insid_2_vs_info[space_id]
end

-- 查看是否还在战斗中
function G3v3Service:isFighting( aoi_scene )
	local g3v3 = aoi_scene.g3v3
	if not g3v3 or g3v3.is_finish then 
		return false
	end	
	return true
end


-------------------------------------- 发送消息[BEG] --------------------------------------
do	-- 发送任务信息
	local rsp_opcode = opCodes.PKM2C_G3V3_VS_INFO
	local msg_name = "PackG3v3.PKM2C_G3V3_VS_INFO"
	local msg_proto = {id = nil}
	function G3v3Service:sendVsInfo(character, vs_info)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, vs_info, nil, character.gpid)
	end
end

do	-- 发送积分更新信息
	local rsp_opcode = opCodes.PKM2C_G3V3_VS_UPDATE
	local msg_name = "PackG3v3.PKM2C_G3V3_VS_UPDATE"
	local msg_proto = {score_a = 0, score_b = 0}
	function G3v3Service:sendScoreUpdate(aoi_scene)
		local vs_info = aoi_scene.g3v3.vs_info
		local gpids = aoi_scene.g3v3.gpids
		msg_proto.score_a = vs_info.camp_a.score
		msg_proto.score_b = vs_info.camp_b.score
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpids)
	end
end

do	-- 发送战斗结束信息
	local rsp_opcode = opCodes.PKM2C_G3V3_FINISH
	local msg_name = "PackG3v3.PKM2C_G3V3_FINISH"
	local msg_proto = {id = nil}
	function G3v3Service:sendFinish(aoi_scene)
		local vs_info = aoi_scene.g3v3.vs_info
		local gpids = aoi_scene.g3v3.gpids
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, vs_info, nil, gpids)
	end
end


do	-- 发送匹配失败
	local rsp_opcode = opCodes.PKB2C_G3V3_MATCH_FAIL
	local msg_name = "PackG3v3.PKB2C_G3V3_MATCH_FAIL"
	local msg_proto = {honour = 0}
	function G3v3Service:sendMatchFail(character, honour)
		msg_proto.honour = honour
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end


do	-- 发送玩家参与3V3的信息
	local rsp_opcode = opCodes.M2C_G3V3_GET_CH_INFO
	local msg_name = "PackG3v3.M2C_G3V3_GET_CH_INFO"
	local msg_proto = {id = nil}
	function G3v3Service:sendCh3V3Info(character)
		local g3v3 = character.global_pk.g3v3
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, g3v3, nil, character.gpid)
	end
end
	