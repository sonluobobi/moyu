--[[
好友系统 Service
author : jianzhu
date : 2016-04-12
--]]

FriendService = FriendService or {}

local externalMergeUInt = external.mergeUInt
local externalSplitUInt = external.splitUInt
local isTableEmpty = table.isTableEmpty

--[[
	好友系统，参与副本|临危任务|BOSS之家
	gcids 参与活动的所有玩家 gcid 列表

	op_type 对应 FriendDefs 好友参与活动类型
	FriendDefs.FRIEND_ACT_TYPE_ID_SUBLINE	组队通关副本
	FriendDefs.FRIEND_ACT_TYPE_ID_LINWEI	临危任务
]]
function FriendService:onJoinAcitivty(gcids, op_type)
	if not gcids or not op_type or isTableEmpty(gcids) then return end
	local arr_data = {}

	for _, gcid in pairs(gcids) do
		local client_aid, character_id = externalSplitUInt(gcid)
		if client_aid then
			if not arr_data[client_aid] then arr_data[client_aid] = {} end
			local cnt = #arr_data[client_aid]
			arr_data[client_aid][cnt + 1] = gcid
		end
	end

	if isTableEmpty(arr_data) then return end

	for aid, arr_gcid in pairs(arr_data) do
		if #arr_gcid > 1 then 
			self:reward(aid, op_type, arr_gcid)
		end
	end
end

--好友参与活动，发奖接口
function FriendService:reward(aid, op_type, gcids)
	-- 通知游戏服
	local gpid = externalMergeUInt(aid, 0)
	local arr_params = {}
	arr_params.op_type = op_type
	arr_params.gcids = gcids

	RewardService:reward(Statics.PK_GAME_TYPE_ID_FRIENDS_JOIN_ACT, 0, gpid, 0, arr_params)	
end