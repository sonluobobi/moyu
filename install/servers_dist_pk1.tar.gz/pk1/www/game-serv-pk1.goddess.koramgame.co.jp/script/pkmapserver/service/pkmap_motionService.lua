-- vim:fenc=utf-8:ts=2:sw=2:sts=2:et:
--------------------------------------------------------------------------------
-- 对象移动逻辑(新协议)
--
-- . 负责所有 lua game_obj 的移动, 包括 怪物/宠物/玩家/技能?
-- . 支持热更新
--
--    @事件通知
--    @位置更新
--    @停止移动
--    @开始移动
--    @变速
--
-- . SceneGameObj
--       aoi_obj
  --       x/y                  -- 当前坐标, 和 aoi_obj.pos 中是相等的
  --       speed                -- 速度, 米/秒
--       tmps.motion_state    -- 移动状态
--
--          -- 管理信息
--          packet_id           -- debug only
--          fov_count           -- 延迟更新视野计数
--
--          -- 路径信息
--          pos_arr             -- 坐标点数组, [x1, y1, x2, y2, ..., xn, yn]
--          type_arr            -- 类型数组, [t1, t2, t3, ..., tn]
--          pos_num             -- 坐标个数, pos_num = #type_arr = #pos_arr / 2
--
--          -- 当前进度
--          pos_idx             -- 当前所在的线段id, 1-based
--          move_type           -- 当前移动类型: nil/false=停止, 1=移动, 2=跳跃, 3=冲刺, 4=冲撞, ...
--          cur_dist            -- 当前线段总距离
--          cur_moved           -- 当前线段已经移动的距离
--
--          -- 速度信息
--          speed               -- 普通速度, 米/毫秒, 开始移动时设置
--          su_expire           -- 加速 过期时间(ms)
--          su_speed            -- 加速 速度(米/毫秒)
--
--          -- 跟随对象, 会在移动过程中不断检测目标
--          dst_obj              -- 目标对象
--          time_check           -- 下次检测的时间, false/nil=不检测
--          error_span           -- 误差距离
--
--  game_obj ISA SceneGameObj
--
-- author: hproof
-- created: 2012/3/8 9:50:37
-- modify: 2013/11/25 
--
--------------------------------------------------------------------------------
--
--
local Utils = Utils
local opCodes = opCodes
local WorldPacket = WorldPacket
local AoiObjectType = AoiObjectType
local Statics = Statics
local Formula = Formula
local Time = assert(Time)
local CharacterDefs = CharacterDefs
local table = table
local pairs = pairs
local assert = assert
local type = type
local string = string
local math = math
local t_insert = table.insert
local math_sqrt = math.sqrt
local math_ceil = math.ceil
local printf = printf
local errorCodes = errorCodes
local setbit = external.set_bit

local FRAME_MS_CD = Config.FRAME_MS_CD			-- 一帧时长
local MAX_FOLLOW_DIST = 3                       -- 跟随对象时, 当目标对象位移超过该距离后, 强制重新寻径
local MAX_FOLLOW_DIST_SQ = MAX_FOLLOW_DIST ^ 2
local TIME_CHECK_CYCLE = 1000                   -- 条件检测时间周期
--local TIME_CHECK_BY_STOP_CYCLE = 150            -- 停止状态下 条件检测时间周期
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER

MotionService = MotionService or {}
MotionService.traced_obj_id = 0                -- 跟踪调试的 game_obj.id
local getNowUnixUsTime = external.getNowUnixUsTime

local GameObjectService,CharacterService

function MotionService:onAfterLoadLua()	
	GameObjectService = _G.GameObjectService
	CharacterService = _G.CharacterService
end


------------------------------------------------------------------------
--  一般逻辑
------------------------------------------------------------------------


-- 初始化 motion_state 结构
function MotionService:_init_state(game_obj, create_new )
  local state = game_obj.tmps.motion_state
  if not state and create_new then
    state = {
      fov_count = 0,
      last_update_fov_time = 0,
      move_type = false,
    }
    game_obj.tmps.motion_state = state
  end
  return state
end


--- 是否在移动/跳跃中
function MotionService:isMoving(game_obj)
  local state = self:_init_state( game_obj)
  return state and state.move_type 
end


--- 获取移动状态: false/nil=停止, 1=移动, 2=跳跃
function MotionService:getMoveType( game_obj )
  local state = self:_init_state( game_obj)
  return state and state.move_type
end

-- 是否在变速中
function MotionService:isChangeSpeed(game_obj)
	if not game_obj.aoi_type or not game_obj.aoi_id then
		return false
	end
	
	local state = self:_init_state(game_obj)
	if state then
		local su_expire, su_speed = state.su_expire, state.su_speed
		if su_expire and su_speed and su_expire > Time.time_now and su_speed*1000 ~= game_obj.speed then
			return true
		end
	end
	return false
end

------------------------------------------------------------------------
--  事件通知
------------------------------------------------------------------------


--- 当从场景删除时
function MotionService:onRemoveFromscene(game_obj)
  local state = self:_init_state( game_obj )
  if state then
    state.fov_count = 0         -- 已经删除, 不需再参与视野
    state.move_type = false     -- 移动标志
    state.dst_obj = nil         -- 释放引用
  end
end


------------------------------------------------------------------------
--  位置更新
------------------------------------------------------------------------


--- 更新单个对象
-- @param aoi_scene     所在 aoi 场景
-- @param game_obj           场景对象
-- @param state = nil
-- @return 是否在移动中
function MotionService:updateObject(aoi_scene, game_obj)
  local state = game_obj.tmps.motion_state 
  if not state or not state.move_type then return end
  local aoi_obj = game_obj.aoi_obj
  
  -- 最后一次更新位置时间
  local time_now = Time.time_now
  local time_value = time_now - state.last_update_time
  state.last_update_time = time_now
  
  local move_type = state.move_type
  local pos_arr = state.pos_arr
  local type_arr = state.type_arr
  local pos_num = state.pos_num  

  -- 获取速度
  local speed = state.speed 
  if state.su_expire and time_now < state.su_expire then
    speed = state.su_speed    -- 变速期间
  end

  -- 按 速度/时间 移动位置
  local pos_idx, cur_moved, cur_dist = self:_move_by_time(time_value, speed, pos_arr, type_arr, pos_num, state.pos_idx, state.cur_moved, state.cur_dist, aoi_obj.obj_type)

  -- 保存进度
  state.pos_idx = pos_idx
  state.cur_moved = cur_moved
  state.cur_dist = cur_dist
  
  if pos_idx >= pos_num then
    move_type = false
  else
    move_type = type_arr[ pos_idx ]
  end
  state.move_type = move_type

  -- 提取坐标
  local x, y = self:_get_pos( pos_arr, pos_num, pos_idx, cur_moved, cur_dist )

  ------------------------------------------------------------------------
  -- 更新 对象/AOI 位置
  self:_set_pos(aoi_scene, game_obj, aoi_obj, state, x, y, false, time_now)

  
  ------------------------ 怪物追随 玩家 start -------------------------
  local is_stop = not move_type
  local dst_obj, time_check = state.dst_obj, state.time_check
  local time_check_by_stop
  
  local is_ok = true
  if not dst_obj or not dst_obj.aoi_obj or game_obj.aoi_type ~= aoi_type_monster then is_ok = false end
  
  -- 去掉怪物停下来 150MS就反应的逻辑 (已改成立即反映)
  --[[if is_ok and is_stop then
	time_check_by_stop = time_check - TIME_CHECK_CYCLE + TIME_CHECK_BY_STOP_CYCLE
	if time_now < time_check_by_stop then
		is_ok = false
	end
  end
  --]]
  if is_ok and (is_stop or time_now >= time_check) then
    local dst_aoi_obj = dst_obj.aoi_obj
    local dst_obj_x, dst_obj_y = dst_aoi_obj.x, dst_aoi_obj.y
    local error_span, research = state.error_span
    -- a), 移动结束后检测
    if is_stop then
      -- 如果距离 dst_obj 太远, 则重新寻径
      local is_near , real_dist= Formula:isNearbyDistance(x, y, dst_obj_x, dst_obj_y, error_span+0.1)
      if not is_near then
        research = true
      end
      -- b), 移动过程中检测
    else
	  
      state.time_check = time_now + TIME_CHECK_CYCLE
      
	  -- 如果足够接近 dst_obj, 则停止
      if Formula:isNearbyDistance(x, y, dst_obj_x, dst_obj_y, error_span) then
        is_stop = 2
      
	  -- 如果当前目标 dst_x/y 距离 dst_obj 太远, 则重新寻径
      else
        local pos_arr_len = pos_num * 2
        local dst_x, dst_y = pos_arr[pos_arr_len-1], pos_arr[pos_arr_len]
        if not Formula:isNearbyDistanceSquare( dst_x, dst_y, dst_obj_x, dst_obj_y, MAX_FOLLOW_DIST_SQ) then
          research = true
        end
      end
    end
    -- 重新寻径
    if research then
      --print('research', aoi_obj.obj_id, move_type, is_stop, aoi_obj.x, aoi_obj.y, dst_obj_x, dst_obj_y)
      if not self:startMoveToObj( game_obj, dst_obj, error_span ) then
        is_stop = 2           -- 寻径失败, 结束
      else
        is_stop = false       -- 寻径成功
      end
    end
  end -- 检查终止条件
  ------------------------ 怪物追随 玩家 end -------------------------
  
  -- done
  if is_stop then
    local bSendStop = is_stop ~= true   -- 如果非自然停止, 需要广播消息
    self:stop( game_obj, bSendStop, state, aoi_scene, aoi_obj, true )
  end
  return state.move_type

end

local is_normal_game_server = external.isNormalGameServer()
local fov_count_frame1, fov_count_cd1 = 4, 200	--注：速度8米以内
local fov_count_frame2, fov_count_cd2 = 3, 150	--注：速度12米以内
local fov_count_frame3, fov_count_cd3 = 2, 100	--注：速度超过12米
--- 设置对象位置
function MotionService:_set_pos(aoiscene, game_obj, aoiobj, state, x, y, force_update_fov, time_now )
	if aoiobj.x ~= x or aoiobj.y ~= y then
		if not time_now then time_now = Time.time_now end
		
		-- 检查位置是否正确
		if x < 0 or y < 0 then
			error('x='..x .. ', y='..y)
		end	
		if game_obj.aoi_type == aoi_type_player and x == 0 and y == 0 then
			error(game_obj.player_id .. ',x='..x .. ', y='..y)
		end
		local width, height = aoiscene.width, aoiscene.height
		if x >= width or y >= height then
			error('x='..x .. ', y='..y)
		end	
		
		-- 更新坐标
		aoiobj.x, aoiobj.y = x, y

		-- 更新GAME OBJ 对象的x, y 属性
		game_obj.x, game_obj.y = x, y
		--PKTEST
		--if game_obj.aoi_type == aoi_type_player then
		--	external.info('cstartmove snowpos ', game_obj.id,' ',game_obj.player_id,' ', x, ' ',y)
		--end
		--  更新视野
		local fov_count_frame, fov_count_cd = fov_count_frame1, fov_count_cd1
		local speed = state and state.speed or game_obj.speed
		if state then
			if state.su_expire and time_now < state.su_expire and state.su_speed then
				speed = state.su_speed    -- 变速期间
			end
		end
		if speed > 0.008 and speed <= 0.012 then
			fov_count_frame, fov_count_cd = fov_count_frame2, fov_count_cd2
		elseif speed > 0.012 then
			fov_count_frame, fov_count_cd = fov_count_frame3, fov_count_cd3
		end
		local last_update_fov_time = state.last_update_fov_time
		local fov_count = state.fov_count + 1
		if force_update_fov or (fov_count >= fov_count_frame or time_now - last_update_fov_time >= fov_count_cd) then				
			local packet_id = state.packet_id				
			state.fov_count = 0
			state.last_update_fov_time = time_now
			aoiscene:updateFov(aoiobj)
		else
			state.fov_count = fov_count
		end
	end
end

------------------------------------------------------------------------
--  停止移动
------------------------------------------------------------------------


--- 停止移动
-- @param is_must_send=nil  是否强制发送 停止移动 消息给客户端. nil=按默认处理
do

  function MotionService:stop(game_obj, is_must_send)

    local state = self:_init_state( game_obj )
    if state then
      state.dst_obj = nil
	  local is_send = is_must_send
	  
      -- 如果当前在移动中
      if state.move_type then

        -- 判断是否需要发送停止消息. 默认情况下, 如果当前位置不是路径的终点, 则需要发送 stopMove
        if not is_send then
          local aoi_obj = game_obj.aoi_obj
          local pos_arr = state.pos_arr
          local pos_arr_len = state.pos_num * 2
          local dst_x, dst_y = pos_arr[pos_arr_len-1], pos_arr[pos_arr_len]
          is_send = aoi_obj.x ~= dst_x or aoi_obj.y ~= dst_y
        end

        -- 发送消息
        if is_send then
          self:_send_stop_move( game_obj, state )
        end

        -- 清空状态
        state.move_type = false
      end

      -- 更新视野
      if state.fov_count > 0 then
        state.fov_count = 0
        local aoiscene, aoiobj = GameObjectService:getAoiSceneAndAoiObj(game_obj)
        aoiscene:updateFov(aoiobj)
      end

    end
  end
end

--- 立即停止移动
--    当发生错误时, 把对象停止在当前位置
function MotionService:stopByError( game_obj, err_msg, params )
  local aoi_obj = game_obj.aoi_obj
  if err_msg then
    Logger:debug("stopByError aoi_type, aoi_id, id, pos:x-y, msg", game_obj.aoi_type, game_obj.aoi_id, game_obj.id, aoi_obj.x, aoi_obj.y, err_msg )
    --WorldPacket.m2cSendDebugError( err_msg )
  end

  -- 停止
  local state = self:_init_state( game_obj, true )
  state.move_type = false
  state.dst_obj = nil
    
  -- 更新视野
  if state.fov_count > 0 then
    state.fov_count = 0
    local aoiscene = GameObjectService:getAoiScene(game_obj)
    aoiscene:updateFov(aoi_obj)
  end

  --
  self:_send_error_stop( game_obj ) -- 无论之前的状态, 都立即停止
  
  -- TODO:停止联体对象
  
end


--- 设置为停止移动状态
function MotionService:set2stop(game_obj)
	local state = self:_init_state(game_obj, true)
	
	if state.move_type then
		-- 停止
		state.move_type = false
		state.dst_obj = nil
	end
end

--- 直接设置坐标, 必须处于停止状态
function MotionService:setPos(game_obj, x, y, bstop)
  local aoiscene, aoiobj = GameObjectService:getAoiSceneAndAoiObj( game_obj )
  assert( aoiscene, "game_obj not in scene")
  
  if not aoiobj then 
	Logger:error("game_obj not in aoi, maybe it is dead!", game_obj.aoi_type, game_obj.id, game_obj.player_id)
	return
  end

  local state = self:_init_state(game_obj, true)
  if state then
    assert( not state.move_type )
    self:_set_pos(aoiscene,game_obj,aoiobj, state, x, y, true)
    
	if bstop then
      self:stopByError( game_obj )
    end
  end
end

-- 瞬移
function MotionService:shunYi(game_obj, x, y, is_no_send)
	MotionService:set2stop(game_obj)
	MotionService:setPos(game_obj, x, y, not is_no_send)
end

------------------------------------------------------------------------
--  开始移动
------------------------------------------------------------------------


--- 按路径移动
--    含发包
--    按照路径 pos_arr 移动, 不判断阻挡, 直到完成所有路径
--    如果 自己 死亡, 需要外界主动调用 stop
--
-- @param game_obj              可移动对象
-- @param pos_arr          路径数组, 包含当前坐标, game_obj.xy == pos_arr[0]
-- @param move_type         移动类型
--
local function isNan(n)	
	return (not(n>=0)) and (not(n<0))
end
function MotionService:startMoveByPath(game_obj, pos_arr, move_type, packet_id)
	local pos_arr_len = #pos_arr
	local pos_num = pos_arr_len / 2
	local time_now = Time.time_now
	local state = self:_init_state( game_obj, true )
	
	assert(pos_num >= 2, 'pos_arr error')
	assert(move_type, 'move_type error')

	-- 保存速度信息
	state.speed = self:getObjectSpeed( game_obj ) / 1000     -- 米/秒 => 米/毫秒

	if state.speed < 0.00001 then
		print(debug.traceback())
	end
	
	local last_update_time = state.last_update_time or 0
	-- 当前已在移动中
	if last_update_time > 0 and state.move_type and time_now - last_update_time < FRAME_MS_CD*2 then
		-- 最后一次更新位置时间不变
		
	-- 当前在非移动中
	else
		-- 设置最后一次更新位置时间
		last_update_time = time_now
	end
	state.last_update_time = last_update_time
	state.last_update_fov_time = time_now
	
	-- 计算 type_arr
	local type_arr = {}
	for i=1, pos_num do
		type_arr[i] = move_type
	end

	-- 拟合当前路径
	if move_type then
		local aoi_obj = game_obj.aoi_obj
		self:_merge_path( aoi_obj.x, aoi_obj.y, move_type, pos_arr, type_arr )
		--Logger:debug('[startMoveByPath]', aoi_obj.obj_id, Utils.formatPath(pos_arr))
		pos_num = #type_arr
	end
	
	-- 发包
	self:_send_start_move(game_obj, move_type, pos_arr, packet_id)
	
	-- 保存 state
	state.packet_id = packet_id

	state.pos_arr = pos_arr
	state.type_arr = type_arr
	state.pos_num = pos_num

	state.pos_idx = 1
	state.move_type = type_arr[1]
	state.cur_dist = self:_get_distance( pos_arr, 1 )
	state.cur_moved = 0

	state.dst_obj = nil                          -- 停止追踪
	
	-- 设置方向
	if pos_arr_len >= 4 then
		local x1, y1, x2, y2 = pos_arr[pos_arr_len-3], pos_arr[pos_arr_len-2], pos_arr[pos_arr_len-1], pos_arr[pos_arr_len]
		local direction = Formula:getAngleByVector( x2-x1, y2-y1 )
		if isNan(direction) then
			print('getAngleByVectorxx ',pos_arr_len,state.move_type)
			print_r(pos_arr)
			direction = 0
		end
		game_obj.aoi_obj.direction = direction
	end
end



--- 移动到位置(会发包给客户端)
--    移动到目标位置, 直到 目标到达/寻径失败
--    如果 自己 死亡, 需要外界主动调用 stop
--
-- @param game_obj         移动游戏对象
-- @param dst_x/dst_y      目标位置
-- @param error_span=nil   误差距离, 如果>0, 则开启定时检测距离
-- @param move_type=nil
-- @return                 是否成功开始
--
local g_FrameIdx=0

function MotionService:startMoveToPos(game_obj, dst_x, dst_y, error_span, move_type, packet_id,FrameIdx)
	if FrameIdx then
		g_FrameIdx=FrameIdx
	end

	local aoi_obj = game_obj.aoi_obj

	-- 调整 error_span, 使得调用 get_path 中的误差更小
	if not error_span or error_span < 0.2 then error_span = 0 else error_span = error_span - 0.1 end

	-- 设置为移动中
	if not move_type then move_type = 1 end

	-- 获取路径
	local pos_arr
	if move_type == 1 then
		-- 走路的路径
		local aoi_scene = assert(GameObjectService:getAoiScene( game_obj ))    
		pos_arr = aoi_scene:getPath( aoi_obj.x, aoi_obj.y, dst_x, dst_y, error_span)   
	else
		-- 跳跃的路径
		pos_arr = { aoi_obj.x, aoi_obj.y, dst_x, dst_y }
	end 

	-- 按路径移动
	if pos_arr and #pos_arr >= 4 then
		self:startMoveByPath(game_obj, pos_arr, move_type, packet_id)
		return true, pos_arr
	end
	
	printf("Can not find path, type:%d, id:%d, (%d,%d)->(%d,%d)", game_obj.aoi_type, game_obj.id, aoi_obj.x, aoi_obj.y, dst_x, dst_y)
end

--- 移动到对象
--    一直追踪对象, 直到 目标到达/寻径失败
--    如果 自己/目标 死亡, 需要外界主动调用 stop
--
-- @param game_obj              主动对象, sceneGameObj
-- @param dst_obj          被跟随对象, sceneGameObj
-- @param error_span       误差距离
-- @return                 是否成功开始
--
function MotionService:startMoveToObj(game_obj, dst_obj, error_span )
  assert(game_obj and dst_obj)

  if error_span < 2 then error_span = 2 end

  -- 移动到目标位置
  local aoi_obj = dst_obj.aoi_obj
  local ret = self:startMoveToPos(game_obj, aoi_obj.x, aoi_obj.y, error_span, 1 )

  -- 设置追踪信息
  if ret then
    local state = self:_init_state( game_obj )
    state.dst_obj = dst_obj
    state.time_check = Time.time_now + TIME_CHECK_CYCLE
    state.error_span = error_span

    return true
  end

end


--- 开始客户端请求的移动
--    负责 合法性验证
--    负责 路径拟合, 从对象当前位置, 拟合到新起点中
--
-- @param game_obj
-- @param params
-- @return 是否开始移动
--
function MotionService:startMoveByClient( aoiscene, game_obj, move_type, pos_arr, packet_id )

  -- 如果暂停, 则不处理
  if aoiscene.is_pause then
    self:stopByError(game_obj, errorCodes.SCENE_ERROR_CAN_NOT_MOVE)
    return false
  end

  -- 其它接口
  local is_player = game_obj.aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
  if is_player then
    local ok, err = CharacterService:canDo(game_obj, CharacterDefs.DO_TYPE_FOR_MOVE)
    if not ok then return false, self:stopByError( game_obj, err ) end
  end

  -- 验证参数
  local ok, err = self:_check_start_move( aoiscene, move_type, pos_arr )
  if not ok then return false, self:stopByError( game_obj, err ) end

  -- 开始移动
  self:startMoveByPath(game_obj, pos_arr, move_type, packet_id)
  --PKTEST
  --if game_obj.aoi_type == aoi_type_player then
	--external.info('cstartmove started ', game_obj.id,' ', game_obj.player_id,' ', pos_arr[1], ' ',pos_arr[2])
  --end
  return true

end

-- 冲撞
function MotionService:chongci(game_obj, target_pos_x, target_pos_y)
	local pos_arr = {game_obj.x, game_obj.y, target_pos_x, target_pos_y}
	
	-- 开始移动
	self:startMoveByPath(game_obj, pos_arr, MotionDefs.TYPE_CHONG_ZHUANG, nil)
end


------------------------------------------------------------------------
--  变速
------------------------------------------------------------------------

--- 改变真实速度
-- @param add_percent  (在原始速度基础上)增加的百分比 1=100%
-- @param duration  持续时间(ms)
function MotionService:addRealSpeedByPercent( game_obj, add_percent, duration )
  local speed = self:getObjectSpeed( game_obj ) * (1 + add_percent)
  local expire = Time.time_now + duration
  self:changeSpeed( game_obj, speed , expire ,true )
end


--- 临时改变速度
-- @param add_percent  (在原始速度基础上)增加的百分比 1=100%
-- @param duration  持续时间(ms)
function MotionService:addSpeedByPercent( game_obj, add_percent, duration )
  local speed = self:getObjectSpeed( game_obj ) * (1 + add_percent)
  local expire = Time.time_now + duration
  self:changeSpeed( game_obj, speed , expire )
end

-- 注：主角只在base_speed基础上加
function MotionService:addSpeedByPercForBase( game_obj, add_percent, duration )
  local speed = self:getObjectSpeed( game_obj ) + self:getObjectBaseSpeed(game_obj) * add_percent
  local expire = Time.time_now + duration
  self:changeSpeed( game_obj, speed , expire )
end

--- 取消临时修改的速度(如果是正常过期结束不需调用)
function MotionService:resumeSpeed( game_obj )
  self:changeSpeed( game_obj, 0, 0 )
end


--- 临时改变速度, 并自动过期, 用于 技能/BUFF 等引起的加速效果
-- @param speed  新的速度(秒/米)
-- @param expire  过期时间(毫秒)
function MotionService:changeSpeed( game_obj, speed, expire ,ischange_realspeed )
  --speed = math.round( speed ) --处理小数后三位和客户端不统一的问题
  -- 保存信息
  local state = self:_init_state( game_obj, true )
  
  if ischange_realspeed then
    game_obj.speed = speed
  end
  state.su_expire = expire
  state.su_speed = speed / 1000     -- m/s -> m/ms
  --if state.move_type then
    if speed == 0 then
      local aoi_obj = game_obj.aoi_obj
	  state.su_stop_x = aoi_obj.x
      state.su_stop_y = aoi_obj.y
    end
  --end

  -- 广播发包
  self:_send_change_speed( game_obj, state )

end

--- 获取对象速度
-- @return speed, 米/秒
do
  local monster_type = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
  local idle_state = Statics.GAME_OBJECT_STATUS_ID_IDLE
  function MotionService:getObjectSpeed( game_obj )
    --game_obj 冗余
    if game_obj.aoi_type == monster_type and game_obj.tmps.now_state == idle_state then
      return game_obj.speed
    end
    return game_obj.speed
  end
    
  function MotionService:getObjectBaseSpeed( game_obj )
    return game_obj.base_speed or game_obj.speed
  end
end


------------------------------------------------------------------------
--  发包
------------------------------------------------------------------------

-- 局部变量
local writeByte = FastPacket.writeByte
local writeShort = FastPacket.writeShort
local writeUShort = FastPacket.writeUShort
local writeInt = FastPacket.writeInt
local writeUInt = FastPacket.writeUInt
local writeCoord = FastPacket.writeCoord
local writeLong = FastPacket.writeLong
local writePath = FastPacket.writePath
local writeFloat1000 = FastPacket.writeFloat1000


local enableTraceBin=FastPacket.enableTraceBin
--local setWritable=FastPacket.setWritable

fastpacket_WritePath=fastpacket_WritePath

-- 发送 packet 
function MotionService:_send_packet( packet, opcode, pids, packet_id )
  local pack = WorldPacket:newClientPacket(opcode, packet_id, pids, packet:size()+4 )
  pack:writeFastPacketRaw(packet)
  WorldPacket:m2cSendBinaryPacket(pack)
end


-- 写入场景信息
function MotionService:_write_scene_info( game_obj, packet )
  writeInt( packet, game_obj.aoi_obj.space_id )
  writeInt( packet, game_obj.aoi_id )
end

-- 写入速度信息
function MotionService:_write_speed( game_obj, state, packet )
  -- speed
  writeFloat1000(packet, (state.speed or 0)  * 1000)
  -- su_speed
  if state.su_expire and Time.time_now < state.su_expire then
    writeByte( packet, 1 )
    writeLong( packet, state.su_expire )
    writeFloat1000( packet, state.su_speed * 1000 )
    if state.su_speed == 0 then
      writeCoord( packet, state.su_stop_x )
      writeCoord( packet, state.su_stop_y)
    end
  else
    writeByte( packet, 0 )
  end
end


local packet = FastPacket(1024)

--- 发送 变速
local M2C_SCENE_CHANGE_SPEED = opCodes.M2C_SCENE_CHANGE_SPEED
function MotionService:_send_change_speed( game_obj, state )
  local gpids = GameObjectService:getFovGPids(game_obj)
  if gpids then
	   WorldPacket:resetWritePacket(packet,opCodes.M2C_SCENE_CHANGE_SPEED)
	  do
		self:_write_scene_info( game_obj, packet )
		self:_write_speed( game_obj, state, packet )
	  end
	  self:_send_packet( packet, M2C_SCENE_CHANGE_SPEED, gpids, nil )
  end
end

--- 发送 开始移动包
local M2C_SCENE_START_MOVE_TO_DEST = opCodes.M2C_SCENE_START_MOVE_TO_DEST
local M2C_SCENE_START_MOVE_TO_DEST_PET = opCodes.M2C_SCENE_START_MOVE_TO_DEST_PET
local M2C_SCENE_START_MOVE_TO_DEST_MONSTER = opCodes.M2C_SCENE_START_MOVE_TO_DEST_MONSTER
local M2C_SCENE_START_MOVE_TO_DEST_PLAYER = opCodes.M2C_SCENE_START_MOVE_TO_DEST_PLAYER
local M2C_SCENE_STOP_MOVE = opCodes.M2C_SCENE_STOP_MOVE
local g_bDebugMove=0 ---分别统计人宠怪的走路消息流量时才需要
local op_code_startmov=M2C_SCENE_START_MOVE_TO_DEST

local AOI_OBJECT_TYPE_ID_PLAYER = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER	-- 角色
local AOI_OBJECT_TYPE_ID_PET = AoiObjectType.AOI_OBJECT_TYPE_ID_PET			-- 幻兽

function MotionService:_send_start_move( game_obj, move_type, pos_arr, packet_id, bMovFinish )  
	if g_bDebugMove==1 then
		if bMovFinish then
			op_code_startmov=M2C_SCENE_MOVE_FINISHED
		else	
			local aoi_type = game_obj.aoi_type		  
			if aoi_type==AOI_OBJECT_TYPE_ID_PLAYER then
				op_code_startmov=M2C_SCENE_START_MOVE_TO_DEST_PLAYER
			elseif aoi_type==AOI_OBJECT_TYPE_ID_PET then
				op_code_startmov=M2C_SCENE_START_MOVE_TO_DEST_PET
			else
				op_code_startmov=M2C_SCENE_START_MOVE_TO_DEST_MONSTER
			end	
		end	 
	end
	
	if not move_type or move_type == 0 then
		print(debug.traceback())
	end
	
	local aoi_obj = game_obj.aoi_obj

	local pids = GameObjectService:getFovGPids(game_obj)
	local cnt=0
	if pids then  
		cnt=#pids
		local state = self:_init_state(game_obj, true)
		WorldPacket:resetWritePacket(packet,op_code_startmov)--opCodes.M2C_SCENE_START_MOVE_TO_DEST
   
		  
		-- scene
		self:_write_scene_info( game_obj, packet )
		-- path info
		writeByte(packet, move_type )

		fastpacket_WritePath(packet,pos_arr)

		-- speed info
		self:_write_speed( game_obj, state, packet )  

		self:_send_packet( packet, op_code_startmov, pids, packet_id )
	end
end


--- 异常终止, 立即停止pos_num_oldlocal
local M2C_SCENE_STOP_MOVE = opCodes.M2C_SCENE_STOP_MOVE
function MotionService:_send_error_stop( game_obj )
  local pids = GameObjectService:getFovGPids(game_obj)
  if pids then
    local aoi_obj = game_obj.aoi_obj
    WorldPacket:resetWritePacket(packet,M2C_SCENE_STOP_MOVE)
 
    do
      self:_write_scene_info( game_obj, packet )
      writeCoord( packet, aoi_obj.x )
      writeCoord( packet, aoi_obj.y )
    end
    --print('game_obj stop',game_obj.nick)
    --print( debug.traceback() )
    self:_send_packet( packet, M2C_SCENE_STOP_MOVE, pids )
	
	if game_obj.aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER then
		Logger:debug('MotionService:_send_error_stop::', game_obj.nick, BufferService:isInStatus(game_obj, EffectType.giddiness), FightService:isSkillLocked(game_obj), debug_traceback(2, 7))
	end
  end
end

--- 发送停止移动
local AOI_OBJECT_TYPE_ID_PLAYER  = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local AOI_OBJECT_TYPE_ID_PET = AoiObjectType.AOI_OBJECT_TYPE_ID_PET
function MotionService:_send_stop_move(game_obj, state)
	-- 如果是 主角/侠客 则改为立即停止.(客户端不会立即拉瞬移)
	local aoi_type = game_obj.aoi_type
	if aoi_type == AOI_OBJECT_TYPE_ID_PLAYER or aoi_type == AOI_OBJECT_TYPE_ID_PET then
		self:_send_error_stop( game_obj )
	else
		-- 停止 = 特殊的移动
		local aoi_obj = game_obj.aoi_obj
		local x, y = aoi_obj.x, aoi_obj.y
		local pos_arr = {x, y, x, y}
		self:_send_start_move( game_obj, 1, pos_arr,0,true)
	end
end


local fastpacket_WritePath=fastpacket_WritePath

-- 写入路径信息
function MotionService:writeWays( game_obj, packet )

  local state = self:_init_state( game_obj, true )
  if not state.move_type then
    writeByte(packet, 0)
	return false
  end		
  writeByte(packet, 1)
  
  local pos_arr = state.pos_arr
  local type_arr = state.type_arr
  local pos_len = state.pos_num * 2

  -- 路径信息
  writeShort(packet, state.pos_idx)
  --writeShort(packet, pos_len)
  --for i=1, pos_len do
  --   writeFloat(packet, pos_arr[i] )
  --end		
  fastpacket_WritePath(packet,pos_arr)
  for i=1, pos_len/2 do
    writeByte(packet, type_arr[i] )
  end

  -- 速度
  self:_write_speed( game_obj, state, packet)

  -- done

  return true
end

------------------------------------------------------------------------
--  GM 命令
------------------------------------------------------------------------


--- 增加速度
-- @param duration=3 持续时间(秒)
-- @return ok, err
function MotionService:gm_speedUp( character, duration )
  local speed = self:getObjectSpeed( character ) * 3
  local expire = Time.time_now + duration * 1000
  self:changeSpeed( character, speed, expire )
  return true
end


------------------------------------------------------------------------
--  辅助
------------------------------------------------------------------------

local SPEED_RATE = MotionDefs.SPEED_RATE
local SPEED_FIX = MotionDefs.SPEED_FIX
-- 移动, 返回 pos_idx, cur_moved, cur_dist
function MotionService:_move_by_time(time_value, speed, pos_arr, type_arr, pos_num, pos_idx, cur_moved, cur_dist, aoi_type )
  --print('time_value=',time_value,pos_num, pos_idx, cur_moved, cur_dist)
  -- 移动 time_value 个时间量
  while time_value > 0 do
    local move_type = type_arr[ pos_idx ]   -- 获取移动类型
    local move_speed = SPEED_FIX[move_type] or (speed * SPEED_RATE[move_type])  -- 不同移动类型的速度加成
	local move_dist = move_speed * time_value   -- 本次移动的距离    
    --print('move_dist=',move_dist,move_speed,time_value)    
    if move_dist <= 0 then break end

    -- 加上移动距离
    cur_moved = cur_moved + move_dist           -- 更新已移动距离
    local move_overflow = cur_moved - cur_dist    -- 溢出距离
    --print('cur_moved=',cur_moved,cur_dist) 
    if move_overflow < 0 then break end     -- 当前线段未完成

    -- 调整到下一个线段
    pos_idx = pos_idx + 1
    cur_moved = 0

    -- 总路径完成
    if pos_idx >= pos_num then
      cur_dist = 0
      break
    else
      cur_dist = self:_get_distance(pos_arr, pos_idx)
    end

    -- 继续移动
    time_value = move_overflow / move_speed
  end

  --print('end=',pos_idx, cur_moved, cur_dist)
  --print('')

  -- ok
  return pos_idx, cur_moved, cur_dist

end


-- 获取该线段的距离
function MotionService:_get_distance( pos_arr, pos_idx )
  local j = pos_idx * 2 - 1
  local x1, y1, x2, y2 = pos_arr[j], pos_arr[j+1], pos_arr[j+2], pos_arr[j+3]
  local dx, dy = x1 - x2, y1 - y2
  return (dx*dx + dy*dy)^0.5
end


-- 返回坐标, 返回 x, y
function MotionService:_get_pos( pos_arr, pos_num, pos_idx, cur_moved, cur_dist )
  local j = pos_idx * 2 - 1

  -- end
  if pos_idx >= pos_num then
    local x = pos_arr[j]
    local y = pos_arr[j+1]
    return x, y
  end

 if cur_dist == 0 then
 	cur_moved,cur_dist = 0,1
 end

  -- 计算插值
  local rate = cur_moved / cur_dist
  local x1, y1, x2, y2 = pos_arr[j], pos_arr[j+1], pos_arr[j+2], pos_arr[j+3]
  local x = x1 + (x2 - x1) * rate
  local y = y1 + (y2 - y1) * rate
  return x, y

end

-- 拟合路径
function MotionService:_merge_path( cur_x, cur_y, move_type, pos_arr, type_arr)
	-- 如果路径只有2个点，且2个点相同位置，则代表角色移动已停止，则不拟合路径
	--if #pos_arr == 4 and pos_arr[1] == pos_arr[3] and pos_arr[2] == pos_arr[4] then
	--	return
	--end
	
	-- 拟合路径
	local x0, y0 = pos_arr[1], pos_arr[2]
	if cur_x ~= x0 or cur_y ~= y0 then
		pos_arr[1] = cur_x
		pos_arr[2] = cur_y
		type_arr[1] = move_type
	end
end


--- 验证是否可移动
-- @return ok, err
function MotionService:_check_start_move( aoiscene, move_type, pos_arr )
  --do return true end
  if not move_type or not pos_arr or #pos_arr < 4 then
    return false, errorCodes.COMMON_PARAM_ERROR
  end

    -- 跳跃
  if move_type == 2 then
    local x1, y1, x2, y2 = pos_arr[1], pos_arr[2], pos_arr[3], pos_arr[4]
    -- 跳跃距离
    local max_jump_dist = CharacterDefs.CHARACTER_DEFAULT_JUMP_DISTANCE
    if not Formula:isNearbyDistance(x1, y1, x2, y2, max_jump_dist) then
      return false, errorCodes.SCENE_JUMP_TOO_FAR
    end
    -- 目标位置是否可跳跃
    if not aoiscene:canJump( x1, y1, x2, y2 ) then
      return false, errorCodes.SCENE_MOVE_ERROR_TARGET
    end
  -- 移动
  elseif not aoiscene:checkPath( pos_arr ) then
    return false, errorCodes.SCENE_MOVE_ERROR_PATH
  end

  return true
end

-- 帧更新
do
	local objss_upv = {}
	local tbl_empty = {}
	
	function MotionService:update(time_now, aoi_scene, objs_player, objs_monster, objs_pets)
		objss_upv[1] = objs_player or tbl_empty
		objss_upv[2] = objs_monster or tbl_empty
		objss_upv[3] = objs_pets or tbl_empty
		
		local i = 0
		for _, game_objs in ipairs(objss_upv) do
			for aoi_id, game_obj in pairs(game_objs) do
				i = i + 1
				local aoi_obj = game_obj.aoi_obj
				local tmps = game_obj.tmps
				
				if not tmps.is_pause or tmps.pause_expire <= time_now then
					-- 更新移动信息
					local motion_state = tmps.motion_state
					if motion_state and motion_state.move_type then
						self:updateObject(aoi_scene, game_obj, aoi_obj, motion_state)
					end
				end
			end
		end
		
		--if i > 20 then print('MotionService:update err i', i) end
	end			
end

function MotionService:cancelDstObj(game_obj)
	local state = self:_init_state(game_obj)
	state.dst_obj = nil
end
