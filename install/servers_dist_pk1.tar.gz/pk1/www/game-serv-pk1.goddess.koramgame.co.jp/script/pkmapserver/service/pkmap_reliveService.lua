--[[
复活service
author : suwin zhong
date : 2014-11-10
--]]

ReliveService = ReliveService or {}
local time_wheel = ReliveDao.time_wheel
local ostime = os.time

-- 复活角色
--@is_revival 是否原地复活
function ReliveService:characterRelive(character, is_revival)
	local scene_id = character.scene_id
	local scene_base = SceneBaseService:getSceneBaseById(scene_id)
	local relive_locate_type = scene_base.relive_locate_type or 0
	
	-- 玩家已不再AOI里面，不能再复活
	if not GameObjectService:isVisible(character) then
		return
	end
	
	-- 帮战初赛中次数用完不能复活
	if GangBattleChusaiService:isInGangChusai( scene_id ) 
	and not GangBattleChusaiService:isCanRelive(character) then
		return 
	end

	-- 帮玩家满血
	self:characterFullHp(character)
	
	-- 给复活的玩家增加保护状态(5秒保护)
	CharacterService:protect(CharacterDefs.PROTECT_TYPE_ID_FOR_RELIVE, character, CharacterDefs.SAFE_TIME_FOR_RELIVE)

	-- 普通复活不用调用(原地复活不用调用)(小蒋提供接口)(一定要放在最后面调用)(等策划的复活文档)
	if is_revival then 
		-- 增加强制复活次数
		self:addRevivalCounter( character )
	else
		if character.level >= 30 then 
			SceneService:setReliverPosition(character)
		end
	end

	-- 发送广播
	self:sendReliveMsg(character)	

	-- 显示出战幻兽(小蒋提供接口)
	if not ShengcunService:isInShengcun( scene_id ) then
		ChPetService:showFightPet(character)	
	else
		ShengcunService:afterRelive( character )
	end
end

-- 服务器定时复活玩家(每1秒执行一次)
function ReliveService:onTimer( time_now )
	-- 没有需要复活的，直接跳过
	if not ReliveDao.is_time_wheel_init then 
		return
	end	
	
	-- 开始处理复活逻辑
	local now_time = time_now/1000
	for i=1, 2 do
		local timestamp = self:getCurTime()		
		if now_time >= timestamp then
			-- 获取当前格子中的所有玩家 
			local gcids = self:getCurPlayers ()

			-- 对在线、死亡、复活时间与当前格子时间相同的玩家复活
			for _, gcid in pairs(gcids) do
				local character = CharacterService:getCharacterByGcid(gcid)
				if character and FightService:isDead(character) then 
					local tmps = character.tmps
					local normal_relive_expire = tmps.normal_relive_expire or 0
					-- 只复活玩家身上复活时间与当前复活时间位置相同的
					if normal_relive_expire == timestamp - 5 then 
						-- 角色复活
						ReliveService:characterRelive(character)
					end
				end
			end
			-- 转动轮子
			self:toNextSeconds()
		end
	end
end

-- 添加玩家到复活列表
function ReliveService:addRelivePlayer( character )
	if not ReliveDao.is_time_wheel_init then 
		self:initTimeWheel()
	end

	local scene_id = character.scene_id
	local scene_base = SceneBaseService:getSceneBaseById(scene_id)
	local free_relive_time_long = 10 --scene_base.free_relive_time_long or 10
	if character.level < 30 then 
		free_relive_time_long = 6
	end

	-- 副本的改为15秒后复活
	if SublineService:isSubline(scene_id, scene_base) then 
		free_relive_time_long = 99
	end

	local now_time = ostime()
	local normal_relive_expire = now_time + free_relive_time_long
	self:interAddRelivePlayer(character.gcid, normal_relive_expire)

	-- 这段为测试代码
	do
		local tmps = character.tmps
		if tmps.normal_relive_expire and tmps.normal_relive_expire > 0 and  normal_relive_expire - tmps.normal_relive_expire <= 2 then 
			Logger:info('短时间内死亡两次', character.nick, debug_traceback(1, 10))
		end
	end
	
	local tmps = character.tmps
	tmps.normal_relive_expire = normal_relive_expire

	-- 如果是3V3场景，则查看原地复活次数
	tmps.force_relive_expire = 0
	local scene_id = character.scene_id
	if G3v3Service:isIn3v3( scene_id ) or 
       TianmoService:isTianmo(scene_id) then 
		local force_relive_counter = character.tmps.force_relive_counter or 0
		if force_relive_counter > 5 then 
			tmps.force_relive_expire = now_time + 5
--		elseif force_relive_counter == 1 then
--			tmps.force_relive_expire = now_time + 5
		end 
	end

--	ReliveService:sendReliveInfo(character)
end

-- 清除原地复活计数器
function ReliveService:clearRevivalCounter( character )
	character.tmps.force_relive_counter = 0
end

-- 增加原地复活次数
function ReliveService:addRevivalCounter( character )
	local scend_id = character.scene_id 
	local tmps = character.tmps
	tmps.force_relive_counter = (tmps.force_relive_counter or 0) + 1
end

------------------------------ 复活时间轮逻辑 [BEG] ------------------
-- 获取当前时间
function ReliveService:getCurTime(  )
	return time_wheel.timestamp
end

function ReliveService:interAddRelivePlayer( gcid, relive_timestamp )
	local timestamp = time_wheel.timestamp
	local cur_index = time_wheel.cur_index
	local diff = relive_timestamp - timestamp + 5
	
	local this_index = (diff + cur_index - 1) % ReliveDefs.RELIVE_TIME_WHEEL_SIZE + 1
	table.insert(time_wheel.data_list[this_index], gcid)
end

-- 获取当前时间的玩家列表
function ReliveService:getCurPlayers(  )
	local cur_index = time_wheel.cur_index
	return time_wheel.data_list[cur_index]
end

-- 转到下一秒
function ReliveService:toNextSeconds(  )
	local cur_index = time_wheel.cur_index
	time_wheel.timestamp  = time_wheel.timestamp + 1
	time_wheel.data_list[cur_index] = {}
	time_wheel.cur_index = cur_index % ReliveDefs.RELIVE_TIME_WHEEL_SIZE + 1
end

function ReliveService:initTimeWheel(  )
	time_wheel.data_list = {}			--需要复活的数据
	time_wheel.timestamp = os.time() + 1--当前位置的时间(此时间为即将复活的玩家)
	time_wheel.cur_index = 1			--当前位置
	time_wheel.size = ReliveDefs.RELIVE_TIME_WHEEL_SIZE
	for i=1, time_wheel.size do 		--初始化好，供直接使用
		table.insert(time_wheel.data_list, {})
	end
	ReliveDao.is_time_wheel_init = true
end
------------------------------ 复活时间轮逻辑 [END] ------------------

-- 复活使用道具或者元宝
function ReliveService:useEquipOrGold( character, arr_params)
	local equip_id = EquipDefs.FUNCTION_EQUIP_RELIVE_EQUIP
	local relive_need_gold = ReliveDefs.RELIVE_NEED_GOLD_NUM
	-- 判断是否有复活药水
	local relive_equip_num = ChItemPackageService:getEquipNumByStackEid(character, equip_id)
	if relive_equip_num > 0 then 
		-- 使用道具复活
		-- 扣除一个道具
		local need_equip_num = 1
		local arr_equip_num = {[equip_id] = need_equip_num}
		ChItemPackageService:delStackEquipsEx(character, arr_equip_num, ChEquipTraceLogDefs.EQUIP_TRACE_OP_ID_RELIVE, {})
	else
		local need_gold = relive_need_gold
		local character_gold = CharacterService:getGold(character)
		if need_gold > character_gold then
			return false, errorCodes.CHARACTER_GOLD_NO_ENOUGH
		end
		
		-- 扣除元宝
		PlatFormService:delGold(character, need_gold, PlatformDefs.EQUIP_ID_FORM_RELIVE)
		
		-- 记录元宝消耗日志
		local memo = '复活'
		DbLogService:logUseGold(character, DbLogDefs.SERVICE_ID_FOR_RELIVE, Statics.MONEY_TYPE_ID_FOR_GOLD, need_gold, character_gold, memo, arr_params)
	end
	return true
end

-- 角色满血变空闲
function ReliveService:characterFullHp(character)
	-- 复活满血
	character.hp = character.max_hp

	-- 如果有合体幻兽
	local character_max_hp2 = character.max_hp2 -- 内层幻兽
	if 0 < character_max_hp2 then
		character.hp2 = character_max_hp2
	end
	local character_max_hp3 = character.max_hp3 -- 外层幻兽
	if 0 < character_max_hp3 then
		character.hp3 = character_max_hp3
	end

	-- 角色变成空闲状态
	CharacterService:changeState(character, Statics.GAME_OBJECT_STATUS_ID_IDLE)
end


do -- 广播复活
	local rsp_opcode = opCodes.M2C_RELIVE_RELIVE
	local msg_name = "PackRelive.M2C_RELIVE_RELIVE"
	function ReliveService:sendReliveMsg(character)
		-- 广播
		local arr_gpids = GameObjectService:getFovGPids(character)
		
		local ret_data = {}
		ret_data.opcode			 = opCodes.M2C_RELIVE_RELIVE
		ret_data.scene_ins_id	 = character.space_id
		ret_data.aoi_id			 = character.aoi_id
		ret_data.hp			 	 = character.hp
		ret_data.hp2		 	 = character.hp2
		ret_data.hp3		 	 = character.hp3
		ret_data.protect_expire  = character.tmps.relive_protect_expire or 0
--		WorldPacket:m2cSendOK(ret_data, nil, arr_gpids)

		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, ret_data, nil, arr_gpids)
	end
end

do -- 发送玩家复活信息
	local rsp_opcode = opCodes.M2C_RELIVE_GET_INFO
	local msg_name = "PackRelive.M2C_RELIVE_GET_INFO"
	local data = {normal_relive_expire = 0}
	function ReliveService:sendReliveInfo(character)
		local msg_proto
		if FightService:isDead(character) then 
			msg_proto = character.tmps
		else
			msg_proto = data
		end
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do -- 发送PK服复活扣除道具成功
	local rsp_opcode = opCodes.M2C_RELIVE_PK_RELIVE
	local msg_name = "PackRelive.M2C_RELIVE_PK_RELIVE"
	local data = {}
	function ReliveService:sendPkReliveSuc(character)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end
