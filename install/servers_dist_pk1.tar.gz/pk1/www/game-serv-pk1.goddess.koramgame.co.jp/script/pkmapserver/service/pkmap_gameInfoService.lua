--[[
游戏的各种全局信息
author : suwin zhong
date : 2013-02-05
--]]

GameInfoService = GameInfoService or {}

-- 获取经验系数
function GameInfoService:getExpRadix( character, sort_id )
	local ch_lv = character.level
	local world_level = character.world_level or 0
	return WorldLevelDefs:getExpRadix(sort_id, world_level, ch_lv)
end