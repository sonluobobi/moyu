--[[
野外场景 service
author : xingzeng.jiang
date : 2014-07-15
--]]

local Formula = Formula
local OutdoorConfig = OutdoorConfig
local OutdoorDefs = OutdoorDefs
local Statics = Statics
local AoiObjectType = AoiObjectType
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local TransferDotDefs = TransferDotDefs
local table = table

OutdoorBossService = OutdoorBossService or {}
setmetatable(OutdoorBossService, SceneServiceInterface)

local SceneService = SceneService
function OutdoorBossService:onAfterLoadLua()
	SceneService = _G.SceneService
	OutdoorConfig = _G.OutdoorConfig
end

function OutdoorBossService:checkEnterScene(character, aoi_scene, dst_scene_base)
	return true
end

function OutdoorBossService:checkLeaveScene(character, aoi_scene)
	return true
end

-- 设置阵营
function OutdoorBossService:setZhenying(aoi_scene, character)
	self:setZhenyingDefault(aoi_scene, character)
end

function OutdoorBossService:setZhenyingDefault(aoi_scene, character, is_send)
	local team = TeamService:getTeamByCid(character.gcid)
	local aoi_obj = character.aoi_obj
	local zhenying = team and Utils.getZhenYingId(team.id) or -1 * aoi_obj.obj_id
	
	GameObjectService:updateZhenying(aoi_scene, character, zhenying, is_send)	
end

function OutdoorBossService:onInitScene(character, aoi_scene)
	aoi_scene.outdoor = {}	--与野外相关内容

	-- 默认场景初始化
	SceneService:onInitSceneDefault(character, aoi_scene)
	-- 初始化中心区怪物
	OutdoorBossService:initCenterBossMonster(aoi_scene)

	return true
end

-- 当怪物被杀
-- character 	击杀者
-- monsters		被杀怪物数组
do
	function OutdoorBossService:onKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
		-- 中心区BOSS被杀的逻辑
		OutdoorBossService:centerbossOnKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
	end
end

function OutdoorBossService:getEquipsByDropids(drop_pack_ids)
	if drop_pack_ids then
		local drop_equips = {}
		for _, drop_pack_id in pairs(drop_pack_ids) do
			local drop_pack = DropPackBaseDao[drop_pack_id]
			if not drop_pack then
				Logger:error('[DropItemsService:getMonsterDropEquips] The drop_pack is nil', monster_id, drop_pack_id, DropPackBaseDao)
			else
				local drop_equips_t = DropItemsService:_calcDrop(drop_pack)
				if drop_equips_t then
					for equip_id, equip_num in pairs(drop_equips_t) do
						drop_equips[equip_id] = (drop_equips[equip_id] or 0) + equip_num
					end
				end
			end
		end
		return drop_equips
	end	
end

function OutdoorBossService:onPlayerHarm(fighter, arr_character_harm)
	if fighter.aoi_type == aoi_type_player then
		SafeModeService:onPlayerHarm(fighter, arr_character_harm)
	end
end

-- 当怪物受伤害
-- arr_kill_monster_aoi_id {aoi_id=harm, ....}
function OutdoorBossService:onMonsterHarm(character, arr_kill_monster_aoi_id)
	-- 中心区仇恨值
	self:centerbossOnMonsterHarm(character, arr_kill_monster_aoi_id)
end

-- 当玩家被杀
function OutdoorBossService:onPlayerKilled( fighter, arr_kill_player_aoi_id )	
	-- 红名 
	RednameService:onPlayerKilled(fighter, arr_kill_player_aoi_id)

	OutdoorBossService:centerbossOnPlayerKilled( fighter, arr_kill_player_aoi_id)

	-- 通知成就系统
	AchieveService:onCheckAchieve(fighter, AchieveDefs.ACHIEVE_SORT_ID_CNT_KILL, table.sizeTable(arr_kill_player_aoi_id))
end

function OutdoorBossService:update(now_time_msec, aoi_scene)
end

-- 每500毫秒更新
function OutdoorBossService:update500ms(now_time_msec, aoi_scene )
	-- 检测BOSS怪生成
	OutdoorBossService:checkCreateBossMonster(aoi_scene, now_time_msec/1000)	

	if Time.is_5s_start then	

		-- 中心区BOSS更新逻辑
		OutdoorBossService:centerbossUpdate5s( aoi_scene )		
	end	
end

-- 每500毫秒更新
function OutdoorBossService:updateForNoPlayer(now_time_msec, aoi_scene )
	OutdoorBossService:update500ms(now_time_msec, aoi_scene )
end

function OutdoorBossService:beforeEnterScene(character, aoi_scene)
	return true
end

-- 离开场景时
function OutdoorBossService:afterLeaveScene(character, aoi_scene, leave_type)
	-- 清空仇恨值
	OutdoorBossService:centerbossAfterLeaveScene( character, aoi_scene)
end

function OutdoorBossService:checkFight(aoi_scene, attacker, target)
  return true
end

do
function OutdoorBossService:getBirthPos(aoi_scene, character)
	return false
end

-- 获取复活点
-- return 	bool:is_back_to_mcity,	true:回到主城，false:本场景复活
--			x, y					本场景复活的X，Y坐标点
	local xiangxian_2_transferids = {
		900303,
		900304,
		900305,
		900306,
		900307,
		900308,
		900309,
	}
	function OutdoorBossService:getRelivePos(character, aoi_scene)
		local transfer_base_id = xiangxian_2_transferids[math.random(1, #xiangxian_2_transferids)]
		local x, y  = SceneAoiService:getRandomTransferIn( aoi_scene.scene_id, transfer_base_id )
		return false, x, y
	end

end

-- 进入场景之后
function OutdoorBossService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	-- 发送中心BOSS仇敌信息
	OutdoorBossService:sendBossCenterEnemy(aoi_scene, character)
end

-- 判断玩家是否在野外
function OutdoorBossService:isInOutdoorBoss( scene_base_id )
	return scene_base_id == 20006
end

-- base发过来的房间列表
function OutdoorBossService:b2m_syncRoom( _, datas )
	local spaceid_2_layer = {}
	OutdoorBossDao.spaceid_2_layer = spaceid_2_layer
	OutdoorBossDao.lays_rooms = datas
	for layer, rooms in pairs(datas) do
		for _, space_id in pairs(rooms) do
			spaceid_2_layer[space_id] = layer
		end
	end
end

-- 设置玩法数据
function OutdoorBossService:initWanfaAoiData(character, aoi_scene)
	local safe_mode_info = character.safe_mode_info
	local redname_status = RednameService:getRednameStatus(safe_mode_info.redname)
	WanfaAoiService:setWanfaAoiData(character, 'redname_status', redname_status)
	WanfaAoiService:setWanfaAoiData(character, 'safe_mode', safe_mode_info.safe_mode)
end

function OutdoorBossService:initCenterBossMonster(aoi_scene)
	local lay_conf = OutdoorConfig.lay_conf
	local monster_pos_conf = OutdoorConfig.monster_pos_conf

	-- 获取当前所有的层级
	local space_id = aoi_scene.space_id
	local layer = OutdoorBossDao.spaceid_2_layer[space_id]
	local this_layer_conf = lay_conf[layer]
	aoi_scene.outdoor.next_create_boss_timestamp = OutdoorConfig:getNextBossTime()
	aoi_scene.outdoor.boss_conf = this_layer_conf.boss_monsters
	aoi_scene.outdoor.bosses = {}
	aoi_scene.outdoor.bosses_hash = {}

	-- 如果当前时间为BOSS时间，则立即生成BOSS
	local _20dianSec = Time:get02newSec()
	if _20dianSec < 2 * 60 * 60 or _20dianSec > 9 * 60 * 60 then
		aoi_scene.outdoor.next_create_boss_timestamp = os.time() - 1
	end

	-- 刷新下次更新时间
	OutdoorBossService:centerbossUpdate5s( aoi_scene )
end

-- 检查创建中心区域的精英怪
function OutdoorBossService:checkCreateBossMonster(aoi_scene, timestamp)
	local outdoor = aoi_scene.outdoor
	if outdoor.boss_conf and outdoor.next_create_boss_timestamp <= timestamp then 
		local next_create_boss_timestamp = aoi_scene.outdoor.next_create_boss_timestamp
		outdoor.next_create_boss_timestamp = OutdoorConfig:getNextBossTime(next_create_boss_timestamp)
		local bosses = outdoor.bosses
		local boss_conf = outdoor.boss_conf
		local times_monster = boss_conf.times_monster
		-- 计算出现在需要用的配置
		local now_time = os.time()
		local _0din_sec = Time:get02newSec()	-- 今天0到跟离现在的时间
		local max_0dian = 999999
		local max_conf = nil
		for conf_0dian, time_conf in pairs(times_monster) do
			if conf_0dian >= _0din_sec and conf_0dian < max_0dian then 
				max_0dian = conf_0dian
				max_conf = time_conf
			end
		end

		for monster_id, poses in pairs(max_conf) do
			for _, pos in pairs(poses) do
				if bosses[_] then
					local aoi_id= bosses[_].aoi_obj and bosses[_].aoi_obj.obj_id
					local monster = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
					
					-- 判断是否是原来的那只怪
					if monster == bosses[_] then 
						--已经死亡的设置为立即被清除
						if GameObjectService:isDead(monster) then
							monster.tmps.delete_time = Time:getDelayMsTime(0)
							bosses[_] = nil
						end
						-- 未死亡，直接使用之前的怪
					else
						bosses[_] = nil	
					end
				end
				if not bosses[_] then
					local x, y, direction = pos.x, pos.y, pos.direction
					if pos.is_rand then
						local boss_center_pos, size_in, size_out = OutdoorConfig.boss_pk_area_circle_center_pos, OutdoorConfig.boss_rand_r_in, OutdoorConfig.boss_rand_r_out 
						x, y = OutdoorBossService:randPosOnCircle( aoi_scene )--math.randPosOnCircle( boss_center_pos[1], boss_center_pos[2], size_in,  size_out)
					end
					local monster = MonsterService:dymCreateMonster(aoi_scene, monster_id, nil, x, y, direction)
					bosses[_] = monster
					monster.tmps.is_outdoor_boss = true   -- 记录是中心区BOSS
					if OutdoorConfig:isBigBoss(monster_id) then 
						monster.tmps.is_outdoor_big_boss = true 	--记录是中心区大BOSS
						monster.tmps.outdoor_boss_tmp_hate = {}
						monster.tmps.outdoor_boss_create_time = os.time()
						monster.tmps.outdoor_boss_killed_time = nil
						-- 设置血量
						local level = OutdoorBossService:centerbossGetBossLv( monster_id )
						if level ~= 0 then 
							monster.max_hp = monster.max_hp * (1 + level * 0.15)
							monster.hp = monster.max_hp
							local update_data = {
								hp = monster.hp,
								max_hp = monster.max_hp
							}
							SceneService:sendAppearUpdate(aoi_scene, monster, update_data)				
						end
					end
				end
			end
		end
	end
end
do
	local can_random_poses = nil
	function OutdoorBossService:randPosOnCircle( aoi_scene )
		if not can_random_poses then 
			can_random_poses = {}
			local boss_center_pos, size_in, size_out = OutdoorConfig.boss_pk_area_circle_center_pos, OutdoorConfig.boss_rand_r_in, OutdoorConfig.boss_rand_r_out 
			local center_x = boss_center_pos[1]
			local center_y = boss_center_pos[2]
			for x=center_x-size_out, center_x + size_out do
				for y=center_y-size_out, center_y + size_out do
					local lenth = (x-center_x)^2 + (y-center_y)^2
					if aoi_scene:canPass(x,y) and lenth >= size_in^2 and lenth <= size_out^2 then 
						table.insert(can_random_poses, {x=x,y=y})
					end
				end
			end
		end
		local pos = can_random_poses[math.random(1,#can_random_poses)]
		return pos.x, pos.y
	end
end

----------------------------------- 中间BOSS仇恨值相关 【BEG】------------------------------------------------------------------------
-- base广播来的BOSS等级信息
function OutdoorBossService:centerbossB2MSyncBossLv( _, data )
	local monster_id_2_lv = OutdoorBossDao.monster_id_2_lv
	for monster_id, lv in pairs(data) do
		monster_id_2_lv[monster_id] = lv
	end
end

function OutdoorBossService:centerbossGetBossLv( monster_id )
	return OutdoorBossDao.monster_id_2_lv[monster_id] or 0
end

-- 当BOSS受到伤害时
function OutdoorBossService:centerbossOnMonsterHarm( character, arr_kill_monster_aoi_id )
	local aoi_scene = GameObjectService:getAoiScene(character)
	-- 计算精英怪的伤害
	for monster_aoi_id, harm in pairs(arr_kill_monster_aoi_id) do
		local monster = GameObjectService:getGameObjectByAoiId(aoi_scene, monster_aoi_id)
		if monster.tmps.is_outdoor_big_boss then 
			local outdoor_boss_tmp_hate = monster.tmps.outdoor_boss_tmp_hate
			outdoor_boss_tmp_hate[character.gcid] = (outdoor_boss_tmp_hate[character.gcid] or 0) + harm
		end
	end	
end

function OutdoorBossService:centerbossOnPlayerKilled( fighter, arr_kill_player_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	local outdoor = aoi_scene.outdoor
	local bosses = outdoor.bosses
	
	if not bosses then return end

	for _, killed_aoi_id in pairs(arr_kill_player_aoi_id) do
		local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, killed_aoi_id)
		local gcid = killed_player.gcid
		for _, monster in pairs(bosses) do
			local outdoor_boss_tmp_hate = monster.tmps.outdoor_boss_tmp_hate
			if outdoor_boss_tmp_hate and outdoor_boss_tmp_hate[gcid] then 
				outdoor_boss_tmp_hate[gcid] = math.ceil(outdoor_boss_tmp_hate[gcid]/2)
			end
		end
	end
end

function OutdoorBossService:centerbossAfterLeaveScene( character, aoi_scene )
	local aoi_scene = GameObjectService:getAoiScene(character)
	local outdoor = aoi_scene.outdoor
	local bosses = outdoor.bosses
	
	if not bosses then return end

	local gcid = character.gcid
	local is_update_enemy = false
	for _, monster in pairs(bosses) do
		if monster.tmps.outdoor_boss_tmp_hate and monster.tmps.outdoor_boss_tmp_hate[gcid] then
			local max_gcid = self:getMaxHarmGcid(monster) or 0

			
			if max_gcid == character.gcid then
				monster.tmps.outdoor_boss_tmp_hate[gcid] = nil
				is_update_enemy = true
			else
				monster.tmps.outdoor_boss_tmp_hate[gcid] = nil
			end
		end
	end
	if is_update_enemy then
	    self:updateBossCenterEnemy(aoi_scene, true)
	end
end

do
local scene_sort_ids = {
	SceneDefs.SCENE_SORT_ID_NORMAL_MCITY, 
	SceneDefs.SCENE_SORT_ID_TOLLGATE,
}
function OutdoorBossService:centerbossOnKilledMonster(character, arr_kill_monster_id, arr_kill_monster_aoi_id)
	
	local aoi_scene = GameObjectService:getAoiScene(character)

	for _, monster_id in pairs(arr_kill_monster_id) do
		local aoi_id = arr_kill_monster_aoi_id[_]
		local monster = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)

		if monster and monster.tmps.is_outdoor_boss then

			-- 巨炎魔宝箱的ID
			local big_boss_baoxiang_eid = OutdoorConfig:getBaoxiangByMonsterId( monster_id )

			local aoi_scene = GameObjectService:getAoiScene(character)

			-- 计算击杀者奖励
			local outdoor = aoi_scene.outdoor
			local boss_id_2_drops = assert(outdoor.boss_conf.boss_id_2_drops)
			local reward_equips = self:getEquipsByDropids(boss_id_2_drops[monster_id])
			if reward_equips and next(reward_equips) then
				local equip_id = nil
				for _, _2 in pairs(reward_equips) do
					equip_id = _
					break
				end		
				if monster.tmps.is_outdoor_big_boss then 
					equip_id = big_boss_baoxiang_eid
					reward_equips = {[equip_id] = 1}
				end				

				local equip_base = EquipBaseService:getEquipBaseById(equip_id)
				local monster_base = MonsterBaseService:getMonsterBaseById(monster_id)
				local params = {}
				table.insert(params, character.nick)
				table.insert(params, MonsterDefs:getMonsterFmtByEid( monster_id ))
				table.insert(params, EquipDefs:getEquipFmtByEid( equip_base.id ))
				-- 本场景广播
				NoticeService:sysMsgScene(character.space_id, OKMsgCodes.NOTICE_OUTDOOR_YANMO, params)
				-- 发到击杀者所在游戏服(只在关卡和主城)
				local area_id = external.splitUInt(character.gpid)
				NoticeService:sysMsgWorld2GameSrv(area_id, OKMsgCodes.NOTICE_OUTDOOR_YANMO, params, scene_sort_ids)		

				-- 弹窗
				ScorePopupService:openScorePopup(character, ScorePopupDefs.SCOREPOPUP_NODE_JISHA)

				monster.tmps.killer_nick = character.nick
				local update_data = {}
				update_data.killer_nick = character.nick
				GameObjectService:appearDirty(monster)
				SceneService:sendAppearDetailUpdate(aoi_scene, monster, update_data)

				Logger:info('【野外BOSS被杀】', character.nick, equip_id, character.player_id)

				-- 查看奖励数量是否已达上限
				local equips = self:checkBigBossBaoxiang(character, reward_equips)
				if next(equips) then
					RewardService:reward(Statics.PK_GAME_TYPE_ID_OUTDOOR_BOSS_RWD, 0, character.gpid, character.gcid, reward_equips)
				end
			end		


			-- 强制生成BOSS敌人信息
			self:updateBossCenterEnemy(aoi_scene, true)		
			self:sendBossCenterEnemy(aoi_scene)


			-- 记录被杀时间
			monster.tmps.outdoor_boss_killed_time = os.time()

			-- 巨炎魔掉落宝箱与金币袋
			if monster.tmps.is_outdoor_big_boss then
				-- 获取区域内的有伤害的玩家数
				local r_2 = OutdoorConfig.boss_pk_area_circle_R ^ 2
				local player_nums = 0
				local boss_x = monster.x
				local boss_y = monster.y
				for gcid, _ in pairs(monster.tmps.outdoor_boss_tmp_hate) do
					local character = CharacterService:getCharacterByGcid(gcid)
					if character then 
						local len_2 = (character.x - boss_x)^2 + (character.y - boss_y)^2
						if len_2 <= r_2 then
							player_nums = player_nums + 1
						end

						-- 宝箱洒落范围内的玩家，获得保底宝箱
						if len_2 <= 100 then 
							-- 同时发送保底奖励
							-- 如果还有保底次数，且还有宝箱次数，发奖
							local en_count_bd, counter_bd = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_BAODI)
							local en_count_bx, counter_bx = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_RWD)
							if en_count_bd > 0 and en_count_bx > 0 then 
								local equips = {[big_boss_baoxiang_eid] = 1}
								RewardService:reward(Statics.PK_GAME_TYPE_ID_OUTDOOR_BOSS_RWD, 0, character.gpid, character.gcid, equips)
								CounterService:addcount(character, counter_bd)
								CounterService:addcount(character, counter_bx)							
							end
						end
					end
				end
				local drop_equips = OutdoorConfig:getDropEquips( monster_id, player_nums )
				DropItemsService:monsterDrop(aoi_scene, monster, drop_equips, character)	
			end

			-- 以下为归属奖励
			local max_gcid = monster.tmps.is_outdoor_big_boss and OutdoorBossService:getMaxHarmGcid( monster )
			local max_character = max_gcid and CharacterService:getCharacterByGcid(max_gcid)
			if max_character then
				-- 广播
				local team = TeamService:getTeamByGCid( max_gcid )
				local reward_equips = {[big_boss_baoxiang_eid] = 1}
				local equip_base = EquipBaseService:getEquipBaseById(EquipDefs.BIG_YANMO_BAOXIANG)
				local equip_base2 = EquipBaseService:getEquipBaseById(23130001)
				local monster_base = MonsterBaseService:getMonsterBaseById(monster_id)
				local params = {}					
				table.insert(params, max_character.nick)
				table.insert(params, MonsterDefs:getMonsterFmtByEid( monster_id ))
				table.insert(params, EquipDefs:getEquipFmtByEid( equip_base.id ) .. ',' .. EquipDefs:getEquipFmtByEid( equip_base2.id ))
				local notice_id = team and OKMsgCodes.NOTICE_OUTDOOR_JUYANMO_KILLED_HATE_TEAM or OKMsgCodes.NOTICE_OUTDOOR_JUYANMO_KILLED_HATE
			
				-- 本场景广播
				NoticeService:sysMsgScene(max_character.space_id, notice_id, params)
				-- 发到击杀者所在游戏服(只在关卡和主城)
				local area_id = external.splitUInt(max_character.gpid)
				NoticeService:sysMsgWorld2GameSrv(area_id, notice_id, params, scene_sort_ids)

				-- 归属奖励多一个宝物宝箱
				reward_equips[23130001] = 1

				-- 发奖
				if team then 
					for _, member in pairs(team.members) do
						local character = CharacterService:getCharacterByGcid(member.gcid)
						if character then 
							local equips = self:checkBigBossBaoxiang(character, reward_equips)
							if next(equips) then
								RewardService:reward(Statics.PK_GAME_TYPE_ID_OUTDOOR_BOSS_MAX_HARM_RWD, 0, member.gpid, member.gcid, equips)
								ScorePopupService:openScorePopup(character, ScorePopupDefs.SCOREPOPUP_NODE_JISHA)
							end
							Logger:info('【野外BOSS归属】', member.nick, member.pid)
						end
					end
				else
					local character = max_character
					local equips = self:checkBigBossBaoxiang(character, reward_equips)
					if next(equips) then
						RewardService:reward(Statics.PK_GAME_TYPE_ID_OUTDOOR_BOSS_MAX_HARM_RWD, 0, max_character.gpid, max_character.gcid, equips)					
						ScorePopupService:openScorePopup(character, ScorePopupDefs.SCOREPOPUP_NODE_JISHA)
					end
					Logger:info('【野外BOSS归属】', max_character.nick, max_character.player_id)
				end
			end			
		end
	end 
end
end

function OutdoorBossService:checkBigBossBaoxiang( character, reward_equips )
	for equip_id, equip_num in pairs(reward_equips) do
		if OutdoorConfig:isBigBossBaoxiang( equip_id ) then 
			local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_RWD)
			if not en_count or en_count <= 0 then 
				reward_equips = table.lightCopyTable(reward_equips)	
				reward_equips[equip_id] = nil
				WorldPacket:m2cSendErr(nil, nil, character.gpid, errorCodes.OUTDOOR_BIG_BOSS_BAOXIANG, {counter.now_storeup_count})
			else
				CounterService:addcount(character, counter, nil, en_count > equip_num and equip_num or en_count)	
			end
			break
		end
	end
	return reward_equips		
end

function OutdoorBossService:getMaxHarmGcid( monster )
	if not monster.tmps.outdoor_boss_tmp_hate then 
		return 
	end
	local max_gcid, max_harm 
	for gcid, harm in pairs(monster.tmps.outdoor_boss_tmp_hate) do
		if not max_harm or max_harm < harm then 
			max_gcid = gcid
			max_harm = harm
		end
	end	
	return max_gcid
end

-- 中心BOSS5秒钟更新逻辑
function OutdoorBossService:centerbossUpdate5s( aoi_scene )
	-- 中间的精英怪
	local outdoor = aoi_scene.outdoor
	local bosses = outdoor.bosses
	for _, monster in pairs(bosses) do
		if monster and monster.hp > 0 then 
			local update_data = {
				hp = monster.hp
			}
			SceneService:sendAppearUpdate(aoi_scene, monster, update_data)				
		end
	end
	-- 中心区BOSS是否到达死亡检测时间
	local outdoor = aoi_scene.outdoor
	local next_check_kill_boss_time = outdoor.next_check_kill_boss_time or 0
	local now_time = os.time()

	if next_check_kill_boss_time and now_time > next_check_kill_boss_time then 

		-- 每个小时的第三分钟检测
		outdoor.next_check_kill_boss_time = now_time - now_time % 3600 + 3600 + 720 
		
		self:centerbossSyncCenterBossKillInfo(aoi_scene)
	end

	OutdoorBossService:sendBossCenterEnemy(aoi_scene)
end

-- 传给base，本场景BOSS的击杀情况
function OutdoorBossService:centerbossSyncCenterBossKillInfo( aoi_scene )
	local outdoor = aoi_scene.outdoor
	local bosses = outdoor.bosses or {}
	local boss_kill_info = {}
	for _, monster in pairs(bosses) do
		local monster_id = monster.monster_base.id
		if monster.tmps.is_outdoor_big_boss then
			local outdoor_boss_create_time = monster.tmps.outdoor_boss_create_time
			local outdoor_boss_killed_time = monster.tmps.outdoor_boss_killed_time
			if outdoor_boss_create_time then
				boss_kill_info[monster_id] = boss_kill_info[monster_id] or {}
				if not outdoor_boss_killed_time then 
					boss_kill_info[monster_id].not_killed = (boss_kill_info[monster_id].not_killed or 0) + 1
				elseif outdoor_boss_killed_time - outdoor_boss_create_time <= 60 then
					boss_kill_info[monster_id].killed_1 = (boss_kill_info[monster_id].killed_1 or 0) + 1
				elseif outdoor_boss_killed_time - outdoor_boss_create_time <= 120 then 
					boss_kill_info[monster_id].killed_2 = (boss_kill_info[monster_id].killed_2 or 0) + 1
				else
					boss_kill_info[monster_id].not_killed = (boss_kill_info[monster_id].not_killed or 0) + 1
				end

				monster.tmps.outdoor_boss_create_time = nil
			end
		end
	end
	--- 同步到BASE
	if next(boss_kill_info) then 
		ServerCall:m2bCall('OutdoorBossService:m2b_syncCenterBossIsKilled', 0, boss_kill_info)
	end
end

function OutdoorBossService:updateBossCenterEnemy(aoi_scene, is_force)
	--Logger:info('OutdoorBossService:updateBossCenterEnemy')
	local outdoor = aoi_scene.outdoor
	local next_center_boss_info_time = outdoor.next_center_boss_info_time
	if is_force or not next_center_boss_info_time or next_center_boss_info_time <= os.time() then 
		outdoor.next_center_boss_info_time = os.time() + 5
		outdoor.center_boss_info = {}
		local bosses = outdoor.bosses
		table.clearTable(outdoor.center_boss_info)

		for _, monster in pairs(bosses) do
			if not GameObjectService:isDead(monster) and monster.tmps.outdoor_boss_tmp_hate then 
				local outdoor_boss_tmp_hate = monster.tmps.outdoor_boss_tmp_hate
				local max_gcid, max_harm = nil
				for gcid, harm in pairs(outdoor_boss_tmp_hate) do
					if not max_gcid or harm > max_harm then 
						max_gcid = gcid
						max_harm = harm
					end
				end
				if max_gcid then 
					local center_boss_enemy = {}
					-- BOSS信息
					center_boss_enemy.boss_aoi_id = monster.aoi_obj.obj_id
					center_boss_enemy.boss_id = monster.monster_base.id
					center_boss_enemy.boss_x = monster.aoi_obj.x
					center_boss_enemy.boss_y = monster.aoi_obj.y

					-- 仇敌信息
					local enemy_ch = CharacterService:getCharacterByGcid(max_gcid)
					center_boss_enemy.enemy_aoi_id = enemy_ch.aoi_obj.obj_id
					center_boss_enemy.x = enemy_ch.aoi_obj.x
					center_boss_enemy.y = enemy_ch.aoi_obj.y
					center_boss_enemy.nick = enemy_ch.nick
					center_boss_enemy.prof = enemy_ch.prof
					center_boss_enemy.vip = enemy_ch.vip
					center_boss_enemy.level = enemy_ch.level
					center_boss_enemy.gender = enemy_ch.gender
					table.insert(outdoor.center_boss_info, center_boss_enemy)

					MonsterService:setMyTargeter2(monster, enemy_ch)
				else
					local center_boss_enemy = {}
					-- BOSS信息
					center_boss_enemy.boss_aoi_id = monster.aoi_obj.obj_id
					center_boss_enemy.boss_id = monster.monster_base.id
					center_boss_enemy.boss_x = monster.aoi_obj.x
					center_boss_enemy.boss_y = monster.aoi_obj.y

					-- 仇敌信息
					center_boss_enemy.enemy_aoi_id = 0
					center_boss_enemy.x = 0
					center_boss_enemy.y = 0
					center_boss_enemy.nick = ''
					center_boss_enemy.prof = 0
					center_boss_enemy.vip = 0
					center_boss_enemy.level = 0
					center_boss_enemy.gender = 0
					table.insert(outdoor.center_boss_info, center_boss_enemy)
				end
			end
		end	
	end

end



do -- 发送中心BOSS仇敌信息
	local rsp_opcode = opCodes.M2C_OUTDOOR_CENTER_BOSS_ENEMY
	local msg_name = "PackOutdoor.M2C_OUTDOOR_CENTER_BOSS_ENEMY"
	local data = {center_boss_info = {}}
	function OutdoorBossService:sendBossCenterEnemy(aoi_scene, character)
		self:updateBossCenterEnemy(aoi_scene)
		local gpids = character and character.gpid or GameObjectService:getGPids(aoi_scene)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, aoi_scene.outdoor, nil, gpids)
	end	
end

----------------------------------- 中间BOSS仇恨值相关 【END】------------------------------------------------------------------------
