--[[
场景事件
author : xingzeng.jiang
date : 2014-07-15
--]]

SceneEventService = SceneEventService or {}

local AoiObjectType = AoiObjectType
local SceneEventBaseDao = SceneEventBaseDao
local Time = Time
local pairs = pairs
local assert = assert
local WorldPacket = WorldPacket
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER

--注册impl service
do
	--- 在这里定义 SceneService
	local _scene_service_interfces_map = {
		[ SceneDefs.SCENE_SORT_ID_OUTDOOR ] = "OutdoorService", 		-- 野外
		[ SceneDefs.SCENE_SORT_ID_OUTDOOR_BOSS ] = "OutdoorBossService", 		-- 野外BOSS
		[ SceneDefs.SCENE_SORT_ID_SUBLINE ] = "SublineService", 		-- 多人副本
		[ SceneDefs.SCENE_SORT_ID_SUBLINE_EMENG ] = "SublineService", 	-- 多人噩梦副本
		[ SceneDefs.SCENE_SORT_ID_3V3 ] 	= "G3v3Service", 			-- 3V3
		[ SceneDefs.SCENE_SORT_ID_TIANMO ] 	= "TianmoService", 			-- 天魔(BOSS之家)
		[ SceneDefs.SCENE_SORT_ID_TIANMO_PRE ] = 'TianmoPreService',	-- 天魔(BOSS之家)准备厅
		[ SceneDefs.SCENE_SORT_ID_DAOJJ_WAR ] = 'DaojianjueService',	-- 刀剑(帝国争锋)
		[ SceneDefs.SCENE_SORT_ID_GANG_CHUSAI ] = 'GangBattleChusaiService',	-- 帮战初赛
		[ SceneDefs.SCENE_SORT_ID_GANG_BATTLE] = "GangBattleNewService", 	--军团战
		[ SceneDefs.SCENE_SORT_ID_FINALWAR] = "FinalWarService",  --末日之战
		[ SceneDefs.SCENE_SORT_ID_GLOBAL_ARENA] = "GlobalArenaService",  --诸神之战
		[ SceneDefs.SCENE_SORT_ID_SHENGCUN_WAR ] = 'ShengcunService',	-- 生存挑战
		[ SceneDefs.SCENE_SORT_ID_SHENGCUN_PRE ] = 'ShengcunService',	-- 生存挑战
		[ SceneDefs.SCENE_SORT_ID_LOVER_TEMPLE ] = 'LoverTempleService',	-- 爱情圣殿
	}
	
	--- 根据 scenebase 获取场景对应的 SceneServiceInterface
	-- @return SceneServiceInterface, name
	function SceneEventService:getSceneService(scenebase)
		local name = _scene_service_interfces_map[ scenebase.scene_sort_id ]
		if not name then name = 'SceneImplDefaultService' end
		local service = assert(_G[name])
		return service, name
	end
end

-- 初始化场景
function SceneEventService:onInitScene(character, aoi_scene)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	service:onInitScene(character, aoi_scene)
end

-- 进入场景前
function SceneEventService:beforeEnterScene(character, aoi_scene, is_reconnect)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	service:beforeEnterScene(character, aoi_scene, is_reconnect)
end

-- 进入场景后
function SceneEventService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	service:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
end

-- 离开场景之前
function SceneEventService:beforeLeaveScene(character, aoi_scene, leave_type)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	service:beforeLeaveScene(character, aoi_scene, leave_type)
end

-- 离开场景之后
function SceneEventService:afterLeaveScene(character, aoi_scene, leave_type)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	service:afterLeaveScene(character, aoi_scene, leave_type)
end

-- 离开场景检查
function SceneEventService:checkLeaveScene(character, aoi_scene)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	local is_ok, err_id, err_params
	if service.checkLeaveScene then
		is_ok, err_id, err_params = service:checkLeaveScene(character, aoi_scene)
		assert(is_ok ~= nil)
	else
		-- 弃权, 统一按true处理
		is_ok = true
	end
	return is_ok, err_id, err_params
end

-- 进入场景前检查
function SceneEventService:checkEnterScene(character, aoi_scene, dst_scene_base)
	local service = SceneEventService:getSceneService(dst_scene_base)
	assert(service)
	local is_ok, err_id, err_params
	if service.checkEnterScene then
		is_ok, err_id, err_params = service:checkEnterScene(character, aoi_scene, dst_scene_base)
		assert(is_ok ~= nil)
	else
		-- 弃权, 统一按true处理
		is_ok = true
	end
	return is_ok, err_id, err_params
end

-- 场景被移动时
function SceneEventService:checkMoveToDest(character, aoi_scene)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	local is_ok, err_id, err_params
	if service.checkMoveToDest then
		is_ok, err_id, err_params = service:checkMoveToDest(character, aoi_scene)
		assert(is_ok ~= nil)
	else
		-- 弃权, 统一按true处理
		is_ok = true
	end
	return is_ok, err_id, err_params
end

-- 客户端进入场景之后
function SceneEventService:afterClientEnterScene(character, aoi_scene)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	return service:afterClientEnterScene(character, aoi_scene)
end

-- 查找怪物攻击目标
function SceneEventService:findOneFightTarget(aoi_scene, monster)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	return service:findOneFightTarget(aoi_scene, monster)
end
function SceneEventService:hasHandleFindOneFightTarget(aoi_scene)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	return service.findOneFightTarget and true or false
end

-- 获取复活点
-- return 	bool:is_back_to_mcity,	true:回到主城，false:本场景复活
--			x, y					本场景复活的X，Y坐标点
function SceneEventService:getRelivePos(character, aoi_scene)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	return service:getRelivePos(character, aoi_scene)
end

-- 是否可以攻击（群攻时）
function SceneEventService:canGroupAttack(aoi_scene, attacker, target)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	return service:canGroupAttack(aoi_scene, attacker, target)
end
function SceneEventService:hasHandleCanGroupAttack(aoi_scene)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	return service.canGroupAttack and true or false
end

-- 是否可以攻击
-- attacker		攻击者对象
-- target		攻击目标(可为空)
-- return is_ok:bool, err_id:int
function SceneEventService:checkFight(aoi_scene, attacker, target)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	return service:checkFight(aoi_scene, attacker, target)
end

-- 是否用场景自身判断规则来检查是否可攻击
function SceneEventService:hasHandleCheckFight(aoi_scene)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	assert(service)
	return service.checkFight and true or false
end

-- 设置阵营(目前只设置玩家阵营)
function SceneEventService:setZhenying(aoi_scene, game_obj)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	if service and service.setZhenying then
		service:setZhenying(aoi_scene, game_obj)
	end
end

-- 设置出生点(重连的时候不会调用到，登录、切换场景会调用到)
-- true/false, x, y
function SceneEventService:getBirthPos(aoi_scene, game_obj)
	local service = SceneEventService:getSceneService(aoi_scene.scene_base)
	if service and service.getBirthPos then
		return service:getBirthPos(aoi_scene, game_obj)
	end
	return false
end

do
	local MonsterBaseDao = MonsterBaseDao
	local Monster = Monster
	local AoiObject = AoiObject
	local SceneService
	local floor = math.floor
	
	--每500MS更新
	function SceneEventService:update500ms(time_now, aoi_scene)
		-- 通用更新逻辑
		
		-- 调用个玩法逻辑
		local service = self:getSceneService(aoi_scene.scene_base)
		if service then
			service:update500ms(time_now, aoi_scene)
		end
		
		return true
	end
	
	--每秒更新
	function SceneEventService:update(time_now, aoi_scene)
		-- 通用更新逻辑
		SceneBufferService:update(time_now, aoi_scene)
		ItemObjService:update(time_now, aoi_scene)
		
		-- 调用个玩法逻辑
		local service = self:getSceneService(aoi_scene.scene_base)
		if service then
			service:update(time_now, aoi_scene)
		end
		
		return true
	end
	
	--每秒更新 (没有玩家的时候调用)
	function SceneEventService:updateForNoPlayer(time_now, aoi_scene)
		-- 调用个玩法逻辑
		local service = self:getSceneService(aoi_scene.scene_base)
		if service and service.updateForNoPlayer then
			service:updateForNoPlayer(time_now, aoi_scene)
		end
		
		return true
	end
end


