--[[
采集系统servuce
author : xingzeng
date : 2012-03-27
]]--

local ItemDefs = assert(ItemDefs)

GatherService = GatherService or {}

local AoiObjectType = AoiObjectType
local AoiObject = AoiObject
local SceneService, GameObjectService
local ItemDefs = ItemDefs

function GatherService:onAfterLoadLua()
	SceneService = _G.SceneService
	GameObjectService = _G.GameObjectService
end

local func_id_to_service_name = {
	[ ItemDefs.ITEM_FUNC_ID_SCENE_BUFFER_GATHER ] = 'SceneBufferService', -- 场景BUFF采集
}

--- 开始采集
-- @return ok, err
function GatherService:startGather(character, aoi_id)
	-- 判断玩家状态
	local ok, err = CharacterService:canDo(character, CharacterDefs.DO_TYPE_FOR_GATHER)
	if not ok then return false, err end

	-- 检查目标对象
	local ok, err, aoi_scene, itemobj, service = self:_check_target_valid(character, aoi_id)
	if not ok then return false, err end

	-- 检查距离
	if not Formula:isNearbyDistanceSquare(character.x, character.y, itemobj.x, itemobj.y, 3*3) then
		return false, errorCodes.COMMON_OUT_OF_DISTANCE 
	end

	-- 开始采集, 调用 service
	local ok, err, time_cost = service['onStartGather'](service, character, aoi_scene, itemobj)
	if not ok then return false, err end

	-- 修改数据, 角色状态/方向, 采集关系
	CharacterService:changeState(character, Statics.AOI_OBJECT_STATUS_ID_COLLECT)
	local dx, dy = itemobj.x - character.x, itemobj.y - character.y 
	character.direction = Formula:getAngleByVector(dx, dy)
	self:_set_relation(aoi_scene, character, itemobj, time_cost)
	

	-- 取消死亡保护状态
	CharacterService:toAllowAttack(character, false)

	-- 返回采集标准协议
	do
		local data = {}
		do
			data.opcode = opCodes.M2C_GATHER_START
			data.space_id = aoi_scene.space_id
			data.dst_aoi_id = aoi_id
		end
		WorldPacket:m2cSendOK(data, 0, character.player_id)
	end

	-- 角色状态广播
	do
		local params = {}
		do
			params.now_state = Statics.AOI_OBJECT_STATUS_ID_COLLECT
			params.direction = character.direction
		end
		local data = CharacterService:packUpdateCharacter(character.id, params)
		local pids = GameObjectService:getFovPids(character)
		WorldPacket:m2cSendOK(data, 0, pids)
	end
	
	-- ok
	return true
end


--- 完成采集
-- @return ok, err
function GatherService:finishGather(character, aoi_id)
	-- 判断玩家状态
	if not CharacterService:isInState(character, Statics.AOI_OBJECT_STATUS_ID_COLLECT) then
		return false, errorCodes.GATHER_ERROR_STATE
	end

	-- 检查目标对象
	local ok, err, aoi_scene, itemobj, service = self:_check_target_valid(character, aoi_id)
	if not ok then return false, err end

	-- 判断采集关系/时间
	local ok, err = self:_can_gather(aoi_scene, character, itemobj)
	if not ok then return false, err end

	-- 完成采集, 调用 service
	ok, err = service['onFinishGather'](service, character, aoi_scene, itemobj)
	if not ok then return false, err end

	-- 修改数据, 角色状态/采集关系
	CharacterService:changeState(character, Statics.AOI_OBJECT_STATUS_ID_IDLE)
	self:_clear_relation(aoi_scene, character)

	-- 返回采集标准协议
	do
		local data = {}
		do
			data.opcode = opCodes.M2C_GATHER_FINISH
			data.space_id = aoi_scene.space_id
			data.dst_aoi_id = aoi_id
		end
		WorldPacket:m2cSendOK(data, 0, character.player_id)
	end

	-- 角色状态广播
	do
		local params = {}
		do
			params.now_state = Statics.AOI_OBJECT_STATUS_ID_IDLE
		end
		local data = CharacterService:packUpdateCharacter(character.id, params)
		local pids = GameObjectService:getFovPids(character)
		WorldPacket:m2cSendOK(data, 0, pids)
	end

	-- ok
	return true
end


--- 判断一个目标是否有效, 判断场景, 对象类型
-- @return ok, err, aoi_scene, itemobj, service
function GatherService:_check_target_valid(character, aoi_id)
	-- 判断场景
	local aoi_scene = GameObjectService:getAoiScene(character.space_id)
	if not aoi_scene then
		return false, errorCodes.GATHER_ERROR_SCENE
	end
	
	-- 获取对象
	local itemobj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
	if not itemobj then 
		return false, errorCodes.GATHER_IS_NOT_EXIST
	end
	
	-- 判断对象类型
	if itemobj.aoi_type ~= AoiObjectType.AOI_OBJECT_TYPE_ID_ITEM or
		itemobj.sort_id ~= ItemDefs.ITEM_SORT_ID_GATHER then 
		return false, errorCodes.GATHER_ERROR_TARGET_TYPE
	end
	
	-- 获取 service
	local svrname = func_id_to_service_name[ itemobj.func_id ]
	local service = _G[ svrname ]
	if not service then
		return false, errorCodes.GATHER_ERROR_TARGET_TYPE
	end
	
	-- ok
	return true, nil, aoi_scene, itemobj, service
end


-- 判断是否在采集中
function GatherService:isInGathering(character)
	return CharacterService:isInState(character, Statics.AOI_OBJECT_STATUS_ID_COLLECT)
end


------------------------------------------------------------------------
--  采集关系
--
--	info ISA GatherInfo
------------------------------------------------------------------------


--- 当离开采集状态时调用
function GatherService:onLeaveCollectStatus(character)
	local aoi_scene = GameObjectService:getAoiScene(character.space_id)
	if aoi_scene then
		self:_clear_relation(aoi_scene, character)
	end
end


--- 设置采集关系
function GatherService:_set_relation(aoi_scene, character, itemobj, time_cost)
	local info = aoi_scene._gather_info
	if not info then
		info = table.simple_clone(GatherInfo)
		aoi_scene._gather_info = info
	end
	-- 记录信息
	local time_now = Time:getTimeNowExact()
	local src_id, dst_id = character.id, itemobj.aoi_id
	info.target_ids[ src_id ] = dst_id
	info.time_finishs[ src_id ] = time_now + time_cost * 1000
end


--- 清空采集关系
function GatherService:_clear_relation(aoi_scene, character)
	local info = aoi_scene._gather_info
	if info then
		-- 清空信息
		local src_id = character.id
		info.target_ids[ src_id ] = nil
		info.time_finishs[ src_id ] = nil
	end
end


--- 判断采集关系
-- @return true/nil
function GatherService:_has_relation(aoi_scene, character, itemobj)
	local info = aoi_scene._gather_info
	if info then
		-- 判断信息
		local src_id, dst_id = character.id, itemobj.aoi_id
		return info.target_ids[ src_id ] == dst_id
	end
end


--- 判断是否可以采集, 根据采集关系/时间
-- @return ok, err
function GatherService:_can_gather(aoi_scene, character, itemobj)
	local info = aoi_scene._gather_info
	if not info then 
		return false, errorCodes.GATHER_ERROR_STATE 
	end
	-- 判断目标
	local src_id, dst_id = character.id, itemobj.aoi_id
	if info.target_ids[ src_id ] ~= dst_id then
		return false, errorCodes.GATHER_ERROR_TARGET
	end
	-- 判断时间
	local time_now = Time:getTimeNowExact()
	if time_now < info.time_finishs[ src_id ]  then
		return false, errorCodes.GATHER_TOO_FAST
	end
	return true
end


--- 获取某个目标的第一个采集者
-- @return character_id/nil
function GatherService:getFirstGatherer(aoi_scene, itemobj)
	local info = aoi_scene._gather_info
	if info then
		local dst_id = itemobj.aoi_id
		for src_id, target_id in pairs(info.target_ids) do
			if target_id == dst_id then
				return src_id
			end
		end
	end
end
