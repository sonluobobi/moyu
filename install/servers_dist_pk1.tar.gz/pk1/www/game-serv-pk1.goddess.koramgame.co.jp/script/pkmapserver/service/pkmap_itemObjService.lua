--[[
ITEM 对象管理service
author : xingzeng
date : 2015-05-06
]]--

ItemObjService = ItemObjService or {}

local AoiObjectType = AoiObjectType
local AoiObject = AoiObject
local SceneService, GameObjectService
local ItemDefs = ItemDefs
local PROFILE_BIN_PKG_TAG_NEEDED=OptimizeSetting.PROFILE_BIN_PKG_TAG_NEEDED
local type = type
local math_round = math.round

function ItemObjService:onAfterLoadLua()
	SceneService = _G.SceneService
	GameObjectService = _G.GameObjectService
end

------------------------------------------------------------------------
--  对象检索
------------------------------------------------------------------------

--- 获取场景内所有的 itemobj
-- @return {aoi_id->ItemObj}
function ItemObjService:getAllItems(aoi_scene)
	local all_items = GameObjectService:getGameObjsByType(aoi_scene, AoiObjectType.AOI_OBJECT_TYPE_ID_ITEM)
	return all_items
end


-- 获取场景内特定类型的 itemobj
-- @param func_id 功能类型, 参见 ItemDefs.ITEM_FUNC_ID_
-- @param recv_arr=nil 接收数据缓存
-- @return arr/nil, num/0
function ItemObjService:getItemsByFuncId(aoi_scene, func_id, recv_arr)
	local arr, n = recv_arr or {}, 0
	local all_items = self:getAllItems(aoi_scene)
	for _,itemobj in pairs(all_items) do
		if itemobj.func_id == func_id then
			n = n + 1
			arr[n] = itemobj
		end
	end
	if n > 0 then return arr, n end
	return nil, 0
end

--- 获取过期的 itemobj
-- @param func_id 功能类型, 参见 ItemDefs.ITEM_FUNC_ID_
-- @return array
function ItemObjService:getExpiredItems(aoi_scene, func_id)
	local items = func_id and self:getItemsByFuncId(aoi_scene, func_id) or
							self:getAllItems(aoi_scene)
	local itemobjs = {}
	
	if items then
		local time_now = Time.time_now
		for _, itemobj in pairs(items) do
			local life_expire = itemobj.life_expire or 0
			if life_expire > 0 and life_expire < time_now then
				itemobjs[#itemobjs+1] = itemobj
			end
		end
	end
	
	return itemobjs
end

--- 获取特定类型的对象数量
-- @return number
function ItemObjService:getItemCountByFuncId(aoi_scene, func_id)
	local n = 0
	local all_items = self:getAllItems(aoi_scene)
	for _,itemobj in pairs(all_items) do
		if itemobj.func_id == func_id then n = n + 1 end
	end
	return n
end


--- 场景更新
function ItemObjService:update(time_now, aoi_scene)
	if Time.count_seconds % 3 ~= 0 then return end -- 3秒更新一次
	
	-- 删除过期的对象
	local itemobjs = ItemObjService:getExpiredItems(aoi_scene)
	if #itemobjs > 0 then
		GameObjectService:delObjs(itemobjs, aoi_scene)
	end
end


------------------------------------------------------------------------
--  内存优化, 添加/删除场景
------------------------------------------------------------------------

local _removed_items = {}

--- 从场景内删除过期的对象
-- @param func_id 功能类型, 参见 ItemDefs.ITEM_FUNC_ID_
function ItemObjService:removeExpiredItems(aoi_scene, func_id)
	local itemobjs = self:getExpiredItems(aoi_scene, func_id, _removed_items)
	GameObjectService:delObjs(itemobjs, aoi_scene)
end


--- 从场景内删除特定类型的对象
function ItemObjService:removeItemsByFuncId(aoi_scene, func_id)
	local itemobjs = self:getItemsByFuncId(aoi_scene, func_id, _removed_items)
	GameObjectService:delObjs(itemobjs, aoi_scene)
end

function ItemObjService:createItemObj(aoi_scene, sort_id, func_id, pickup_mode, own_gcids, 
										life_expire, x, y, item_base, item_num, master_aoi_id)
	local itemobj = ItemObj:new(sort_id, func_id, pickup_mode, own_gcids, life_expire, item_base, item_num, master_aoi_id)
	local aoi_obj = AoiObject:new(AoiObjectType.AOI_OBJECT_TYPE_ID_ITEM, x, y, 0, itemobj, aoi_scene)					
	GameObjectService:addObj(itemobj, aoi_obj, aoi_scene)
	itemobj.create_mtime = Time.time_now
	return itemobj
end

------------------------------------------------------------------------
--  外观
------------------------------------------------------------------------

do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort
	local writeCoord = FastPacket.writeCoord	
	local writeLong = FastPacket.writeLong
	local writeULong = FastPacket.writeULong
	local writeUShort = FastPacket.writeUShort
	
	-- 写入基础外观
	function ItemObjService:writeObjAppear(itemobj, fast_packet)
		writeByte(fast_packet, 0)							-- speed
		writeLong(fast_packet, 0)							-- hp
		writeUInt(fast_packet, itemobj.item_base.id)		-- base_id
		writeUInt(fast_packet, itemobj.parent_aoi_id or 0)			-- parent_aoi_id
	end
	
	-- 写入详细外观
	function ItemObjService:writeObjAppearDetail(itemobj, fast_packet)
		writeByte(fast_packet, itemobj.sort_id)				-- 物品类型
		writeByte(fast_packet, itemobj.func_id)				-- 功能类型
		writeLong(fast_packet, itemobj.life_expire)			-- 过期时间(毫秒)
		writeUShort(fast_packet, itemobj.item_num)			-- 物品堆叠数
		
		-- 物品归属
		local own_gcids = itemobj.own_gcids
		if type(own_gcids) == 'table' then
			writeByte(fast_packet, #own_gcids)
			for _, gcid in ipairs(own_gcids) do
				writeULong(fast_packet, gcid)
			end
		else
			writeByte(fast_packet, 0)
		end
		
		writeUInt(fast_packet, itemobj.master_aoi_id or 0)	-- 掉落主人AOI ID
		writeUShort(fast_packet, math_round((itemobj.life_expire - (itemobj.create_mtime or 0))/1000)) -- 掉落物生存时长
	end
end
