
SkillBaseService = SkillBaseService or {}

local SkillBaseDao = SkillBaseDao
local SkillDetailDao = SkillDetailDao
local SkillDetail = SkillDetail


function SkillBaseService:getSkillBaseById(skill_id)
	return SkillBaseDao[skill_id]
end

--获取技能描述,包含skill_base的信息
--skill_base -->skill_base/skill_id(可直接使用技能ID)
--skill_level-->技能等级
function SkillBaseService:getSkillDetail(skill_base, skill_level)
	local skill_id = type(skill_base) == 'table' and skill_base.id or skill_base
	
	local lev2skill_detail = SkillDetailDao[skill_id]

	local detail = lev2skill_detail and lev2skill_detail[skill_level] or nil
	if not detail then
		Logger:error('[SkillBaseService:getSkillDetail] skill detail not exists : ' .. skill_id .. ',' .. skill_level)	
	end
	
	return detail
end

--- 通过技能ID获取技能详细数据
--- level 技能等级，不填则为0
do
	local base_skill_info = {}
	function SkillBaseService:getDetailSkillInfoById(skill_id, level)		
		level = level or 1
		base_skill_info.skill_detail = SkillBaseService:getSkillDetail(skill_id, level)
		base_skill_info.skill_base = SkillBaseService:getSkillBaseById(skill_id)
		if not base_skill_info.skill_detail or not base_skill_info.skill_base then 
			Logger:info('配置有问题的技能,请检查，技能ID', skill_id, '等级', level)
			assert(false)
		end
		return base_skill_info
	end
end