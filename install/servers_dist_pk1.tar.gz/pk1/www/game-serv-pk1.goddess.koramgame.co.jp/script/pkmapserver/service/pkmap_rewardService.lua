--[[
跨服PK发奖系统service
author : suwin zhong
date : 2015-04-03
--]]

local externalMergeUInt = external.mergeUInt
local externalSplitUInt = external.splitUInt
local WorldPacket = WorldPacket

RewardService = RewardService or {}


do
	-- upvalue
	local arr_reward_req = {}
	local opcode = opCodes.PKM2B_PKSERVER_REWARD

	-- 发奖统一入口(不传角色是因为发奖的时候玩家不一定还在PK服里，统一处理)
	-- game_type_id : 玩法id(定义在Statics.lua)
	-- child_game_type_id : 子玩法id
	-- gpid
	-- gcid
	-- arr_datas : 其他参数(各个玩法内部自己定义)
	function RewardService:reward(game_type_id, child_game_type_id, gpid, gcid, arr_datas)
		if game_type_id then
			-- 发送发奖请求
			arr_reward_req.game_type_id = game_type_id
			arr_reward_req.child_game_type_id = child_game_type_id
			arr_reward_req.gpid = gpid
			arr_reward_req.gcid = gcid
			arr_reward_req.arr_datas = arr_datas

			-- 按大区发
			WorldPacket:pkServer2GameSendPack(opcode, gpid, arr_reward_req)
		else
			error("未知的发奖游戏类型")
		end
	end
end

do
	local opcode = opCodes.PKM2B_PKSERVER_REWARD_BIN
	local writeUInt = Packet.writeUInt
	local writeUShort = Packet.writeUShort
	local writeByte = Packet.writeByte
	local extern_sendGameServerPacket = external.sendGameServerPacket
	-- 发奖统一入口 需要角色在线  二进制传输 (用于频繁调用)
	-- game_type_id : 玩法id(定义在Statics.lua)
	function RewardService:onlineRewardBin(game_type_id, gpid, gcid, equip_id, equip_num)
		if not equip_id or not equip_num or not gpid then
			Logger:fatal("参数错误:gpid", gpid, 'gcid', gcid, 'equip_id', equip_id, 'equip_num', equip_num)
		end
		
		if game_type_id then
			local pack = WorldPacket:newPacket(opcode, nil, gpid)
			pack:writeUInt(equip_id)
			pack:writeUShort(equip_num)
			pack:writeByte(game_type_id)
			
			-- 按大区发
			extern_sendGameServerPacket(gpid, pack)
		else
			error("未知的发奖游戏类型")
		end
	end
end