local ostime = os.time
local osdate = os.date
local Time = Time


CounterService = {}

function CounterService:init(character)
	character.counters = WorldPacket:decodeData(character.counters) or {}
end

function CounterService:pack(character)
	return WorldPacket:encodeData(character.counters)
end

function CounterService:getEnUseCount(character, counter_baseid)
	local counter = character.counters[counter_baseid]
	local counter_base = assert(CounterDefs:getCounterBase(counter_baseid))
	assert(counter, counter_baseid)

	-- 检测数据更新
	self:_checkUpdate( counter, counter_base, character )

	return counter.now_storeup_count - counter.count, counter
end

-- 检查更新计数器
function CounterService:_checkUpdate( counter, counter_base, character )
	-- 检测是否需要清理
	self:_checkAndClear(counter, counter_base)
	
	if counter_base.sort_id == CounterDefs.COUNTER_SORT_ID_DAILY then
		CounterService:_upStoreupEnUseCount(counter, counter_base, character)
	else
		counter.now_storeup_count = counter_base.count
	end
end


-- 过期清理
function CounterService:_checkAndClear(counter, counter_base)
	-- 记录计数历史
	local history = counter.history
	if not history then
		history = {}
		counter.history = history
	end
	
--	if counter.updated > 0 then
	if counter_base.sort_id == CounterDefs.COUNTER_SORT_ID_DAILY then
		local is_before_today, in_date = Time:isBeforeToday(counter.updated)
		if is_before_today then
			if history[in_date] == nil then
				history[in_date] = counter.count
			end
			
			-- 重置
			counter.count = 0
			counter.updated = ostime()
		end
	elseif counter_base.sort_id == CounterDefs.COUNTER_SORT_ID_WEEK then
		local os_time = ostime()
		local this_week_begin = CounterDefs:getThisWeekBegin(os_time)
		if counter.updated < this_week_begin then 
			local _, in_date = Time:isBeforeToday(counter.updated)
			if history[in_date] == nil then
				history[in_date] = counter.count
			end
			-- 重置
			counter.count = 0
			counter.updated = os_time				
		end
	end
--	end
	
	-- 清理旧的counter history
end

-- 更新累计的可用次数 (仅支持每日计数类型累计)
function CounterService:_upStoreupEnUseCount(counter, counter_base, character)
	assert(counter_base.sort_id == CounterDefs.COUNTER_SORT_ID_DAILY)
	
	local today_date = osdate('%Y%m%d') + 0
	
	-- 今日已经计算过
	local storeup_up_date = counter.storeup_up_date
	if storeup_up_date == today_date then
		return counter.now_storeup_count
	end
	
	local history = counter.history
	
	-- 累计次数计算
	local count_daily = counter_base.count
	local storeup_count_max = counter_base.storeup_count
	local curtime = ostime()
	local calc_day_num = storeup_up_date > 0 and CounterDefs.COUNTER_SAVE_HISTORY_DAY_NUM or 0
	local now_storeup_count = counter.now_storeup_count
	
	-- 查看次数是否与VIP相关
	if counter_base.vip_fun_id  then 
		local type_fun_id = type(counter_base.vip_fun_id)
		if type_fun_id == 'number' then
			local is_open, _1, _2, value2 = CharacterVipService:isOwnVipFuncWith0(character, counter_base.vip_fun_id)
			count_daily = assert(value2.count)
			storeup_count_max = assert(value2.storeup_count)
		elseif type_fun_id == 'function' then 
			count_daily, storeup_count_max = counter_base.vip_fun_id(counter_base, counter, character)
		end
	end

	-- 减去最后一天使用次数
	if storeup_up_date > 0 and history[storeup_up_date] then
		now_storeup_count = now_storeup_count - history[storeup_up_date]
	end
	
	-- 累计的数量已经达最大
	if now_storeup_count >= storeup_count_max then
		counter.now_storeup_count = storeup_count_max
		
		-- 更新累计的时间
		counter.storeup_up_date = today_date
		return counter.now_storeup_count
	end
		
	-- 累计
	for i = 0, calc_day_num, 1 do
		local day = osdate('%Y%m%d', curtime - 3600 * 24 * i) + 0
		if storeup_up_date >= day then
			break
		end
		
		if now_storeup_count >= storeup_count_max then
			break
		end
		
		if history == nil or history[day] == nil then
			now_storeup_count = now_storeup_count + count_daily
		else
			local used_count = history[day]
			now_storeup_count = now_storeup_count + 
				(used_count == nil and count_daily or count_daily - used_count)
		end
	end
	
	if now_storeup_count > storeup_count_max then
		now_storeup_count = storeup_count_max
	end
	
	counter.now_storeup_count = now_storeup_count
	counter.storeup_up_date = today_date
	return now_storeup_count
end

function CounterService:addcount(character, counter, diy_up_param, add_count, is_not_2_game)
	add_count = add_count or 1
	counter.count = counter.count + add_count
	if counter.count > counter.now_storeup_count then
		Logger:error('CounterService:addcount，计数器超限', counter)
		counter.count = counter.now_storeup_count
	end
	if not is_not_2_game then 
		CounterService:updateMapCounter(counter.base_id, character.gpid, character.gcid, add_count, diy_up_param)
	end
end

-- 增加总次数
function CounterService:increaseTotalCount(character, counter, cnt)
	counter.now_storeup_count = counter.now_storeup_count + cnt
	counter.updated = ostime()
end

-- 更新base的计数器
-- area_id 		对应的服务器的大区ID
-- counter_id 	对应的计数器ID
-- sub_ids 		对应的子计数器列表
function CounterService:updateBaseCounter(counter_id, area_id, sub_counter_id, num)
	local data = {}
	data.type = 'base'
	data.num = num
	data.sub_counter_id = sub_counter_id
	data.counter_id = counter_id
	local gpid = externalMergeUInt(area_id, 0)
	self:send2GameSrv(gpid, data)
end

-- 更新base的计数器
-- area_id 		对应的服务器的大区ID
-- counter_id 	对应的计数器ID
-- gcids 		角色列表
function CounterService:updateMapCounter(counter_id, gpid, gcid, num, diy_up_param)
	local data = {}
	data.type = 'map'
	data.num = num
	data.gcid = gcid
	data.gpid = gpid
	data.counter_id = counter_id
	data.diy_up_param = diy_up_param
	self:send2GameSrv(gpid, data)	
end

do
	local op_code = opCodes.PKM2B_COUNTER_ADD
	local externalMergeUInt = external.mergeUInt
	function CounterService:send2GameSrv(gpid, data)
		WorldPacket:pkServer2GameSendPack(op_code, gpid, data)
	end
end