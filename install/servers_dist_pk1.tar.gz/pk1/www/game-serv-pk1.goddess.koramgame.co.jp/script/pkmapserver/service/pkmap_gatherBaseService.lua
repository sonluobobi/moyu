--[[
采集物基础servuce
author : xingzeng
date : 2012-03-27
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local table = table
local tableInsert = table.insert
local GatherBaseDao = GatherBaseDao

GatherBaseService = GatherBaseService or {}

function GatherBaseService:getGatherBaseById(id)
	return GatherBaseDao.data[id]
end

