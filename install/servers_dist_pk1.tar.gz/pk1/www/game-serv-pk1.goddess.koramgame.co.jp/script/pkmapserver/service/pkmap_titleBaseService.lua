--[[
称号系统基础Service，用于数据获取以及相关逻辑处理
author : guoyin.huang
date : 2015-06-15
--]]

local titleBaseDao = TitleBaseDao
TitleBaseService = TitleBaseService or {}


-- 获取所有基本称号信息
function TitleBaseService:getAllTitles()
	return titleBaseDao.data
end


-- 通过id获取所有基本称号信息
-- title_id : 称号id
function TitleBaseService:getTitleBaseById(title_id)
	return titleBaseDao.data[title_id]
end


-- 通过称号类型获取所有称号
function TitleBaseService:getTitlesByType( type )
	return titleBaseDao.type_2_data[type]
end