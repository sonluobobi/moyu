--[[
怪物基础数据系统Service，用于数据加工，逻辑处理
author : suwin zhong
date : 2012-03-01
--]]

local abs = math.abs
local floor = math.floor

MonsterBaseService = MonsterBaseService or {}

-- 根据id获取怪物基础数据
-- monster_id : 怪物id
-- return obj / nil
function MonsterBaseService:getMonsterBaseById(monster_id)
	if table.isTable(MonsterBaseDao.data[monster_id]) then
		return MonsterBaseDao.data[monster_id]
	else
		return nil
	end
end


-- 获取怪物基础属性值(获取速度的不要用该方法，用上面的方法)
-- monster : 怪物
-- key : 要获取值的属性名
function MonsterBaseService:getMonsterBaseVal(monster, key)
	local monster_base = monster.monster_base
	local monster_base_new = monster.monster_base_new

	if monster_base_new then
		return monster_base_new[key] or monster_base[key] or 0
	else
		return monster_base[key] or 0
	end
end


-- 获取一个怪物新的基础属性
-- (目前是提供给杰林的木人巷中会用到)
-- monster_id : 怪物id
-- level : 等级
-- return tbl / nil
function MonsterBaseService:getMonsterBaseNew(monster_id, level)
	local MonsterBaseNewDao_data = MonsterBaseNewDao.data

	if MonsterBaseNewDao_data[monster_id] then
		return MonsterBaseNewDao_data[monster_id][level] or nil
	end

	return nil
end


-- 缓存新怪物实体到Dao中
-- (目前是提供给杰林的木人巷中会用到)
-- monster_id : 怪物id
-- level : 等级
-- monster_base_new : 新的属性值(键值对)(注意 : 必须和monster_base里面的命名一致)
function MonsterBaseService:cacheMonsterBaseNew(monster_id, level, monster_base_new)
	local MonsterBaseNewDao_data = MonsterBaseNewDao.data

	if not MonsterBaseNewDao_data[monster_id] then
		MonsterBaseNewDao_data[monster_id] = {}
	end

	MonsterBaseNewDao_data[monster_id][level] = monster_base_new
end


-- 将一个特殊的怪物基础属性关联到实际怪物身上
-- (目前是提供给杰林的木人巷中会用到)
-- monster : 实际怪物
-- monster_base_new : 新的怪物属性
function MonsterBaseService:relationMonsterBaseNew(monster, monster_base_new)
	-- 关联起来
	monster.monster_base_new = monster_base_new

	-- 修改相关初始值
	local maxp_hp_new = monster_base_new.max_hp
	if maxp_hp_new then
		monster.hp = maxp_hp_new
	end
end