--[[
怪物AI service
author : suwin zhong
date : 2014-11-13
--]]

local Statics = Statics
local WorldPacket = WorldPacket
local random = math.random
local isTable = table.isTable
local tableInsert = table.insert
local sizeTable = table.sizeTable

local EffectType_biansheng = EffectType.biansheng

local writeInt = FastPacket.writeInt
local writeUInt = FastPacket.writeUInt
local writeByte = FastPacket.writeByte
local writeUShort = FastPacket.writeUShort	
local writeLong = FastPacket.writeLong -- U64

local getNowUnixUsTime = external.getNowUnixUsTime
local g_bEnableLuaTimeoutGuard=OptimizeDbg.g_bEnableLuaTimeoutGuard


-- upvalue
local arr_rsp_bc_monster_dead = {} -- 用于广播怪物死亡(世界boss等会用到)

MonsterAiService = MonsterAiService or {}


local MonsterSkillAiService
local GameObjectService
local FightService
local MonsterBaseService
local MonsterService
local MotionService
local SceneBaseService
local CharacterService
local BufferService

function MonsterAiService:onAfterLoadLua()
	MonsterSkillAiService = _G.MonsterSkillAiService
	GameObjectService = _G.GameObjectService
	FightService = _G.FightService
	MonsterBaseService = _G.MonsterBaseService
	MonsterService = _G.MonsterService
	MotionService = _G.MotionService
	SceneBaseService = _G.SceneBaseService
	CharacterService = _G.CharacterService
	BufferService = _G.BufferService
end


-- 怪物状态机(自动攻击)(小蒋的副本也会用到)
-- monster : 怪物对象
-- targeter : 目标对象(角色/侠客)
-- delay_msec : 延迟的响应的毫秒数
-- is_force_aoto_fight : 是否强制变成战斗状态
function MonsterAiService:toFightState(monster, targeter, delay_msec, is_force_aoto_fight)
	is_force_aoto_fight = is_force_aoto_fight or false
	if is_force_aoto_fight or self:isAllowChangeAutoFight(monster, targeter) then
		self:changeAutoFight(monster, targeter, delay_msec)
	end
end


-- 怪物状态机(移动状态)
-- monster : 怪物对象
-- targeter : 目标对象
-- target_pos_x : 目标位置x(返回出生点等)
-- target_pos_y : 目标位置y(返回出生点等)
-- error_span : 距离多远位置停下
-- is_clear_target : 是否清空目标对象(不填，默认是会清的)
-- is_walk : 是否用走的方式移动(不填，默认是跑)
function MonsterAiService:toMoveState(monster, targeter, target_pos_x, target_pos_y, error_span, is_clear_target, is_walk)
	if self:isAllowChangeMoving(monster, targeter) then
		self:changeMoving(monster, targeter, target_pos_x, target_pos_y, error_span, is_clear_target, is_walk)
	end
end


-- 怪物状态机(死亡状态)(保留尸体)
-- monster : 怪物对象
function MonsterAiService:toPreDeadState(monster)
	if self:isAllowChangePreDead(monster) then
		-- 触发一些死亡的ai
		local aoiScene, now_unix_time
		MonsterSkillAiService:playMyAi(aoiScene, monster, now_unix_time)
		-- 变成预死亡状态
		self:changePreDead(monster)
	end
end


-- 怪物状态机(死亡状态)(删除尸体)
-- monster : 怪物对象
-- is_force_dead : 是否强制变成死亡状态
function MonsterAiService:toDeadState(monster, is_force_dead)
	is_force_dead = is_force_dead or false
	if is_force_dead or self:isAllowChangeDead(monster) then
		self:changeDead(monster)
	end
end


-- 怪物状态机(返回出生点)
-- monster : 怪物对象
function MonsterAiService:toHomeState(monster)
	if self:isAllowChangeHoming(monster) then
		self:changeHoming(monster)
	end
end


-- 怪物状态机(空闲状态)
-- monster : 怪物对象
function MonsterAiService:toIdleState(monster)
	if self:isAllowChangeIdel(monster) then
		self:changeIdle(monster)
	end
end


-- 怪物状态机(AI准备状态)
-- monster : 怪物对象
-- monsterAi : 要触发的ai
-- now_unix_time : 当前系统时间
function MonsterAiService:toAiPrepareState(monster, monsterAi, now_unix_time)
	if self:isAllowChangeAiPrepare(monster) then
		self:changeAiPrepare(monster, monsterAi, now_unix_time)
	end
end


-- 怪物状态机(AI播放状态)
-- monster : 怪物对象
function MonsterAiService:toAiPlayingState(monster)
	if self:isAllowChangeAiPlaying(monster) then
		self:changeAiPlaying(monster)
	end
end


-- 怪物逃跑(非状态机，变成移动状态)
-- monster : 怪物对象
-- targeter : 目标对象
function MonsterAiService:toEscapeState(monster, targeter)
	local is_ok, new_x, new_y

	-- 寻找一个逃跑点(利用退守的接口)
	local aoiScene = GameObjectService:getAoiScene(targeter)
	is_ok, new_x, new_y = aoiScene:getBackPos(targeter.x, targeter.y, monster.x, monster.y, 3)

	if not is_ok then
		-- 如果无法后退，则随机找一个点(随机移动)
		new_x, new_y = aoiScene:randPos(monster.x, monster.y, 3)
	end

	-- 变成移动状态
	self:toMoveState(monster, nil, new_x, new_y)
end

------------------------------------------------------------------------------------------------------------------------------------

-- 怪物ai更新入口(由C++定时器触发，理论是50ms触发一次)
-- aoiScene : 场景对象
-- arr_monster : 怪物列表
-- now_unix_time : 当前系统的秒数
-- now_unix_mstime : 当前系统的毫秒数
-- is_500ms_start : 是否有500毫秒的间隔了

local g_FrameIdx=0
do
	function MonsterAiService:update(time_now, aoiScene, arr_monster, FrameIdx)
		local Time = Time
		local now_unix_time = Time:getSecondsNow()
		local now_unix_mstime = time_now
		local is_500ms_start = Time.is_500ms_start

		g_FrameIdx = FrameIdx

		if isTable(arr_monster) then
		
			-- value
			local state, is_action, is_visible
			-- local
			local FightService = FightService
			local GameObjectService = GameObjectService
			local arr_relive_monster = {} -- 需要复活的怪物(之所以不在循环里直接复活，是因为小蒋那边会出问题，会破坏哈希表的循环)

			local stime
			
			for _, monster in pairs(arr_monster) do

				if g_bEnableLuaTimeoutGuard then
				  stime= getNowUnixUsTime()	
				end
			
				-- 检查是否有buffer事件要出发
				-- if is_500ms_start then
				if false then
					-- buffer效果触发
					FightService:bufferEffect(monster, now_unix_time, now_unix_mstime)

					-- 临时仇恨处理
					if monster.tmps.tmp_hate then
						local tmp_hate_expire = monster.tmps.tmp_hate[2] or 0
						if tmp_hate_expire < now_unix_time then
							local hate_aoi_id = monster.tmps.tmp_hate[1] or 0
							MonsterService:cleanHateLists(monster, hate_aoi_id)
							monster.tmps.tmp_hate = nil
						end
					end
				end

				state = self:getNowState(monster)
				is_action = false -- 一个怪物在一次循环里只做一件事
				is_visible = GameObjectService:isVisible(monster) -- 怪物是否可见

				local actionid =0
				-- 空闲状态 ------------------------------------------------------------------------------------------------------------
				if is_visible and self:isIdle(state) then
					actionid=1
					if is_500ms_start then
						local monsterBase = monster.monster_base
						local monsterTmps = monster.tmps
						local allow_move_time = monsterTmps.allow_move_time or 0 -- 允许移动的时间，用于等待客户端播放完出生特效
						
						if allow_move_time <= now_unix_time then
							-- 重新寻找出生攻击对象
							is_action = self:isFindBornTarget(aoiScene, monster)

							-- 主动怪
							if not is_action then
								actionid=10
								if self:isCanFindTarget(monster, now_unix_mstime) then
									is_action = self:findTarget(aoiScene, monster) -- 检查视野里是否有出现角色目标
									actionid=11
								end
							end

							if not is_action then
								-- 随机移动怪
								if MonsterDefs.MOVE_SORT_ID_FOR_RANDOM == monsterBase.move_sort_id then
									is_action = self:randomMove(aoiScene, monster, now_unix_mstime) -- 让怪物随机移动
									actionid=12
								elseif MonsterDefs.MOVE_SORT_ID_FOR_LOOP == monsterBase.move_sort_id then
									is_action = self:loopMove(monster, now_unix_mstime) -- 让怪物循环移动
									actionid=13
								end
							end
						end
					end
				-- 移动状态 ------------------------------------------------------------------------------------------------------------
				elseif is_visible and self:isMoving(state) then
					actionid=2
					local monsterTmps = monster.tmps
					local monsterBase = monster.monster_base
					local monster_aoi = monster.monster_aoi
					local is_to_home_state = false

					-- 跑动类型
					if MonsterDefs.MOVE_TYPE_ID_FOR_RUN == monsterTmps.move_type_id then
						-- 检查是否已经超过可移动范围了
						local is_near_enough, sqr_dist = Formula:isNearbyDistance(monster.x, monster.y, monsterTmps.active_x, monsterTmps.active_y, monsterBase.follow_dist)
						if not is_near_enough then
							-- 回家
							is_to_home_state = true
							self:toHomeState(monster)

							-- 日志记录
							-- self:logGoHome('超过回防距离', monster, nil)
						end
					end

					-- 不是回家
					if not is_to_home_state then
						actionid=3
						-- 主动怪
						if self:isCanFindTarget(monster, now_unix_mstime) then
							actionid=31
							is_action = self:findTarget(aoiScene, monster) -- 检查视野里是否有出现角色目标
						end

						if not is_action then
							-- 调用移动接口(力志提供)
							actionid=32
							if not MotionService:updateObject(aoiScene, monster) then
								actionid=33
								self:doAfterAction(aoiScene, monster)
							end
						end
					end
				-- 回家状态(移动) -----------------------------------------------------------------------------------------------------
				elseif is_visible and self:isHoming(state) then
					actionid=4
					if not MotionService:updateObject(aoiScene, monster) then
						self:toIdleState(monster)
					end
				-- 战斗状态 -----------------------------------------------------------------------------------------------------------
				elseif is_visible and self:isAutoFight(state) then
					actionid=5
					self:fight(aoiScene, monster, now_unix_time, now_unix_mstime)
				-- 死亡状态(保留尸体) -----------------------------------------------------------------------------------------------
				elseif self:isPreDead(state) then
					actionid=6
					if is_500ms_start then
						if self:isDeleteTimeOk(monster, now_unix_mstime) then
							self:toDeadState(monster)
						end
					end
				-- 死亡状态(不保留尸体) -----------------------------------------------------------------------------------------------
				elseif self:isDead(state) then
					actionid=7
					if is_500ms_start then
						tableInsert(arr_relive_monster, monster)
						-- 改到下面去复活了 self:relive(monster, now_unix_mstime)
					end
				-- 死亡状态(不保留尸体)(用不复活) -------------------------------------------------------------------------------------
				-- elseif self:isDeadForever(state) then
				-- 不用做任何事情，不用处理

				-- AI准备状态 ---------------------------------------------------------------------------------------------------------
				elseif is_visible and self:isAiPrepare(state) then
					actionid=8
					self:aiPrepare(monster, now_unix_mstime)

				-- AI播放状态 ---------------------------------------------------------------------------------------------------------
				elseif is_visible and self:isAiPlaying(state) then
					actionid=9
					self:aiPlaying(aoiScene, monster, now_unix_mstime)
				end
				
				if g_bEnableLuaTimeoutGuard then
					local etime = getNowUnixUsTime()
					if etime - stime >= 100 then
						printf('[%d] space_id:%d aoi_id:%d [monsterai_timeout] use time(us) :%d  #arr_monster:%d' .. ' actionid:%d.\n',g_FrameIdx,aoiScene.space_id,monster.aoi_id,etime - stime,#arr_monster,actionid)
					end
				end
			end -- end for

			-- 执行复活
			if 0 < sizeTable(arr_relive_monster) then
				for _, monster in pairs(arr_relive_monster) do
					self:relive(monster, now_unix_mstime)
				end
			end
		end -- end if isTable(arr_monster) then
	end -- end func
end

-- 怪物进行某项行为后的后续处理(移动到目的地后/触发一个AI播放完后等)
-- aoiScene : aoi场景对象
-- monster : 怪物
function MonsterAiService:doAfterAction(aoiScene, monster)
	local target_aoi_id = self:getTargetAoiId(monster)
	if 0 < target_aoi_id then
		local targeter = GameObjectService:getGameObjectByAoiId(aoiScene, target_aoi_id)
		if not targeter then
			local monsterTmps = monster.tmps
			local hate_lists = monsterTmps.hate_lists
			if hate_lists then
				-- 将目标从仇恨列表中清除
				MonsterService:cleanHateLists(monster, target_aoi_id)

				-- 原来的目标删除
				monsterTmps.target_aoi_id = 0

				-- 寻找最大仇恨值(updateHatestAoiId里面会更新怪物的target_aoi_id)
				local new_target_aoi_id = MonsterService:updateHatestAoiId(monster)
				if 0 < new_target_aoi_id then
					-- 找新的目标对象
					targeter = GameObjectService:getGameObjectByAoiId(aoiScene, new_target_aoi_id)
				end
			end
		end

		if targeter then
			-- 变成自动攻击状态
			self:updatePreState(monster, Statics.AOI_OBJECT_STATUS_ID_MOVING)
			self:toFightState(monster, targeter, 10, true)
			return
		end
	end

	-- 变成空闲状态
	self:toIdleState(monster)
end


-- 寻找出生默认的攻击对象
-- monster : 怪物
-- return true / false
function MonsterAiService:isFindBornTarget(aoiScene, monster)
	local born_target_aoi_id = monster.tmps.born_target_aoi_id or 0

	if 0 < born_target_aoi_id then
		local targeter = GameObjectService:getGameObjectByAoiId(aoiScene, born_target_aoi_id)
		if targeter and (not FightService:isDead(targeter)) then
			self:toFightState(monster, targeter, 10)
			return true
		else
			-- 默认出生的攻击对象已经死亡，则清空
			monster.tmps.born_target_aoi_id = 0
		end
	end

	return false
end


-- 主动怪寻找视野里的角色
-- monster : 怪物
-- now_unix_mstime : 当前系统毫秒时间
-- return true / false
function MonsterAiService:isCanFindTarget(monster, now_unix_mstime)
	local monsterBase = monster.monster_base
	local monsterTmps = monster.tmps

	if MonsterDefs.IS_ACTIVE_MONSTER_YES == monsterBase.is_active_monster 
			and 0 == monsterTmps.target_aoi_id and
				self:isFindTimeOk(monster, now_unix_mstime) then
		if 0 < monster.aoi_obj.see_player_num then -- 要被人看见
			return true
		end
	end

	return false
end


-- 当角色离开关卡，让boss怪物自动回防(提供给吉林使用)
-- character : 角色对象
function MonsterAiService:onLastPlayerLeaveScene(aoiScene)
	-- local
	local MONSTER_SORT_ID_FOR_BOSS = MonsterDefs.MONSTER_SORT_ID_FOR_BOSS
	local arr_monsters = GameObjectService:getGameObjsByType(aoiScene, AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER)
	for _, now_monster in pairs(arr_monsters) do
		if not self:isInDeadState(now_monster.tmps.now_state) and (MONSTER_SORT_ID_FOR_BOSS == now_monster.monster_base.monster_sort_id) then
			self:toHomeState(now_monster)
		end
	end
end


-- 主动怪寻找视野里的(角色/侠客)
-- aoiScene : 场景对象
-- monster : 怪物
-- return true / false
function MonsterAiService:findTarget(aoiScene, monster)
	-- local
	local GameObjectService = GameObjectService
	local scene_base = SceneBaseService:getSceneBaseById(aoiScene.map_id)
	local aoiObj = assert(GameObjectService:getAoiObjByGameObj(monster))

	local arr_aoiObj
	local is_find_character = true

	-- 非侠客历练场景
	-- if SceneDefs.SCENE_SORT_ID_PET_LILIAN ~= scene_base.scene_sort_id then
	if true then
		-- 找角色
		arr_aoiObj = aoiScene:getRoundPlayerAoiObjs(aoiObj, monster.monster_base.view_dist)
	end

	-- 视野里有发现目标，立刻变成去攻击目标
	if 0 < #arr_aoiObj then
		-- local
		local CharacterService = CharacterService
		local FightService = FightService
		local is_ok, now_targeter

		for _, now_aoiObj in pairs(arr_aoiObj) do
			is_ok = false
			now_targeter = GameObjectService:getGameObjectByAoiObj(now_aoiObj)			
			-- 能找到目标，目标不能是死的，不能是同一个阵营
			if now_targeter then
				if is_find_character then
					if FightService:isCanAttack(monster, now_targeter) then
						is_ok = true
					end
				else
					is_ok = true
				end
			end

			if is_ok then
				self:updateActivePos(monster) -- 更新发现目标的位置
				self:toFightState(monster, now_targeter, 10)
				return true
			end
		end
	end

	return false
end


-- 怪物随机移动
-- aoiScene : 场景对象
-- monster : 怪物
-- now_unix_mstime : 当前系统毫秒
-- return true / false
function MonsterAiService:randomMove(aoiScene, monster, now_unix_mstime)
	local monsterTmps = monster.tmps

	-- 到了允许自由移动时间点
	if monsterTmps.random_move_time <= now_unix_mstime then
		local monster_aoi = monster.monster_aoi

		-- 随机获取一个点(吉林提供接口)
		-- 随机移动(规则: 距离出生点2米内，随机找一个点移动；触发条件是被玩家看到)
		
		local stime 
		if g_bEnableLuaTimeoutGuard then
		  stime= getNowUnixUsTime()
		end		
		local target_x, target_y = aoiScene:randPos(monster_aoi.x, monster_aoi.y, 2)
		
		if g_bEnableLuaTimeoutGuard then
			local stime2 = getNowUnixUsTime()
			if (stime2 -stime)>=50 then
					printf('xx[12aoiScene:randPos] use time(us) :%d',stime2 - stime)					
			end
		end
		
		self:toMoveState(monster, nil, target_x, target_y, 0, nil, true)

		if g_bEnableLuaTimeoutGuard then
			local stime3 = getNowUnixUsTime()
			if (stime3 -stime2)>=50 then
					printf('xx[12toMoveState] use time(us) :%d',stime3 - stime2)					
			end
		end

		-- 更新下一次移动时间点
		monsterTmps.random_move_time = now_unix_mstime + random(8000, 15000) -- (8 - 15秒)

		return true
	end

	return false
end


-- 怪物循环移动
-- monster : 怪物
-- now_unix_mstime : 当前系统毫秒
-- return true / false
function MonsterAiService:loopMove(monster, now_unix_mstime)

	local monsterTmps = monster.tmps

	-- 到了循环移动时间点
	if monsterTmps.loop_move_time <= now_unix_mstime then
		local monster_aoi = monster.monster_aoi

		-- 是否需要停顿
		local is_need_stop = true

		-- 女神不停顿
		if MonsterService:isNvSheng(monster) then
			is_need_stop = false
		end

		-- 目标点索引
		local loop_move_index = monsterTmps.loop_move_index
		if loop_move_index > #monster_aoi.patro_ways then
			if is_need_stop then
				loop_move_index = 1 -- 非滚石怪，重新到原点开始移动
			else
				return false -- 滚石怪走到结束位置的时候，就不再动了
			end
		end

		local target = monster_aoi.patro_ways[loop_move_index]
		if isTable(target) then
			local target_x, target_y = target[1], target[2]

			if target_x and target_y then
				self:toMoveState(monster, nil, target_x, target_y, 0, nil, true)
			end
		else
			print("巡逻怪巡逻路径录入错误", monster.monster_base.nick)
		end

		-- 更新下一次移动时间点和目标索引
		if is_need_stop then
			monsterTmps.loop_move_time = now_unix_mstime + random(10000, 20000) -- (10 - 20秒)
		else
			monsterTmps.loop_move_time = now_unix_mstime -- 滚石的移动不停顿
		end
		monsterTmps.loop_move_index = loop_move_index + 1

		return true
	end

	return false
end
--------------------------------------------------- 基本状态判断 start -----------------------------------------------------
-- 是否是空闲状态
-- state : 状态
function MonsterAiService:isIdle(state)
	return Statics.AOI_OBJECT_STATUS_ID_IDLE == state
end


-- 是否是死亡状态(保留尸体)
-- state : 状态
function MonsterAiService:isPreDead(state)
	return Statics.AOI_OBJECT_STATUS_ID_PRE_DEAD == state
end


-- 是否是死亡状态(不保留尸体)(会复活)
-- state : 状态
function MonsterAiService:isDead(state)
	return Statics.AOI_OBJECT_STATUS_ID_DEAD == state
end


-- 是否是死亡状态(不保留尸体)(永不复活)
-- state : 状态
function MonsterAiService:isDeadForever(state)
	return Statics.AOI_OBJECT_STATUS_ID_DEAD_FOREVER == state
end


-- 是否死亡中(包含死亡的各种状态判断)
-- state : 状态
function MonsterAiService:isInDeadState(state)
	local Statics = Statics
	if Statics.AOI_OBJECT_STATUS_ID_PRE_DEAD == state or Statics.AOI_OBJECT_STATUS_ID_DEAD == state or Statics.AOI_OBJECT_STATUS_ID_DEAD_FOREVER == state then
		return true
	end

	return false
end


-- 是否是移动状态
-- state : 状态
function MonsterAiService:isMoving(state)
	return Statics.AOI_OBJECT_STATUS_ID_MOVING == state
end


-- 是否是回家状态
-- state : 状态
function MonsterAiService:isHoming(state)
	return Statics.AOI_OBJECT_STATUS_ID_FOR_HOMING == state
end


-- 是否是自动攻击状态
-- state : 状态
function MonsterAiService:isAutoFight(state)
	return Statics.AOI_OBJECT_STATUS_ID_AUTO_FIGHT == state
end


-- 怪物播放某个动作是否已经过期
-- monster : 怪物
-- return true / false
function MonsterAiService:isActionExpire(monster)
	if monster.tmps.action_expire > Time:getTimeNow() then
		return false
	end

	return true
end


-- 是否是AI准备状态
-- state : 状态
function MonsterAiService:isAiPrepare(state)
	return Statics.AOI_OBJECT_STATUS_ID_AI_PREPARE == state
end


-- 是否是AI播放状态
-- state : 状态
function MonsterAiService:isAiPlaying(state)
	return Statics.AOI_OBJECT_STATUS_ID_AI_PLAYING == state
end
--------------------------------------------------- 基本状态判断 end -------------------------------------------------------

--------------------------------------------------- 切换条件判断 start -----------------------------------------------------
-- 判断是否允许立刻变成自动战斗状态
-- monster : 怪物
-- targeter : 目标对象
-- return true / false
function MonsterAiService:isAllowChangeAutoFight(monster, targeter)
	local state = self:getNowState(monster)

	-- 死亡状态
	if self:isInDeadState(state) then
		return false
	end

	-- 原本就处于自动战斗状态
	if self:isAutoFight(state) then
		return false
	end

	-- 原本就处于AI准备状态中
	if self:isAiPrepare(state) then
		return false
	end

	-- 原本就处于AI播放状态中
	if self:isAiPlaying(state) then
		return false
	end

	-- 移动状态
	if self:isMoving(state) then
		local target_aoi_id = self:getTargetAoiId(monster)
		if 0 < target_aoi_id then
			-- if targeter.aoi_id ~= target_aoi_id then
				-- 怪物已经在追踪玩家/侠客
				return false
			-- end
		end

		-- 让怪物停止移动
		MotionService:stop(monster)
	end

	-- 回家状态
	if self:isHoming(state) then
		MotionService:stop(monster)
	end

	return true
end


-- 判断是否允许立刻变成移动状态
-- monster : 怪物
-- targeter : 目标对象
-- return true / false
function MonsterAiService:isAllowChangeMoving(monster, targeter)
	local state = self:getNowState(monster)

	-- 死亡状态
	if self:isInDeadState(state) then
		return false
	end

	-- 原本就处于移动状态
	if self:isMoving(state) then
		return false
	end

	-- 战斗状态
	if self:isAutoFight(state) then
		-- 怪物攻击动作还没有播放完成
		if not self:isActionExpire(monster) then
			return false
		end
	end

	return true
end


-- 判断是否允许立刻变成回出生点状态
-- monster : 怪物
-- return true / false
function MonsterAiService:isAllowChangeHoming(monster)
	local state = self:getNowState(monster)

	-- 死亡状态
	if self:isInDeadState(state) then
		return false
	end

	return true
end


-- 判断是否允许立刻变成空闲状态
-- monster : 怪物
-- return true / false
function MonsterAiService:isAllowChangeIdel(monster)
	local state = self:getNowState(monster)

	-- 死亡状态
	if self:isInDeadState(state) then
		return false
	end

	-- 原本就处于空闲状态
	if self:isIdle(state) then
		return false
	end

	-- 原本处于移动状态
	if self:isMoving(state) then
		-- 让怪物停止移动
		MotionService:stop(monster)
	end

	-- 回家状态
	if self:isHoming(state) then
		MotionService:stop(monster)
	end

	return true
end


-- 判断是否允许立刻变成死亡状态(保留尸体)
-- monster : 怪物
-- return true / false
function MonsterAiService:isAllowChangePreDead(monster)
	local state = self:getNowState(monster)

	-- 原本就处于死亡状态
	if self:isInDeadState(state) then
		return false
	end

	-- 原本就处于移动状态
	if self:isMoving(state) then
		-- 让怪物停止移动
		MotionService:stop(monster, false)
	end

	-- 回家状态
	if self:isHoming(state) then
		MotionService:stop(monster, false)
	end

	return true
end


-- 判断是否允许立刻变成死亡状态(不保留尸体)
-- monster : 怪物
-- return true / false
function MonsterAiService:isAllowChangeDead(monster)
	local state = self:getNowState(monster)

	-- 原本就处于死亡状态(不保留尸体)--- 只能从死亡(保留尸体状态)切换过来
	if self:isPreDead(state) then
		return true
	end

	return false
end


-- 判断是否允许变成ai准备状态
-- monster : 怪物
-- return true / false
function MonsterAiService:isAllowChangeAiPrepare(monster)
	local state = self:getNowState(monster)

	-- 死亡状态
	if self:isInDeadState(state) then
		return false
	end

	-- 被技能锁定状态(入口(MonsterAiService:fight)就已经判断过了，这里不用判断)

	-- 原本就处于移动状态
	if self:isMoving(state) then
		return false
	end

	return true
end


-- 判断是否允许变成ai播放状态
-- monster : 怪物
-- return true / false
function MonsterAiService:isAllowChangeAiPlaying(monster)
	local state = self:getNowState(monster)

	-- 只能从准备状态变成播放状态
	if self:isAiPrepare(state) then
		return true
	end

	return false
end


-- 是否是同一个阵营
-- monster : 怪物
-- targeter : 角色/侠客
-- return true / false
function MonsterAiService:isSamePowersId(monster, targeter)
	local monster_powers_id = monster.tmps.powers_id or 0
	local targeter_powers_id = targeter.tmps and targeter.tmps.powers_id or 1

	if monster_powers_id == targeter_powers_id then
		return true
	end

	return false
end
--------------------------------------------------- 切换条件判断 end -------------------------------------------------------

--------------------------------------------------- 正式切换状态 start -----------------------------------------------------
-- 变成自动战斗状态
-- monster : 怪物
-- targeter : 目标对象
-- delay_msec : 延迟响应时间
function MonsterAiService:changeAutoFight(monster, targeter, delay_msec)
	local monsterTmps = monster.tmps

	-- 更新状态
	monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_AUTO_FIGHT

	-- 记录攻击目标
	monsterTmps.target_aoi_id = targeter.aoi_id

	-- 更新攻击的时间点
	if not delay_msec then
		local FightDefs = FightDefs
		delay_msec = random(FightDefs.FIGHT_MONSTER_RESPONSE_DELAY_MSEC_MIN, FightDefs.FIGHT_MONSTER_RESPONSE_DELAY_MSEC_MAX) -- 默认450-650毫秒随机
	end
	monsterTmps.fight_time = Time:getDelayMsTime(delay_msec)
end


-- 变成移动状态
-- monster : 怪物
-- targeter : 目标对象
-- target_pos_x : 目标位置x(返回出生点等)
-- target_pos_y : 目标位置y(返回出生点等)
-- error_span : 距离多远位置停下
-- is_clear_target : 是否清空目标对象(默认清除)(只适用于移动到目的地的)
-- is_walk : 是否用走的方式
function MonsterAiService:changeMoving(monster, targeter, target_pos_x, target_pos_y, error_span, is_clear_target, is_walk)
	local monsterTmps = monster.tmps
	local flg_find_path -- 是否找到路径

	-- 更新状态
	monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_MOVING

	local stime
	if g_bEnableLuaTimeoutGuard then
		stime = getNowUnixUsTime()
	end		
					
	if targeter then
		-- 记录攻击目标
		monsterTmps.target_aoi_id = targeter.aoi_id

		-- 获取距离目标多远可以停下
		if not error_span then
			error_span = 0
		end

		-- 移动方式是跑动
		monsterTmps.move_type_id = MonsterDefs.MOVE_TYPE_ID_FOR_RUN -- 跑动

		-- 调用场景移动接口(力志提供)
		flg_find_path = MotionService:startMoveToObj(monster, targeter, error_span)
		
		if g_bEnableLuaTimeoutGuard then
					local etime = getNowUnixUsTime()
					if etime-stime >50 then
					 printf('xxxtoMoveState act11: us:%d',etime-stime );
					end
		end
	else
		if nil == is_clear_target then
			is_clear_target = true -- 默认清空目标对象
		end
		
		if is_clear_target then
			-- 取消跟踪目标
			monsterTmps.target_aoi_id = 0
		end

		if is_walk then
			-- 移动方式是走动
			monsterTmps.move_type_id = MonsterDefs.MOVE_TYPE_ID_FOR_WALK -- 走动
		else
			-- 移动方式是跑动
			monsterTmps.move_type_id = MonsterDefs.MOVE_TYPE_ID_FOR_RUN -- 跑动
		end

		-- 调用场景移动接口(力志提供)
		flg_find_path = MotionService:startMoveToPos(monster, target_pos_x, target_pos_y, 0,nil,nil,g_FrameIdx)
		
		if g_bEnableLuaTimeoutGuard then
			local etime = getNowUnixUsTime()
			if etime-stime >50 then
			 printf('xxxtoMoveState act22:  us:%d',etime-stime );
			end
		end
	end

	-- 找不到路径
	if not flg_find_path then
		-- 回家状态
		self:toHomeState(monster)
		-- 延迟3秒下次寻找目标
		self:updateFindTime(monster, 3000)

		-- 日志记录
		self:logGoHome('寻路失败', monster, targeter, target_pos_x, target_pos_y)
		if g_bEnableLuaTimeoutGuard then
			local etime = getNowUnixUsTime()
			if etime-stime >50 then
			 print('xxxtoMoveState act33:',' us:',etime-stime );
			end
		end
	end
end


-- 变成返回出生点状态
-- monster : 怪物
function MonsterAiService:changeHoming(monster)
	-- local
	local MonsterBaseService = MonsterBaseService
	local monsterTmps = monster.tmps
	local monsterBase = monster.monster_base
	local monster_aoi = monster.monster_aoi

	-- 更新状态
	monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_FOR_HOMING

	-- 恢复满血满蓝
	local is_homing_max_hp = monsterBase.is_homing_max_hp or 0
	if MonsterDefs.IS_HOMING_MAX_HP_YES == is_homing_max_hp then
		monster.hp = MonsterBaseService:getMonsterBaseVal(monster, 'max_hp')
	end

	local old_target_aoi_id = monsterTmps.target_aoi_id or 0
	-- 取消跟踪目标
	monsterTmps.target_aoi_id = 0

	-- 清空我的仇恨列表
	local hate_lists = monsterTmps.hate_lists
	if hate_lists then
		MonsterService:cleanHateLists(monster)
	end

	-- 重置ai次数
	local is_homing_reset_ai = monsterBase.is_homing_reset_ai or 0
	if 1 == is_homing_reset_ai then
		self:resetAiState(monster, false)
	end

	-- 调用场景移动接口(力志提供)
	MotionService:startMoveToPos(monster, monsterTmps.active_x, monsterTmps.active_y, 0)

	-- 广播视野里的玩家放弃将自己作为目标 suwin
	self:bcGiveUpFightTarget(monster)
end


-- 变成死亡状态(保留尸体)
-- monster : 怪物
function MonsterAiService:changePreDead(monster)
	local monsterTmps = monster.tmps

	-- 更新状态
	monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_PRE_DEAD

	-- 清空追踪目标
	monsterTmps.target_aoi_id = 0

	-- 记录删除尸体时间(5秒后删除)
	-- 多少秒后删除尸体
	local del_delay_sec = monster.monster_base.del_delay_sec or 5
	monsterTmps.delete_time = Time:getDelayMsTime(del_delay_sec * 1000)

	-- 看看有没有召唤出来的怪也要删除
	self:delMyChildMonster(monster)
end


-- 变成死亡状态(不保留尸体)(吉林也会调用该接口，酒坛)
-- monster : 怪物
function MonsterAiService:changeDead(monster)
	local monsterTmps = monster.tmps
	local monsterBase = monster.monster_base
	local is_del = nil

	if 0 < monsterBase.relive_interval then -- 有复活间隔的，可复活
		local my_relive_nums = monsterTmps.my_relive_nums
		if 0 < my_relive_nums then
			if my_relive_nums >= monsterBase.relive_num then
				-- 更新状态(永不复活)
				monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_DEAD_FOREVER
				is_del = true
			else
				-- 更新状态(会复活)
				monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_DEAD
			end
		else
			-- 更新状态(会复活)
			monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_DEAD
		end

		-- 记录复活时间
		monsterTmps.relive_time = self:getReliveTime(monster)
	else
		-- 复活间隔为0的，永远不复活
		-- 更新状态(永不复活)
		monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_DEAD_FOREVER
		is_del = true
	end

	-- 清空掉落物记录
	monsterTmps.drop_items = nil

	if is_del then
		-- 不复活，或者没复活次数了
		GameObjectService:delObj(monster)
	else
		-- 从场景中删除(小蒋提供接口)
		GameObjectService:hideObject(monster, 0)
	end
end


-- 变成空闲状态
-- monster : 怪物
function MonsterAiService:changeIdle(monster)
	local monsterTmps = monster.tmps

	-- 更新状态
	monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_IDLE

	-- 清空追踪目标
	monsterTmps.target_aoi_id = 0
end


-- 变成AI准备状态
-- monster : 怪物
-- monsterAi : 要触发的ai
-- now_unix_time : 当前系统时间
function MonsterAiService:changeAiPrepare(monster, monsterAi, now_unix_time)
	local monsterTmps = monster.tmps

	-- 更新状态
	monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_AI_PREPARE

	-- 相关参数
	monsterTmps.ai_now_monster_ai = monsterAi -- 要发生的ai对象

	local prepare_msec = monsterAi.prepare_msec or 1000
	monsterTmps.ai_prepare_expire = Time:getDelayMsTime(prepare_msec)
end


-- 变成ai播放状态
-- monster : 怪物
function MonsterAiService:changeAiPlaying(monster)
	local monsterTmps = monster.tmps

	-- 更新状态
	monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_AI_PLAYING

	-- 相关参数
	local monsterAi = monsterTmps.ai_now_monster_ai
	if monsterAi then
		local ai_playing_msec = monsterAi.play_skill_msec or 0
		if 0 == ai_playing_msec then
			ai_playing_msec = 600
		end

		-- 单次攻击类
		if 1 == monsterAi.play_skill_times then
			-- 重剑力劈/跳跃攻击/...
			monsterTmps.ai_playing_expire = Time:getDelayMsTime(ai_playing_msec) -- ai播放过期
			monsterTmps.ai_playing_time = Time:getDelayMsTime(500)	 -- 多久后使用出技能
		else
			-- 持续性攻击类(不朽源泉/...)
			local play_skill_interval_ms = monsterAi.play_skill_interval * 1000 -- 每次触发间隔
			local ai_playing_expire = ai_playing_msec + 100

			monsterTmps.ai_playing_expire = Time:getDelayMsTime(ai_playing_expire) -- ai播放过期
			monsterTmps.ai_playing_time = Time:getDelayMsTime(play_skill_interval_ms) -- 多久后使用出技能
		end
	end
end
--------------------------------------------------- 正式切换状态 end -------------------------------------------------------

--------------------------------------------------- 辅助方法 start ---------------------------------------------------------
-- 获取怪物的状态
function MonsterAiService:getNowState(monster)
	return monster.tmps.now_state
end


-- 获取怪物的攻击对象的aoi_id
function MonsterAiService:getTargetAoiId(monster)
	return monster.tmps.target_aoi_id
end


-- 设置怪物的攻击对象
function MonsterAiService:setTargetAoiId(monster, targeter)
	monster.tmps.target_aoi_id = targeter.aoi_id
end


-- 获取怪物的复活时间点
function MonsterAiService:getReliveTime(monster)
	local relive_interval = monster.monster_base.relive_interval

	local relive_ms = 1000000000
	if 0 < relive_interval then
		relive_ms = relive_interval * 1000
	end

	return Time:getDelayMsTime(relive_ms)
end


-- 是否攻击时间点OK
function MonsterAiService:isFightTimeOk(monster, now_unix_mstime)
	return monster.tmps.fight_time <= now_unix_mstime
end


-- 更新下次攻击时间点
-- delay_ms : 下一次的毫秒
function MonsterAiService:updateFightTime(monster, delay_ms)
	monster.tmps.fight_time = Time:getDelayMsTime(delay_ms)
end


-- 是否寻找目标时间点OK
function MonsterAiService:isFindTimeOk(monster, now_unix_mstime)
	local find_time = monster.tmps.find_time or 0
	return find_time <= now_unix_mstime
end


-- 更新下次寻找目标时间点
-- delay_ms : 下一次的毫秒
function MonsterAiService:updateFindTime(monster, delay_ms)
	monster.tmps.find_time = Time:getDelayMsTime(delay_ms)
end


-- 延迟被攻击伤害cd
-- monster
function MonsterAiService:delayAttackCd(monster)
	local attack_delay_ms = monster.monster_base.attack_delay_ms or 0
	if 0 < attack_delay_ms then
		monster.tmps.fight_time = Time:getDelayMsTime(attack_delay_ms)
	end
end


-- 是否到时间变成死亡(删除尸体)时间点
function MonsterAiService:isDeleteTimeOk(monster, now_unix_mstime)
	return monster.tmps.delete_time <= now_unix_mstime
end


-- 是否复活时间点OK
function MonsterAiService:isReliveTimeOk(monster, now_unix_mstime)
	return monster.tmps.relive_time <= now_unix_mstime
end


-- 更新怪物上一次行为类型
-- monster : 怪物
-- state_id : 行为id
function MonsterAiService:updatePreState(monster, state_id)
	monster.tmps.pre_state = state_id
end


-- 判断怪物上一次行为是否为某种行为
-- monster : 怪物
-- state_id : 行为id
-- return : true / false
function MonsterAiService:isSamePreState(monster, state_id)
	return monster.tmps.pre_state == state_id
end


-- 更新主动怪物发现可追踪玩家的位置
function MonsterAiService:updateActivePos(monster)
	local monsterTmps = monster.tmps
	monsterTmps.active_x = monster.x
	monsterTmps.active_y = monster.y
end
--------------------------------------------------- 辅助方法 end -----------------------------------------------------------

--------------------------------------------------- 怪物行为 start ---------------------------------------------------------
-- 怪物攻击
-- aoiScene : 场景对象
-- monster : 怪物
-- now_unix_time : 当前系统的秒数
-- now_unix_mstime : 当前系统的毫秒数
function MonsterAiService:fight(aoiScene, monster, now_unix_time, now_unix_mstime)
	-- local
	local FightService = FightService

	-- 已死亡，不做事
	if FightService:isDead(monster) then
		return
	end

	-- 被连击中，不做事
	if FightService:isSkillLocked(monster) then
		return
	end

	-- 晕眩中
	if BufferService:isInStatus(monster, EffectType.giddiness) then
		return
	end

	-- 未到时间触发攻击
	if not self:isFightTimeOk(monster, now_unix_mstime) then
		return
	end

	-- 有AI被触发
	local is_ai_play, cd_ms = MonsterSkillAiService:playMyAi(aoiScene, monster, now_unix_time)
	if is_ai_play then
		-- 更新怪物下一次攻击时间点
		self:updateFightTime(monster, cd_ms)
		-- 更新怪物动作类型
		self:updatePreState(monster, Statics.AOI_OBJECT_STATUS_ID_AUTO_FIGHT)

		-- 广播给客户端触发ai动作
		return
	end

	-- local
	local monsterBase = monster.monster_base
	local monsterTmps = monster.tmps
	local CharacterService = CharacterService

	-- local
	local flg_change_idle = true -- 是否将怪物变成空闲
	local keep_on = true -- 是否可以执行攻击逻辑
	local is_fight_character = false -- 是否打角色

	-- 获取怪物要攻击的对象
	local target_aoi_id = self:getTargetAoiId(monster)
	local targeter = GameObjectService:getGameObjectByAoiId(aoiScene, target_aoi_id)

	-- 回防错误日志
	local go_home_msg = '' -- 回防原因
	if not targeter then
		go_home_msg = '找不到角色/幻兽/召唤兽'
		keep_on = false
	else
		-- 是不是打角色
		if FightService:isCharacter(targeter) then
			is_fight_character = true
		end
	end

	if keep_on then
		-- 角色是否可以被攻击
		if is_fight_character then
			local is_can_attack, is_follow = FightService:isCanAttack(monster, targeter)
			if not is_can_attack then
				if is_follow then
					-- 等待对象变成可以攻击，先跟随着
					self:updateFightTime(monster, 1000) -- 等待1秒后再尝试攻击
					return
				else
					-- 不能攻击也不能跟随，只能回家
					go_home_msg = '角色不能被攻击(死亡/保护/同阵营等)'
					keep_on = false
				end
			end
		else
			-- 攻击其他类型的对象，判断是否对象死亡
			if FightService:isDead(targeter) then
				-- 不能攻击也不能跟随，只能回家
				go_home_msg = '被攻击者死亡'
				keep_on = false
			end
		end
	end

	if keep_on then
		-- 可以攻击，则不能变成空闲
		flg_change_idle = false

		-- 初始化场景辅助信息
		local scene_base = SceneBaseService:getSceneBaseById(aoiScene.map_id)

		-- 怪物当前使用的技能
		local skill_id = monsterBase.skill_id
		local bufferBianSheng = BufferService:getBufferByType(monster, 'biansheng')
		if bufferBianSheng then -- 怪物如果变身，会有可能变成其他技能
			local biansheng_skill_id = bufferBianSheng.buffer_base.effect_value_ext.skill_id or 0
			if 0 < biansheng_skill_id then
				skill_id = biansheng_skill_id
			end
		end

		local skill = FightService:getFighterSkill(monster, skill_id)
		local skill_base = skill.skill_base
		local skill_base_distance = skill_base.distance

		-- local
		local aoi_object_status_id_moving = Statics.AOI_OBJECT_STATUS_ID_MOVING
		
		-- 判断距离
		local is_near_enough = FightService:isFightDisOk(monster, targeter, skill, 0)

		-- 距离还是太远
		if not is_near_enough then
			-- 怪物是否是静止怪
			if MonsterDefs.MOVE_SORT_ID_FOR_STATIC == monsterBase.move_sort_id then
				-- 变成空闲
				self:toIdleState(monster)
			else
				-- 距离太远，变成移动状态
				self:toMoveState(monster, targeter, nil, nil, skill_base_distance)
			end
			return
		else
			if self:isSamePreState(monster, aoi_object_status_id_moving) then
				-- 距离够近，看是否同位置有其他怪物，有就得移动
				-- local is_need_move, pos_x, pos_y = aoiScene:get_idle_pos(monster, targeter)
				local is_need_move, pos_x, pos_y = aoiScene:getIdlePosForMonster(monster.aoi_obj, targeter.aoi_obj)
				if is_need_move then
					local is_clear_target = false
					self:toMoveState(monster, nil, pos_x, pos_y, 0, is_clear_target)
					return
				end
			end
		end

		-- 使用技能
		local arr_pos = FightService:getDefaultPos()
		local keep_on, error_id, arr_targeter = FightService:doFight(aoiScene, monster, targeter, arr_pos, skill)

		if keep_on then
			-- 更新怪物下一次攻击时间点
			self:updateFightTime(monster, skill_base.play_cool_msec)
			-- 更新怪物动作类型
			self:updatePreState(monster, Statics.AOI_OBJECT_STATUS_ID_AUTO_FIGHT)

			-- 攻击后续处理
			FightService:doAfterFight(aoiScene, monster, targeter, arr_targeter)

			-- 正确的响应
			local ret_packet = FightService:buildBinPacket(aoiScene, monster, targeter, skill, arr_targeter, arr_pos, 0)
			if ret_packet then
				WorldPacket:m2cSendPacket(ret_packet)
			end

			-- print("-----------------------------------------------------------------------------")

			-- 通知buffer消息更新
			-- FightService:notifyUpdateBuffer(monster, arr_bc_player_id)

			-- 如果是被攻击的目标死亡，则也可以走空闲逻辑
			if FightService:isDead(targeter) then
				-- 立刻变成空闲
				flg_change_idle = true

				go_home_msg = '被攻击目标死亡'
			end
		end
	end

	-- 将怪物变成空闲状态
	if flg_change_idle then
		-- 如果有仇恨
		local hate_lists = monsterTmps.hate_lists
		if hate_lists then
			-- 将目标从仇恨列表中清除
			MonsterService:cleanHateLists(monster, target_aoi_id)

			-- 原来的目标删除
			monsterTmps.target_aoi_id = 0

			-- 寻找最大仇恨值(updateHatestAoiId里面会更新怪物的target_aoi_id)
			local new_target_aoi_id = MonsterService:updateHatestAoiId(monster)
			if 0 < new_target_aoi_id then
				-- 自动寻找下一个仇恨者
				return
			end
		end

		-- 是否回家
		if MonsterDefs.IS_IDLE_HOMING_YES == monsterBase.is_idle_homing then
			self:toHomeState(monster)

			-- 日志记录
			self:logGoHome(go_home_msg, monster, targeter)
		else
			self:toIdleState(monster)
		end
	end
end


-- 怪物复活
-- monster : 怪物
-- now_unix_mstime : 当前系统毫秒时间
function MonsterAiService:relive(monster, now_unix_mstime)
	-- 到时间点可以复活了
	if self:isReliveTimeOk(monster, now_unix_mstime) then
		-- local
		local MonsterBaseService = MonsterBaseService
		local monsterBase = monster.monster_base
		local monster_aoi  = monster.monster_aoi
		local monsterTmps = monster.tmps

		-- 重新赋值属性
		monster.hp = MonsterBaseService:getMonsterBaseVal(monster, 'max_hp')

		-- 恢复复活坐标和面朝方向
		monster.x = monster_aoi.x
		monster.y = monster_aoi.y
		monster.direction = monster_aoi.direction

		-- 将可看见我的角色清0(小蒋说不能再调用，因为aoi_obj已经不见了)
		-- monster.aoi_obj.see_player_num = 0

		-- 该怪物有复活次数限制
		if 0 < monsterBase.relive_num then
			-- 修改复活次数
			monsterTmps.my_relive_nums = monsterTmps.my_relive_nums + 1
		end

		-- 清空我的仇恨列表
		local hate_lists = monsterTmps.hate_lists
		if hate_lists then
			MonsterService:cleanHateLists(monster)
		end

		-- 重置我的ai参数
		self:resetAiState(monster, true)

		-- 变成空闲状态
		monsterTmps.now_state = Statics.AOI_OBJECT_STATUS_ID_IDLE

		-- 重置允许移动时间
		local move_delay_msec = monsterBase.move_delay_msec or 1000
		monsterTmps.allow_move_time = Time:getSecondsNow() + (move_delay_msec / 1000)

		-- 将怪物重新添加到场景里
		GameObjectService:showObject(monster, 0)
	end
end


do
	-- 通知视野里的玩家放弃将自己做为目标
	-- monster : 怪物
	local packet = FastPacket(1024)
	function MonsterAiService:bcGiveUpFightTarget(monster)
		local aoiScene = GameObjectService:getAoiScene(monster)
		local arr_gpid = GameObjectService:getFovGPids(monster, aoiScene)
		if not arr_gpid then
			-- 视野里没有玩家，就不通知了
			return nil
		end

		WorldPacket:resetWritePacket(packet, opCodes.M2C_FIGHT_GIVE_UP_FIGHT_TARGET)
		
		-- 包结构
		writeUInt(packet, monster.aoi_id)
		
		local ret_pack = WorldPacket:newClientPacket(opCodes.M2C_FIGHT_GIVE_UP_FIGHT_TARGET, nil, arr_gpid, 20)
		ret_pack:writeVer()
		ret_pack:writeFastPacketRaw(packet)
		WorldPacket:m2cSendPacket(ret_pack)
	end
end


-- 通知客户端一个怪物已死亡
-- monster : 怪物对象
function MonsterAiService:bcMonsterDead(monster)

	arr_rsp_bc_monster_dead.opcode = opCodes.M2C_FIGHT_BC_MONSTER_DEAD
	arr_rsp_bc_monster_dead.monster_aoi_id = monster.aoi_id

	local arr_bc_player_id = MonsterService:getFovPlayerIds(monster)
	WorldPacket:m2cSendOK(arr_rsp_bc_monster_dead, 0, arr_bc_player_id)
end


-- 怪物ai准备
-- monster : 怪物
-- now_unix_mstime : 当前系统毫秒时间
function MonsterAiService:aiPrepare(monster, now_unix_mstime)
	local monsterTmps = monster.tmps
	local ai_prepare_expire = monsterTmps.ai_prepare_expire or 0

	-- 时间到了就变成ai播放状态
	if now_unix_mstime >= ai_prepare_expire then
		self:toAiPlayingState(monster)
	end
end


-- 怪物ai播放 suwin
-- aoiScene : 场景实例 
-- monster : 怪物
-- now_unix_mstime : 当前系统毫秒时间
function MonsterAiService:aiPlaying(aoiScene, monster, now_unix_mstime)
	local monsterTmps = monster.tmps
	local ai_playing_expire = monsterTmps.ai_playing_expire or 0
	local flg_finish_action = false -- 是否结束ai

	-- 是否在总的可触发时间内
	if now_unix_mstime < ai_playing_expire then
		-- 是否已到下一次触发时间
		local ai_playing_time = monsterTmps.ai_playing_time or 0
		if now_unix_mstime >= ai_playing_time then
			-- local
			local monsterAi = monsterTmps.ai_now_monster_ai -- 要触发的ai对象
			if monsterAi then
				-- 触发怪物技能ai
				MonsterSkillAiService:playAiAttack(aoiScene, monster, monsterAi)
			else
				-- 找不到ai技能信息
				flg_finish_action = true
			end
		end
	else
		-- ai过期了
		flg_finish_action = true
	end

	if flg_finish_action then
		self:doAfterAction(aoiScene, monster)
	end
end
--------------------------------------------------- 怪物行为 end -----------------------------------------------------------


--------------------------------------------------- 怪物战斗逻辑辅助方法 start ---------------------------------------------
-- 重置怪物ai计数
-- monster : 怪物
-- is_reset_zhaohuan : 是否重置召唤
function MonsterAiService:resetAiState(monster, is_reset_zhaohuan)
	local monsterTmps = monster.tmps

	-- 替怪物加上触发ai判断时间(怪物出生多久后才开始走AI判断)
	local ai_delay_msec = monster.monster_base.ai_delay_msec or 10000
	monsterTmps.ai_can_play_expire = Time:getSecondsNow() + (ai_delay_msec / 1000)

	-- 清空一些ai参数
	monsterTmps.ai_targeter_aoi_id = 0
	monsterTmps.ai_targeter_pos_x = 0
	monsterTmps.ai_targeter_pos_y = 0
	monsterTmps.ai_kill_monster_num = 0

	if is_reset_zhaohuan then
		-- monsterTmps.ai_zhaohuan_time = 0	-- 召唤时间
		-- monsterTmps.ai_zhaohuan_nums = 0	-- 召唤次数
	end

	-- 循环重置ai参数
	local arr_ai_datas = monsterTmps.ai_datas
	for key, _ in pairs(arr_ai_datas) do
		arr_ai_datas[key] = 0
	end
end


-- 删除掉我召唤的子怪
-- monster : 怪物
function MonsterAiService:delMyChildMonster(monster)
	local ai_child_monster_aoi_id = monster.tmps.ai_child_monster_aoi_id
	local child_count = sizeTable(ai_child_monster_aoi_id)
	if 0 < child_count then
		local aoiScene = GameObjectService:getAoiScene(monster)
		for i = 1, child_count do
			local now_monster_aoi_id = ai_child_monster_aoi_id[i]
			local nowChildMonster = GameObjectService:getGameObjectByAoiId(aoiScene, now_monster_aoi_id)
			if nowChildMonster and (0 < nowChildMonster.hp) then
				-- 怪物变成死亡状态(保留尸体)
				self:toPreDeadState(nowChildMonster)

				-- 停止怪物移动(小蒋提供接口)
				MotionService:stop(nowChildMonster)
			end
		end
	end
end
--------------------------------------------------- 怪物战斗逻辑辅助方法 end -----------------------------------------------

--------------------------------------------------- 日志记录 start ---------------------------------------------------------
-- 记录日志记录
-- msg : 描述信息
-- monster : 怪物对象
-- targeter : 角色对象 / 侠客
-- target_x : 寻路目标x
-- target_y : 寻路目标y
function MonsterAiService:logGoHome(msg, monster, targeter, target_x, target_y)
	-- local
	-- 只记录紫禁之巅的
	
	--[[
	if monster and 20010 == monster.monster_aoi.scene_id then
		local file_name = 'monster_go_home.log'
		msg = Time:getSecondsNow() .. '|' .. msg .. '|' .. monster.monster_base.nick .. '|' .. monster.x .. '|' .. monster.y .. '|'
		if targeter then
			msg = msg .. targeter.nick .. '|' .. targeter.x .. '|' .. targeter.y .. '|'
		end

		if target_x and target_y then
			msg = msg  .. 'target_x:' .. target_x .. '|target_y:' .. target_y .. '|'
		end

		external.log(msg, file_name)
	end
	--]]
end
--------------------------------------------------- 日志记录 end -----------------------------------------------------------