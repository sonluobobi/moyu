--[[
安全模式系统 SERVICE
author : xingzeng.jiang
date : 2014-10-16
--]]

SafeModeService = SafeModeService or {}

local WorldPacket = WorldPacket
local Time = Time
local random = math.random
local os_time = os.time
local ceil = math.ceil
local table = table
local next = next
local pairs = pairs
local string_len = string.len
local SafeModeDefs = SafeModeDefs
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local aoi_type_monster = AoiObjectType.AOI_OBJECT_TYPE_ID_MONSTER
local RedNameDefs = RedNameDefs
local Statics = Statics

local GameObjectService, RednameService, FightService
function SafeModeService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
	RednameService = _G.RednameService
	WanfaAoiService = _G.WanfaAoiService
	FightService = _G.FightService
end

-- 初始化
function SafeModeService:init(character)
	local safe_mode_info = character.safe_mode_info
	
	if (type(safe_mode_info) == "string" and string_len(safe_mode_info) > 1) then
		character.safe_mode_info = WorldPacket:decodeData(character.safe_mode_info)
		setmetatable(character.safe_mode_info, SafeModeInfo)
	else
		character.safe_mode_info = SafeModeInfo:new()
	end
end

-- 打包
function SafeModeService:pack(character)
	local str = WorldPacket:encodeData(character.safe_mode_info)
	return str
end

-- 响应PK完成
function SafeModeService:onPlayerHarm(character, arr_character_harm)
	local safe_mode_cool = Time.time_second + SafeModeDefs.SAFE_MODE_PK_COOL_SEC
	local my_zhenying = character.tmps.zhenying
	local DEFAULT_ZHENYING_SHOU = Statics.DEFAULT_ZHENYING_SHOU
	local DEFAULT_ZHENYING_GONG = Statics.DEFAULT_ZHENYING_GONG
	
	-- 增加切换模式冷却时间
	character.safe_mode_info.safe_mode_cool = safe_mode_cool
	
	if arr_character_harm and my_zhenying ~= DEFAULT_ZHENYING_SHOU and my_zhenying ~= DEFAULT_ZHENYING_GONG then
		local aoi_scene = GameObjectService:getAoiScene(character)
		
		for aoi_id, _ in pairs(arr_character_harm) do
			local game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
			if game_obj.aoi_type == aoi_type_player then
				-- 劫镖、运镖模式下不影响红名、安全模式
				local zhenying = game_obj.tmps.zhenying
				if zhenying ~= DEFAULT_ZHENYING_SHOU and zhenying ~= DEFAULT_ZHENYING_GONG then
					game_obj.safe_mode_info.safe_mode_cool = safe_mode_cool
					
					-- 添加到临时仇敌列表
					self:toOurTmpEnemy(character, game_obj)
				end
			end
		end
	end
end

-- 游戏服同步安全模式、红名信息到PK服
function SafeModeService:sync(character, safe_mode_info_in)
	local safe_mode_info = character.safe_mode_info
	
	local old_is_rn_dead = safe_mode_info.is_rn_dead
	local old_redname = safe_mode_info.redname
	local old_safe_mode = safe_mode_info.safe_mode
	
	safe_mode_info.safe_mode = safe_mode_info_in.safe_mode
	safe_mode_info.is_rn_dead = safe_mode_info_in.is_rn_dead
	safe_mode_info.redname = safe_mode_info_in.redname
	
	local is_in_outdoor = OutdoorService:isInOutdoor(character.scene_id) or OutdoorBossService:isInOutdoorBoss(character.scene_id)
	local old_status, status
	
	if old_safe_mode ~= safe_mode_info.safe_mode and is_in_outdoor then
		WanfaAoiService:setWanfaAoiData(character, 'safe_mode', safe_mode_info.safe_mode, true)
	end
	
	if old_is_rn_dead ~= safe_mode_info_in.is_rn_dead then
		RednameService:autoAddBuffer(character)
		
	elseif old_redname ~= safe_mode_info_in.redname then
		old_status = RednameService:getRednameStatus(old_redname)
		status = RednameService:getRednameStatus(safe_mode_info.redname)
		if old_status ~= status then
			RednameService:autoAddBuffer(character)
		end
		
		if is_in_outdoor then
			WanfaAoiService:setWanfaAoiData(character, 'redname_status', status, true)
		end
	end
	
	SafeModeService:sendNotice(old_status, status, old_is_rn_dead, safe_mode_info.is_rn_dead)
end

function SafeModeService:sendNotice(old_status, status, old_is_rn_dead, is_rn_dead)
	if old_status ~= status then
		if status == RedNameDefs.RED_NAME_STATUS_LIGHT then
			WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SAFE_MODE_REDNAME_LIGHT)
		elseif status == RedNameDefs.RED_NAME_STATUS_MIDDLE then
			WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SAFE_MODE_REDNAME_MIDDLE)
		elseif status == RedNameDefs.RED_NAME_STATUS_SERIOUS then
			WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SAFE_MODE_REDNAME_HIGH)
		else
			WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SAFE_MODE_REDNAME_NONE)
		end
	end
	
	if old_is_rn_dead ~= is_rn_dead and is_rn_dead == 1 then
		WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SAFE_MODE_REDNAME_DEAD)
	end
end

-- 把攻击者和被攻击者的相互加入临时仇家列表里
-- fighter : 攻击者(肯定是角色)
-- targeter : 被攻击者(肯定是角色)
function SafeModeService:toOurTmpEnemy(fighter, targeter)
	-- 当前系统时间
	local now_time = Time.time_second

	-- 攻击者加入被攻击者仇家里
	local arr_targeter_tmp_enemy = targeter.tmps_ex.outdoor_tmp_enemys or {}
	targeter.tmps_ex.outdoor_tmp_enemys = arr_targeter_tmp_enemy
	local fighter_gcid = fighter.gcid
	local tmp_enemy = arr_targeter_tmp_enemy[fighter_gcid]
	local tmp_enemy_expire = tmp_enemy and tmp_enemy.expire_time or 0
	if tmp_enemy_expire < now_time then
		if not tmp_enemy then
			tmp_enemy = {gcid = fighter_gcid}
			arr_targeter_tmp_enemy[fighter_gcid] = tmp_enemy
		end
		tmp_enemy.expire_time = now_time + SafeModeDefs.TMP_ENEMY_EXPIRE_SEC
		tmp_enemy.aoi_id = fighter.aoi_id
	end

	-- 被攻击者加入攻击者仇家里
	local arr_fighter_tmp_enemy = fighter.tmps_ex.outdoor_tmp_enemys or {}
	fighter.tmps_ex.outdoor_tmp_enemys = arr_fighter_tmp_enemy
	local targeter_gcid = targeter.gcid
	local tmp_enemy = arr_fighter_tmp_enemy[targeter_gcid]
	local tmp_enemy_expire = tmp_enemy and tmp_enemy.expire_time or 0
	if tmp_enemy_expire < now_time then
		if not tmp_enemy then
			tmp_enemy = {gcid = targeter_gcid}
			arr_fighter_tmp_enemy[targeter_gcid] = tmp_enemy
		end
		tmp_enemy.expire_time = now_time + SafeModeDefs.TMP_ENEMY_EXPIRE_SEC
		tmp_enemy.aoi_id = targeter.aoi_id
	end
end

-- 判断被攻击者是否是我的仇家
-- fighter : 攻击者(肯定是角色)
-- targeter : 被攻击者(肯定是角色)
function SafeModeService:isMyTmpEnemy(fighter, targeter)
	-- local
	local tmp_enemys = fighter.tmps_ex.outdoor_tmp_enemys or {}
	fighter.tmps_ex.outdoor_tmp_enemys = tmp_enemys
	local now_time = Time.time_second

	-- 清除掉过期的
	for gcid, tmp_enemy in pairs(tmp_enemys) do
		if now_time > tmp_enemy.expire_time then
			tmp_enemys[gcid] = nil
		end
	end

	return tmp_enemys[targeter.gcid]
end

-- 检查攻击者是否能攻击目标
-- fighter : 攻击者(肯定是角色)
-- targeter : 被攻击者(角色/侠客/怪物)
-- return boolean
function SafeModeService:isCanAttack(fighter, targeter)  
	local is_in_outdoor = OutdoorService:isInOutdoor(fighter.scene_id)
	local is_in_outdoor_boss = OutdoorBossService:isInOutdoorBoss(fighter.scene_id)
	-- 不在野外
	if not is_in_outdoor and not is_in_outdoor_boss then
		return true
	end
	
	--劫镖判断
  if is_in_outdoor and not JieBiaoService:isCanAttack(fighter,targeter) then return false end
	
	-- 怪物可以打或被打
	if targeter.aoi_type == aoi_type_monster or fighter.aoi_type == aoi_type_monster then
		return true
	end
	
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	local character
	local parent_aoi_id = fighter.parent_aoi_id
	if fighter.aoi_type == aoi_type_player then
		character = fighter
	elseif parent_aoi_id and parent_aoi_id > 0 then
		character = GameObjectService:getGameObjectByAoiId(aoi_scene, parent_aoi_id)
	else
		-- 非召唤兽或幻兽、非玩家
		return true
	end
	
	-- 无主人状态
	if not character then
		return true
	end
	
	-- 主人是怪物
	if character.aoi_type == aoi_type_monster then
		return true
	end
	
	local character_targeter
	local parent_aoi_id = targeter.parent_aoi_id
	if targeter.aoi_type == aoi_type_player then
		character_targeter = targeter
	elseif parent_aoi_id and parent_aoi_id > 0 then
		character_targeter = GameObjectService:getGameObjectByAoiId(aoi_scene, parent_aoi_id)
	else
		-- 非召唤兽或幻兽、非玩家
		return true
	end
	
	-- 无主人状态
	if not character_targeter then
		return true
	end
	
	-- 主人是怪物
	if character_targeter.aoi_type == aoi_type_monster then
		return true
	end
	
	local my_safe_mode = character.safe_mode_info.safe_mode
	
	-- 同帮会的，不可以打
	local gang_id_targeter = character_targeter.gang_id 
	local gang_id = character.gang_id 
	if my_safe_mode == SafeModeDefs.SAFE_MODE_PK and gang_id and gang_id > 0 and gang_id_targeter == gang_id then
		return false, '同帮会的，不能打'
	end
	
	-- 被攻击者和攻击者都是和平模式
	if my_safe_mode == SafeModeDefs.SAFE_MODE_SPACE and
		character_targeter.safe_mode_info.safe_mode == SafeModeDefs.SAFE_MODE_SPACE then
		return false, '和平模式不能攻击其他和平模式的玩家'
	end
	
	-- 攻击目标阵营是中立，也返回true (这里有BUG,会导致可以杀阵营为0的玩家)
	--if targeter.tmps.zhenying == Statics.DEFAULT_ZHENYING_NEUTRAL then
	--	return true
	--end
	
	-- 攻击者是军团模式
	if my_safe_mode == SafeModeDefs.SAFE_MODE_PK then
		return true
	end
	
	-- 攻击者是自由PK模式
	if my_safe_mode == SafeModeDefs.SAFE_MODE_FREE_PK then
		return true
	end
	
	-- 被攻击者是红名
	if RednameService:isReadname(character_targeter) then
		return true
	end
	
	-- 存在临时仇家关系，则肯定可以打，不管模式
	if self:isMyTmpEnemy(character, character_targeter) then
		return true
	end
	
	return false, '和平模式下，不能攻击非红名玩家'
end

-- 是否在屠杀模式下可以攻击targeter
function SafeModeService:isEnAttackByFreePK(fighter, targeter)
	-- 不同阵营可以攻击
	if not FightService:isSameZhenYing(fighter, targeter) then
		return true
	end
	
	-- 攻击者不是玩家
	if fighter.aoi_type ~= aoi_type_player then
		return false
	end
	
	local is_in_outdoor = OutdoorService:isInOutdoor(fighter.scene_id)
	local is_in_outdoor_boss = OutdoorBossService:isInOutdoorBoss(fighter.scene_id)
	-- 不在野外
	if not is_in_outdoor and not is_in_outdoor_boss then
		return false
	end
	
	-- 不在屠杀模式
	if fighter.safe_mode_info.safe_mode ~= SafeModeDefs.SAFE_MODE_FREE_PK then
		return false
	end
	
	-- 目标玩家
	local ch_targeter
	if targeter.aoi_type ~= aoi_type_player then
		-- 目标没有主人, 或是攻击者子对象
		if not targeter.parent_aoi_id or targeter.parent_aoi_id == fighter.aoi_id or targeter.gcid == fighter.gcid then
			return false
		end
		local aoi_scene = GameObjectService:getAoiScene(fighter)
		ch_targeter = GameObjectService:getGameObjectByAoiId(aoi_scene, targeter.parent_aoi_id)
	else
		ch_targeter = targeter
	end
	
	-- 是队友,可以攻击
	if ch_targeter and ch_targeter.gcid ~= fighter.gcid and ch_targeter.id ~= fighter.id and TeamService:isTwoChInSameTeam(fighter, ch_targeter) then
		return true
	end
	
	return false
end

do
	local rsp_opcode = opCodes.PKM2C_SAFE_MODE_SET
	local msg_name = "PackSafeMode.PKM2C_SAFE_MODE_SET"
	local msg_proto = {}
	function SafeModeService:sendSafeModeSet(character, safe_mode, token)
		msg_proto.safe_mode = safe_mode
		msg_proto.token = token
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_SAFE_MODE_GET_TMP_ENEMYS
	local msg_name = "PackSafeMode.M2C_SAFE_MODE_GET_TMP_ENEMYS"
	local msg_proto = {}
	function SafeModeService:sendTmpEnemys(character)
		msg_proto.enemys = table.values(character.tmps_ex.outdoor_tmp_enemys)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end