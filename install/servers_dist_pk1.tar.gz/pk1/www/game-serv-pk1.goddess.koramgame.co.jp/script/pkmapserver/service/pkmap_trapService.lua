--[[
陷阱系统 service
author : shuyi.zhong
date : 2014-10-30
--]]

TrapService = TrapService or {}

local WorldPacket = WorldPacket
local Statics = Statics
local Time = Time
local random = math.random
local ceil = math.ceil
local table = table
local tableInsert = table.insert
local sizeTable = table.sizeTable
local ext_getNowUnixMsTime = external.getNowUnixMsTime
local DEFAULT_ZHENYING_TRAP = Statics.DEFAULT_ZHENYING_TRAP
local ResultTypeMiss = FightDefs.ResultTypeMiss -- 闪避

local FightService
local GameObjectService
local BufferBaseService
local BufferService
function TrapService:onAfterLoadLua()
	FightService = _G.FightService
	GameObjectService = _G.GameObjectService
	BufferBaseService = _G.BufferBaseService
	BufferService = _G.BufferService
end


do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	
	-- 写入基础外观
	function TrapService:writeObjAppear(trap, fast_packet)
		writeByte(fast_packet, 0)						-- speed
		writeLong(fast_packet, 0)
		writeUInt(fast_packet, trap.trap_base.id)		-- base_id
		writeUInt(fast_packet, trap.parent_aoi_id or 0)	-- parent_aoi_id
	end
	
	-- 写入详细外观
	function TrapService:writeObjAppearDetail(trap, fast_packet)
		
		writeLong(fast_packet, trap.expire_time)	-- 陷阱结束时间
		
	end
end


do
	local TRAP_SORT_ID_LOST_HP = TrapDefs.TRAP_SORT_ID_LOST_HP					-- 固定扣血
	local TRAP_SORT_ID_LOST_HP_PERCENT = TrapDefs.TRAP_SORT_ID_LOST_HP_PERCENT	-- 百分比扣血
	local TRAP_SORT_ID_SKILL_ID = TrapDefs.TRAP_SORT_ID_SKILL_ID				-- 通过技能计算扣血
	local TRAP_SORT_ID_ADD_BUFFER = TrapDefs.TRAP_SORT_ID_ADD_BUFFER			-- 触发buffer
	local TRAP_SORT_ID_ADD_BUFFER_WANFA = TrapDefs.TRAP_SORT_ID_ADD_BUFFER_WANFA-- 触发玩法buffer
	local TRAP_SORT_ID_PARENT_LEVEL = TrapDefs.TRAP_SORT_ID_PARENT_LEVEL		-- 召唤者等级 * 固定值
	local externalCombineBit = external.combine_bit
	local AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER		-- 角色
	local AoiObjectType_AOI_OBJECT_TYPE_ID_PET = AoiObjectType.AOI_OBJECT_TYPE_ID_PET			-- 幻兽
	local AoiObjectType_AOI_OBJECT_TYPE_ID_BEAST = AoiObjectType.AOI_OBJECT_TYPE_ID_BEAST		-- 召唤兽
	local AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT		-- 机器人

	local TRAP_ID_FOR_CHUANRANXIANJIN = TrapDefs.TRAP_ID_FOR_CHUANRANXIANJIN -- 丧尸危机，感染陷阱

	-- 陷阱每帧更新入口
	function TrapService:update(time_now, aoiScene, arr_trap)
		local FightService = FightService
		local GameObjectService = GameObjectService

		for aoi_id, now_trap in pairs(arr_trap) do
			if time_now < now_trap.expire_time then
				-- 还没过期

				-- 是否到时间触发攻击
				local next_play_time = now_trap.next_play_time
				if time_now > next_play_time  then
					-- print('陷阱攻击啦......................................')
					-- local
					local now_trapBase = now_trap.trap_base
					local sort_id = now_trapBase.sort_id	   -- 陷阱类型
					
					-- 更新下一次触发时间(避免因为下面逻辑出错而影响更新)
					now_trap.next_play_time = now_trap.next_play_time + now_trapBase.interval
					
					-- add by xingzeng.jiang
					if TRAP_SORT_ID_ADD_BUFFER_WANFA == sort_id then
						-- 触发玩法buffer 陷阱，触发不能太频繁，这里强制控制在500ms以内
						if now_trapBase.interval < 500 then
							now_trapBase.interval = 500
						end
						
						local now_trap_radius = now_trapBase.radius
						local dest_type = externalCombineBit(AoiObjectType_AOI_OBJECT_TYPE_ID_PLAYER, AoiObjectType_AOI_OBJECT_TYPE_ID_PET, AoiObjectType_AOI_OBJECT_TYPE_ID_BEAST, AoiObjectType_AOI_OBJECT_TYPE_ID_ROBOT)
						local arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(now_trap.aoi_obj, now_trap.x, now_trap.y, now_trap_radius, dest_type)
						local buffer_ids = now_trapBase.buffer_ids -- 召唤的buffer数组
						
						-- 过滤掉不能攻击的
						local arr_targeter, targeter_num = FightService:filterTargeter(aoiScene, now_trap, arr_aoiObj, aoiObj_num)

						-- 存在可攻击对象
						if 0 < targeter_num then
							for i = 1, targeter_num do
								local now_targeter = arr_targeter[i]
								
								local is_need_send = false -- 是否添加buff成功，是否需要广播
								for _, now_buffer_id in pairs(buffer_ids) do
									local now_bufferBase = BufferBaseService:getBufferBaseById(now_buffer_id)
									if BufferBaseService:isInstantBuffer(nil, now_bufferBase) then
										BufferService:useInstantBuffer(now_targeter, now_bufferBase)
									else
										local is_add_buffer_sucess, is_need_bc = BufferService:addTmpBuffer(now_targeter, now_bufferBase, nil, nil, true)
										if is_add_buffer_sucess then
											if 1 == is_need_bc then
												is_need_send = true -- 需要发送给客户端
											end
										end
									end
								end
								-- 广播buff
								if is_need_send then
									BufferService:bcBuffers(aoiScene, now_targeter)
								end
							end
						end
					else
						-- 召唤出陷阱的对象
						local fighter = self:getMyParent(aoiScene, now_trap)
						if fighter then
							-- 陷阱属性
							local param = now_trapBase.param or 0	   -- 参数值
							local buffer_ids = now_trapBase.buffer_ids -- 召唤的buffer数组

							-- 陷阱影响的对象的血的变化队列
							local arr_aoi_change_hp = {}
							local targeter = nil
							local arr_targeter, targeter_num

							-- 固定扣血/百分比/召唤者等级扣血等
							if (TRAP_SORT_ID_LOST_HP == sort_id) or (TRAP_SORT_ID_LOST_HP_PERCENT == sort_id) or (TRAP_SORT_ID_PARENT_LEVEL == sort_id) then
								-- 攻击处理
								local now_trap_radius = now_trapBase.radius
								local dest_type = FightService:getFightDestTypes(aoiScene, fighter)
								local arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(now_trap.aoi_obj, now_trap.x, now_trap.y, now_trap_radius, dest_type)

								-- 过滤掉不能攻击的
								arr_targeter, targeter_num = FightService:filterTargeter(aoiScene, now_trap, arr_aoiObj, aoiObj_num)

								-- 存在可攻击对象
								if 0 < targeter_num then
									local harm, harm_perc
									for i = 1, targeter_num do
										-- init
										harm = 0 -- 伤害绝对值
										harm_perc = 0 -- 伤害百分比值

										-- 取出被攻击者
										local now_targeter = arr_targeter[i]

										if TRAP_SORT_ID_LOST_HP == sort_id then
											-- 固定值
											harm = param
										elseif TRAP_SORT_ID_LOST_HP_PERCENT == sort_id then
											-- 百分比
											harm = ceil(FightService:getOutestMaxHp(now_targeter) * param / 100)
										else
											-- 召唤者等级 * 固定值
											local parent_level = 0
											if FightService:isMonster(fighter) then -- 陷阱是怪物召唤出来的
												parent_level = fighter.monster_base.level or 1
											else
												parent_level = fighter.level or 1 -- 玩家召唤的
											end
											harm = ceil(parent_level * param)
										end

										FightService:doFight(aoiScene, fighter, now_targeter, nil, nil, {now_targeter}, harm)

										self:addToAoiChangeHp(arr_aoi_change_hp, now_targeter)
									end
								end

							elseif (TRAP_SORT_ID_SKILL_ID == sort_id) then
								-- 技能id
								local skill_id = param

								-- 动态扣血百分比(玩家/怪物召唤出来的陷阱)
								local arr_pos = FightService:getDefaultPos()
								arr_pos.fighter_attack_x = now_trap.x -- 攻击的真实位置是陷阱的位置才对
								arr_pos.fighter_attack_y = now_trap.y

								local skill = FightService:getFighterSkill(now_trap, skill_id)
								local keep_on, error_id

								keep_on, error_id, arr_targeter = FightService:doFight(aoiScene, fighter, targeter, arr_pos, skill)

								-- 广播扣血信息
								for _, now_targeter in pairs(arr_targeter) do
									self:addToAoiChangeHp(arr_aoi_change_hp, now_targeter)
								end

							elseif (TRAP_SORT_ID_ADD_BUFFER == sort_id) then
								-- 加buffer
								local now_trap_radius = now_trapBase.radius

								local is_only_character = false
								local is_need_same_zhenying = 1
								if TRAP_ID_FOR_CHUANRANXIANJIN == now_trapBase.id then
									-- 丧尸危机的感染只感染角色的
									is_only_character = true
									is_need_same_zhenying = 0 -- 可以感染自己阵营的人
								end

								local dest_type = FightService:getFightDestTypes(aoiScene, fighter, is_only_character)
								local arr_aoiObj, aoiObj_num = aoiScene:getRoundObjs(now_trap.aoi_obj, now_trap.x, now_trap.y, now_trap_radius, dest_type)

								-- 过滤掉不能攻击的
								arr_targeter, targeter_num = FightService:filterTargeter(aoiScene, now_trap, arr_aoiObj, aoiObj_num, nil, is_need_same_zhenying)

								-- 存在可攻击对象
								if 0 < targeter_num then
									for i = 1, targeter_num do
										local arr_add_ok_buffer_id = {} -- 被成功添加的buffer_id数组，用于后面广播更新
										local now_targeter = arr_targeter[i]
										-- 目前的buffer只有晕眩的，所以暂时写死幻兽不会被打中，并且晕眩中不会继续被打中
										if not FightService:isPet(now_targeter) and (not BufferService:isInStatus(now_targeter, EffectType.giddiness)) then
											local is_need_send = false -- 是否添加buff成功，是否需要广播
											for _, now_buffer_id in pairs(buffer_ids) do
												local now_bufferBase = BufferBaseService:getBufferBaseById(now_buffer_id)
												local is_add_buffer_sucess, is_need_bc = BufferService:addTmpBuffer(now_targeter, now_bufferBase, nil, nil, true)
												if is_add_buffer_sucess then
													tableInsert(arr_add_ok_buffer_id, now_buffer_id)
													if 1 == is_need_bc then
														is_need_send = true -- 需要发送给客户端
													end
												end
											end
											-- 广播buff
											if is_need_send then
												-- 广播对象的buff(小蒋提供接口)
												BufferService:bcBuffers(aoiScene, now_targeter)
											end
										end -- if not FightService:isPet(now_targeter) then
									end
								end
							else
								error("陷阱的类型有错误；陷阱名字：" .. now_trapBase.title)
							end

							-- 广播血量变化
							FightService:sendObjsChangeHp(aoiScene, now_trap, arr_aoi_change_hp)

							-- 攻击后的统一处理
							if 0 < sizeTable(arr_targeter) then
								-- 攻击后逻辑处理(要放在攻击包/血量更新包后面，不然客户端会出错)
								FightService:doAfterFight(aoiScene, fighter, nil, arr_targeter)
							end
						else
							-- 召唤者已经不见了，删除掉陷阱
							GameObjectService:delObj(now_trap, aoiScene)
						end	--if fighter then
					end --if TRAP_SORT_ID_ADD_BUFFER_WANFA == sort_id then
				end
			else
				-- 已经过期，要删除掉
				GameObjectService:delObj(now_trap, aoiScene)
			end
		end
	end


	-- 添加到更新队列里
	function TrapService:addToAoiChangeHp(arr_aoi_change_hp, targeter)
		local targeter_tmps_fight_info = targeter.tmps.fight_info
		local targeter_tmps_fight_info_action_id = targeter_tmps_fight_info.action_id
		-- 闪避的要跳过
		if ResultTypeMiss ~= targeter_tmps_fight_info_action_id then
			if targeter_tmps_fight_info.arr_targeter_del_hp[1] then -- 有这种报错，但还未知是什么原因导致，先加上这个判断，避免报错
				local hp_index = targeter_tmps_fight_info.arr_targeter_del_hp[1][1]
				local change_hp = targeter_tmps_fight_info.arr_targeter_del_hp[1][2]
				local now_hp = targeter_tmps_fight_info.arr_targeter_del_hp[1][3]
				local now_aoi_change_hp = FightService:newObjChangeHp(targeter.aoi_id, hp_index, 
																						change_hp, now_hp, 
																							targeter_tmps_fight_info_action_id)
				tableInsert(arr_aoi_change_hp, now_aoi_change_hp)
			end
		end
	end
end


do
	-- 创建一个新的陷阱，并添加到场景实例中去，广播给客户端
	-- aoiScene : 场景实例id
	-- trap_id : 陷阱id
	-- x : 创建陷阱的x坐标
	-- y : 创建陷阱的y坐标
	-- fighter : 创建者(可以为nil)
	local AoiObject_new = AoiObject.new
	function TrapService:createTrap(aoiScene, trap_id, x, y, fighter)
		local GameObjectService = GameObjectService

		local trap_base = assert(TrapBaseDao[trap_id], trap_id)

		local trap = self:newTrap(trap_base, fighter)

		local aoi_obj = AoiObject_new(AoiObject, AoiObjectType.AOI_OBJECT_TYPE_ID_TRAP, x, y, 0, trap, aoiScene)
		GameObjectService:addObj(trap, aoi_obj, aoiScene)

		if fighter then
			fighter.tmps.my_trap_aoi_id = trap.aoi_id
		end
		
		return trap
	end


	-- new一个陷阱实体
	-- trap_base : 陷阱基本信息
	-- fighter : 放出陷阱的人(可以为nil)
	function TrapService:newTrap(trap_base, fighter)
		local trap = {}

		trap.nick = trap_base.title -- 规范命名
		
		trap.next_play_time = ext_getNowUnixMsTime() + trap_base.perpare_time	-- 下一次释放效果时间
		trap.expire_time = ext_getNowUnixMsTime() + trap_base.duration -- 过期时间

		trap.parent_aoi_id = fighter and fighter.aoi_id or 0 -- 主人的AOI ID

		local my_zhenying = fighter and fighter.tmps.zhenying or DEFAULT_ZHENYING_TRAP -- 所在阵营
		trap.tmps = Trap:createTmps(my_zhenying)

		trap.trap_base = trap_base

		return trap
	end


	-- 删除陷阱实体
	-- fighter : 放出陷阱的人
	-- aoiScene : 场景实例，没有可以为nil
	function TrapService:delMyTrap(fighter, aoiScene)
		-- local
		local GameObjectService = GameObjectService
		local my_trap_aoi_id = fighter.tmps.my_trap_aoi_id or 0

		if 0 < my_trap_aoi_id then
			fighter.tmps.my_trap_aoi_id = 0

			-- 删除掉
			if not aoiScene then
				aoiScene = GameObjectService:getAoiScene(fighter)
			end

			local my_trap = GameObjectService:getGameObjectByAoiId(aoiScene, my_trap_aoi_id)
			if my_trap then
				GameObjectService:delObj(my_trap, aoiScene)
			end
		end
	end

	-- 获取我的主人
	-- aoiScene : 场景实例
	-- trap : 陷阱
	-- return : parent / nil
	function TrapService:getMyParent(aoiScene, trap)
		return GameObjectService:getGameObjectByAoiId(aoiScene, trap.parent_aoi_id)
	end
end
