--[[
野外场景 service
author : guoyin.huang
date : 2014-07-15
--]]

local space_id_2_battle_info = ShengcunDao.space_id_2_battle_info
ShengcunService = ShengcunService or {}
setmetatable(ShengcunService, SceneServiceInterface)

local SceneService = SceneService
local ShengcunDefs = ShengcunDefs
local ShengcunConfig = ShengcunConfig
function ShengcunService:onAfterLoadLua()
	SceneService = _G.SceneService
	ShengcunDefs = _G.ShengcunDefs
	ShengcunConfig = _G.ShengcunConfig
end

-- BASE同步过来的场景数据信息
function ShengcunService:b2m_sync( _, data )
	space_id_2_battle_info[data.space_id] = data
end

-- 进入场景请求
function ShengcunService:b2m_entryBattle( character, data )
	local space_id = data.space_id
	local line_id = data.line_id
	local camp = data.camp_id
	local pos = ShengcunService:getRandomCampTransforIn(ShengcunDefs.scene_war, camp)
	SceneService:moveScene(character, ShengcunDefs.scene_war, space_id, line_id, pos.x, pos.y)
end

do  -- 返回扣除的血量比例
	local enum_2_hp_perc = {
		[1] = { 		-- 角色
			[1] = 0.04,	-- 角色
			[2] = 0.15,	-- 普通丧尸
			[3] = 0.08,	-- 高级丧尸
		},
		[2] = { 		-- 普通丧尸
			[1] = 0.03,	-- 角色
		},
		[3] = {			-- 高级丧尸
			[1] = 0.05,	-- 角色
		},
	}
	function ShengcunService:getDelHpPerc( fighter, targeter )
		local aoi_scene = GameObjectService:getAoiScene(fighter)
		local fighter_enum = FightService:isCharacter(fighter) and 1 or 2
		local targeter_enum = FightService:isCharacter(targeter) and 1 or 2
		if fighter_enum == 1 then 
			local ch_info = self:getChInfoByGcid(aoi_scene, fighter.gcid)
			if ch_info.is_zombie then 
				fighter_enum = 3
			end
		elseif fighter.monster_base then
			local monster_base = fighter.monster_base
			if monster_base.id == ShengcunConfig.boss_monster_id then 
				fighter_enum = 3
			end
		else
			Logger:error('ShengcunService:getDelHpPerc未知的攻击类型:', fighter.nick, fighter.aoi_type,fighter.beast_base)
			return 0
		end

		if targeter_enum == 1 then 
			local ch_info = self:getChInfoByGcid(aoi_scene, targeter.gcid)
			if ch_info.is_zombie then 
				targeter_enum = 3
			end
		elseif targeter.monster_base then
			local monster_base = assert(targeter.monster_base)
			if monster_base.id == ShengcunConfig.boss_monster_id then 
				targeter_enum = 3
			end
		else
			Logger:error('ShengcunService:getDelHpPerc未知的被攻击类型:', targeter.nick, targeter.aoi_type,targeter.beast_base)
			return 0
		end
		return enum_2_hp_perc[fighter_enum][targeter_enum]
	end
end

-- 判断玩家是否被感染
function ShengcunService:isInfected( character )
	local aoi_scene = GameObjectService:getAoiScene(character)
	assert(aoi_scene.shengcun)
	local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
	return ch_info.virus_speed > 0 and not ch_info.is_zombie
end

-- 判断玩家是否已经变成丧尸
function ShengcunService:isZombie( aoi_scene, character )
	if not aoi_scene.shengcun then return false end
	local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
	return ch_info.is_zombie
end

-- 场景初始化
function ShengcunService:onInitScene(character, aoi_scene)
	local space_id = aoi_scene.space_id
	if space_id_2_battle_info[space_id] then
		-- 获取本场景玩家数据
		local data = assert(space_id_2_battle_info[space_id])
		space_id_2_battle_info[space_id] = nil

		aoi_scene.shengcun = {}
		local shengcun = aoi_scene.shengcun

		-- GCID对应到玩家
		local gcid_2_ch_info = {}
		-- GCID对应到阵营
		local gcid_2_camp = {}

		shengcun.gcid_2_camp = gcid_2_camp
		shengcun.gcid_2_ch_info = gcid_2_ch_info

		-- 记录是否完成
		shengcun.is_finish = false
		-- 所有阵营数据
		shengcun.camps = data.camps
		-- 阵营ID到阵营
		shengcun.camp_id_2_camp = {}
		-- 补给站小地图
		shengcun.bujizhan_small_map = {}
		-- 设置玩法的开始与结束时间
		shengcun.start_time = os.time()
		shengcun.end_time = shengcun.start_time + ShengcunConfig.war_time_long
		shengcun.check_fin_time = shengcun.start_time + 15 	--15秒后开始检测玩法是否结束


		-- 接下是第几波怪
		shengcun.wave = 1
		-- 下一波怪出现的时间
		shengcun.next_wave_time = ShengcunConfig.monster_conf[shengcun.wave].second + shengcun.start_time

		-- 怪物aoi_id 对应的区域
		shengcun.monster_aoiid_2_area = {}  	
		-- 区域对应的怪物数量
		shengcun.area_2_monster_num = {}
		-- 总的怪物数量
		shengcun.total_monster_num = 0

		for _, camp in pairs(data.camps) do
			camp.member_num = #camp.members
			camp.total_life = ShengcunConfig.member_num_2_total_life[camp.member_num]	--总积分
			camp.life = camp.total_life
			camp.dead_life = 0 	--已死掉的命数
			camp.title = 'camp' .. camp.camp_id
			camp.is_zhanling = false 			--是否有占领补给站

			shengcun.camp_id_2_camp[camp.camp_id] = camp

			-- 计算总战力
			local sc_prof = math.random(1, 3)
			for _, ch_info in pairs(camp.members) do
				ch_info.virus_speed = 0
				ch_info.virus_value = 0
				ch_info.virus_tm = 0
				ch_info.shengcun_prof = sc_prof
				ch_info.is_zombie = false 	--是否已变成僵尸
				ch_info.group_id = camp.camp_id
				ch_info.rank = 1
				ch_info.is_reward = false

				-- 存储起来
				gcid_2_ch_info[ch_info.gcid] = ch_info
				gcid_2_camp[ch_info.gcid] = camp

				sc_prof = sc_prof + 1
				if sc_prof > 3 then sc_prof = 1 end
			end					
		end

		-- 创建补给站
		ShengcunService:createBujzhan( aoi_scene )
	end

	-- 默认场景初始化
	SceneService:onInitSceneDefault(character, aoi_scene)
	return true
end

function ShengcunService:update500ms(now_time_msec, aoi_scene)
	-- 准备厅不执行周期更新
	if not aoi_scene.shengcun then return end

	local timestamp = now_time_msec/1000
	local shengcun = aoi_scene.shengcun

	-- 检测完成
	if not shengcun.is_finish then 
		if timestamp >= shengcun.end_time then 
			self:finish(aoi_scene)
		end
	end

	-- 已经完成不再执行后面逻辑
	if shengcun.is_finish then 
		return 
	end

	-- 检测僵尸创建
	if shengcun.next_wave_time <= timestamp then 
		if self:createMonster(aoi_scene, shengcun.wave) then
			if ShengcunConfig.monster_conf[shengcun.wave + 1] then
				shengcun.wave = shengcun.wave + 1
				shengcun.next_wave_time = ShengcunConfig.monster_conf[shengcun.wave].second + shengcun.start_time
			else
				shengcun.next_wave_time = os.time() + 99999
			end
		end
	end

	-- 检测角色感染死亡
	self:checkVirusDead(aoi_scene)

	-- 检测补给站占领
	self:checkZhanlingSuc(aoi_scene)

	-- 检查结束
	self:checkFin(aoi_scene, timestamp)
end

-- 进入场景之后
function ShengcunService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	-- 不是战斗房间
	if not aoi_scene.shengcun then return end

	-- 角色数据赋值aoi_id
	local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
	ch_info.aoi_id = character.aoi_obj.obj_id

	-- 蜚断线重连判断次数，如果有剩余次数结束的时候才会发奖
	if not ch_info.is_entry then 
		-- 标记已进入
		ch_info.is_entry = true
		local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_SHENGCUN)
		if en_count > 0 then 
			-- 扣除次数，标记要发奖
			ch_info.is_reward = true
			CounterService:addcount(character, counter)
		end
	end

	-- 发送补给站数据
	self:sendBujizhanInfo(aoi_scene, character.gpid)

	-- 发送角色数据
	self:sendChInfo(aoi_scene, character)

	-- 发送站场信息
	self:sendBattleInfo(aoi_scene, character.gpid)

	-- 幻兽下阵
	ChPetService:hideFightPet(character, aoi_scene)

	-- 添加一个血清BUFFER
	--[[
	local scene_buffer_id = ShengcunConfig.boss_monster_scene_buffer_id
	local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
	SceneBufferService:addSceneBuffer(character, scene_buffer_base, 1, false)
	]]

	-- 如果已经结束直接发完成包
	if aoi_scene.shengcun.is_finish then 
		local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
		self:sendFinish(character, ch_info)
	end
end

-- 离开场景时
function ShengcunService:afterLeaveScene(character, aoi_scene, leave_type)
	-- 不是战场不处理
	if not aoi_scene.shengcun then return end

	-- 标记已离开
	local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
	ch_info.is_leave = true

	-- 如果正在占领补给站则停止占领
	ShengcunService:stopZhanlingAfterDead( aoi_scene, ch_info.aoi_id )

	-- 如果不是丧尸状态离开，重算生命数
	if not ch_info.is_zombie then 
		if not self:isFinish(aoi_scene) then
			self:updateLife(aoi_scene, ch_info, true)
			self:checkFin(aoi_scene, os.time())
		end
	end
end


do  -- 判断是否能使用某个技能
	local skill_id_2_shengcun_prof = {
		[13001] = ShengcunDefs.SHENGCUN_PROF_ZOMBIE,
		[13002] = ShengcunDefs.SHENGCUN_PROF_ZOMBIE,
		[13006] = ShengcunDefs.SHENGCUN_PROF_SHIYAOYUAN, --传染(放陷阱)
		[13007] = ShengcunDefs.SHENGCUN_PROF_SHIYAOYUAN, --空气传染
		[13008] = ShengcunDefs.SHENGCUN_PROF_YANJIUYUAN, --冷冻枪
		[13009] = ShengcunDefs.SHENGCUN_PROF_YAOJISHI, 	--抑制
	}
	function ShengcunService:isCanUseSkill( character, skill_id )
		-- 判断是否生存场景
		if not self:isInShengcun(character.scene_id) then return false, errorCodes.COMMON_PARAM_ERROR end

		-- 法帅变身的技能
		if skill_id >= 13003 and skill_id <= 13005 then 
			return character.prof == CharacterDefs.PROF_ID_FOR_ZHAOHUANSHI, errorCodes.COMMON_PARAM_ERROR
		end

		local skill_prof = skill_id_2_shengcun_prof[skill_id]
		if not skill_prof then 
			return false, errorCodes.COMMON_PARAM_ERROR
		end

		-- 判断职业是否拥有此技能
		local aoi_scene = GameObjectService:getAoiScene(character)
		if not aoi_scene.shengcun then 
			return false, errorCodes.COMMON_PARAM_ERROR 
		end

		if self:isFinish(aoi_scene) then 
			return false, errorCodes.COMMON_PARAM_ERROR
		end

		local ch_info = assert(self:getChInfoByGcid(aoi_scene, character.gcid))
		if ch_info.is_life_out then 
			return false, errorCodes.COMMON_PARAM_ERROR
		end

		-- 僵尸可使用僵尸技能
		if ch_info.is_zombie then 
			return skill_prof == ShengcunDefs.SHENGCUN_PROF_ZOMBIE
		else
			return ch_info.shengcun_prof == skill_prof
		end
	end
end

-- 检测感染死亡
function ShengcunService:checkVirusDead( aoi_scene )
	local shengcun = aoi_scene.shengcun
	local gcid_2_ch_info = shengcun.gcid_2_ch_info
	local now_time = os.time()
	local is_ganran = false

	for _, ch_info in pairs(gcid_2_ch_info) do
		local character = CharacterService:getCharacterByGcid(ch_info.gcid)
		-- 在线的，不是丧尸且未死亡的玩家才检测
		if not ch_info.is_zombie and ch_info.virus_speed > 0 and character and not FightService:isDead(character) then
			-- 更新当前的感染度
			self:updateVirusValue(ch_info, now_time)
			-- 感染度100则认为已经感染死亡
			if ch_info.virus_value >= 100 then 
				is_ganran = true
				-- 感染死亡,清空感染速度，标记为已变成丧尸
				ch_info.virus_speed = 0
				ch_info.is_zombie = true

				-- 扣除本职业的命数(不发送到客户端,遍历结束后统一发送到客户端)
				self:updateLife(aoi_scene, ch_info)

				-- 标记为即将变成丧尸(复活的时候才会变成丧尸)
				character.tmps.is_2_zombie = true

				-- 数据更新
				self:sendChInfo(aoi_scene, character)
				-- 外观更新
				self:onVirusChange(aoi_scene, character)

				-- 设置怪物为死亡状态
				if not FightService:isDead(character) then
					CharacterService:toDead(character)
				end

				-- 更新被感染玩家的阵营
				GameObjectService:updateZhenying(aoi_scene, character, Statics.DEFAULT_ZHENYING_MONSTER, true)

				-- 如果身上有BUFFER，直接清掉
				local scene_buffer_id = ShengcunConfig.boss_monster_scene_buffer_id
				local ch_scene_buffer = SceneBufferService:getChSceneBuffer(character, scene_buffer_id)
				if ch_scene_buffer and ch_scene_buffer.num > 0 then
					-- 删除被杀者身上的BUFFER
					SceneBufferService:delSceneBuffer(character, scene_buffer_id, ch_scene_buffer.num, false)
				end		
			end
		end
	end

	-- 如果有玩家被感染死亡，更新战场数据
	if is_ganran then 
		self:sendBattleInfoUpdate(aoi_scene)
	end
end

-- 更新阵营的生命数
function ShengcunService:updateLife( aoi_scene, ch_info, is_send )
	local camp_info = self:getCampInfoByGcid(aoi_scene, ch_info.gcid)
	local members = camp_info.members
	local live_member_num = 0
	for _, ch_info in pairs(members) do
		-- 不是丧尸且未离开，才计算人数
		if not ch_info.is_zombie and not ch_info.is_leave then 
			live_member_num = live_member_num + 1
		end
	end
	camp_info.total_life = ShengcunConfig.member_num_2_total_life[live_member_num]
	if camp_info.total_life < camp_info.life then 
		camp_info.life = camp_info.total_life
	end

	-- 给场景所有玩家广播生命数更新
	if is_send then 
		self:sendBattleInfoUpdate(aoi_scene)
	end
end

-- 获取角色战场数据
function ShengcunService:getChInfoByGcid( aoi_scene, gcid )
	return aoi_scene.shengcun.gcid_2_ch_info[gcid]
end

-- 获取阵营战场数据
function ShengcunService:getCampInfoByGcid( aoi_scene, gcid )
	return aoi_scene.shengcun.gcid_2_camp[gcid]
end

-- 通过阵营ID获取阵营数据
function ShengcunService:getCampInfoByCamp( aoi_scene, camp )
	return aoi_scene.shengcun.camp_id_2_camp[camp]
end

--------------------------------- 医疗站 【BEG】 -----------------------------------------
do 	-- 创建医疗站
	local bujizhan_poses = {
		{x = 32, y=32},
	}	
	-- 创建医疗站
	function ShengcunService:createBujzhan( aoi_scene )
		local shengcun = aoi_scene.shengcun
		shengcun.bujis = {}
		local bujis = shengcun.bujis

		for buji_id, pos in pairs(bujizhan_poses) do
			local bujizhan = {}
			bujizhan.id = buji_id
			bujizhan.zhenying = 0
			bujizhan.status = ShengcunDefs.BUJI_STATUS_EMPTY
			bujizhan.x = pos.x
			bujizhan.y = pos.y
			table.insert(bujis, bujizhan)

			shengcun.bujizhan_small_map[buji_id] = SmallMapService:addItem(aoi_scene, SmallMapDefs.SMALL_MAP_SORT_ID_BUJIZHAN, pos.x, pos.y, bujizhan.zhenying)
		end
	end

	-- 开始占领
	function ShengcunService:startZhanling(character, id)
		local aoi_scene = GameObjectService:getAoiScene(character)
		local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)

		local shengcun = aoi_scene.shengcun
		if not shengcun or self:isFinish(aoi_scene) then return end

		local bujis = assert(shengcun.bujis)

		-- 判断是否可以占领
		local buji = bujis[id]
		if buji.zhenying == ch_info.group_id then 
			-- 已经是本阵营
			return false, errorCodes.COMMON_PARAM_ERROR
		end

		-- 正在被占领中
		if buji.occupy_aoi_id and buji.occupy_aoi_id > 0 then 
			return false, errorCodes.COMMON_PARAM_ERROR
		end

		-- 开始占领
		buji.occupy_aoi_id = character.aoi_obj.obj_id
		buji.occupy_end_time = Time.time_now + 5 * 1000
		buji.occupy_time_long = 5

		-- 发送补给站信息更新
		self:sendBujizhanInfo(aoi_scene)

		-- 通知开始占领成功
		self:sendStartZhanlingSuc(character, {id=id})

		return true
	end	

	-- 检测占领完成
	function ShengcunService:checkZhanlingSuc( aoi_scene )
		local shengcun = aoi_scene.shengcun
		local bujis = shengcun.bujis
		local is_modify = false
		local update_camps = {}

		for _, buji in pairs(bujis) do
			if buji.occupy_end_time and buji.occupy_end_time <= Time.time_now then
				local character = assert(GameObjectService:getGameObjectByAoiId(aoi_scene, buji.occupy_aoi_id))
				local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
				local group_id = ch_info.group_id

				--如果之前的补给站已经被其他阵营占领，则更新这个阵营的玩家的感染度
				if buji.zhenying > 0 then
					local camp_info = self:getCampInfoByCamp(aoi_scene, buji.zhenying)
					buji.zhenying = 0
					camp_info.is_zhanling = self:isHasZhanling(aoi_scene, camp_info.camp_id) 
					if not camp_info.is_zhanling then 
						for _, ch_info in pairs(camp_info.members) do
							if ch_info.virus_speed > 0 and not ch_info.is_leave then 
								local character = CharacterService:getCharacterByGcid(ch_info.gcid)
								self:onVirusChange(aoi_scene, character)
							end
						end
					end
				end

				-- 更新补给站数据
				buji.zhenying = group_id
				buji.occupy_aoi_id = nil
				buji.occupy_end_time = nil
				buji.occupy_time_long = nil
				buji.status = ShengcunDefs.BUJI_STATUS_ZHANLING

				-- 更新小地图状态
				local small_map_aoi_id = shengcun.bujizhan_small_map[buji.id]
				SmallMapService:updateItem(aoi_scene, small_map_aoi_id, {zhenying_id=buji.zhenying})

				is_modify = true
				
				-- 更新占领成功的阵营的玩家的感染度
				do
					local camp_info = self:getCampInfoByCamp(aoi_scene, buji.zhenying)
					camp_info.is_zhanling = self:isHasZhanling(aoi_scene, camp_info.camp_id) 
					for _, ch_info in pairs(camp_info.members) do
						if ch_info.virus_speed > 0 and not ch_info.is_leave then 
							local character = CharacterService:getCharacterByGcid(ch_info.gcid)
							self:onVirusChange(aoi_scene, character)
						end
					end

					-- 广播占领或者被占领
					for _, ch_info in pairs(shengcun.gcid_2_ch_info) do
						if not ch_info.is_leave and ch_info.is_entry then 
							if ch_info.group_id == buji.zhenying then 
								WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SHENGCUN_NOTICE_ZHANLING, nil, ch_info.gpid)	
							else
								WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SHENGCUN_NOTICE_BEIZHANLING, nil, ch_info.gpid)	
							end
						end
					end
				end
			end
		end

		-- 如果有变化，更新补给站数据给所有玩家
		if is_modify then 
			self:sendBujizhanInfo(aoi_scene)
		end
	end

	-- 死亡或者离开取消占领
	function ShengcunService:stopZhanlingAfterDead( aoi_scene, aoi_id )
		local shengcun = aoi_scene.shengcun
		local bujis = shengcun.bujis
		local is_modify = false
		for _, buji in pairs(bujis) do
			if buji.occupy_aoi_id and buji.occupy_aoi_id == aoi_id then
				buji.occupy_aoi_id = nil
				buji.occupy_end_time = nil
				is_modify = true
			end
		end

		if is_modify then 
			self:sendBujizhanInfo(aoi_scene)
		end		
	end

	-- 判断己方是否有占领
	function ShengcunService:isHasZhanling( aoi_scene, camp_id )
		local shengcun = aoi_scene.shengcun
		local bujis = shengcun.bujis
		for _, buji in pairs(bujis) do
			if buji.zhenying == camp_id then 
				return true
			end
		end				
	end

end
--------------------------------- 医疗站 【END】 -----------------------------------------
-- 检查创建僵尸
do
	-- 4个区域(每个象限一个区域)
	local areas = {
		[1] = true,
		[2] = true,
		[3] = true,
		[4] = true,
	}
	function ShengcunService:createMonster( aoi_scene, wave )
		-- 根据现有僵尸数量，创建僵尸
		local shengcun = aoi_scene.shengcun
		local wave = shengcun.wave
		local zombie_conf = ShengcunConfig.monster_conf[wave]
		
		if not zombie_conf then return false end

		-- 广播出现丧尸
		NoticeService:sysMsgScene(aoi_scene.space_id, OKMsgCodes.SHENGCUN_NOTICE_WAVE, {[1]=wave})

		local monster_aoiid_2_area = shengcun.monster_aoiid_2_area
		local area_2_monster_num = shengcun.area_2_monster_num
		local total_monster_num = shengcun.total_monster_num

		local monster_id = ShengcunConfig.monster_id
		local boss_monster_id = ShengcunConfig.boss_monster_id

		-- 添加普通僵尸(每波添加总共的数量,如果总数到达了50只，则不再添加)
		for i=1, zombie_conf.monster_num do
			-- 总的普通丧尸数量不能超过限制
			if shengcun.total_monster_num > ShengcunConfig.max_monster_num then 
				break
			end
			-- 随机一个区域
			local random_pos = math.random(1, #areas)
			for i=1, #areas do
				if not area_2_monster_num[random_pos] then 
					area_2_monster_num[random_pos] = 0
				end
				-- 每个区域的丧尸数量不能超过最大值
				if area_2_monster_num[random_pos] < ShengcunConfig.area_max_monster_num then 
					-- 就选择此区域
					local x, y = ShengcunService:randomPos( aoi_scene,random_pos )
					local monster = MonsterService:dymCreateMonster(aoi_scene, monster_id, nil, x, y, 120)
					monster_aoiid_2_area[monster.aoi_id] = random_pos
					area_2_monster_num[random_pos] = area_2_monster_num[random_pos] + 1					
					shengcun.total_monster_num = shengcun.total_monster_num + 1
					break
				end

				-- 如果此区域满，则放到下一个区域
				random_pos = random_pos + 1
				if random_pos == #areas + 1 then 
					random_pos = 1
				end
			end
		end

		-- 添加超级僵尸
		for i=1, zombie_conf.boss_monster_num do
			local area_index = math.random(1, #areas)
			local x, y = ShengcunService:randomPos(aoi_scene, area_index )
			local monster = MonsterService:dymCreateMonster(aoi_scene, boss_monster_id,nil , x, y, 120)
		end	

		return true
	end

	-- 随机一个位置
	function ShengcunService:randomPos( aoi_scene, xiangxian )
		return self:randomPosByXiangXian(aoi_scene, xiangxian)
	end

	do
		local bujizhan_r = 6
		local map_x_max = 64
		local map_y_max = 64
		local xiangxian_2_poses  = nil
		local randOneElement = math.randOneElement
		function ShengcunService:randomPosByXiangXian( aoi_scene, xiangxian )
			if not xiangxian_2_poses then 
				-- 将场景所有可用的点都进行计算（以1米为间隔）
				-- 将这些点按象限保存起来
				xiangxian_2_poses = {}
				for i=1, 4 do
					xiangxian_2_poses[i] = {}
				end

				local map_x_beg = map_x_max/2 - bujizhan_r
				local map_x_end = map_x_max/2 + bujizhan_r
				local map_y_beg = map_y_max/2 - bujizhan_r
				local map_y_end = map_y_max/2 + bujizhan_r
				-- 初始化可用坐标
				for x=1, map_x_max do
					for y=1, map_y_max do
						if not(x > map_x_beg and x < map_x_end and y > map_y_beg and y < map_y_end) and aoi_scene:canPass(x,y) then 
							if x > map_x_max/2 then 
								if y > map_y_max/2 then 
									table.insert(xiangxian_2_poses[1], {x,y})
								else
									table.insert(xiangxian_2_poses[2], {x,y})
								end
							else
								if y > map_y_max/2 then 
									table.insert(xiangxian_2_poses[3], {x,y})
								else
									table.insert(xiangxian_2_poses[4], {x,y})
								end
							end
						end
					end
				end
			end

			-- 从象限内的可能点中随机一个点
			local arr = xiangxian_2_poses[xiangxian]
			local pos = arr[math.random(1, #arr)]
			return pos[1], pos[2]
		end
	end
end

-- 检查玩家是否可以战斗
function ShengcunService:checkFight(aoi_scene, attacker, target)
	if aoi_scene.shengcun and not aoi_scene.shengcun.is_finish then 
		if attacker.tmps_ex then 
			local ch_info = self:getChInfoByGcid(aoi_scene, attacker.gcid)
			return not ch_info.is_life_out, errorCodes.FIGHT_FIGHTER_SHENGCUN_LIFE_OUT
		end
	end
end

do  -- 进入场景前初始化玩家的时装，武器和神兵
	local prof_2_avata_id = {
		[1] = 10130018,
		[2] = 10130017,
		[3] = 10130019,
	}
	function ShengcunService:beforeEnterScene(character, aoi_scene)
		character.max_hp2 = 0
		character.hp2 = 0
		character.max_hp3 = 0
		character.hp3 = 0

		ChPetService:hideFightPet(character, aoi_scene)

		-- 设置时装外观
		if aoi_scene.shengcun then 
			local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
			if ch_info then 
				local sc_prof = ch_info.shengcun_prof
				character.appear.avatar = prof_2_avata_id[sc_prof] or character.appear.avatar
			end
			character.appear.weaponid = 10010001
			character.appear.shenbing = 0
		end
		return true
	end
end

-- 设置头顶文字
function ShengcunService:initWanfaAoiData( character, aoi_scene )
	if aoi_scene.shengcun then
		self:onVirusChange(aoi_scene, character, true)
	end
	return true
end

-- 判断是否生存玩法
function ShengcunService:isInShengcun( scene_id )
	return scene_id == ShengcunDefs.scene_war or scene_id == ShengcunDefs.scene_pre
end

-- 当玩家被杀时
function ShengcunService:onPlayerKilled( fighter, arr_kill_player_aoi_id )
	-- 不是生存战场或者活动已结束，不处理
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	if not aoi_scene.shengcun then return end
	if self:isFinish(aoi_scene) then return end

	local now_time = os.time()

	-- 遍历被杀者
	for _, killed_player_aoi_id in pairs(arr_kill_player_aoi_id) do
		
		-- 如果是此玩家正在占领，则取消占领
		ShengcunService:stopZhanlingAfterDead( aoi_scene, killed_player_aoi_id )

		-- 被杀者角色对象
		local killed_player = GameObjectService:getGameObjectByAoiId(aoi_scene, killed_player_aoi_id)
		if killed_player then 

			local killed_ch_info = assert(self:getChInfoByGcid(aoi_scene, killed_player.gcid))
			-- 只是非丧尸需要处理
			if not killed_ch_info.is_zombie then 
				-- 假如被感染，进度条暂停
				if killed_ch_info.virus_speed > 0 then
					self:updateVirusValue(killed_ch_info, os.time())
				end

				-- 如果身上有BUFFER，则直接将BUFFER掉落到地上
				local scene_buffer_id = ShengcunConfig.boss_monster_scene_buffer_id
				local ch_scene_buffer = SceneBufferService:getChSceneBuffer(killed_player, scene_buffer_id)
				if ch_scene_buffer and ch_scene_buffer.num > 0 then
					-- 将其中一个掉落到地上
					local x= killed_player.x
					local y = killed_player.y
					local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
					SceneBufferService:addSceneBufferDropItem(aoi_scene, scene_buffer_base, {{x,y},{x,y}})

					-- 删除被杀者身上的BUFFER
					SceneBufferService:delSceneBuffer(killed_player, scene_buffer_id, ch_scene_buffer.num, false)
				end		

				-- 处理生命数
				local camp_info = self:getCampInfoByGcid(aoi_scene, killed_player.gcid)
				if camp_info.life > 0 then
					camp_info.life = camp_info.life - 1
					if camp_info.life <= 0 then 

						local gpids = {}
						-- 标记所有玩家的生命数用完
						for _, ch_info in pairs(camp_info.members) do
							ch_info.is_life_out = true
							-- 只有未变成丧尸、未离开，且进入过的玩家需要通知
							if not ch_info.is_zombie and not ch_info.is_leave and ch_info.is_entry then 
								gpids[#gpids + 1] = ch_info.gpid
							end
						end
						-- 通知同一阵营，生命数用完(这部分玩家将会退出)
						if next(gpids) then
							self:sendLifeOut(gpids)
						end
					end
				end
			end
		end
	end

	-- 更新所有数据
	self:sendBattleInfoUpdate(aoi_scene)

	-- 检查是否结束
	self:checkFin(aoi_scene, now_time)
end

-- 当怪物被杀
function ShengcunService:onKilledMonster( character, arr_kill_monster_id, arr_kill_monster_aoi_id )

	local aoi_scene = GameObjectService:getAoiScene(character)
	if aoi_scene.shengcun.is_finish then 
		return 
	end	

	local shengcun = aoi_scene.shengcun
	local area_2_monster_num = shengcun.area_2_monster_num
	local monster_aoiid_2_area = shengcun.monster_aoiid_2_area

	for _, monster_id in pairs(arr_kill_monster_id) do
		if monster_id == ShengcunConfig.monster_id then 
			-- 普通僵尸
			local aoi_id = arr_kill_monster_aoi_id[_]
			local area = assert(monster_aoiid_2_area[aoi_id])
			-- 标记此aoi_id已经死亡
			monster_aoiid_2_area[aoi_id] = nil
			-- 区域的怪物-1
			area_2_monster_num[area] = area_2_monster_num[area] - 1
			-- 总的怪物数-1
			shengcun.total_monster_num = shengcun.total_monster_num - 1

			-- 普通丧尸概率掉落血清
			if ShengcunConfig:isDropXueqing() then 
				local monster = GameObjectService:getGameObjectByAoiId(aoi_scene, arr_kill_monster_aoi_id[_])
				local scene_buffer_id = ShengcunConfig.boss_monster_scene_buffer_id
				local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
				local pos = {monster.x, monster.y}
				local pos_area = {pos, pos}				
				SceneBufferService:addSceneBufferDropItem(aoi_scene, scene_buffer_base, pos_area)				
			end

		elseif monster_id == ShengcunConfig.boss_monster_id then 
			-- 超级僵尸掉落血清BUFFER
			local monster = GameObjectService:getGameObjectByAoiId(aoi_scene, arr_kill_monster_aoi_id[_])
			local scene_buffer_id = ShengcunConfig.boss_monster_scene_buffer_id
			local scene_buffer_base = SceneBufferBaseService:getSceneBufferBase(scene_buffer_id)
			local pos = {monster.x, monster.y}
			local pos_area = {pos, pos}				
			SceneBufferService:addSceneBufferDropItem(aoi_scene, scene_buffer_base, pos_area)
		end
	end
end

-- 设置阵营
function ShengcunService:setZhenying(aoi_scene, character)
	if aoi_scene.shengcun and not self:isFinish(aoi_scene) then 
		local camp_id = ShengcunService:getCamp( aoi_scene, character )
		GameObjectService:updateZhenying(aoi_scene, character, camp_id)
	end
end

-- 获取角色阵营ID
function ShengcunService:getCamp( aoi_scene, character )
	local camp_info = self:getCampInfoByGcid(aoi_scene, character.gcid)
	return camp_info.camp_id
end

do  ------------------------- 出生与复活【BEG】 ---------------------------------
	local camp_id_2_transfer_base_ids = {
		[1] = {x=30.4, y=47.5},
		[2] = {x=50.6, y=26.3},
		[3] = {x=42.5, y=8.2},
		[4] = {x=18.8, y=10.1},
		[5] = {x=13, y=27.5},
	}

	-- 获取复活点
	-- return 	bool:is_back_to_mcity,	true:回到主城，false:本场景复活
	--			x, y					本场景复活的X，Y坐标点
	function ShengcunService:getRelivePos(character, aoi_scene)
		if not aoi_scene.shengcun then 
			return false, character.x, character.y
		end
		local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
		if ch_info.is_zombie then 
			return false, character.x, character.y
		end

		-- 找一个最近的点
		local x, y = character.x, character.y
		local min_pos = nil
		local min_lenth = 999999999
		for _, pos in pairs(camp_id_2_transfer_base_ids) do
			local this_lenth = (pos.x - x)^2 + (pos.y - y)^2
			if min_lenth > this_lenth then 
				min_pos = pos
				min_lenth = this_lenth
			end
		end

		return false, min_pos.x, min_pos.y
	end

	-- 获取出生点
	function ShengcunService:getBirthPos(aoi_scene, character)
		if not aoi_scene.shengcun then return false end
		local camp = ShengcunService:getCamp( aoi_scene, character )
		local pos = ShengcunService:getRandomCampTransforIn(DaojianjueConfig.war_scene_id, camp)
		return true, pos.x, pos.y
	end

	-- 获取出生点与复活点
	function ShengcunService:getRandomCampTransforIn(scene_id, camp_id)
		local transfer_base_id = 0
		return camp_id_2_transfer_base_ids[camp_id]
	end

	-- 复活后
	function ShengcunService:afterRelive( character )
		local aoi_scene = GameObjectService:getAoiScene(character)
		local ch_info = aoi_scene.shengcun.gcid_2_ch_info[character.gcid]

		-- 变丧尸只变一次
		if ch_info.is_zombie and not ch_info.is_change then 
			-- 添加一个变丧尸BUFFER
			local now_bufferBase = assert(BufferBaseService:getBufferBaseById(40000021))
			local is_add_buffer_sucess, is_need_bc = BufferService:addTmpBuffer(character, now_bufferBase, nil)		
			BufferService:bcBuffers(aoi_scene, character)
			ch_info.is_change = true

			character.tmps.is_2_zombie = nil
		end

		-- 如果已经变成丧尸，更新速度为3
		if ch_info.is_zombie then 
			local speed_t = 3
			MotionService:changeSpeed(character, speed_t, aoi_scene.shengcun.end_time * 1000)
		end

		-- 如果是感染状态，重新开始感染进度
		if ch_info.virus_speed > 0 and not ch_info.is_zombie then 
			ch_info.virus_tm = os.time()
			self:onVirusChange(aoi_scene, character)
		end
	end

end  ------------------------- 出生与复活【END】 ---------------------------------

-- 判断结束
function ShengcunService:checkFin( aoi_scene, now_time)
	local shengcun = aoi_scene.shengcun
	assert(not shengcun.is_finish)

	-- 判断时间是否已经到达
	if now_time > shengcun.end_time then 
		return self:finish(aoi_scene)
	end

	-- 只剩下一个队伍的情况，也直接结束
	if now_time - shengcun.start_time > 10 and self:getLifeCampNum( shengcun ) <= 1 then
		return self:finish(aoi_scene)
	end
end

-- 获取存活的阵营数
function ShengcunService:getLifeCampNum( shengcun )
	local life_camp_num = 0
	local life_camp = nil
	for _, camp_info in pairs(shengcun.camps) do
		if camp_info.life > 0 then 
			life_camp_num = life_camp_num + 1
			life_camp = camp_info
		end
	end
	return life_camp_num, life_camp
end

-- 活动结束，发奖
function ShengcunService:finish(aoi_scene)
	local shengcun = aoi_scene.shengcun
	assert(not shengcun.is_finish)
	shengcun.is_finish = true

	-- 计算胜利方的阵营(生命数最多的或者最后死亡时间最早的)
	table.sort(shengcun.camps, function ( l, r )
		if l.life ~= r.life then return l.life > r.life end
		return l.total_fc > r.total_fc
	end)
	
	-- 发胜利奖励
	for rank, camp_info in pairs(shengcun.camps) do
		for _, ch_info in pairs(camp_info.members) do
			if rank == 1 then 
				ch_info.is_win = true
			else
				ch_info.is_win = false
			end
			if ch_info.is_leave and (not ch_info.is_zombie and not ch_info.is_life_out) then 
				ch_info.is_win = false
			end
		end
	end

	-- 广播幸存者
	if shengcun.camps[1] then 
		-- 幸存者名单列表
		local nicks = {}
		for _, member in pairs(shengcun.camps[1].members) do
			nicks[#nicks + 1] = member.nick
		end

		local names = ''
		for _, nick in ipairs(nicks) do
			if _ ~= #nicks then 
				names = names .. nick .. ','
			else
				names = names .. nick
			end
		end
		NoticeService:sysMsgWorld(OKMsgCodes.SHENGCUN_NOTICE_LIVE, {[1] = names})
	end

	for gcid, ch_info in pairs(shengcun.gcid_2_ch_info) do
		-- 只有进入的玩家才会发奖
		if ch_info.is_entry then 

			local equip_num = 0
			if ch_info.is_reward then 
				if ch_info.is_win then 
				-- 胜利奖
					equip_num = ShengcunConfig.win_equip_num
				elseif ch_info.is_leave and (not ch_info.is_zombie and not ch_info.is_life_out) then
				-- 安慰奖
					equip_num = ShengcunConfig.leave_equip_num
				else
				-- 失败奖
					equip_num = ShengcunConfig.lose_equip_num
				end
				ch_info.equips = {[ShengcunConfig.reward_equip_id] = equip_num}

				-- 不是丧尸且没有离开的玩家，多奖励10个道具
				if not ch_info.is_zombie and not ch_info.is_leave then
					equip_num = equip_num + ShengcunConfig.live_equip_num
					ch_info.live_equips = {[ShengcunConfig.reward_equip_id] = ShengcunConfig.live_equip_num}
				end

				if equip_num > 0 then 
					ch_info.total_equips = {[ShengcunConfig.reward_equip_id] = equip_num}
				end
			end

			-- 没有离开的玩家才发结束包
			if not ch_info.is_leave then 
				local character = assert(CharacterService:getCharacterByGcid(ch_info.gcid))
				self:sendFinish(character, ch_info)
			end

			if ch_info.total_equips then 
				-- 到游戏服发奖
				local data = {}
				data.is_win = ch_info.is_win
				data.equips = ch_info.total_equips
				RewardService:reward(Statics.PK_GAME_TYPE_ID_SHENGCUN, 0, ch_info.gpid, ch_info.gcid, data)	
			end
		end
	end

	-- 通知BASE战斗结束
	ShengcunService:m2b_noticeFinish( aoi_scene )
end

-- 通知base 战斗结束 
function ShengcunService:m2b_noticeFinish( aoi_scene )
	local data = {}
	data.space_id = aoi_scene.id
	data.gcids = {}
	for _, ch_info in pairs(aoi_scene.shengcun.gcid_2_ch_info) do
		if ch_info.is_entry and not ch_info.is_leave then
			table.insert(data.gcids, ch_info.gcid)
		end
	end
	ServerCall:m2bCall('ShengcunService:m2b_finish', 0, data)
end

-- 是否已经结束
function ShengcunService:isFinish( aoi_scene )
	local shengcun = aoi_scene.shengcun
	return shengcun and shengcun.is_finish
end


------------------------------------------ 病毒感染相关 【BEG】 ---------------------------------
do
	local keys = {'group_id', 'is_zombie', 'virus_speed', 'virus_tm', 'virus_value', 'shengcun_prof'}
	function ShengcunService:onVirusChange( aoi_scene, character, is_not_send )
		
		local ch_info = assert(self:getChInfoByGcid(aoi_scene, character.gcid))

		-- 修正感染速度
		if ch_info.virus_speed > 0 then 
			local camp_info = self:getCampInfoByGcid(aoi_scene, ch_info.gcid)
			ch_info.virus_speed = ShengcunDefs.prof_2_speed[ch_info.shengcun_prof] * (camp_info.is_zhanling and 0.5 or 1)
		end

		-- 如果已经变成丧失，改变职业为丧尸，方便处理
		if ch_info.is_zombie then 
			ch_info.shengcun_prof = ShengcunDefs.SHENGCUN_PROF_ZOMBIE
		end

		local update_obj = {}
		for _, key in pairs(keys) do
			WanfaAoiService:setWanfaAoiData(character, key, ch_info[key], false)
			update_obj[key] = ch_info[key]
		end
		if not is_not_send then 
			update_obj.aoi_id = character.aoi_obj.obj_id
			local gpids = GameObjectService:getGPids(aoi_scene)
			WanfaAoiService:sendWanfaAoiDataUp(aoi_scene, update_obj, gpids)
		end

		-- 更新角色数据
		self:sendChInfo(aoi_scene, character)
	end
end

do 	-- 当病毒BUFFER被加到身上时
	function ShengcunService:onVirusBufferAdd( aoi_scene, character )
		if not FightService:isLikeCharacter(character) then return end
		if not aoi_scene.shengcun or self:isFinish(aoi_scene) then 
			return 
		end
		local ch_info = assert(self:getChInfoByGcid(aoi_scene, character.gcid))
		-- 不是丧尸才能被感染
		if ch_info.virus_speed == 0 and not ch_info.is_zombie then 
			-- 设置为被感染了
			ch_info.virus_speed = assert(ShengcunDefs.prof_2_speed[ch_info.shengcun_prof])
			ch_info.virus_tm = os.time()
			ch_info.virus_value = 0

			ShengcunService:onVirusChange( aoi_scene, character )

			-- 淡入淡出提醒
			WorldPacket:m2cSendCommOkMsg(OKMsgCodes.SHENGCUN_NOTICE_GANRAN, nil, character.gpid)
		end
	end
end

do 	-- 当使用血清时
	function ShengcunService:onUseXueqingBuffer( aoi_scene, character )
		if not FightService:isLikeCharacter(character) then return end
		if not aoi_scene.shengcun or self:isFinish(aoi_scene) then 
			return 
		end		
		local ch_info = assert(self:getChInfoByGcid(aoi_scene, character.gcid))
		if ch_info.virus_speed ~= 0 then 
			-- 设置为被感染了
			ch_info.virus_speed = 0
			ch_info.virus_tm = 0
			ch_info.virus_value = 0
			ShengcunService:onVirusChange( aoi_scene, character )
		end
	end
end

do 	-- 当使用抑制剂时
	function ShengcunService:onUseYizhiBuffer( aoi_scene, character )
		if not FightService:isLikeCharacter(character) then return end
		if not aoi_scene.shengcun or self:isFinish(aoi_scene) then 
			return 
		end		
		local ch_info = assert(self:getChInfoByGcid(aoi_scene, character.gcid))
		if not ch_info.is_zombie and ch_info.virus_speed > 0 then 
			local now_time = Time.time_second
			self:updateVirusValue(ch_info, now_time)
			ch_info.virus_value = ch_info.virus_value / 2
			ShengcunService:onVirusChange( aoi_scene, character )
		end
	end
end

-- 更新感染值
function ShengcunService:updateVirusValue( ch_info, now_time )
	ch_info.virus_value = ch_info.virus_value + (now_time - ch_info.virus_tm) * ch_info.virus_speed
	ch_info.virus_tm = now_time
end
------------------------------------------ 病毒感染相关 【BEG】 ---------------------------------


------------------------------------------ 协议发送 【BEG】 --------------------------------------
do	-- 发送补给站信息
	local rsp_opcode = opCodes.PKM2C_SHENGCUN_BUJI
	local msg_name = "PackShengcun.PKM2C_SHENGCUN_BUJI"
	function ShengcunService:sendBujizhanInfo(aoi_scene, gpid)
		local gpids = gpid and {[1]=gpid} or GameObjectService:getGPids(aoi_scene)
		if gpids and next(gpids) then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, aoi_scene.shengcun, nil, gpids)
		end
	end
end

do	-- 发送整个战场的信息
	local rsp_opcode = opCodes.PKM2C_SHENGCUN_BATTLE_INFO
	local msg_name = "PackShengcun.PKM2C_SHENGCUN_BATTLE_INFO"
	function ShengcunService:sendBattleInfo(aoi_scene, gpid)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, aoi_scene.shengcun, nil, gpid)
	end
end

do	-- 发送阵营数据更新
	local rsp_opcode = opCodes.PKM2C_SHENGCUN_BATTLE_INFO_UP
	local msg_name = "PackShengcun.PKM2C_SHENGCUN_BATTLE_INFO_UP"
	function ShengcunService:sendBattleInfoUpdate(aoi_scene)
		local gpids = GameObjectService:getGPids(aoi_scene)
		if gpids and next(gpids) then
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, aoi_scene.shengcun, nil, gpids)
		end
	end
end

do	-- 发送阵营数据更新
	local rsp_opcode = opCodes.PKM2C_SHENGCUN_CH_INFO
	local msg_name = "PackShengcun.PKM2C_SHENGCUN_CH_INFO"
	function ShengcunService:sendChInfo(aoi_scene, character)
		local ch_info = self:getChInfoByGcid(aoi_scene, character.gcid)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, ch_info, nil, character.gpid)
	end
end

do	-- 发送结算数据
	local rsp_opcode = opCodes.PKM2C_SHENGCUN_FINISH
	local msg_name = "PackShengcun.PKM2C_SHENGCUN_FINISH"
	function ShengcunService:sendFinish(character, data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end


do	-- 发送开始占领成功
	local rsp_opcode = opCodes.PKM2C_SHENGCUN_START_ZHANLING
	local msg_name = "PackShengcun.PKM2C_SHENGCUN_START_ZHANLING"
	function ShengcunService:sendStartZhanlingSuc(character, data)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, character.gpid)
	end
end

do	-- 发送感染死亡
	local rsp_opcode = opCodes.PKM2C_SHENGCUN_VIRUS_DEAD
	local msg_name = "PackShengcun.PKM2C_SHENGCUN_VIRUS_DEAD"
	function ShengcunService:sendVirusDead(character)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, {}, nil, character.gpid)
	end
end

do	-- 发送阵营人数全部死亡
	local rsp_opcode = opCodes.PKM2C_SHNEGCUN_LIFE_OUT
	local msg_name = "PackShengcun.PKM2C_SHNEGCUN_LIFE_OUT"
	function ShengcunService:sendLifeOut(gpids)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, {}, nil, gpids)
	end
end
------------------------------------------ 协议发送 【END】 --------------------------------------