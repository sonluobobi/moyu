--[[
角色装备栏系统servuce
author : xingzeng
date : 2014-08-15
]]--

local external = external
local Logger = Logger
local WorldPacket = WorldPacket
local table = table
local string_len = string.len
local type = type
local table = table
local random = math.random
local SceneDefs = SceneDefs

local EquipDefs = EquipDefs
local ChItemDefs = ChItemDefs
local ChItemPackage = ChItemPackage
local EffectType = EffectType

ChItemBarService = ChItemBarService or {
}

local CharacterService
function ChItemBarService:onAfterLoadLua()
	CharacterService = _G.CharacterService
end

function ChItemBarService:pack(character)
	local itembar = character.items
	local _items_effect_values = itembar._items_effect_values
	itembar._items_effect_values = nil
	local str = WorldPacket:encodeData(itembar)
	itembar._items_effect_values = _items_effect_values
	return str
end

-- 初始化角色装备栏
function ChItemBarService:init(character)
	local itembars = character.items
	
	if (type(itembars) == "string" and string_len(itembars) > 5) then
		itembars = WorldPacket:decodeData(itembars)
	else
		itembars = {}
	end
	
	character.items = itembars
	
	return true
end

-- 获取武器的装备ID
function ChItemBarService:getWuqiEid(character)
	local itembars = character.items
	local items = itembars.items
	if items then
		local item = items[ChItemDefs.EQUIPBAR_POS_WUQI]
		return item and item.equip_id or 0
	end
	return 0
end

