--[[
情侣系统pk Service
author : jianzhu
date : 2016-09-26
--]]

LoversService = LoversService or {}

--获取情侣昵称
function LoversService:getLoverNick(character)
	local lover_nick = character.lover_nick or ''
	local hidden_lover_nick = character.hidden_lover_nick or 0
	if hidden_lover_nick == 1 then lover_nick = '' end

	return lover_nick
end