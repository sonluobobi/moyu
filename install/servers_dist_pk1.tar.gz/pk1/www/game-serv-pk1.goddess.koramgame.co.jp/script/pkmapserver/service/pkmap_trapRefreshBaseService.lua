--[[
场景Trap基础servuce
author : xingzeng
date : 2012-03-27
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local table = table
local tableInsert = table.insert
local array = array
local TrapRefreshBaseDao = TrapRefreshBaseDao

TrapRefreshBaseService = TrapRefreshBaseService or {}

function TrapRefreshBaseService:getTrapRefreshBase(scene_id, trap_id)
	local scene_buffer_refs = TrapRefreshBaseDao.data[scene_id]
	
	if table.isTableEmpty(scene_buffer_refs) then
		return
	end
	
	if trap_id then
		for _, scene_buffer_ref in pairs(scene_buffer_refs) do
			local trap_ids = scene_buffer_ref.trap_ids
			if array.indexof(trap_ids, trap_id) then
				return scene_buffer_ref
			end
		end
	else
		return scene_buffer_refs
	end
end


