--[[
场景机器人系统 SERVICE
author : xingzeng.jiang
date : 2015-04-16
--]]

SceneRobotService = SceneRobotService or {}

local WorldPacket = WorldPacket
local Statics = Statics
local Time = Time
local random = math.random
local ceil = math.ceil
local table = table
local tableInsert = table.insert
local ext_getNowUnixMsTime = external.getNowUnixMsTime
local PROFILE_BIN_PKG_TAG_NEEDED=OptimizeSetting.PROFILE_BIN_PKG_TAG_NEEDED
local AoiObject = AoiObject
local aoi_type_robot = AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT
local math_floor = math.floor

local FightService, GameObjectService, CharacterService
function SceneRobotService:onAfterLoadLua()
	FightService = _G.FightService
	GameObjectService = _G.GameObjectService
	CharacterService = _G.CharacterService
end

do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	
	-- 写入基础外观
	function SceneRobotService:writeObjAppear(robot, fast_packet)
		writeByte(fast_packet, math_floor((robot.speed or 0) * 10))
		writeLong(fast_packet, robot.hp)
		writeUInt(fast_packet, 0)				-- base_id
		writeUInt(fast_packet, robot.parent_aoi_id)
		writeLong(fast_packet, robot.hp2)	-- 合体里位的幻兽 当前血量
		writeLong(fast_packet, robot.hp3)	-- 合体外位的幻兽 当前血量
	end
	
	-- 写入详细外观
	function SceneRobotService:writeObjAppearDetail(robot, fast_packet)
		local appear = robot.appear
		writeLong(fast_packet, robot.max_hp)
		writeString(fast_packet, robot.nick)
		writeByte(fast_packet, robot.prof)	-- prof
		writeByte(fast_packet, robot.gender)	-- gender
		writeUInt(fast_packet, appear.weaponid)			-- weaponid
		writeUInt(fast_packet, ChAppearService:getYifuOrAvatarForFight( appear ))	-- avatar
		writeUInt(fast_packet, robot.horses.ride_horse_id or 0)
		writeLong(fast_packet, robot.max_hp2)	-- 合体里位的幻兽 最大血量
		writeLong(fast_packet, robot.max_hp3)	-- 合体外位的幻兽 最大血量
		writeByte(fast_packet, robot.level)
		writeUInt(fast_packet, appear.wing_base_id)	--翅膀
		writeLong(fast_packet, robot.gcid)
		
		local sys_protect_expire = robot.tmps.sys_protect_expire or 0
		local relive_protect_expire = robot.tmps.relive_protect_expire or 0
		
		local bits = 0
		if sys_protect_expire > 0 then
			bits = ext_set_bit(bits, 0, 1)
		end
		if relive_protect_expire > 0 then
			bits = ext_set_bit(bits, 1, 1)
		end
		writeByte(fast_packet, bits)
		if sys_protect_expire > 0 then
			writeLong(fast_packet, sys_protect_expire)
		end
		if relive_protect_expire > 0 then
			writeLong(fast_packet, relive_protect_expire)
		end
		
		writeUInt(fast_packet, appear.title_id)					-- 称号
		writeUInt(fast_packet, robot.gang_id or 0)	-- 帮会
		writeUInt(fast_packet, robot.area_id)	-- 大区ID
		writeUInt(fast_packet, appear.qihun_wuqi or 0)	-- 器魂武器
		writeUInt(fast_packet, appear.qihun_yifu or 0)	-- 器魂衣服
		writeUShort(fast_packet, appear.ns_id or 0)		-- 跟随女神ID
		writeUShort(fast_packet, appear.ns_lv or 0)		-- 跟随女神等级		
		writeString(fast_packet, robot.gang_title or '')-- 跟随女神等级	
		writeUShort(fast_packet, robot.gang_job or 0)	--军团职业
		writeByte(fast_packet, robot.vip or 0)			--VIP
		writeUShort(fast_packet, appear.badge_id or 0)		--军团微章
		writeByte(fast_packet, appear.gang_type or 0)		--是否VIP军团		
		writeUInt(fast_packet, appear.shenbing or 0) 		--神兵
		writeString(fast_packet, '')	--情侣
		writeUInt(fast_packet, 0)		-- 精灵
	end
end

-- 每帧更新入口
function SceneRobotService:update(time_now, aoi_scene, robots)
	local now_second = Time.time_second          -- 当前时间(秒)
	local is_second_start = Time.is_second_start
	
	for _, game_obj in pairs(robots) do
		local aoi_obj = game_obj.aoi_obj
		
		-- 移动中
		if MotionService:isMoving(game_obj) then
			-- 移动更新
			MotionService:updateObject(aoi_scene, game_obj)
		end
		
		-- 秒更新
		if is_second_start then
			-- 角色定时自动回血
			CharacterService:autoRestoreHp(aoi_scene, game_obj, now_second)
		end

		-- 删除已死亡的
		if is_second_start then
			local pre_dead_srobots = aoi_scene.pre_dead_srobots
			if pre_dead_srobots then
				for gcid, srobot_info in pairs(pre_dead_srobots) do
					if srobot_info.dead_mtime <= time_now then
						local srobot = GameObjectService:getGameObjectByAoiId(aoi_scene, srobot_info.aoi_id)
						if srobot then GameObjectService:delObj(srobot, aoi_scene) end
						pre_dead_srobots[gcid] = nil
					end
				end
			end
		end
	end
end

function SceneRobotService:onFightDead(scene_robot)
	local aoi_scene = GameObjectService:getAoiScene(scene_robot)
	local pre_dead_srobots = aoi_scene.pre_dead_srobots or {}
	aoi_scene.pre_dead_srobots = pre_dead_srobots
	
	pre_dead_srobots[scene_robot.gcid] = {id=scene_robot.id, aoi_id=scene_robot.aoi_id,
				dead_mtime=Time.time_now + 5 * 1000}

	-- 通知BASE机器人死亡
	local data = {gcid = scene_robot.gcid}
	ServerCall:m2bCall('TeamService:onRobotDead', 0, data)
end

-- 创建一个场景机器人,并将机器人加入到场景实例中
function SceneRobotService:createSceneRobot(aoi_scene, robot_cid, robot_attrib_str, parent_ch_obj)
	-- 创建一个character
	local robot = SceneRobot.new()
	
	local robot_attrib_db = robot_attrib_str
	SceneRobot.init(robot, robot_attrib_db, parent_ch_obj)
	robot.id = robot_cid
	robot.gpid = Utils.genSceneRobotGPid(robot)
	robot.gcid = Utils.genSceneRobotGCid(robot.id)
	
	-- 初始化机器人角色数据
	CharacterService:initObject(robot, false)
	
	-- 随机一个传入点
	local x, y = SceneAoiService:getRandomTransferInForNormal(aoi_scene.scene_id)
			
	-- 创建AOI对象
	local aoi_obj = AoiObject.new(AoiObject, aoi_type_robot, x, y, 90, robot, aoi_scene)					
	
	-- 对幻兽对象设置机器人的AOI 信息
	ChPetService:setRobotAoiInfo(robot)
	
	-- 满血
	ReliveService:characterFullHp(robot)
	
	-- 机器人战斗相关属性(供客户端使用)
	robot.client_fight_attribs = SceneRobotService:newRobotChDetailByCharacter(robot)
	SceneRobotService:sendSceneRobotInfo(parent_ch_obj, robot)
	
	-- 加入场景AOI
	GameObjectService:addObj(robot, aoi_obj, aoi_scene)
	
	-- 出战幻兽
	ChPetService:showFightPet(robot, aoi_scene)
	
	return robot
end

-- 机器人主人发生改变
do
	local update_data = {}
	function SceneRobotService:robotMansterUpdate(robot, parent_ch_obj)
		local aoi_scene = GameObjectService:getAoiScene(robot)
		robot.parent_aoi_id = parent_ch_obj.aoi_id
		
		update_data.parent_aoi_id = robot.parent_aoi_id
		GameObjectService:appearDirty(robot)
		SceneService:sendAppearDetailUpdate(aoi_scene, robot, update_data)
	end
end


-- 通过游戏对象Character 创建机器人角色属性对象 RobotChDetail
function SceneRobotService:newRobotChDetailByCharacter(character)
	local robot_ch_detail = {}
	robot_ch_detail.gcid = character.gcid
	robot_ch_detail.id = character.id
	robot_ch_detail.nick = character.nick				-- 昵称
	robot_ch_detail.gender = character.gender			-- 性别
	robot_ch_detail.prof = character.prof				-- 职业
	robot_ch_detail.level = character.level				-- 等级

	robot_ch_detail.picture = character.picture			-- 头像
	robot_ch_detail.res_id = character.res_id			-- 头像

	robot_ch_detail.fight_capacity = character.fight_capacity		-- 战力
	robot_ch_detail.speed = character.speed							-- 速度
	
	robot_ch_detail.max_hp = character.max_hp						-- 最大MP值
	robot_ch_detail.max_hp2 = character.max_hp2	or 0				-- 最大MP值
	robot_ch_detail.max_hp3 = character.max_hp3	or 0				-- 最大MP值
	
	robot_ch_detail.max_attack = character.max_attack				-- 最大攻击
	robot_ch_detail.min_attack = character.min_attack				-- 最小攻击

	robot_ch_detail.defence_phy = character.defence_phy				-- 物理防御
	robot_ch_detail.defence_magic = character.defence_magic			-- 魔法防御

	robot_ch_detail.douzhi = character.douzhi						-- 斗志

	robot_ch_detail.critical_hit = character.critical_hit			-- 暴击
	robot_ch_detail.dodge = character.dodge							-- 闪避
	robot_ch_detail.parry = character.parry							-- 格挡
	robot_ch_detail.addi_harm = character.addi_harm					-- 附伤 附加伤害绝对值
	robot_ch_detail.addi_harm_perc = character.addi_harm_perc		-- 加伤 增加百分比伤害
	robot_ch_detail.reduce_harm = character.reduce_harm				-- 减伤：降低伤害绝对值
	robot_ch_detail.reduce_harm_perc = character.reduce_harm_perc	-- 免伤：降低百分比伤害
	robot_ch_detail.kill_force = character.kill_force				-- 斩杀力
	robot_ch_detail.luck = character.luck							-- 幸运
	robot_ch_detail.rob_mianzhan_expire = character.rob_mianzhan_expire
	
	robot_ch_detail.horses = character.horses
	robot_ch_detail.pets = character.pets
	robot_ch_detail.skills = character.skills
	robot_ch_detail.updated = Time:getSecondsNow()
	
	robot_ch_detail.gang_id = character.gang_id
	robot_ch_detail.ride_horse_id = character.horses.ride_horse_id or 0
	
	-- 外形相关
	robot_ch_detail.wuqi_eid = character.appear.weaponid
	robot_ch_detail.yifu_avatar_eid = character.appear.avatar
	robot_ch_detail.full_jl_lev = 0
	robot_ch_detail.qihun_wuqi = character.appear.qihun_wuqi or 0
	robot_ch_detail.qihun_yifu = character.appear.qihun_yifu or 0
	robot_ch_detail.wing_base_id = character.appear.wing_base_id or 0	-- 翅膀
	robot_ch_detail.shenbing_eid = character.appear.shenbing or 0		-- 神兵
	robot_ch_detail.sb_skill_level = character.appear.sb_skill_level or 0		-- 神兵
	
	self:initRobotChDetail(robot_ch_detail)
	
	return robot_ch_detail
end

-- 初始化机器人角色属性
function SceneRobotService:initRobotChDetail(robot_ch_detail)
	-- 技能
	ChSkillService:initForRobot(robot_ch_detail)

	-- 幻兽
	ChPetService:initForRobot(robot_ch_detail)
	
	-- 坐骑
	ChHorseService:initForRobot(robot_ch_detail)
end

-- 响应进入场景后事件
function SceneRobotService:afterEnterScene(character, aoi_scene)
	
end

-- 发送机器人属性回包
do
	local rsp_opcode = opCodes.M2C_SCENE_ROBOT_INFO_GET
	local msg_name = "PackSceneRobot.M2C_SCENE_ROBOT_INFO_GET"
	local msg_proto = {}
	function SceneRobotService:sendSceneRobotInfo(character, robot)
		msg_proto.aoi_id = robot.aoi_id
		msg_proto.client_fight_attribs = robot.client_fight_attribs
		msg_proto.parent_aoi_id = robot.parent_aoi_id
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end
