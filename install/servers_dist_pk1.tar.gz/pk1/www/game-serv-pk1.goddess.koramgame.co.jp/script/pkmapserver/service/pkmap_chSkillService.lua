--[[
角色技能管理 SERVICE
author : xingzeng.jiang
date : 2014-07-15
格式 :
{"slot":[10107,10106,10105,10104,10101],
"ch_skills":{
	"10108":{"skill_id":10108,"level":1},
	"10106":{"skill_id":10106,"level":1},
	"10104":{"skill_id":10104,"level":1},
	"10102":{"skill_id":10102,"level":1},
	"10109":{"skill_id":10109,"level":1}
	}
}
--]]

local WorldPacket = WorldPacket
local pairs = pairs
local type = type
local Config = Config
local SkillDefs = SkillDefs
local SKILL_SLOT_POS_COUNT = SkillDefs.SKILL_SLOT_POS_COUNT
local Time = Time
local table = table
local errorCodes = errorCodes

local SkillBaseDao = SkillBaseDao
local SkillDetailDao = SkillDetailDao
local ChSkillsInfo = ChSkillsInfo

local f_sk_skill_id = 'skill_id'
local f_sk_level = 'level'

ChSkillService = ChSkillService or {}

local SkillBaseService

function ChSkillService:onAfterLoadLua()
	SkillBaseService = _G.SkillBaseService
end

function ChSkillService:init(character)
	local skills_info = character.skills
	if skills_info and skills_info ~= '' then
		skills_info = WorldPacket:decodeData(skills_info)
		character.skills = skills_info
	else
		skills_info = ChSkillsInfo:init()
		character.skills = skills_info
		--根据职业开启技能
		local prof_skills = SkillBaseDao.prof_id2skills[character.prof]
		assert(prof_skills)
--		table.dump(prof_skills, -1)
		for _, skill_base in pairs(prof_skills) do
			local skill_detail =  SkillBaseService:getSkillDetail(skill_base.id, 1) 
			if skill_detail.ch_level <= character.level then 
				ChSkillService:openChSkill(character, skill_base, false, true)
			end
		end		
--		CharacterService:key2Dirty(character, 'skills')
	end
end

-- 初始化机器人角色技能数据
function ChSkillService:initForRobot(character)
	local skills_info = character.skills
	if (type(skills_info) == "string" and string.len(skills_info) > 1) then
		skills_info = WorldPacket:decodeData(skills_info)
	end
	
	if type(skills_info) == 'table' then
		local arena_skills = {}
		for _, skill_id in pairs(skills_info.slot) do
			arena_skills[#arena_skills+1] = skills_info.ch_skills[skill_id]
		end
		character.arena_skills = arena_skills
	elseif skills_info and skills_info ~= '' then
		Logger:fatal('[ChSkillService:initForArena] skills_info is not table')
	end
	character.skills = nil

end


do
	local sb_skill_2_base_skill = {
		[10113] = 10107,
		[10114] = 10108,
		[10115] = 10109,
		[10213] = 10204,
		[10313] = 10306,
	}
	function ChSkillService:isShenbingSkill( skill_id )
		return sb_skill_2_base_skill[skill_id]
	end

	local shengcun_skill_hash = {
		[13001] = true,
		[13002] = true,
		[13003] = true,
		[13004] = true,
		[13005] = true,
		[13006] = true,
		[13007] = true,
		[13008] = true,
		[13009] = true,
		[13010] = true,
	}
	function ChSkillService:isShengcunSkill( skill_id )
		return shengcun_skill_hash[skill_id]
	end
	local zhanshi_skill_hash = {
		[10301] = true,
		[10302] = true,
		[10303] = true,
		[10312] = true,
	}
	function ChSkillService:isZhanshiBaseSkill( skill_id )
		return zhanshi_skill_hash[skill_id]
	end
end

--- 通过技能ID获取玩家技能详细数据
do
	local ch_skill_info = {}
	function ChSkillService:getChDetailSkillInfoById(character, skill_id)
		if ShengcunService:isInShengcun( character.scene_id ) then
			if self:isShengcunSkill(skill_id) then
				-- 在生存玩法中判断技能是否可以使用
				if ShengcunService:isCanUseSkill( character, skill_id ) then
					ch_skill_info.skill_detail = assert(SkillBaseService:getSkillDetail(skill_id, 1))
					ch_skill_info.skill_base = assert(SkillBaseService:getSkillBaseById(skill_id))						
				else
					-- 不能使用也让玩家正常使用
					ch_skill_info.skill_detail = assert(SkillBaseService:getSkillDetail(skill_id, 1))
					ch_skill_info.skill_base = assert(SkillBaseService:getSkillBaseById(skill_id))						
				end
			else
				if self:isZhanshiBaseSkill(skill_id) then 
					ch_skill_info.skill_detail = assert(SkillBaseService:getSkillDetail(skill_id, 1))
					ch_skill_info.skill_base = assert(SkillBaseService:getSkillBaseById(skill_id))						
				else
					assert(false, skill_id)
				end
			end			
		else
			local skills_info = character.skills
			local ch_skills = skills_info.ch_skills	
			if not ch_skills then return end	
			
			local skill = ch_skills[skill_id]
			if not skill then 
				-- 角色身上没有此技能时，查看BUFFER中是否有此技能
				if BufferService:isHasSkill(character, skill_id) then 
					ch_skill_info.skill_detail = assert(SkillBaseService:getSkillDetail(skill_id, 1))
					ch_skill_info.skill_base = assert(SkillBaseService:getSkillBaseById(skill_id))				
				-- 查看神兵系统是否拥有此技能
				elseif self:isShenbingSkill(skill_id) then
					local base_skill_id = self:isShenbingSkill(skill_id)
					if not base_skill_id then 
						return nil
					end
					local base_skill = assert(ch_skills[base_skill_id])
					ch_skill_info.skill_detail = assert(SkillBaseService:getSkillDetail(skill_id, base_skill.level))
					ch_skill_info.skill_base = assert(SkillBaseService:getSkillBaseById(skill_id))				
				else
					Logger:error('玩家使用不该使用的技能', character.gcid, character.nick, character.player_id, character.scene_id, skill_id)
					ch_skill_info.skill_detail = assert(SkillBaseService:getSkillDetail(skill_id, 1))
					ch_skill_info.skill_base = assert(SkillBaseService:getSkillBaseById(skill_id))							
				end
			else
				ch_skill_info.skill_detail = assert(SkillBaseService:getSkillDetail(skill_id, skill.level))
				ch_skill_info.skill_base = assert(SkillBaseService:getSkillBaseById(skill_id))
			end
		end
		return ch_skill_info
	end
end

-- 获取神兵的附加伤害值
do
	function ChSkillService:getShenbingExtraSkillEffect( character )

		local sb_skill_level = character.appear.sb_skill_level
		if not sb_skill_level or sb_skill_level <= 0 then 
			return nil
		end
		local shenbing_base = ShenbingBaseDao:getSkilBase(character.prof, sb_skill_level)
		return shenbing_base.extra_skill_effect
	end
end

--- 获取角色自动回血技能详细数据
do
	local ch_skill_info = {}
	local prof_2_skill = {
		[1] = 10110,
		[2] = 11103,	-- 策划不愿意改ID
		[3] = 10310,
	}
	function ChSkillService:getChDetailAutoSkillInfo(character)
		local prof = character.prof
		local skill_id = prof_2_skill[prof]
		local skills_info = character.skills
		local ch_skills = skills_info.ch_skills	
		if not ch_skills then return end	
		
		local skill = ch_skills[skill_id]
		if not skill then return nil end
		
		ch_skill_info.skill_detail = assert(SkillBaseService:getSkillDetail(skill_id, skill.level))
		ch_skill_info.skill_base = assert(SkillBaseService:getSkillBaseById(skill_id))
		return ch_skill_info
	end
end

--- 获取玩家技能信息
function ChSkillService:getChSkill(character, skill_id)
	local skills_info = character.skills
	local ch_skills = skills_info.ch_skills	
	if not ch_skills then return end	
	return ch_skills[skill_id], skills_info
end

--获取技能等级
function ChSkillService:getChSkillLevel(character,skill_id)
	
	local ch_skills = character.skills.ch_skills	
	if not ch_skills then return end
	
	local ch_skill = ch_skills[skill_id]
	if not ch_skill then return end
	
	return ch_skill[f_sk_level]
end

--- 开启技能
function ChSkillService:openChSkill(character, skill_base, is_send, is_into_slot)
	local skills_info = character.skills
	local ch_skills = skills_info.ch_skills
	if not ch_skills then
		ch_skills = {}
		skills_info.ch_skills = ch_skills
	end
	
	local skill_id = skill_base.id
	local skill_group_id = skill_base.group_id
	local ch_skill = ch_skills[skill_id]
	if ch_skill then
		Logger:error('skill is opened', character.id, skill_id)
		return ch_skill
	end
	
	ch_skill = 
	{
		[f_sk_skill_id] = skill_id,
		[f_sk_level] = 1,
	}
	ch_skills[skill_id] = ch_skill
	
	local is_up_slot = false
	if is_into_slot then
		local slot = skills_info.slot
		local skill_base_t = SkillBaseDao[skill_id]
		local empty_pos
		local slot_pos = skill_base_t.slot_pos
		if slot_pos and not slot[slot_pos] and slot_pos > 0 then
			slot[slot_pos] = skill_id
			is_up_slot = true
			empty_pos = slot_pos
		end
	end
	
--	CharacterService:key2Dirty(character, 'skills')
	
	if is_send then
		self:sendChSkillOpen(character, ch_skill)
		
		if is_up_slot then
			self:sendSkillSlotUpdate(character, empty_pos, skill_id)
		end
	end
	
	return ch_skill
end

--获取技能战力加成
function ChSkillService:getFightCapacity(character)
	local skills_info = character.skills
	local slot = skills_info.slot
	local ch_skills = skills_info.ch_skills
	
	local fight_capacity = 0
	if slot then
		for order_by, skill_id in pairs(slot) do
			local skill_base = SkillBaseDao[skill_id]
			local fc_coeff = skill_base.fc_coeff
			assert(fc_coeff and fc_coeff > 0, skill_id)
			
			local ch_skill = ch_skills[skill_id]
			if ch_skill then 
				fight_capacity = fight_capacity + fc_coeff * ch_skill[f_sk_level]
			end
		end
	end
	
	return fight_capacity
end

--查看技能是否在技能槽中
function ChSkillService:isSkillInSlot(character, skill_id)
	local skills_info = character.skills
	local slot = skills_info.slot
	local skill_base = SkillBaseDao.getSkillBaseById(skill_id)
	local slot_pos = skill_base.slot_pos
	return slot[slot_pos] == skill_id
end

do
	local obj_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
	
	function ChSkillService:updateCurrentSkill(aoi_scene, attacker, skill_base)
		-- 暂没有当前技能需求
	end
end

function ChSkillService:updateCooling(game_obj, skill_base)
	local time_now = Time.time_now
	local self_skill_expire = time_now + skill_base.self_skill_expire
	local play_skill_expire = time_now + skill_base.play_skill_expire
	local tmps = game_obj.tmps
	
	tmps.self_skill_expire = self_skill_expire
	tmps.play_skill_expire = play_skill_expire
end

do
	function ChSkillService:updateSkillSlot(character, order_by, skill_id, is_send)
		local skills_info = character.skills
		local slot = skills_info.slot
		--位置错误
		if order_by > SKILL_SLOT_POS_COUNT or order_by < 1 then
			Logger:error('[updateSkillSlot] order_by > SKILL_SLOT_POS_COUNT', character.id, character.player_id, order_by, skill_id)
			return false, errorCodes.SKILLS_ERROR_ORDERBY_BEYOND
		end
		-- 检查是否已学得该技能
		local ch_skill = self:getChSkill(character, skill_id)
		if not ch_skill then
			Logger:error('[updateSkillSlot] ch_skill is nil', character.id, character.player_id, order_by, skill_id)
			return false, errorCodes.SKILLS_ERROR_NO_OWN
		end
		--已经装备此技能
		if slot[order_by] == skill_id then
			return false,errorCodes.SKILLS_ERROR_ALREADY_SLOT
		end

		local skill_base = SkillBaseDao[skill_id]
		local slot_pos = skill_base.slot_pos
		--未放在正确的位置
		if slot_pos ~= order_by then
			return false,errorCodes.SKILLS_ERROR_SLOT_ERR_POS
		end
		
		slot[slot_pos] = skill_id
--		CharacterService:key2Dirty(character, 'skills')
		if is_send then
			self:sendSkillSlotUpdate(character, order_by, skill_id)
		end
		
		return true
	end
end

--升级技能 
function ChSkillService:upgradeSkill(character, skill_id)
	local ch_skill = self:getChSkill(character, skill_id)
	local level = ch_skill[f_sk_level]
	
	--技能等级不能超过玩家等级
	if level >= character.level then
		return false, errorCodes.SKILLS_ERROR_CANNOT_BEYOND_CHLEV
	end
	
	level = level + 1
	--已经达到最高级
	local skill_detail = SkillBaseService:getSkillDetail(skill_id, level)
	if not skill_detail then
		return false, errorCodes.SKILLS_ERROR_LEV_FULL
	end
	
	--未达到升级需要的升级
	if skill_detail.ch_level > character.level then
		return false, errorCodes.SKILLS_ERROR_CH_LEV_NOT_ENOUGH
	end
	
	ch_skill[f_sk_level] = level
	self:sendChSkillUpgrade(character, ch_skill)
	
	-- 相同父技能ID的技能一起升级
	local skill_base = SkillBaseService:getSkillBaseById(skill_id)
	local parent_id = skill_base.parent_id
	if parent_id and parent_id > 0 then
		local skill_bases = SkillBaseDao.parent_id2skills[parent_id]
		for skill_id_t, skill_base_t in pairs(skill_bases) do
			if skill_id_t ~= skill_id then
				local ch_skill_t = self:getChSkill(character, skill_id_t)
				ch_skill_t[f_sk_level] = level
				self:sendChSkillUpgrade(character, ch_skill_t)
			end
		end
	end
--	CharacterService:key2Dirty(character, 'skills')
	
	return true
end
--[[
function ChSkillService:skillsToFightCapacity(skills)
	do return 100 end
end
]]--
function ChSkillService:pack(character)
	return WorldPacket:encodeData(character.skills)
end

do
	local rsp_opcode = opCodes.M2C_CH_SKILL_SKILLS_INFO_GET
	local msg_name = "PackSkill.M2C_CH_SKILL_SKILLS_INFO_GET"
	local msg_proto = {}
	function ChSkillService:sendChChSkillsInfo(character)
		local ch_skills = character.skills.ch_skills
		msg_proto.arr_ch_skill = table.values(ch_skills)
		
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_SKILL_SLOT_GET
	local msg_name = "PackSkill.M2C_CH_SKILL_SLOT_GET"
	local msg_proto = {arr_skill_id = {}}
	function ChSkillService:sendChChSkillSlotInfo(character)
		local slot = character.skills.slot
		local arr_skill_id = msg_proto.arr_skill_id
		for i = 1, SKILL_SLOT_POS_COUNT do
			arr_skill_id[i] = slot[i] or 0
		end
		
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_SKILL_UPGRADE
	local msg_name = "PackSkill.M2C_CH_SKILL_UPGRADE"
	local msg_proto = {}
	function ChSkillService:sendChSkillUpgrade(character, ch_skill)
		local msg_proto = msg_proto
		msg_proto.skill_id = ch_skill[f_sk_skill_id]
		msg_proto.level = ch_skill[f_sk_level]
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_SKILL_CHSKILL_OPEN
	local msg_name = "PackSkill.M2C_CH_SKILL_CHSKILL_OPEN"
	local msg_proto = {}
	function ChSkillService:sendChSkillOpen(character, ch_skill)
		local msg_proto = msg_proto
		msg_proto.skill_id = ch_skill[f_sk_skill_id]
		msg_proto.level = ch_skill[f_sk_level]
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end

do
	local rsp_opcode = opCodes.M2C_CH_SKILL_SLOT_UPDATE
	local msg_name = "PackSkill.M2C_CH_SKILL_SLOT_UPDATE"
	local msg_proto = {}
	function ChSkillService:sendSkillSlotUpdate(character, order_by, skill_id)
		local msg_proto = msg_proto
		msg_proto.skill_id = skill_id
		msg_proto.order_by = order_by
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, character.gpid)
	end
end


