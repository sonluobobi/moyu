--[[
爱情圣殿Service
author : guoyin.huang
date : 2016-11-08
]]--


LoverTempleService = LoverTempleService or {}
setmetatable(LoverTempleService, SceneServiceInterface)

local SceneService = SceneService
function LoverTempleService:onAfterLoadLua()
	SceneService = _G.SceneService
end

-- 场景初始化
function LoverTempleService:onInitScene(character, aoi_scene)
	local lover_temple = {}
	aoi_scene.lover_temple = lover_temple
	
	-- 队伍ID到阵营数据
	lover_temple.team_id_2_lover_info = {}
	-- gcid到阵营数据
	lover_temple.gcid_2_lover_info = {}
	-- 配置
	lover_temple.scene_id = aoi_scene.scene_id
	-- 任务ID起始位置
	lover_temple.task_id_start = 1
	
	-- 创建怪物
	self:initMonster(aoi_scene)

	-- 默认场景初始化
	SceneService:onInitSceneDefault(character, aoi_scene)
	return true
end

do
	local lover_temple_scene_hash = {}
	for _, scene_id in pairs(SceneDefs.LOVER_TEMPLE_SCENE_IDS) do
		lover_temple_scene_hash[scene_id] = true
	end
	-- 判断是否在爱情圣殿中
	function LoverTempleService:isInLoverTemple( scene_id )
		return lover_temple_scene_hash[scene_id]
	end
end

--- 新建一个爱情任务对象
function LoverTempleService:newLoverTaskData( lover_temple, character )
	local lover_info = {}
	lover_info.task_npcs = {}	-- 当前NPC数据
	lover_info.tasks = {}		-- 当前任务数据

	-- 随机NPC（同时随机任务）
	for i=1, LoverTempleConfig.team_npc_num do
		self:randomNpc(lover_temple, lover_info)
	end
end

-- 增加一个NPC(同时会在NPC上挂载一个任务)
function LoverTempleService:randomNpc( lover_temple, lover_info )
	local pos = math.random
	local scene_id = lover_temple.scene_id
	local config = LoverTempleConfig.scene_id_2_config[scene_id]

	-- 已经使用的NPC
	local used_npc_id_hash = {}
	local used_position_id_hash = {}
	for _, npc_info in pairs(lover_info.task_npcs) do
		used_npc_id_hash[npc_info.npc_id] = true
		used_npc_id_hash[npc_info.position_id] = true
	end

	-- 随机一个NPC
	local npc_ids = config.npc_ids
	assert(#npc_ids >= 4)
	local pos = math.random(1, #npc_ids)
	while used_npc_id_hash[npc_ids[pos]] do
		pos = pos + 1
		if pos > #npc_ids then 
			pos = 1
		end
	end
	local npc_id = npc_ids[pos]

	-- 随机一个坐标
	local scene_points = ScenePositionDao:getScenePosesByType(scene_id, ScenePositionDefs.SCENE_POSITION_TYPE_NPC)
	local point_pos = math.random(1, #scene_points)
	while used_position_id_hash[scene_points[point_pos].id] do
		point_pos = point_pos + 1
		if point_pos > #scene_points then 
			point_pos = 1
		end		
	end
	local scene_point = scene_points[point_pos]

	local npc_info = {}
	npc_info.npc_id = npc_id
	npc_info.x = scene_point.x
	npc_info.y = scene_point.y
	npc_info.position_id = scene_point.id
	npc_info.is_accept = false

	-- 随机一个任务
	local task = LoverTempleService:randomTask( lover_temple,false,  lover_info.is_lover )
	task.npc = npc_info
	npc_info.task = task
	npc_info.task_base_id = task.task_base_id
	npc_info.task_id = task.task_id
	return npc_info
end

function LoverTempleService:randomTask( lover_temple, is_except_find, is_lover )
	-- 随机一个任务类型
	local task_base = LoverTempleTaskBaseDao:random( is_except_find, is_lover )
	local config = LoverTempleConfig.scene_id_2_config[lover_temple.scene_id]

	-- 给任务随机具体数值（包括怪物，采集物，夺宝的位置）
	local task = {}
	task.task_id = lover_temple.task_id_start 
	task.task_base_id = task_base.id
	task.task_base = task_base
	task.status = 0


	if task_base.dst_sort_id == TaskDefs.LOVE_TEMPLE_SORT_ID_MONSTER then

		-- 如果是杀怪类型，随机两种怪
		task.monster = {}
		-- 随机两种怪
		local monster_ids = math.randExtract(config.monster_ids, 2)
		for _, monster_id in pairs(monster_ids) do
			local monster_scedule = {
				monster_id = monster_id,
				need_cnt = 1,
				fin_cnt = 0,
			}
			table.insert(task.monster, monster_scedule)
		end

	elseif task_base.dst_sort_id == TaskDefs.LOVE_TEMPLE_SORT_ID_CAIJI then

		-- 如果是采集类型，随机两种采集物
		task.caiji = {}
		-- 随机两种怪
		local caiji_ids = math.randExtract(config.caiji_ids, 2)
		for _, caiji_id in pairs(caiji_ids) do
			local caiji_scedule = {
				caiji_id = caiji_id,
				need_cnt = 1,
				fin_cnt = 0,
			}
			table.insert(task.caiji, caiji_scedule)
		end

	elseif task_base.dst_sort_id == TaskDefs.LOVE_TEMPLE_SORT_ID_WABAO then

		-- 如果是挖宝类型，随机两个坐标
		task.wabao = {}
		task.wabao.status = 1
		local scene_point = ScenePositionDao:getScenePosRandomByType(lover_temple.scene_id, ScenePositionDefs.SCENE_POSITION_TYPE_WABAO)
		task.wabao.bt_x = scene_point.x
		task.wabao.bt_y = scene_point.y
		local scene_point = ScenePositionDao:getScenePosRandomByType(lover_temple.scene_id, ScenePositionDefs.SCENE_POSITION_TYPE_WABAO)
		task.wabao.bx_x = scene_point.x
		task.wabao.bx_y = scene_point.y		

	elseif task_base.dst_sort_id == TaskDefs.LOVE_TEMPLE_SORT_ID_FIND_MEMBER then

		-- 如果找人类型，啥也不做
		-- do nothing

	else
		assert(false)
	end

	lover_temple.task_id_start = lover_temple.task_id_start + 1

	return task
end

-- 当怪物被杀时
function LoverTempleService:onKilledMonster( character, arr_kill_monster_id, arr_kill_monster_aoi_id )
	local aoi_scene = GameObjectService:getAoiScene(character)
	if not aoi_scene.lover_temple then 
		return 
	end	

	local lover_info = assert(self:getLoverInfoByGcid(aoi_scene, character.gcid))
	if lover_info.is_send_time_out then 
		return
	end	
	local is_modify = false
	
	for _, monster_id in pairs(arr_kill_monster_id) do
		-- 检查任务完成
		for _, task in pairs(lover_info.tasks) do
			if task.monster then 
				for _, monster_scedule in pairs(task.monster) do
					if monster_scedule.monster_id == monster_id and monster_scedule.need_cnt > monster_scedule.fin_cnt then 
						monster_scedule.fin_cnt = monster_scedule.fin_cnt + 1
						is_modify = true
					end
				end
			end
		end

		-- 重新生成怪物
		self:addMonster(aoi_scene,monster_id)
	end

	-- 检查任务完成
	if is_modify then 
		local fin_tasks = {}
		for _, task in pairs(lover_info.tasks) do
			if task.monster then 
				local is_fin = true
				for _, monster_scedule in pairs(task.monster) do
					if monster_scedule.fin_cnt < monster_scedule.need_cnt then 
						is_fin = false
					end
				end
				if is_fin then 
					table.insert(fin_tasks, task)
				end
			end
		end

		-- 完成任务
		for _, task in pairs(fin_tasks) do
			self:serverFinTask(aoi_scene.lover_temple ,lover_info, task)
		end

		-- 发送任务信息到客户端
		self:sendTaskInfo(lover_info, lover_info.gpids)
	end
end

-- 发某个任务的奖励
function LoverTempleService:reward( lover_info, task )
	local task_base = task.task_base
	local reward = task_base.reward
	local reward_num = task_base.reward_num

	-- 双方均发奖
	local gcid_2_jiesuan = lover_info.gcid_2_jiesuan

	for gcid, ch_jiesuan in pairs(gcid_2_jiesuan) do
		-- 将奖励加到总的奖励中
		ch_jiesuan.fin_task_num = ch_jiesuan.fin_task_num  + 1

		local character = CharacterService:getCharacterByGcid(gcid)
		local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE_REWARD)
		if en_count > 0 then 
			-- 添加次数
			local reward_num = task_base.reward_num
			CounterService:addcount(character, counter, nil, reward_num > en_count and en_count or reward_num)
			ch_jiesuan.reward_num = ch_jiesuan.reward_num + reward_num
			local equips = ch_jiesuan.equips
			for k, v in pairs(reward) do equips[k] = (equips[k] or 0) + v end	
		else
			-- 广播当日的奖励次数已用完
			WorldPacket:m2cSendCommOkMsg(OKMsgCodes.LOVER_TEMPLE_LOVER_REWARD_TIMES_UP, nil, character.gpid)
			
			-- 奖励列表里面添加除爱情石外的其他道具
			local equips = ch_jiesuan.equips
			for k, v in pairs(reward) do 
				if k ~= EquipDefs.FUNCTION_EQUIP_ID_AIQINGSHI then 
					equips[k] = (equips[k] or 0) + v 
				end
			end				
		end
	end

	-- 告诉客户端，已完成任务数与获得奖励数量更新
	self:sendFinTaskNumUpdate(lover_info)
end

function LoverTempleService:initMonster( aoi_scene )
	local scene_id = aoi_scene.scene_id
	local config = LoverTempleConfig.scene_id_2_config[scene_id]
	for _, monster_id in pairs(config.monster_ids) do
		-- 创建相对数据的怪
		for i=1, LoverTempleConfig.monster_num do
			LoverTempleService:addMonster( aoi_scene, monster_id )
		end
	end
end

function LoverTempleService:addMonster( aoi_scene, monster_id )
	local scene_poses = ScenePositionDao:getScenePosByType(aoi_scene.scene_id, ScenePositionDefs.SCENE_POSITION_TYPE_MONSTER)
	local scene_pos_base = scene_poses[math.random(1, #scene_poses)]
	local monster = MonsterService:dymCreateMonster(aoi_scene, monster_id,nil , scene_pos_base.x, scene_pos_base.y, scene_pos_base.direction)
end

-- 接任务
function LoverTempleService:acceptTask(aoi_scene, character, arr_params, is_force, member_num )
	local accept_task = nil
	local lover_temple = aoi_scene.lover_temple
	local lover_info = lover_temple.gcid_2_lover_info[character.gcid]	
	
	if not is_force then 
		local task_id = arr_params.task_id

		-- 每个玩家最多只能接两个任务
		local accept_task_num = 0
		for _, task in pairs(lover_info.tasks) do
			if task.gcid == character.gcid then 
				accept_task_num = accept_task_num + 1
			end
		end
		if accept_task_num >= 2 then 
			return false, errorCodes.LOVER_TEMPLE_TASK_ACCEPT_TOO_MORE
		end

		-- 接取任务
		local task_npc_info = nil
		for _, npc_info in pairs(lover_info.task_npcs) do
			if npc_info.task_id == task_id then 
				if npc_info.is_accept then 
					return false, errorCodes.COMMON_PARAM_ERROR
				end

				if npc_info.task.task_base.dst_sort_id == TaskDefs.LOVE_TEMPLE_SORT_ID_FIND_MEMBER then 
					if #lover_info.gpids <= 1 then 
						return false, errorCodes.LOVER_TEMPLE_TASK_ACCEPT_NEED_2
					end
				end

				task_npc_info = npc_info
				break
			end
		end

		-- 没找到对应 NPC
		if not task_npc_info then 
			return false, errorCodes.COMMON_PARAM_ERROR
		end

		-- 标记NPC为任务已接
		task_npc_info.is_accept = true
		accept_task = task_npc_info.task
	else
		local team = TeamService:getTeamByGCid(character.gcid)
		accept_task = self:randomTask(lover_temple, member_num and member_num <= 1)
	end
	-- 接任务
	accept_task.gcid = character.gcid
	accept_task.aoi_id = character.aoi_obj.obj_id
	accept_task.status = 1
	table.insert(lover_info.tasks, accept_task)

	-- 如果是挖宝任务，添加小地图对象
	if accept_task.task_base.dst_sort_id == TaskDefs.LOVE_TEMPLE_SORT_ID_WABAO then 
		-- 添加小地图对象
		accept_task.smallmap_item = SmallMapItem:newSimple(SmallMapDefs.SMALL_MAP_SORT_ID_JEWEL_BOX, accept_task.wabao.bt_x, accept_task.wabao.bt_y)
		SmallMapService:sendItemUpdate(aoi_scene, accept_task.smallmap_item, lover_info.gpids)
	end

	self:sendNpcInfo(lover_info, lover_info.gpids)
	self:sendTaskInfo(lover_info, lover_info.gpids)
	return true	
end

-- 完成任务
function LoverTempleService:finishTask( aoi_scene, character, arr_params )
	local task_id = arr_params.task_id
	local task = nil
	local lover_info = assert(self:getLoverInfoByGcid(aoi_scene, character.gcid))
	for _, ch_task in pairs(lover_info.tasks) do
		if ch_task.task_id == task_id then 
			task = ch_task
			break
		end
	end
	if not task then 
		return true
	end

	if task.status == TaskDefs.CH_TASK_STATUS_FINISHED then 
		return false, errorCodes.LOVER_TEMPLE_TASK_HAS_FINISH
	end
 
	-- 查看任务类型
	local task_base = task.task_base
	if task_base.dst_sort_id == TaskDefs.LOVE_TEMPLE_SORT_ID_FIND_MEMBER then 
		-- 只有找人任务可客户端完成
		return self:serverFinTask(aoi_scene.lover_temple, lover_info, task )
	else
		-- 其他任务不允许直接完成
		return false, errorCodes.COMMON_PARAM_ERROR
	end
end

-- 放弃任务
function LoverTempleService:giveupTask( aoi_scene, character, arr_params )
	local give_up_task_id = arr_params.task_id
	local lover_info = assert(self:getLoverInfoByGcid(aoi_scene, character.gcid))
	for _, task in pairs(lover_info.tasks) do
		if task.task_id == give_up_task_id then 
			if task.gcid ~= character.gcid then
				if task.task_base.dst_sort_id ~= TaskDefs.LOVE_TEMPLE_SORT_ID_FIND_MEMBER then 
					return false, errorCodes.LOVER_TEMPLE_TASK_CANNOT_GIVE_OTHERS
				end
				
				if #lover_info.gpids > 1 then 
					return false, errorCodes.LOVER_TEMPLE_TASK_CANNOT_GIVE_OTHERS
				end
			end
			table.remove(lover_info.tasks, _)

			if task.smallmap_item then 
				SmallMapService:delSmallMapItem(aoi_scene, task.smallmap_item.aoi_id, lover_info.gpids)
			end

			for _, gpid in pairs(lover_info.gpids) do
				if gpid ~= character.gpid then 
					local params = {}
					table.insert(params, character.nick)
					table.insert(params, string.format('{lovertemple_title:%d}',task.task_base_id))
					WorldPacket:m2cSendCommOkMsg(OKMsgCodes.LOVER_TEMPLE_LOVER_GIVE_UP, params, gpid)
				end
			end

			if task.npc then 
				task.npc.is_accept = false
			end

			self:sendTaskInfo(lover_info, lover_info.gpids)

			return true
		end
	end
	return false, errorCodes.LOVER_TEMPLE_TASK_NOT_EXIST
end

-- 当完成挖宝时
function LoverTempleService:onFinWabao( aoi_scene, character, arr_params )
	local task_id = arr_params.task_id
	local lover_info = assert(self:getLoverInfoByGcid(aoi_scene, character.gcid))
	if lover_info.is_send_time_out then 
		return 
	end
	-- 检查任务完成
	local task 
	for _, ch_task in pairs(lover_info.tasks) do
		if ch_task.task_id == task_id then 
			task = ch_task
		end
	end	
	if task then 
		if arr_params.status == 2 then 
			self:serverFinTask(aoi_scene.lover_temple ,lover_info, task)
			SmallMapService:delSmallMapItem(aoi_scene, task.smallmap_item.aoi_id, lover_info.gpids)
		else
			task.wabao.status = 2
			self:sendTaskInfo(lover_info, lover_info.gpids)
			SmallMapService:delSmallMapItem(aoi_scene, task.smallmap_item.aoi_id, lover_info.gpids)
			task.smallmap_item = SmallMapItem:newSimple(SmallMapDefs.SMALL_MAP_SORT_ID_JEWEL_BOX, task.wabao.bx_x, task.wabao.bx_y)
			SmallMapService:sendItemUpdate(aoi_scene, task.smallmap_item, lover_info.gpids)
		end
	end
end

-- 当完成采集时
function LoverTempleService:onFinCaiji( aoi_scene, character, caiji_id )
	local lover_info = assert(self:getLoverInfoByGcid(aoi_scene, character.gcid))
	if lover_info.is_send_time_out then 
		return
	end	
	local is_modify = false

	-- 检查任务完成
	for _, task in pairs(lover_info.tasks) do
		if task.caiji then 
			for _, caiji_scedule in pairs(task.caiji) do
				if caiji_scedule.caiji_id == caiji_id and caiji_scedule.need_cnt > caiji_scedule.fin_cnt then 
					caiji_scedule.fin_cnt = caiji_scedule.fin_cnt + 1
					is_modify = true
				end
			end
		end
	end

	-- 检查任务完成
	if is_modify then 
		local fin_tasks = {}
		for _, task in pairs(lover_info.tasks) do
			if task.caiji then 
				local is_fin = true
				for _, caiji_scedule in pairs(task.caiji) do
					if caiji_scedule.fin_cnt < caiji_scedule.need_cnt then 
						is_fin = false
					end
				end
				if is_fin then 
					table.insert(fin_tasks, task)
				end
			end
		end

		for _, task in pairs(fin_tasks) do
			self:serverFinTask(aoi_scene.lover_temple ,lover_info, task)
		end

		self:sendTaskInfo(lover_info, lover_info.gpids)
	end	
end

-- 服务端调用任务完成
function LoverTempleService:serverFinTask( lover_temple, lover_info, task )
	if lover_info.is_send_time_out then 
		return 
	end
	assert(task.status == TaskDefs.CH_TASK_STATUS_ACCEPT)
	self:reward(lover_info, task)

	-- 删除任务
	for _, ch_task in pairs(lover_info.tasks) do
		if ch_task.task_id == task.task_id then 
			table.remove(lover_info.tasks, _)
			-- 通知客户端任务完成
			LoverTempleService:sendTaskFinish(ch_task, lover_info.gpids)
			break
		end
	end

	-- 如果有NPC是此任务，刷新此NPC
	for _, npc_info in pairs(lover_info.task_npcs) do
		if npc_info.task_id == task.task_id then 
			lover_info.task_npcs[_] =  nil
			lover_info.task_npcs[_] = self:randomNpc(lover_temple, lover_info)
			break
		end
	end
	self:sendTaskInfo(lover_info, lover_info.gpids)
	self:sendNpcInfo(lover_info, lover_info.gpids)

	return true
end

function LoverTempleService:update500ms(now_time_msec, aoi_scene)
	local now_time = math.floor(now_time_msec / 1000)
	local lover_temple = aoi_scene.lover_temple
	for _, lover_info in pairs(lover_temple.team_id_2_lover_info) do
		if lover_info.next_task_update_time <= now_time then 
			-- 刷新任务
			LoverTempleService:updateLoverNpc( lover_temple, lover_info )
			-- 设置下次刷新时间
			lover_info.next_task_update_time = now_time + LoverTempleConfig.task_update_interval
		end

		-- 如果玩法时间到，发送总的结算数据
		if not lover_info.is_send_time_out and lover_info.end_time < now_time then 
			-- 发安慰奖
			for gcid, ch_jiesuan in pairs(lover_info.gcid_2_jiesuan) do
				
				if ch_jiesuan.fin_task_num <= 0 then 
					-- 发保底奖
					local character = CharacterService:getCharacterByGcid(gcid)
					local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE_REWARD)
					if en_count > 0 then 
						CounterService:addcount(character, counter, nil, 1)
					end
					local baodi_reward = {[21010529]=1,[21013901]=1}

					-- 添加次数
					ch_jiesuan.reward_num = 1
					ch_jiesuan.equips = baodi_reward						
				end
			end
			LoverTempleService:sendTimeOut(lover_info)
			lover_info.is_send_time_out = true
		end

		-- 如果玩法时间已经结束一定时间后，直接将玩家踢出
		if lover_info.end_time + 5 < now_time then 
			for gcid, _ in pairs(lover_info.gcid_hash) do
				ServerCall:m2bCall('SceneService:logoutWanfa', gcid, nil)
			end
		end

		if not lover_info.is_send_small_map then 
			-- 发送小地图数据
			local small_map_items = {}
			for _, task in pairs(lover_info.tasks) do
				if task.smallmap_item then 
					table.insert(small_map_items, task.smallmap_item)
				end
			end
			if #small_map_items > 0 then 
				SmallMapService:sendItemsUpdate(aoi_scene, small_map_items, lover_info.gpids)
			end		
		end
	end
end

-- 更新NPC数据
function LoverTempleService:updateLoverNpc( lover_temple, lover_info )
	local is_modify = false
	for _, npc in pairs(lover_info.task_npcs) do
		if npc.is_accept then 
			is_modify = true
			lover_info.task_npcs[_] = nil
			lover_info.task_npcs[_] = self:randomNpc(lover_temple, lover_info)
		end
	end
	if is_modify then 
		self:sendNpcInfo(lover_info, lover_info.gpids)
	end
end

function LoverTempleService:getBirthPos(  aoi_scene, character )
	local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE)
	if counter.count_total <= 0 then 
		-- 传到某个NPC边上
		local lover_info = self:getLoverInfoByGcid(aoi_scene, character.gcid)
		if lover_info then 
			local npc_info = lover_info.task_npcs[math.random(1, #lover_info.task_npcs)]
			-- 移动到NPC旁边
			return true, npc_info.x + 1, npc_info.y
		end
	end	
end

-- 进入场景之后
function LoverTempleService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	local lover_temple = aoi_scene.lover_temple
	local team = assert(TeamService:getTeamByGCid(character.gcid))

	--如果还没有队伍数据，则新建队伍数据
	local lover_info = lover_temple.team_id_2_lover_info[team.id] 	

	if not is_reconnect then 
		local en_count, counter = CounterService:getEnUseCount(character, CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE)
		local is_first = false
		if counter.count_total <= 0 then 
			is_first = true
		end		

		-- 扣除次数
		CounterService:addcount(character, counter, 1)

		if not lover_info then 
			lover_info = {}
			lover_temple.team_id_2_lover_info[team.id] = lover_info

			lover_info.task_npcs = {}
			lover_info.tasks = {}
			lover_info.gcid_hash = {}
			lover_info.gcid_2_jiesuan = {}
			lover_info.gpids = {}
			lover_info.aoi_ids = {}
			lover_info.team_id = team.id
			lover_info.task_id_2_smallmaps = {} 	-- 任务ID到小地图对象
			lover_info.next_task_update_time = os.time() + LoverTempleConfig.task_update_interval
			lover_info.end_time = os.time() + LoverTempleConfig.task_time_long

			for i=1, 4 do
				table.insert(lover_info.task_npcs, self:randomNpc(lover_temple, lover_info))
			end
			if is_first then 
				lover_info.task_npcs[1].x = character.x + 1
				lover_info.task_npcs[1].y = character.y + 1
			end
		end
		if not lover_temple.gcid_2_lover_info[character.gcid] then
			lover_temple.gcid_2_lover_info[character.gcid] = lover_info
			lover_info.gcid_hash[character.gcid] = character.aoi_obj.obj_id
			lover_info.gcid_2_jiesuan[character.gcid] = {fin_task_num = 0, equips = {}, gpid=character.gpid, reward_num=0}
			table.insert(lover_info.gpids, character.gpid)
			table.insert(lover_info.aoi_ids, character.aoi_obj.obj_id)
		end	

		-- 随机添加一个任务
		self:acceptTask(aoi_scene, character, nil, true, team.member_num)


	else
		self:sendFinTaskNumUpdate(lover_info)
	end

	-- 广播数据
	self:sendNpcInfo(lover_info, character.gpid)
	self:sendTaskInfo(lover_info, lover_info.gpids)

	lover_info.is_send_small_map = nil

	LoverTempleService:updateIsLover( aoi_scene, lover_info )
end

function LoverTempleService:updateIsLover( aoi_scene, lover_info )
	local gcid_2_jiesuan = lover_info.gcid_2_jiesuan
	local chs = {}
	for gcid, _ in pairs(lover_info.gcid_hash) do
		local character = CharacterService:getCharacterByGcid(gcid)
		table.insert(chs, character)
	end

	-- 更新是否是情侣
	local is_lover = nil
	if #chs == 2 then 
		is_lover = chs[1].area_id == chs[2].area_id and chs[1].lover_cid == chs[2].id
	end
	lover_info.is_lover = is_lover
end

-- 离开场景时
function LoverTempleService:afterLeaveScene(character, aoi_scene, leave_type)
	-- 清空自己接到的任务
	local lover_temple = aoi_scene.lover_temple
	local lover_info = assert(lover_temple.gcid_2_lover_info[character.gcid])
	lover_temple.gcid_2_lover_info[character.gcid] = nil

	-- 发奖
	if next(lover_info.gcid_2_jiesuan[character.gcid]) then
		local ch_jiesuan = lover_info.gcid_2_jiesuan[character.gcid]
		local data = {}
		data.reward_num = ch_jiesuan.reward_num
		data.equips= ch_jiesuan.equips
		data.fin_task_num = ch_jiesuan.fin_task_num

		if next(data.equips) then
			RewardService:reward(Statics.PK_GAME_TYPE_ID_LOVER_TEMPLE, nil, character.gpid, character.gcid, data)		
		end
	end

	local ch_aoi_id = lover_info.gcid_hash[character.gcid]
	lover_info.gcid_hash[character.gcid] = nil
	lover_info.gcid_2_jiesuan[character.gcid] = nil
	for _, gpid in pairs(lover_info.gpids) do
		if gpid == character.gpid then 
			table.remove(lover_info.gpids, _)
			break
		end
	end
	for _, aoi_id in pairs(lover_info.aoi_ids) do
		if aoi_id == ch_aoi_id then 
			table.remove(lover_info.aoi_ids, _)
			break
		end
	end	

	if not next(lover_info.gcid_hash) then 
		lover_temple.team_id_2_lover_info[lover_info.team_id] = nil
	else
		-- 同队伍其他任务参与者数据更新
		self:sendTaskInfo(lover_info, lover_info.gpids)

		-- 告诉队伍我离开了
		WorldPacket:m2cSendCommOkMsg(OKMsgCodes.LOVER_TEMPLE_LOVER_LEAVE, nil, lover_info.gpids)
	end

	LoverTempleService:updateIsLover( aoi_scene, lover_info )
end
	
function LoverTempleService:getLoverInfoByGcid( aoi_scene, gcid )
	return aoi_scene.lover_temple.gcid_2_lover_info[gcid]
end

do	-- 发送NPC信息
	local rsp_opcode = opCodes.PKM2C_LOVE_TEMPLE_NPC_INFO
	local msg_name = "PackLoverTemple.PKM2C_LOVE_TEMPLE_NPC_INFO"
	function LoverTempleService:sendNpcInfo(lover_info, gpids)
--		Logger:info('【 LoverTempleService:sendNpcInfo】', lover_info.task_npcs)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, lover_info, nil, gpids)
	end
end

do	-- 发送任务信息
	local rsp_opcode = opCodes.PKM2C_LOVE_TEMPLE_TASK_INFO
	local msg_name = "PackLoverTemple.PKM2C_LOVE_TEMPLE_TASK_INFO"
	function LoverTempleService:sendTaskInfo(lover_info, gpids)
--		Logger:info('【 LoverTempleService:sendTaskInfo', lover_info.tasks)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, lover_info, nil, gpids)
	end
end

do	-- 发送任务完成
	local rsp_opcode = opCodes.PKM2C_LOVE_TEMPLE_FINISH
	local msg_name = "PackLoverTemple.PKM2C_LOVE_TEMPLE_FINISH"
	local data = {}
	function LoverTempleService:sendTaskFinish(ch_task, gpids)
		data.task = ch_task
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end
end

do	-- 发送时间结束
	local rsp_opcode = opCodes.PKM2C_LOVE_TEMPLE_TIME_OUT
	local msg_name = "PackLoverTemple.PKM2C_LOVE_TEMPLE_TIME_OUT"
	function LoverTempleService:sendTimeOut(lover_info)
--		Logger:info(lover_info.gcid_2_jiesuan)
		for gcid, data in pairs(lover_info.gcid_2_jiesuan) do
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, data.gpid)
		end
	end
end

do	-- 发送已完成任务数量更新
	local rsp_opcode = opCodes.PKM2C_LOVER_TEMPLE_FIN_TASK_UPDATE
	local msg_name = "PackLoverTemple.PKM2C_LOVER_TEMPLE_FIN_TASK_UPDATE"
	function LoverTempleService:sendFinTaskNumUpdate(lover_info)
		for gcid, data in pairs(lover_info.gcid_2_jiesuan) do
			WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, data.gpid)
		end
	end
end