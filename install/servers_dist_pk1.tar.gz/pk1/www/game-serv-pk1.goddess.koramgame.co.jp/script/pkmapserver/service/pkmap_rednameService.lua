--[[
红名系统 SERVICE
author : xingzeng.jiang
date : 2014-10-16
--]]

RednameService = RednameService or {}

local WorldPacket = WorldPacket
local Time = Time
local random = math.random
local os_time = os.time
local ceil = math.ceil
local table = table
local next = next
local pairs = pairs
local RedNameDefs = RedNameDefs
local aoi_type_player = AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER
local upv_empty_tbl = {}

local BufferService, BufferBaseService, GameObjectService, SafeModeService
function RednameService:onAfterLoadLua()
	BufferService = _G.BufferService
	BufferBaseService = _G.BufferBaseService
	GameObjectService = _G.GameObjectService
	SafeModeService = _G.SafeModeService
end

-- 是否在红名中
function RednameService:isReadname(character)
	return character.safe_mode_info.redname >= 3
end

-- 获取红名状态
function RednameService:getRednameStatus(redname)
	local status = RedNameDefs.RED_NAME_STATUS_NORMAL
	
	if redname >= 3 and redname <= 10 then
		status = RedNameDefs.RED_NAME_STATUS_LIGHT
	elseif redname >= 11 and redname <= 20 then
		status = RedNameDefs.RED_NAME_STATUS_MIDDLE
	elseif redname >= 21 then
		status = RedNameDefs.RED_NAME_STATUS_SERIOUS
	end
	
	return status
end

-- 响应PK完成
function RednameService:onPlayerKilled(fighter, arr_kill_player_aoi_id)
	local aoi_scene = GameObjectService:getAoiScene(fighter)
	local character
	local parent_aoi_id = fighter.parent_aoi_id
	if fighter.aoi_type == aoi_type_player then
		character = fighter
	elseif parent_aoi_id and parent_aoi_id > 0 then
		character = GameObjectService:getGameObjectByAoiId(aoi_scene, parent_aoi_id)
	else
		return
	end
	
	local safe_mode_info = character.safe_mode_info
	
	local old_redname = safe_mode_info.redname or 0
	local add_redname = 0
	--local is_pk_mode = (safe_mode_info.safe_mode == SafeModeDefs.SAFE_MODE_PK or safe_mode_info.safe_mode == SafeModeDefs.SAFE_MODE_FREE_PK) and true or false
	local kill_player_num = 0
	local DEFAULT_ZHENYING_SHOU = Statics.DEFAULT_ZHENYING_SHOU
	local DEFAULT_ZHENYING_GONG = Statics.DEFAULT_ZHENYING_GONG
	
	for _, aoi_id in pairs(arr_kill_player_aoi_id) do
		local game_obj = GameObjectService:getGameObjectByAoiId(aoi_scene, aoi_id)
		if game_obj.aoi_type == aoi_type_player then
			-- 劫镖、运镖模式下不影响红名、安全模式
			local zhenying = game_obj.tmps.zhenying
			if zhenying ~= DEFAULT_ZHENYING_SHOU and zhenying ~= DEFAULT_ZHENYING_GONG then
				-- 红名首次死亡
				if self:isReadname(game_obj) and game_obj.safe_mode_info.is_rn_dead == 0 then
					self:rednameDeadToGameServ(game_obj)
				end
				
				-- 杀死安全模式的玩家
				if game_obj.safe_mode_info.safe_mode == SafeModeDefs.SAFE_MODE_SPACE then
					add_redname = add_redname + 1
				end
			end
			
			kill_player_num = kill_player_num + 1
		end
	end
	
	-- 增加红名点
	if add_redname > 0 then
		self:addRednameToGameServ(character, add_redname)
	end
	
	-- 通知游戏服增加杀人数
	if kill_player_num > 0 then
		self:addKillPlayerNumToGameServ(character, kill_player_num)
	end
end

-- 通知游戏服MAP添加红名点
function RednameService:addRednameToGameServ(character, add_redname)
	local opcode = opCodes.PKM2M_SAFE_MODE_REDNAME_ADD
	local pack_data = {add_redname = add_redname}
	WorldPacket:pkServer2GameSendPack(opcode, character.gpid, pack_data, nil)
end

-- 通知游戏服MAP玩家已红名死亡
function RednameService:rednameDeadToGameServ(character)
	local opcode = opCodes.PKM2M_SAFE_MODE_REDNAME_DEAD
	local pack_data = {}
	WorldPacket:pkServer2GameSendPack(opcode, character.gpid, pack_data, nil)
end

-- 通知游戏服MAP玩家新增杀人数
function RednameService:addKillPlayerNumToGameServ(character, kill_player_num)
	local opcode = opCodes.PKM2M_SAFE_MODE_KILL_PLAYERNUM
	local pack_data = {kill_player_num=kill_player_num}
	WorldPacket:pkServer2GameSendPack(opcode, character.gpid, pack_data, nil)
end

-- 响应进入场景
function RednameService:afterEnterScene(character, aoi_scene)
	local scene_base = aoi_scene.scene_base
	if scene_base.is_local_ai == 1 then
		return
	end
	
	local scene_sort_id = aoi_scene.scene_base.scene_sort_id
	if scene_sort_id ~= SceneDefs.SCENE_SORT_ID_NORMAL_MCITY and
		scene_sort_id ~= SceneDefs.SCENE_SORT_ID_TOLLGATE and
		scene_sort_id ~= SceneDefs.SCENE_SORT_ID_BAOWU_ROB and
		scene_sort_id ~= SceneDefs.SCENE_SORT_ID_ARENA and
		scene_sort_id ~= SceneDefs.SCENE_SORT_ID_SCENARIO and
		scene_sort_id ~= SceneDefs.SCENE_SORT_ID_2V2 and
		scene_sort_id ~= SceneDefs.SCENE_SORT_ID_FINALWAR and
		scene_sort_id ~= SceneDefs.SCENE_SORT_ID_SLAVE then
		RednameService:autoAddBuffer(character)
	end
end

-- 添加红名惩罚BUFFER
function RednameService:autoAddBuffer(character)
	local safe_mode_info = character.safe_mode_info
	
	local status = self:getRednameStatus(safe_mode_info.redname)
	local redname_status2buffer_ids = RedNameDefs.redname_status2buffer_ids
	local del_buffer_ids = {}
	
	-- clear
	for _, buffer_ids in pairs(redname_status2buffer_ids) do
		for _, buffer_id in pairs(buffer_ids) do
			if BufferService:delBuffer(character, buffer_id) then
				del_buffer_ids[buffer_id] = buffer_id
			end
		end
	end
	
	if safe_mode_info.is_rn_dead ~= 1 then
		local arr_del_buffer_ids = table.values(del_buffer_ids)
		BufferService:sendDelBuffers(nil, character, arr_del_buffer_ids)
		return
	end
	
	-- add buffer
	local buffer_ids = redname_status2buffer_ids[status]
	if buffer_ids then
		for _, buffer_id in pairs(buffer_ids) do
			local buffer_base = BufferBaseService:getBufferBaseById(buffer_id)
			BufferService:addTmpBuffer(character, buffer_base)
			del_buffer_ids[buffer_id] = nil
		end
		
		BufferService:sendBuffers(nil, character, buffer_ids)
		local aoi_scene = GameObjectService:getAoiScene(character)
		local gpids = GameObjectService:getFovGPids(character, aoi_scene, character.gpid)
		BufferService:bcBuffers(aoi_scene, character, gpids)
	end
	
	if next(del_buffer_ids) then
		local arr_del_buffer_ids = table.values(del_buffer_ids)
		BufferService:sendDelBuffers(nil, character, arr_del_buffer_ids)
	end
end


