--[[
公告系统service层
author : guoyin.huang
date : 2015-05-08
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local Statics = Statics
local Utils = Utils
local table = table
local Logger = Logger
local WorldPacket = WorldPacket
local isTableEmpty = table.isTableEmpty

NoticeService = NoticeService or {}

-------------------------  发到本服的公告 【BEG】 ------------------------
-- 普通广播（发给某个场景中的所有玩家）
-- @space_id : 场景实例id( character.space_id, aoi_scene.space_id )
-- @msg_id:		普通广播的消息ID(OkMsgCodes.lua中定义)
-- @msg_params:	普通广播的消息参数
function NoticeService:sysMsgScene(space_id, msg_id, msg_params)
	if not space_id or not msg_id then 
		return Logger:error("NoticeService:sysMsgScene params error!")
	end

	local data = self:makeMsg(NoticeDefs.NOTICE_SORT_ID_COMMON, msg_id, msg_params)
	local aoi_scene = AoiSceneService:getAoiScene(space_id)	
	if not aoi_scene then 
		return Logger:error("NoticeService:sysMsgScene space_id error, scene not exist!")
	end
	local gpids = GameObjectService:getGPids(aoi_scene)
	
	self:sendNotice(data, gpids)
end

-- 普通广播（发给一批玩家）
-- @gpids:		玩家列表
-- @msg_id:		普通广播的消息ID(OkMsgCodes.lua中定义)
-- @msg_params:	普通广播的消息参数
function NoticeService:sysMsgScenePlayers(gpids, msg_id, msg_params)
	if not msg_id then 
		return Logger:error("NoticeService:sysMsgScenePlayers params error!")
	end
	-- 生成消息
	local data = self:makeMsg(NoticeDefs.NOTICE_SORT_ID_COMMON, msg_id, msg_params)
	
	-- 发送
	self:sendNotice(data, gpids)	
end

-- 普通广播（发给全服玩家）
-- @msg_id:		普通广播的消息ID(OkMsgCodes.lua中定义)
-- @msg_params:	普通广播的消息参数
function NoticeService:sysMsgWorld(msg_id, msg_params, scene_sort_ids)
	if not msg_id then 
		return Logger:error("NoticeService:sysMsgScene params error!")
	end
	-- 生成消息
	local data = self:makeMsg(NoticeDefs.NOTICE_SORT_ID_COMMON, msg_id, msg_params, scene_sort_ids)
	
	-- 全服发送
	self:sendNotice(data, -1)
end

-- 活动开启类广播
-- @msg_id:		普通广播的消息ID(OkMsgCodes.lua中定义)
-- @msg_params:	普通广播的消息参数
function NoticeService:sysMsgActive(msg_id, msg_params)
	if not msg_id then 
		return Logger:error("NoticeService:sysMsgScene params error!")
	end
	-- 生成消息
	local data = self:makeMsg(NoticeDefs.NOTICE_SORT_ID_ACTIVE, msg_id, msg_params)
	
	-- 全服发送
	self:sendNotice(data, -1)
end

-- 发到聊天框的广播
-- @msg_id:		聊天框的消息ID
-- @msg_params:	聊天框的消息参数
-- @scene_sort_ids:		支持的场景列表(空表或nil则所有场景均支持)
function NoticeService:sysMsgChat(msg_id, msg_params, scene_sort_ids)
	if not msg_id then 
		return Logger:error("NoticeService:sysMsgChat params error!")
	end
	-- 生成消息
	local data = self:makeMsg(NoticeDefs.NOTICE_SORT_ID_CHAT, msg_id, msg_params, scene_sort_ids)
	
	-- 全服发送
	self:sendNotice(data, -1)
end
--------------------------  发到本服的公告 【END】 --------------------------
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
--------------------------  发到游戏服的公告 【BEG】 ------------------------
-- 普通广播（发给某个游戏服的所有玩家）
-- @area_id:	要广播的服务器的大区ID	
-- @msg_id:		普通广播的消息ID(OkMsgCodes.lua中定义)
-- @msg_params:	普通广播的消息参数
-- @scene_sort_ids: 	显示广播的场景类型列表
function NoticeService:sysMsgWorld2GameSrv(area_id, msg_id, msg_params, scene_sort_ids)
	if not msg_id then 
		return Logger:error("NoticeService:sysMsgScene params error!")
	end
	-- 生成消息
	local data = self:makeMsg(NoticeDefs.NOTICE_SORT_ID_COMMON, msg_id, msg_params, scene_sort_ids)
	local gpid = external.mergeUInt(area_id, 0)
	WorldPacket:pkServer2GameSendPack(opCodes.PKB2B_NOTICE_NOTICE, gpid, data )
end

-- 发到聊天框的广播（发给某个游戏服的所有玩家）
-- @area_id:	要广播的服务器的大区ID	
-- @msg_id:		聊天框的消息ID
-- @msg_params:	聊天框的消息参数
-- @scene_sort_ids:		支持的场景列表(空表或nil则所有场景均支持)
function NoticeService:sysMsgChat2GameSrv(area_id, msg_id, msg_params, scene_sort_ids)
	if not msg_id then 
		return Logger:error("NoticeService:sysMsgChat params error!")
	end
	-- 生成消息
	local data = self:makeMsg(NoticeDefs.NOTICE_SORT_ID_CHAT, msg_id, msg_params, scene_sort_ids)
	local gpid = external.mergeUInt(area_id, 0)
	WorldPacket:pkServer2GameSendPack(opCodes.PKB2B_NOTICE_NOTICE, gpid, data )
end

-- 普通广播,通过游戏服转发给所有玩家
function NoticeService:sysMsgWorld2AllSrv(msg_id, msg_params, scene_sort_ids)
	if not msg_id then 
		return Logger:error("NoticeService:sysMsgScene params error!")
	end
	-- 生成消息
	local data = self:makeMsg(NoticeDefs.NOTICE_SORT_ID_COMMON, msg_id, msg_params, scene_sort_ids)
	
	ServerCall:m2bCall('NoticeService:m2b_sysMsgWorld2AllSrv', 0, data)
end


-- 通用聊天框广播接口，noticedefid,sender可以为空默认发到聊天框的世界频道
-- noticedefid的定义从NoticeDefs中取，只对 100以上定义有效，表示任意频道发送
-- 
-- noticedefid,sender都有值时表示以自己的身份往聊天noticedefid频道发送消息 
-- 其假设条件：
-- 1.msg_id对应的消息定义一定要大于等于一个参数
-- 2.sender为数组，元素个数为8，且对照CHAT_PERSON保持顺序不能错乱
--
function NoticeService:sysMsgChatComm(gpids, msg_id, msg_params,noticedefid,sortids,sender)
    noticedefid = noticedefid or NoticeDefs.NOTICE_SORT_ID_COMMON
    local data = self:makeMsg2(noticedefid, msg_id, msg_params, sortids,sender)    
    if gpids~=-1 and isTableEmpty(gpids) then return end
    self:sendNotice(data, gpids)
end

------------------------  发到游戏服的公告 【END】 --------------------------
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
--------------------------- 统一接口 【BEG】 --------------------------------
do
	local data = {}
	function NoticeService:makeMsg( sort_id, msg_id, msg_params, scene_sort_ids)
		data.msg_id = msg_id
		data.msg_params = {}
		data.sort_id = sort_id
		data.scene_sort_ids = scene_sort_ids
		if msg_params then 
			local params = data.msg_params
			for _, param in ipairs(msg_params) do
				table.insert(params, '' .. param)
			end
		end
		return data
	end
end

do
    local data = {}
    function NoticeService:makeMsg2( sort_id, msg_id, msg_params, scene_sort_ids,sender)
        data.msg_id = msg_id
        data.msg_params = {}
        data.sort_id = sort_id
        data.scene_sort_ids = scene_sort_ids
        if msg_params then 
            local params = data.msg_params
            for _, param in ipairs(msg_params) do
                table.insert(params, '' .. param)
            end
            local appendstr = "|"
            if sender then
              for k,v in pairs(sender) do
                  appendstr = appendstr.. v  .. "|" 
              end
              if #params>0 then
                params[#params]=params[#params]..appendstr
              else
                params[1]=appendstr 
              end  
            end
        end
        return data
    end
end

do -- 发送广播消息
	local rsp_opcode = opCodes.B2C_NOTICE_NOTICE
	local msg_name = "PackNotice.B2C_NOTICE_NOTICE"
	function NoticeService:sendNotice(data, gpids)
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end
end
--------------------------- 统一接口 【END】 ------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
----------------------------- 杀人广播 【BEG】-----------------------------------
function NoticeService:KillNoticeScene(aoi_scene, sort_id, count, killer_camp, killer, killed, killer_gcid)
	local gpids = GameObjectService:getGPids(aoi_scene)
	self:sendKillNotice(gpids, sort_id, count, killer_camp, killer, killed, killer_gcid)
end

do	-- 发送杀人广播 
	local rsp_opcode = opCodes.B2C_NOTICE_KILL_NOTICE
	local msg_name = "PackNotice.B2C_NOTICE_KILL_NOTICE"
	local data = {}
	function NoticeService:sendKillNotice(gpids, sort_id, count, killer_camp, killer, killed, killer_gcid)
		data.sort_id = sort_id
		data.count = count
		data.killer_camp = killer_camp
		data.killer = killer
		data.killed = killed
		data.killer_gcid = killer_gcid
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, data, nil, gpids)
	end
end

--发广播到当前场景，主城
--发消息到附近，世界
function NoticeService:noticeSceneZhucenChat(aoi_scene,area_id,msg_id,msg_params,msg_params2,FilterPiaoZi)
    if not FilterPiaoZi then
        --当前场景广播
        NoticeService:sysMsgScene(aoi_scene.space_id, msg_id, msg_params)
        --目标主城广播
        NoticeService:sysMsgWorld2GameSrv(area_id, msg_id, msg_params,{SceneDefs.SCENE_SORT_ID_NORMAL_MCITY} )
    end    
    
    local realmsg = msg_params2 or msg_params
    
    NoticeService:sysMsgChat2GameSrv(area_id, msg_id, realmsg,{SceneDefs.SCENE_SORT_ID_NORMAL_MCITY})
    
    --Logger:error("msg_params2::",msg_params2)
    --附近场景的聊天
    local data = self:makeMsg2(NoticeDefs.CHAT_TYPE_SCENE, msg_id, realmsg)    
    local gpids = GameObjectService:getGPids(aoi_scene)
    self:sendNotice(data, gpids)    
end

--发消息到军团频道
function NoticeService:noticeGangChat(aoi_scene,area_id,msg_id,msg_params,gang_id)
    local data = self:makeMsg2(NoticeDefs.CHAT_TYPE_GANG, msg_id, msg_params)   
    data.gang_id = gang_id
    local gpid = external.mergeUInt(area_id, 0)
    WorldPacket:pkServer2GameSendPack(opCodes.PKB2B_NOTICE_NOTICE, gpid, data )
end



----------------------------- 杀人广播 【END】-----------------------------------