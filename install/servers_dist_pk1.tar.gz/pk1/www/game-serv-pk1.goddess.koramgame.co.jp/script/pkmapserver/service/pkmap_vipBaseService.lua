--[[
侠客成长(历练)的基础数据
author : xingzeng
date : 2012-03-27
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local table = table
local tableInsert = table.insert

VipBaseService = VipBaseService or {}

-- 根据id获取侠客历练基础数据
-- vip_id : 道具_id
-- return obj / nil
function VipBaseService:getVipBaseByLev(vip_lev)
	local vip_base = VipBaseDao.data[vip_lev]
	return vip_base
end

function VipBaseService:getVipBaseData()
	return  VipBaseDao.data
end

function VipBaseService:getVipFuncBase(vip_lev, vip_func_id)
	local vip_base = VipBaseService:getVipBaseByLev(vip_lev)
	if not vip_base then return end
	local funcs = vip_base.funcs
	local vip_func_base = funcs[vip_func_id]
	return vip_func_base
end