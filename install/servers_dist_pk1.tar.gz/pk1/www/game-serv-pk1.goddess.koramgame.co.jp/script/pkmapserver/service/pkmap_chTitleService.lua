--[[
角色称号系统Service，用于相关逻辑处理
author : suwin zhong
date : 2012-12-15
--]]

local opCodes = opCodes
local errorCodes = errorCodes
local tableInsert = table.insert
local tableSlice = table.tableSlice

ChTitleService = ChTitleService or {}

-- upvalue
local arr_rsp_bc_update_character_title = {} -- 广播给玩家更新角色称号
local arr_update_character_title_to_base = {} -- 让base帮忙派发称号
local arr_rsp_get_character_title_list = {} -- 获取角色所有称号


-- 初始化角色称号
function ChTitleService:init(character)
	local titles = character.titles
	if(type(titles) == "string" and string.len(titles) > 1) then
		character.titles = WorldPacket:decodeData(titles)
	else
		character.titles = {}
	end
	
	-- 将称号数据清理干净
	local is_calCharacterAttrib = false -- 这里不能重算角色属性，因为角色还未被初始化完
--	self:cleanMyTitle(character, is_calCharacterAttrib)

end


-- 打包角色称号数据
function ChTitleService:pack(character)
	return WorldPacket:encodeData(character.titles)
end



-- 获取角色身上的一个称号
-- character : 角色
-- title_id : 称号id
function ChTitleService:getMyTitleById(character, title_id)
	-- 先确保身上的称号属性干净
	local is_calCharacterAttrib = true
--	self:cleanMyTitle(character, is_calCharacterAttrib)

	return character.titles[title_id]
end


-- 获取角色称号所有称号串
-- character : 角色
-- return : string 返回角色称号列表串
function ChTitleService:getAllMyTitle(character)
	-- 先确保身上的称号属性干净
	local is_calCharacterAttrib = true
--	self:cleanMyTitle(character, is_calCharacterAttrib)

	local arr_title_detail = {}
	local title_detail
	local titles = character.titles
	for title_id, character_title_base in pairs(titles) do
		title_detail = self:getTitleDetail(character_title_base)
		tableInsert(arr_title_detail, title_detail)
	end

	return arr_title_detail
end


-- 获取角色显示着的称号列表
-- character : 角色
-- return : table
function ChTitleService:getMyShowTitle(character)
	-- 先确保身上的称号属性干净
	local is_calCharacterAttrib = true
--	self:cleanMyTitle(character, is_calCharacterAttrib)

	local arr_title_detail = {}
	local title_detail
	local titles = character.titles.list
	local title_is_show = TitleDefs.TITLE_IS_SHOW
	for title_id, character_title_base in pairs(titles) do
		if title_is_show == character_title_base.is_show then
			title_detail = self:getTitleDetail(character_title_base)
			tableInsert(arr_title_detail, title_detail)
		end
	end

	return arr_title_detail
end


-- 获取角色显示着的称号(用于给周围的人看)
-- character : 角色
-- return : string 返回角色称号列表串
function ChTitleService:getMyShowTitleStr(character)
	-- 缓存称号系统
	local title_cache = character.tmps.cache_show_titles
	if not title_cache then
		title_cache = self:getMyShowTitle(character)
		-- 缓存到角色身上
		character.tmps.cache_show_titles = title_cache
	end
	return title_cache[1] and title_cache[1].id or 0
end


-- 获取详细的角色称号实体(用于客户端显示)
-- character_title_base : 称号基础信息
function ChTitleService:getTitleDetail(character_title_base)
	-- 获取称号基础信息
	local detail_title = {}
	detail_title['id'] = character_title_base.id			 -- 称号id
	detail_title['expire']  = character_title_base.expire  -- 称号过期时间
	detail_title['is_show'] = character_title_base.is_show -- 是否显示

	return detail_title
end


-- 更新某个称号的显示状态
-- character : 角色
-- title_id : 称号id
-- show_id : 显示 / 隐藏
-- return true
function ChTitleService:updateTitleShow(character, title_id, show_id)
	character.titles[title_id].is_show = show_id
	self:cleanMyShowTitleCache(character)
	return true
end


-- 获取称号的附加属性
-- character : 角色
function ChTitleService:getChEffectValues(character)
	local arr_show_title = ChTitleService:getMyShowTitle(character)

	local arr_effect_value = {}
	local arr_this_effect
	for _, title_detail in pairs(arr_show_title) do
		arr_this_effect = title_detail.ext_attrib
		if arr_this_effect then
			local now_value
			for key, value in pairs(arr_this_effect) do
				now_value = arr_effect_value[key] or 0
				arr_effect_value[key] = now_value + value
			end
		end
	end

	return arr_effect_value
end

-- 更新角色外观
function ChTitleService:onTitleChanged( character )
	-- 设置脏
	GameObjectService:appearDirty(character)

	-- 广播给视野内其他玩家
	local title_id = self:getMyShowTitleStr(character)
	local aoi_scene = GameObjectService:getAoiScene(character)
	local appear_data_update = {}
	appear_data_update.title_id = title_id

	SceneService:sendAppearDetailUpdate(aoi_scene, character, appear_data_update)	
end

-- 替角色添加一个称号(对外接口)
-- character_id : 角色id
-- title_id : 称号id(看defs/TitleDefs.lua中的定义)
-- return : true
function ChTitleService:assignTitle(character_id, title_id)
	-- 判断角色是否还在这个map上
	local character = CharacterService:getCharacterById(character_id)
	if character then -- 角色在当前map server上
		self:addTitle2Character(character, title_id)
	else
		self:sendPackToBaseForAssignTitle(character_id, title_id)
	end
end


-- 清空显示的称号缓存
-- character : 角色对象
function ChTitleService:cleanMyShowTitleCache(character)
	character.tmps.cache_show_titles = nil
end


-- 角色已经不在当前mapserver的时候，转发到base，让base帮忙派发
-- character_id : 角色id
-- title_id : 称号id
function ChTitleService:sendPackToBaseForAssignTitle(character_id, title_id)
	-- 获取称号基本信息
	local title_base = TitleBaseService:getTitleBaseById(title_id)

	if title_base then
		-- 组包
		arr_update_character_title_to_base.opcode = opCodes.M2B_TITLE_TO_BASE_FOR_ASSIGN
		arr_update_character_title_to_base.character_id = character_id
		arr_update_character_title_to_base.title_id = title_id
		
		WorldPacket:m2bSendPack(arr_update_character_title_to_base, g_packet_id, character_id)
	else
		print("找不到该称号信息，称号id是：", title_id)
	end
end



-- 获取角色显示的称号的经验加成值
-- character : 角色
-- return true
function ChTitleService:getTitleExpPercent(character)
	local exp_percent = 0 -- 额外加成0

	-- 获取显示的称号的加成
	local arr_title_effect = ChTitleService:getChEffectValues(character)
	exp_percent = arr_title_effect['exp_perc'] or 0

	return exp_percent
end