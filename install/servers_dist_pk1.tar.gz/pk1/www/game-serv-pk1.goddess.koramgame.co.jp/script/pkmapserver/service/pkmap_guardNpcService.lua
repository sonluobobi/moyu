--[[
守护NPC系统 service
author : shuyi.zhong
date : 2015-04-09
--]]

GuardNpcService = GuardNpcService or {}

local WorldPacket = WorldPacket
local Statics = Statics
local Time = Time
local random = math.random
local ceil = math.ceil
local table = table
local tableInsert = table.insert
local ext_getNowUnixMsTime = external.getNowUnixMsTime
local DEFAULT_ZHENYING_GUARD_NPC = Statics.DEFAULT_ZHENYING_GUARD_NPC

local PROFILE_BIN_PKG_TAG_NEEDED = OptimizeSetting.PROFILE_BIN_PKG_TAG_NEEDED

local GameObjectService
function GuardNpcService:onAfterLoadLua()
	GameObjectService = _G.GameObjectService
end


do
	local writeUInt = FastPacket.writeUInt
	local writeByte = FastPacket.writeByte
	local writeShort = FastPacket.writeShort	
	local writeLong = FastPacket.writeLong
	local writeString = FastPacket.writeString
	local writeUShort = FastPacket.writeUShort
	local math_floor = math.floor
	
	-- 写入基础外观
	function GuardNpcService:writeObjAppear(guardNpc, fast_packet)
		writeByte(fast_packet, math_floor((guardNpc.speed or 0) * 10))
		writeLong(fast_packet, guardNpc.hp)
		writeUInt(fast_packet, guardNpc.guard_npc_base.id) -- base_id
		writeUInt(fast_packet, 0)						   -- parent_aoi_id
	end
	
	-- 写入详细外观
	function GuardNpcService:writeObjAppearDetail(guardNpc, fast_packet)
		if PROFILE_BIN_PKG_TAG_NEEDED then writeByte(fast_packet, 0x11) end

		writeLong(fast_packet, guardNpc.max_hp)

		if PROFILE_BIN_PKG_TAG_NEEDED then writeByte(fast_packet, 0x88) end
	end
end


do
	-- 创建一个新的守护NPC，并添加到场景实例中去，广播给客户端
	-- aoiScene : 场景实例id
	-- guard_npc_id : 守护npc_id
	-- x : 创建陷阱的x坐标
	-- y : 创建陷阱的y坐标
	local AoiObject_new = AoiObject.new
	function GuardNpcService:createGuardNpc(aoiScene, guard_npc_id, x, y)
		local guard_npc_base = assert(GuardNpcBaseDao[guard_npc_id], guard_npc_id)

		local guardNpc = self:newGuardNpc(guard_npc_base)

		local aoi_obj = AoiObject_new(AoiObject, AoiObjectType.AOI_OBJECT_TYPE_ID_GUARD_NPC, x, y, 0, guardNpc, aoiScene)
		GameObjectService:addObj(guardNpc, aoi_obj, aoiScene)
	
		return guardNpc
	end


	-- new一个守护NPC实体
	-- guard_npc_base : 守护npc的基本信息
	function GuardNpcService:newGuardNpc(guard_npc_base)
		local guardNpc = {}

		guardNpc.nick = guard_npc_base.title -- 规范命名
		guardNpc.speed = guard_npc_base.speed or 0 -- 速度
		guardNpc.hp = guard_npc_base.max_hp
		guardNpc.max_hp = guard_npc_base.max_hp
		
		local my_zhenying = DEFAULT_ZHENYING_GUARD_NPC -- 所在阵营
		guardNpc.tmps = GuardNpc:createTmps(my_zhenying)

		guardNpc.guard_npc_base = guard_npc_base
		guardNpc.model_times = guard_npc_base.model_times or 1
		guardNpc.body_size = guard_npc_base.body_size or 0

		return guardNpc
	end
end


do
	-- 守护NPC每帧更新入口
	function GuardNpcService:update(time_now, aoiScene, arr_guard_npc)
	end
end