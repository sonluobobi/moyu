--[[
排行榜service
author : xingzeng jiang
date : 2012-05-23
--]]
local ostime = os.time
local osdate = os.date
local Time = Time
local math_floor = math.floor
local tonumber = tonumber

ToplistService = ToplistService or {}
local ToplistService = ToplistService
local ToplistDao = ToplistDao
local ToplistRewardDao = ToplistRewardDao
local ToplistDefs = ToplistDefs
local Config = Config


function ToplistService:b2m_sendToplist( _, data )
	local unique_key = data.unique_key
	local gpid = data.gpid
	local sort_id = data.sort_id
	local start_rank = data.start_rank or 1
	local num = data.num or 100
	local next_up_time = os.time() + 1
	local toplist,my_rank, total_num
	if sort_id == ToplistDefs.TOPLIST_SORT_ID_ZHUSHEN_HUANGHUN then 
		toplist, my_rank, total_num = GlobalArenaService:getToplist( unique_key, start_rank, num, gpid )
	else
		assert(false)
	end
	ToplistService:sendToplist(gpid, sort_id, start_rank, num, toplist, my_rank, nil, next_up_time, total_num)
end

do
	local rsp_opcode = opCodes.B2C_TOPLIST_GET
	local msg_name = "PackToplist.B2C_TOPLIST_GET"
	local msg_proto = {}
	function ToplistService:sendToplist(gpid, sort_id, start_rank, num, toplist, my_rank, my_fc_up_perc, next_up_time, total_num)
		msg_proto.sort_id = sort_id
		msg_proto.start_rank = start_rank
		msg_proto.num = num
		msg_proto.my_rank = my_rank or 0
		msg_proto.toplist = toplist
		msg_proto.my_fc_up_perc = my_fc_up_perc
		msg_proto.next_up_time = next_up_time
		msg_proto.total_num = total_num
		
		WorldPacket:m2cSendOKProtoBuf(rsp_opcode, msg_name, msg_proto, nil, gpid)
	end
end
