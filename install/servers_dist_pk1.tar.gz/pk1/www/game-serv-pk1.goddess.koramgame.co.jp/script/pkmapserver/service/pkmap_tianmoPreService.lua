--[[
天魔灭心系统service
author : xingzeng
date : 2015-05-06
]]--

local external = external
local opHandler = opHandler
local opCodes = opCodes
local packet = packet
local tableInsert = table.insert
local random = math.random
local TianmoDefs = TianmoDefs
local TianmoConfig = TianmoConfig
local AoiObjectType = AoiObjectType
local table = table
local tableSort = table.sort
local Statics = Statics
local TianmosDao = TianmosDao
local OKMsgCodes = OKMsgCodes

TianmoPreService = TianmoPreService or {}
setmetatable(TianmoPreService, SceneServiceInterface)

local TianmoPreService = TianmoPreService

local SceneService, GameObjectService, TianmoService

function TianmoPreService:onAfterLoadLua()
	SceneService = _G.SceneService
	GameObjectService = _G.GameObjectService
	TianmoService = _G.TianmoService
end

function TianmoPreService:update(time_now, aoi_scene)
	local group_id = aoi_scene.tianmo_group_id
	local boss_room_ins = TianmoService:getBossRoom(group_id)
	
	-- 将所有玩家从PK服中剔出
	if not aoi_scene.tianmo_is_kickout and TianmoService:isEnd(150, group_id) then
		local chs = GameObjectService:getPlayerGameObjs(aoi_scene)
		for _, character in pairs(chs) do	
			ServerCall:m2bCall('SceneService:logoutWanfa', character.gcid, nil)
		end
		aoi_scene.tianmo_is_kickout = true
	end
	
	if not boss_room_ins then
		return
	end
	
	-- 检查如果已结束，就广播给玩家玩法已结束
	TianmoService:bcTianmoEnd(aoi_scene, group_id)
end


function TianmoPreService:afterEnterScene(character, aoi_scene, prev_scene_id, is_reconnect, is_login)
	local group_id = TianmoService:getGroupId(character)
	aoi_scene.tianmo_group_id = group_id
end
