--[[
框架入口 c++调用入口函数
--]]

local c_opHandlers = c_opHandlers._handlers

local opcodeNames = opcodeNames
local Time = Time
local SceneCtrl = SceneCtrl
local WorldPacket = WorldPacket
local ServerCall = ServerCall

local getNowUnixUsTime = external.getNowUnixUsTime

g_is_world_inited = g_is_world_inited or false
	
	
--加载脚本完成后（包括reload)
do
	-- 响应LUA脚本加载或热更新完成
	local string_find, string_len = string.find, string.len
	function c_after_load()
		local ReadOnly = ReadOnly
		local gmt = getmetatable(_G)
		
		-- 调用所有service  ctrl 的 onAfterLoadLua(响应LUA脚本加载或热更新完成) 函数
		for cls_name, cls_obj in pairs(_G) do
			if type(cls_obj) == 'table' and cls_obj ~= _G and cls_obj ~= gmt then
				local mt = getmetatable(cls_obj)
				if mt ~= ReadOnly and type(cls_obj.onAfterLoadLua) == 'function' and
					(string_find(cls_name, 'Ctrl') == string_len(cls_name) - 3 or
						string_find(cls_name, 'Service') == string_len(cls_name) - 6)
					then
					cls_obj:onAfterLoadLua()
				end
			end
		end
	end
end

-- 启动初始化
function c_initWorld()	
	local area_id = external.getAid()
	if area_id<970 then print = function()end end
	

	g_is_world_inited = true
	
	return 12345
end



function c_clientIndex(aid,pid, packet)
end

function c_pkg_handler(gpid, packet)
	local opcode = packet:getOpcode()
	local handler = c_opHandlers[opcode]
	if not handler then
		local opcode_name = opcodeNames[opcode] or 'unknown'
		Logger:error('chatserver no found the function for opcode=',opcode,'opcode_name=',opcode_name)
	else
		--WorldPacket.g_character = character
		WorldPacket.g_opcode = opcode
		WorldPacket.g_packet_id = packet:getPacketId()
		
		handler(gpid,packet)
		
		--WorldPacket.g_character = 0
		WorldPacket.g_opcode = 0
		WorldPacket.g_packet_id = 0
	end
	
	return 0;
end




-- 服务器退出

function c_shutdownWorld()

end


function c_connect_handler(aid,pid)
end


function c_update(time_now)
end

-- 断线
function c_disconnect_handler(aid,pid,packet_id)
	WorldPacket.g_packet_id = packet_id
	WorldPacket.g_aid = aid
	WorldPacket.g_pid = pid
		
	--
	
	WorldPacket.g_packet_id = 0
	WorldPacket.g_aid = 0
	WorldPacket.g_pid = 0
end