--[[
语音聊天ctrl
author : biquan.xu
date : 2015-8-15
]]--

local c_opHandlers = c_opHandlers._handlers
local i_opHandlers = i_opHandlers._handlers

local opCodes = opCodes
local Time    = Time
local WorldPacket = WorldPacket
local tableInsert = table.insert
local table       = table
local ChatDefs  = ChatDefs

local externalMergeUInt = external.mergeUInt
local externalSplitUInt = external.splitUInt

local writeBlobToFile=external.writeBlobToFile
local readBlobFromFile=external.readBlobFromFile

ChatCtrl = ChatCtrl or {}

g_voiceDataIdx= g_voiceDataIdx or 0

local g_voice_data_dir=external.getConfigString('voiceDataDir')

function getVoiceDataDir(vrt)
	if vrt==VoiceRecordType.VOICE_RECORD_FLOWER_COMPETE then
	   return g_voice_data_dir.."../voiceFlower/"
	end
    --if not vrt or (vrt==VoiceRecordType.VOICE_RECORD_CHAT) then
		if g_voice_data_dir=="" then
		  error("voiceDataDir can't be empty.check  conf/common.lua please.")
		end
       return g_voice_data_dir
    --end
	
	--error("invalid vrt:"..vrt)
end

function getVoiceId(vrt,aid,cid,seq,seconds)
    local vdd=getVoiceDataDir(vrt)
    if not vdd then
       return 
    end
    ---语音聊天的voice_xxx 非语音聊天voicexxx_yyy 客户端包括服务端会自动清理语音聊天的语音，不会清理非语音聊天的语音
    if vrt==VoiceRecordType.VOICE_RECORD_FLOWER_COMPETE then
	   return string.format("voiceflower_%d_%d_%d",aid,cid,seconds) 
	end
    --if not vrt or (vrt==VoiceRecordType.VOICE_RECORD_CHAT) then
		local dt=external.getUnixTime()
		return string.format("voice_%d_%d_%d_%d_%d_%d",aid,cid,dt,seq, g_voiceDataIdx,seconds) 
    --end
	
end

--语音数据保存   语音文件名格式 参见.proto
do	
	local msg_nameV2C_VOICE_CHAT_DATA = 'PackVoiceChat.V2C_VOICE_CHAT_DATA'
	local msg_nameC2V_VOICE_CHAT_DATA = 'PackVoiceChat.C2V_VOICE_CHAT_DATA'
	
	function ChatCtrl.c2v_voiceChatData(gpid, packet)
		g_voiceDataIdx=g_voiceDataIdx+1
				
		local arr_params = packet:readParams(msg_nameC2V_VOICE_CHAT_DATA)
		
		local aid,cid = externalSplitUInt(arr_params.gcid)
		local voice_id=getVoiceId(arr_params.vrt,aid,cid,arr_params.seq,arr_params.seconds)
		local voice_data_dir=getVoiceDataDir(arr_params.vrt)
		
		local voice_data_path=voice_data_dir..voice_id
		
        local bOK=writeBlobToFile(voice_data_path,arr_params.voiceData)
        
        local data={}
        if bOK then
			data.voice_id=voice_id
        end
        
        data.gcid=arr_params.gcid
        data.seq=arr_params.seq
        data.vrt=arr_params.vrt
      	
		WorldPacket:v2cSendOKProtoBuf(opCodes.V2C_VOICE_CHAT_DATA,msg_nameV2C_VOICE_CHAT_DATA, data, packet,gpid)				 
	end
	c_opHandlers[opCodes.C2V_VOICE_CHAT_DATA] = ChatCtrl.c2v_voiceChatData
end

do	
	local msg_nameC2V_GET_VOICE_CHAT_DATA = 'PackVoiceChat.C2V_GET_VOICE_CHAT_DATA'
	local msg_nameV2C_GET_VOICE_CHAT_DATA = 'PackVoiceChat.V2C_GET_VOICE_CHAT_DATA'
	function ChatCtrl.c2v_getVoiceChatData(gpid, packet)
				
		local arr_params = packet:readParams(msg_nameC2V_GET_VOICE_CHAT_DATA)
		local data={}
		data.gcid=arr_params.gcid
		data.voice_id=arr_params.voice_id
		local voice_data_dir=getVoiceDataDir(arr_params.vrt)
		
		local voice_data_path=voice_data_dir..data.voice_id
		local bOk,voiceData=readBlobFromFile(voice_data_path)
		if bOk then
			--print('V2C_GET_VOICE_CHAT_DATA',gpid,string.len(voiceData),data.voice_id)
			--table.dump('V2C_GET_VOICE_CHAT_DATA(negle voicedata):',data,-1)
			
			data.voiceData=voiceData	
			data.vrt=arr_params.vrt
			        
			WorldPacket:v2cSendOKProtoBuf(opCodes.V2C_GET_VOICE_CHAT_DATA,msg_nameV2C_GET_VOICE_CHAT_DATA, data, packet,gpid)	
		else		   
			WorldPacket:v2cSendErr( packet, gpid,errorCodes.VOICE_DATA_FILE_NOT_EXISTED)
			--print('failed to getVoiceData.error:',voiceData)
		end
		
					 
	end
	c_opHandlers[opCodes.C2V_GET_VOICE_CHAT_DATA] = ChatCtrl.c2v_getVoiceChatData
end
