--[[
合服处理ctrl
author : biquan.xu
date : 2016-01-21
]]--

local string_format = string.format
local DatabaseService = DatabaseService
local areaCombine = areaCombine
local areaCombineInfo = areaCombineInfo

local Time = Time
local Utils = Utils 

areaCombineCtrl = areaCombineCtrl or {}
htVouchBornAid2CombineInfo =htVouchBornAid2CombineInfo or {}

-- 查询合服列表
function areaCombineCtrl.b2d_queryAreaCombineInfo(sid, params)	
			
	local areaCombineInfoList = DatabaseService:getDBEntitysEx('tbl_area_combine_real', areaCombineInfo)
	htVouchBornAid2CombineInfo={}
	if areaCombineInfoList then
		for _, areaCombineInfo in pairs(areaCombineInfoList) do
		   htVouchBornAid2CombineInfo[areaCombineInfo.oldaid]=areaCombineInfo.newaid
		end
	end
	
	-- RSP
	ServerCall:d2xCall(sid, 'areaCombineCtrl.d2b_syncAreaCombineInfo', 0, htVouchBornAid2CombineInfo)
end
