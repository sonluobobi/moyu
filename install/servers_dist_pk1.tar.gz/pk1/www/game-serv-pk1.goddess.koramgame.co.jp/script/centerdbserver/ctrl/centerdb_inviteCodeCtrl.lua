--[[
邀请码CTRL
author : xingzeng
date : 2012-05-24
]]--

local string_format = string.format
local DatabaseService = DatabaseService
local InviteCode = InviteCode
local InviteCodeUsed = InviteCodeUsed
local InviteCodeDefs = InviteCodeDefs
local Time = Time
local Utils = Utils 
local InviteCodeConfig = InviteCodeConfig

InviteCodeCtrl = InviteCodeCtrl or {}

-- 同步邀请信息
function InviteCodeCtrl.b2d_syncInviteCodeInfo(sid, params)
	local area_id = params.area_id
	local player_id = params.player_id
	local guid = params.guid
	local nick = params.nick
	local fight_capacity = params.fight_capacity
	local level = params.level
	local cid = params.cid
	local prof = params.prof
	local gender = params.gender
	local vip = params.vip
	
	local pack_data = {area_id=area_id, player_id=player_id}
	
	-- 检查/添加邀请码
	local invite_code_entity = InviteCodeCtrl:_addInviteCode(params)
	local invite_code
	if invite_code_entity then
		invite_code = invite_code_entity.invite_code
		pack_data.invite_code = invite_code
		pack_data.invite_level = invite_code_entity.level
	else
		pack_data.invite_code = nil
		pack_data.invite_level = nil
	end
	
	if invite_code then
		-- 获取被邀请人列表
		local where = string_format('invite_code = "%s" ', invite_code)
		pack_data.arr_invitee = DatabaseService:getDBEntitysEx('tbl_invite_code_used', InviteCodeUsed, where)
	end
	
	-- 获取自己使用邀请码记录
	local where = string_format('invitee_player_id = %d', player_id)
	local invite_code_used = DatabaseService:getDBEntityOne('tbl_invite_code_used', InviteCodeUsed, where)
	
	-- 更新被邀请人的战力等信息
	if invite_code_used and invite_code_used.invitee_guid == guid then
		local where = string_format('invite_code = "%s" and invitee_player_id = %d and invitee_guid = "%s"', invite_code_used.invite_code, player_id, guid)
		local up_params = {updated=Time:getDateTimeStrNow(), invitee_area_id = area_id, invitee_fight_capacity = fight_capacity, 
							invitee_level = level, invitee_nick=nick, invitee_prof=prof, invitee_gender=gender, invitee_vip=vip, invitee_cid=cid}
		DatabaseService:updateEx('tbl_invite_code_used', where, up_params, InviteCodeUsed)
	end
	
	-- RSP
	pack_data.invite_code_used = invite_code_used
	ServerCall:d2xCall(sid, 'InviteCodeCtrl.d2b_syncInviteCodeInfo', 0, pack_data)
end

function InviteCodeCtrl:_addInviteCode(params)
	local area_id = params.area_id
	local player_id = params.player_id
	local guid = params.guid
	local nick = params.nick
	local level = params.level
	local cid = params.cid

	local where = string_format('guid = "%s" AND player_id = %d ', guid, player_id)
	local invite_code_db = DatabaseService:getDBEntityOne('tbl_invite_code', InviteCode, where)
	if not invite_code_db and level >= InviteCodeDefs.INVITE_PLAYER_LEVEL_MIN then
		local invite_code = InviteCodeCtrl.genInviteCode(area_id, cid)
		local invite_code_entity = InviteCode:new(invite_code, area_id, player_id, guid, nick, level)
		-- 存入DB
		DatabaseService:replaceByEntityCls('tbl_invite_code', invite_code_entity, InviteCode)

		return invite_code_entity, true
	elseif invite_code_db then
		-- 更新
		local where = string_format('invite_code = "%s" and guid = "%s"', invite_code_db.invite_code, guid)
		local up_params = {updated=Time:getDateTimeStrNow(), level = level}
		DatabaseService:updateEx('tbl_invite_code', where, up_params, InviteCode)
		
		invite_code_db.level = level
		invite_code_db.updated = up_params.updated
	end

	return invite_code_db
end

-- 使用邀请码
function InviteCodeCtrl.b2d_useInviteCode(sid, params)
	local invite_code = params.invite_code
	local invitee_guid = params.invitee_guid
	local invitee_area_id = params.invitee_area_id
	local invitee_player_id = params.invitee_player_id
	local invitee_nick = params.invitee_nick
	local invitee_fight_capacity = params.invitee_fight_capacity
	local invitee_level = params.invitee_level
	local invitee_prof = params.invitee_prof
	local invitee_gender = params.invitee_gender
	local invitee_vip = params.invitee_vip
	local invitee_cid = params.invitee_cid
	
	local pack_data = {invite_code = invite_code, invitee_area_id = invitee_area_id, invitee_player_id = invitee_player_id}
	
	-- 检查邀请码是否存在
	local where = string_format('invite_code = "%s" ', invite_code)
	local invite_code_db = DatabaseService:getDBEntityOne('tbl_invite_code', InviteCode, where)
	if not invite_code_db or invite_code_db.invite_code ~= invite_code then
		pack_data.err_id = errorCodes.INVITE_CODE_NOT_EXIST
		return ServerCall:d2xCall(sid, 'InviteCodeCtrl.d2b_useInviteCode', 0, pack_data)
	end
	
	-- 检查是否为自己的邀请码
	if invite_code_db.player_id == invitee_player_id then
		pack_data.err_id = errorCodes.INVITE_CODE_CANNOT_SELF
		return ServerCall:d2xCall(sid, 'InviteCodeCtrl.d2b_useInviteCode', 0, pack_data)
	end

	-- 检查自己是否已使用过
	local where = string_format('invitee_player_id = %d', invitee_player_id)
	local used_invite_code = DatabaseService:getDBEntityOne('tbl_invite_code_used', InviteCodeUsed, where)
	if used_invite_code then
		pack_data.err_id = used_invite_code.invite_code ~= invite_code and errorCodes.INVITE_CODE_A_USED_OTHER or errorCodes.INVITE_CODE_ALREADY_USED
		return ServerCall:d2xCall(sid, 'InviteCodeCtrl.d2b_useInviteCode', 0, pack_data)
	end
	
	-- 检查邀请码已使用次数
	local max_invitee_num = InviteCodeConfig:getInviteeNum(invite_code_db.level)
	local where = string_format('invite_code = "%s"', invite_code)
	local used_cnt = DatabaseService:getRecordCnt('tbl_invite_code_used', where)
	if used_cnt >= max_invitee_num then
		pack_data.err_id = errorCodes.INVITE_CODE_USE_TOO_MANY
		return ServerCall:d2xCall(sid, 'InviteCodeCtrl.d2b_useInviteCode', 0, pack_data)
	end
	
	-- 添加使用记录
	local invite_code_used = InviteCodeUsed:new(invite_code, invitee_guid, invitee_area_id, invitee_player_id, 
							invitee_fight_capacity, invitee_level, invitee_nick, invitee_gender, invitee_prof, invitee_cid, invitee_vip)
	invite_code_used.is_new = 1
	DatabaseService:addEx('tbl_invite_code_used', invite_code_used, false, InviteCodeUsed)
	
	-- RSP OK
	pack_data.err_id = nil
	pack_data.invite_code_used = invite_code_used
	pack_data.area_id = invite_code_db.area_id
	pack_data.player_id = invite_code_db.player_id
	ServerCall:d2xCall(sid, 'InviteCodeCtrl.d2b_useInviteCode', 0, pack_data)
end

-- 更新被邀请人的战力等信息
function InviteCodeCtrl.b2d_updateInvitee(sid, params)
	local invite_code = params.invite_code
	local invitee_guid = params.invitee_guid
	local invitee_area_id = params.invitee_area_id
	local invitee_player_id = params.invitee_player_id
	local invitee_fight_capacity = params.invitee_fight_capacity
	local invitee_level = params.invitee_level
	local invitee_nick = params.invitee_nick
	local invitee_prof = params.invitee_prof
	local invitee_gender = params.invitee_gender
	local invitee_vip = params.invitee_vip
	local invitee_cid = params.invitee_cid
	
	-- 更新
	local where = string_format('invite_code = "%s" and invitee_player_id = %d and invitee_guid = "%s"', invite_code, invitee_player_id, invitee_guid)
	local up_params = {updated=Time:getDateTimeStrNow(), invitee_area_id = invitee_area_id, invitee_fight_capacity = invitee_fight_capacity, 
						invitee_level = invitee_level, invitee_nick=invitee_nick, invitee_cid=invitee_cid, invitee_vip=invitee_vip}
	DatabaseService:updateEx('tbl_invite_code_used', where, up_params, InviteCodeUsed)
	
	-- 获取邀请人信息
	local where = string_format('invite_code = "%s" ', invite_code)
	local invite_code_entity = DatabaseService:getDBEntityOne('tbl_invite_code', InviteCode, where)
	
	local invite_code_used = InviteCodeUsed:new(invite_code, invitee_guid, invitee_area_id, invitee_player_id, invitee_fight_capacity, 
							invitee_level, invitee_nick, invitee_gender, invitee_prof, invitee_cid, invitee_vip)
	
	-- RSP
	local pack_data = {
		area_id = invite_code_entity.area_id,
		player_id = invite_code_entity.player_id,
		arr_invitee = {invite_code_used},
	}
	ServerCall:d2xCall(sid, 'InviteCodeCtrl.d2b_updateInvitee', 0, pack_data)
end

function InviteCodeCtrl.genInviteCode(area_id, cid)
	-- 获取被邀请人列表
	local where = string_format(' is_used = 0 LIMIT 1')
	local invite_code_lib = DatabaseService:getDBEntityOne('tbl_invite_code_lib', InviteCodeLib, where)
	
	if invite_code_lib then
		for i = 1, 9 do
			local invite_code = invite_code_lib.invite_code
			if not filterWords:isSafe(invite_code) then
				-- 记录已使用
				local where_up = string_format('invite_code = "%s"', invite_code)
				local up_params = {use_dtime='2010-01-01 01:01:01', is_used = 1}
				DatabaseService:updateEx('tbl_invite_code_lib', where_up, up_params, InviteCodeLib)
				
				invite_code_lib = DatabaseService:getDBEntityOne('tbl_invite_code_lib', InviteCodeLib, where)
			else
				break
			end
		end
	end
	
	if not invite_code_lib or not filterWords:isSafe(invite_code_lib.invite_code) then
		return Utils.genInviteCode(area_id, cid)
	end
	
	local invite_code = invite_code_lib.invite_code
	
	-- 记录已使用
	local where = string_format('invite_code = "%s"', invite_code)
	local up_params = {use_dtime=Time:getDateTimeStrNow(), is_used = 1}
	DatabaseService:updateEx('tbl_invite_code_lib', where, up_params, InviteCodeLib)
	
	return invite_code
end

-- 记录新被邀请人已查看
function InviteCodeCtrl.b2d_newInviteeViewed(sid, params)
	local invite_code = params.invite_code
	local invitee_player_id = params.invitee_player_id
	
	local where = string_format('invite_code = "%s" and is_new = 1', invite_code)
	local up_params = {is_new=0}
	DatabaseService:updateEx('tbl_invite_code_used', where, up_params, InviteCodeUsed)
end
