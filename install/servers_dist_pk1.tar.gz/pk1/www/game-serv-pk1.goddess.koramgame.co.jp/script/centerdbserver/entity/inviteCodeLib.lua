--[[
邀请码库表
author : xingzeng.jiang
date : 2014-02-18
--]]

-- 邀请码库表
InviteCodeLib = {
	invite_code = '', 		--邀请码
	is_used = 0, 			--是否已使用
	use_dtime = '',			--使用时间
}
