--[[
合服表
author : biquan.xu
date : 2016-01-21
--]]

-- 合服表
areaCombineInfo = {
  oldaid = 0,
  newaid = 0,
	--born_vouch_aid = 0, 	--出生充值aid
	--target_vouch_aid = 0, 	--主服充值aid
	--cid_offset =0,			--cid偏移
	--max_born_cid=0,			--最大出生cid
}


