---[[
--	数据库操作类
--  by mjl
--  at 2013年7月26日
---]]
local dbFreeRecordset=external.dbFreeRecordset

Database = Database or 
{
	mysql_fields_size = 0,
	mysql_fields = {},
	database = nil,
	sql = StdString(),
}

--初始化 database
function Database:init(db)
	Database.database = db
end

function Database:releaseFields()
	local mysql_fields_size = self.mysql_fields_size
	if mysql_fields_size > 0 then
		local mysql_fields = self.mysql_fields
		for i=mysql_fields_size,1,-1 do
			local fields = mysql_fields[i]
			--fields:release()
			dbFreeRecordset(fields)
			mysql_fields[i] = nil
		end	
		self.mysql_fields_size = 0
	end			
end
