--[[
框架入口 c++调用入口函数
--]]

local c_opHandlers = c_opHandlers._handlers
local i_opHandlers = i_opHandlers._handlers
local opcodeNames = opcodeNames
local WorldPacket = WorldPacket
local Database = Database
local dbFreeRecordset=external.dbFreeRecordset

--local enablePkgLuaTimeoutGuard=external.enablePkgLuaTimeoutGuard

g_is_world_inited = false

--加载脚本完成后（包括reload)
do
	-- 响应LUA脚本加载或热更新完成
	local string_find, string_len = string.find, string.len
	function c_after_load()
		local ReadOnly = ReadOnly
		local gmt = getmetatable(_G)
		
		-- 调用所有service  ctrl 的 onAfterLoadLua(响应LUA脚本加载或热更新完成) 函数
		for cls_name, cls_obj in pairs(_G) do
			if type(cls_obj) == 'table' and cls_obj ~= _G and cls_obj ~= gmt then
				local mt = getmetatable(cls_obj)
				if mt ~= ReadOnly and type(cls_obj.onAfterLoadLua) == 'function' and
					(string_find(cls_name, 'Ctrl') == string_len(cls_name) - 3 or
						string_find(cls_name, 'Service') == string_len(cls_name) - 6)
					then
					cls_obj:onAfterLoadLua()
				end
			end
		end
	end
end

-- 优化数据表
local function optimizeTables(database)
	local sql = StdString()
	sql:assign("show tables")
	local fields = database:query(sql)
	if fields then
		local count = fields:rowCount()
		for i=1, count do
			local tbl = fields:getString(0)
			
			sql:assign("optimize table " .. tbl)
			local x = database:query(sql)
			if x then
				dbFreeRecordset(x)
			end			
			fields:nextRow()
		end
		dbFreeRecordset(fields)
	end
end


-- 启动初始化
function c_initWorld(db, thread_idx)	
	local area_id = external.getAid()
	if area_id<970 then print = function()end end
		
	assert(thread_idx == LUA_THREAD_IDX)
	g_is_world_inited = true
	
	DatabaseService:init(db)
	
	CsvLoader:load('db')
	
	if thread_idx == 0 then
		--优化表
		optimizeTables(db)
	end
	 
	return 12345	
end

-- 内部请求
local collectgarbage = collectgarbage
function c_internalIndex(sid, packet)
	local opcode = packet:getOpcode()
	local handler = i_opHandlers[opcode]
	if not handler then
		local opcode_name = opcodeNames[opcode] or 'unknown'
		Logger:error('centerdbserver no found the function, opcode=',opcode,'opcode_name=',opcode_name)
	else
		WorldPacket.g_packet_id = packet:getPacketId()
		WorldPacket.g_opcode = opcode
		handler(sid,packet)
		WorldPacket.g_opcode = 0
		WorldPacket.g_packet_id = 0
		
		Database:releaseFields()
		collectgarbage('step')
	end
end

-- 服务器退出
function c_shutdownWorld()end
function c_clientIndex()end
function c_update()end
function c_timerIndex()end


-- 添加平台元宝操作接口回调,db中使用
-- package : 数据包
function c_addGoldCallBack(sid,packet)
end

function c_curlCallBack(sid,packet)
	
end


function c_queryGoldIndex(sid, packet)
	--local key = packet:readUInt()
	--local ret_code = packet:readShort()
	--local str = packet:readString()
	
end


-- 消费平台元宝操作接口回调,db中使用
-- package : 数据包
function c_consumeGoldCallBack(sid, packet)
	--local key = packet:readUInt()
	--local ret_code = packet:readShort()
	--local str = packet:readString()	
	
end