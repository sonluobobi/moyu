--[[
充值商城基础Service，用于数据获取以及相关逻辑处理
author : xingzeng.jiang
date : 2016-01-11
--]]

local VoucherMallBaseDao = VoucherMallBaseDao
VoucherMallBaseService = VoucherMallBaseService or {}

function VoucherMallBaseService:getVoucherMallBaseById(id)
	return VoucherMallBaseDao.data[id]
end

function VoucherMallBaseService:getVMallBaseByGooglePlayId(google_play_id)
	local data = VoucherMallBaseDao.data
	for _, e in pairs(data) do
		if e.google_play_id == google_play_id then
			return e
		end
	end
end