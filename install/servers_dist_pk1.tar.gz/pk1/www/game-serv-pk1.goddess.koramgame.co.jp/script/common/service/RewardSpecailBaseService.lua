--[[
特殊奖励数据 SERVICE
author : xingzeng.jiang
date : 2014-10-16
--]]

RewardSpecialBaseService = RewardSpecialBaseService or {}

local WorldPacket = WorldPacket
local Time = Time
local random = math.random
local ceil = math.ceil
local table = table
local RewardSpecialDefs = RewardSpecialDefs

local RewardSpecialBaseDao = RewardSpecialBaseDao

-- 获取邀请码奖励：下一级达成战力
function RewardSpecialBaseService:getInviteCodeNextFC(now_fight_capacity)
	local reward_ids = RewardSpecialBaseDao.sort2reward_ids[RewardSpecialDefs.REWARD_SPECIAL_SORT_INVITE_CODE_REFERRALS]
	local next_fc = 0
	local rewards = RewardSpecialBaseDao.data
	for _, reward_id in pairs(reward_ids) do
		local reward_item = rewards[reward_id]
		local cond_v1 = reward_item.cond_v1
		if cond_v1 > now_fight_capacity and (next_fc == 0 or next_fc > cond_v1) then
			next_fc = cond_v1
		end
	end
	
	return next_fc
end

-- 获取子奖励列表
function RewardSpecialBaseService:getSubRewardBasesBySortId(sort_id)
	local reward_ids = RewardSpecialBaseDao.sort2reward_ids[sort_id]
	local rewards = RewardSpecialBaseDao.data
	local REWARD_SPECIAL_ID_SUB_CARD = RewardSpecialDefs.REWARD_SPECIAL_ID_SUB_CARD
	local reward_items = {}
	
	for _, reward_id in pairs(reward_ids) do
		if reward_id > REWARD_SPECIAL_ID_SUB_CARD then
			reward_items[#reward_items+1] = rewards[reward_id]
		end
	end
	
	return reward_items
end