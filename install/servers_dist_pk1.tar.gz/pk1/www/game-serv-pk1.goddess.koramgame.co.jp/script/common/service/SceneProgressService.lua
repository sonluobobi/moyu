--[[
�������� SERVICE
author : xingzeng.jiang
date : 2014-07-15
--]]

SceneProgressService = SceneProgressService or {}
local WorldPacket = WorldPacket
local SceneProgress = SceneProgress
local pairs = pairs
local Config = Config

function SceneProgressService:init(character)
	local dy_scenes = character.dy_scenes	
	if not dy_scenes or dy_scenes == '' then
		dy_scenes ={}
	else
		dy_scenes = WorldPacket:decodeData(dy_scenes)
	end	
	
	if Config.IS_TEST_SERVER then		
		local is_old_data = true	
		for k,v in pairs(dy_scenes) do				
			if v[1] == -1 then
				is_old_data = false
				break
			end				
		end			
		if is_old_data then			
			for k,v in pairs(dy_scenes) do				
				if v[1] == 0 then
					v[1] = -1
				end				
			end			
		end
	end	
	character.dy_scenes = dy_scenes
end

function SceneProgressService:getSceneProgress(character,scene_id)	
	local dy_scenes = character.dy_scenes
	local dy_scene = dy_scenes[scene_id]
	if not dy_scene then
		dy_scene = SceneProgress:new()
		dy_scenes[scene_id] = dy_scene
	end
	return dy_scene
end

function SceneProgressService:isPassedOne(character,scene_ids)

	if not scene_ids then return 0 end
	
	local dy_scenes = character.dy_scenes	
	for i=1, #scene_ids do	
		local dy_scene = dy_scenes[ scene_ids[i] ]
		if dy_scene and dy_scene[1] >= 0 then
			return 1
		end	
	end
	
	return 0	
end

function SceneProgressService:isPassedAll(character,scene_ids)	
	
	if not scene_ids then return 0 end
	
	local dy_scenes = character.dy_scenes	
	for i=1, #scene_ids do	
		local dy_scene = dy_scenes[ scene_ids[i] ]
		if not dy_scene or dy_scene[1] < 0 then
			return 0
		end
	end
	return 1
end


function SceneProgressService:setSceneProgressValue(character,scene_id,idx,value)	
	local dy_scene = self:getSceneProgress(character,scene_id)
	dy_scene[idx] = value or 0		
end

function SceneProgressService:getSceneProgressValue(character,scene_id,idx)
	local dy_scene = self:getSceneProgress(character,scene_id)
	return dy_scene[idx]
end


