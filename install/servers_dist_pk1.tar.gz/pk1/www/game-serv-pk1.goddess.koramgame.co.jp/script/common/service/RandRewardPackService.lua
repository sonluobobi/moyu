--[[
随机奖励包 SERVICE
author : xingzeng.jiang
date : 2014-10-16
--]]

RandRewardPackService = RandRewardPackService or {}

local WorldPacket = WorldPacket
local Time = Time
local random = math.random
local ext_getNowUnixMsTime = external.getNowUnixMsTime
local ceil = math.ceil
local table = table

local RandRewardPackBaseDao = RandRewardPackBaseDao

-- 随机奖励
function RandRewardPackService:randRewardByGroupId(group_id, prof)
	local gid2packs = RandRewardPackBaseDao.gid2packs
	local gid2pack_probas = RandRewardPackBaseDao.gid2pack_probas
	local packs = gid2packs[group_id]
	local pack_probas = gid2pack_probas[group_id][prof]
	local id = math.randOneElement(pack_probas)
	local reward_pack = packs[id]
	
	return reward_pack
end

-- 随机奖励
function RandRewardPackService:randRewardBySceneId(scene_id, group_id, prof)
	local gid2packs = RandRewardPackBaseDao.gid2packs
	local gid2pack_probas = RandRewardPackBaseDao.sid2pack_probas[scene_id]
	if not gid2pack_probas or not gid2pack_probas[group_id] then
		return
	end
	local packs = gid2packs[group_id]
	local pack_probas = gid2pack_probas[group_id][prof]
	local id = math.randOneElement(pack_probas)
	local reward_pack = packs[id]
	
	return reward_pack
end

-- 获取保底奖励
function RandRewardPackService:getBaodiRandReward(group_id, prof)
	local gid2baodi_packs = RandRewardPackBaseDao.gid2baodi_packs
	local arr_baodi_pack = gid2baodi_packs[group_id][prof]
	if not arr_baodi_pack then return end
	local len = #arr_baodi_pack
	if len > 0 then
		return arr_baodi_pack[random(1, len)]
	end
end
