--[[
pk/语音/中心 ---》游戏服玩法 映射表
author : jinlin.liu
date : 2016-08-18
--]]

PkserverMappingService = PkserverMappingService or {}

local WorldPacket = WorldPacket
local Utils = Utils
local externalSplitUInt = external.splitUInt
local externalMergeUInt = external.mergeUInt

-----------------------------------------------------------------
--
--下面是固定分配所有玩法在大组或者小组方式的映射
--
-----------------------------------------------------------------

do
    --玩法id -> 所有的组id
    function PkserverMappingService:getGroupIds(game_type_id)
       local mappingconfig = Utils.getGameServersConfig()
       local groupidstr=PkserverMappingService:__getGroupName(game_type_id)
       local groupIds={}
       --table.dump("config:",mappingconfig,-1)
       if mappingconfig and mappingconfig[1] and mappingconfig[1].gameservers then
           local gameservers = mappingconfig[1].gameservers
           for k,v in pairs(gameservers) do
                if v.params and v.params[groupidstr] then
                    local group_tempid = v.params[groupidstr]
                    groupIds[group_tempid] = 1
                end     
           end
       end
       return table.keys(groupIds)
    end    
    
    -- gcid_or_gpid, 玩法id -> 组号
    function PkserverMappingService:getGroupIdByGid(gcid_or_gpid,game_type_id)
      local area_id = externalSplitUInt(gcid_or_gpid)
      return self:getGroupId(area_id, game_type_id)
    end

    --aid/character,玩法id->组号
    function PkserverMappingService:getGroupId(character_or_aid,game_type_id)
        local aid
        if type(character_or_aid) == "table" then
            aid = character_or_aid.area_id
        else 
            aid = character_or_aid 
        end
        if not aid then 
            Logger:error("传入的character_oraid有误:",character_or_aid,game_type_id)   
            return 1 
        end
       local mappingconfig = Utils.getGameServersConfig()
       local groupidstr=PkserverMappingService:__getGroupName(game_type_id)
       
       --table.dump("config:",mappingconfig,-1)
       if mappingconfig and mappingconfig[1] and mappingconfig[1].gameservers then
           local gameservers = mappingconfig[1].gameservers
           for k,v in pairs(gameservers) do
               if v.aid == aid then
                    if v.params and v.params[groupidstr] then
                        return v.params[groupidstr] or 1
                    end     
                    Logger:error("当前服的分配方案有问题:不存在group_id",aid,groupidstr)   
                    return 1        
               end
           end
           Logger:error("当前跨服没有连接该aid:",aid,groupidstr)   
           return 1
       end
       Logger:error("当前跨服映射表配置有问题:",aid,groupidstr)   
       return 1
    end


    --aid,玩法id-> 在一组的aids
    function PkserverMappingService:getAreaids(character_or_aid,game_type_id)
        local aid
        if type(character_or_aid) == "table" then
            aid = character_or_aid.area_id
        else 
            aid = character_or_aid 
        end
        if not aid then 
            Logger:error("传入的character_oraid有误:",character_or_aid,game_type_id)   
            return {} 
        end
       local current_groupid = PkserverMappingService:getGroupId(character_or_aid,game_type_id)
       --Logger:error("getAidsByGroupidAndWangfaid",wfaids,mappingconfig,aid,game_type_id)
       return self:getAreaidsByGameTypeId(game_type_id,current_groupid)
    end
    
    -- 玩法+组id->areaids
    function PkserverMappingService:getAreaidsByGameTypeId(game_type_id,current_groupid)
        local mappingconfig = Utils.getGameServersConfig()
        local groupidstr=PkserverMappingService:__getGroupName(game_type_id)
        local wfaids = {}
        if not current_groupid then
            Logger:error("当前玩家参与的玩法没配置组",groupidstr,current_groupid,game_type_id) 
            return wfaids 
        end
       
       --table.dump("config:",mappingconfig,-1)
       if mappingconfig and mappingconfig[1] and mappingconfig[1].gameservers then
           local gameservers = mappingconfig[1].gameservers
           for k,v in pairs(gameservers) do
               local params = v.params
               if params and params[groupidstr] and current_groupid==params[groupidstr] then
                   wfaids[#wfaids+1] = v.aid
               end
           end
       end
       return wfaids
    end
    
    -- 取配置中所有的大区id
    function PkserverMappingService:getAllAreaids()
       local mappingconfig = Utils.getGameServersConfig()
       local aids={}
       --table.dump("config:",mappingconfig,-1)
       if mappingconfig and mappingconfig[1] and mappingconfig[1].gameservers then
           local gameservers = mappingconfig[1].gameservers
           for k,v in pairs(gameservers) do
                if v.aid then
                    aids[v.aid] = 1         
                end     
           end
       end
       return table.keys(aids)
    end
    
    function PkserverMappingService:__getGroupName(game_type_id)
       local pk_mapping = Statics.pk_mapping
       if pk_mapping[game_type_id] then
        return pk_mapping[game_type_id]
       end
       return "group_id2"
    end
end

-----------------------------------------------------------------
--
--下面是通过具体玩法设置组号 已过期
--
-----------------------------------------------------------------

do
    --玩法id +  当前大区id -> 组id
	function PkserverMappingService:getGroupidByAidAndWangfaid(wanfaid,aid)
	   local mappingconfig = Utils.getGameServersConfig()
	   --table.dump("config:",mappingconfig,-1)
	   if mappingconfig and mappingconfig[1] and mappingconfig[1].gameservers then
	       local gameservers = mappingconfig[1].gameservers
	       for k,v in pairs(gameservers) do
	           if v.aid == aid then
                    if v.params then
                        return v.params[wanfaid]
                    end	       
                    return nil        
	           end
	       end
	       return nil
	   end
	   return nil
	end
	
	--玩法id + groupid -> 参与的大区ids
	function PkserverMappingService:getAidsByGroupidAndWangfaid(wanfaid,groupid)
	   local mappingconfig = Utils.getGameServersConfig()
	   local wfaids = {}
	   --table.dump("config:",mappingconfig,-1)
	   if mappingconfig and mappingconfig[1] and mappingconfig[1].gameservers then
	       local gameservers = mappingconfig[1].gameservers
	       for k,v in pairs(gameservers) do
	           local params = v.params
	           if params then
	               if params[wanfaid] and params[wanfaid] == groupid then
	                    wfaids[#wfaids+1] = v.aid
	               end
	           end
	       end
	   end
	   --table.dump("getAidsByGroupidAndWangfaid",wfaids,-1)
	   return wfaids
    end
    
    --玩法id + gpid/gcid ->groupid
    function PkserverMappingService:getGroupidByWangfaidAndGpidOrGcid(wanfaid,gid)
        local mappingconfig = Utils.getGameServersConfig()
        --table.dump("config:",mappingconfig,-1)
        local aid, _ = externalSplitUInt(gid)
        if aid and mappingconfig and mappingconfig[1] and mappingconfig[1].gameservers then
           local gameservers = mappingconfig[1].gameservers
           for k,v in pairs(gameservers) do
               local params = v.params
               if v.aid == aid  then
                   if  params and params[wanfaid] then
                       return params[wanfaid]
                   end
                   return nil
               end
           end
        end
        return nil
    end
end


