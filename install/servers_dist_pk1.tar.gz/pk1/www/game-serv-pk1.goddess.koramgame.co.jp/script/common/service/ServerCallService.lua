---[[
--	服务器之间的互相调用
--	调用方式  ServerCall:x2xCall(func, gcid, data)
--	func是被调用的函数，原型为   XXX:function(character/sid,data,gcid/nil)
--
--	比如 base调用map的方法 ServerCall:b2mCall('MyService:b2m_callMe',gcid,data)
--  by mjl
--  at 2013年7月19日
---]]

ServerCall = ServerCall or {}
local ServerCall = ServerCall
local WorldPacket = WorldPacket
local table = table
local Log = Log
local splitUInt = external.splitUInt
local substr = string.sub
local assert = assert
local UString = UString
local type = type
local _G = _G
local error = error
local rawget = rawget
local external_info = external.info
local table_concat = table.concat
local string_format = string.format

----------------------
local game_opcode = opCodes.S2S_MSG_S2S_CALL_IN_GAME
local global_pk_opcode = opCodes.S2S_MSG_S2S_CALL_IN_GLOBAL

local _empty_data = {}
local SERVER_NAME = SERVER_NAME .. (g_mapserver_id and ('_'.. g_mapserver_id) or '')
local function makePacket(func, gcid, data, opcode, packet_gcid)

	local data = data or _empty_data
	
	local aid,cid
	if gcid == -1 then
		gcid = 0
		aid,cid = -1,0
	else		
		aid,cid = splitUInt(gcid)
	end
	
	external_info(table_concat({'To ServerCall',func,'aid=',aid,'cid=',cid,'packid=',WorldPacket.g_packet_id},'|'))

	local packet = WorldPacket:newPacket(opcode, nil, packet_gcid or gcid)
	packet:writeString(func)
	packet:writeLong(gcid)
	packet:writeTable(data)
	return packet
end

do
	-- 注：chObjOrSid其实就是 sid 或 character
	local function sys_called(chObjOrSid,packet)
		local func = packet:readString()
		local gcid = packet:readLong()
		local data = packet:readTable()
		
		WorldPacket.g_func = func
		WorldPacket.g_gcid = gcid
		ServerCall:onCall(func, gcid, data, chObjOrSid)
		WorldPacket.g_gcid = 0
		WorldPacket.g_func = false
	end
	i_opHandlers[game_opcode] = sys_called
	i_opHandlers[global_pk_opcode] = sys_called
end

-- 注：别随便修改，ChItemPackageService:_callback_isHasOneEmptyPos 有调用
-- 注：chObjOrSid其实就是 sid 或 character
function ServerCall:onCall(method_name, gcid, data, chObjOrSid)
	data = data or _empty_data
	local aid, cid = splitUInt(gcid)
	local msg = table_concat({'Do ServerCall',method_name,'aid=',aid,'cid=',cid,'packid=',WorldPacket.g_packet_id},'|')
	external_info(msg)
	
	-- 验证参数
	if not method_name then 
		error("ServerCall.onCall, lost method name!")
		return 
	end
	
	UString.invokeByMethodName(method_name, chObjOrSid, data, gcid)
end

------------------------
--timer
do
	local addEvent = external.addEvent
	function ServerCall:addTimer(func, gcid, data, delay_ms, repeat_time, imm)
		local packet = makePacket(func, gcid, data, game_opcode)
		return addEvent(packet,delay_ms,repeat_time,imm and 1 or 0)
	end
end

------------------------


----------------------------------------------------------------------
-- b2x
----------------------------------------------------------------------
function ServerCall:b2mCall(func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode)
	WorldPacket:b2mSendPacket(packet, false)
end
function ServerCall:b2mCalltToAllMap(func, data)
	local packet = makePacket(func, -1, data, game_opcode)
	WorldPacket:b2mSendPacket(packet, true)
end
function ServerCall:b2mCallByMapserv(func , gcid, data, mapserv_id)
	local packet = makePacket(func, gcid, data, game_opcode)
	WorldPacket:b2mSendPacketByMapserv(packet,mapserv_id)
end
function ServerCall:b2mCallBySpace(func, gcid, data, space_id)
	local packet = makePacket(func, gcid, data, game_opcode)
	WorldPacket:b2mSendPacketBySpace(packet,space_id)
end
function ServerCall:b2dCall(func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode)
	WorldPacket:b2dSendPacket(packet)
end
---使用dbserver的第0条线程进行数据库持久化
function ServerCall:b2dCall_0(func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode,0)
	WorldPacket:b2dSendPacket(packet)
end
---------------------------------------------------------------------
-- m2x
---------------------------------------------------------------------
function ServerCall:m2bCall(func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode)
	WorldPacket:m2bSendPacket(packet)
end

function ServerCall:m2mCall(func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode)
	WorldPacket:m2mSendPacket(packet)
end

function ServerCall:m2dCall(func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode)
	WorldPacket:m2dSendPacket(packet)
end

---使用dbserver的第0条线程进行数据库持久化
function ServerCall:m2dCall_0(func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode, 0)
	WorldPacket:m2dSendPacket(packet)
end

function ServerCall:m2dCallCurl(gcid, data, callback)
	assert(data.host)
	assert(data.get or data.post)
	data.callback = callback
	local packet = makePacket('CurlService:docurl', gcid, data, game_opcode)
	WorldPacket:m2dSendPacket(packet)
end


-----------------------------------------------------------------------
-- d2x
-----------------------------------------------------------------------
function ServerCall:d2xCall(sid, func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode)
	WorldPacket:dbSendPacket(sid,packet)
end
function ServerCall:d2xCall_0(sid, func, gcid, data)
	local packet = makePacket(func, gcid, data, game_opcode, 0)
	WorldPacket:dbSendPacket(sid,packet)
end
-----------------------------------------------------------------------

