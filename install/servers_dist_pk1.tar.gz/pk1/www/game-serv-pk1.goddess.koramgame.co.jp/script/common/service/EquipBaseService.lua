--[[
基础道具系统servuce
author : xingzeng
date : 2012-03-27
]]--

local external = external
local EquipBaseDao = EquipBaseDao

EquipBaseService = EquipBaseService or {}

-------------------------------- GET类函数 start ------------------------------
-- 根据id获取道具基础数据
-- equip_id : 道具_id
-- return obj / nil
function EquipBaseService:getEquipBaseById(equip_id)
	return EquipBaseDao.data[equip_id]
end

-- 获取一批equip基本信息 (注意：返回的是一个临时TABLE)
-- arr_equip_id:array 道具id数组
-- eid_is_key:boolean 道具ID是否在数组的KEY部分
-- bidkey:boolean	  返回的数组是否用EQUIP ID做KEY
-- return array:table
function EquipBaseService:getEquipBaseByIds(arr_equip_id, eid_is_key, bidkey)
	if not arr_equip_id then return end
	local arr_equip = {}
	local equip_base_data = EquipBaseDao.data
	
	for k, equip_id in pairs(arr_equip_id) do
		if eid_is_key then equip_id = k end
		local equip = equip_base_data[equip_id]
		if type(equip) == 'table' then
			if bidkey then
				arr_equip[equip_id] = equip
			else
				arr_equip[#arr_equip+1] = equip
			end
		end
	end
	return arr_equip
end
-------------------------------- GET类函数 end ------------------------------


-------------------------- 道具类型相关定义 start -----------------------------
-- 根据道具功能类型获取道具ID/ID数组
-- is_get_all	是否获取所有的道具ID (默认：false, 仅获取一个道具ID)
-- return : 道具ID/道具ID数组
function EquipBaseService:getFuncEquipId(function_type, is_get_all)
	local eids = EquipBaseDao.functype2eid[function_type]
	if is_get_all then return eids end
	return eids ~= nil and eids[1] or 0
end

-- 获取大类ID
function EquipBaseService:getParentSortId(equip_sort_id)
	return math.floor(equip_sort_id/100)
end

-- 根据宝石ID获取宝石分类ID
function EquipBaseService:getJewelSortByEquipId(equip_id)
	return strSub(equip_id, 1, 4)
end
	
-- 根据一批宝石ID获取宝石分类ID数组
function EquipBaseService:getJewelSortByEquipIds(arr_equip_id)
	local arr_sort_id = {}
	for _, equip_id in pairs(arr_equip_id) do
		arr_sort_id[equip_id] = strSub(equip_id, 1, 4)
	end
	
	return arr_sort_id
end

-- 获取高级别的宝石道具ID
function EquipBaseService:getUpLevJewelEid(equip_id, up_level)
	return equip_id + up_level
end
	
-- 将道具ID、数量 数组转换成HASH
function EquipBaseService:arrToHashEquips(arr_equip_id_nums, star_i)
	local star_i = star_i or 1
	local equip_id2nums = {}
	local count = #arr_equip_id_nums;
	
	for i = star_i, count, 2 do
		local equip_id, equip_num = arr_equip_id_nums[i], arr_equip_id_nums[i+1]
		equip_id2nums[equip_id] = equip_num
	end
	
	return equip_id2nums
end
