--[[
���������� SERVICE
author : xingzeng.jiang
date : 2014-07-15
--]]

SceneBaseService = SceneBaseService or {}
local SceneBaseDao = SceneBaseDao

function SceneBaseService:getSceneBaseById(scene_id)
	return SceneBaseDao[scene_id]
end

function SceneBaseService:allScenes()
	return SceneBaseDao
end

function SceneBaseService:checkTransfer(src_transfer_ins_id,dst_transfer_base_id)
	return true
end

-- �Ƿ�Ϊ���ǳ���
function SceneBaseService:isMainCity(scene_id)
	local scene_base = SceneBaseDao[scene_id]
	return scene_base.scene_sort_id == SceneDefs.SCENE_SORT_ID_NORMAL_MCITY
end



