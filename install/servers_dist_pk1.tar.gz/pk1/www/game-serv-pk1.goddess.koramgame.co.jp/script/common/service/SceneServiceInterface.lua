--[[
场景服务interface
author : xingzeng.jiang
date : 2014-07-15
--]]

SceneServiceInterface = SceneServiceInterface or 
{
	name = 'SceneServiceInterface',
	
	--- 切换场景前，判断是否可离开场景, 源场景的 service 会被调用该函数
	-- @return true / false,err
	checkLeaveScene = nil,	--function(self, character, aoi_scene ) return true end,

	--- 切换场景前，判断是否可进入场景, 目标场景的 service 会被调用该函数
	-- @return bool err_id, err_param
	checkEnterScene = function(self, character, aoi_scene, dst_scene_base ) return true end,
	
	--- 场景被移动时
	-- @return nil : 代表弃权(等同于true)
	checkMoveToDest = nil,	--function(self, character, aoi_scene) return true end,
	
	--- 场景创建之后, 初始化场景
	-- @param character 第一个进入场景的玩家
	onInitScene = function(self, character, aoiscene) end,
		
	--- 进入场景之前. 玩家还没有添加到 aoi, 可以修改初始坐标
	beforeEnterScene = function(self, character, aoiscene ,is_reconnect) end,
	
	--- 进入场景之后
	afterEnterScene = function(self, character, aoiscene, prev_scene_id, is_reconnect, is_login) end,
	
	--- 客户端进入场景之后
	afterClientEnterScene = function(self, character, aoiscene) end,
	
	--- 离开场景之前
	-- @param leave_type 1=场景切换，2=离线
	beforeLeaveScene = function(self, character, aoiscene, leave_type) end,
	
	afterLeaveScene = function(self, character, aoiscene, leave_type) end,
	
	-- 获取复活点
	-- return 	bool:is_back_to_mcity,	true:回到主城，false:本场景复活
	--			x, y					本场景复活的X，Y坐标点
	getRelivePos = function(self, character, aoiscene) end,	
	
	--- 是否可以攻击（群攻时）
	canGroupAttack = nil,	--function(self, aoi_scene, attacker, target) end,
	
	-- 是否可以攻击
	-- attacker		攻击者对象
	-- target		攻击目标(可为空)
	-- return is_ok:bool, err_id:int
	checkFight = function(self, aoi_scene, attacker, target) return true end,
	
	--- 场景500毫秒更新事件
	update500ms = function(self, aoi_scene) end,
	
	--- 场景每秒更新事件
	update = function(self, time_now_msec, aoi_scene) end,
	
	--每秒更新 (没有玩家的时候调用)
	updateForNoPlayer = nil, --function SceneEventService:updateForNoPlayer(time_now, aoi_scene)
	
	--- 查找怪物攻击目标
	-- return nil : 代表弃权，走默认规则
	findOneFightTarget = nil,	--function(self, aoi_scene, monster) end,
	
	-- 设置阵营(目前只设置玩家阵营)
	setZhenying = nil,		--function(self, aoi_scene, game_obj)
	
	-- 设置出生点(重连的时候不会调用到，登录、切换场景会调用到)
	-- true/false, x, y
	getBirthPos = function(self, aoi_scene, game_obj) return false end,
	
}
SceneServiceInterface.__index = SceneServiceInterface

