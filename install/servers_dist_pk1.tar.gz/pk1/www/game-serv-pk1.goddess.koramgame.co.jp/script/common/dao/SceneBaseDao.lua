--[[
场景基本表
author : xingzeng.jiang
date : 2014-07-15
--]]

SceneBaseDao = {
	-- [scene_id] = SceneBase,
	sort2scene_bases = {},
}

local pairs = pairs
local assert = assert
function SceneBaseDao:loadFromCsv(csv_data)	
	local CHARACTER_FOV_SIZE = CharacterDefs.CHARACTER_FOV_SIZE
	local sort2scene_bases = SceneBaseDao.sort2scene_bases
	
	for id, csv_db in pairs(csv_data) do
		local csv = SceneBase:new(csv_db)
		self[csv.id] = csv
		
		local scene_sort_id = csv.scene_sort_id
		local scene_bases = sort2scene_bases[scene_sort_id] or {}
		sort2scene_bases[scene_sort_id] = scene_bases
		scene_bases[csv.id] = csv
		
		csv.fov_size = CHARACTER_FOV_SIZE
	end
	
end

