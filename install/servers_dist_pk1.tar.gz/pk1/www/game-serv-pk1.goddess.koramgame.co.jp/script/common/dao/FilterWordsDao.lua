---[[
--	屏蔽字dao
--  by chao.wu
--  at 2013年10月23日
---]]
FilterWordsDao = {}

local utf8 = utf8
local strGsub = string.gsub
local pairs = pairs
local FilterWordsDao = FilterWordsDao
local insert = table.insert


function FilterWordsDao:loadFromCsv(csv_data)
	
	--print(os.time(),SERVER_NAME,'FilterWordsDao:loadFromCsv')
	local content
	local key 
	for id, csv in pairs(csv_data) do		
		content = strGsub(csv.content, "%s+$", "")	-- 过滤回车符号'\r'		
		content = strGsub(content, "^%s+", "")	-- 过滤回车符号'\r'		
		if content ~= csv.content then
			--print('bad FilterWords',id,csv.content,content)
		end		
		if content ~= '' then
			local obj = utf8:new(content)
			key = 'fw' .. obj:sub(1, 1)
			if not FilterWordsDao[key] then
				FilterWordsDao[key] = {}
			end
			insert(FilterWordsDao[key], content)
		end
	end
	--print(os.time(),SERVER_NAME,'FilterWordsDao:loadFromCsv done')
end


