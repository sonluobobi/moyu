
GashaponBaseDao = {
	base_data = {},			--基础数据
	detail_data = {},		--详细数据
	itemid_2_detail = {},	--基础ID到详细数据
}
GashaponDetailDao = {}

function GashaponBaseDao:getAllGashaponDetailByItemId( item_id )
	return self.itemid_2_detail[item_id]
end

function GashaponBaseDao:getBaseByid( item_id )
	return self.base_data[item_id]
end

function GashaponBaseDao:getDetailById( id )
	return self.detail_data[id]
end

function GashaponBaseDao:loadFromCsv(csv_data)
	for i, csv_db in pairs(csv_data) do
		GashaponBaseDao.base_data[csv_db.id] = csv_db
	end
end

function GashaponDetailDao:loadFromCsv( csv_data )
	if csv_data then 
		local detail_data = GashaponBaseDao.detail_data
		local itemid_2_detail = GashaponBaseDao.itemid_2_detail
		for _, detail_base in pairs(csv_data) do
			detail_data[detail_base.id] = detail_base
			itemid_2_detail[detail_base.item_id] = itemid_2_detail[detail_base.item_id] or {}
			table.insert(itemid_2_detail[detail_base.item_id], detail_base)
		end
	end
end
