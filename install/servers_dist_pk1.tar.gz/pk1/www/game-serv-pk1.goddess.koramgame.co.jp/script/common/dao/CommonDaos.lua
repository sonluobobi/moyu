--[[
一些简单的dao， 不用为每个dao到创建一个文件
author : xingzeng.jiang
date : 2014-07-15
--]]






