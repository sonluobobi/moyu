--[[
��ֵ�̳� DAO
author : xingzeng.jiang
date : 2016-01-11
--]]

VoucherMallBaseDao = {
	data = {},
	data_ver = 0,
	arr_fanli_vmall_base = {},
}

local function _cmp(a, b)
	if a.get_gold > b.get_gold then
		return true
	elseif a.get_gold < b.get_gold then
		return false
	else
		return a.id > b.id
	end
end

function VoucherMallBaseDao:loadFromCsv(csv_data)
	local data = VoucherMallBaseDao.data
	local arr_fanli_vmall_base = VoucherMallBaseDao.arr_fanli_vmall_base
	VoucherMallBaseDao.data_ver = VoucherMallBaseDao.data_ver + 1
	
	for id, csv_db in pairs(csv_data) do
		data[id] = csv_db
		if (csv_db.reward_gold > 0 and csv_db.reward_times > 0) or csv_db.buy_times > 0 then
			arr_fanli_vmall_base[#arr_fanli_vmall_base+1] = csv_db
		end
	end
	
	table.sort(arr_fanli_vmall_base, _cmp)
	
	VoucherMallConfig:addDyVoucherMall()
end

