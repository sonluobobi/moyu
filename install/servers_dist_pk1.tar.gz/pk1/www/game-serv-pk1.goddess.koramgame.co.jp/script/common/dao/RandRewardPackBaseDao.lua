--[[
���������
author : xingzeng.jiang
date : 2014-11-11
--]]

RandRewardPackBaseDao = {
	gid2packs = {}, 				--[group_id][id] = RandRewardPackBase
	gid2pack_probas = {},			--[group_id] = [[id, proba], ...]
	gid2baodi_packs = {},			--[group_id] = [RandRewardPackBase, ...]
	sid2pack_probas = {},
}

function RandRewardPackBaseDao:loadFromCsv(csv_data)
	local gid2packs = RandRewardPackBaseDao.gid2packs
	local gid2pack_probas = RandRewardPackBaseDao.gid2pack_probas
	local gid2baodi_packs = RandRewardPackBaseDao.gid2baodi_packs
	local sid2pack_probas = RandRewardPackBaseDao.sid2pack_probas
	
	for i, csv_db in pairs(csv_data) do
		local group_id, id, proba, prof, scene_id = csv_db.group_id, csv_db.id, csv_db.proba, csv_db.prof, csv_db.scene_id
		assert(group_id)
		assert(proba)
		
		local id2pack = gid2packs[group_id] or {}
		gid2packs[group_id] = id2pack
		id2pack[id] = csv_db
		RandRewardPackBaseDao:recombinData(gid2pack_probas, csv_db, group_id, id, proba, prof)
		
		if csv_db.is_baodi == 1 then
			local prof2baodi_packs = gid2baodi_packs[group_id] or {}
			gid2baodi_packs[group_id] = prof2baodi_packs
		
			local baodi_packs_xz = prof2baodi_packs[CharacterDefs.PROF_ID_FOR_XUEZHU] or {}
			local baodi_packs_fs = prof2baodi_packs[CharacterDefs.PROF_ID_FOR_ZHAOHUANSHI] or {}
			local baodi_packs_zs = prof2baodi_packs[CharacterDefs.PROF_ID_FOR_ZHANSHI] or {}
			prof2baodi_packs[CharacterDefs.PROF_ID_FOR_XUEZHU] = baodi_packs_xz
			prof2baodi_packs[CharacterDefs.PROF_ID_FOR_ZHAOHUANSHI] = baodi_packs_fs
			prof2baodi_packs[CharacterDefs.PROF_ID_FOR_ZHANSHI] = baodi_packs_zs
			
			if prof == 0 or prof == CharacterDefs.PROF_ID_FOR_NONE then
				baodi_packs_xz[#baodi_packs_xz+1] = csv_db
				baodi_packs_fs[#baodi_packs_fs+1] = csv_db
				baodi_packs_zs[#baodi_packs_zs+1] = csv_db
			else
				table.insert(prof2baodi_packs[prof], csv_db)
			end
		end
		
		if scene_id and scene_id > 0 then
			local gid2pack_probas2 = sid2pack_probas[scene_id] or {}
			sid2pack_probas[scene_id] = gid2pack_probas2
			RandRewardPackBaseDao:recombinData(gid2pack_probas2, csv_db, group_id, id, proba, prof)
		end
	end
end

function RandRewardPackBaseDao:recombinData(gid2pack_probas, csv_db, group_id, id, proba, prof)
	local prof2pack_probas = gid2pack_probas[group_id] or {}
	gid2pack_probas[group_id] = prof2pack_probas
	
	local pack_probas_xz = prof2pack_probas[CharacterDefs.PROF_ID_FOR_XUEZHU] or {}
	local pack_probas_fs = prof2pack_probas[CharacterDefs.PROF_ID_FOR_ZHAOHUANSHI] or {}
	local pack_probas_zs = prof2pack_probas[CharacterDefs.PROF_ID_FOR_ZHANSHI] or {}
	prof2pack_probas[CharacterDefs.PROF_ID_FOR_XUEZHU] = pack_probas_xz
	prof2pack_probas[CharacterDefs.PROF_ID_FOR_ZHAOHUANSHI] = pack_probas_fs
	prof2pack_probas[CharacterDefs.PROF_ID_FOR_ZHANSHI] = pack_probas_zs
	
	local pack_proba = {id, proba}
	if prof == 0 or prof == CharacterDefs.PROF_ID_FOR_NONE then
		pack_probas_xz[#pack_probas_xz+1] = pack_proba
		pack_probas_fs[#pack_probas_fs+1] = pack_proba
		pack_probas_zs[#pack_probas_zs+1] = pack_proba
	else
		table.insert(prof2pack_probas[prof], pack_proba)
	end
end