--[[
道具基础数据系统Dao，用于数据管理
author : xingzeng
date : 2012-03-27
]]--

EquipBaseDao = {
	data = {}, 		-- 存储道具基础数据，格式 : {id => obj, ...}
	functype2eid = {},	-- 道具功能类型到道具ID映射表 (eg : {[sort_id]={eid,...}})
	
}

-- 格式化道具数据
function EquipBaseDao:loadFromCsv(csv_data)
	local data = self.data
	local functype2eid = self.functype2eid
	local eid2price_gold = self.eid2price_gold
	
	-- 存储equip数据
	for _, equip_db in pairs(csv_data) do
		local equip_id = tonumber(equip_db.id)
		
		local equip_base = data[equip_id]
		
		if equip_base == nil then
			equip_base = EquipBase:new()
		end
		
		equip_base:init(equip_db)
		data[equip_id] = equip_base
		
		--- 功能道具
		--[[ 元宝价格改用从language_price.lua中获取
		local key = string.format('e%d', equip_base.id)
		local price_gold = LanguagePrice[key] and LanguagePriceFunc:getPrice(key) or 0
		equip_base._price_gold = price_gold
		--]]
		
		if not EquipDefs:isZhuangBei(equip_base.equip_sort_id) and equip_base.function_type > 0 then
			local function_type = equip_base.function_type
			local eids = functype2eid[function_type]
			if not eids then
				eids = {}
				functype2eid[function_type] = eids
			end
			eids[#eids+1] = equip_base.id
		end
	end

end
