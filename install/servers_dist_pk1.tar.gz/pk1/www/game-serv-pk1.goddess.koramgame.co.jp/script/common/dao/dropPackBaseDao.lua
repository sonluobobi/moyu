
DropPackBaseDao = {}

function DropPackBaseDao:loadFromCsv(csv_data)
	for i, csv_db in pairs(csv_data) do
		DropPackBaseDao[csv_db.id] = csv_db
	end
end

