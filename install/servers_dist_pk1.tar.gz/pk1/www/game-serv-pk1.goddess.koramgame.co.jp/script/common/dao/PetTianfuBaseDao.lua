--[[
幻兽天赋基础数据Dao
author : xingzeng
date : 2012-03-27
]]--

PetTianfuBaseDao = {
	data = {}, 		-- {id => obj, ...}
	
}

-- 格式化道具数据
function PetTianfuBaseDao:loadFromCsv(csv_data)
	local data = self.data
	
	-- 存储equip数据
	for _, csv_db in pairs(csv_data) do
		--csv_db.effect_params = {effect_value1=csv_db.effect_value1,effect_value2=csv_db.effect_value2,effect_value3=csv_db.effect_value3}
		data[csv_db.id] = csv_db
	end
end
