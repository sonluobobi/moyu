--[[
玩法双倍系统 dao
author : jianzhu
date : 2016-11-18
--]]

WanfaRewardDoubleDao = {
	--玩法类型对应时间访问配置 {1 = {'2016-07-09', '2016-07-12'}, 2= {'2016-07-09', '2016-07-12'}}
	wanfa_type_date_config_map ={}
}

--更新内存玩法双倍数据
function WanfaRewardDoubleDao:sync_data(data)
	local wanfa_type = data.wanfa_type and UNumber.str2Int(data.wanfa_type) or nil
	local start_time = data.start_time or nil
	local end_time = data.end_time or nil

	if not wanfa_type or not start_time or not end_time then return end

	local date_config = {}
	date_config[1] = start_time
	date_config[2] = end_time

	self.wanfa_type_date_config_map[wanfa_type] = date_config
end

--获取指定玩法，对应的配置信息
function WanfaRewardDoubleDao:get_wanfa_type_date_config(wanfa_type)
	local ret = nil 
	local wanfa_type_date_config_map = self.wanfa_type_date_config_map

	if wanfa_type and wanfa_type_date_config_map[wanfa_type] then 
		ret = wanfa_type_date_config_map[wanfa_type]
	end

	return ret
end
