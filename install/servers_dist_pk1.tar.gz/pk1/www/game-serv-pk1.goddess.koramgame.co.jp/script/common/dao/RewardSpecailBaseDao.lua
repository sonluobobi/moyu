--[[
特殊奖励数据 Dao
author : xingzeng
date : 2012-03-27
]]--

RewardSpecialBaseDao = {
	data = {},					--奖励列表 data[reward_id] = RewardSpecialBase
	sort2reward_ids = {},			--sort2reward[sort_id] = {reward_ids}
	maincards = {},				--主卡列表 data[reward_id] = RewardSpecialBase
}

function RewardSpecialBaseDao:loadFromCsv(csv_data)
	local data, maincards = self.data, self.maincards
	local sort2reward_ids = self.sort2reward_ids
	
	for _, reward_specail_db in pairs(csv_data) do
		local reward_id = reward_specail_db.id
		data[reward_id] = reward_specail_db
		
		if reward_id < RewardSpecialDefs.REWARD_SPECIAL_ID_SUB_CARD then
			maincards[reward_id] = reward_specail_db
		end
		
		local sort_id = reward_specail_db.sort_id
		local reward_ids = sort2reward_ids[sort_id] or {}
		sort2reward_ids[sort_id] = reward_ids
		reward_ids[#reward_ids+1] = reward_id
	end
end
