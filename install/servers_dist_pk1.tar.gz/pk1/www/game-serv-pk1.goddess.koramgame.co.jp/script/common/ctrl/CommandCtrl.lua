--[[
通用命令行
author : xingzeng.jiang
date : 2014-07-15
--]]

CommandCtrl = CommandCtrl or {}
LuaCommand  = 
{
	DUMP_VALUE = 'DUMP_VALUE',
	
}
local LuaCommand = LuaCommand 

local WorldPacket = WorldPacket
local Utils = Utils
local ret_opcode = opCodes.W2B_MSG_NO_PLR_DO_COMMAND
local SERVER_NAME = SERVER_NAME
local i_opHandlers = i_opHandlers._handlers

do
	local JsonString = JsonString
	local docompress = cjson.docompress
	local print_r = print_r
	function CommandCtrl:getDumpVar(gcid,data,sid)
		
		local serv = data.serv
		local pwd = data.pwd
		local depth = data.depth
		local v = Utils.dir2v(pwd)
		
		local dump_str = print_r(v,depth,1)
		local full_pwd = serv .. '/' .. pwd
		
		if SERVER_NAME == 'dbserver' then
			local ret_data = {}
			ret_data.full_pwd = full_pwd
			ret_data.dump_str = dump_str
			ServerCall:d2xCall(sid,'CommandCtrl:d2bGetDumpVar', 0, ret_data)
			return
		end		
		
		local pack = WorldPacket:newPacket(ret_opcode)		
		pack:writeString(LuaCommand.DUMP_VALUE)		
		pack:writeString(full_pwd)
		local js = JsonString(dump_str,#dump_str)
		docompress(js)
		pack:writeCString(js)
		if SERVER_NAME == 'baseserver' then
			WorldPacket:b2cSendPacket(pack)
		else
			WorldPacket:m2cSendPacket(pack)
		end				
	end
end


do
    --获取系统开服时间
    function CommandCtrl:loadServerOpenDate()
        local params = {}
        params.id = OneInfoDefs.ID_SERVEROPENDATE_INFO
        params.callback = 'CommandCtrl:x2d_onLoadServerOpenDate'
        ServerCall:b2dCall_0('OneInfoService:x2d_getInfo', 0, params)
    end
    
    function CommandCtrl:x2d_onLoadServerOpenDate(_, params)
        --table.dump("data,,,,",params)
        local data = params.info
        CommandCtrl:__serverOpenDateRule(data)
        self:sync2map()    
    end
    
    function CommandCtrl:__serverOpenDateRule(data)
        if not data or data == "" then 
            Config.SERVER_OPEN_DATE_INT =external.getOpenDate() or Time:getDateNow() 
        else
            local intdata = data + 0
            if intdata>20000000 and intdata < 30000000 then
                Config.SERVER_OPEN_DATE_INT = intdata     
            else
                Logger:error("x2d_onLoadServerOpenDate 数据有误使用默认配置",data,intdata)
                Config.SERVER_OPEN_DATE_INT =external.getOpenDate()
            end              
        end
    end
    
    function CommandCtrl:sync2map()
        ServerCall:b2mCalltToAllMap('CommandCtrl:b2m_syncData', {Config.SERVER_OPEN_DATE_INT})    
    end
    
    function CommandCtrl:b2m_syncData(_, data )
        if data and data[1] then
            local intdata = data[1] + 0
            Config.SERVER_OPEN_DATE_INT =  intdata
        else
            Logger:error("b2m_syncData 数据有误",data)
        end
    end
    
    -- "2012-05-31 13:04:03"
    function CommandCtrl:setServerOpenDate(datestring)     
        --print("datestring",datestring)   
        if datestring then
            local secs = Time:getSecondsByDateTimeStr( datestring )
            local opendatestr = os.date("%Y%m%d",secs)
            local opendate = opendatestr + 0
            if opendate>20000000 and opendate < 30000000 then
                --print("opendata,",opendatestr,opendate)
                Config.SERVER_OPEN_DATE_INT = opendate
                self:sync2map() 
                local params = {}
                params.id = OneInfoDefs.ID_SERVEROPENDATE_INFO
                params.info = opendatestr
                ServerCall:b2dCall_0('OneInfoService:x2d_saveInfo', 0, params)
            else
                Logger:error("配置开服时间有误",datestring,opendate)
            end    
        else
            Logger:error("配置开服时间有误",datestring)
        end    
    end
    
    --"只db调用"
    function CommandCtrl:db_getServerOpenDate()
        local info = OneInfoService:getInfo( OneInfoDefs.ID_SERVEROPENDATE_INFO )
        CommandCtrl:__serverOpenDateRule(info)
    end
    
end



do
    function CommandCtrl:setGameServersConfigNotValid()
        local ret = Utils.setGameServersConfigNotValid()
        if not ret then return ret end
        --成功
        Utils.__realGetGameServersConfig("PKServers")
        --Logger:error("bbbsssss:",Config.GAMESERVERS_CACHES["PKServers"])
        ServerCall:b2mCalltToAllMap('CommandCtrl:b2m_syncGameServerConfigData', {data=Config.GAMESERVERS_CACHES["PKServers"]})
        return ret        
    end 
    
    function CommandCtrl:b2m_syncGameServerConfigData(_, data )
        --Utils.setGameServersConfigNotValid()
        --Logger:error("tomap set valid!!",data)
        if data.data then
            Config.GAMESERVERS_CACHE_VALID["PKServers"] = true
            Config.GAMESERVERS_CACHES["PKServers"] = data.data
        end
    end
        
end


------------游戏服pk,语音，中心是否正常的测试逻辑 begin-----------------

do
    local serverStatus={["pk"]=false,["center"]=false,["vchat"]=false}
    local gpacketdata = {}
    
    function CommandCtrl.returnServerTestData()
        local oldpakid = WorldPacket.g_packet_id
        local oldwebpid =  WorldPacket.g_webproxy_packet_id
        
        WorldPacket.g_webproxy_packet_id = gpacketdata.g_webproxy_packet_id
        WorldPacket.g_packet_id = gpacketdata.g_packet_id
        WorldPacket:baseRspRpc(RpcDefs.RPC_RSP_CODE_ID_OK, '当前服务器状态:',serverStatus)
        
        WorldPacket.g_webproxy_packet_id = oldwebpid
        WorldPacket.g_packet_id = oldpakid
    end
    
    -- 定时触发下一步
    function CommandCtrl.serverTestTimer()     
        Logger:error("当前服出错",serverStatus.cur)   
        if serverStatus.cur=="pk" then
            serverStatus.pk = false
            serverStatus.cur="center"
            CommandCtrl:serverConnectTestG2Center()
        elseif serverStatus.cur=="center" then
            serverStatus.center = false
            serverStatus.cur="vchat"
            CommandCtrl:serverConnectTestG2Vchat()
        elseif serverStatus.cur=="vchat" then
            serverStatus.vchat = false
            serverStatus.cur = nil
            serverStatus.timerid = nil
            --回webproxy
            --Logger:error("return到webproxy",serverStatus)
            return CommandCtrl.returnServerTestData()
        end
        CommandCtrl:addServerTestTimer()    
    end
    i_opHandlers[opCodes.T2B_SERVER_TEST_RET] = CommandCtrl.serverTestTimer
    
    function CommandCtrl:addServerTestTimer()
        local pack_data={}
        pack_data.opcode = opCodes.T2B_SERVER_TEST_RET
        local timerid = WorldPacket:addTimer(pack_data, 1800, 1)    --1800毫秒未返示表示已出错
        serverStatus.timerid = timerid
    end
    
    function CommandCtrl:serverTestTimerReset()
        if serverStatus.timerid then
            WorldPacket:delTimer(serverStatus.timerid)
            serverStatus.timerid = nil
        end
    end
    
    function CommandCtrl:serverConnectTestG2pk()
        serverStatus.timestamp = serverStatus.timestamp or 0
        if Time.time_second-serverStatus.timestamp <= 60 then --60秒缓存
            --Logger:error("返回本地的",Time.time_second,serverStatus.timestamp ,Time.time_second-serverStatus.timestamp )
            return WorldPacket:baseRspRpc(RpcDefs.RPC_RSP_CODE_ID_OK, '当前服务器状态：', serverStatus)
        end
        gpacketdata.g_webproxy_packet_id = WorldPacket.g_webproxy_packet_id
        gpacketdata.g_packet_id = WorldPacket.g_packet_id
        
        serverStatus={["pk"]=false,["center"]=false,["vchat"]=false}
        
        serverStatus.timestamp = Time.time_second 
        serverStatus.cur="pk"
        
        --发测试到pk服
        local opcode = opCodes.B2PKB_SERVER_TEST
        local arr_params = {aid=Config.GAME_AREA_CODE}
        WorldPacket:base2PkBaseSendPack(Statics.PK_SERVER_TYPE_ID_FOR_GAME, opcode, arr_params, nil, 0)     
        CommandCtrl:addServerTestTimer()
    end 
    
    function CommandCtrl:serverConnectTestG2Center()
        --发测试到center服
        local opcode = opCodes.B2CB_SERVER_TEST
        local arr_params = {aid=Config.GAME_AREA_CODE}
        WorldPacket:base2PkBaseSendPack(Statics.PK_SERVER_TYPE_ID_FOR_CENTER, opcode, arr_params, nil, 0)     
    end 
    
    function CommandCtrl:serverConnectTestG2Vchat()
       --发测试到vchat服
        local opcode = opCodes.B2VB_SERVER_TEST
        local arr_params = {aid=Config.GAME_AREA_CODE}
        WorldPacket:base2PkBaseSendPack(Statics.PK_SERVER_TYPE_ID_VOICE_CHAT, opcode, arr_params, nil, 0)     
    end 
    
    
    ---跨服处理的包
    function CommandCtrl.B2PKB_SERVER_TEST(_, packet)
        local arr_params = packet:readParams()
        --Logger:error("B2PKB_SERVER_TEST:",arr_params)
        local aid = arr_params.aid
        local gpid = external.mergeUInt(aid, 0)
        WorldPacket:pkServer2GameSendPack(opCodes.PKB2B_SERVER_TEST, gpid, {})
    end
    i_opHandlers[opCodes.B2PKB_SERVER_TEST] = CommandCtrl.B2PKB_SERVER_TEST
    
    function CommandCtrl.B2CB_SERVER_TEST(_, packet)
        local arr_params = packet:readParams()
        Logger:error("B2CB_SERVER_TEST:",arr_params)
        local aid = arr_params.aid
        local gpid = external.mergeUInt(aid, 0)
        WorldPacket:pkServer2GameSendPack(opCodes.CB2B_SERVER_TEST, gpid, {})
    end
    i_opHandlers[opCodes.B2CB_SERVER_TEST] = CommandCtrl.B2CB_SERVER_TEST
    
    function CommandCtrl.B2VB_SERVER_TEST(_, packet)
        local arr_params = packet:readParams()
        --Logger:error("B2VB_SERVER_TEST:",arr_params)
        local aid = arr_params.aid
        local gpid = external.mergeUInt(aid, 0)
        WorldPacket:pkServer2GameSendPack(opCodes.VB2B_SERVER_TEST, gpid, {})
    end
    i_opHandlers[opCodes.B2VB_SERVER_TEST] = CommandCtrl.B2VB_SERVER_TEST
    
    
    ---到游戏服的包
    function CommandCtrl.PKB2B_SERVER_TEST(_, data )
        CommandCtrl:serverTestTimerReset()
        --Logger:error("当前服成功1",serverStatus.cur)  
        serverStatus.cur="center"
        serverStatus.pk = true
        CommandCtrl:serverConnectTestG2Center()
        CommandCtrl:addServerTestTimer()  
    end
    i_opHandlers[opCodes.PKB2B_SERVER_TEST] = CommandCtrl.PKB2B_SERVER_TEST
    
    
    function CommandCtrl.CB2B_SERVER_TEST(_, data )
        CommandCtrl:serverTestTimerReset()
        --Logger:error("当前服成功2",serverStatus.cur)
        serverStatus.cur="vchat"
        serverStatus.center = true
        CommandCtrl:serverConnectTestG2Vchat()
        CommandCtrl:addServerTestTimer()  
    end
    i_opHandlers[opCodes.CB2B_SERVER_TEST] = CommandCtrl.CB2B_SERVER_TEST
    
    function CommandCtrl.VB2B_SERVER_TEST(_, data )
        CommandCtrl:serverTestTimerReset()
        --Logger:error("当前服成功3",serverStatus.cur)
        serverStatus.cur=nil
        serverStatus.vchat = true
        return CommandCtrl.returnServerTestData() 
    end
    i_opHandlers[opCodes.VB2B_SERVER_TEST] = CommandCtrl.VB2B_SERVER_TEST
    
        
end

------------游戏服pk,语音，中心是否正常的测试逻辑 end  -----------------






