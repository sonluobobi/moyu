--[[
情侣系统 entity
author : jianzhu
date : 2016-04-08
--]]

Lovers = {
	------------------------ 数据表结构 start -----------------------
	apply_cid = 0, --求婚者cid
	agree_cid = 0, --同意者cid
	marry_time = 0, --结婚时间
	divorce_status = 0, --离婚状态
	divorce_apply_time = 0, --离婚或者申请离婚时间
	divorce_apply_cid = 0, --提出离婚者cid
	divorce_cancel_cid = 0, --离婚取消者cid
	is_force_divorce = 0, --是否强制离婚
	is_agree_divorce = 0, --是否主动同意离婚

	------------------------ 数据表结构 end -----------------------
	marry_apply_time = 0, --求婚时间
	marry_target_cid = 0, --求婚对象
	is_fetched_gift = false, --是否已领取过结婚礼物 type:bool
}

--非数据库属性
local no_db_lovers_field = {
	'marry_apply_time',
	'marry_target_cid',
	'is_fetched_gift',
}

LoversForDB = Utils.genDBEntity(Lovers, no_db_lovers_field)

LoversInfo = {
	lover_cid = 0, --情侣cid
	lover_unique_key = '', --情侣全局唯一id
	lover_nick = '', --情侣昵称
	marry_time = 0, --结婚时间
	appear = '', -- 外观相关

	divorce_status = 0, --离婚状态
	divorce_timeout_time = 0, --离婚或超时时间
	divorce_req_cid = 0, --发起离婚求婚者cid
	divorce_cancel_cid = 0, --离婚取消者cid
	is_force_divorce = false, --是否强制离婚 type:bool
	is_agree_divorce = false, --是否主动同意离婚 type:bool

	marry_gifts = '', --新婚礼物
	is_fetched_gift = false, --是否已领取过结婚礼物 type:bool
}