--[[
幻兽天赋数据
author : xingzeng
date : 2015-08-31
--]]

PetTianfuBase = {
	id = 0,						-- 天赋ID	__kn
	sort_id = 0,				-- 天赋类型(0:普通， 1:buffer类)
	heti_active_sort = 0,		-- 合体幻兽天赋激活类型(0：活的时候激活，1：活且为受击者时激活)
	
	effect_type = '',			-- 增加的效果类型
	effect_value1 = 0,			-- 增加的效果值1	type:double
	effect_value2 = 0,			-- 增加的效果值2(不支持累加)	type:double
	effect_value3 = 0,			-- 增加的效果值3(不支持累加)	type:double
	effect_value4 = 0,			-- 增加的效果值4(不支持累加)	type:double
	
	buffer_id = 0,				-- 触发的BUFFER ID
	
	is_leijia_effect_value1 = 0,-- effect_value1效果值是否可累加 (0:effect_value1不可累加，1：effect_value1可累加)
	is_dead_trigger = 0,		-- 是否在死亡时触发(0:活的时候触发， 1：死的时候触发)
	texiao_id = 0,				-- 天赋特效ID
	is_effect_all = 0,			-- 是否作用所有亲戚对象(主人，召唤兽，出战幻兽)
	fight_capacity = 0,			-- 天赋的战力
	
	title = '',					-- 天赋名称
	intro = '',					-- 描述模版  (eg:暴击率+<effect_value1*100>%, 攻击+<effect_value1>~<effect_value2>)
}

