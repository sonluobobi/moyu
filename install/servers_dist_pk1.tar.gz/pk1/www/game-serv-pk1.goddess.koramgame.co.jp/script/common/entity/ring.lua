--[[
魅力活动
author: liujinlin
date: 2016-05-16
]]--

--db中数据
Ring = {
	level = 0,
	active_indexes = {},
	tupostatus = 1,
	status = 2,
	added_attr = {},--增加的属性，属性名字从character取
	weid = 0,--戴的戒指id
}

function Ring:new(level,status)
  local o = {}
  o.level = level
  o.active_indexes = {}
  o.tupostatus = 1
  o.status = status 
  return o
end

--配置数据
RingUpgrade = {

  --id__kn,name__s,kill_force,kill_force_tupo,upgrade_cost,upgrade_tupocost,upgrade_equip__t
  id = 0,
  name = '',  --名字  
  kill_force = 0,
  kill_force_tupo = 0,
  upgrade_cost = 0,
  upgrade_tupocost = 0,
  upgrade_equip={}, --升星需要的材料{[1]={[10012001]={num=4,vit=200}}}} type:ArrayList
                    --索引位置对应客户端材料的摆放位置，num表示需要多少个,vit表示加血多少,vit这样的字段从character结构里面找
}

function RingUpgrade:new(id,name,kill_force,kill_force_tupo,upgrade_cost,upgrade_tupocost,upgrade_equip)
  local o={}
  o.id=id
  o.name=name  --名字
  o.kill_force=kill_force --斩杀力
  o.kill_force_tupo=kill_force_tupo
  o.upgrade_cost=upgrade_cost
  o.upgrade_tupocost=upgrade_tupocost
  o.upgrade_equip=upgrade_equip
  return o
end

