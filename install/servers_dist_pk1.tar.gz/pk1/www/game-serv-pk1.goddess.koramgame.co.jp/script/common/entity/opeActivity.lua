--[[
活动属性表实体

@author : xingzeng jiang
@create : 2012-12-22
]]--

OpeActivity = 
{
    id = 0,							--活动ID号
	activity_sort_id = 0,			--活动分类ID
	title = '',						--活动名
	order_by = 0,					--排位号(越大越排后面,支持负数)
	opeact_time_type = 0,			--活动时间类型 (0: 活动后台录入的时间，1：固化活动开启时间，2：创建角色时间）
	
	--时间范围
	start_time = '',				--活动开始时间("年:月:日 时:分:秒")
	end_time = '',					--活动结束时间("年:月:日 时:分:秒")
	c__stime_sec = 0,					--活动开始时间(时间戳 供客户端使用)
	c__etime_sec = 0,					--活动结束时间(时间戳 供客户端使用)
	
	res_id = '',		   			--资源ID
	c__func_open_id = 0,			--功能开关ID
	
	intro = '',						--活动描述
	created = '',					--创建时间
	updated = '',					--更新时间
}
OpeActivity.__index = OpeActivity

function OpeActivity:new(pool, data)
	local o = pool or {}
	
	for key, value in pairs(data) do
		if self[key] and value ~= self[key] then
			o[key] = value
		end
	end
	
	setmetatable(o, self)
	
	return o
end

OpeActivityFixBase = 
{
	id = 0,
	activity_sort_id = 0,
	title = '',
	intro = '',
}
