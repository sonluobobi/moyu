--[[
道具基本属性信息，csv结构
author : xingzeng
date : 2014-08-14
--]]

EquipBase = {
	id = 0,					-- 道具CLASS ID(基础ID)
	
	----------------------------- 基础属性 start -------------------------------
	equip_sort_id = 0,		-- 类型ID
	sub_sort_id = 0,		-- 子类型ID
	
	title = '',				-- 道具名
	stack_num = 0,			-- 最大堆叠数
	res_id = '',			-- 3d资源ID列表(时装会分男女资源)
	pic_id = 0,				-- 2d图标ID
	res_direction_y = 0,	-- 模型 y 旋转, 角度值
	model_times = 0,		-- 模型倍数, type:float
	gs_model_times = 0,		-- 在场景内跟随主角显示的模型倍数, type:float
	
	prof = 0,				-- 所属职业
	is_bind = 0,			-- 0:初始绑定， 1：初始不绑定 (绑定代表不可交易)
	is_protect = 0,			-- 是否死亡保护(不会掉落)
	is_recycle = 0,			-- 是否可回收给系统商店
	sale_price = 0,			-- 卖出价格 （银两）
	quality = 0,			-- 品阶颜色 (0, 1，2，3，4 对应 白绿蓝紫金)
	need_trace = 0,			-- 是否跟踪
	package_type = 0,		-- 包裹标签分类：1为贵重、2为装备、3为强化、4为药品、5为侠客、6 其他
	rank_weight = 0,		-- 排序权重， 权重越大，越排靠前
	gang_storage_price = 0,	-- 军团仓库的获得的帮贡（填0或者不填表示不能放到军团仓库中）
	aptitude = 0,			-- 资质
	juewei_level = 0,		-- 爵位等级
	random_param = nil,		-- 机率刷道具刷出的机率参数
	is_bc_opened = 0,		-- 随机宝物刷出此道具时，是否需要广播
	is_bc_gift = 0,			-- 是否需要广播的随机道具

	intro = '',				-- 简介
	----------------------------- 基础属性 end -------------------------------
	
	--------------------------- 道具相关属性 start ---------------------
	is_use = 0,				-- 是否可直接使用
	is_use_batch = 0,		-- 是否可批量使用
	is_use_when_get = 0,	-- 是否获得的时候自动使用
	ch_level = 0,			-- 道具使用角色等级要求
	ch_level_max = 0,		-- 最大使用等级
	trade_max_price = 0,	-- 交易最大价格上限(用于海外版本)
	
	--功能道具属性
	function_type = 0,		-- 功效类型
	function_value1 = 0,	-- 功效值1
	function_value2 = false,-- 功效值2 type:Hashtable
	
	buffer_ids = false,		-- 时限性道具BUFFER ID串(eg:{343,454,466})		type:Hashtable
	use_type = 0,			-- 消耗类型(0为实时性，1为时效性。平台接口需要)
	useful_time = 0,		-- 有效时长（分钟为单位）
	
	rebate_rate = 0,		-- 折扣系数(最终价格为原始价格乘以此系数)   //type:float

	chip_mix_eid = 0,		-- 该碎片合成后的玩家装备ID
	
	baowu_chip_rob_player_proba = 0,-- 幻兽宝物碎片抢夺玩家的概率 (基数100)
	baowu_chip_rob_robot_proba = 0,-- 幻兽宝物碎片抢夺机器人的概率 (基数100)
	baowu_equip_id = 0,		-- 宝物碎片对应的宝物道具ID
	baowu_chip_orderby = 0,	-- 宝物碎片排位编号
	open_function_id = 0,	-- 相关的游戏功能ID(定义见OpenFuncDefs.lua)
	--------------------------- 道具相关属性 end ---------------------
	
	----------------------------- 装备相关属性 start -------------------------------
	base_effect_values = false,-- 基础属性初值(eg:{max_hp=34,duozhi=3})	type:Hashtable
	addi_effect_values = false,-- 附加属性	type:ArrayList
	grow_values = false,	-- 成长值	type:Hashtable
	suit_id = 0,			-- 套装ID
	need_chips = false,		-- 合成该装备需要的碎片数量 type:Hashtable eg:{[20110332]=3,[20110331]=2}
	add_pet_exp = 0,		-- 被幻兽吞噬所加的经验值
	
	--翅膀相关属性
	figure_list = false,		-- 翅膀道具使用后可获得的外形列表 {eg:{1,...}}	//type:int[]
	base_exp = 0,				-- 基础经验值	
	
	--- 宝物相关属性
	upgrade_exp_base = 0, 		--升级需要的经验基础值（0-1只需要此经验即可）
	upgrade_exp_add = 0, 		--升级需要的经验增加值（每升一级，所需要经验在上一级基础上加上此值)
	level_addi_effect_values = false,	--特定等级属性加成 {[30] ={max_hp=34}..}	type:Hashtable
	max_level = 0,				--最高等级
	bw_base_exp = 0,			-- 宝物基础经验值
	fate_title = '',			--缘份描述(比如XX幻兽专属)
	need_baowu_chip_ids = false,-- 合成需要的幻兽宝物碎片道具ID列表	type:Hashtable
	rob_baodi_times = 0,		-- 抢夺该宝物的保底次数
	
	is_normal_zb = 0,			-- 是否常规装备
	----------------------------- 装备相关属性 end -------------------------------
	
	----------------------------- 宝石相关属性 start -------------------------------
	jewel_level = 0,		-- 宝石级别
	jewel_value = 0,		-- 宝石加成效果值
	jewel_value2 = 0,		-- 宝石加成效果值2
	ext_fight_capacity = 0,	-- 宝石额外增加的战力
	----------------------------- 宝石相关属性 end -------------------------------
	
	----------------------------- 幻兽女神相关属性 (fuqian.liao) start -------------------------------
	goddess_base_id = 0,		--碎片可合成的女神ID
	pet_base_id = 0,		--碎片可合成的幻兽ID
	need_chip_num = 0,		--合成该幻兽需要的碎片数量
	----------------------------- 幻兽女神相关属性 (fuqian.liao) end -------------------------------

	spirit_sort_id = 0,			-- 精灵类型
	spirit_main_num = 0,		-- 精灵主属性条数
	spirit_effect_id = 0,		-- 精灵主属性类型
	spirit_pic_id = 0,			-- 精灵圆图标ID
	
	tstar_pet_sort_id = 0,				--双星装备幻兽类型
	tstar_addi_effect_values = false,	--双星装备幻兽加成效果 eg:{dodog=xx,luck=xx} type:Hashtable
	
}
EquipBase.__index = EquipBase

-- 客户端不需要的字段(生成的.cs文件里面的EquipBase类不会含下面字段)
EquipBase__noclient = {
	is_protect=1,
	need_trace=1,
	random_param=1,
	buffer_ids=1,
	baowu_chip_rob_player_proba=1,
	use_type=1,
	baowu_chip_rob_robot_proba=1,
	upgrade_exp_base=1,
	upgrade_exp_add=1,
	rob_baodi_times=1,
}

-- 装备、道具、宝石子类 (提供客户端使用)
EquipBSBase = {	--base:EquipBase
}
EquipDJBase = {	--base:EquipBase
}
EquipZBBase = {	--base:EquipBase
}
EquipBWBase = {	--base:EquipBase
}
EquipCBBase = { --base:EquipBase
}
EquipSpiritBase = { --base:EquipBase
}
EquipTowStarBase = { --base:EquipBase
}


--- 装备的属性
EquipAttrEffect = {
	max_hp = 0,					-- 最大血量
	max_attack = 0;				-- 最大攻击
	min_attack = 0;				-- 最小攻击
	defence_phy = 0;			-- 物理防御
	defence_magic = 0;			-- 法术防御
	douzhi = 0;					-- 斗志
	critical_hit = 0;			-- 暴击
	dodge = 0;					-- 闪避
	parry = 0;					-- 格挡
	addi_harm = 0;				-- 附伤 附加伤害绝对值
	reduce_harm = 0;			-- 减伤：降低伤害绝对值
	kill_force = 0;				-- 斩杀力
	luck = 0;					-- 幸运
}

-- 包裹类型表(提供客户端使用)
PackageType = {
	id = 0,			-- 包裹类型ID	(当parent_id=0的时候，该字段则代表是父类型ID)
	parent_id = 0,	-- 包裹父类型ID
	title = '',		-- 包裹类型名
	pic = 0,		-- 包裹类型图片资源ID
}

-- 创建基础道具对象
function EquipBase:new()
	local o = {}
	setmetatable(o, self)
	
	return o
end

local table = table
local isTableEmpty=table.isTableEmpty

function EquipBase:init(equip_db)
	for key, value in pairs(equip_db) do
		-- 基类值为nil，代表是table类型的字段
		if not self[key] then
			if not isTableEmpty(value) then
				self[key] = value
			end
		elseif value ~= self[key] then
			self[key] = value
		end
	end
	
	-- 时装特殊处理
	if equip_db.equip_sort_id == EquipDefs.EQUIP_SORT_ID_AVATAR and not self.base_effect_values then
		self.base_effect_values = {}
	end
end
