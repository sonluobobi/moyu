--[[
魅力活动
author: liujinlin
date: 2016-02-18
]]--

Charm = {
	cid = 0,	--角色ID
	nick = '',  --玩家名称
	charm_value = 0, --魅力值
	rank = 0, --排名
	old_rank = 0, --之前排名
	join_time = '',--报名时间
	activity_time = '', --活动时间
	voicekey = '', --语音key		
	dt = '', --最新的几条动态
	voicechangetime = ''
}

CharmLarge = {
  cid = 0,  --角色ID
  nick = '',  --玩家名称
  charm_value = 0, --魅力值
  rank = 0, --排名
  old_rank = 0, --之前排名
  join_time = '',--报名时间
  activity_time = '', --活动时间
  voicekey = '', --语音key  
  voicechangetime = '',
  dt = '', --最新的几条动态
  prof = 0, --职业
  gender = 0, --性别
}

CharmLog = {
  give_cid = 0, --送花玩家id
  recv_cid = 0, --得到花的玩家id
  itemid = 0, --道具id
  charm_ch = 0, --魅力值变化
  give_time = '', --赠送时间
  flower_num = 0, --鲜花数目
  activity_time = '', --活动时间区分某一次活动
}

CharmReward = {
  id = 0, --排名奖励id
  rankb = 0, --开启名次
  ranke = 0, --结束名次
  desc = '', --描述
  reward = '', --奖励数据
}

CharmRecord = {
  type = 0, --类型1表示送花记录，2收花记录，3报名动态,4修改语音动态,5魅力值到达,6收到玫瑰
  nick = '', --昵称(1,2,6)
  num = 0, --数目(1,2,5,6)
  change = 0, --魅力值变化(1,2)
  time = '', --某个时间送或者收花(1,2)
  voicekey = 0, --key(3,4)
  itemid = 0, --(1,2)
}

CharmRecordDB = {  
  nick = '', --昵称(1,2,6)
  num = 0, --数目(1,2,5,6)
  change = 0, --魅力值变化(1,2)
  time = '', --某个时间送或者收花(1,2)
  voicekey = '', --key(3,4)
  itemid = 0,
}

function Charm:new(cid,nick)
  local o = {}
  o.cid = cid
  o.nick = nick
  return o
end

function CharmLog:new()
  local o = {}
  o.give_cid = 0
  o.recv_cid = 0
  o.itemid = 0
  o.charm_ch = 0
  o.give_time = ''
  o.flower_num = 0
  o.activity_time = ''
  o.created = ''
  return o  
end

function CharmRecord:new(type,nick,num,change,time,voicekey,itemid)
  local o = {}
  o.type = type
  o.nick = nick
  o.num = num
  o.change = change
  o.time = time
  o.voicekey = voicekey
  o.itemid = itemid
  return o
end

function CharmLarge:new(cid,nick,prof,gender)
  local o = {}
  o.cid = cid
  o.nick = nick
  o.charm_value = 0
  o.rank = 0
  o.old_rank = 0
  o.join_time = ''
  o.voicekey = ''
  o.prof = prof
  o.gender = gender
  return o
end

function Charm:new(cid,nick)
  local o = {}
  o.cid = cid
  o.nick = nick
  o.charm_value = 0
  o.rank = 0
  o.old_rank = 0
  o.join_time = ''
  o.voicekey = ''
  return o
end


