--[[
幻兽基础数据
author : xingzeng
date : 2014-10-11
--]]

PetBase = {
	id = 0,					-- 幻兽ID	__kn
	sort_id = 0,			-- 幻兽类型 见 PetDefs.lua 定义
	
	nick = '',				-- 幻兽名字  __s
	res_id = 0,				-- 幻兽3D资源ID
	pic_id = 0,				-- 幻兽2D资源ID(头像,卡牌)
	quality = 0,			-- 幻兽品阶
	aptitude = 0,			-- 幻兽资质
	prof = 0,				-- 所属职业
	max_star = 0,			-- 可以升级到的最大星数
	body_size = 0,			-- 身体大小(身体中心点到身体最远边界的距离)	--type:float 
	--en_jicheng_sort_ids = false,	-- 可以继承的幻兽类型 --type:ArrayList __t
	max_level = 0,			-- 幻兽初始最大等级
	fight_capacity = 0,		-- 幻兽初始战力
	
	-- 幻兽属性初值
	init_min_attack = 0,	-- 最小攻击初值
	init_max_attack = 0,	-- 最大攻击初值
	init_defence_phy = 0,		-- 物防初值
	init_defence_magic = 0,		-- 魔防初值
	init_max_hp = 0,			-- 最大生命初值
	init_douzhi = 0,			-- 斗志初值
	init_critical_hit = 0,		-- 暴击初值
	init_dodge = 0,				-- 闪避初值
	init_parry = 0,				-- 格挡初值
	init_luck = 0,				-- 幸运初值
	
	-- 幻兽属性成长初值
	init_grow_min_attack = 0,	-- 最小攻击成长初值	type:float
	init_grow_max_attack = 0,	-- 最大攻击成长初值	type:float
	init_grow_defence_phy = 0,	-- 物防成长初值	type:float
	init_grow_defence_magic = 0,-- 魔防成长初值	type:float
	init_grow_max_hp = 0,		-- 最大生命成长初值	type:float
	
	skill_id = 0,				-- 幻兽的基础技能ID
	add_star = 0,				-- 每次幻化升级的星级数
	shouhun_num = 0,			-- 幻兽献祭时获得的兽魂数量
	add_kill_forces = false,	-- 幻化到X次增加的斩杀力 type:int[]  {10,10,10,10,20} 代表幻化1-4次每次加10点斩杀力,第5次加20点斩杀力
	
	huanhua_need_pet_id = 0,	-- 11资质(含)后幻化需要的幻兽ID(注：目前11资质开始才会用该字段)
	huanhua_pet_nums = false,	-- 幻化需要的同ID幻兽个数[{min_star=xx,max_star=xx,need_num=xx},...] type:ArrayList  __t
	huanhua_xo_nums = false,	-- 幻化需要的XO兽道具个数[{min_star=xx,max_star=xx,need_num=xx},...] type:ArrayList  __t
	huanhua_hj_nums = false,	-- 幻化需要的幻晶数 [{min_star=xx,max_star=xx,need_num=xx},...] type:ArrayList  __t
	huanhua_addi_effects = false,-- 幻化激活的效果 [{star=xx,effect_type=xx,effect_value=xx},...] type:ArrayList  __t
	huanhua_tianfu_ids = false,	-- 幻化次数对应天赋ID列表	type:Hashtable __t {[1]={2,3},[3]={2,3}}
	
	fate_pet_effects = false,	-- 幻兽缘份 {{pet_ids={123,111},title=xx,min_attack=xx,...},...} type:ArrayList
	fate_addi_effect = false,	-- 宝物缘份 {{jieshu_multi=0,bw_ids={123,111},title=xx,min_attack=xx,...},...} type:ArrayList
	tujian_order_by = 0,		-- 图鉴的幻兽排序编号
	
	intro = '',				-- 幻兽描述 __s
}
PetBase.__index = PetBase

-- 缘分数据结构，客户端使用
PetYuanfenBase = {
	pet_id = 0,					-- 幻兽ID
	baowu_equip_ids = {},		-- 宝物道具ID列表 type:List<int>
	fate_pet_ids = {},			-- 缘分对应的幻兽ID列表 type:List<int>
	title = '',					-- 缘分名字
	effects = {},				-- 缘分效果 type:Effects
	jieshu_multi = 0,			-- 阶数倍数 type:double
	client_Equals__s = "title",	-- 重载等于符号，提供客户端使用
}

local table = table
function PetBase:new(csv)
	local o = {}
	setmetatable(o, self)
	
	for key, value in pairs(csv) do
		if not self[key] then
			if not table.isTableEmpty(value) then
				o[key] = value
			end
		elseif value ~= o[key] then
			o[key] = value
		end
	end
	
	-- NIL掉服务端不需要用的字段
	o.res_id = nil
	o.intro = nil
	
	return o
end

