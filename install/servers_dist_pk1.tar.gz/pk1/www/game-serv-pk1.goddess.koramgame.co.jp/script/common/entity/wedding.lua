--[[
婚宴活动
author: liujinlin
date: 2016-07-20
]]--

--id__kn,scene_id,type,wedname__s,guest_num,card_num,card_name__s,reward_name__s,wast_gold,phase_time__t,qifen_index_reward__t,toastback_reward__t,toast_reachvalue_reward__t,fireworks_reward__t,gift_reward__t,gift_reward_preview__t
Wedding = {
	id = 0,                            --索引
	scene_id = 0,                      --场景id
	type = 0,                          --婚礼类型
	wedname = '',                      --婚礼名字
	guest_num = 0,                     --宾客数目
	card_num = 0,                      --礼卡数目
	card_name = '',                    --礼卡名字
	reward_name = '',                  --奖励名字
	cost_gold = 0,                     --消耗元宝数
	cost_vouchgold = 0,                --消耗充值魔石数
	everyday_plan = false,             --每天的可预约计划type:ArrayList
	phase_time = false,                --时间表type:int[]
	qifen_index_reward = false,        --气氛奖励 type:ArrayList 
	toast_reward = false,              --举杯奖励type:Hashtable
	toastback_reward = false,          --回杯奖励type:Hashtable
	toast_reachvalue_reward = false,   --碰杯发起者，回杯到一定数据后奖励type:ArrayList
	fireworks_reward = false,          --礼花奖励type:Hashtable
	fireworks_luckrewards  = false,    --礼花幸运奖励type:Hashtable
	gift_reward_preview  = false,      --礼包奖励预览type:ArrayList	
	robball_rewards  = false,          --抢花球奖励type:Hashtable
	toast_times = 0,                   --免费举杯次数
	firework_times = 0,                --免费礼花
	lifuid=0,		           --礼服id
}

function Wedding:new(id,scene_id,type,everyday_plan,phase_time,qifen_index_reward,
                     toastback_reward,toast_reachvalue_reward,fireworks_reward,
                     gift_reward_preview,wedname,guest_num,card_num,card_name,
                     reward_name,cost_gold,cost_vouchgold,
                     toast_times,firework_times,toast_reward,fireworks_luckrewards,robball_rewards)
    local o = {}
    o.id = id
    o.scene_id = scene_id
    o.type = type
    o.everyday_plan = everyday_plan
    o.phase_time = phase_time
    o.qifen_index_reward = qifen_index_reward
    o.toastback_reward = toastback_reward
    o.toast_reachvalue_reward = toast_reachvalue_reward
    o.fireworks_reward = fireworks_reward
    o.gift_reward_preview = gift_reward_preview 
    o.fireworks_luckrewards = fireworks_luckrewards
    o.wedname = wedname
    o.guest_num = guest_num
    o.card_num = card_num
    o.card_name = card_name
    o.reward_name = reward_name
    o.cost_gold = cost_gold
    o.cost_vouchgold = cost_vouchgold
    o.toast_times = toast_times
    o.firework_times = firework_times
    o.toast_reward = toast_reward
    o.robball_rewards = robball_rewards
    return o
end


-----------服务端用---------------------------------------------------------------------
WeddingRole={
    cid = 0,        --角色id
    prof = 0,       --职业
    gender = 0,     --性别
    level = 0,      --等级
    nick = '',       --角色名称  
    vip = 0,        --vip等级
}

function WeddingRole:new(cid,prof,gender,level,nick,vip)
    local o = {}
    o.cid=cid
    o.prof=prof
    o.gender=gender
    o.level=level
    o.nick=nick
    o.vip=vip
    return o
end

WeddingOrder={
    weding_id = 0,      --婚礼id
    type = 0,       --1普通，2高级，3豪华
    start_time =0,      --开始时间
    end_time = 0,       --结束时间
    order_status = 0,   --1空闲，2已经预约
    male_cid = 0,       --男
    male_nick = '',      --男姓名
    female_cid = 0,     --女
    female_nick = '',    --女姓名
    invite_card_status = 0, --请帖状态  0:不能参加，1:申请通过参加，2：请帖参加
}

function WeddingOrder:new(weding_id,type,start_time,end_time,order_status,
                          male_cid,male_nick,female_cid,female_nick,has_invite_card)
    local o = {}
    o.weding_id = weding_id
    o.type=type
    o.start_time=start_time
    o.end_time=end_time
    o.order_status=order_status
    o.male_cid=male_cid
    o.male_nick=male_nick
    o.female_cid=female_cid
    o.female_nick=female_nick
    o.invite_card_status=has_invite_card or 0
    
    return o
end


WeddingOrderUpdate={
    weding_id = 0,      --婚礼id
    order_status = 0,   --1空闲，2已经预约
    male_cid = 0,       --男
    male_nick = '',      --男姓名
    female_cid = 0,     --女
    female_nick = '',    --女姓名
    invite_card_status = 0,  --0表示还未收到过，1：接收到请帖未看，2：接收到请帖已经看过
}

function WeddingOrderUpdate:new(weding_id,order_status,male_cid,male_nick,
                        female_cid,female_nick,has_invite_card)
    local o = {}
    
    return o                        
end

--一场婚礼一条记录
WeddingRecord={
    timekey = 0, --开始时间
    weding_id = 0, --婚礼id
    male_cid = 0,
    female_cid = 0,
    male_nick = '',      --男姓名
    female_nick = '',    --女姓名    
    card_num = 0,        --礼卡数目
    type = 0,        --婚宴类型
    order_status=0,      --预约状态
    set_notpermit=0,   --不允许其它人参加
    set_permit=0,      --无需申请
}

function WeddingRecord:new(timekey,weding_id,male_cid,female_cid,male_nick,female_nick,card_num,order_status,type)
    local o = {}
    o.timekey=timekey
    o.weding_id=weding_id
    o.male_cid=male_cid
    o.female_cid=female_cid
    o.male_nick=male_nick
    o.card_num=card_num
    o.order_status=order_status
    o.female_nick=female_nick 
    o.type =  type or 1 
    o.set_notpermit = 0
    o.set_permit = 0
    return o
end

WeddingJoinInfo={
    timekey = 0, --开始时间
    cid = 0,     -- 参与者cid
    nick = '',   --名称
    prof = 0,   --职业
    gender = 0, --性别
    level = 0, --等级    
    vip = 0,    --vip
    apply_times = 0, -- 申请次数
    has_card = 0, --请贴数
    gifts = '', --礼品
    words = '',
    recvcard_status = 0, --0表示还未收到过，1：接收到请帖未看，2：接收到请帖已经看过
}


WedRing={
    cid = 0, --角色id
    item_id = '', --赎买的道具id
}


function WeddingJoinInfo:new(timekey,cid,nick,prof,gender,level,vip,apply_times,has_card,
                gifts,words,recvcard_status)
    local o = {}
    o.timekey=timekey
    o.cid=cid
    o.nick=nick
    o.prof=prof
    o.gender=gender
    o.level=level
    o.vip = vip
    o.apply_times=apply_times
    o.has_card=has_card 
    o.gifts =  gifts 
    o.words =  words 
    o.recvcard_status =  recvcard_status
    return o

end                




