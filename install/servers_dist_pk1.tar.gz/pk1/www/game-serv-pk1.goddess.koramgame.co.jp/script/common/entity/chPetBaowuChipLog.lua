--[[
角色幻兽装备碎片流向追踪日志 数据结构
author : xingzeng
date : 2014-11-03
--]]

ChPetBaowuChipLog = 
{
	id = 0,					-- 追踪日志流水号ID 自增ID
	get_cid = 0,			-- 抢夺者 抢得 宝物碎片 / 从系统获得宝物碎片 角色ID
	get_pid = 0,			-- 抢夺者 帐号ID
	get_nick = '',			-- 抢夺者 角色名
	lost_cid = 0,			-- 被抢夺者 失去 宝物的碎片角色ID / 系统产出 (0:代表是系统产出)
	lost_pid = 0,			-- 被抢夺者
	lost_nick = '',			-- 被抢夺者 角色名
	op_id = 0,				-- 操作类型ID(1:抢夺, 2:从随机奖励库获得, 3:合成宝物)
	
	chip_equip_id = 0,		-- 宝物碎片基础ID
	chip_equip_title = '',	-- 宝物碎片名
	chip_equip_num = 0,		-- 宝物碎片碎片数量
	get_ch_now_num = 0,		-- 抢夺者 抢之后拥有该碎片数量
	lost_ch_now_num = 0,	-- 被抢夺者 被抢之后拥有该碎片数量
	
	params = '',			--调用接口传递的参数(客户端post上来)
	created = '',			-- 创建时间
}

ChPetBaowuChipLogClient = {
	id = 0,					-- 追踪日志流水号ID 自增ID
	get_cid = 0,			-- 抢夺者 抢得 宝物碎片 / 从系统获得宝物碎片 角色ID
	get_nick = '',			-- 抢夺者 角色名
	lost_cid = 0,			-- 被抢夺者 失去 宝物的碎片角色ID / 系统产出 (0:代表是系统产出)
	lost_nick = '',			-- 被抢夺者 角色名
	chip_equip_id = 0,		-- 宝物碎片基础ID
	chip_equip_title = '',	-- 宝物碎片名
	created = '',			-- 创建时间
}
