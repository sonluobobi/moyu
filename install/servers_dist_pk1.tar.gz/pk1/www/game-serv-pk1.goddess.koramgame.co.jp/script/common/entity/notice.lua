--[[
广播数据实体
author : guoyin.huang
date : 2015-08-27
--]]

-- 杀人广播
KillNotice = {
	sort_id = 0,	--杀人广播类型
	count = 0,		--杀人计数
	killer_camp = 0,--杀人者所在阵营
	killer = '',	--杀人者
	killed = '', 	--被杀者
	killer_gcid = 0,	--杀人者GCID  //type:ulong
	msg = '',		--文本
}
	