--[[
场景特殊位置属性信息，csv结构
author : guoyin.huang
date : 2015-05-08
--]]

ScenePosition = {
	id = 0,             --id
	type = 0,			--位置类型，见def
	scene_id = 0,		--所在场景ID
	direction = 0,		--方向
	x = 0,				--x坐标
	y = 0,				--y坐标
	value = 0,			--特定参数值
}
