--[[
活跃度数据结构
author : fuqian.liao
date : 2015-01-05
--]]

-- 主玩法表
ActiveBase = {
	id = 0,                 -- ID
	game_type_id = 0,       -- 玩法ID(见Statics)
	game_title = '',		-- 玩法名
	label_type = 0,			-- 所属标签
	is_team_game = 0,		-- 是否组队玩法 (1为组队玩法，0为非组队玩法)
	is_can_robot = 0,		-- 是否可招募机器人
	member_num_max = 0,		-- 队伍人数上限
	active_open_level = 0,	-- 玩法开启等级
	other_srv_join = 0,		-- 是否可以加入其他服队伍(1为可加入其他服的队伍)
	counter_id = 0,			-- 玩法计数器ID
	help_intr = '',			-- 帮助提示
	rewards_intr = '',		-- 获取奖励描述
	active_time_intr = '',	-- 时间描述
	active_time = false,	-- 时间 			//type:Hashtable
	active_time_ex = false, -- 时间扩展(跨天活动)	////type:Hashtable
	has_preview = 0,		-- 是否需要预告
	is_not_open = 0,		-- 玩法是否不用开启(服务端使用)
	parent_func_open_id = 0,-- 功能开放ID
}

-- 子玩法表
ActiveSubBase = {
	id = 1,						-- ID
	child_game_type_id = 0,		-- 子玩法ID
	child_game_title = '',		-- 子玩法名
	game_type_id = 0,			-- 对应的玩法ID
	sub_active_open_level = 0,	-- 子玩法开启等级
	suggest_fight_capacity = 0,	-- 推荐战力
	is_join_direct = 0,			-- 是否可直接进入(1为可直接进入，0或不填为不可)	
	sub_counter_id = 0,			-- 子玩法计数器ID
	sub_counter_equip_id = 0,	-- 可代替次数的道具ID(副本中使用)
	scene_id = 0,				-- 场景ID
	reward_equip_ids = false,	-- 可能获得的道具奖励	//type:int[]
	drop_pack_ids = false,		-- 掉落包串			//type:int[]
	sub_active_desc = '',		-- 子玩法描述
	rewards_intr = '',			-- 子玩法获取奖励描述
	func_open_id = 0,			-- 功能开放ID

	zhaohui_rewards = false,	-- 找回奖励			////type:Hashtable
	help_desc = '',				-- 弹窗帮助内容
	
	baodi_counter_id = 0,		-- 保底计数器ID
	baodi_reward_eids = {},		-- 保底奖励道具ID列表	 __t type:int[] {20111002,32001001}
	baodi_fail_times = 0,		-- 保底需要失败次数
	baodi_reward_title = '',	-- 保底奖励道具名称
}

-- 日常活动表
DailyActiveBase = {
	id  = 1,				-- ID
	function_id = 0,		-- 功能ID
	game_title = '',		-- 标题
	intro = '',				-- 活动描述
	pic = '',				-- 图标 
}

-- 玩法找回
ActiveRewardZhaohui = {
	id = 0,					--玩法找回ID
	active_title = '',		--玩法名称
	buy_type = 0,			--购买方式(1为免费，2为魔石，3为均可)
	price = 0,				--魔石找回的价格
	is_price_mul_value = 0, --魔石找回是否需要乘以数量
	free_radius = 0,		--免费找回获得的奖励的系数 	//type:float
	tips = '',				--玩法描述扩展
	order_by = 0,			--排序字段
}