--[[
活动子项表实体

@author : xingzeng jiang
@create : 2012-12-22
]]--

OpeActivityItem = 
{
    id = 0,						--活动项ID号 (自增)
    
    --活动信息
    activity_id = 0,			--活动ID	（管理活动表活动ID）
    activity_sort_id = 0,		--活动分类ID (冗余)
    activity_item_sort_id = 0,	--活动项分类ID
	order_by = 0,				--排位号(越大越排后面,支持负数)
	opeact_time_type = 0,		--活动时间类型 (0: 活动后台录入的时间，1：固化活动开启时间，2：创建角色时间, 3:升级开启）
	
    --参与等级限制
    character_level_min = 0,	--活动参与级别最小值
    character_level_max = 0,	--活动参与级别最大值(0：无限制)
    
	------------------------------- 兑换类相关 start --------------------------------------
    exchange_cond_sort_id = 0,			--兑换条件分类ID  (常规兑换类)
    exchange_special_cond_sort_id = 0,	--兑换特殊条件分类ID (特殊条件兑换类)
    exchange_reward_sort_id = 0,		--兑换奖励分类ID
    
	--------------  特殊条件兑换类 start -----------------
    special_limit_min = 0,		--特殊条件达成限制最小值
    special_limit_max = 0,		--特殊条件达成限制最大值
	--------------  特殊条件兑换类 end -----------------
 
    --活动兑换各类对应约束条件
    consume_num = 0,			--活动内消费数量
    charge_num = 0,				--活动内充值数量
    need_equip_ids = '',		--兑换道具ID串
    need_equip_nums = '',		--兑换道具数量串
	arr_del_equip_num = nil,	-- need_equip_ids，need_equip_nums 格式化之后的
	band_account_pids = '',		--绑定的账号ID
	ext_value1 = 0,				--扩展值1（如：幻兽个数）
	ext_value2 = 0,				--扩展值2（如：幻兽资质）
	ext_value3 = 0,				--扩展值3
	ext_value4 = '',			--扩展值4
	ext_value5 = '',			--扩展值5
	fix_ext_value = false,		--固化活动扩展值 提供客户端使用 type:Hashtable {type=xx, value=xx, partical_id=xx, xn_equip_ids={[20011001]=10,...}}
	is_early_show = 0,			--活动项是否提前显示
	is_no_redflag = 0,			--是否不显示红点提醒(0:显示红点提醒,1:不显示红点提醒)
	
    --活动兑换获得奖励
	reward_equip_ids = '',		--奖励道具ID串
    reward_equip_nums = '',		--奖励道具数量
	arr_add_equip_num = nil,	-- reward_equip_ids，reward_equip_nums 格式化之后的
    rand_reward_equips = '',	--随机奖励
	arr_rand_reward_equips = nil,-- rand_reward_equips解码之后
	c__reward_equips = false,	--奖励道具列表(客户端显示使用) type:List<EquipItem>
	c__luck_goddess_confs = {},--幸运女神信息配置 ext_value4解码之后 type:List<LuckGoddessConf>
	
    --活动兑换限制条件
    get_ch_num = 0,				--领取名额限制(全服限制)(0：无要求)
    eday_exh_times = 0,			--每天兑换次数(0：无要求)
    act_exh_times = 0,			--活动期内当前活动项可兑换次数(0：无要求)
    
	is_input_num = 0,			--是否需要客户端输入数量

	------------------------------- 兑换类相关 end --------------------------------------
	
    --时间范围
	start_datetime = '',		--活动开始时间("年:月:日 时:分:秒")
    end_datetime = '',			--活动结束时间("年:月:日 时:分:秒")
	voucher_etime_offset_day = 0,--充值结束时间偏移天数
	voucher_sdtime = nil,		--充值统计开始时间(不存在数据库，仅在内存)
	voucher_edtime = nil,		--充值统计结束时间(不存在数据库，仅在内存)
	c__voucher_stime = 0,		--充值统计开始时间 供客户端使用
	c__voucher_etime = 0,		--充值统计结束时间 供客户端使用
	c__stime_sec = 0,			--活动开始时间(时间戳 供客户端使用)
	c__etime_sec = 0,			--活动结束时间(时间戳 供客户端使用)
	c__reach_etime_sec = 0,		--活动达成条件结束时间(时间戳 供客户端使用)
	reach_edtime_offset = 0,	--条件达成结束时间 针对开始时间的偏移天数(仅用于固化活动)
	
    --基本属性
    title = '',					--标题
    intro = '',					--内容描述
    created = '',				--创建时间
    updated = '',				--更新时间
}
OpeActivityItem.__index = OpeActivityItem

function OpeActivityItem:new(pool, data)
	local o = pool or {}
	
	for key, value in pairs(data) do
		if self[key] and value ~= self[key] then
			o[key] = value
		end
	end
	
	setmetatable(o, self)
	
	return o
end

OpeActivityItemFixBase = 
{
	id = 0,
	activity_id = 0,
	title = '',
	intro = '',
	fix_ext_value = false,	--固化活动扩展值 提供客户端使用 type:Hashtable {type=xx, value=xx, partical_id=xx, xn_equip_ids={[20011001]=10,...}}
}
