--[[
竞技场会用到的角色详细属性
author : xingzeng
date : 2014-08-15
--]]

Arena = {
	
}

ArenaChRank = {
	arena_cid = nil,		-- 竞技场CID,机器人=mergeUInt(rank,cid),玩家=cid
	cid	= 0,				-- 角色ID
	nick = '',				-- 角色昵称
	rank = 0,				-- 排名
	old_rank = 0,			-- 上次排名
	fight_capacity = 0,		-- 战力
	win_streak = 0,			-- 连胜次数
	level = nil,			-- 等级
	updated = '',			-- 更新时间
}

ArenaPKLog = {
	cid	= 0,				-- 发起PK的角色ID
	rank = 0,				-- 发起PK的新排名
	nick = '',				-- 发起PK的角色昵称
	passive_pk_cid = 0,		-- 被PK的角色ID
	passive_pk_rank = 0,	-- 被PK的新排名
	passive_pk_nick = '',	-- 被PK的角色昵称
	is_win = 0,				-- 是否挑战胜利(0:失败， 1：胜利)
	is_uprank = 0,			-- 发起PK者是否上升名次(0:否， 1：是)
	created = '',			-- 创建时间(内存里面用unix时间戳int类型存储，DB用datetime)
}

ArenaChDetail = {
	gcid = nil,				-- 64位角色ID
	id = 0,					-- 角色ID
	
	nick = '',				-- 昵称
	gender = 0,				-- 性别
	prof = 0,				-- 职业
	level = 0,				-- 等级

	picture = 0,			-- 头像
	res_id = 0,				-- 头像

	fight_capacity = 0,		-- 战力
	speed = 0,				-- 速度

	hp = 0,					-- 当前HP值
	max_hp = 0,				-- 最大MP值

	max_attack = 0,			-- 最大攻击
	min_attack = 0,			-- 最小攻击

	defence_phy = 0,		-- 物理防御
	defence_magic = 0,		-- 魔法防御

	douzhi = 0,				-- 斗志

	critical_hit = 0,		-- 暴击
	dodge = 0,				-- 闪避
	parry = 0,				-- 格挡
	addi_harm = 0,			-- 附伤 附加伤害绝对值
	addi_harm_perc = 0,		-- 加伤 增加百分比伤害
	reduce_harm = 0,		-- 减伤：降低伤害绝对值
	reduce_harm_perc = 0,	-- 免伤：降低百分比伤害
	kill_force = 0,			-- 斩杀力
	luck = 0,				-- 幸运
	
	-- 夺宝用到
	rob_mianzhan_expire = 0,-- 夺宝免战时间
	fight_pet_id = 0,		-- 出战的幻兽基础ID
	heti_pet_ids = nil,		-- 合体的幻兽基础ID列表
	
	-- 竞技场或夺宝场PK用到
	arena_fight_ch_pet = nil,-- 出战的幻兽
	arena_skills = nil,		-- 角色的技能
	
	gang_id = 0,			-- 帮会ID
	wing_base_id = 0,		-- 翅膀基础ID
	wuqi_eid = 0,			-- 武器装备基础ID
	yifu_avatar_eid = 0,	-- 衣服或时装道具基础ID
	qihun_wuqi = 0,			-- 器魂武器
	qihun_yifu = 0,			-- 器魂衣服
	sb_skill_level = 0,		-- 神兵技能等级
	
	updated = 0,			-- 更新时间 
}

-- 竞技场幸运排名
ArenaLuckRank = {
	id = 0,					-- 自增ID
	jie_id = 0,				-- 届ID(eg : 20150302)
	rank = 0,				-- 幸运排名
	reward_gold = 0,		-- 奖励绑定元宝数量
	
	cid = 0,				-- 角色ID
	nick = '',				-- 角色昵称
	updated = '',			-- 更新时间
}

function ArenaLuckRank:new(jie_id, rank, reward_gold)
	local o = {}
	o.jie_id = jie_id
	o.rank = rank
	o.reward_gold = reward_gold
	o.cid = 0
	o.updated = Time:getDateTimeStrNow()
	return o
end


-- 竞技场数据库字段列表
ChFieldsForArena = {
	id = 0,					-- 64位角色ID
	
	nick = '',				-- 昵称
	gender = 0,				-- 性别
	prof = 0,				-- 职业
	level = 0,				-- 等级

	picture = 0,			-- 头像
	res_id = 0,				-- 头像

	fight_capacity = 0,		-- 战力
	speed = 0,				-- 速度

	hp = 0,					-- 当前HP值
	max_hp = 0,				-- 最大HP值
	max_hp2 = 0,
	max_hp3 = 0,
	
	max_attack = 0,			-- 最大攻击
	min_attack = 0,			-- 最小攻击

	defence_phy = 0,		-- 物理防御
	defence_magic = 0,		-- 魔法防御

	douzhi = 0,				-- 斗志

	critical_hit = 0,		-- 暴击
	dodge = 0,				-- 闪避
	parry = 0,				-- 格挡
	addi_harm = 0,			-- 附伤 附加伤害绝对值
	addi_harm_perc = 0,		-- 加伤 增加百分比伤害
	reduce_harm = 0,		-- 减伤：降低伤害绝对值
	reduce_harm_perc = 0,	-- 免伤：降低百分比伤害
	kill_force = 0,			-- 斩杀力
	luck = 0,				-- 幸运
	rob_mianzhan_expire = 0,-- 夺宝免战时间
	
	pets = '',				-- 出战的幻兽
	skills = '',			-- 角色的技能
	horses = '',			-- 坐骑
	wing = '',				-- 翅膀
	items = '',
	item_strongs_info = '',
	appear = '',			-- 外观相关
}