-- 战斗属性， 提供客户端使用

FightAttrib = {
	prof = 0,
	level = 0,
	douzhi = 0, 			--斗志
	min_attack = 0, 		-- 最小物理攻击
	max_attack = 0, 		-- 最大物理攻击
	defence_phy = 0, 		-- 物理防御
	defence_magic = 0, 		-- 魔法防御
	dodge = 0, 				-- 闪避
	critical_hit = 0, 		-- 暴击
	parry = 0, 				-- 格挡
	luck = 0, 				-- 幸运
	addi_harm = 0, 			-- 加伤绝对值(加伤)
	addi_harm_perc = 0, 	-- 加伤百分比(附伤)
	reduce_harm = 0, 		-- 减伤绝对值(减伤)
	reduce_harm_perc = 0, 	-- 减伤百分比(免伤)
	kill_force = 0, 		-- 斩杀力
	fight_capacity = 0,
	shengbing_skill_level = 0, -- 神兵技能等级(裔钊让加的)
}
