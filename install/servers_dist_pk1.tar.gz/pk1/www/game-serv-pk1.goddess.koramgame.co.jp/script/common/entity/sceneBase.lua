--[[
场景基本属性信息，csv结构
author : xingzeng.jiang
date : 2014-07-15
--]]

SceneBase = {

	-------------------- 场景基本属性 start --------------------
	id = 0,                       --id 场景CLASS Id
	parent_id = 0,                --父场景ID(用于关卡虚拟父关卡，每个父关卡有普通,困难,宗师子关卡)
	scene_sort_id = 0,            --场景类型,   参考 SceneDefs.SCENE_SORT_ID
	
  	title = '',                   --场景名:数字编号
	title2 = '',				  --场景名:中文
	res_id = 0,                   --场景资源ID
	res_name = '',			  	  --场景资源名
	small_res = '',			  	  --副本列表缩略图
	loading_image_ids = '',       -- 进入场景时 loading 界面中显示的图片ID列表
	music = 0,                    --场景背景音乐
	is_local_ai = 0,			  --是否单机场景
	is_client_calc_harm = 0,	  --是否有客户端计算伤害
	
	difficulty = 0,               --场景难度级别, 参考 SceneDefs.SCENE_DIFFICULTY_
	safe_mode = 0,                --安全模式, 参考 SceneDefs.SCENE_SAFE_MODE_
	default_fixed_pos = false,    --缺省的修正位置	type:int[]
	is_hide_monster_title = 0,    --是否隐藏怪物名字
	-------------------- 场景基本属性 end --------------------
	
	------------------- 场景复活 begin -----------------------
	is_en_yuandi_relive = 0,      --是否可以原地复活(0:不可以，1：可以)
	relive_locate_type = 0,		  --复活位置类型(0:本场景,1:主城)
	free_relive_time_long = 0,	  --自动复活需要等待的时长
--	is_relive_pet = 0,			  --复活时是否复活幻兽(0:不复活,1:复活)
	------------------- 场景复活 end -------------------------
	
	
	-- 关卡相关信息
	chapter_id = 0,				-- 所属关卡章节ID
	drop_pack_ids = false,		-- 掉落包ID列表 type:ArrayList
	pass_reward_equips = false,	-- 通关奖励的道具列表 [equip_id,equip_num, ...]	//type:int[]
	pass_reward_silver = 0,		-- 通关奖励的金币
	pass_reward_exp = 0,		-- 通关奖励的经验(已弃用，该用公式)
	phase_num = 0,				-- 关卡的总阶段数
	chapter_order_by = 0,		-- 关卡在章节中的排位
	show_monster_pic_id = 0,	-- 界面显示的关卡怪物头像
	show_drop_equips = false,	-- 界面显示掉落的道具列表 仅仅客户端显示用 [equip_id,equip_id,...] type:int[]
	trigger_id = 0,				-- 剧情ID
	tj_fight_capacity = 0,		-- 推荐战力
	tj_level = 0,				-- 推荐等级
	is_boss_tollgate = 0,		-- 是否BOSS关卡(0:否，1：是)
		
	-------------------- 场景开启相关 start --------------------
	pre_tollgate_id = 0,	-- 前置关卡ID
	ch_level = 0,			-- 需要玩家等级
	-------------------- 场景开启相关 end --------------------
	
	-------------------- 场景进入条件 start ----------------------
	ch_num_max = 0,               --场景容纳的最多玩家数量(主城野外填0)
	-------------------- 场景进入条件 end ----------------------
	
	--关卡、副本与怪物对话
	tooltips = '',				 --鼠标提示
	intro = '',                  --场景介绍
	
	-- 对SceneAoi,RandRewardPackBase 的索引
	scene_aoi_ids = '',			-- 该场景内包含的SceneAoi对象id列表 type:int[]
	rand_reward_pack_ids = '',	-- 该场景内包含的RandRewardPackBase对象id列表 type:int[]
	
	fov_size = nil,				--不由填表设置，而是在CommonDao/SceneBaseDao.lua 内加载CSV数据的时候设定
}

SceneBase.__index = SceneBase

local table = table
function SceneBase:new(csv)
	local o = {}
	setmetatable(o, self)
	
	for key, value in pairs(csv) do
		-- 基类值为nil，代表是table类型的字段
		if not self[key] then
			if not table.isTableEmpty(value) then
				o[key] = value
			end
		elseif value ~= o[key] then
			o[key] = value
		end
	end
	
	o.show_drop_equips = nil
	o.show_monster_pic_id = nil
	o.tooltips = nil
	o.intro = nil
	
	return o
end