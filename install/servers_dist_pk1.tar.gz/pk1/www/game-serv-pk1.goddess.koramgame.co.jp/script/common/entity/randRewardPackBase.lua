--[[
随机奖励包 数据结构
author : xingzeng
date : 2014-11-03
--]]

RandRewardPackBase = 
{
	id = 0,				-- 随机奖励包ID
	group_id = 0,		-- 奖励库组ID (1:夺宝和竞技场)
	
	scene_id = 0,		-- 关联的关卡场景ID
	baowu_chip_equip_id = 0,-- 奖励的宝物碎片道具ID
	equip_id = 0,		-- 奖励的其他道具ID
	equip_num = 0,		-- 奖励的其他道具数量
	proba = 0,			-- 出现概率 (概率基数为 同组所有奖励概率之和)
	proba_fake = 0,		-- 假概率(用户客户端补充未翻中的牌显示)
	is_baodi = 0,		-- 是否为保底道具 (0:否, 1:是)
	prof = 0,			-- 角色职业
	ch_level_min = 0,	-- 角色等级要求 下限(暂未使用)
	ch_level_max = 0,	-- 角色等级要求 上限(暂未使用)
}

-- 客户端不需要的字段(生成的.cs文件里面的EquipBase类不会含下面字段)
RandRewardPackBase__noclient = {
	baowu_chip_equip_id=1,is_baodi=1,ch_level_min=1,ch_level_max=1,
}