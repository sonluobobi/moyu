--[[
道具追踪日志数据结构定义
author : xingzeng
date : 2012-03-27
--]]

ChEquipTraceLog = {
	id = 0,				--自增ID
	master_cid = 0,		--主操作者角色ID
	master_pid = 0,		--主操作者帐户ID
	master_nick = '',	--主操作者角色昵称
	master_ip = '',		--主操作者IP
	slave_cid = 0,		--被操作者角色ID
	slave_pid = 0,		--被操作者帐户ID
	slave_nick = '',	--被操作者角色昵称
	slave_ip = '',		--被操作者IP
	
	is_get = 0,			--是否获得(1 获得, 0 失去)
	op_id = 0,			--操作类型ID
	
	equip_id = 0,		--原始道具ID
	ch_equip_id = 0,	--角色道具实例ID
	equip_sort_id = 0,	--道具类型ID
	equip_title = '',	--道具名称
	equip_num = 0,		--道具数量
	reward_module_id = 0,--通用奖励包来源
	
	scene_id = 0,		--道具流动时触发者角色所在场景ID
	params = '',		--调用接口传递的参数(客户端post上来)
	
	created = '',		--创建时间
	updated = '',		--更新时间
}
ChEquipTraceLog.__index = ChEquipTraceLog

function ChEquipTraceLog:new(character, slave_character, op_id, is_get, ch_equip_id, equip, equip_num, params)
	local o = {}
	setmetatable(o, self)
	
	o.id = nil
	o.master_cid = character.id
	o.master_pid = character.player_id
	o.master_nick = character.nick
	o.master_ip = character.now_login_ip
	o.slave_cid = slave_character.id
	o.slave_pid = slave_character.player_id
	o.slave_nick = slave_character.nick
	o.slave_ip = slave_character.now_login_ip
	
	o.op_id = op_id
	o.is_get = is_get and 1 or 0
	
	o.equip_id = equip.id
	o.ch_equip_id = ch_equip_id
	o.equip_sort_id = equip.equip_sort_id
	o.equip_title = equip.title
	o.equip_num = equip_num
	
	o.scene_id = character.scene_id
	o.params = params or ''
	
	return o
end
