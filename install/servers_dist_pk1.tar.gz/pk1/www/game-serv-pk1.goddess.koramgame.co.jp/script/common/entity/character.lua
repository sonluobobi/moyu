--[[
角色基本数据 entity
author : jianzhu.liu
date : 2016-04-07
--]]

CharacterBase = {
	id = 0,  --角色id
	player_id = 0, --帐号id
	unique_key = '', --全局唯一id
	nick = '',		--昵称
	gender = 0,    --性别
	prof = 0,		--职业
	level = 0,		--等级
	vip = 0,		--vip等级
}