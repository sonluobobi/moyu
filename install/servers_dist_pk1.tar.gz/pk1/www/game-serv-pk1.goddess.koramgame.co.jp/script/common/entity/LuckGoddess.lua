--[[
幸运女神活动
@author : xingzeng jiang
@create : 2016-09-07
]]--

LuckGoddessInfo = {
	activity_item_id = 0,					--活动项ID
	activity_sdtime = '',					--活动开始时间
	bout_id = 0,							--轮数ID
	exp = 0,								--经验值
	rewarded_cid = 0,						--获奖者角色ID
	rewarded_nick = '',						--获奖者角色名
	reward_equip_id = 0,					--专属奖励道具ID
	reward_equip_num = 0,					--专属奖励数量
	updated = '',
	created = '',							
}

local Time = Time
local tonumber = tonumber

function LuckGoddessInfo:new(act_item, bout_id, luck_goddess_conf)
	local o = {}
	o.activity_item_id = act_item.id
	o.activity_sdtime = act_item.start_datetime
	o.bout_id = bout_id
	o.exp = 0
	o.created = Time:getDateTimeStrNow()
	return o
end

LuckGoddessConf = {
	bout_id = 0,				--轮数ID
	exp = 0,					--该轮满需要的经验值
	zhuanshu_equip_id = 0,		--专属奖励道具ID
	zhuanshu_equip_num = 0,		--专属奖励道具数量
	xuyuan_equip_id = 0,		--许愿奖励道具ID
	xuyuan_equip_num = 0,		--许愿奖励道具数量
}

function LuckGoddessConf:new(conf)
	local o = {}
	o.bout_id = tonumber(conf.bout_id)				--轮数ID
	o.exp = tonumber(conf.exp)					--该轮满需要的经验值
	o.zhuanshu_equip_id = tonumber(conf.zhuanshu_equip_id)		--专属奖励道具ID
	o.zhuanshu_equip_num = tonumber(conf.zhuanshu_equip_num)		--专属奖励道具数量
	o.xuyuan_equip_id = tonumber(conf.xuyuan_equip_id)		--许愿奖励道具ID
	o.xuyuan_equip_num = tonumber(conf.xuyuan_equip_num)
	return o
end
