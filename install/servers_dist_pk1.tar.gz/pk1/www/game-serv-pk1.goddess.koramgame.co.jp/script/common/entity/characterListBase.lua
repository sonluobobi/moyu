--[[
获取角色列表结构体
author : suwin zhong
date : 2015-06-27
--]]

CharacterListBase = {
	gcid = 0,		-- type:long
	picture = 0,	-- 头像
	gender = 0,		-- 性别
	nick = '',		-- 名字
	level = 0,		-- 等级
	vip = 0,		-- vip
	prof = 0,		-- 职业
	weaponid = 0,	-- 武器id
	avatar_id = 0,  -- avatar_id
	horse_id = 0,	-- 坐骑id
	wing_equip_id = 0, -- 翅膀id
	star_level = 0,	-- 全身精炼等级
	ban_type = 0,	-- 是否封停
	ban_expire = '', -- 封停过期时间
	last_login_time = '', -- 上一次登录时间
	gang_title = '', -- 军团名字
	created = '',	-- 创建时间
}
