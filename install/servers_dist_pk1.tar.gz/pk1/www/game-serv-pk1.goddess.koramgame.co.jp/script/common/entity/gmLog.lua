--[[
GM日志实体
author : 杰林
date : 2012-07-30
]]--

GMLog = {
	id = 0,				  --自增ID
	operate_cid = 0,      --操作玩家角色id
	operate_pid = 0,      --操作玩家player_id
	func_name = '',       --功能函数名
	slave_cid = 0,        --被操作玩家角色id
	slave_pid = 0,        --被操作玩家pid
	params = '',          --传入参数
	created = nil,		  --创建时间
}


function GMLog:new(operate_cid, operate_pid, func_name, slave_cid, slave_pid, params)
	local o = {}
	o.operate_cid = operate_cid
	o.operate_pid = operate_pid
	o.func_name = func_name
	o.slave_cid = slave_cid
	o.slave_pid = slave_pid
	o.params = params
	
	return o
end
