--[[
军团日志 entity
author : jianzhu
date : 2016-05-06
--]]

GangLog = {
	id = 0,				--记录标识id
	gang_id = 0, 		--军团id
	gang_title = '', 	--军团名称
	log_type = 0,		--日志总类型,1捐献;2屠龙;3其他
	log_desc_type = 0,	--日志文字描述类型
	op_cid = 0, 		--操作者角色ID
	op_nick = '',		--操作者昵称
	op_time = 0,		--操作时间
	value1 = '', 		--参数1
	value2 = '',		--参数2
	value3 = '',		--参数3
}

GangLogInfo = {
	log_desc_type = 0,	--日志文字描述类型
	op_time = 0,		--操作时间
	gang_title = '', 	--军团名称
	op_nick = '',		--操作者昵称
	value1 = '', 		--参数1
	value2 = '',		--参数2
	value3 = '',		--参数3
}