
SkillBase = 
{
	id = 0,				-- 技能ID
	parent_id = 0,		-- 父技能ID(普攻3段的3个技能 都用单攻技能ID作父技能ID)
	group_id = 0,		-- 技能组ID(同一个组的只能占1个技能槽位置)
	
	open_level = 0,		-- 开启等级
	is_auto_get = 0,	-- 技能是否会自动添加到角色身上

	prof = 0,			-- 所属职业
	slot_pos = 0,		-- 装备位置
	priority = 0,		-- 技能释放优先级
	order_by = 0,		-- 排序ID
	title = '',			-- 技能名称		type:string
	parent_sort_id = 0,	-- 父类型 0:主动技能, 1:被动技能
	sort_id = 0,		-- 类型  见 SkillDefs.lua
	effect_sort_id = 0,	-- 效果类型 见 SkillDefs.lua
	is_server_fight = 0, --0客户端，1服务端
	prof_faction = 0,	-- 技能派系 1：物理系， 2：法术系
	picture = 0,		-- 图片
	owner_type = 0,		-- 施法者 1:玩家，2：怪物，3:侠客
	is_lock	= 0,		-- 是否锁定技，1为锁定技，锁定技攻击进行时被攻击者不能被其他玩家攻击
	target_id = 0,		-- 作用对象类型 定义见 SkillDefs.lua
	ch_num = 0,			-- 作用人数上限
	distance = 0,		-- 攻击目标距离(客户端选取目标用)(无目标距离填0) -- type:float
	ai_distance = 0,	-- 自动施法的距离	-- type:float


	move_type = 0,		-- 移动类型,见SkillDefs.lua 
	area_type = 0,		-- 作用范围类型，定义见 SkillDefs.lua AREA_TYPE_ID_*
	
	area_radius = 0,	--半径  //type:float
	area_length = 0,	--长(矩形长)//type:float
	area_width = 0,		--宽(矩形宽)//type:float
	
	target_move_dist = 0, -- 目标移动的距离(击退等)			//type:float
	self_move_dist = 0,	  -- 自己瞬间移动的距离				//type:float
	self_slow_move_dist = 0,--自己持续移动的距离(非瞬间，可打断)	//type:float
	
	self_cool_msec = 0,	-- 私有CD时间,技能冷却的时间单位:豪秒
	play_cool_msec = 0, -- 使用此技能后，用下一个技能需要的CD时间 单位:豪秒
	
	client_effect ='',	-- 技能特效

	attacker_sound_type = false,	-- 攻击方声效类型			//type:int[]		
	sound_id =0, 		-- 施法音效（施放技能的时候一直在播放的音效）
	talk_id = 0,		-- 施法者施法时发出的声音
	

	intro = '',			--技能描述
	lianji_num = 1,		--连击次数
	fc_coeff = 0,		--战力 -- type:float


	duration = 0,		--技能播放时长
	interval = 0,		--连续技能伤血间隔
	broadcast = 0,		--技能释放广播人数(-1表示全场景广播，正数为随机广播的最大人数)
	
	is_dead_when_use = 0,--当使用技能的时候是否死亡,(0或不填不死亡，1为死亡)
	
}

SkillDetail = 
{
	id = 0,				-- 技能每级的ID
	skill_level = 0,	-- 技能等级
	skill_id = 0,		-- 技能ID
	title = '',			-- 技能名称		type:string
	
	ch_level = 0,		-- 学习角色等级要求
	
	harm_percent = 1,		--伤血百分比		//type:float
	harm_percent2 = 0,		--伤血百分比2		//type:float
	extra_harm = 0,			--附加固定伤害		//type:float
	
	sputter = false,		-- 技能溅射 {半径，伤害的人数，伤害的系数} //type:ArrayList	
	
	--add_hp_percent 		给目标加血百分比
	--del_defence_percent 	降低目标防御
	extra_target_effect = false,	--技能附加给目标相关属性  type:Hashtable
	
	--extra_critical_hit_prob	增加暴击率
	--add_critical_hit_percent	增加暴击百分比
	--extra_xixue_percent		吸血百分比
	--
	extra_self_effect = false,	--技能附加给自己的相关属性//type:Hashtable
	
	target_buffers = false,		-- 附加给攻击范围的buffer// type:ArrayList
	self_buffers = false,		-- 给自己附加的BUFFER// type:ArrayList
	only_target_buffers = false, --只附加给选中目标的buffer // type:ArrayList
	
	traps = false,		-- 陷阱//type:ArrayList
	beasts = false,		-- 召唤的召唤兽//type:ArrayList
	monsters = false,	-- 召唤的怪物{{monster_id=111,num=10}}//type:ArrayList
	scene_event = false,-- 召唤场景事件（客户端使用) //type:Hashtable
	spec_params = false,-- 特殊参数{type=1,}//type:Hashtable

	intro = '',			-- 技能每级描述	每次造成{0}的伤害
	intro_params = '',	-- 技能描述参数	100%,16(显示的时候将会将{0}替换为100%,{1}替换为16)

	goddess_desc = '',	-- 技能在女神界面的描述
}

local table = table
local type = type

function SkillBase:new(csv)
	local o = csv
	
	for key, value in pairs(SkillBase) do
		if value and type(value) ~= 'function' and not o[key] then
			o[key] = value
		end
	end

	-- 连击次数默认设置为1
	if o.lianji_num == 0 then 
		o.lianji_num = 1
	end
	
	-- 去掉服务器不需要的字段
	o.intro = nil
	o.client_effect = nil
	
	o.__index = SkillBase
	return o
end

function SkillDetail:new(csv, skill_base)
	local o = csv
	return o
end
