--[[
	场景游戏对象基类
	author : xingzeng.jiang
	date : 2014-07-15
	
	character.dy_scenes = 
	{
		[scene_id] = SceneProgress
	}
--]]

SceneProgressKey = 
{
	passed = 1,		--通关次数
	star = 2,		--星星
	left_cnt = 3,	--困难本剩余次数
	reset_cnt = 4,	--困难本重置次数
	fresh_time = 5,	--困难本刷新时间
}


SceneProgress = SceneProgress or {}

function SceneProgress:new()
	return {-1,0}
end



