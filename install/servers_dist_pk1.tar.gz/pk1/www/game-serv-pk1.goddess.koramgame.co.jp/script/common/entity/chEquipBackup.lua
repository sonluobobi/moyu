--[[
道具属性备份数据结构定义
author : xingzeng
date : 2012-03-27
--]]

ChEquipBackup = {
	id = 0,				--自增ID
	cid = 0,			--角色ID
	ch_equip_id = 0,	--角色道具实例ID
	equip_id = 0,		--道具基础ID
	data = '',			--角色道具属性数据
	created = '',		--创建时间
	updated = '',		--更新时间
}