--[[
组队数据实体
author : guoyin.huang
date : 2015-03-23
--]]

-- 队伍csv
TeamBase = {
	id = 0,		--IDKn
	game_type = 0,		--玩法类型
	game_title = '',	--玩法名
	child_game_type_id 	= 0,	--房间ID
	room_title 		= '',--房间名
	member_num_max = 0,	--最大成员数
	level = 0, 			--参加的等级要求
	other_srv_join = 0,	--是否显示及加入其他服的队伍
	active_id = 0,		--对应的活动项ID
	times_show_place = 0,--剩余次数显示位置
}

Team = {
	id = 0,			--队伍ID（全局唯一)
	child_game_type_id = 0,	--房间ID(见TeamBase.csv)
	code = '',		--密码
	member_Num = 0, --队伍人数
	members = false,--队伍成员
	captain_nick = '',--队长nick
	captain_gcid=0, --队伍gcid
	total_fc = 0,	--队伍总战力
	gang_id = 0,	--帮会ID
	area_id = 0,	--初始创建队伍的玩家的大区ID
}

TeamMember = {
	gcid = 0,			--角色ID
	gpid = 0,			--player_id
	nick = 0,			--带服务器的角色名
	total_fc = 0,		--总战力
	level = 0,			--等级
	gender = 0,			--性别
	cid = 0,			
	pid = 0,
	area_id = 0,		--大区ID
	is_robot = 0,		--是否机器人
--	is_quit = 0,		--是否已经退队
	
}


-- 机器人缓冲区
RobotBuffer = {
	robot_array = nil,		--数据
	write_pos = 0,			--写指针
	max_size = 0,			--数组最大长度
	gcid_hash = nil,		--保存gcid,不让出现重复的机器人
}
