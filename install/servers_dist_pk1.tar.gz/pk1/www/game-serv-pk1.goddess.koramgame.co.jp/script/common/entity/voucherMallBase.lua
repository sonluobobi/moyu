--[[
充值商城基础表
author : xingzeng
date : 2014-08-15
--]]

VoucherMallBase = {
	id = 0,           	 		-- ID
	sort_id = 0,				-- 类型 0:普通充值 1:购买活动卡(月卡，终身卡，基金) 2:充值赠送元宝类
	card_id = 0,				-- 对应活动卡ID(见RewardSpecailBase表)
	order_by_weight = 0,		-- 排位权重(值越高越排后面)
	voucher_amount = 0,			-- 需要充值的RMB
	voucher_amount_ios = 0,		-- 需要充值的RMB(韩语IOS用)
	get_gold = 0,				-- 充值可获得的魔石数
	reward_gold = 0,			-- 单次充值赠送的元宝数
	reward_times = 0,			-- 可赠送的总次数
	res_id = 0,					-- 图标资源ID
	is_other = 0,				-- 是否为其他(在购买了全部类型2的1次之后才会显示)
	is_recommend = 0,			-- 是否推荐(1:推荐, 0:不推荐)
	get_immediately = 0,		-- 月卡、基金充值立得XX魔石(仅仅客户端使用，海外右上角显示)
	
	pre_id = 0,					-- 前置商城道具ID(0：无要求， 非0：要求前置的道具已购买之后才会出现)
	buy_times = 0,				-- 购买次数限制, 已购买满就隐藏(0：无要求， 非0：有限制)
	google_play_id = '',		-- 谷歌平台的商品ID
	lenovo_itemid = '',			-- 联想平台的商品ID
	coolpad_itemid = '',		-- 酷派平台的商品ID
	appstore_itemid = '',		-- APPSTORE的商品ID
	quickios_itemid = '',		-- QUICK APPSTORE的商品ID
	onestoreapp_itemid = '',	-- 韩服第三方包商品ID
	other_google_play_id = '',	-- 其他渠道的谷歌商品ID
	other_appstore_itemid = '',	-- 其他渠道的APPSTORE的商品ID
	
	title = '',					-- 名字
	intro = '',					-- 描述
	tips = '',					-- 额外提示
	income_intro_params = '',	-- 奖励描述参数(目前用于基金)
	bonus_times = 0,			-- 获得魔石倍数
}
