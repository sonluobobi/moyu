--[[
角色通用奖励包结构定义
author : guoiyin.huang
date : 2014-11-20
--]]

-- 角色通用奖励包结构
RewardItem = {
	id = 0,				-- 奖励包的ID
	cid = 0,			-- 奖励包所属的角色ID
	sort_id = 0,		-- 奖励包类型
	module_id = 0,		-- 奖励来源模块ID
	status = 0,			-- 状态(0 可领取且未领取, 1 已领取, 2 不可领取)
	incomes = '',		--[[ 奖励包收益
						= { equips = {[equip_id]=[equip_num], [equip_id]=[equip_num]},
							silver = 0,
							voucher = 0,
							...
						}
						--]]
	title_id = 0,		-- 奖励包名称(语言包ID)
	intro_id = 0,		-- 奖励描述ID(语言包ID)
	share_id = 0,		-- 奖励分享(语言包ID)
	title = '',			-- 奖励包名称
	intro = '',			-- 奖励包描述
	share = '',			-- 奖励包分享
	timestamp = 0,		-- 奖励获取时间戳	
	expire = 0,			-- 奖励包过期时间	type:uint
}
RewardItem.__index = RewardItem

RewardEquipItem = {
	equip_id = 0,		--道具ID
	num = 0,			--数量
}

-- 奖励收益信息的结构
RewardItemIncome = {
	equips = nil,		--奖励道具ID,服务器为hash,客户端为数组	//type:RewardEquipItem[]
	var1 = '',			-- 特殊参数1
	var2 = '',			-- 特殊参数2
	var3 = '',			-- 特殊参数3
	var4 = '',			-- 特殊参数4
	equipstr = '',		-- 道具名字
	rank = 0,			-- 排名
	score = 0,			-- 积分
	win_type = 0,		-- 玩法结果类型（定义见 RewardDefs)	
}

-- 创建角色通用包奖励对象
function RewardItem:new(cid, module_id, reward_incomes, sort_id)
	local pool = {}
	assert(reward_incomes, 'reward_incomes is nil')
	local module_id = tonumber(module_id)
	
	local item = pool
	setmetatable(item, self)
	item.id = nil
	
	item.cid = cid
	item.sort_id = sort_id
	item.module_id = module_id
	item.incomes = reward_incomes
	item.expire = os.time() + RewardDefs.REWARD_EXPIRE_TIME
	item.timestamp = os.time()
	item.intro_id = RewardDefs.reward_from_module_intro[module_id] or 0
	item.title_id = RewardDefs.reward_from_module_name[module_id] or 0
	item.share_id = RewardDefs.reward_from_module_share[module_id] or 0
	item.title = nil
	item.intro = nil
	item.share = nil
	item.status = RewardDefs.REWARD_STATUS_NO_FETCH
	
	if reward_incomes.intro_id and reward_incomes.intro_id > 0 then
		item.intro_id = reward_incomes.intro_id
	elseif reward_incomes.intro then
		item.intro = reward_incomes.intro
		item.intro_id = 0
		reward_incomes.intro = nil
	end
	
	if reward_incomes.title_id and reward_incomes.title_id > 0 then
		item.title_id = reward_incomes.title_id
	elseif reward_incomes.title then
		item.title = reward_incomes.title
		item.title_id = 0
		reward_incomes.title = nil
	end

	if reward_incomes.share_id and reward_incomes.share_id > 0 then
		item.share_id = reward_incomes.share_id
	elseif reward_incomes.share then
		item.share = reward_incomes.share
		item.share_id = 0
		reward_incomes.share = nil
	end	
	
	return item
end
