--[[
计数器数据结构定义
author : guoyin.huang
date : 2014-12-15
--]]

Counter = {
	base_id = 0,		-- 计数器ID
	subcounter_id = 0,	-- 子计数器ID
	count = 0,			-- 已计数次数
	updated = 0,		-- 最后一次计数时间
	history = '',		-- 计数历史(eg:{20120308=2,20120309=3})
	count_total = 0,	-- 累计次数
	now_storeup_count = 0,	-- 当前累计的次数
	storeup_up_date = 0,	-- 累计的更新日期(eg:20120308)
	diy_data = '',		-- 自定义数据部分(清空count的时候同时会清空diy_data)
}

CounterBase = {
	base_id = 0,		-- 计数器ID
	sort_id = 0,		--计数器类型
	count = 0,			--次数最大值
	storeup_count = 0,	--可以积累的最大次数(按天累计)
	has_sub_counter = 0,--是否含子计数器
	ch_lev = nil,		--要求角色等级 (默认不要求)
}

