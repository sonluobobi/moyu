--[[
特殊奖励包表结构定义
author : xingzeng
date : 2012-06-24
--]]

RewardSpecialBase = {
	id = 0,					--奖励ID
	sort_id = 0,			--特殊奖励类型
	parent_reward_id = 0,	--父奖励ID
	reward_equips = {},		--奖励  type:Hashtable
	prof2reward_equips = {},--分职业奖励  type:Hashtable
	is_daily_reward = 0,	--是否每日发奖
	cond_v1 = 0,			--条件1	(如：角色等级，需要充值额度，战力)
	cond_v2 = 0,			--条件2
	max_fetch_num = 0,		--最大可领取次数(<=0代表不限次数)
	title = '',				--奖励标题
	intro = '',				--奖励描述
}
