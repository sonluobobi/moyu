--[[
掉落包基础表
author : xingzeng
date : 2014-10-13
--]]

DropPackBase = {
	id = 0,               -- 掉落包ID
	sort_id = 0,   		  -- 掉落包类型 0:普通掉落包
	title = '',           -- 掉落包名称  __s
	pack_proba = 0,       -- 掉落包的掉落概率	概率基数：10000 见DropPackDefs.lua
	equip_ids = false,	  -- 掉落的道具ID列表 [20102221,10011001] type:ArrayList __t
	equip_nums = false,	  -- 掉落的道具ID列表 [1,1] type:ArrayList __t  整个字段不填，默认为1
	equip_probas = false, -- 掉落的道具掉落概率列表 [30,40] type:ArrayList __t
	silvers = false,      -- 银子掉落 [min_silver, max_silver] type:ArrayList	__t
	exp = 0,              -- 经验掉落
	prof = 0,             -- 职业
	func_open_id = 0,     -- 功能开放ID
}
