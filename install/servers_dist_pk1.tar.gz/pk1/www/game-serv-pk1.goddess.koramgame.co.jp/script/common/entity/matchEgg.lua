--[[
孵蛋数据实体
author : jinlin.liu
date : 2016-09-09
--]]

MatchEggDb = {
	cid=0,             --角色id
	room_id=0,         --房间id
	room_status=0,     --当前状态
	room_usestatus=0,  --使用情况 1表示可使用 2表示不可使用
	pet_id=0,          --基础幻兽id
	role_petid=0,      --角色的幻兽id
	target_petid=0,    --对方幻兽基础id
	finish_time='',    --结束时间    
	chosed_equipid=0,  --选择的孵化器道具id
	sort_ids='',       --所有的幻兽ids
	other_nick = '',   --孵化中，会有对方玩家的名字
}

function MatchEggDb:new(cid,room_id,room_usestatus,chosed_equipid)
     local o = {}
     o.cid = cid
     o.room_id = room_id
     o.room_status = 1
     o.room_usestatus = room_usestatus
     o.pet_id = 0
     o.role_petid = 0
     o.finish_time = 0
     o.chosed_equipid = chosed_equipid
     o.sort_ids = {} 
     o.target_petid = 0    
     o.other_nick = ''
     return o
end

MatchRoom ={
      room_id = 0,    --孵化室id 情侣孵化室id为1，其它递增
      room_status = 0,    --孵化室状态 1.空闲 2.放了幻兽还未配对 3.孵化中 4.孵化完成
      pet_id = 0,    --基础幻兽id
      role_petid = 0,    --角色幻兽id
      finish_time = 0,    --孵化完成的时间戳
      chosed_equipid = 0,    --选中的孵化器id
      conditions = 0,    --条件 幻兽类型 ids  
      target_petid=0,   --情侣孵化室需要显示情侣的幻兽基础id
      other_nick = '',  --孵化中，会有对方玩家的名字
}

MatchPet = {
      pet_id   = 0,    --基础幻兽id 
     sort_ids = false,    --条件ids       type:ArrayList   
      role_petid   = 0,    --角色幻兽id
}

--csv结构
MatchEgg = {
    --id__kn,pettype1,pettype2,rewards__t
    id = 0,            --索引id
    pettype1 = 0,            --主幻兽类型
    pettype2 = 0,            --从幻兽类型
    rewards = false,         --概率孵化物{{精灵id,数量,概率值1,概率值2}} type:ArrayList     
}

function MatchEgg:new(pettype1,pettype2,rewards)
    local o = {}
    o.pettype1=pettype1
    o.pettype2=pettype2
    o.rewards=rewards
    return o
end
