--[[
finalwar 末日黄昏	系统定义
]]

FinalWarReward = {
	id = 0,			--key(开头是子玩法id和索引组成)
	subid = 0,	    --activity sub base中的配置
	fromrank = 0,	--起始排名
	endrank = 0,			--结束排名
	rankreward   = false,	--具体奖励 {[10130002]=100}	 //type:Hashtable
	title = 0,
}


function FinalWarReward:new(id,subid,fromrank,endrank,rankreward,title)
  local o={}
  o.id=id
  o.subid=subid  --子玩法id
  o.fromrank=fromrank --
  o.endrank=endrank
  o.rankreward=rankreward
  o.title = title
  return o
end

OneFinalWar = {
    pre_scene_ins_list = {},    --准备厅场景列表{[前哨id]={},[巅峰id]={}}
    war_scene_ins_list = {},    --战斗场景列表{[前哨id]={},[巅峰id]={}}
    fc_2_scene_ins_list = {},   --战力到实例列表
    
    status1 = 2,    --状态，0为准备厅，1为战场，2为结束
    status2 = 2,    --状态，0为准备厅，1为战场，2为结束

    gcid_2_chinfo = {}, --准备参加的玩家列表

    timer_id1 = nil,    --定时器1为巅峰
    timer_id2 = nil,    --定时器2为前哨

    gcid_2_scene_ins_id = {},   --玩家所在场景实例
    
    --巅峰战场的前3
    prerank = {},  -- {FinalWarRoleRank}
    activity_time = 0, --上一次的时间  
}

function OneFinalWar:new()
  local o={}
  o.pre_scene_ins_list={}
  o.war_scene_ins_list={}  --子玩法id
  o.fc_2_scene_ins_list={} --
  o.status1=2
  o.status2=2
  o.gcid_2_chinfo = {}
  o.timer_id1 = nil
  o.timer_id2 = nil
  o.gcid_2_scene_ins_id = {}
  o.gcid_2_chinfo = {}
  o.prerank = {}
  o.activity_time = 0
  return o
end

