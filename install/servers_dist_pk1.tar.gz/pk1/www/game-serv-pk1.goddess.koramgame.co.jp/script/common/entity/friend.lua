--[[
好友系统  entity
author: jianzhu
date: 2016-01-18
]]--

Friends = {
	------------------------ 数据表结构 start -----------------------
	id = 0,	--角色ID
	unique_key = '', --全局唯一id
	player_id = 0,  --玩家ID
	nick = '',  --玩家名称
	vip = 0, --玩家vip
	friend_list = '', --好友列表
	black_list = '', --黑名单列表
	enemy_list = '', --仇敌列表
	friend_request_log = '', --好友请求日志
	is_hefu = 0, --是否合服
	------------------------ 数据表结构 end -------------------------
		
	arr_friend = false, --好友列表(客户端使用) type:List<FriendsData>
	arr_black   = false,--黑名单(客户端使用) type:List<FriendsData>
	arr_enemy  = false,-- 仇敌(客户端使用) type:List<FriendsData>
}

--非数据库属性
local no_db_friend_field = {
	'unique_key',
	'player_id',
	'nick',
	'arr_friend',
	'arr_black',
	'arr_enemy',
}

FriendForDB = Utils.genDBEntity(Friends, no_db_friend_field)

FriendsData = {
	friend_unique_key = '', --角色全局唯一 unique_key
	friend_gcid = 0, --好友gcid  type:ulong
	friend_nick	= '', --好友昵称
	focus_time = 0, --关注时间，默认0
	last_talk_time = 0, --最近互聊时间，默认为0
	make_friends_time = 0, --交友时间
	friend_type = 0, --好友类型 1:本服|2:跨服
	is_online = false, --是否在线,true在线 type:bool
	vip_level = 0, --vip等级
	gender = 0, --性别
	prof =0, --职业
	intimacy =0, --亲密度
	is_both_friends = false, --是否互相为好友, type:bool
	friend_cid = 0, --好友角色id
	level = 0, --好友等级
}

function FriendsData:new(friend_data)
	local ret = friend_data

	ret.focus_time = 0
	ret.last_talk_time = 0
	ret.make_friends_time = Time:getSecondsNow()
	ret.intimacy = 0

	return ret 
end