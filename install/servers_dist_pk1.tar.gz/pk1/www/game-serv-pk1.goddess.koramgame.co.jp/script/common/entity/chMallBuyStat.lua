--[[
商城道具购买记录

@author : guoyin.huang
@created : 2015-02-10
]]--


ChMallBuyStat = 
{
	id = 0,							--商城记录id
	character_id = 0,				--统计的角色ID（0:代表全服统计)
	mall_id = 0,					--商品ID
	mall_sort_id = 0,				--商城分类ID
	mall_order_by = 0,				--商城位置ID
	sale_start = '',				--限购开始时间
	equip_id = 0,					--限购的道具ID
	buy_num = 0,					--已购买的数量统计总和
	created = '',					--创建时间
	updated = '',					--更新时间
}
ChMallBuyStat.__index = ChMallBuyStat

function ChMallBuyStat:new(pool, data)
	local o = pool or {}
	
	for key, value in pairs(data) do
		if self[key] and value ~= self[key] then
			o[key] = value
		end
	end
	
	setmetatable(o, self)
	
	return o
end
