--[[
邀请码
author : lin.jie
date : 2014-02-18
--]]
local Time = Time

-- 邀请码记录
InviteCode = {
	invite_code = '', 		--邀请码
	area_id = 0, 			--邀请人所在的大区ID
	player_id = 0, 			--邀请人帐号ID
	guid = '',				--邀请人角色GUID
	level = 0,				--邀请人的等级
	nick = '',				--邀请人角色名
	created = '',			--创建时间
	updated = '',			--更新时间
}

function InviteCode:new(invite_code, area_id, player_id, guid, nick, level)
	local o = {}
	o.invite_code = invite_code
	o.area_id = area_id
	o.player_id = player_id
	o.guid = guid
	o.nick = nick
	o.level = level
	
	return o
end

-- 邀请码使用记录
InviteCodeUsed = {
	id = 0,				--自增ID
	invite_code = '',		--邀请码
	invitee_guid = '',		--被邀请人的GUID
	invitee_area_id = 0,	--被邀请人的大区ID
	invitee_player_id = 0,	--被邀请人的帐号ID
	invitee_cid = 0,		--被邀请人的角色ID
	invitee_nick = '',		--被邀请人的昵称
	invitee_fight_capacity = 0,--被邀请人的战力
	invitee_level = 0,		--被邀请人的等级
	invitee_prof = 0,		--被邀请人职业
	invitee_gender = 0,		--被邀请人性别
	invitee_vip = 0,		--被邀请人VIP
	is_new = 0,				--是否新被邀请人(邀请码主人未查看过，就是代表新人)
	created = '',			--创建时间
	updated = '',			--更新时间
}

function InviteCodeUsed:new(invite_code, invitee_guid, invitee_area_id, invitee_player_id, invitee_fight_capacity, 
					invitee_level, invitee_nick, invitee_gender, invitee_prof, invitee_cid, invitee_vip)
	local now_dtime = Time:getDateTimeStrNow()
	local invite_code_used = {
		invite_code = invite_code,
		invitee_guid = invitee_guid,
		invitee_area_id = invitee_area_id,
		invitee_player_id = invitee_player_id,
		invitee_nick = invitee_nick,
		invitee_fight_capacity = invitee_fight_capacity,
		invitee_level = invitee_level,
		invitee_gender = invitee_gender,
		invitee_prof = invitee_prof,
		invitee_cid = invitee_cid,
		invitee_vip = invitee_vip,
		created = now_dtime,
        updated = now_dtime,
	}
	return invite_code_used
end

-- 被邀请人(提供客户端使用)
InviteCodeInvitee = {
	invitee_area_id = 0,	--被邀请人的大区ID
	invitee_cid = 0,		--被邀请人的角色ID
	invitee_nick = '',		--被邀请人的昵称
	invitee_fight_capacity = 0,--被邀请人的战力
	invitee_level = 0,		--被邀请人的等级
	invitee_prof = 0,		--被邀请人职业
	invitee_gender = 0,		--被邀请人性别
	invitee_vip = 0,		--被邀请人VIP
	invitee_guid = '',		--被邀请人的GUID
}

-- 角色邀请信息
ChInviteCodeInfo = {
	invite_code_used = nil,	-- 已使用的邀请码对象
	code2invitee = nil,		-- 被邀请成功的列表 code2invitee[id] = InviteCodeUsed
	last_up_time = 0,
}

function ChInviteCodeInfo:new(invite_code_used)
	local o = {}
	o.invite_code_used = invite_code_used
	o.last_up_time = 0
	return o
end


