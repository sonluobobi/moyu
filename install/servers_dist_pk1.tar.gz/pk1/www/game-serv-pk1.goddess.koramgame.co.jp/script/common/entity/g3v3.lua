--[[
3V3	系统定义
]]

G3v3Member = {
	gcid = 0,			--gcid 		//type:long
	nick = '',			--nick
	level = 0,			--玩家等级
	killed_score = 0,	--被杀可获得的积分
	harm = 0,			--总伤害值
	score = 0,			--总积分
	attack_times = 0,	--攻击次数
	attack_times_perc = 0,--攻击次数百分比	type:float
	honour = 0,			--获得的荣誉
	honour_multi = 0,	--荣誉的倍数
	fight_fc = 0,		--战力
	picture = 0,		--图标
	kill_num = 0,		--杀人数
	prof = 0,			--职业
	gender = 0,			--性别
}

G3v3CampInfo = {
	camp = 0,			--阵营
	total_score = 0,	--总的积分
	total_fight_fc = 0,	--总战力
	score = 0,			--剩下的积分
	members   = false,	--成员	type:List<G3v3Member>
}

