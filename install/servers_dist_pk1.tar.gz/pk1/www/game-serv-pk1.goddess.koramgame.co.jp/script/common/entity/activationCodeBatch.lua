--[[
激活码批次实体

@author : xingzeng jiang
@created : 2012-12-22
]]--

ActivationCodeBatch = 
{
	id = 0,							--激活码批号ID
	activation_code_sort_id = 0,	--激活码分类ID (1：普通类, 2: 无前缀类)
	title = '',						--激活码批次名
	
	activation_prefix = '',			--该批次激活码前缀
	activation_code_total = 0,		--该批次激活码总数量
	server_ids = '',				--用于服务器标识串(如：s1,s34,t1,s333 = 0,"0"或""代表全服)
	
	gift_pack = '',					--激活码兑换礼包ID串
	reward_equip_nums = false,		--gift_pack格式化之后的数据：激活码兑换礼包ID 到 数组的table type:Hashtable
	
	character_level_max = 0,    	--允许角色最大等级 (0:不限制）
	character_level_min = 0,   	 	--允许角色最小等级
	use_num_pre = 0,           	 	--每人可使用次数（0：不限制）
	is_limit_character = 0,     	--是否限制角色（0：不限制角色，限制player_id，1：限制角色，不限制player_id）
	channel = 0,					--渠道ID
	channel_title = '',				--渠道名
	is_global_use = 0,				--是否所有人可用,1是,0否
	
	start_time = '',				--激活码有效开始时间
	end_time = '',					--激活码有效结束时间
	stime_sec = nil,				--活动开始时间(时间戳 仅内存中用，DB没有该字段)
	etime_sec = nil,				--活动结束时间(时间戳 仅内存中用，DB没有该字段)
	
	intro = '',						--介绍
	created = '',					--创建时间
	updated = '',					--更新时间
}
ActivationCodeBatch.__index = ActivationCodeBatch

function ActivationCodeBatch:new(pool, data)
	local o = pool or {}
	
	for key, value in pairs(data) do
		if self[key] and value ~= self[key] then
			o[key] = value
		end
	end
	
	setmetatable(o, self)
	
	return o
end
