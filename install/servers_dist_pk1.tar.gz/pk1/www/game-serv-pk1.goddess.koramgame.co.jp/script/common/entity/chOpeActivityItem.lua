--[[
活动项表角色参加记录实体

@author : xingzeng jiang
@created : 2012-12-22
]]--


ChOpeActivityItem = 
{
	id = 0,							--自增id
	character_id = 0,				--角色ID
	activity_id = 0,				--活动ID
	activity_item_id = 0,			--活动项ID
	activity_item_sort_id = 0,		--活动项分类ID
	activity_item_start_time = '',	--活动项开始时间
	
	state = 0,						--状态：nil/0:已领取, 1:未领取
	join_times = 0,					--活动内参与次数
	today_join_times = 0, 			--当天参与次数
	join_last_datetime = '',		--最后一次参与时间
	join_last_time = nil,			--最后一次参与时间
	bout_id = 0,					--轮数ID
	
	created = '',					--创建时间
	updated = '',					--更新时间
}
ChOpeActivityItem.__index = ChOpeActivityItem

local Time = Time

function ChOpeActivityItem:new(pool, data)
	local o = pool or {}
	
	for key, value in pairs(data) do
		if self[key] and value ~= self[key] then
			o[key] = value
		end
	end
	o.join_last_time = Time:getSecondsByDateTimeStr(o.join_last_datetime)
	setmetatable(o, self)
	
	return o
end
