--[[
角色幻兽装备碎片数据结构定义
author : xingzeng
date : 2014-11-03
--]]

-- 幻兽碎片数据结构
ChPetBaowuChip = 
{
	id = 0,				-- 角色宝物碎片ID
	cid = 0,			-- 所属角色ID
	player_id = 0,		-- 所属角色的帐号ID
	chip_equip_id = 0,	-- 宝物碎片基础ID
	stack_num = 0,		-- 拥有数量
	
	created = '',		-- 创建时间
	updated = '',		-- 更新时间
	
}

local Time = Time
function ChPetBaowuChip:new(cid, player_id, chip_equip_id, stack_num)
	local o = {}
	o.cid = cid
	o.player_id = player_id
	o.chip_equip_id = chip_equip_id
	o.stack_num = stack_num or 1
	o.created = Time:getDateTimeStrNow()
	return o
end

-- 客户端抢夺界面需要的属性
BaowuChipForClient = {
	chip_equip_id = 0,	--宝物碎片道具ID
	cid = 0,			--宝物所属的角色ID
	nick = '',			--宝物所属的角色名
	level = 0,			--宝物所属的角色等级
	prof = 0,			--宝物所属的角色职业
	fight_capacity = 0,	--宝物所属的角色战力
	fight_pet_id = 0,	--出战幻兽基础ID
	heti_pet_ids = false,	--合体的幻兽基础ID	type:List<int>
}

function BaowuChipForClient:new(cid, ch_attrib, chpet_baowu_chip, nick)
	local o = {}
	o.chip_equip_id = chpet_baowu_chip.chip_equip_id
	o.cid = chpet_baowu_chip.cid
	o.nick = nick or ch_attrib.nick
	o.level = ch_attrib.level
	o.prof = ch_attrib.prof
	o.fight_capacity = ch_attrib.fight_capacity
	o.fight_pet_id = ch_attrib.fight_pet_id
	o.heti_pet_ids = ch_attrib.heti_pet_ids
	return o
end
