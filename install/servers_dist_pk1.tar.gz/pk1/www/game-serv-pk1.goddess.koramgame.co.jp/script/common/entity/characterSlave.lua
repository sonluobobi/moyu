--[[
角色奴隶信息
author : fuqian.liao
date : 2015-04-01
--]]

CharacterSlave = {
	character_id = 0,		-- 角色id type:long
	player_id = 0,			-- 玩家id
	nick = '',				-- 角色名字
	slave_exp = 0,			-- 仆从贡献的经验
	last_devote_exp_time = 0, --仆从最近贡献经验的时间戳
	slave_type = 0,			-- 身份类型
	slave_type_expire = 0,	-- 身份类型过期时间
	safe_expire = 0,                 --保护期过期时间
	bianchi_expire = 0,           --鞭笞过期时间
	taohao_expire = 0,             --讨好过期时间
	master_cid = 0,                  -- 尊主的角色id
	master_nick = '',		-- 尊主的名字
	counters   = '',                    -- 计数器  type:SlaveCounters__new
	my_losers = '',                  --手下败将 
	my_enemys = '',			--夺仆之敌 
	my_slaves = '',			--仆从 
	msg_list = '', 			--日志记录    
	
	---------------- 非数据库字段 (客户端使用)------------------------------------
	arr_loser = false,                  --手下败将  type:List<SlaveMyLoser>
	arr_enemy = false,			--夺仆之敌  type:List<SlaveMyEnemy>
	arr_slave = false,			--仆从      type:List<SlaveMySlave>
	
	master_fight_capacity = 0,    --尊主的战力
	master_gender = 0,                  --尊主的性别
	master_prof    = 0,                   --尊主的职业
	is_display_texiao = 0,           --是否播放特效(如果为1，就不立即更新界面，而是播放特效，然后再更新界面)
	
	master_wuqi_eid = 0,			--武器装备基础ID
	master_yifu_avatar_eid =0,		--衣服或时装道具基础ID
	master_qihun_wuqi = 0,
	master_qihun_yifu = 0,
}
--非数据库属性
local arr_no_db_field = {
	'arr_loser',
	'arr_enemy',
	'arr_slave',
	'master_gender',
	'master_prof',
	'master_fight_capacity',
	'is_display_texiao',
	
	'master_wuqi_eid',
	'master_yifu_avatar_eid',
	'master_full_jl_lev',
	'master_qihun_yifu',
	'master_qihun_wuqi'
 }
 
 --数据库实体
SlaveForDB,SlaveFieldForDB = Utils.genDBEntity(CharacterSlave, arr_no_db_field)

-- new 一个角色奴隶对象
function CharacterSlave:new(character_id, player_id, nick)
	local ret = {}

	ret.character_id = character_id
	ret.player_id = player_id
	ret.nick = nick
	ret.slave_exp   = 0
	ret.slave_type = 0
	ret.slave_type_expire = 0
	ret.safe_expire       = 0
	ret.bianchi_expire = 0
	ret.taohao_expire   = 0
	ret.master_cid        = 0
	ret.master_nick = ''
	
	ret.counters = nil
	
	ret.my_losers     = nil
	ret.my_enemys     = nil
	ret.my_slaves     = nil
	ret.msg_list	  = nil

	return ret
end

-------------------------------------------------------------------------------

-- 我的手下败将结构
SlaveMyLoser = {
	character_id = 0,           -- 角色id type:long
	nick = '',
	level = 0,
	slave_type = 0,
	slave_type_expire = 0,
	safe_expire = 0,
	fight_capacity = 0,
	gang_title = '',
	master_nick = '',
	master_fight_capacity = 0,
	fight_pet_id = 0,
	heti_pet_ids = {}, -- type:ArrayList
	my_time = 0,	  -- 失败时间
}

-- new 一个竞技场失败者对象
-- character_id : 角色id
function SlaveMyLoser:new(character_id)
	local ret = {}
	ret.character_id = character_id
	ret.my_time          = Time:getSecondsNow()
	
	return ret
end

-------------------------------------------------------------------------------

-- 我的仆从结构
SlaveMySlave = {
	character_id = 0,  -- 角色id type:long
	nick     = '' ,             --角色名称
	expire = 0,		   -- 奴隶的过期时间
	level  = 0,		   -- 被抓捕时候的等级
	gender = 0,  --性别
	prof    = 0,   --职业
	last_devote_time = 0, -- 奴隶的最后一次贡献经验时间
	
	wuqi_eid = 0,			--武器装备基础ID
	yifu_avatar_eid =0,		--衣服或时装道具基础ID	
	qihun_wuqi = 0,			-- 器魂武器
	qihun_yifu = 0,			-- 器魂衣服	
}

-- new一个我的仆从
-- character_id : 角色id
-- expire : 过期时间
-- level : 被抓的时候的等级
function SlaveMySlave:new(slave_cid,slave_nick,slave_detail)
	local ret = {}

	
	ret.character_id = slave_cid
	ret.nick               = slave_nick
	ret.expire           = Time:getSecondsNow() + SlaveDefs.TIME_FOR_KEEP_SLAVE_SECOND
	ret.level             = slave_detail.level
	ret.gender           = slave_detail.gender
	ret.prof              = slave_detail.prof
	ret.last_devote_time = Time:getSecondsNow()
		
	ret.wuqi_eid              = slave_detail.wuqi_eid
	ret.yifu_avatar_eid       = slave_detail.yifu_avatar_eid
	ret.qihun_wuqi			  = slave_detail.qihun_wuqi
	ret.qihun_yifu			  = slave_detail.qihun_yifu

	return ret
end


-------------------------------------------------------------------------------

-- 我的敌人结构
SlaveMyEnemy = {
	character_id = 0, -- 角色id type:long
	my_time = 0,		  -- 奴隶的过期时间
}

-- new 一个我的敌人
-- character_id : 角色id
function SlaveMyEnemy:new(character_id)
	local ret = {}

	ret.character_id = character_id
	ret.my_time = Time:getSecondsNow()

	return ret
end


-------------------------------------------------------------------------------

-- 消息体结构
SlaveMsg = {
	my_time = 0, -- 消息发生时间
	msg_id = 0,
	param1 = '',
	param2 = '',
	param3 = '',
}

-- new 奴隶系统消息
-- msg : 消息
-- param1 : 参数1
-- param2 : 参数2
-- param3 : 参数3
function SlaveMsg:new(msg_id, param1, param2, param3)
	local ret = {}

	ret.my_time = Time:getSecondsNow()
	ret.msg_id = msg_id
	ret.param1 = param1
	ret.param2 = param2
	ret.param3 = param3

	return ret
end

-------------------------------------------------------------------------------

-- 计数器结构
SlaveCounters = {
	tdate = 0, -- 计数器日期，例如 20150401
	accept_time     = 0, --收徒次数
	resist_time     = 0, --反抗次数
	taohao_time     = 0, --讨好次数
	bianchi_time   = 0, --鞭笞次数
	cry_help_time = 0, --求救次数
}

-------------------------------------------------------------------------------
