--[[
商城数据实体
author : guoyin.huang
date : 2014-01-15
--]]

MallBase = {
	id = 0,		--
	sort_id = 0,	--商城类型
	title = '',		--商城名称
	order_by = 0,	--排序
}

-- 商城ITEM表
DbMallItem = {
	-- 基础
	id = 0,			--商品ID
	sort_id = 0,	--类型
	equip_id = 0,	--道具ID

	order_by = 0,	--排序ID
	buy_gold = 0,	--元宝价格
	once_num = 0,	--一个商品对应的道具数量
	use_voucher_gold = 0,	--是否必须使用充值魔石（1为必须使用）

	buy_gold_add = 0,			--价格增量
	buy_gold_add_times_limit = 0,		--价格增长多少次后，不再增长
	is_hot = 0,		--是否热卖
	sale_start = '',--销售开始时间
	sale_end = '',	--销售结束时间
	
	--折扣相关
	rebate_gold = 0,	--折扣后的元宝数,没有或为0则为不折扣
	rebate_start = '',	--折扣开始时间
	rebate_end = '',	--折扣结束时间

	--开放条件
	vip_level = 0,	--VIP等级需求

	--限购
	srv_limit_type = 0,			--限购类型 0:不限购,1:总量限制,2:每天限购
	srv_limit_cnt = 0,			--全服限买数量
	ch_limit_type = 0,			--角色限购类型
	vip0 = 0,				--VIP限买数量
	vip1 = 0,				--VIP限买数量
	vip2 = 0,				--VIP限买数量
	vip3 = 0,				--VIP限买数量
	vip4 = 0,				--VIP限买数量
	vip5 = 0,				--VIP限买数量
	vip6 = 0,				--VIP限买数量
	vip7 = 0,				--VIP限买数量
	vip8 = 0,				--VIP限买数量
	vip9 = 0,				--VIP限买数量
	vip10 = 0,				--VIP限买数量
	vip11 = 0,
	vip12 = 0,
	rebate_equip_id = 0,		--打折卡ID
}

MallItem = {
	-- 基础
	id = 0,			--商品ID
	sort_id = 0,	--类型
	equip_id = 0,	--道具ID
	order_by = 0,	--排序ID
	buy_gold = 0,	--元宝价格
	once_num = 0,	--一个商品对应的道具数量
	use_voucher_gold = 0,	--是否必须使用充值魔石（1为必须使用）
	
	buy_gold_add = 0,			--价格增量
	buy_gold_add_times_limit = 0,		--价格增长多少次后，不再增长

	is_hot = 0,		--是否热卖
	sale_start = 0,--销售开始时间
	sale_end = 0,	--销售结束时间
	
	--折扣相关
	rebate_gold = 0,	--折扣后的元宝数,没有或为0则为不折扣
	rebate_start = 0,	--折扣开始时间
	rebate_end = 0,	--折扣结束时间

	--开放条件
	vip_level = 0,	--VIP等级需求

	--限购
	srv_limit_type = 0,			--限购类型 0:不限购,1:总量限制,2:每天限购
	srv_limit_cnt = 0,			--全服限买数量
	ch_limit_type = 0,			--角色限购类型
	vip0 = 0,				--VIP限买数量
	vip1 = 0,				--VIP限买数量
	vip2 = 0,				--VIP限买数量
	vip3 = 0,				--VIP限买数量
	vip4 = 0,				--VIP限买数量
	vip5 = 0,				--VIP限买数量
	vip6 = 0,				--VIP限买数量
	vip7 = 0,				--VIP限买数量
	vip8 = 0,				--VIP限买数量
	vip9 = 0,				--VIP限买数量
	vip10 = 0,				--VIP限买数量
	vip11 = 0,
	vip12 = 0,

	item_key = '',			--唯一KEY（服务器使用）
	srv_buy_cnt = 0,		--全服已购买数量(客户端使用)
	ch_buy_cnt = 0,			--角色已购买数量(客户端使用)
	rebate_equip_id = 0,	--打折卡ID()
}

MallItem.__index = MallItem

function MallItem:new(pool, data)
	local o = pool or {}
	
	for key, value in pairs(data) do
		if self[key] and value ~= self[key] then
			o[key] = value
		end
	end
	
	setmetatable(o, self)
	
	return o
end

-- 商城消费记录实体
MallBuyRecordItem = {
	id = 0,				--	记录的ID
	character_id = 0,	-- 	角色ID
	mall_id		= 0,	--  商品ID
	mall_sort_id = 0,	--  类型
	mall_order_by = 0,	--  排序
	sale_start = '',		--  销售开始时间
	equip_id = 0,		--  道具ID
	buy_num = 0,		--	已购买数量
	once_num = 0,		--  一个商品对应的道具数量
--	updated = '',
}

function MallBuyRecordItem:new(character, goods_base, num)
	local o = {}
	o.character_id = character.id
	o.mall_id = goods_base.id
	o.mall_sort_id = goods_base.sort_id
	o.mall_order_by = goods_base.order_by
	o.sale_start = goods_base.sale_start
	o.equip_id = goods_base.equip_id
	o.buy_num = num
	o.once_num = goods_base.once_num or 1
	return o
end


