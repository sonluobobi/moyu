--[[
婚戒突破升级系统
author: liujinlin
date: 2016-11-02
]]--

--db中数据
LoverRing = {
	cid = 0,
	cur_level = 0,
	cur_exp = 0,
	had_tupo = true,	
	added_attr = {},
	is_marry = false,
}

function LoverRing:new(cid,level,had_tupo,is_marry)
  local o = {}
  o.cid = cid
  o.cur_level = level
  o.cur_exp = 0
  o.had_tupo = had_tupo
  o.added_attr = {}
  o.is_marry = is_marry 
  return o
end

--配置数据
LoverRingUpgrade = {
  --id__kn,quality,level,next_tupolevel,one_time_exp,total_exp,upgrade_equip__t,tupo_equip__t,upgrade_attr__t,tupo_attr__t
  quality = 0,
  level = 0,
  next_tupolevel = 0,
  one_time_exp=0,
  total_exp=0,
  upgrade_equip=false,  -- 升级/加经验需要的道具  type:ArrayList
  tupo_equip=0,         -- 突破需要的魔石
  upgrade_attr=false,   -- 升级获得的属性  type:Hashtable
  tupo_attr=false,      -- 突破获得的属性  type:Hashtable
}

function LoverRingUpgrade:new(quality,level,next_tupolevel,one_time_exp,total_exp,
    upgrade_equip,tupo_equip,upgrade_attr,tupo_attr)
  local o={}
  o.quality=quality
  o.level=level  --名字
  o.next_tupolevel=next_tupolevel --斩杀力
  o.one_time_exp=one_time_exp
  o.total_exp=total_exp
  o.upgrade_equip=upgrade_equip
  o.tupo_equip=tupo_equip
  o.upgrade_attr=upgrade_attr
  o.tupo_attr=tupo_attr
  return o
end

