--[[
快速日期计算,只要针对当前时间的计算才能高效(跨天时才会重算)
author : guoyin.huang
date : 2015-01-07
使用方法: 
	模块中使用 Date:new() 新建自己模块的对象
	每次使用前，调用Date:updateTime(timestamp) 更新内容
	即可直接使用
]]--
Date = Date or 
{
	--时间戳
	timestamp = 0,				--设置的时间戳
	--今天 
	unix_today_start = 0,		--今天 00:00:00
	unix_today_end = 0,			--今天 23:59:59
	str_today = nil	,			--今天 2014-12-12
	--昨天
	unix_yestoday_end = 0,		--昨天 23:59:59
	str_yestoday = nil,			--昨天 2014-12-11
	unix_yestoday_start = 0,	--昨天 00:00:00	
}
Date.__index = Date

function Date:new()
	local o = {}
	setmetatable(o, Date)
	return o
end

function Date:updateTime(timestamp)
	local timestamp = timestamp or os.time()
	self.timestamp = timestamp
	if timestamp < self.unix_today_start or timestamp > self.unix_today_end then
		local now_tbl = os.date("*t", timestamp)
		now_tbl.hour = 0
		now_tbl.min = 0
		now_tbl.sec = 0
		self.unix_today_start = os.time(now_tbl)
		self.unix_today_end = self.unix_today_start + 24 * 60 * 60 - 1
		self.unix_yestoday_end = self.unix_today_end - 24 * 60 * 60
		self.unix_yestoday_start = self.unix_today_start - 24 * 60 * 60
		self.str_today = os.date("%Y-%m-%d", self.unix_today_end)
		self.str_yestoday = os.date("%Y-%m-%d", self.unix_yestoday_start)		
	end
end

