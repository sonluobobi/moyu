-- 
--------------------------------------------------------------------------------
-- 数组 工具
--
--
-- author: hproof
-- created: 2012/4/9 13:45:48
--
--------------------------------------------------------------------------------
--

local string_gmatch = string.gmatch
local table_concat = table.concat
local math_random = math.random
local table_remove = table.remove

array = array or {}

--[[  --  BlockCommentNo_2
--- OOP 用法
function array.new()
  local o = {}
  o.__index = array
end
--]]  --  BlockCommentNo_2


--- 从 str 中解析 arr 数组, 每个元素是一个 number
--    注意, 该函数会把 "1,,2||||3" 解析为 [1,2,3], 多个分隔符会被合并
--
-- @return array / nil
--
function array.from_mumerical_string( str, rec_arr )
  if str then
    local arr = rec_arr or {}
    local n = 0
    for w in string_gmatch( str, "(%d+)" ) do
      n = n + 1
      arr[n] = tonumber(w)
    end
    for i=n+1,#arr do arr[i] = nil end
    return arr
  end
end

--- 返回 value 在 arr 中的第一个索引号, field=nil 用于获取元素子属性
function array.indexof( arr, value, field )
  if not( arr and value ) then return end
  if field then
    for i,v in ipairs(arr) do
      if v[field] == value then return i end -- 比较 a[i][field] 和 value
    end
  else
    for i,v in ipairs(arr) do
      if v == value then return i end      -- 比较 a[i] 和 value
    end
  end
end
array.contains = array.indexof

--- 对 indexof 的简单封装, 返回指定元素
function array.find( arr, value, field )
  local index = array.indexof( arr, value, field )
  return index and arr[index]
end

--- 在数组中插入一个元素, 如果重复着忽略
function array.insert_if_not_exist( arr, value )
	local n = #arr
	for i=1, n do
		if arr[i] == value then return end
	end
	arr[n+1] = value
end

--- 查找未使用的 index, 例如当数组 [1,3,5,7,9] 中有值时, 会返回 [2,4,6,8,10] 表示空闲位置
-- @param maxn				查找上边界
-- @param start=1			查找开始位置, 如果不在 min/max 范围内, 则自动调整
-- @param minn=1 			查找下边界
-- @return					index / nil
function array.find_unused_indexs( arr, maxn, start, minn )
	if arr then
		minn = minn or 1
		start = start or 1
		assert( minn <= maxn )
		if start < minn then start = minn elseif start > maxn then start = maxn end
		for i=start,maxn do if not arr[i] then return i end end
		for i=minn,start-1 do if not arr[i] then return i end end
	end
end

--- 删除1个value, 返回是否成功, field=nil 用于获取元素子属性
function array.remove( arr, value, field )
  if not( arr and value ) then return end
  local n = #arr
  if field then
    for i=1, n do
      if arr[i][field] == value then            -- 测试 arr[i][field]
        arr[i] = arr[n]
        arr[n] = nil
        return true
      end
    end
  else
    for i=1, n do
      if arr[i] == value then                   -- 测试 arr[i]
        arr[i] = arr[n]
        arr[n] = nil
        return true
      end
    end
  end
end

--- 根据字段名, 删除重复的元素
-- @param field 测试的字段名
-- @param bsetnil 是否把后面多余的内容设置为 nil
-- @return n  返回新的个数
function array.remove_duplicate_by_field( arr, n, field, bsetnil )
	if not arr or not n or n==0 then return 0 end
	local flags, j = {}, 0
	for i=1, n do 
		local v = assert(arr[i])
		local vv = assert(v[field])
		if not flags[vv] then
			flags[vv] = true
			j = j + 1
			arr[j] = v
		end
	end
	if bsetnil then
		for i=j+1, n do arr[i] = nil end
	end
	return j
end

--- 判断 arr1 是否包含所有 arr2 中的元素
function array.isContains( arr1, arr2 )
	for _,v2 in pairs(arr2) do
		local found = false
		for _,v1 in pairs(arr1) do
			if v2 == v1 then found = true break end
		end
		if not found then return false end
	end
	return true
end

--- 判断val是否在数组arr里
function array.in_array(val, arr)
	if val and arr then
		for _, v in pairs(arr) do
			if v == val then
				return true
			end
		end
	end
	return false
end

--- 集合运算, 并集
local _tmp_get_union_set = {}
function array.get_union_set(arr1, arr2)
	local tmp = _tmp_get_union_set
	for i=1,#arr1 do tmp[arr1[i]] = true end
	for i=1,#arr2 do tmp[arr2[i]] = true end
	local ret = {}
	for k,v in pairs(tmp) do
		ret[ #ret+1 ] = k
	end
	for i=1,#ret do tmp[ret[i]] = nil end
	return ret
end

--- 集合运算, 计算 不同时属于 arr1/arr2 的元素
function array.get_xor( arr1, arr2 )
	local ret = {}
	local function foo()
		for i=1,#arr1 do
			local v1 = arr1[i]
			for j=1,#arr2 do
				local v2 = arr2[j]
				if v2 == v1 then v1 = nil break end
			end
			if v1 then ret[#ret+1] = v1 end
		end
	end
	foo()
	arr1, arr2 = arr2, arr1
	foo()
	return ret
end

--- 把 value 添加到 arr 中
function array.add( arr, value )
  if not( arr and value ) then return end
  arr[ #arr + 1 ] = value
end

function array.addArray(tbl1, tbl2)
	tbl1 = tbl1 or {}
	tbl2 = tbl2 or {}
	for _, v in ipairs(tbl2) do
		tbl1[#tbl1+1] = v
	end
	return tbl1
end

-- 获取数组大小
function array.size(arr)
	return table.isTable(arr) and #arr or 0
end

-- 从数组中取出一段
-- length = nil (length == nil 时, 取从offset开始的到结尾的数据)
-- return array
function array.array_slice(arr, offset, length, ret_arr)
	local ret_arr = ret_arr and ret_arr or {}
	local arr_size = #arr
	local end_idx = length and offset + length - 1 or arr_size
	local j = 1
	
	if end_idx > arr_size then end_idx = arr_size end
	
	for i = offset, end_idx, 1 do
		ret_arr[j] = arr[i]
		j = j + 1
	end
	
	return ret_arr
end

--- 用于 for 迭代器, 返回 [a..b, c..d]
--		例如: for i in count2(1, 10, 110, 110 ) do print(i) end
function array.count2(a, b, c, d )
	local n1, n2, i = b-a, d-c, 0
	local function foo()
		if i <= n1 then
			if i == n1 then
				n1, i = -1, 0
				return b
			end
			i = i + 1
			return a + i - 1
		elseif i <= n2 then
			i = i + 1
			return c + i - 1
		end
	end
	return foo
end


--- 用于 for 迭代器, 返回 [ start .. up, 1 .. start ]
--		例如: for i in count_loop(1, 10, 5 ) do print(i) end   --> 5, 6, 7, 8, 9, 10, 1, 2, 3, 4 
function array.count_loop( low, up, start )
	assert( start >= low and start <= up ) 
	local s, i = true, start - 1
	local function foo()
		i = i + 1
		if s then
			if i == up then
				s, i = false, low - 1
				return up
			end
			return i
		elseif i < start then
			return i
		end
	end
	return foo
end


--- 获取所有字段
function array.fields( arr, field )
	local ret = {}
	for i, v in ipairs( arr ) do
		ret[i] = v[ field ]
	end
	return ret
end


--[[  --  BlockCommentNo_3
do
  local arr = array.from_mumerical_string("1,2,3")

  print("dump arr:")
  print(table_concat(arr, ","))

  print("add 4:")
  array.add( arr, 4 )
  print(table_concat(arr, ","))

  print("remove 3:")
  array.remove(arr, 3)
  print(table_concat(arr, ","))

  arr = {}
  local o1 = {id=1, name="o1"}
  local o2 = {id=2, name="o2"}
  array.add(arr, o1)
  array.add(arr, o2)
  print( "o1", array.indexof( arr, o1 ) )
  print( "id=2", array.indexof( arr, 2, "id" ) )

  array.remove(arr, o1)
  print( "o1", array.indexof( arr, o1 ) )
  array.remove(arr, 2, "id")
  print( "o2", array.indexof( arr, o2 ) )
end
--]]  --  BlockCommentNo_3


--- 字符串中是否包含某个字串
-- @param split = ','
function array.has_sub_string( str, sub, split )
	if str then
		local n1 = string.find( str, sub, 1, true )
		if n1 then
			local byte = string.byte
			local b_split = byte( split or ',' , 1 )
			if n1 > 1 and byte( str, n1-1 ) ~= b_split then 
				return 
			end
			local n2 = n1 + #sub
			if n2 <= #str and byte( str, n2 ) ~= b_split then 
				return 
			end
			return true
		end
	end
end

-- 清空数组
function array.clear_array(arr)
	if table.isTable(arr) then
		for i = #arr, 1, -1 do
			arr[i] = nil
		end
	end
	
	return arr
end


--- 写入 int 数组到 packet 中
function array.packIntArray( packet, arr )
	-- 空数组
	if type(arr) ~= 'table' then
		packet:writeInt(0)
		return
	end
	-- 写入每个 int 元素
	local len = #arr
	packet:writeInt(len)
	for i=1, len do
		packet:writeInt( arr[i] )
	end
end

-- 删除数组中一个指定值
function array.removeOne(arr, value)
	if not( arr and value ) then return end
	local idx
	for i,v in ipairs(arr) do
		if v == value then
			idx = i
			break
		end
	end
	table_remove(arr, idx)
	return arr
end
