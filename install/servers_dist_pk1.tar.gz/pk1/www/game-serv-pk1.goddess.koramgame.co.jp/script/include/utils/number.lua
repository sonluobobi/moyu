--
--------------------------------------------------------------------------------
-- 数值类辅助工具
--
--------------------------------------------------------------------------------
local ceil = math.ceil
local floor = math.floor
local random = math.random

UNumber = UNumber or {}

-- 将字符串变成数字
-- str : 字符串
function UNumber.str2Int(str)
	return assert(tonumber(str), str)
end

-- 是否是大于0的数值型
-- val : 要检查的数值
function UNumber.isBiggerZero(val)
	if "number" == type(val) and 0 < val then
		return true
	end
  

	return false
end

--- 判断是否是 number
--
function UNumber.isNumber( ... )
   for i,k in ipairs(arg) do if type(k) ~= "number" then return false end end
   return true
end

-- 判断是否是正整数
function UNumber.isPositiveNumber(n)
	return type(n) == 'number' and n > 0 
end

-- 判断是否是正整数
function UNumber.isPositiveNumberArr(...)
	for i=1, arg.n do
		local v = arg[i]
		if type(v) ~= 'number' or v <= 0 then return false end
	end
	return true
end


--- 获取正整数, 返回 number/nil
function UNumber.toPositiveNumber( n )
	return type(n)=='number' and n>0 and n or nil
end

--- 判断数字是否在范围 [min, max] 内
function UNumber.isNumberInRange(n, min, max)
	return type(n)=='number' and n>=min and n<=max
end

-- add by jiang
-- 根据一组比率值，随机抽取其中一个概率的索引
function UNumber.getRandomIdx(arr_rate, proba_radix_total)
	if proba_radix_total == nil then
		proba_radix_total = 100
	end

	local rand_num = random(1, proba_radix_total)

	local current_num = 0
	local selected_idx = false

	for i = 1, #arr_rate, 1 do
		if arr_rate[i] > 0 then
			local radix = arr_rate[i]
			if rand_num > current_num and rand_num <= current_num + radix then
				selected_idx = i
				break
			end

			current_num = current_num + radix
		end
	end

	return selected_idx;
end


--- 获取随机坐标
-- @param rect = {l, t, r, b}
function UNumber.getRandomPosByRect( rect )
	local l, t, r, b = rect[1], rect[2], rect[3], rect[4]
	local x = math.random( l, r )
	local y = math.random( t, b )
	return x, y
end


--- 获取等极段
-- @param level_split = { {lv1, lv2}, {lv1, lv2}, ... }
-- @param level = number
-- @return levels = {lv1, lv2}/nil
function UNumber.getLevels( level_split, level )
	for _, range in pairs( level_split ) do
		local a, b = range[1], range[2]
		assert( a and b and a > 0 and b > 0 )
		if level >= a and level <= b then return range end
	end
end

-- 取小数点后x位,最后一位四舍五入
-- @param base-基数
-- @param num-小数点后多少位
function UNumber.getAfterPoin(base, num)
	if not UNumber.isNumber(base) or not UNumber.isNumber(num) then
		return
	end
	num = 10^num
	base = base * num
	base = UNumber.round(base)
	base = base / num
	return base
end
