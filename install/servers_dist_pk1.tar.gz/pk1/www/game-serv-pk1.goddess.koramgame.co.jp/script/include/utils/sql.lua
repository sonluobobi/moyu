--[[
sql的辅助工具
author : suwin zhong
date : 2012-02-21
$Id: $
--]]
local table_insert = table.insert
local table_concat = table.concat
local string_format = string.format

USql = USql or {}


