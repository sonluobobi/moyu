--
--------------------------------------------------------------------------------
-- 字符串辅助工具
--
--------------------------------------------------------------------------------
local random = math.random
local floor = math.floor
local modf = math.modf
local strLen = string.len
local strFind = string.find
local strSub = string.sub
local debug = debug
local next = next
local tableInsert = table.insert
local external = external
local table_insert = table.insert
local table_sort = table.sort
local table_concat = table.concat
local ceil = math.ceil
local string_format = string.format
local gmatch = string.gmatch
local string_find = string.find
local string_sub = string.sub

UString = UString or {}


function UString.split(fullString, separator, valueToInt)

	local p
	if valueToInt then p = string_format ("(%s+)%s*","%d",separator) else p = string_format("(%s+)%s*","%a",separator) end
	return gmatch(fullString,p)
end

-- 分割字符串
-- fullSting : 	string	要分割的字符串
-- separator : 	string	分割符
-- valueToInt : boolean	是否将结果值变成数值(默认不变成整型)
-- splitArray=nil:table	分解后的结果存储的数组
-- is_value2key:boolean	是否将拆分出来的value当作数组的KEY
function UString.splitString(fullString, separator, valueToInt, splitArray, is_value2key)
	if valueToInt then
		valueToInt = true
	else
		valueToInt = false
	end

	local splitArray = splitArray or {}

	if not fullString or not separator then -- 不存在需要分割的/分割号不存在
		return splitArray
	end

	local fullLength = strLen(fullString) -- 字串长度
	if fullLength == 0 then
		return splitArray
	end

	local separatorLength = strLen(separator) -- 分隔符长度
	if separator == '.' then separator = '%.' end
	local startIndex = 1
	local splitIndex = 1
	while true do
		local lastIndex = strFind(fullString, separator, startIndex)
		if not lastIndex then
			if valueToInt then
				local value = strSub(fullString, startIndex, fullLength) + 0
				if is_value2key then splitArray[value] = 1
				else splitArray[splitIndex] = value end
			else
				local value = strSub(fullString, startIndex, fullLength)
				if is_value2key then splitArray[value] = 1
				else splitArray[splitIndex] = value end
			end
			break
		end
		if valueToInt then
			local value = strSub(fullString, startIndex, lastIndex - 1) + 0
			if is_value2key then splitArray[value] = 1
			else splitArray[splitIndex] = value end
		else
			local value = strSub(fullString, startIndex, lastIndex - 1)
			if is_value2key then splitArray[value] = 1
			else splitArray[splitIndex] = value end
		end
		startIndex = lastIndex + separatorLength
		splitIndex = splitIndex + 1
	end
	return splitArray
end

--- 拆分函数名
--			. 把 x.foo 拆分为 x . foo 3部分
--			. 把 x:foo 拆分为 x : foo 3部分
--			. 把 foo 拆分为 foo 1部分
-- @return a, b, c
function UString.splitMethodName( method_name )
	local idx = string_find(method_name, '.', 1, true) or
		string_find(method_name, ':', 1, true)
	if idx then
		return string_sub(method_name, 1, idx-1 ), string_sub(method_name, idx, idx), string_sub(method_name, idx+1 )
	else
		return method_name
	end
end

--- 调用by函数名
function UString.invokeByMethodName( method_name, p1, p2, p3)
	local a, b, c = UString.splitMethodName( method_name )
	UString.invokeByMethodNameArr(a, b, c, p1, p2, p3)
end
function UString.invokeByMethodNameArr( a, b, c, p1, p2, p3 )
	local x = assert(_G[a], 'Can not find _G[' .. a .. ']' )
	if not b then
		x(p1, p2, p3)
	else
		local fn = assert( x[c], 'Can not find ' .. a .. '.' .. c )
		if b == '.' then
			fn(p1, p2, p3)
		elseif b == ':' then
			fn(x, p1, p2, p3)
		else
			assert( false, 'method_name error!' )
		end
	end
end

-- 合并字符串
-- inputTable : 要合并的字符串
-- separator : 分割符
function UString.implodeString(inputTable, separator)
	if (type(separator) ~= "string") then
		return nil
	end
	return table_concat(inputTable, separator);
end

-- added by xuebin.ke
-- inputTable : 要合并的字符串(仅仅支持以下标为1开始的数组,值为简单数字或者字符串)
--				注意要保证inputTable里面不可以有nil元素
-- separator : 分割符
function UString.implodeString2(inputTable, separator)
	if (type(separator) ~= "string") then
		return nil
	end
	if type(inputTable) == "table" then
		return table_concat(inputTable, separator);
	end
end

function UString.splitTowStr2Map(str_key, str_value, separator, value2int, ret_tbl)
	local keys, values = str_key, str_value
	local key2value, arr_key_cnt, arr_value_cnt

	if keys and keys ~= '' and values and values ~= '' then
		--Logger:debug('dddddddddaaaaaa', keys, values)
		local arr_key = type(keys) == 'number' and keys or UString.splitString(keys, separator, value2int, {})
		local arr_value = type(values) == 'number' and values or UString.splitString(values, separator, value2int, {})
		key2value = ret_tbl or {}
		for i = 1, #arr_key do
			local key, value = arr_key[i], arr_value[i]
			key2value[key] = value
		end
		
		arr_key_cnt = #arr_key
		arr_value_cnt = #arr_value
	end

	return key2value, arr_key_cnt, arr_value_cnt
end



local chr = string.byte
local pack = pack
local function isUTF8String(bytes,len)
	local i=1
	while i <= len
	do
		local nextBytes = 0;
		local byte = bytes[i];
		if (byte <= 127) then
			-- ascii不用检查
		else
			if(byte < 192) then
				return 1;	   -- 这个区间不存在
			elseif(byte <= 223) then
				nextBytes = 1; -- 1个跟随字节
			elseif(byte <= 239) then
				nextBytes = 2; -- 2个跟随字节
			elseif(byte <= 247) then
				do return 3; end
				nextBytes = 3; -- 3个跟随字节， mysql不支持，报错
			elseif(byte <= 251) then
				do return 4; end
				nextBytes = 4; --
			elseif(byte <= 253) then
				do return 5; end
				nextBytes = 5; --
			else
				return 6;      --
			end

			--跟随字节不足
			if (i+nextBytes > len) then
				return 7;
			end
			--检查跟随字节
			for n=1 , nextBytes	do
				byte = bytes[i+n];
				if(byte < 128 or byte > 191) then
					return 8;
				end
			end
			--跳过跟随字节
			i = i + nextBytes;
		end
		i = i + 1
	end
	return 0
end

do
	local floor = math.floor
	local Ach = chr('A')
	local Zch = chr('Z')
	local ach = chr('a')
	local zch = chr('z')
	local _0ch = chr('0')
	local _9ch = chr('9')
	
	local function isUtf8(bytes,len,check_nick)
		local ch_count = 0
		local i=1
		while i <= len
		do
			local nextBytes = 0;
			local byte = bytes[i];
			if (byte <= 127) then
				-- 1个位宽
				ch_count = ch_count + 1
				-- ascii
				if check_nick then
					--[AZaZ]
					if not((byte >= _0ch and byte <= _9ch) or (byte >= Ach and byte <= Zch) or (byte >= ach and byte <= zch)) then 
						return 101 
					end
				end				
			else
				-- 1。5个位宽
				ch_count = ch_count + 1.6
				if(byte < 192) then
					return 1;	   -- 这个区间不存在
				elseif(byte <= 223) then
					nextBytes = 1; -- 1个跟随字节
				elseif(byte <= 239) then
					nextBytes = 2; -- 2个跟随字节
				elseif(byte <= 247) then
					do return 3; end
					nextBytes = 3; -- 3个跟随字节， mysql不支持，报错
				elseif(byte <= 251) then
					do return 4; end
					nextBytes = 4; --
				elseif(byte <= 253) then
					do return 5; end
					nextBytes = 5; --
				else
					return 6;      --
				end

				--跟随字节不足
				if (i+nextBytes > len) then
					return 7;
				end
				--检查跟随字节
				for n=1 , nextBytes	do
					byte = bytes[i+n];
					if(byte < 128 or byte > 191) then
						return 8;
					end
				end
				--跳过跟随字节
				i = i + nextBytes;
			end
			i = i + 1
		end
		return 0, floor(ch_count)
	end

	function UString.isUtf8(str,check_nick)
		local len = strLen(str)
		local bytes = {chr(str,1,len)}
		local isAllChar = UString.__isAllChar(bytes)
		local ret, ch_count = isUtf8(bytes,len,check_nick)
		if ret ~= 0 then
			if 101 ~= ret then
				local msg = table.concat(bytes,",")
				msg = "Utils.isUtf8 is false, ret=" .. ret  .. ", bytes => " .. msg
				Logger:error( msg)
			end
			return false,0,isAllChar
		end
		return true,ch_count,isAllChar
	end
	
	function UString.__isAllChar(bytes)	  
	   for k,v in pairs(bytes) do
	       local byte = v
           if (byte > 127) then return false end
	   end
	   return true
	end
	
	function UString.isAllChar(str)  
	   local len = strLen(str)
	   local bytes = {chr(str,1,len)}  
       for k,v in pairs(bytes) do
           local byte = v
           if (byte > 127) then return false end
       end
       return true
    end
    
    function UString.utf8CharacterNum(inputstr)
        -- 计算字符串宽度
        -- 可以计算出字符宽度，用于显示使用
        local lenInByte = #inputstr
        local width = 0
        local i = 1
        while (i<=lenInByte) 
        do
             local curByte = string.byte(inputstr, i)
             local byteCount = 1;
             if curByte>0 and curByte<=127 then
                 byteCount = 1                                               --1字节字符
             elseif curByte>=192 and curByte<223 then
                 byteCount = 2                                               --双字节字符
             elseif curByte>=224 and curByte<239 then
                 byteCount = 3                                               --汉字
             elseif curByte>=240 and curByte<=247 then
                 byteCount = 4                                               --4字节字符
             end
              
             local char = string.sub(inputstr, i, i+byteCount-1)
    
             i = i + byteCount     -- 重置下一字节的索引
             width = width + 1     -- 字符的个数（长度）
        end
        return width
    end
    
	
end

