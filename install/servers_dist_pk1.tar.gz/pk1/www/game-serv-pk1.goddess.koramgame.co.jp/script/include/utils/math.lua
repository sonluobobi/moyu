-- 
--------------------------------------------------------------------------------
-- 
--
-- author: hproof
-- created: 2012/5/1 17:54:10
--
--------------------------------------------------------------------------------
--

math = math or {}
local math = math

local random = math.random
local table_remove = table.remove
local floor = math.floor
local math_ceil = math.ceil
--- 随机一个索引
-- @param arr			number 数组, 其中每个元素表示抽中该元素的概率
-- @return				返回随机抽中的索引号
function math.randomIndex(arr)
	local sum, n = 0, #arr
	for i=1,n do sum = sum + arr[i] end
	local idx = random(1, sum * 101 )
	idx = math_ceil(idx/101)
	sum = 0
	for i=1,n do
		sum = sum + arr[i]
		if sum >= idx then return i end
	end
	assert(false)
end

--- 随机一个索引(兼容哈希类型)
-- @param arr			number 数组, 其中每个元素表示抽中该元素的概率
-- @return				返回随机抽中的索引号
function math.randomIndex2(arr)
	local sum = 0
	for _,value in pairs(arr) do
		sum = sum + value
	end
	local idx = random(1, sum )
	sum = 0
	for i,value in pairs(arr) do
		sum = sum + value
		if sum >= idx then return i end
	end
	assert(false)
end

--- 随机n个整数
-- @return table, table[i]=true 表示i有效
function math.randomN(min, max, n, ret)
	assert( (max - min + 1) >= n )
	local ret = ret or {}
	if max - min == n - 1 then
		for i = min, max do ret[i] = true end
		return ret
	end
	local c = 0
	while c < n do
		local i = random(min, max)
		if not ret[i] then
			ret[i] = true
			c = c + 1
		end
	end
	return ret
end

--- 随机一个整数
-- @param arr = { min, max }
function math.randomArrayRange( arr )
	local min, max = arr[1], arr[2]
	return random(min, max)
end

--- 数组求和
-- @param arr			number 数组
function math.sum(arr)
	local n = 0
	for i=1,#arr do n = n + arr[i] end
	return n
end

--- 限制在一个范围内
function math.limit(value, min, max)
	return value < min and min or value > max and max or value
end


--- 四舍五入
function math.round( value )
	return floor( value + 0.5 )
end

function math.randOneElement(arr_element, proba_radix_total_in)
	assert(arr_element)
	assert(arr_element[1])
	if not proba_radix_total_in and #arr_element == 1 then
		return arr_element[1][1], arr_element[1], 1
	end
	if proba_radix_total_in and arr_element[1][2] >= proba_radix_total_in then
		return arr_element[1][1], arr_element[1], 1
	end
	
	local arr_rate = {}
	local proba_radix_total = proba_radix_total_in or 0
	
	for i, element in ipairs(arr_element) do
		arr_rate[i] = element[2]
		if not proba_radix_total_in then proba_radix_total = proba_radix_total + element[2] end
	end
	
	local selected_idx = math.getRandomIdxForRadix(arr_rate, proba_radix_total)
	if not selected_idx then return end
	
	local element = arr_element[selected_idx]
	return element[1], element, selected_idx
end

function math.getRandomIdxForRadix(arr_rate, proba_radix_total)
	local proba_radix_total = proba_radix_total
	if not proba_radix_total then
		proba_radix_total = 0
		for idx, rate in ipairs(arr_rate) do
			proba_radix_total = proba_radix_total + rate
		end
	end
	
	local rand_num = random(1, proba_radix_total)
	local current_num = 0
	local selected_idx = nil
	
	for idx, rate in ipairs(arr_rate) do
		if rand_num > current_num and rand_num <= current_num + rate then
			selected_idx = idx
			break
		end
		
		current_num = current_num + rate
	end
	
	return selected_idx
end

--[[
	随机奖励
	reward_equips_random 奖励配置格式：
	{
		{{equip_id,equip_num,proba}, {equip_id,equip_num,proba}},
		...
	}
	
	proba_radix_total	概率基数， 如果不传则将是概率之和做为基数
--]]
function math.randRewardEquips(reward_equips_random, proba_radix_total)
	local reward_equips = {}
	
	for _, item in ipairs(reward_equips_random) do
		local arr_rate = {}
		for idx, e in ipairs(item) do
			arr_rate[idx] = e[3]
		end
		local rand_idx = math.getRandomIdxForRadix(arr_rate, proba_radix_total)
		if rand_idx then
			local rand_e = item[rand_idx]
			local equip_id, equip_num = rand_e[1], rand_e[2]
			reward_equips[equip_id] = (reward_equips[equip_id] or 0) + equip_num
		end
	end
	
	return reward_equips
end

-- 打乱数组
function math.randArray(arr,arr_len,rand_cnt)
	local default = arr_len/2
	if not rand_cnt or rand_cnt > default then
		rand_cnt = default
	end
	
	for i=1,rand_cnt do
		local r = random(1,arr_len)
		if r ~= i then
			arr[r] , arr[i] = arr[i], arr[r]
		end
	end
end	

-- 从数组中随机抽出几个元素
function math.randExtract(arr, extract_num, ret_arr)
	local ret_arr = ret_arr or {}
	local arr_copyed = {}
	for k,v in ipairs(arr) do arr_copyed[k] = v end
	local arr_size = #arr_copyed
	
	for i = 1, arr_size < extract_num and arr_size or extract_num do
		local idx = random(1, #arr_copyed)
		ret_arr[i] = arr_copyed[idx]
		table_remove(arr_copyed, idx)
	end
	
	return ret_arr
end

-- 在一个圆或者圆环中随机一个位置(性能不佳，不要用在调用很多的地方)
-- @center_x	中心区x
-- @center_y 	中心区y
-- @size_in 	内环的半径（如果是圆，则填1或者0）
-- @size_out 	外环的半径
function math.randPosOnCircle( center_x, center_y, size_in, size_out )
	local jiaodu = math.rad(math.random(1, 360))	-- 随机角度

	 -- 随机半径（取半径的平方，随机后再取平方根, 使得怪物不会集中在中心区域）
	local radius = (math.random(size_in * size_in, size_out * size_out))^(0.5)
	local x_pos = center_x + radius * math.cos(jiaodu)
	local y_pos = center_y + radius * math.sin(jiaodu)
	return x_pos, y_pos	
end