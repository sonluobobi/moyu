--[[
通用工具类
author : xingzeng.jiang
date : 2014-07-14
$Id: $
--]]

-- 重新赋值 线程安全的 os.data
-- 注:lua原生库是非线程安全的
os.date = external and external.os_date

-- 注册表（用于检测playe 、aoi 对象在注册表的引用 条数）
_R = debug.getregistry()

-- 格式化 断言
local assert = assert
local stringFormat = string.format
function assertf(bool,f,...)
	local msg = ''
	if f then
		msg = stringFormat(f,...)
	end
	return assert(bool,msg)
end

-- 洒种子
math.randomseed(tostring(os.time()):reverse():sub(1,9))
math.random(1,100)
math.random(1,100)

local implode = table.concat
local pairs = pairs
local type = type
local external = external
local mergeUInt = external.mergeUInt
local stringSub = string.sub
local stringLen = string.len
local floor = math.floor
local tonumber = tonumber
local chr = string.byte
local tableConcat = table.concat
local stringFormat= string.format
local tableInsert = table.insert
local osTime = os.time
local osDate = os.date
local random = math.random
local externalSplitUInt = external.splitUInt
local externalMergeUInt = external.mergeUInt
local externalGetAid = external.getAid

-- 角色对象 aoi对象 垃圾回收管理
-- 采用弱表
do	
	g_character_garbage_list = g_character_garbage_list or {}
	setmetatable(g_character_garbage_list,{__mode = 'v'})
	
	g_laoi_garbage_list = g_laoi_garbage_list or {}
	setmetatable(g_laoi_garbage_list,{__mode = 'v'})

	local laoi_garbage_list = g_laoi_garbage_list	
	local character_garbage_list = g_character_garbage_list
	
	local insert = table.insert
	local pairs = pairs
	local collectgarbage = collectgarbage
	
	function push_character_garbage(v)	
		do return end		
		insert(character_garbage_list,v)
	end

	function push_laoi_garbage(v)	
		do return end		
		insert(laoi_garbage_list,v)
	end
	
	local SERVER_NAME = SERVER_NAME .. ' ' .. (g_mapserver_id or '')
	function count_garbage(time_now)		
		do return end		
		collectgarbage('collect')		
		local n,m = 0,0
		for i, v in pairs(character_garbage_list) do
			n = n + 1
		end
		
		for i, v in pairs(laoi_garbage_list) do
			m = m + 1
		end		
		Logger:error(time_now,SERVER_NAME,'lua mem(MB) = ',collectgarbage('count')/1024,n,m)		
		return n,m
	end
end

-- 捕捉异常函数 try
do
	local traceback = debug.traceback
	local function proxy(catch_func,status,a,...)
		if status == false then
			if catch_func then
				catch_func(a)
			else
				Logger:error('default catch_func:',a)
				Logger:error(traceback())
			end
			return nil
		else
			return a,...
		end
	end
	local pcall = pcall
	function try(catch_func,do_func,...)
		return proxy(catch_func,pcall(do_func,...))
	end
end

-- 工具类
Utils = Utils or {}
local Utils = Utils

do
	local format = string.format
	local md5 = external.md5
	function Utils.gen_md5Key(pkey,character)
		return md5( format('$*&//%d\\@#~%d^%%',pkey,character.id) )	
	end
end

do
	local pcall = pcall
	local traceback = debug.traceback
	function Utils.pcall(do_func, ...)
		local ok, err = pcall(do_func, ...)
		if not ok then
			Logger:error('[Utils.pcall]', err)
		end
	end
end

-- 判断指定时间是否已过期 (用于凌晨停服时刻过期情况)
-- last_do_time 	最后一次更新的时间
function Utils.isTimeDue(last_do_time)
	if last_do_time == nil or last_do_time <= 0 then
		return true
	end

	local cur_hour = tonumber(osdate('%H'))
	local critical_time

	if cur_hour < Config.SERVER_STOP_TIME_END then
		critical_time = tonumber(string.format('%s%02d%s', osdate('%Y%m%d', ostime() - 3600 * 24),
						Config.SERVER_STOP_TIME_END, '0000'))
	else
		critical_time = tonumber(string.format('%s%02d%s', osdate('%Y%m%d'),
						Config.SERVER_STOP_TIME_END, '0000'))
	end

	last_do_time = tonumber(osdate('%Y%m%d%H%M%S', tonumber(last_do_time)))

	local is_due = last_do_time < critical_time and true or false

	return is_due
end

-- 获取能返回客户端的packet_id
function Utils.getClientPacketId(packet_id)
	return Utils.isFromCommand(packet_id) and 0 or packet_id
end

-- 检查是否COMMAND端口进来的
function Utils.isFromCommand(packet_id)
	local packet_id = packet_id or g_packet_id
	return (packet_id and packet_id <= 1000 and packet_id > 0) and true or false
end

-- 检查是否在停服时间段内
function Utils.isStopServTime()
	local h = os.date("%H", os.time())
	h = tonumber(h)
	if h >= Config.SERVER_STOP_TIME_START and h <= Config.SERVER_STOP_TIME_END then
		return true
	end
	
	return false
end

-- 获取服务器名字 (目前仅支持官服)
function Utils.getServName(area_id)
	local is_tw = Language:isTW()
	local serv_id
	if is_tw then
		serv_id = area_id - 532000
	else
		serv_id = area_id - 155000
	end
	local serv_name = string.format('S%d', serv_id)
	return serv_name
end

-- 获取已开服的天数
function Utils.getServOpenDays()
	assert(Config.SERVER_OPEN_DATE_INT)
	
	local year = math.floor(Config.SERVER_OPEN_DATE_INT/10000)
	local month = math.floor((Config.SERVER_OPEN_DATE_INT%10000) / 100)
	local day = math.floor((Config.SERVER_OPEN_DATE_INT%100))
	
	local serv_open_datetime = 
	 string.format('%04d-%02d-%02d 00:00:01',year,month,day)
	 
	local serv_open_time = Utils.str2Time(serv_open_datetime)
	local serv_open_days = math.ceil((ostime() - serv_open_time)/86400)
	
	return serv_open_days
end

-- 回调CTRL层接口句柄列表
g_ctrl_callback_handles = g_ctrl_callback_handles or {}
local g_ctrl_callback_handles = g_ctrl_callback_handles

-- 注册回调接口
function Utils.regCtrlCallbackHandle(ctrl_name, func_name)
	local ctrl_obj = assert(_G[ctrl_name])
	local k1 = ctrl_name .. '.' .. func_name
	local k2 = ctrl_name .. ':' .. func_name
	g_ctrl_callback_handles[k1] = assert(ctrl_obj[func_name])
	g_ctrl_callback_handles[k2] = {ctrl_obj, assert(ctrl_obj[func_name])}
end

-- 回调CTRL层接口, 最多支持7个参数
function Utils.callbackCtrl(name, p1, p2, p3, p4, p5, p6, p7, p8)
	local handle = assert(g_ctrl_callback_handles[name], name)
	if type(handle) == 'table' then
		local ctrl_obj = handle[1]
		handle = handle[2]
		handle(ctrl_obj, p1, p2, p3, p4, p5, p6, p7, p8)
	else
		handle(p1, p2, p3, p4, p5, p6, p7, p8)
	end
end

-- 生成DB使用的Entity对象
function Utils.genDBEntity(entity_cls, db_no_use_fields)
	local db_entity_cls = {}
	local arr_db_field   = {}
	
	for field, value in pairs(entity_cls) do
		if not array.in_array(field, db_no_use_fields) then
			db_entity_cls[field] = value
			arr_db_field[#arr_db_field+1] = field
		end
	end
	
	return db_entity_cls,arr_db_field
end

-- 生成场景机器人的GCID
-- 机器人cid 在pkbaseserver的生成的
function Utils.genSceneRobotGCid(robot_cid)
	return mergeUInt(external.getAid(), robot_cid)
end

-- 生成场景机器人的GPID
function Utils.genSceneRobotGPid(robot)
	-- 机器人没有GPID
	return nil
end

-- 格式化路径
function Utils.formatPath(path_pos_arr)
	local path_log = ''
	for _, pos_t in pairs(path_pos_arr) do path_log = path_log .. ', ' .. stringFormat('%.3f', pos_t) end
	return path_log
end

-- 取pk/vchat/center服的跨服配置GAMESERVERS_CACHES
function Utils.getGameServersConfig()
    if Config then
        return Utils.__realGetGameServersConfig("PKServers")
    else
        Logger:error("config无数据，有误")    
        return {} 
    end    
end

function Utils.setGameServersConfigNotValid()
   return Utils.__realSetGameServersConfigValid("PKServers",false) 
end
function Utils.__realSetGameServersConfigValid(Key,isTrue)
    if Config and Config.GAMESERVERS_CACHE_VALID then
        Config.GAMESERVERS_CACHE_VALID[Key] = isTrue
        --table.dump("Config",Config,-1)
        return true
    else   
        --table.dump("Config",Config,-1) 
        return false
    end
end

function Utils.__realGetGameServersConfig(Key)
    if Config.GAMESERVERS_CACHES[Key] and  Config.GAMESERVERS_CACHE_VALID[Key] then
        return Config.GAMESERVERS_CACHES[Key]        
    else
        local ret = external.getConfigEncodedLuaTable(Key)
        local dcret= WorldPacket:decodeData(ret)
        Config.GAMESERVERS_CACHES[Key] = dcret
        Config.GAMESERVERS_CACHE_VALID[Key] = true
        return dcret
    end    
end


-- 生成消费元宝成功TOKEN
-- character	角色对象
-- mtime		当前时间戳(毫秒) (可为空)
function Utils.genConsumeGoldToken(character, mtime)
	local mtime = mtime or external.getUnixMsTime()
	local key = '34(@#Q&$09kalshf|d)'
	local token = external.md5(stringFormat('%d%d%%d%s', character.gpid, character.gcid, mtime, key)) .. mtime
	return token
end

-- 校验消费元宝成功TOKEN
function Utils.checkConsumeGoldToken(character, token)
	local token_len = stringLen(token)
	local mtime = stringSub(token, token_len - 13 + 1)
	local token_new = Utils.genConsumeGoldToken(character, mtime)
	return token == token_new
end

-- 生成google礼包码兑换道具TOKEN
function Utils.genGoogleGiftToken(character, sign_data)
	local key = Statics.GOOGLE_GIFT_CODE_KEY
	local token = external.md5(stringFormat('%d_%s_%s_%s', character.player_id, character.unique_key, key, sign_data))
	return string.upper(token)
end

-- 校验生成google礼包码兑换道具TOKEN
function Utils.checkGoogleGiftToken(character, sign_data, token)
	local token_new = Utils.genGoogleGiftToken(character, sign_data)
	return token == token_new
end

-- 获取阵营ID
-- id		aoi_id/team_id等 用来生成阵营ID
--			注：必须大于0
-- namespace 0:正数命名空间(zhenying=id+100)  1:负数命名空间(zhenying=id * -1)
do
	local DEFAULT_ZHENYING_MAX
	function Utils.getZhenYingId(id, namespace)
		if not DEFAULT_ZHENYING_MAX then DEFAULT_ZHENYING_MAX = Statics.DEFAULT_ZHENYING_MAX end
		local zhenying
		if namespace == 1 and id > 0 then
			zhenying = -1 * id
		else
			zhenying = id > 0 and id + DEFAULT_ZHENYING_MAX or id
		end
		return zhenying
	end
end


do
	local chars = {}
	for i=1,8 do	
		chars[i] = tostring(i)	
	end
	for i=string.byte('A'), string.byte('Z') do
		if i ~= string.byte('O') then
			chars[ #chars + 1 ] = string.char(i)
		end
	end	
	local tableconcat = table.concat
	
	function Utils.base_convert(num, base)
		local i = 0
		local chs = {}	
		while i <= 20 do
			local x = num % base
			local ch = '9'
			if x > 0 then ch = chars[x] end	
			i = i + 1
			chs[i] = ch		
			num = (num - x) /base		
			if num == 0 then break end	
		end
		return tableconcat(chs,'',1,i)
	end	
end

do
	function Utils.genInviteCode(aid, cid)		
		local aid = aid % 1000 + random(30,800)*1000
		local num = externalMergeUInt(aid,cid)
		return 	Utils.base_convert(num,34)	
	end
	--if SERVER_NAME == 'baseserver' then
	--	for i=1,20 do
	--		print(Utils.gcid2invitecode(8693018102074037))
	--	end
	--end
end


-- 充值的GCID转换成路由有的GCID
--只用于dbserver
--baseserver 必须用AreaCombineService:getRouteGcid(gcid) 
function Utils.voucherGcid2RouteGcid(vgcid)
	local _, cid = externalSplitUInt(vgcid)
	return externalMergeUInt(externalGetAid(), cid)
end


local str_find=string.find
local str_len=string.len
local str_sub=string.sub

-- 字符串转vouch_aid cid
function Utils.getBornAidCidByUKey(unique_key)
	local posBegin,posEnd=str_find(unique_key,'_')
	if not posBegin then
	   return 
	end
	if posBegin<0 then
	   return 
	end
	local born_vouch_aid=tonumber(str_sub(unique_key,0,posBegin-1))
	local born_cid=tonumber(str_sub(unique_key,posEnd+1,str_len(unique_key)))
	
	return born_vouch_aid,born_cid
end

--[[ 获取超时回调触发器 (超时后会回调传入接口)
-- callback_func_name	回调函数名(eg:GangService:onSave2Db)
-- timeout_sec			超时时间 单位:秒
-- is_no_save_data		是否需要保存数据(缺省:需要)
-- return :function	触发器
		返回的触发器函数参数
		-- gcid 64位角色ID 可为空
		-- params 参数 会传入给回调函数
-- 例子
do
	local timeout_trigger = Utils.getTimeoutCallbackTrigger('AService:onSave2Db', 30)
	function AService:save2Db(data)
		timeout_trigger(nil, data)
	end
	function AService:onSave2Db(_, arr_data)		-- arr_data 是data的集合
		ServerCall:b2dCall('ACtrl:save2Db', 0, arr_data)
	end
end
do
	function CharacterService:onUpdateAttrib(character)
		local timeout_trigger = character.tmps.on_up_attrib_timeout_trigger
		if not timeout_trigger then
			timeout_trigger = Utils.getTimeoutCallbackTrigger('CharacterService:onTimeoutUpdateAttrib', 30, true)
			character.tmps.on_up_attrib_timeout_trigger = timeout_trigger
		end
		timeout_trigger(character.gcid)
	end
	function CharacterService:onTimeoutUpdateAttrib(character)
		GangService:onChUpAttrib(character)
		...
	end
end
--]]
do
	Utils.need_save_queues = {}
	Utils.need_save_queue_len = 0
	local empty_params = {}
	
	function Utils.getTimeoutCallbackTrigger(callback_func_name, timeout_sec, is_no_save_data)
		local last_ch_attrib_uptime = 0
		local call_timer_mtime = 0
		local Time = Time
		local CharacterService = CharacterService
		local UString = UString
		local is_no_save_data = is_no_save_data
		local timeout_msec = timeout_sec * 1000
		local params = {callback_func_name = callback_func_name, need_save_queue_idx = 0}
		local need_save_queue = {}
		
		if not is_no_save_data then
			local need_save_queue_idx = Utils.need_save_queue_len + 1
			Utils.need_save_queue_len = need_save_queue_idx
			Utils.need_save_queues[need_save_queue_idx] = need_save_queue
			params.need_save_queue_idx = need_save_queue_idx
		end
		if Utils.need_save_queue_len > 5000 then Logger:error('[TimeoutCallbackTrigger] need_save_queues_len > 5000: ', Utils.need_save_queue_len) end
		
		return function (gcid, save2db_data)
			local time_now = Time.time_now
			if save2db_data and not is_no_save_data then
				local len = #need_save_queue
				need_save_queue[len+1] = save2db_data
				if len > 1000 then Logger:error('[TimeoutCallbackTrigger] need_save_queue_len > 1000: ', len) end
			end
			
			local last_ch_attrib_uptime = tmps.last_ch_attrib_uptime or 0
			if last_ch_attrib_uptime + timeout_msec <= time_now then
				local character
				if gcid and gcid > 0 then character = CharacterService:getCharacterByGcid(gcid) end
				UString.invokeByMethodName(callback_func_name, character, need_save_queue)
				table.clearTable(need_save_queue)
			elseif call_timer_mtime + timeout_msec - 1000 < time_now then
				call_timer_mtime = time_now
				ServerCall:addTimer('Utils.onTImerTimeoutTrigger', gcid or 0, params, timeout_msec + 500, 1)
			end
			
			last_ch_attrib_uptime = time_now
		end
	end
	
	local table = table
	function Utils.onTImerTimeoutTrigger(character, params)
		local character
		local gcid = params.gcid
		if gcid and gcid > 0 then character = CharacterService:getCharacterByGcid(gcid) end
		
		local need_save_queues = Utils.need_save_queues
		local need_save_queue_idx = params.need_save_queue_idx or 0
		local need_save_queue = need_save_queue_idx > 0 and need_save_queues[need_save_queue_idx] or empty_params
		UString.invokeByMethodName(params.callback_func_name, character, need_save_queue)
		if need_save_queue_idx > 0 then
			table.clearTable(need_save_queue)
		end
	end
end
	

	
	