-- 
--------------------------------------------------------------------------------
-- 简单的任务管理器, 协程
--
--
--
--    使用方式
--
--       -- 1, 定义功能函数
--          local function run_robot_ai(obj)
--             while not dead() do
--                wait_command()
--                do_command()
--             end
--          end
--
--       -- 2, 创建任务管理器, 并添加任务
--          local t = Task:new()
--          t:add( id, run_robot_ai, obj )
--          
--       -- 3, 在 update 函数中, 定期调用 task
--          local function on_update()
--             t:step()
--          end
--
--
-- author: hproof
-- created: 2012/3/14 12:26:10
--
--------------------------------------------------------------------------------
--

Task = {}


--- 新建一个任务管理器
function Task:new()
	local o = { 
		threads = {},
	}
	setmetatable(o, self)
	self.__index = self
	return o
end


--- 任务是否都完成了
function Task:isDone()
	return not next( self.threads )
end


--- 判断是否存在任务
function Task:contains(id)
	return self.threads[id]
end


--- 添加一个任务
-- @param fn(...)    任务函数, ... 将作为参数传递给 fn
function Task:add( id, fn, ... )
	local threads = self.threads
	assert( id and not threads[id] )
	local co = coroutine.create( fn )
	local s, e = coroutine.resume( co, ... )
	if s then threads[id] = co elseif e then error(e) end
end


--- 删除一个任务
function Task:remove( id )
	self.threads[id] = nil
end


--- 执行一个循环
function Task:update()
	local olds, news = self.threads, {}
	self.threads = news
	for id,co in pairs(olds) do
		if coroutine.status(co) ~= 'dead' then
			local ok, err = coroutine.resume( co )
			if ok then news[id] = co else error(err) end
		end
	end
end

--- 循环执行所有任务直到完成
function Task:loop()
	while not self:isDone() do self:step() end
end

