-- 
--------------------------------------------------------------------------------
-- 消息响应类
--
-- 	示例:
-- 			EventHandler[ event_id ][ module_name ] = function(...) end			-- 设置消息处理函数
-- 			EventHandler:dispatchEvent( event_id , ...)											-- 派发消息
--
-- 				其中:
-- 					event_id 是 消息ID, 可以是 number/string
-- 					module_name 是模块名, 用于区别各模块并避免互相覆盖, 例如 "PetCtrl", "MonsterService" 等.
-- 					function 必须是 function/nil
--
-- 	注意:
-- 			不要在消息响应函数里面, 去修改消息映射表
--
-- author: hproof
-- created: 2012/4/23 18:29:19
--
--------------------------------------------------------------------------------
--

EventHandler = EventHandler or {
	_handlers = {},
}

--- 派发消息
function EventHandler:dispatchEvent( event_id, ... )
	local t = self._handlers[event_id]
	if t then 
		for k,v in pairs(t)  do 
--			v(...)
			local ok, err = pcall(v, ...)
			if not ok then printf("EventHandler:dispatchEvent error: " .. err) end
		end
	end
end

do 
	local m = {}
	setmetatable(EventHandler, m)

	-- 设置元方法 __index, 使得用 event_id 访问下标时总是成功
	function m:__index(k)
		local ttk = type(k)
		assert(ttk=='string' or ttk=='number', "key type error!")
		local _handlers = self._handlers
		local m1 = rawget(_handlers, k)
		if not m1 then
			m1 = {}
			rawset(_handlers, k, m1)
		end
		return m1
	end
end
