--[[
军团屠龙  defs
author: jianzhu
date: 2015-11-23
]]--


GangDragonDefs = {
	GANG_DRAGON_SCENE_ID = 60003,
	GANG_DRAGON_INTERVAL = 1*60, --战斗持续时间
	GANG_DRAGON_INIT_LEVEL = 1, --金龙初始化等级

	--添加军团屠龙时间接口列表
	GANG_DRAGON_ADD_BATTLE_TIME_FROM_GANG_BATTLE = 'gang_battle', --军团战
}

function GangDragonDefs:getExpByHarm(harm)
	local add_exp = math.floor(harm / 17000)
	local model_exp = math.floor(harm % 17000)

	if  model_exp > 9000 then 
		add_exp = add_exp + 1
	end

	return add_exp
end