OutdoorDefs = 
{
	scene_id_outdoors = {
		[20001]=1,			-- 野外1场景ID
		[20002]=1,			-- 野外2场景ID
		[20003]=1,			-- 野外3场景ID
	},

	OUTDOOR_TASK_TYPE_LINWEI = 1,	--临危任务
	OUTDOOR_TASK_TYPE_JEIBIAO = 2,	--截标
}

OutdoorGlboalDefs = 
{
	SCENE_ID_OUTDOOR_GOLBAL = 20001,	-- 跨服野外场景ID
}

function OutdoorDefs:isOutdoorScene(scene_id)
	return self.scene_id_outdoors[scene_id] and true or false
end