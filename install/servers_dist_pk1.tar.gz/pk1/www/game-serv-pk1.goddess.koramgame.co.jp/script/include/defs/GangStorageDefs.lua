--[[
功能:	军团仓库
author: guoyin.huang
date:	2015-03-10
]]


GangStorageDefs = {
	GANG_STORAGE_SIZE 	= 150,	--帮会仓库大小
	CH_STORAGE_MAX_SIXZE = 10,	--每个帮会成员最大可寄售道具数量

	GANG_STORAGE_EXP_DAYS = 3,	--有效的天数(从寄售当天零点开始计算)

	-- 奖励类型
	GANG_STORAGE_REWARD_TYPE_UNSALE = 1,	--取消寄售
	GANG_STORAGE_REWARD_TYPE_BUY 	= 2,	--购买
	GANG_STORAGE_REWARD_TYPE_OUTTIME= 3,	--寄售过期

	GANG_STORAGE_TAX = 0.5,					--税收比率

	-- 仓库日志类型
	GANG_STORAGE_LOG_SALE = 1,		--xxxxx将xxxx放入仓库
	GANG_STORAGE_LOG_UNSALE = 2,	--xxxxx将xxxx从仓库取回
	GANG_STORAGE_LOG_CLEAR = 3,		--xxxxx将xxxx从仓库返还给xxxx
	GANG_STORAGE_LOG_BUY = 4,		--xxxxx将xxxx从仓库取出
	GANG_STORAGE_LOG_TIMEOUT = 5,	--xxxx被自动返还给xxxxx

	-- 仓库日志条数
	GANG_STORAGE_LOG_NUM = 40,	

	--仓库类别分职业分类获取，每页展示数
	GANG_STORAGE_PROF_PER_SIZE = 10, 
}

if AsReadOnly then
	AsReadOnly(GangStorageDefs)
end