--[[
坐骑定义文件
author : xingzeng
date : 2014-10-11
--]]

HorseDefs = HorseDefs or {}

-- 坐骑类型
HorseDefs.HORSE_SORT_ID_NORMAL = 0			-- 普通类型
	
HorseDefs.EVOLVE_NEED_EQUIP_NUM_PER = 5		-- 每次进化需要消耗 5个进化丹

HorseDefs.EAT_NEED_EQUIP_NUM = 2			-- 一次喂养需要消耗的道具

HorseDefs.UPGRADE_BAOJI_PROBA = 10			-- 10%概率触发升级暴击

HorseDefs.SPEED_FOR_CH_COEFF = 0.001		-- 坐骑加成给玩家速度系数  玩家速度 + 0.01*坐骑速度

-- 第一匹马ID
HorseDefs.FIRST_HORSE_ID = 100001

-- 驯化类型(ID数值不能修改)
HorseDefs.HORSE_XUNHUA_SORT_ID_START = 1
HorseDefs.HORSE_XUNHUA_SORT_ID_CRITICAL_HIT = 1	--默契(暴击)
HorseDefs.HORSE_XUNHUA_SORT_ID_PARRY = 2		--平衡(格挡)
HorseDefs.HORSE_XUNHUA_SORT_ID_DODGE = 3		--灵巧(闪避)
HorseDefs.HORSE_XUNHUA_SORT_ID_END = 3

HorseDefs.HORSE_XUNHUA_LEV_MAX = 10				--驯化最高等级

-- 驯化暴击概率
HorseDefs.SPEED_XUNHUA_BAOJI_2_PROMBA = 20
HorseDefs.SPEED_XUNHUA_BAOJI_5_PROMBA = 5

--坐骑装备加速有20%概率出现2倍暴击，5%概率出现5倍暴击
HorseDefs.SPEED_UPGRADE_BAOJI_2_PROMBA = 20
HorseDefs.SPEED_UPGRADE_BAOJI_5_PROMBA = 5

--驯化一次消耗的金币数量
HorseDefs.XUNHUA_ONE_NEED_SILVER = 10000

AsReadOnly(HorseDefs)