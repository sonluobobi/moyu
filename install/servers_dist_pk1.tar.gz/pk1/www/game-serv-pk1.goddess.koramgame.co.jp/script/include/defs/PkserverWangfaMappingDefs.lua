--
--------------------------------------------------------------------------------
-- pk服映射游戏服映射玩法定义
--author : jinlin.liu
--date : 2016-08-18
--------------------------------------------------------------------------------


PkserverWangfaMappingDefs = {
	WANGFA_ZHUSHEN_FINAWAR = 1001, --诸神与末日之战
	WANGFA_BOSS_HOME = 1002 ,--boss之家
	
}

AsReadOnly(PkserverWangfaMappingDefs)
