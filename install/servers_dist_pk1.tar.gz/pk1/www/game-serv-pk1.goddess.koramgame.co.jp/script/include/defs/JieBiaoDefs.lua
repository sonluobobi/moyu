--[[
魅力活动定义
author : jinlin.liu
date : 2016-4-12
--]]

JieBiaoDefs =
{ 
  JB_TYPE_SHOU = 1,--守
  JB_TYPE_GONG = 2,--攻
  
  JB_STATUS_BEFORE_PREPARE = 0,--0表示预备前，
  JB_STATUS_PREPARE = 1,--1预备，
  JB_STATUS_BEGIN = 2,--开始，
  JB_STATUS_END = 3, --结束 
  
  JB_POS_UP = 3,--上
  JB_POS_DOWN = 1,--下
  JB_POS_LEFT = 4,--左
  JB_POS_RIGHT = 2,--右
  
  JB_DEFAULT_PREPARE_TIME=20,
  
  JB_DEFAULT_GODDESS = 5,
  
  JB_POS_INTERVAL = 4, --2秒钟一次
  JB_SMALL_MAP_POS_INTERVAL = 6, --3秒钟一次
  JB_SMALL_MAP_SHANSHOU_INTERVAL = 20, --10秒钟闪烁
  
  JB_GONG_NUM = 100,
  JB_SHOU_NUM = 100,
  
  JB_BUFFER_ID = 40000012,--这个目前是蝙蝠降速的    
  
}