
SafeModeDefs = 
{
	-- 野外安全模式
	SAFE_MODE_START = 0,
	SAFE_MODE_SPACE = 0,	-- 和平
	SAFE_MODE_PK = 1,		-- 杀戮(帮派)
	SAFE_MODE_FREE_PK = 2,	-- 自由PK，同帮会可PK
	SAFE_MODE_END = 2,
	
	SAFE_MODE_PK_COOL_SEC = 180,		--PK之后增加的冷却时间
	TMP_ENEMY_EXPIRE_SEC = 180,			--临时仇敌的过期时间
}
AsReadOnly(SafeModeDefs)