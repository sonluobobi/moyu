--[[
计数器定义
author : guoyin.huang
date : 2014-12-15
$Id: $
--]]

local tableInsert = table.insert

CounterDefs =  
{
	COUNTER_SORT_ID_DAILY = 0,				-- 每日计数器(每日计数清空)

	COUNTER_SORT_ID_WEEK = 1,				-- 周计数器(每周周一0点清空)

	COUNTER_SORT_ID_EVER = 2,				-- 永久计数器(计数不清空)


	COUNTER_SAVE_HISTORY_DAY_NUM = 3,		-- 记录领取历史的天数

	counter_bases = nil,					-- 计数器基础对象定义

	------------------------- 各计数器基础对象定义 start ----------------------
	-- MAPSERVER的计数器 (1-100)
	COUNTER_BASE_ID_BAOWU_CHIP_ROB_LX_FAIL = 1,		-- 宝物碎片抢夺连续失败计数
	COUNTER_BASE_ID_BAOWU_CHIP_ROB_RW_LX_FAIL = 2,	-- 夺宝随机奖励连续没出保底道具的次数
	COUNTER_BASE_ID_ARENA_REWARD_LX_FAIL = 4,		-- 竞技场随机奖励连续没出保底道具的次数
	COUNTER_BASE_ID_3V3 = 5,						--3V3(不使用)
	COUNTER_BASE_ID_TIANMO = 6,						--BOSS之家
	COUNTER_BASE_ID_TEAM_SUBLINE  = 7,				--组队副本
	COUNTER_BASE_ID_TEAM_SUBLINE_30  = 8,			--30组队副本
	COUNTER_BASE_ID_TEAM_SUBLINE_40  = 9,			--40组队副本
	COUNTER_BASE_ID_TEAM_SUBLINE_50  = 10,			--50组队副本
	COUNTER_BASE_ID_TEAM_SUBLINE_60  = 11,			--60组队副本
--	COUNTER_BASE_ID_MEDAL = 12,						--每天可获得奖牌数
	COUNTER_BASE_ID_TEAM_SUBLINE_70  = 13,			--70组队副本
	COUNTER_BASE_ID_TEAM_SUBLINE_80  = 14,			--80组队副本
	COUNTER_BASE_ID_TEAM_SUBLINE_90  = 15,			--90组队副本
	COUNTER_BASE_ID_TEAM_SUBLINE_100  = 16,			--100组队副本
	COUNTER_BASE_ID_FREE_PIGEON = 17,				--免费飞鸽
	COUNTER_BASE_ID_GET_EXP_MONSTER_NUM = 18,		--每日拾取怪物掉落经验的次数(类同获得X只怪物经验)	
	COUNTER_BASE_ID_LINWEI_TASK_TIMES = 19,			--每天可参加临危任务的次数
	COUNTER_BASE_ID_FETCH_VIT1 = 20,				--体力下午免费领取
	COUNTER_BASE_ID_FETCH_VIT2 = 21,				--体力晚上免费领取
	COUNTER_BASE_ID_FIRST_EGG = 22,					--第一次砸蛋
	COUNTER_BASE_ID_BUY_VIT = 23,					--购买体力药计数
	COUNTER_BASE_ID_BUY_ENDURANCE = 24,				--购买耐力药计数
	COUNTER_BASE_ID_ROB_BAOWU_CHIP = 25,			--第一次夺宝
	COUNTER_BASE_ID_ROB_BAOWU_CHIP_REF = 26,		--第一、二次夺宝刷新
	COUNTER_BASE_ID_FOR_2V2	= 27,					--每天2V2参与次数
	COUNTER_BASE_ID_GANG_BATTLE_CHUSAI = 28,		--帮战初赛
	COUNTER_BASE_ID_OUTDOOR_BOSS_RWD = 29,			--野外奖励次数
	COUNTER_BASE_ID_BABEL_RESET_TIMES = 30,			--试炼塔重置次数
	COUNTER_BASE_ID_BABEL_TIMES = 31,				--试炼塔挑战次数
	COUNTER_BASE_ID_BABEL_RESET_TIMES_GOLD = 32,	--试炼塔可通过魔石重置次数
	COUNTER_BASE_ID_VIP_GIFT = 33,					--VIP购买礼包
	COUNTER_BASE_ID_BUY_SUBLINE_TIMES = 34,			--VIP购买副本次数
	COUNTER_BASE_ID_GANG_DONATE_GOLD_PRIMARY = 35,  --军团捐献魔石初级
	COUNTER_BASE_ID_GANG_DONATE_GOLD_MIDDLE = 36,   --军团捐献魔石中级
	COUNTER_BASE_ID_GANG_DONATE_GOLD_HIGH = 37,     --军团捐献魔石高级	
	COUNTER_BASE_ID_FUN_OPEN_CALLBACK = 38,     	--功能开关回调
	COUNTER_BASE_ID_ADD_INITMACY_LEVLE2 = 39,     	--好友送花2档80亲密度
	COUNTER_BASE_ID_ADD_INITMACY_LEVLE3 = 40,     	--好友送花3档500亲密度	 
 	COUNTER_BASE_ID_JIEBIAO_SHOU = 41,       --劫镖守次数
  	COUNTER_BASE_ID_JIEBIAO_GONG = 42,       --劫镖攻次数
  	COUNTER_BASE_ID_FACEBOOK_MARK = 43,				--facebook关注奖励
  	COUNTER_BASE_ID_TEAM_SUBLINE_115  = 44,			--115组队副本
  	COUNTER_BASE_ID_TEAM_SUBLINE_125  = 45,			--125组队副本
  	COUNTER_BASE_ID_TEAM_SUBLINE_135  = 46,			--135组队副本
  	COUNTER_BASE_ID_TEAM_SUBLINE_145  = 47,			--145组队副本
  	COUNTER_BASE_ID_TEAM_SUBLINE_155  = 48,			--155组队副本
  	COUNTER_BASE_ID_TEAM_SUBLINE_165  = 49,			--165组队副本
  	COUNTER_BASE_ID_TEAM_SUBLINE_175  = 50,			--175组队副本
  	COUNTER_BASE_ID_TEAM_SUBLINE_185  = 51,			--185组队副本
  	COUNTER_BASE_ID_TEAM_SUBLINE_195  = 52,			--185组队副本
  	COUNTER_BASE_ID_OPEN_DAILY_GIFT   = 53,			--每日可开礼包
  	COUNTER_BASE_ID_GLOBAL_ARENA 	  = 54,			--跨服竞技场
  	COUNTER_BASE_ID_BABEL_TIMES_GOLD_ENTRY = 55,	--豆蔓魔石进入的次数
  	COUNTER_BASE_ID_OUTDOOR_BOSS_BAODI = 56,		--野外巨炎魔宝箱每次保底次数
	COUNTER_BASE_ID_TRADE_BUY_LIMIT  = 57,			--海外交易限制每人每天购买次数
	COUNTER_BASE_ID_TRADE_SALE_LIMIT = 58,			--海外交易限制每人每天出售的次数
	COUNTER_BASE_ID_UNDERCROFT   	= 59,			--地下城堡每天挑战次数
	COUNTER_BASE_ID_UNDERCROFT_GOLD	= 60,			--地下城堡每天魔石进入的次数
	COUNTER_BASE_ID_EMENG_LONGYA = 61,				--龙牙副本
	COUNTER_BASE_ID_EMENG_JINBI = 62,				--金币副本
	COUNTER_BASE_ID_EMENG_YINKOUSHAO = 63,			--银口哨副本
	COUNTER_BASE_ID_EMENG_HUANJING = 64,			--幻晶副本
	COUNTER_BASE_ID_EMENG_GOLD = 65,				--魔石副本
	COUNTER_BASE_ID_SHENGCUN = 66,					--生存玩法(丧尸危机)
	COUNTER_BASE_ID_LOVER_TEMPLE = 67,				--爱情圣殿参与次数
	COUNTER_BASE_ID_HOLIDAY_DROP = 68,				--主城掉落可拾取数据(配置均为1次，根据活动修改数值)
	COUNTER_BASE_ID_LOVER_TEMPLE_REWARD = 69,		--爱情圣殿奖励次数
	
	-- BASESERVER的计数器 (101-200)
	COUNTER_BASE_ID_DAOJIANJUE = 101,				--刀剑（帝国争锋)
	COUNTER_BASE_ID_GANG_CMD = 102,					--军团密令
	COUNTER_BASE_ID_HORSE_EVOLVE = 103,				--坐骑进化
	COUNTER_BASE_ID_TARGET_UPGRADE = 104,			--爵位进化广播
	COUNTER_BASE_ID_ROBED_BW_VIEW = 105,			--有未查看过被抢夺紫色宝物记录
	COUNTER_BASE_ID_VIP_GANG_REWARD = 106,			--VIP军团领奖
	COUNTER_BASE_ID_GANG_DRAGON = 107,				--军团屠龙
	COUNTER_BASE_ID_GANG_DRAGON_TEAM = 108,			--军团屠龙之军团总次数限制
	COUNTER_BASE_ID_ACT_CODE_USE = 109,				--激活码批次使用记录
	COUNTER_BASE_ID_CHARM_CHANGEVOICE = 110,     	--魅力活动修改拉票语音	
	COUNTER_BASE_ID_CHAT_BAN   = 111,     			--禁言
	COUNTER_BASE_ID_CHAT_UNBAN = 112,     			--解禁言
	COUNTER_BASE_ID_GANG_BATTLE_BAOMING = 113,		--军团战报名
	COUNTER_BASE_ID_SEND_GANG_BADGE = 114,     		--发送军团徽章

	-- 通用合服相关 (注：老的101-114 是特殊的，细节问建筑)
	-- 1-129 清掉
	-- 130-149  合并最大值
	-- 150以上是角色 按角色合并
	COUNTER_BASE_ID_HEFU_SERVER = 130,				--子计数器为其他的（比如坐骑等级等）
	COUNTER_BASE_ID_HEFU_CID = 150,					--子计数器为角色ID
	
	COUNTER_BASE_ID_SUBLINE_95_BAODI  = 150,		--95组队副本保底计数器
	COUNTER_BASE_ID_SUBLINE_105_BAODI  = 151,		--105组队副本保底计数器
	COUNTER_BASE_ID_SUBLINE_115_BAODI  = 152,		--115组队副本保底计数器
  	COUNTER_BASE_ID_SUBLINE_125_BAODI  = 153,		--125组队副本保底计数器
  	COUNTER_BASE_ID_SUBLINE_135_BAODI  = 154,		--135组队副本保底计数器
  	COUNTER_BASE_ID_SUBLINE_145_BAODI  = 155,		--145组队副本保底计数器
  	COUNTER_BASE_ID_SUBLINE_155_BAODI  = 156,		--155组队副本保底计数器
  	COUNTER_BASE_ID_SUBLINE_165_BAODI  = 157,		--165组队副本保底计数器
  	COUNTER_BASE_ID_SUBLINE_175_BAODI  = 158,		--175组队副本保底计数器
  	COUNTER_BASE_ID_SUBLINE_185_BAODI  = 159,		--185组队副本保底计数器
}	
-- CounterBase Counter 类定义见mapserver/entity/map_counter.lua

-- 需要打包到PK服的MAP计数器列表
-- 这些计数器有优化空间，将来数量非常多的时候，可以根据玩法，只带某些计数器到跨服
CounterDefs.map_need_pack_2_pk = {
	[1] = CounterDefs.COUNTER_BASE_ID_GANG_BATTLE_CHUSAI,	-- 帮战初赛
	[2] = CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_RWD,		-- 野外BOSS奖励次数
	[3] = CounterDefs.COUNTER_BASE_ID_JIEBIAO_SHOU, 		--劫镖守次数
  	[4] = CounterDefs.COUNTER_BASE_ID_JIEBIAO_GONG, 		--劫镖攻次数
  	[5] = CounterDefs.COUNTER_BASE_ID_LINWEI_TASK_TIMES,	--临危任务次数
  	[6] = CounterDefs.COUNTER_BASE_ID_GLOBAL_ARENA,			--跨服竞技场（诸神黄昏）
  	[7] = CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_BAODI,	--野外宝箱保底次数
  	[8] = CounterDefs.COUNTER_BASE_ID_SHENGCUN,				--生存挑战
  	[9] = CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE,			--爱情圣殿
  	[10] = CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE_REWARD, --爱情圣殿
}
do
	CounterDefs.map_need_pack_2_pk_hash = {}
	for _, counter_base_id in pairs(CounterDefs.map_need_pack_2_pk) do
		CounterDefs.map_need_pack_2_pk_hash[counter_base_id] = true
	end
end

-- 需要同步到客户端的BASE计数器(只能使用以角色ID为子计数器ID的计数器)
CounterDefs.base_need_send_list = {
	[1] = CounterDefs.COUNTER_BASE_ID_DAOJIANJUE,
	[2] = CounterDefs.COUNTER_BASE_ID_ROBED_BW_VIEW,
	[3] = CounterDefs.COUNTER_BASE_ID_GANG_DRAGON,
	[4] = CounterDefs.COUNTER_BASE_ID_CHARM_CHANGEVOICE,
	[5] = CounterDefs.COUNTER_BASE_ID_CHAT_BAN,
	[6] = CounterDefs.COUNTER_BASE_ID_CHAT_UNBAN,
	[7] = CounterDefs.COUNTER_BASE_ID_GANG_BATTLE_BAOMING,
	[8] = CounterDefs.COUNTER_BASE_ID_SUBLINE_95_BAODI,
	[9] = CounterDefs.COUNTER_BASE_ID_SUBLINE_105_BAODI,
	[10] = CounterDefs.COUNTER_BASE_ID_SUBLINE_115_BAODI,
	[11] = CounterDefs.COUNTER_BASE_ID_SUBLINE_125_BAODI,
	[12] = CounterDefs.COUNTER_BASE_ID_SUBLINE_135_BAODI,
	[13] = CounterDefs.COUNTER_BASE_ID_SUBLINE_145_BAODI,
	[14] = CounterDefs.COUNTER_BASE_ID_SUBLINE_155_BAODI,
	[15] = CounterDefs.COUNTER_BASE_ID_SUBLINE_165_BAODI,
	[16] = CounterDefs.COUNTER_BASE_ID_SUBLINE_175_BAODI,
	[17] = CounterDefs.COUNTER_BASE_ID_SUBLINE_185_BAODI,
	
}

-- 需要同步到客户端的MAP计数器
CounterDefs.map_need_send_list = {
	[1] = CounterDefs.COUNTER_BASE_ID_GANG_BATTLE_CHUSAI,		--帮战初赛
	[2] = CounterDefs.COUNTER_BASE_ID_TIANMO,			--BOSS之家		
	[3] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE,			--组队副本
	[4] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_30,		--30副本
	[5] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_40,		--40副本
	[6] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_50,		--50副本
	[7] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_60,		--60副本
	[8] = CounterDefs.COUNTER_BASE_ID_FOR_2V2,		--2V2可参与次数
	[9] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_70,
	[10] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_80,
	[11] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_90,
	[12] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_100,
	[13] = CounterDefs.COUNTER_BASE_ID_FREE_PIGEON,--免费飞鸽
	[14] = CounterDefs.COUNTER_BASE_ID_LINWEI_TASK_TIMES,	--每天可参加临危任务次数
	[15] = CounterDefs.COUNTER_BASE_ID_FETCH_VIT1,	--体力下午免费领取
	[16] = CounterDefs.COUNTER_BASE_ID_FETCH_VIT2,	--体力下午免费领取
	[17] = CounterDefs.COUNTER_BASE_ID_BUY_VIT,		--购买体力药计数
	[18] = CounterDefs.COUNTER_BASE_ID_BUY_ENDURANCE,	--购买耐力药计数
	[19] = CounterDefs.COUNTER_BASE_ID_BABEL_RESET_TIMES,	--试炼塔重置次数
	[20] = CounterDefs.COUNTER_BASE_ID_BABEL_TIMES,			--试炼塔挑战次数
	[21] = CounterDefs.COUNTER_BASE_ID_BABEL_RESET_TIMES_GOLD,--试炼塔可通过魔石重置次数
	[22] = CounterDefs.COUNTER_BASE_ID_BUY_SUBLINE_TIMES,	--购买副本的次数
	[23] = CounterDefs.COUNTER_BASE_ID_GANG_DONATE_GOLD_PRIMARY,--军团捐献魔石初级
	[24] = CounterDefs.COUNTER_BASE_ID_GANG_DONATE_GOLD_MIDDLE,	--军团捐献魔石中级
	[25] = CounterDefs.COUNTER_BASE_ID_GANG_DONATE_GOLD_HIGH,	--军团捐献魔石高级
	[26] = CounterDefs.COUNTER_BASE_ID_ADD_INITMACY_LEVLE2, --好友送花2档80亲密度
	[27] = CounterDefs.COUNTER_BASE_ID_ADD_INITMACY_LEVLE3, --好友送花3档500亲密度
	[28] = CounterDefs.COUNTER_BASE_ID_JIEBIAO_SHOU, --劫镖守次数
	[29] = CounterDefs.COUNTER_BASE_ID_JIEBIAO_GONG, --劫镖攻次数
	[30] = CounterDefs.COUNTER_BASE_ID_FACEBOOK_MARK,	--facebook关注领奖
	[31] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_115,
	[32] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_125,
	[33] = CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_RWD,	--野外宝箱次数
	[34] = CounterDefs.COUNTER_BASE_ID_GLOBAL_ARENA,		--跨服竞技场（诸神黄昏）
	[35] = CounterDefs.COUNTER_BASE_ID_BABEL_TIMES_GOLD_ENTRY, -- 豆蔓可魔石进入的次数
	[36] = CounterDefs.COUNTER_BASE_ID_UNDERCROFT, 		-- 地下城堡进入次数 
	[37] = CounterDefs.COUNTER_BASE_ID_UNDERCROFT_GOLD,	-- 地下城堡每天魔石进入的次数
	[38] = CounterDefs.COUNTER_BASE_ID_EMENG_LONGYA,	-- 龙牙副本
	[39] = CounterDefs.COUNTER_BASE_ID_EMENG_JINBI,		-- 金币副本
	[40] = CounterDefs.COUNTER_BASE_ID_EMENG_YINKOUSHAO,-- 银口哨副本
	[41] = CounterDefs.COUNTER_BASE_ID_EMENG_HUANJING,	-- 幻晶副本
	[42] = CounterDefs.COUNTER_BASE_ID_EMENG_GOLD,		-- 魔石副本
	[43] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_135,		-- 135组队副本
	[44] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_145,		-- 145组队副本
	[45] = CounterDefs.COUNTER_BASE_ID_SHENGCUN,		-- 生存挑战（丧尸危机）
	[46] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_155,		-- 145组队副本
	[47] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_165,		-- 165组队副本
	[48] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_175,		-- 175组队副本
	[49] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_185,		-- 185组队副本
	[50] = CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_195,		-- 195组队副本
	[51] = CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE,			-- 爱情圣殿
	[52] = CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE_REWARD,		-- 爱情圣殿奖励数量
}

-- 国内不发facebook计数器
if Language:isCN() then
	CounterDefs.map_need_send_list[30] = nil
end

do
	CounterDefs.base_need_send_hash = {}
	for k, v in pairs(CounterDefs.base_need_send_list) do
		CounterDefs.base_need_send_hash[v] = true
	end

	CounterDefs.map_need_send_hash = {}
	for k, v in pairs(CounterDefs.map_need_send_list) do
		CounterDefs.map_need_send_hash[v] = true
	end
end

-- base计数器特殊处理
-- @返回每日可用次数与总次数
function CounterDefs.baseGetDiyCount( counter_base, counter )
	local counter_baseid = counter.base_id 			--计数器ID
	local sub_counter_id = counter.subcounter_id 	--子计数器ID
	local count 			-- 每日计数
	local storeup_count		-- 累积计数

	if counter_baseid == CounterDefs.COUNTER_BASE_ID_GANG_CMD then 
		--vip 军团:3  普通:1
		local bVipGang=GangService:isVipGang(sub_counter_id)
		if bVipGang then
			count = 3
		else
			count = 1
		end
		storeup_count = count
	else
		Logger:error('计数器定义中每日次数使用自定义函数，而函数中未实现,计数器ID:' .. counter_baseid)
		assert(false)
	end
	return count, storeup_count
end

-- map计数器特殊处理
-- 假日次数双倍
function CounterDefs.holidayMultiCount( counter_base, character, timestamp )
	local multi = WanfaRewardRadixDefs:getRewardRadix(WanfaRewardRadixDefs.WANFA_SORT_ID_SUBLINE)
	if timestamp then 
		multi = 1
	end
	return counter_base.count * multi, counter_base.storeup_count * multi
end

-- 创建一个计数器基础对象
-- sort_id					计数器类型
-- count					周期内次数最大值
-- storeup_count = nil		可以积累的最大次数(按天累计)
-- has_sub_counter = nil	是否含子计数器(eg: 是:角色副本进入计数器，角色每个副本都有一个子计数器)
--											   否:竞技场每天挑战计数器 各角色只有一个竞技场每天挑战计数器
-- vip_fun_id = nil 		VIP功能ID或调用的函数
-- return table:counter_base
local function _newCounterBase(sort_id, count, storeup_count, has_sub_counter, ch_lev, vip_fun_id)
	local counter_base = {}
	assert(count > 0)

	counter_base.base_id = nil			-- 在后面会统一赋值
	counter_base.sort_id = sort_id
	counter_base.count = count
	counter_base.storeup_count = storeup_count and storeup_count or 0
	counter_base.has_sub_counter = has_sub_counter and true or false
	counter_base.ch_lev = ch_lev
	counter_base.vip_fun_id = vip_fun_id
	return counter_base
end

CounterDefs.counter_bases = {}
local counter_bases = CounterDefs.counter_bases
do
-------------------------------- MAP [BEG] -----------------------------------
-- 宝物碎片抢夺连续失败计数
counter_bases[CounterDefs.COUNTER_BASE_ID_BAOWU_CHIP_ROB_LX_FAIL] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 9999, 0, true)

-- 夺宝随机奖励连续没出保底道具的次数
counter_bases[CounterDefs.COUNTER_BASE_ID_BAOWU_CHIP_ROB_RW_LX_FAIL] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 9999999, 0)

-- 竞技场随机奖励连续没出保底道具的次数
counter_bases[CounterDefs.COUNTER_BASE_ID_ARENA_REWARD_LX_FAIL] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 9999999, 0)

-- 3V3每日次数
counter_bases[CounterDefs.COUNTER_BASE_ID_3V3] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 10, 10)

-- BOSS之家每日次数
counter_bases[CounterDefs.COUNTER_BASE_ID_TIANMO] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2)	

-- 组队副本已进入计数器
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 4, 4, nil, nil, CounterDefs.holidayMultiCount)
-- 30组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_30] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 40组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_40] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 50组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_50] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 60组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_60] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 70组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_70] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 80组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_80] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 90组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_90] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 100组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_100] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 115组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_115] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 125组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_125] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 135组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_135] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 145组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_145] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 155组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_155] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 165组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_165] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 175组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_175] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 185组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_185] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)
-- 195组队副本
counter_bases[CounterDefs.COUNTER_BASE_ID_TEAM_SUBLINE_195] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, CounterDefs.holidayMultiCount)


-- 噩梦本
-- 龙牙
counter_bases[CounterDefs.COUNTER_BASE_ID_EMENG_LONGYA] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)
-- 金币
counter_bases[CounterDefs.COUNTER_BASE_ID_EMENG_JINBI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)
-- 银口哨
counter_bases[CounterDefs.COUNTER_BASE_ID_EMENG_YINKOUSHAO] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)
-- 幻晶
counter_bases[CounterDefs.COUNTER_BASE_ID_EMENG_HUANJING] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)
-- 魔石
counter_bases[CounterDefs.COUNTER_BASE_ID_EMENG_GOLD] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)


-- 临危任务参与次数
counter_bases[CounterDefs.COUNTER_BASE_ID_LINWEI_TASK_TIMES] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 3, 3)

-- 劫镖守
counter_bases[CounterDefs.COUNTER_BASE_ID_JIEBIAO_SHOU] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 18, 18)

-- 劫镖攻
counter_bases[CounterDefs.COUNTER_BASE_ID_JIEBIAO_GONG] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 18, 18)

-- facebook关注奖励
counter_bases[CounterDefs.COUNTER_BASE_ID_FACEBOOK_MARK] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 1, 1)


-- 体力下午免费领取
counter_bases[CounterDefs.COUNTER_BASE_ID_FETCH_VIT1] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)

-- 体力下午免费领取
counter_bases[CounterDefs.COUNTER_BASE_ID_FETCH_VIT2] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)

-- 第一次砸蛋
counter_bases[CounterDefs.COUNTER_BASE_ID_FIRST_EGG] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 1, 0, true)

-- 每日拾取怪物掉落经验的次数
counter_bases[CounterDefs.COUNTER_BASE_ID_GET_EXP_MONSTER_NUM] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 400, 400)

-- 第一、二次夺宝刷新
counter_bases[CounterDefs.COUNTER_BASE_ID_ROB_BAOWU_CHIP_REF] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 50, 50)

-- 第一次夺宝
counter_bases[CounterDefs.COUNTER_BASE_ID_ROB_BAOWU_CHIP] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 50, 50)

-- 2V2
counter_bases[CounterDefs.COUNTER_BASE_ID_FOR_2V2] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2)

-- 帮战初赛
--counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_BATTLE_CHUSAI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_WEEK, 10, 10)
counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_BATTLE_CHUSAI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 3, 3)

-- 野外BOSS奖励次数
counter_bases[CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_RWD] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 12, 12)

-- 野外BOSS死亡时获得宝箱的保底次数
counter_bases[CounterDefs.COUNTER_BASE_ID_OUTDOOR_BOSS_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 3, 3)

-- 有未查看过被抢夺紫色宝物记录
counter_bases[CounterDefs.COUNTER_BASE_ID_ROBED_BW_VIEW] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 1, 99999, true)

-- 试炼塔重置次数
counter_bases[CounterDefs.COUNTER_BASE_ID_BABEL_RESET_TIMES] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)

-- VIP礼包领取(每个VIP等级每个玩家一次)
counter_bases[CounterDefs.COUNTER_BASE_ID_VIP_GIFT] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 1, 1, true)

-- 功能开关回调
counter_bases[CounterDefs.COUNTER_BASE_ID_FUN_OPEN_CALLBACK] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 1, 1, true)

-- 每日可开宝箱
counter_bases[CounterDefs.COUNTER_BASE_ID_OPEN_DAILY_GIFT] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, true)

-- 跨服竞技场（诸神黄昏）
counter_bases[CounterDefs.COUNTER_BASE_ID_GLOBAL_ARENA] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 10, 10)

-- 试炼塔挑战次数
counter_bases[CounterDefs.COUNTER_BASE_ID_BABEL_TIMES] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 4, 4)

--军团捐献魔石初级
counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_DONATE_GOLD_PRIMARY] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)
--军团捐献魔石中级
counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_DONATE_GOLD_MIDDLE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)
--军团捐献魔石高级
counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_DONATE_GOLD_HIGH] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)

--好友送花2档80亲密度
counter_bases[CounterDefs.COUNTER_BASE_ID_ADD_INITMACY_LEVLE2] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)

--好友送花3档500亲密度
counter_bases[CounterDefs.COUNTER_BASE_ID_ADD_INITMACY_LEVLE3] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1)

-- 地下城堡每日免费次数
counter_bases[CounterDefs.COUNTER_BASE_ID_UNDERCROFT] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 5, 5)

-- 丧尸危机每日次数
counter_bases[CounterDefs.COUNTER_BASE_ID_SHENGCUN] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2)

-- 爱情圣殿每日参与次数
counter_bases[CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2)

-- 爱情圣殿每日领取奖励数量
counter_bases[CounterDefs.COUNTER_BASE_ID_LOVER_TEMPLE_REWARD] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 25, 25)


-- 主城假日掉落拾取
counter_bases[CounterDefs.COUNTER_BASE_ID_HOLIDAY_DROP] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, true)

---------------------------------------------------- VIP ---------------------------------------------------
--- 与VIP相关的计数器， 次数见VipBase.csv，第六个参数为VIP的功能ID

-- 每天免费飞鸽次数		VipDefs.VIP_FUNC_ID_FREE_CHAT_TIMES
counter_bases[CounterDefs.COUNTER_BASE_ID_FREE_PIGEON] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 10, 10, nil, nil, 1)
-- 购买体力药计数		VipDefs.VIP_FUNC_ID_VIT_BUY_TIMES
counter_bases[CounterDefs.COUNTER_BASE_ID_BUY_VIT] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, nil, nil, 2)
-- 购买耐力药计数		VipDefs.VIP_FUNC_ID_ENDURANCE_BUY_TIMES
counter_bases[CounterDefs.COUNTER_BASE_ID_BUY_ENDURANCE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 5, 5, nil, nil, 3)
-- 购买副本次数计数		VipDefs.VIP_FUNC_ID_
counter_bases[CounterDefs.COUNTER_BASE_ID_BUY_SUBLINE_TIMES] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, nil, nil, 6)
-- 试炼塔可通过魔石重置次数
counter_bases[CounterDefs.COUNTER_BASE_ID_BABEL_RESET_TIMES_GOLD] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2, nil, nil, 5)
-- 豆蔓可通过魔石进入的次数
counter_bases[CounterDefs.COUNTER_BASE_ID_BABEL_TIMES_GOLD_ENTRY] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, nil, nil, 23)
-- 地下城堡每日魔石进入的次数
counter_bases[CounterDefs.COUNTER_BASE_ID_UNDERCROFT_GOLD] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, nil, nil, 25)


-------------------------------- MAP [END] -----------------------------------

-------------------------------- BASE [BEG] -----------------------------------


-- 每天军团密令的次数
counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_CMD] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, true, nil, CounterDefs.baseGetDiyCount)

-- 每天参加刀剑次数
counter_bases[CounterDefs.COUNTER_BASE_ID_DAOJIANJUE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, true)

-- 坐骑进化
counter_bases[CounterDefs.COUNTER_BASE_ID_HORSE_EVOLVE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 200, 200, true)

-- 进化总数计数
counter_bases[CounterDefs.COUNTER_BASE_ID_TARGET_UPGRADE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 100, 100, true)

-- 军团vip礼包总数计数
counter_bases[CounterDefs.COUNTER_BASE_ID_VIP_GANG_REWARD] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 1, 1, true)

-- 每天参加军团屠龙次数
counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_DRAGON] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, true)

-- 每天军团总屠龙次数
counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_DRAGON_TEAM] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 40, 40, true)

-- 激活码批次使用记录
counter_bases[CounterDefs.COUNTER_BASE_ID_ACT_CODE_USE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 1000, 1000, true)

-- 魅力活动使用
counter_bases[CounterDefs.COUNTER_BASE_ID_CHARM_CHANGEVOICE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 5, 5, true)


-- 军团战报名
counter_bases[CounterDefs.COUNTER_BASE_ID_GANG_BATTLE_BAOMING] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 1, 1, true)

-- 发送军团徽章道具
counter_bases[CounterDefs.COUNTER_BASE_ID_SEND_GANG_BADGE] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 1, 1)


-- 副本奖励保底 失败次数
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_95_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_105_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_115_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_125_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_135_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_145_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_155_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_165_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_175_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
counter_bases[CounterDefs.COUNTER_BASE_ID_SUBLINE_185_BAODI] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_EVER, 500, 500, true)
-------------------------------- BASE [END] -----------------------------------

-- 以下为需要区分语言的
if Language:isCN() then
----------------------- BASE ---------------------------------------
-- 禁言
counter_bases[CounterDefs.COUNTER_BASE_ID_CHAT_BAN] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 10, 10, true)

-- 解禁言
counter_bases[CounterDefs.COUNTER_BASE_ID_CHAT_UNBAN] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 10, 10, true)

----------------------- MAP -----------------------------------------

else
----------------------- BASE ---------------------------------------
-- 禁言
counter_bases[CounterDefs.COUNTER_BASE_ID_CHAT_BAN] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 3, 3, true)

-- 解禁言
counter_bases[CounterDefs.COUNTER_BASE_ID_CHAT_UNBAN] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 3, 3, true)

----------------------- MAP -----------------------------------------
end  -- end if Language:isCN() then

if Language:isEN() then
-- 交易购买
counter_bases[CounterDefs.COUNTER_BASE_ID_TRADE_BUY_LIMIT] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2)

-- 交易出售
counter_bases[CounterDefs.COUNTER_BASE_ID_TRADE_SALE_LIMIT] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 2, 2)

else

-- 交易购买
counter_bases[CounterDefs.COUNTER_BASE_ID_TRADE_BUY_LIMIT] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 999, 999)

-- 交易出售
counter_bases[CounterDefs.COUNTER_BASE_ID_TRADE_SALE_LIMIT] = _newCounterBase(CounterDefs.COUNTER_SORT_ID_DAILY, 999, 999)

end  -- end if Language:isEN() then

end  -- end do

do
	for counter_baseid, counter_base in pairs(CounterDefs.counter_bases) do
		counter_base.base_id = counter_baseid
	end
end

function CounterDefs:getCounterBase(counter_baseid)
	return self.counter_bases[counter_baseid]
end


do
	local this_week_begin = nil
	local this_week_end = nil
	-- 更新本周开始与结束信息
	function CounterDefs:_updateThisWeek(os_time)
		if not this_week_begin or os_time > this_week_end or os_time < this_week_begin then 
			local week = os.date("%w",os_time)	-- 周几
			if week == 0 then week = 7 end      -- 周日为周7
			local need_dec = week - 1
			local week_start = os_time - 24 * 3600 * need_dec  -- 本周一的此时此刻
			this_week_begin = Time:get0dianSec2(week_start)    -- 本周一0点
			this_week_end   = this_week_begin + 7 * 24 * 3600 - 1 -- 本周最后一秒
		end
	end

	function CounterDefs:getThisWeekBegin(os_time)
		self:_updateThisWeek(os_time)
		return this_week_begin
	end

	function CounterDefs:getThisWeekEnd(os_time)
		self:_updateThisWeek(os_time)
		return this_week_end
	end	
end

if AsReadOnly then
	AsReadOnly(CounterDefs)
end

------------------------- 各计数器基础对象定义 end ----------------------
