-- aoi特效类型定义
AoiTexiaoDefs =
{
	-- 临时特效
	SORT_SCORE_ADD_PIAOZI = 1,		--积分飘字特效
}
AsReadOnly(AoiTexiaoDefs)