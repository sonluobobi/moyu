--[[
	玩法奖励倍数定义
]]

--各个玩法定义
WanfaRewardRadixDefs = {
	wanfa_sort_id_reward_ratio 			= {}, 	--玩法奖励倍数定义
	wanfa_reward_ratio_week_days 		= {0,6},--周末自动开放配置 0=星期天
	wanfa_reward_ratio_timestr 			= {'2016-07-09', '2016-07-12'}, --指定日期段

	WANFA_SORT_ID_2V2					= 1,	--2V2
	WANFA_SORT_ID_GANG_DRAGON			= 2,	--军团屠龙
	WANFA_SORT_ID_SUBLINE 				= 3,	--组队副本
}

--各个玩法玩法双倍时间段配置
WanfaRewardRadixDefs.wanfa_sort_id_reward_time = {
	[WanfaRewardRadixDefs.WANFA_SORT_ID_2V2] 			= {'2016-07-09', '2016-07-12'},	--2V2
	[WanfaRewardRadixDefs.WANFA_SORT_ID_GANG_DRAGON] 	= {'2016-07-09', '2016-07-12'},	--军团屠龙
	[WanfaRewardRadixDefs.WANFA_SORT_ID_SUBLINE] 		= {'2016-07-09', '2016-07-12'},	--组队副本
}

--各个玩法加成配置
WanfaRewardRadixDefs.wanfa_sort_id_reward_ratio = {
	[WanfaRewardRadixDefs.WANFA_SORT_ID_2V2] 			= 2,	--2V2
	[WanfaRewardRadixDefs.WANFA_SORT_ID_GANG_DRAGON] 	= 2,	--军团屠龙
	[WanfaRewardRadixDefs.WANFA_SORT_ID_SUBLINE] 		= 2,	--组队副本
}

--检查是否开放
function WanfaRewardRadixDefs:checkIsOpen(sort_id, timestamp)
	--判断周末
	local cur_week = os.date('%w', timestamp) -- 0星期天 - 6星期六

	if Time:isInWeekDays(WanfaRewardRadixDefs.wanfa_reward_ratio_week_days) then 
		return true
	end

	local wanfa_reward_ratio_timestr = WanfaRewardDoubleDao:get_wanfa_type_date_config(sort_id)
	if not sort_id or not wanfa_reward_ratio_timestr then return false end

	--@todo 判断节假日
	--判断指定日期段
	local cur_date_str = os.date("%Y-%m-%d", timestamp)
	if not table.isTableEmpty(wanfa_reward_ratio_timestr) then
		local start_date = wanfa_reward_ratio_timestr[1]
		local end_date = wanfa_reward_ratio_timestr[2]

		if cur_date_str >= start_date and cur_date_str <= end_date then
			return true 
		end
	end

	return false
end

--获取玩法双倍id列表
function WanfaRewardRadixDefs:getRewardDoubleWanfaIds()
	local wanfa_sort_id_reward_ratio = WanfaRewardRadixDefs.wanfa_sort_id_reward_ratio or {}
	local ret = {}

	local sort_id_map = {}
	sort_id_map[WanfaRewardRadixDefs.WANFA_SORT_ID_2V2] = Statics.GAME_TYPE_ID_2V2 --2V2
	sort_id_map[WanfaRewardRadixDefs.WANFA_SORT_ID_GANG_DRAGON] = Statics.GAME_TYPE_ID_GANG_DRAGON --军团屠龙
	sort_id_map[WanfaRewardRadixDefs.WANFA_SORT_ID_SUBLINE] = Statics.PK_GAME_TYPE_ID_SUBLINE --组队副本

	for sort_id,_ in pairs(wanfa_sort_id_reward_ratio) do
		if WanfaRewardRadixDefs:checkIsOpen(sort_id) then 
			ret[#ret + 1] = sort_id_map[sort_id]
		end
	end

	return ret
end

--获取玩法加成接口
function WanfaRewardRadixDefs:getRewardRadix(sort_id, timestamp)
	if not sort_id 
	or not WanfaRewardRadixDefs.wanfa_sort_id_reward_ratio[sort_id] 
	or not WanfaRewardRadixDefs:checkIsOpen(sort_id, timestamp) then 
		return 1
	else
		local add_perc = WanfaRewardRadixDefs.wanfa_sort_id_reward_ratio[sort_id]
		if add_perc < 1 then add_perc = 1 end --默认一倍
		
		return add_perc
	end
end