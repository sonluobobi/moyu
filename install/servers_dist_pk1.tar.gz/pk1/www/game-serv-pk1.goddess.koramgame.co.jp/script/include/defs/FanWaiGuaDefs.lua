--[[
防外挂信息
author : shuyi.zhong
date : 2015-09-11
--]]

FanWaiGuaDefs = {
	WAIGUA_TYPE_FOR_BIANSUCILUN = 1,  -- 变速齿轮
	WAIGUA_TYPE_FOR_NEICUN_ERROR = 2, -- 内存错误

	PUNISH_TYPE_FOR_NOTHING = 1,	 -- 不惩罚
	PUNISH_TYPE_FOR_LEAVE_SCENE = 2, -- 离开场景
	PUNISH_TYPE_FOR_LOUGOUT = 3,	 -- 下线
}