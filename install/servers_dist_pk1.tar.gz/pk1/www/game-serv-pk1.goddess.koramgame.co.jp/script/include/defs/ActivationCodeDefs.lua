--[[
激活码相关定义
@author : xingzeng jiang
@create : 2012-12-22
]]--

ActivationCodeDefs = {
	-- 激活码中心服务器  使用接口地址
	ACTIVATION_CODE_CENTER_SERV_HOST_URL = 'http://act.moyu.kunlun.com/activation_code/index.php',
	ACTIVATION_CODE_CENTER_SERV_HOST_URL_TEST = 'http://acttest.moyu.kunlun.com/activation_code/index.php',
	
	-- 向激活码中心服认证后 回调函数名
	ACTIVATION_CODE_CENTER_CALLBACK_FUNC = 'callBackUseActivationCode',
	
	TOKEN_DECODE_KEY = '22xafjlajjlj^&*^*%*%1',	--与激活码中心通信的密钥
	
	--激活码分类ID (1：普通类, 2: 无前缀类)
	ACTIVATION_CODE_SORT_ID_NORMAL = 1,
	ACTIVATION_CODE_SORT_ID_NO_PREFIX = 2,
}

-- 获取激活码中心服地址
function ActivationCodeDefs:getActCodeServUrl()
	local act_code_serv_url = ActivationCodeDefs.ACTIVATION_CODE_CENTER_SERV_HOST_URL
	
	-- 测试服
	if Language:isTestServ() then
		act_code_serv_url = ActivationCodeDefs.ACTIVATION_CODE_CENTER_SERV_HOST_URL_TEST
	end
	
	--[[
	if Language:isEN() then
		act_code_serv_url = 'http://act.en.global.hoc.koramgame.com/activation_code/index.php'
	end
	--]]

	--北美
	if Language:isWorldAreaBeiMei() then
		act_code_serv_url = 'http://act.en.global.hoc.koramgame.com/activation_code/index.php'
	end

	--南美 
	if Language:isWorldAreaNanMei() then
		act_code_serv_url = 'http://act.br.global.hoc.koramgame.com/activation_code/index.php'
	end

	--欧洲
	if Language:isWorldAreaOuZhou() then
		act_code_serv_url = 'http://act.eu.global.hoc.koramgame.com/activation_code/index.php'
	end

	--东南亚
	if Language:isWorldAreaDongNanYa() then
		act_code_serv_url = 'http://act.sgp.global.hoc.koramgame.com/activation_code/index.php'
	end

	--日本
	if Language:isWorldAreaRiBen() then
		act_code_serv_url = 'http://act.jp.global.hoc.koramgame.com/activation_code/index.php'
	end

	--韩国
	if Language:isWorldAreaHanGuo() then
		act_code_serv_url = 'http://act.kr.global.hoc.koramgame.com/activation_code/index.php'
	end
	
	-- 应用宝
	if Language:isCnAreaYyb() then
		act_code_serv_url = 'http://act.moyu-yyb.kunlun.com/activation_code/index.php'
	end

	-- ios
	if Language:isCnAreaIos() then
		act_code_serv_url = 'http://act.moyu-ios.kunlun.com/activation_code/index.php'
	end

	-- 越狱ios
	if Language:isCnAreaYyIos() then
		act_code_serv_url = 'http://act.moyu-yyios.kunlun.com/activation_code/index.php'
	end

	-- 台湾大区
	if Language:isWorldAreaTW() then
		act_code_serv_url = 'http://act.moyu.kimi.com.tw/activation_code/index.php'
	end

	--新北美
	if Language:isWorldAreaBeiMeiNew() then
		act_code_serv_url = 'http://act.en1.global.hoc.koramgame.com/activation_code/index.php'
	end

	--俄罗斯
	if Language:isWorldAreaELuoSi() then
		act_code_serv_url = 'http://act.ru.global.hoc.koramgame.com/activation_code/index.php'
	end

	--泰国越南
	if Language:isYueNanTaiGuo() then
		act_code_serv_url = 'http://act.hoctv.siamgame.in.th/activation_code/index.php'
	end

	-- quick ios
	if Language:isCnAreaQuickIOS() then
		act_code_serv_url = 'http://act.moyu-quickios.kunlun.com/activation_code/index.php'
	end

	return act_code_serv_url
end
