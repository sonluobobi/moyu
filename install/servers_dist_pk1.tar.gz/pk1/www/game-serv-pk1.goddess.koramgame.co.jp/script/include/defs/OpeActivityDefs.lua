--[[
运营活动相关定义
@author : xingzeng jiang
@create : 2012-12-22
]]--

OpeActivityDefs = {
	--活动分类
    ACTIVITY_SORT_ID_FESTIVAL	= 1,	--节日活动
    ACTIVITY_SORT_ID_SYSTEM		= 2,	--系统活动 (一般值周期性的活动）
    ACTIVITY_SORT_ID_MAX		= 2,	--活动分类id最大值
	
	--发布类型
	OPERATE_SORT_PUBLISH_ACTIVITY = 1, 	 		--活动发布
	OPERATE_SORT_PUBLISH_DISCOUNT = 2,  		--活动打折
	OPERATE_SORT_PUBLISH_ACTIVATION_CODE = 3,  	--激活码批次信息
	OPERATE_SORT_PUBLISH_MALL     = 4,			--商城发布
	
	PRE_JOIN_ACTIVITY_EXPIRE_SEC = 90,	--准备参加活动计数过期时间 秒
	
	OPE_ACTIVITY_RECORD_NUM_MAX = 300,		-- 各类运营活动发布的记录条数上限
	
	OPE_ACTIVITY_TODAY_JOIN_NUM_MAX = 300,	-- 每日参加活动的次数上限
	
	OPE_ACTIVITY_CH_ENABLE_JOIN_INFO_EXPIRE = 1500,	-- 活动角色可参加次数情况缓存过期时间
	OPE_ACTIVITY_VOUCHER_CONSUME_EXPIRE = 1500,		-- 活动期间类玩家的充值、消费缓存
	OPE_ACTIVITY_VIP_CHNUM_STAT_EXPIRE = 3600,		-- 游戏内VIPX人数统计 缓存过期时间
	OPE_ACTIVITY_VOUCHER_TOPLIST_EXPIRE = 1800,		-- 充值排行榜缓存过期时间
	OPE_ACTIVITY_GOLDEGG_TOPLIST_EXPIRE = 1800,		-- 砸金蛋排行榜缓存过期时间
	OPE_ACTIVITY_CONSUME_TOPLIST_EXPIRE = 1800,		-- 消费排行榜客户端获取缓存过期时间
	OPE_ACTIVITY_REDGODD_TOPLIST_EXPIRE = 1800,		-- 红女神排行榜客户端获取缓存过期时间
	
	-- 活动流程状态
	OPE_ACT_STATE_NO_CHECK = 0,						--尚未检查
	OPE_ACT_STATE_ALREADY_CHECK = 1,	       		--已经检查完成
	OPE_ACT_STATE_ALREADY_REWARD = 2,				--已经发奖完成
	OPE_ACT_STATE_ONLY_CHECK_NO_CHECK = 10,			--尚未检查(仅需要检查不兑换)
	OPE_ACT_STATE_ONLY_CHECK_ALREADY_CHECK = 11,	--已经检查完成(仅需要检查不兑换)
	
	-- 检查或发奖处理结果状态
	OPE_ACT_JOIN_DEAL_OK = true,				-- 处理成功
	OPE_ACT_JOIN_DEAL_FAIL = false,				-- 处理失败
	OPE_ACT_JOIN_DEAL_STATE_GIVE_UP = 1,		-- 放弃，弃权 (移交给MAP处理)
	OPE_ACT_JOIN_DEAL_STATE_TEMP_NO_DEAL = 2,	-- 暂不处理(移交到DB处理)
	
	--活动 领取次数的报错阀值
	OPE_ACT_ERR_JOIN_TIMES_MAX = 500,			-- 后面会根据语言版本设定该值
	
	-- 每天领取次数的报错阀值
	OPE_ACT_ERR_JOIN_TIMES_TODAY_MAX = 250,		-- 后面会根据语言版本设定该值
	
	-- 固化活动的开启状态
	OPE_ACT_FIX_STATUS_CLOSE = 0,
	OPE_ACT_FIX_STATUS_OPEN = 1,
	
	-- 固化活动起始ID
	OPE_ACT_FIX_START_ID = 5000001,
	OPE_ACT_FIX_LONGTIME_START_ID = 5800001,
	
	-- 特殊定制化活动起始ID(运营活动菜单使用)
	SPECIAL_ACT_START_ID = 6000000,
	
	-- 是否检查固化活动早前已开启过
	-- 如果早前已开启过：禁止运营再次开启
	OPE_ACT_FIX_CHECK_BEFORE_ALREADY_OPEN = true,
	OPE_ACT_FIX_CHECK_BEFORE_ALREADY_CH_NUM = 500,
	
	-- 随机奖励概率基数
	RAND_REWARD_PROBA_BASE = 100000,
	
	-- 活动其实时间基点类型
	START_TIME_BASE_SORT_OPEPUBLISH = 0,			--活动后台发布时间
	START_TIME_BASE_SORT_OPE_FIX = 1,				--固化活动开启时间
	START_TIME_BASE_SORT_CH_CREATED = 2,			--角色创建时间
	START_TIME_BASE_SORT_CH_UPGRADE_LEV = 3,		--角色升级触发开启
	START_TIME_BASE_SORT_COMBINE_SERV = 4,			--合服时间
	
	-- 活动分组ID
    GROUP_ID_COMMON = 0,                     		--通用界面(初下面之外的活动都放这里)
    GROUP_ID_VER_UPDATE_NOTICE = 1,           		--版本更新公告
    GROUP_ID_VTOP_WING = 2,              			--充值排行榜送翅膀
	GROUP_ID_VTOP_SHENBING = 3,           			--充值排行榜送神兵
	GROUP_ID_VBUY_GIFT = 4,        		   			--充值购买类活动：现金限时礼包
	GROUP_ID_LEVEL_VBUY_GIFT = 5,           		--等级现金限时礼包
	GROUP_ID_CHRISTMAS_SNOW = 6,           			--圣诞飘雪
	GROUP_ID_CALL_RETURN = 7,           			--召回活动
	
	-- 消费排行榜的生成频率
	CONSUME_TOPLIST_UPDATE_INTERVAL = 2,			--消费排行榜缓存时间(秒 数据脏，且获取的时候才会检查并生成排行榜)
}

do
	local area_id = external.getAid() or 0
	if area_id >= 970 then
		OpeActivityDefs.OPE_ACT_FIX_CHECK_BEFORE_ALREADY_OPEN = false
	end
end

OpeActivityItemDefs = {
    --活动项分类
    ACTIVITY_ITEM_SORT_ID_FOR_NORMAL_EXCHNAGE		= 1,	--常规兑换类
    ACTIVITY_ITEM_SORT_ID_FOR_SPECIAL_CONDITION 	= 2,	--特殊条件兑换类
    
	------------------ 兑换类相关(常规兑换类,特殊条件兑换类)  start -----------------
    --活动兑换条件分类 (常规兑换类)
    AE_SORT_ID_FOR_FIX_EQUIP				= 1,	--道具兑换(暂只支持道具兑换道具,道具兑换装备,参数1:金币,参数2:兽魂,参数3:魔石,参数4:是否为充值魔石(0/1))
    AE_SORT_ID_FOR_PERIOD_CONSUME			= 2,	--活动内魔石消费额度兑换(不开放)
    AE_SORT_ID_FOR_PERIOD_CHARGE			= 3,	--活动内魔石充值额度兑换
	AE_SORT_ID_FOR_NO_CONDITION				= 5,	--无条件兑换类
	AE_SORT_ID_FOR_UPDATE_NOTICE			= 6,	--更新公告类
    AE_SORT_ID_FOR_ASSIGN_PLAYER            = 9,    --指定账户兑换(适合小数据量，1千个账户左右)
	AE_SORT_ID_FOR_ONE_CHARGE_EXCHANGE		= 10,	--活动内单笔充值额度兑换(参数1：条件下限，参数2：条件上限)
	AE_SORT_ID_FOR_ONE_CHRISTMAS_SNOW		= 11,	--圣诞飘雪
	
    --特殊条件兑换类活动兑换条件分类(特殊条件兑换类)
    AES_SORT_ID_FOR_CHARACTER_LEVEL		= 1,		--角色等级达成类
    AES_SORT_ID_FOR_CHARGE				= 2,		--阶段内充值金额达成类
    AES_SORT_ID_FOR_CONSUME				= 3,		--阶段内消费元宝达成类
	AES_SORT_ID_FOR_CHARGE_ONE			= 4,		--阶段内最大单笔充值额度达成
	AES_SORT_ID_FOR_CHARGE_BUY			= 5,		--阶段内充值购买达成(参数1:购买需要充值的魔石, 参数2:购买需要充值的金额(RMB或美元之类)*100,参数3:收益率%,参数4:商品ID,参数5:韩服IOS购买需要充值的金额)
	AES_SORT_ID_FOR_LEV_XJLB			= 6,		--等级限时现金礼包(参数1:购买需要充值的魔石, 参数2:购买需要充值的金额(RMB或美元之类)*100,参数3:收益率%,参数4:商品ID,参数5:韩服IOS购买需要充值的金额)
	AES_SORT_ID_FOR_CHARGE_TOPLIST		= 12,		--充值排行榜达成类(仅固化活动使用)
	AES_SORT_ID_FOR_HORSE_LEV			= 13,		--坐骑等级达成类
	AES_SORT_ID_FOR_GOLD_EGG_TOPLIST  	= 14,		-- 限时砸金蛋排行榜达成类
	AES_SORT_ID_FOR_CONSUME_TOPLIST		= 15,		--消费排行榜活动(不可做成固化活动)(参数1:名次下限,参数2:名次上限,参数3:要求最低消费魔石,参数4:消费结束时间偏移天数)
	AES_SORT_ID_FOR_REDGODD_TOPLIST  	= 16,		-- 红女神排行榜达成类

	AES_SORT_ID_FOR_CH_JEWEL_LEV_TOTAL	= 21,		--角色装备栏12件装备宝石总等级达成
	AES_SORT_ID_FOR_CH_FIGHT_CAPACITY	= 22,		--角色战力达成
	AES_SORT_ID_FOR_VIP_CH_NUM			= 29,		--全服VIPX人数达成(参数1:VIP等级,参数2:人数)
	AES_SORT_ID_FOR_OWN_PET_NUM			= 33,		--拥有X个指定资质幻兽的达成(参数1:个数,参数2:资质)
	AES_SORT_ID_FOR_VIP_LEV				= 35,		--VIP等级达成
	AES_SORT_ID_FOR_10_ZIZHI_HUANHUA	= 36,		--x个10资质幻兽幻化星级(参数1:个数,参数2:幻化星数)
	AES_SORT_ID_FOR_PET_FIGHT_CAPACITY	= 37,		--x个幻兽战力达成(参数1:个数,参数2:要求战力)
	AES_SORT_ID_FOR_EQUIP_CHAOS_GOLD	= 38,		--金色或以上装备洗练金色总X条达成
	AES_SORT_ID_FOR_EQUIP_CHAOS_PURPLE	= 39,		--金色或以上装备洗练紫色以上总X条达成
	AES_SORT_ID_FOR_RAND_DROP_EQUIP		= 40,		--在关卡或副本或野外额外掉落道具(参数1:掉落条件ID,参数2:不需填)
	AES_SORT_ID_FOR_EQUIP_JEWEL_LEV_RH	= 41,		--x个宝石达到y等级以上(参数1:个数,参数2:宝石等级)
	AES_SORT_ID_FOR_TOLLGATE_STAR_REACH	= 42,		--关卡总星数达成
	AES_SORT_ID_FOR_7_ZIZHI_HUANHUA		= 43,		--x个7资质(或以上)幻兽幻化星级(参数1:个数,参数2:幻化星数)
	AES_SORT_ID_FOR_PET_XUNLIAN_TOTAL	= 44,		--幻兽训练总次数
	AES_SORT_ID_FOR_VERSION_UPDATE		= 45,		--版本更新达成(参数1:需要更新到的客户端版本号)
	AES_SORT_ID_FOR_PET_FIGHT_HETI_BW	= 46,		--出战合体幻兽拥有X个Y品阶宝物(不含经验宝物)(参数1:个数,参数2:宝物品阶)
	AES_SORT_ID_FOR_OPEN_VTOP_ACT		= 47,		--翅膀/神兵/砸金蛋(参数1:对应固化活动ID,(参数2-4不填会用默认值)参数2:第1名充值下限(默认10000魔石),参数3:2-3名充值下限(默认5000魔石),参数4:4-10名充值下限(默认2000魔石))
	AES_SORT_ID_FOR_GUANZHU_HELP		= 48,		--关注HELP活动
	AES_SORT_ID_FOR_LUCK_GODDESS		= 49,		--幸运女神活动(不可做成固化活动)(参数1:暴击概率/100, 参数2:是否允许魔石许愿(0:否,1:是), 参数4:各轮配置信息)
	AES_SORT_ID_FOR_IOS_BIND 			= 50,		--IOS账号绑定
	AES_SORT_ID_FOR_CALLED_VIP_LEV		= 52,		--被召回人VIP等级达成(参数1:VIP等级)
	AES_SORT_ID_FOR_CALLER_PLAYER_NUM	= 53,		--已召回人数达成(参数1:已召回人数, 参数2:VIP等级)
	AES_SORT_ID_FOR_CALL_CODE_USE		= 54,		--召回码使用活动(仅控制此活动是否显示)
	AES_SORT_ID_FOR_CALLED_QIANDAO		= 55,		--被召回人登录签到(参数1:第X天签到)
	
	-- 活动期间内达成
	AESR_SORT_ID_IN_REACH_START 		= 101,		--活动期间内达成类型 开始ID
	AESR_SORT_ID_FOR_PET_XUNLIAN		= 101,		--活动期间内幻兽训练达成(参数1：需要达成次数)
	AESR_SORT_ID_FOR_HORSE_EVOLVE		= 102,		--活动时间内坐骑进化次数(参数1：需要达成次数)
	AESR_SORT_ID_FOR_ZADAN_PURPLE		= 103,		--活动时段内砸紫蛋次数(参数1：需要达成次数)
	AESR_SORT_ID_IN_REACH_END 			= 199,		--活动期间内达成类型 结束ID
	
    --活动兑换奖励分类 (暂不支持新增奖励类型，如果增加，请修改b2m_joinActivityItem的奖励处理逻辑)
	AER_SORT_ID_FOR_NONE			= 0,	--无奖励
    AER_SORT_ID_FOR_FIX_EQUIP		= 1,	--奖励固定道具
    AER_SORT_ID_FOR_RAND_EQUIP		= 2,	--奖励随机道具
    ------------------ 兑换类相关 start -----------------
}

function OpeActivityItemDefs:isCallbackOpeAct(activity_item)
	if activity_item.activity_item_sort_id ~= self.ACTIVITY_ITEM_SORT_ID_FOR_SPECIAL_CONDITION then
		return false
	end
	
	local exchange_special_cond_sort_id = activity_item.exchange_special_cond_sort_id
	if exchange_special_cond_sort_id == self.AES_SORT_ID_FOR_CALLED_VIP_LEV or 
		exchange_special_cond_sort_id == self.AES_SORT_ID_FOR_CALLER_PLAYER_NUM or
		exchange_special_cond_sort_id == self.AES_SORT_ID_FOR_CALLED_QIANDAO or
		exchange_special_cond_sort_id == self.AES_SORT_ID_FOR_CALL_CODE_USE 
		then
		return true
	else
		return false
	end
end
AsReadOnly(OpeActivityItemDefs)
AsReadOnly(OpeActivityDefs)

