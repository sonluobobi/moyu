--
--------------------------------------------------------------------------------
-- 活跃度相关定义
--author : jinlin.liu
--date : 2016-07-20
--------------------------------------------------------------------------------


WeddingDefs = {
	
	WED_SEND_SILVER_COUNT = 10000,       -- 送金币数目
	WED_SEND_VOUCHGOLD_COUNT = 10,       -- 送魔石数目
	
	
	
	WED_ORDER_STATUS_FREE = 1,     -- 空闲
	WED_ORDER_STATUS_ORDERED = 2,     -- 已预约
	
	WED_TYPE_COMM = 1,     -- 婚宴类型1普通，2高级，3豪华
	WED_TYPE_GOOD = 2,
	WED_TYPE_SUPER = 3,
	
	WED_OPT_TYPE_ACCEPT = 1, --1为接受 2为拒绝 3不允许其它人参加 4无需审核
	WED_OPT_TYPE_REFUSE = 2,
	WED_OPT_TYPE_NOT_ALLOW = 3,
	WED_OPT_TYPE_NONEED_VERIFY = 4,
	
	
	WED_PROCESS_TYPE_PREPARE = 1, --婚宴状态 1入席 2开始,3礼仪,4抢花球,5礼仪后,6结束
	WED_PROCESS_TYPE_BEGIN = 2,
	WED_PROCESS_TYPE_LIYI = 3,
	WED_PROCESS_TYPE_ROB_BALL = 4,
	WED_PROCESS_TYPE_AFTERLIYI = 5,
	WED_PROCESS_TYPE_OVER = 6,
	
	WED_SEND_GIFT_STATUS_NOTSEND = 1, --1表示未送
	WED_SEND_GIFT_STATUS_HASSEND = 2, -- 2 表示已送
	
	WED_SCENE_COMMON = 60008,  --普通婚宴场景
	WED_SCENE_GOOD = 60009,  --高级婚宴场景
	WED_SCENE_SUPER = 60010,  --豪华婚宴场景
	
	WED_TOTAL_CARD_NUM = 40, --总请帖数
	--0表示还未收到过，1：接收到请帖未看，2：接收到请帖已经看过
	WED_CARD_NOTGET = 0,
	WED_CARD_HASGET = 1,
	WED_CARD_HASREAD = 2,
	
	WED_SCENE_OPT_FIREWORKDS = 1,
	WED_SCENE_OPT_TOAST = 2,
	WED_SCENE_OPT_TOAST_BACK = 3,
	
	WED_NEED_COMPARE_MONEY = 1,
	
	WED_CANNOT_IN = 0,  --0:不能参加，1:申请通过参加，2：请帖参加 3:主人参加
	WED_NOINVITECARD_IN = 1,
	WED_HASINVITECARD_IN = 2,
	WED_OWNER_IN = 3,
	
	WED_APP_TIMES = 1,  --每天只可申请参加一场婚宴
	WED_ALLOW_NOCARD_NUM = 10,--只允许10个没有请帖
	
	WED_COST_COMMON_GOLD = 0, --普通魔石
	WED_COST_VOUCH_GOLD = 1, --充值魔石
	
	--红点定义
	WED_REDFLAG_MASTER_APP = 1,--申请相关的红点
	WED_REDFLAG_INVITE_CARD = 2, --请帖相关红点
	
	WED_ITEMID_ORDER_CARD = 21010338, --预约券

	WED_ITEMID_COMMON_CLOTH = 10130003, --普通礼服
	WED_ITEMID_GOOD_CLOTH = 10130009, --高级礼服
	WED_ITEMID_SUPPER_CLOTH = 10130010, --豪华礼服


	WED_WDRING_SILVER =  10110002,  --银对戒
	WED_WDRING_BAIJING =  10110003,   --白金对戒
	WED_WDRING_BAOSHI =  10110004,   --宝石对戒
	WED_WDRING_ZHUANSHI =  10110005,  --钻石对戒
	
}

