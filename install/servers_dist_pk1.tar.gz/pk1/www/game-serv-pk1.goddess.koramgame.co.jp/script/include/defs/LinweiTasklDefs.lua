--[[
临危任务定义
author : guoyin.huang
--]]


LinweiTaskDefs =
{
	-- 任务类型
	LINWEI_TASK_TYPE_BEG = 1,
	LINWEI_TASK_TYPE_QINGGUAI = 1,	--清怪任务
	LINWEI_TASK_TYPE_NPC = 2,		--守护NPC
	LINWEI_TASK_TYPE_BOSS= 3,		--杀BOSS
	LINWEI_TASK_TYPE_SURPISE = 4,	--惊喜任务
	LINWEI_TASK_TYPE_CONTINUE= 5,	--串联任务
	LINWEI_TASK_TYPE_ENG = 5,

	-- 任务类别
	LINWEI_TASK_SORT_BASE = 1,	--基础任务
	LINWEI_TASK_SORT_COMB = 2,	--组合任务

	-- 临危库数据类型
	LINWEI_LIB_SORT_NPC = 3,	--赋予NPC
	LINWEI_LIB_SORT_BOSS= 2,	--赋予BOSS怪
	LINWEI_LIB_SORT_MONSTER = 1,--赋予普通怪

	-- 临危位置
	LINWEI_POS_LEFT_BELOW  = 1,	--左下
	LINWEI_POS_RIGHT_BELOW = 2,	--右下
	LINWEI_POS_RIGHT_UPPER = 3,	--右上
	LINWEI_POS_LEFT_UPPER  = 4,	--左上

	-- 临危对象类型
	LINWEI_OBJ_TYPE_MONSTER = 1,	--普通怪物
	LINWEI_OBJ_TYPE_BOSS 	= 2,	--BOSS
	LINWEI_OBJ_TYPE_NPC 	= 3,	--NPC
	LINWEI_OBJ_TYPE_NPC_WARP= 4,	--传送门
	LINWEI_OBJ_TYPE_BOMB_MONSTER = 5, 	--爆炸怪

	-- 临危任务状态
	LINWEI_STATUS_COMMON 	  = 1,		--正常打怪中
	LINWEI_STATUS_ONE_TASK_FINISH = 2,	--一个任务完成
	LINWEI_STATUS_FAIL = 3,				--任务失败
	LINWEI_STATUS_WAVE_FINISH = 4,		--一波怪完成

	LINWEI_MEDAL_MAX_NUM = 80,			--每日可获得的奖牌数

	BAOXIANG_EQUIP_ID = 21010020,		--宝箱道具ID
}

if AsReadOnly then
	AsReadOnly(LinweiTaskDefs)
end