
GangBattleChusaiDefs = {
	-- 玩家状态
	STATUS_COMMON = 1,	--未匹配状态
	STATUS_MATCH = 2, 	--匹配中
	STATUS_FIGHT = 3,	--战斗中
}