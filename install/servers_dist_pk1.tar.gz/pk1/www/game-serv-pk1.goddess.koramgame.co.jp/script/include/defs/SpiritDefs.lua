SpiritDefs = {
	SORT_ID_GUANGMING = 1,		--光明精灵
	SORT_ID_ANYE = 2,			--暗夜精灵

	-- 这里不能修改， 必须跟 幻兽部位栏ID一致(ChPetEquipDefs.PET_EQUIP_BAR_*)
	ZHENFA_ID_START = 0,
	ZHENFA_ID_END = 2,


	-- 每次吃精灵需要消耗的银两
	EAT_SPIRIT_NEED_SILVER = 5000,	
}

-- 是否需要吃掉一条从属性
function SpiritDefs:isEatCEffect(  )
	return math.random(1, 2) == 1
end
