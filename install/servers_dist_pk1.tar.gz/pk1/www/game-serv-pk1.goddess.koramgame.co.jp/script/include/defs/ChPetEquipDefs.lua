--[[
	幻兽装备def
]]--

ChPetEquipDefs = 
{
	--幻兽位置，客户端使用,分别对应装备服务器的1，2，3 
	--(注：别修改，客户端有些地方写死了)
	PET_EQUIP_BAR_ZHAN = 0,	--出战	->1
	PET_EQUIP_BAR_IN   = 1, --内	->2
	PET_EQUIP_BAR_OUT  = 2,	--外	->3
	PET_EQUIP_BAR_TROOP_START  = 3,	--骑士宝物装备栏开始编号
	PET_EQUIP_BAR_TROOP1  = 3,	--1号骑士
	PET_EQUIP_BAR_TROOP2  = 4,	--2号骑士
	PET_EQUIP_BAR_TROOP3  = 5,	--3号骑士
	PET_EQUIP_BAR_TROOP4  = 6,	--4号骑士
	PET_EQUIP_BAR_TROOP5  = 7,	--5号骑士
	PET_EQUIP_BAR_TROOP6  = 8,	--6号骑士
	PET_EQUIP_BAR_TROOP7  = 9,	--7号骑士
	PET_EQUIP_BAR_TROOP8  = 10,	--8号骑士
	PET_EQUIP_BAR_TROOP9  = 11,	--9号骑士
	PET_EQUIP_BAR_TROOP10 = 12,	--10号骑士
	PET_EQUIP_BAR_TROOP_END  = 12,	--骑士宝物装备栏结束编号
	
	MAX_BAOWU_LEVEL = 100,		--宝物最大等级

	BAOWU_EXP_2_SILVER = 1,		--宝物经验消耗的
	
	BW_JINGLIAN_MIN_QUALITY = 7,		-- 紫色品阶以上宝物才可以精炼
	BW_JINGLIAN_FULL_LEV = 15,			-- 精炼达到的最高等级
}

if AsReadOnly then
	AsReadOnly(ChPetEquipDefs)
end