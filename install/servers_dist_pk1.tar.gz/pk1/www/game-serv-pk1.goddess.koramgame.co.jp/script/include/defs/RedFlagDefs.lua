--[[
红点提醒标志 定义
author : xingzeng
date : 2014-08-18
$Id: $
--]]

RedFlagDefs = RedFlagDefs or {}

-- MAP 红点ID定义
RedFlagDefs.RED_FLAG_ID_INVITEE_REWARD = 1		-- 邀请下线奖励
RedFlagDefs.RED_FLAG_ID_MONTH_CARD = 2			-- 月卡
RedFlagDefs.RED_FLAG_ID_LIFELONG_CARD = 3		-- 终身卡
RedFlagDefs.RED_FLAG_ID_FUND = 4				-- 基金
RedFlagDefs.RED_FLAG_ID_BETTER_BWCHIP = 5		-- 有更好宝物碎片
RedFlagDefs.RED_FLAG_ID_WANFA_REWRAD = 6		-- 玩法奖励找回
RedFlagDefs.RED_FLAG_ID_GLOBAL_ARENA = 7		-- 诸神黄昏
RedFlagDefs.RED_FLAG_ID_SPIRIT_GUARD = 8		-- 精灵守护
RedFlagDefs.RED_FLAG_ID_UNDERCROFT = 9			-- 地下城堡
RedFlagDefs.RED_FLAG_ID_DAOJIANJUE = 10			-- 帝国争锋

-- BASE 红点ID定义
RedFlagDefs.RED_FLAG_ID_GANG_BATTLE_BAOMING = 101	--是否可报名
RedFlagDefs.RED_FLAG_ID_GANG_BATTLE_VS_LIST = 102	--是否有新对战表

-- 带更新时间的红点ID定义
RedFlagDefs.RED_FLAG_ID_UPTIME_START = 201			--开始ID
RedFlagDefs.RED_FLAG_ID_UPTIME_WENDDING = 201		--婚姻新事件
RedFlagDefs.RED_FLAG_ID_UPTIME_END = 301			--结合ID

AsReadOnly(RedFlagDefs)