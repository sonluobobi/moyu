BabelDefs = {
	MAX_BABEL_ID  = 60,	--摩天豆蔓最高层
}