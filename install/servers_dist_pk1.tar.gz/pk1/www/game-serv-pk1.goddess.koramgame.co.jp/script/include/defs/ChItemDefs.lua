
ChItemDefs = {
	-- 注：真实包裹大小 比 玩家能看到的大小 大200
	--     玩家每次扩展包裹， 2个大小同时扩充
	--	   包裹理论最大上限 350 + 150 = 500
	CH_PACKAGE_INIT_SIZE = 350,			-- 包裹初始给的 真实大小(注：该值不能太大，太大影响性能)
	CH_PACKAGE_INIT_SIZE_SHOW = 150,	-- 包裹初始给的 玩家能看到的大小
	CH_PACKAGE_SIZE_SHOW_MAX = 300,		-- 玩家能扩充到的 包裹上限(玩家看到的包裹最大尺寸)
	CH_PACKAGE_SIZE_CLIENT_MAX_BEYOND = 100,-- 客户端检查包裹允许超出上限的数量
	
	CH_EQUIPBAR_BOX_NUM_TOTAL = 1,			-- 最多可以拥有的装备栏个数
	CH_EQUIPBAR_FREE_BOX_NUM = 1,			-- 免费开启的装备栏个数
	CH_EQUIPBAR_BOX_SIZE = 28,				-- 一个装备栏大小
	
	CH_ITEMBAR_SPECIAL_BOX_NUM_TOTAL = 1,	--特殊装备栏的个数
	CH_ITEMBAR_SPECIAL_BOX_SIZE = 1,		--特殊装备栏的大小
	
	---------------------- 装备栏部位相关 start -----------------------
	-- 装备栏部位ID定义
	EQUIPBAR_POS_WUQI = 1,					-- 武器
	EQUIPBAR_POS_XIANGLIAN = 2,				-- 项链
	EQUIPBAR_POS_SHOUZHUO = 3,				-- 手镯
	EQUIPBAR_POS_JIEZHI = 4,				-- 戒指
	EQUIPBAR_POS_WUSHOU = 5,				-- 护手、手套
	EQUIPBAR_POS_TOUSHI = 6,				-- 头饰
	EQUIPBAR_POS_YIFU = 7,					-- 衣服
	EQUIPBAR_POS_YAODAI = 8,				-- 腰带
	EQUIPBAR_POS_HUTUI = 9,					-- 护腿
	EQUIPBAR_POS_XIEZI = 10,				-- 鞋子
	EQUIPBAR_POS_AVATAR = 11,				-- 时装
	EQUIPBAR_POS_QINGLV = 12,				-- 情侣
	EQUIPBAR_POS_MAGIC_RING = 13,			-- 魔戒
	EQUIPBAR_POS_SHEN_BING = 14,			-- 神兵
		
	EQUIPBAR_POS_HORSE1 = 19,			-- 坐骑装备1
	EQUIPBAR_POS_HORSE2 = 20,			-- 坐骑装备2
	EQUIPBAR_POS_HORSE3 = 21,			-- 坐骑装备3
	EQUIPBAR_POS_HORSE4 = 22,			-- 坐骑装备4
	
	EQUIPBAR_POS_FIGHT_MSTAR = 23,			-- 出战幻兽主星
	EQUIPBAR_POS_FIGHT_SSTAR = 24,			-- 出战幻兽傍星
	EQUIPBAR_POS_HT_IN_MSTAR = 25,			-- 内层合体幻兽主星
	EQUIPBAR_POS_HT_IN_SSTAR = 26,			-- 内层合体幻兽傍星
	EQUIPBAR_POS_HT_OUT_MSTAR = 27,			-- 外层合体幻兽主星
	EQUIPBAR_POS_HT_OUT_SSTAR = 28,			-- 外层合体幻兽傍星
	
	EQUIPBAR_POS_WING = 30,				-- 翅膀(不在装备栏)
	
	-- 主角的装备栏部位ID范围
	CH_EQUIPBAR_POS_BEGIN = 1,
	CH_EQUIPBAR_POS_END = 14,
	
	-- 侠客装备栏部位ID范围
	PET_EQUIPBAR_POS_BEGIN = 0,
	PET_EQUIPBAR_POS_END = 0,
	
	-- 坐骑装备栏部位ID范围
	HORSE_EQUIPBAR_POS_BEGIN = 19,
	HORSE_EQUIPBAR_POS_END = 22,
	-- 这里重复配置了，但是2种都有在使用，这里就不修改了
	EQUIPBAR_POS_NORMAL_EQUIP_HORSE_START = 19,	-- 坐骑装备的格子已开启的起始ID
	EQUIPBAR_POS_NORMAL_EQUIP_HORSE_END = 22,	-- 坐骑装备的格子已开启的最大ID
	
	-- 幻兽双星装备栏部位ID范围
	TSTAR_EQUIPBAR_POS_BEGIN = 23,
	TSTAR_EQUIPBAR_POS_END = 28,
	
	EQUIPBAR_POS_NORMAL_EQUIP_MIN = 1,			-- 普通装备的格子起始ID
	EQUIPBAR_POS_NORMAL_EQUIP_MAX = 28,			-- 普通装备的格子结束ID(跟CH_EQUIPBAR_BOX_SIZE一致)
	EQUIPBAR_POS_NORMAL_EQUIP_MAX_OPENED = 14,	-- 普通装备的格子已开启的最大ID
	EQUIPBAR_POS_NORMAL_EQUIP_MAX_STRONG = 10,	-- 已开启强化到最大ID
			
	-- 角色道具所在位置类型
	EQUIP_IN_ITEM_TYPE_PACKAGE = 0,				-- 包裹
	EQUIP_IN_ITEM_TYPE_EQUIPBAR = 1,			-- 装备栏
	EQUIP_IN_ITEM_TYPE_PETBAR = 2,				-- 幻兽装备栏
	EQUIP_IN_ITEM_TYPE_HORSEBAR = 3,			-- 坐骑装备栏
	EQUIP_IN_ITEM_TYPE_STORAGE = 4,				-- 仓库
	EQUIP_IN_ITEM_TYPE_SPECIAL = 5,				-- 特殊装备栏
	
	-- 道具分类到装备穿戴位置映射关系
	-- 内容定义在EquipDefs类定义后面
	equipsort_2_equipbar_pos = {},
	
	---------------------- 装备栏部位相关 end -----------------------
	
	-- 装备强化类型ID定义
	EQUIP_STRONG_ID_OWN = 0,				-- 持有
	EQUIP_STRONG_ID_STRONG = 1,				-- 强化升级
	EQUIP_STRONG_ID_PUNCH = 2,				-- 打孔
	EQUIP_STRONG_ID_EMBED = 3,				-- 镶嵌
	EQUIP_STRONG_ID_JINGLIAN = 4,			-- 精炼
	
	-- 装备附加效果表类型定义
	EQUIP_ADDI_EFFECT_SORT_ID_STRONG = 0,	-- 身上全套装备强化(含宝石等级、强化等级)附加效果
	EQUIP_ADDI_EFFECT_SORT_ID_AVATAR = 1,	-- 身上2件时装翅膀的附加效果
	
	EQUIP_ITEM_OPEN_HOLE_MAX = 3,				-- 装备部位最大可开孔数
	
	-- 装备类型ID对应的强化ID
	esort_id2no_estrong_id = nil,
	
	-- 强化升级 暴击
	strong_baoji_multi_proba = {
		[1] = 10,
		[2] = 10,
		[3] = 10,
		[4] = 10,
		[5] = 10,
	},
	
	-- 全身满强化X级的个数要求
	EQUIPBAR_FULL_STRONG_LEV_NUM = 10,				
	
	-- 宝石合成
	MAX_LIMIT_JEWEL_LEV_THEORY = 20,					-- 宝石等级理论上限
	MIXTURE_JEWEL_MAX_LEV = 9,							-- 可合成的最高宝石等级
	JEWEL_MIXTURE_MAX_NUM = 9999,						-- 一次合成宝石的最大数量
	EQUIPBAR_FULL_JEWEL_NUM = 30,						-- 全身满宝石的个数要求
	EQUIP_SPLIT_DAILY_NUM = 10,							-- 每日最多可分解装备数量
	
	--装备部位初始化孔数随机数 (赞未使用)
	equip_init_punch_rand = {45,50,4,1},

	------------- 装备栏精炼 start ---------------------
	------------- 装备栏精炼 end ---------------------
	
	
	------------- 宝石祝福 start ---------------------
	JEWEL_BLESS_MIN_JEWEL_LEV = 6,						--6级宝石才开启祝福
	JEWEL_BLESS_MAX_LEV = 12,							--宝石祝福最高等级
	order_by2jewel_bless_effect_type = {},				--部位对应的宝石祝福加成属性名 type:Hashtable
	
	jewel_lev2max_less_lev = {},						--宝石等级对应开启的祝福等级上限 type:Hashtable
	------------- 宝石祝福 end ---------------------
}
AsReadOnly(ChItemDefs)
local ChItemDefs = ChItemDefs

--部位对应的宝石祝福加成属性名
ChItemDefs.order_by2jewel_bless_effect_type = {
	[ChItemDefs.EQUIPBAR_POS_WUQI] = 'addi_harm_perc',					-- 武器
	[ChItemDefs.EQUIPBAR_POS_XIANGLIAN] = 'reduce_harm_perc',			-- 项链
	[ChItemDefs.EQUIPBAR_POS_SHOUZHUO] = 'addi_harm_perc',				-- 手镯
	[ChItemDefs.EQUIPBAR_POS_JIEZHI] = 'addi_harm_perc',				-- 戒指
	[ChItemDefs.EQUIPBAR_POS_WUSHOU] = 'addi_harm_perc',				-- 护手、手套
	[ChItemDefs.EQUIPBAR_POS_TOUSHI] = 'reduce_harm_perc',				-- 头饰
	[ChItemDefs.EQUIPBAR_POS_YIFU] = 'reduce_harm_perc',				-- 衣服
	[ChItemDefs.EQUIPBAR_POS_YAODAI] = 'reduce_harm_perc',				-- 腰带
	[ChItemDefs.EQUIPBAR_POS_HUTUI] = 'addi_harm_perc',					-- 护腿
	[ChItemDefs.EQUIPBAR_POS_XIEZI] = 'reduce_harm_perc',				-- 鞋子
	
	[ChItemDefs.EQUIPBAR_POS_AVATAR] = 'addi_harm_perc',				-- 时装
	[ChItemDefs.EQUIPBAR_POS_QINGLV] = 'addi_harm_perc',				-- 情侣
	[ChItemDefs.EQUIPBAR_POS_MAGIC_RING] = 'addi_harm_perc',			-- 魔戒
	[ChItemDefs.EQUIPBAR_POS_SHEN_BING] = 'addi_harm_perc',			-- 神兵
		
	[ChItemDefs.EQUIPBAR_POS_HORSE1] = 'reduce_harm_perc',				-- 坐骑装备1
	[ChItemDefs.EQUIPBAR_POS_HORSE2] = 'reduce_harm_perc',				-- 坐骑装备2
	[ChItemDefs.EQUIPBAR_POS_HORSE3] = 'reduce_harm_perc',				-- 坐骑装备3
	[ChItemDefs.EQUIPBAR_POS_HORSE4] = 'reduce_harm_perc',				-- 坐骑装备4
	
	[ChItemDefs.EQUIPBAR_POS_WING] = 'reduce_harm_perc',				-- 翅膀
}

--宝石等级对应开启的祝福等级上限
ChItemDefs.jewel_lev2max_less_lev = {
	[6] = 3,
	[7] = 6,
	[8] = 9,
	[9] = 12,
}

-- 道具分类到装备穿戴位置映射关系
do
	local equipsort_2_equipbar_pos
	local type = type
	
	-- 根据装备类型获取装备所在的位置
	function ChItemDefs:getChItemBarPos(equip_sort_id, petequip_bar_id)
		if not equipsort_2_equipbar_pos then
			equipsort_2_equipbar_pos = {}
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_WUQI] = self.EQUIPBAR_POS_WUQI
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_XIANGLIAN] = self.EQUIPBAR_POS_XIANGLIAN
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_SHOUZHUO] = self.EQUIPBAR_POS_SHOUZHUO
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_JIEZHI] = self.EQUIPBAR_POS_JIEZHI
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_WUSHOU] = self.EQUIPBAR_POS_WUSHOU
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_TOUSHI] = self.EQUIPBAR_POS_TOUSHI
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_YIFU] = self.EQUIPBAR_POS_YIFU
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_YAODAI] = self.EQUIPBAR_POS_YAODAI
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_HUTUI] = self.EQUIPBAR_POS_HUTUI
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_XIEZI] = self.EQUIPBAR_POS_XIEZI
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_AVATAR] = self.EQUIPBAR_POS_AVATAR
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_QINGLV] = self.EQUIPBAR_POS_QINGLV
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_MAGIC_RING] = self.EQUIPBAR_POS_MAGIC_RING
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_SHENBING] = self.EQUIPBAR_POS_SHEN_BING
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_HORSE1] = self.EQUIPBAR_POS_HORSE1
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_HORSE2] = self.EQUIPBAR_POS_HORSE2
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_HORSE3] = self.EQUIPBAR_POS_HORSE3
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_HORSE4] = self.EQUIPBAR_POS_HORSE4
			
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_TSTAR_MAIN] = {self.EQUIPBAR_POS_FIGHT_MSTAR,self.EQUIPBAR_POS_HT_IN_MSTAR,self.EQUIPBAR_POS_HT_OUT_MSTAR}
			equipsort_2_equipbar_pos[EquipDefs.EQUIP_SORT_ID_TSTAR_SECOND] = {self.EQUIPBAR_POS_FIGHT_SSTAR,self.EQUIPBAR_POS_HT_IN_SSTAR,self.EQUIPBAR_POS_HT_OUT_SSTAR}
		end
		
		local order_by = equipsort_2_equipbar_pos[equip_sort_id]
		if type(order_by) == 'table' then
			return nil, order_by
		end
		return order_by
	end

end

do
	-- 装备类型对应不能进行的强化
	local esort_id2no_estrong_id
	
	function ChItemDefs:isNoStrong(character, equip_sort_id, equip_strong_id)
		if not esort_id2no_estrong_id then
			esort_id2no_estrong_id = {
				
			}
		end
		
		local no_strongs = esort_id2no_estrong_id[equip_sort_id]
		local is_no_strong = no_strongs and no_strongs[equip_strong_id] or false
		return is_no_strong and true or false
	end
end

-- 是否合法的order_by
function ChItemDefs:isOkOrderBy(order_by)
	return (order_by >= self.TSTAR_EQUIPBAR_POS_BEGIN and order_by <= self.TSTAR_EQUIPBAR_POS_END) or
		(order_by >= self.HORSE_EQUIPBAR_POS_BEGIN and order_by <= self.HORSE_EQUIPBAR_POS_END) or
		(order_by >= self.CH_EQUIPBAR_POS_BEGIN and order_by <= self.CH_EQUIPBAR_POS_END)
end

function ChItemDefs:isPetTowStar(order_by)
	return order_by >= self.TSTAR_EQUIPBAR_POS_BEGIN and order_by <= self.TSTAR_EQUIPBAR_POS_END
end

function ChItemDefs:isPlayerOrderBy(order_by)
	return order_by >= self.CH_EQUIPBAR_POS_BEGIN and order_by <= self.CH_EQUIPBAR_POS_END
end
