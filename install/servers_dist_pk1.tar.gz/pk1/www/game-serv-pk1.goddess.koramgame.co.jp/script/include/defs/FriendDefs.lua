--
--------------------------------------------------------------------------------
-- 好友定义
--author : fuqian.liao
--date : 2014-12-01
--------------------------------------------------------------------------------
--

FriendDefs = {
	OP_TYPE_ADD = 1, --添加好友
	OP_TYPE_FOCUS = 2, --关注好友
	OP_TYPE_CANCLE_FOCUS = 3, --取消关注
	OP_TYPE_DELETE = 4, --删除好友

	--好友类型 
	FRIEND_TYPE_LOCAL = 1, --本服
	FRIEND_TYPE_REMOTE = 2, --跨服

	FRIEND_PROF_PER_SIZE = 20, --每页展示好友数
	
	DEFAULT_FRIEND_NUM = 40,               --默认好友数
	FRIEND_SORT_ID_FRIEND    = 1,           --好友
	FRIEND_SORT_ID_ENEMY      = 2,           --仇敌
	FRIEND_SORT_ID_BLACK      = 3,           --黑名单
	
	sort_id2_field = {},

	--好友请求列表保留记录数
	FRIEND_REQUEST_LOG_NUM = 20, --保留20条好友请求记录

	--好友送花
	ADD_INITMACY_LEVLE1 = 1, -- 道具赠送
	ADD_INITMACY_LEVLE2 = 2, -- 2档80亲密度
	ADD_INITMACY_LEVLE3 = 3, -- 3档500亲密度

	add_initmacy_counter = {}, --好友送花分档计数器
	add_initmacy_vip_func_id = {}, --好友送花分档vip func_id定义

	--好友参与活动类型
	FRIEND_ACT_TYPE_ID_SUBLINE = 1, --组队副本
	FRIEND_ACT_TYPE_ID_LINWEI = 2, --临危受命

	act_add_initmacy_map = {}, --好友活动，对应亲密度值

	--黑名单
	DEFAULT_BLACK_NUM = 10,               --默认黑名单数
}

FriendDefs.sort_id2_field[FriendDefs.FRIEND_SORT_ID_FRIEND] = 'friend_list'
FriendDefs.sort_id2_field[FriendDefs.FRIEND_SORT_ID_ENEMY]   = 'enemy_list'
FriendDefs.sort_id2_field[FriendDefs.FRIEND_SORT_ID_BLACK]   = 'black_list'


FriendDefs.add_initmacy_counter = 
{
	[FriendDefs.ADD_INITMACY_LEVLE2] = 39,
	[FriendDefs.ADD_INITMACY_LEVLE3] = 40,
}

FriendDefs.add_initmacy_vip_func_id = 
{
	[FriendDefs.ADD_INITMACY_LEVLE2] = 21,
	[FriendDefs.ADD_INITMACY_LEVLE3] = 22,
}

--好友活动，添加对应亲密度值
FriendDefs.act_add_initmacy_map = 
{
	[FriendDefs.FRIEND_ACT_TYPE_ID_SUBLINE] = 35, --组队通关副本
	[FriendDefs.FRIEND_ACT_TYPE_ID_LINWEI] = 15, --临危任务
}

--获取不同类型对应的 field
function FriendDefs:getSortIdField(sort_id)
	return self.sort_id2_field[sort_id]
end