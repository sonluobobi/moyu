--[[
公告系统相关常量定义, author : xuebin.ke, date : 2012-11-08
--]]	

NoticeDefs = {
	-- type:公告的类型
	NOTICE_SORT_ID_COMMON 	= 1,	-- 普通广播
	NOTICE_SORT_ID_CHAT		= 2,	-- 发到聊天框的广播
	NOTICE_SORT_ID_ACTIVE   = 3,	-- 活动开启类广播
	NOTICE_SORT_ID_FLOWER 	= 4,	-- 鲜花	
	
	CHAT_TYPE_BEGIN = 100, --聊天频道标记位
	CHAT_TYPE_SECRET   = 101, --私聊
    CHAT_TYPE_TEAM      = 102, --队伍聊天
    CHAT_TYPE_GANG      = 103, --帮会聊天
    CHAT_TYPE_SCENE     = 104, --附近
    CHAT_TYPE_WORLD     = 105, --世界
    CHAT_TYPE_FORBID    = 106, --禁言
    CHAT_TYPE_PIGEON    = 107, --飞鸽

}

-- 需要广播的等级列表
NoticeDefs.need_notice_lvs =  {50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200}
NoticeDefs.need_notice_fcs =  {50000, 100000, 150000, 200000, 250000, 300000, 350000, 400000, 450000, 500000, 550000, 600000, 650000, 700000, 750000, 800000, 850000, 900000, 950000, 1000000, 1050000, 1100000, 1150000, 1200000, 1250000, 1300000, 1350000, 1400000, 1450000, 1500000, 1550000, 1600000, 1650000, 1700000, 1750000, 1800000, 1850000, 1900000, 1950000, 2000000}

-- 是否是需要广播的等级
function NoticeDefs:isNeedNoticeLv(lv)
	return lv >= 50 and lv % 10 == 0, math.floor(lv/10) * 10
end

-- 是否需要广播的战力
function NoticeDefs:isNeedNoticeFc( old_top_fc, new_top_fc )
	if new_top_fc < 50000 then return false end
	if old_top_fc > 2000000 then return false end

	local old_top_fc_lay = math.floor(old_top_fc / 50000)
	local new_top_fc_lay = math.floor(new_top_fc / 50000)
	if old_top_fc_lay ~= new_top_fc_lay then 
		return true, old_top_fc_lay * 50000, new_top_fc_lay * 50000
	else
		return false
	end
end
