--[[
NPC 定义
author : xingzeng
date : 2014-08-18
$Id: $
--]]

NpcDefs = {
	NPC_SORT_ID_NORMAL = 0,			--普通类型
	NPC_SORT_ID_CHARM_ANGEL = 1,	--魅力使者
	NPC_SORT_ID_LOVERS_MARRY = 2,	--结婚使者
	NPC_SORT_ID_LOVERS_DIVORCE = 3,	--离婚使者
	
	NPC_ID_LOVERS_MARRY = 10075,		--结婚使者(神父)
	NPC_ID_LOVERS_DIVORCE = 10076,		--离婚使者
}
