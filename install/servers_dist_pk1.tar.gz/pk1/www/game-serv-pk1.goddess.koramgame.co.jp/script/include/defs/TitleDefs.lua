--------------------------------------------------------------------------------
-- 称号系统定义
-- shuyi.zhong
--------------------------------------------------------------------------------

TitleDefs = {
	
	-- 称号开启
	TITLE_IS_SHOW = 1, -- 显示
	TITLE_IS_HIDE = 0, -- 隐藏
	
	TITLE_IS_ACTIVE = 1, --激活
	

	-- 一个角色最多只能有1个显示的称号
	MAX_SHOW_TITLE_NUM = 1,

	-- 称号类型(同一类型的称号互斥)
	TITLE_SORT_ID_FOR_TARGET = 1,		-- 爵位系统的称号
	TITLE_SORT_ID_FOR_VIP = 2,  		-- VIP类型的称号
	TITLE_SORT_ID_FOR_ARENA = 3,		-- 竞技场
	TITLE_SORT_ID_FOR_GANG_BATTLE = 4,	-- 军团战称号奖励
	TITLE_SORT_ID_FOR_TOPLIST_ZHASHALI = 5, --排行榜（斩杀力）
	TITLE_SORT_ID_FOR_TOPLIST_ZHANLI = 6,	--排行榜（战力）
	TITLE_SORT_ID_FOR_TOPLIST_LEVEL = 7,	--排行榜（等级）
	TITLE_SORT_ID_FOR_TOPLIST_PET = 8,		--排行榜（幻兽）
	TITLE_SORT_ID_FOR_TOPLIST_HORSE = 9,	--排行榜（坐骑）
	TITLE_SORT_ID_FOR_TOPLIST_FLOWER = 10,  --排行榜（送花）
	TITLE_SORT_ID_FOR_TOPLIST_BIAOSHENG = 11,--排行榜（战力飙升）
	TITLE_SORT_ID_FOR_TOPLIST_KILLER = 12,	-- 杀手榜
	TITLE_SORT_ID_FOR_NS_TOPLIST = 13,		-- 女神排行榜
	TITLE_SORT_ID_FOR_FINALWAR = 14,		-- 末日之战称号
	TITLE_SORT_ID_FOR_LOVER = 15,			-- 情侣称号

	
	TITLE_SORT_ID_FOR_NOT_MUTEX = 100,		--非互斥的称号类型（添加此类型称号时，不会把同类型的给删除）

	-- 默认激活的称号位数量
	DAFAULT_ACTIVE_NUM = 1,	

	-- 非VIP最大可激活数量
	MAX_ACTIVE_NUM_FOR_NOT_VIP = 1,

	-- 竞技场称号ID定义
	TITLE_ID_FOR_ARENA_RANK1 = 301,
	TITLE_ID_FOR_ARENA_RANK2 = 302,
	
	-- 军团称号相关
	TITLE_ID_FOR_GANG_BATTLE_GANG_MASTER = 401, --首席团长
	TITLE_ID_FOR_GANG_BATTLE_GANG_MEMBER = 402, --铁血军团 

	TITLE_ID_FOR_ZHANSHALI_TOP1 = 501,	--斩杀力第一名
	TITLE_ID_FOR_ZHANSHALI_TOP2_10 = 502,	--斩杀力二到十名

}

function TitleDefs:isTitleGuoqi( title )
	return title.expire > 0 and os.time() > title.expire 
end