--[[
3V3	系统定义
]]


G3v3Defs = {
	G3V3_SCENE_ID = 80001,	--场景ID

	G3V3_MATCH_TYPE_TEAM = 1,	--队伍类型
	G3V3_MATCH_TYPE_CH 	 = 2,	--个人类型

	G3V3_STATUS_COMMON = 1,		--未匹配
	G3V3_STATUS_MATCHING = 2,	--匹配中
	G3V3_STATUS_FIGHTING = 3,	--战斗中
	G3v3_STATUS_FINISH = 4,		--玩法已结束

	G3V3_CAMP_A = 1,	--阵营A	
	G3V3_CAMP_B = 2,	--阵营B

	G3V3_CAMP_MEMBER_NUM = 3,	--阵营的人数上限
}
