
StarDefs = {
	UPGRADE_NEED_NUM = 3,	-- 每次升级需要的星星数
	PER_STAR_MAX_NUM = 12,  --每个星座星星数
}