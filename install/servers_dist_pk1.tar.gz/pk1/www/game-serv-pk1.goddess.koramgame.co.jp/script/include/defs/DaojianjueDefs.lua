--[[
3V3	系统定义
]]


DaojianjueDefs = {
	STATUS_PREPARE = 0,			-- 准备状态
	STATUS_FIGHT = 1,			-- 战斗状态
	STATUS_FINISH = 2,			-- 完成状态
}
