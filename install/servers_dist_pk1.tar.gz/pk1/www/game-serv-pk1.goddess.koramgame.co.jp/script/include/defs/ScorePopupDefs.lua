--[[
商店评分弹窗 def
author : jianzhu
date : 2016-10-18
--]]

ScorePopupDefs = {

	--应用程序到url的映射
	url_map = {
		--['com.kunlun.smsy.kl'] = 'http://www.kunlun.com/',

		--kr GP
		['com.koramgame.ggplay.hockr'] = 'https://play.google.com/store/apps/details?id=com.koramgame.ggplay.hockr', 
		--kr ios
		['com.koramgame.hockr'] = 'https://itunes.apple.com/kr/app/gadiseu/id1143003200?ls=1&mt=8', 

		--sgp google
		['com.heroesofchaos.koramgame.global'] = 'https://play.google.com/store/apps/details?id=com.heroesofchaos.koramgame.global',
		--sgp ios
		['com.heroesofchaos.global'] = 'https://itunes.apple.com/app/heroes-of-chaos/id1133806729?l=zh&ls=1&mt=8',

		--na google
		['com.heroesofchaos.ggplay.koramgame.na'] = 'https://play.google.com/store/apps/details?id=com.heroesofchaos.ggplay.koramgame.na',
		--na ios
		['com.heroesofchaos.koramgame.na'] = 'https://itunes.apple.com/app/heroes-of-chaos/id1142550537?l=zh&ls=1&mt=8',

		--ru google
		['com.heroesofchaos.ggplay.koramgame.ru'] = 'https://play.google.com/store/apps/details?id=com.heroesofchaos.ggplay.koramgame.ru',
		--ru ios
		['com.heroesofchaos.koramgame.ru'] = 'https://itunes.apple.com/app/heroes-of-chaos-alliance-war/id1143458117?l=zh&ls=1&mt=8',

		--sa google
		['com.heroesofchaos.ggplay.koramgame.sa'] = 'https://play.google.com/store/apps/details?id=com.heroesofchaos.ggplay.koramgame.sa',
		--sa ios
		['com.heroesofchaos.koramgame.sa'] = 'https://itunes.apple.com/app/heroes-chaos-juega-mmorpg/id1151030355?l=zh&ls=1&mt=8',

		--eu google
		['com.heroesofchaos.ggplay.koramgame.eu'] = 'https://play.google.com/store/apps/details?id=com.heroesofchaos.ggplay.koramgame.eu',
		--eu ios
		['com.heroesofchaos.koramgame.eu'] = 'https://itunes.apple.com/app/heroes-of-chaos-war-order/id1149260981?l=zh&ls=1&mt=8',

	}, 

	gifts = {[21011501] = 250000, [21010007]= 6000}, --奖励
	POPUP_OPEN_VALUE = 1, --总开关，功能开关开放的值

	POPUP_CD = 4320 * 60, --冷却CD时间,秒
	POPUP_LEVEL_BEGIN = 10, --开启开始等级
	POPUP_LEVEL_END = 300, --开启结束等级
	POPUP_TIME_BEGIN = '2016-10-19 00:00:00', --主动弹窗开始时间
	POPUP_TIME_END = '2016-10-22 00:00:00', --主动弹窗结束时间

	SCOREPOPUP_OPTIONS_VERY_GOOD = 1, -- 非常好
	SCOREPOPUP_OPTIONS_GOOD = 2, -- 还不错

	SCOREPOPUP_NODE_AUTO_OPEN = 0, -- 主动弹窗
	SCOREPOPUP_NODE_CONI_DOZER = 1, -- 推币机推下宝箱
	SCOREPOPUP_NODE_DAOJJ_TOP = 2, -- 70级前帝国争锋胜利，且排名前三
	SCOREPOPUP_NODE_DAOJJ_BAOXIANG = 3, -- 70级前帝国争锋宝箱开出紫锤子
	SCOREPOPUP_NODE_LINWEI = 4, -- 临危抢红包，抢到100魔石以上
	SCOREPOPUP_NODE_ZUOQI = 5, -- 坐骑升到冰霜马
	SCOREPOPUP_NODE_ZADAN = 6, -- 砸蛋到9、10、11资质的幻兽（含砸金蛋）
	SCOREPOPUP_NODE_JISHA = 7, -- 击杀巨岩魔或拿到队伍归属奖
	SCOREPOPUP_NODE_MOJIE = 8, -- 80级前巨岩魔宝箱开出整件的红魔戒
	SCOREPOPUP_NODE_BOSS_TOP = 9, -- BOSS之家排名第一名或最后一击
	SCOREPOPUP_NODE_BOSS_BAOXIANG = 10, -- boss之家宝箱开出概率最低的物品，即角色装备成品
	SCOREPOPUP_NODE_DASHATESHA = 11, -- 任意玩法中完成大杀特杀或以上级别杀戮
	SCOREPOPUP_NODE_GOLLGATE = 12, -- 关卡星级宝箱开出整件翅膀时
	SCOREPOPUP_NODE_ARENA = 13, -- 竞技场取得30连胜以上
	SCOREPOPUP_NODE_JINSE = 14, -- 95级以前获得金色品阶及以上宝物碎片
	SCOREPOPUP_NODE_FUDAN = 15, -- 孵蛋，孵出金色及以上品阶的精灵时
}

local my_area_id = (external and external.getVouchAid and external.getVouchAid()) or 2078001
local local_url_map = ScorePopupDefs.url_map

if Language:isTestServ() then
	local_url_map['com.kunlun.smsy.kl'] = 'http://www.kunlun.com/'
end
