--[[
商店系统定义
author : guoyin.huang
date : 2015-01-22
$Id: $
--]]


ShopDefs =
{
	SHOP_MONEY_TYPE_BEGIN = 1,	--商店货币类型开始
	SHOP_MONEY_TYPE_GOLD = 1,	--魔石
	SHOP_MONEY_TYPE_JUNGONG = 4,--军功
	SHOP_MONEY_TYPE_HONOUR = 5,	--荣誉
	SHOP_MONEY_TYPE_INVITE_SOCRE = 6,	--推广积分

	SHOP_MONEY_TYPE_END = 6,	--商店货币类型结束

	SHOP_LIMIT_DAY = 1,				--按天限购
	SHOP_LIMIT_NOT = 0,				--不限购

	-- 客户端使用
	SHOP_TYPE_JUNGONG = 1,			-- 军功商店
	SHOP_TYPE_HONOUR_BS = 2,		-- 荣誉宝石商店
	SHOP_TYPE_HONOUR_LS = 3,		-- 荣誉女神商店
	SHOP_TYPE_GOLD = 9,				-- 魔石商店（隐藏）
	SHOP_TYPE_INVITE_SOCRE = 10,				-- 魔石商店（隐藏）

	-- 父商店类型(服务端只使用此类型)
	SHOP_PARENT_TYPE_JUNGONG = 1,	-- 军功商店
	SHOP_PARENT_TYPE_HONOUR  = 2,	-- 荣誉商店
	SHOP_PARENT_TYPE_GOLD 	 = 3, 	-- 魔石商店
	SHOP_PARENT_TYPE_INVITE_SCORE 	 = 4, 	-- 推广商店

	
	-- 允许直购的道具ID列表
	allow_buy_equip_ids = {
		[24010001] = {num=1},	-- [购买的道具ID]=单次可以购买的数量
		[24020001] = {num=1},
		[24030001] = {num=1},
		[24040001] = {num=1},
		[24050001] = {num=1},
		[21010904] = {num=100},
		[21010903] = {num=100},

		-- 副本令
		[21010122] = {num = 1, is_subline = true},
		[21010123] = {num = 1, is_subline = true},
		[21010124] = {num = 1, is_subline = true},
		[21010125] = {num = 1, is_subline = true},
		[21010126] = {num = 1, is_subline = true},
		[21010127] = {num = 1, is_subline = true},
		[21010128] = {num = 1, is_subline = true},
		[21010129] = {num = 1, is_subline = true},
		[21010130] = {num = 1, is_subline = true},
		[21010131] = {num = 1, is_subline = true},
		[21010132] = {num = 1, is_subline = true},
		[21010133] = {num = 1, is_subline = true},
		[21010134] = {num = 1, is_subline = true},
		[21010135] = {num = 1, is_subline = true},
		[21010136] = {num = 1, is_subline = true},
		[21010137] = {num = 1, is_subline = true},
		[21010138] = {num = 1, is_subline = true},
		[21010139] = {num = 1, is_subline = true},
	},
}


