--[[
组队系统定义
author : guoyin.huang
date : 2014-12-19
$Id: $
--]]

TeamDefs =
{
	-------------------- 队伍定义 start ---------------------------
	-----队伍状态
	TEAM_STATUS_IDLE    = 0,		 --空闲状态
	TEAM_STATUS_BUSY 	= 1,         --忙状态

	-----存储机器人的数量
	ROBOT_CACHE_NUM = 20,			--缓存的机器人数量
	
	-----机器人可以再次招募的时间
	ROBOT_REREQ_TIME = 30 * 60,

	-----被踢出后可再次进入的时间
	KICKED_OUT_CAN_REJOIN_TIME = 15,

	-------------------- 队伍定义 end -----------------------------

	-------------------- 与跨服交互定义 [BEG] -----------------------------

	TEAM_TO_PK_TYPE_CREATE 		= 'create',			--创建
	TEAM_TO_PK_TYPE_JOIN   		= 'join',			--加入
	TEAM_TO_PK_TYPE_QUICK_JOIN	= 'quick_join',		--快速加入
	TEAM_TO_PK_TYPE_KICK   		= 'kick',			--踢出
	TEAM_TO_PK_TYPE_QUIT   		= 'quit',			--退出
	TEAM_TO_PK_TYPE_REQ_ROBOT 	= 'req_robot',		--召唤机器人
	TEAM_TO_PK_TYPE_REQ_ROBOT_GM 	= 'req_robot_gm',		--召唤机器人
	TEAM_TO_PK_TYPE_RESET_PASSWD= 'reset_passwd',	--修改密码
	TEAM_TO_PK_TYPE_ENTRY		= 'entry',			--进入玩法
	TEAM_TO_PK_TYPE_REFRESH_ROBOT= 'refresh_robot',	--刷新机器人
	TEAM_TO_PK_TYPE_APPEAR_CHANGE = 'appear',		--外观变化
	
	-------------------- 与跨服交互定义 [END] -----------------------------
}
