-- 客户端UI相关定义

ClientUIDefs =
{
	-- 客户端界面ID定义(客户端使用)
	UI_ID_PET = 1;							--幻兽界面
	UI_ID_EQUIP_STRONG = 2;					--装备强化
	UI_ID_SKILL = 3;						--技能界面
	UI_ID_TRADE = 4;						--交易
}

AsReadOnly(ClientUIDefs)