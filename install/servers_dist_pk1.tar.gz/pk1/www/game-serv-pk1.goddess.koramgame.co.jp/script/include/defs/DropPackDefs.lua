--[[
掉落包定义文件
author : xingzeng
date : 2014-10-16
--]]

DropPackDefs = 
{
	DROP_PACK_PROBA_RADIX = 100000,			-- 掉落包概率基数
	
	DROP_PACK_DROP_DISTANCE = 5,			-- 物品掉落后, 散落的距离
	
	-- 掉落包拥有者类型
	DROP_OWN_TYPE_NONE = 0,		-- 无拥有者
	DROP_OWN_TYPE_SELF = 1,		-- 个人
	DROP_OWN_TYPE_TEAM = 2,		-- 队伍 
	
	DROP_PACK_PICKUP_DIST = 3,				-- 拾取的距离判定
}

AsReadOnly(DropPackDefs)