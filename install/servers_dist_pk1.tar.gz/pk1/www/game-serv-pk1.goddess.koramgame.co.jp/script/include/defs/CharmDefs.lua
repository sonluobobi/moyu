--[[
魅力活动定义
author : jinlin.liu
date : 2016-2-19
--]]

CharmDefs =
{ 
  DEFAULT_CHARM_NUM = 0,
  
  CHARM_GLOBAL_STATUS_NEVER_OPENED = 0, --已关闭
  CHARM_GLOBAL_STATUS_BEGIN_OPEN = 1, --开始前
  CHARM_GLOBAL_STATUS_OPENING = 2, --开启中
  CHARM_GLOBAL_STATUS_OVER = 3, --结束
  CHARM_GLOBAL_STATUS_TMPO_CLOSED = 4, --暂时关闭
  
  CHARM_RECORD_TYPE_GIVE = 1,--送花记录
  CHARM_RECORD_TYPE_RCV = 2,--收花记录
  CHARM_RECORD_TYPE_JOIN_VOICE = 3,--动态:报名
  CHARM_RECORD_TYPE_CHANGE_VOICE = 4,--动态:修改报名语音
  CHARM_RECORD_TYPE_CHARM_VALUE_REACH = 5,--动态:魅力值到达某个值
  CHARM_RECORD_TYPE_RCV_FLOWER = 6,--动态:收到花
  
  CHARM_DT_NUM = 4,--取详细信息时，动态的条数
  
  CHARM_STATUS_JOINED = 2,--已经报名
  CHARM_STATUS_NOT_JOINED = 1,--未报名
  
  CHARM_LOG_CACHE_NUM = 21, --服务端缓存的数目  
  
  CHARM_DT_FLOWER_CONDITION = 99, --99朵玫瑰生成动态
  
  CHARM_DT_CHARM_VALUE = 1000, --1000朵玫瑰动态 
  
}


