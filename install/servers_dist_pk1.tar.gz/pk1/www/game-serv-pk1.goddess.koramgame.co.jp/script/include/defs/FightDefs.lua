FightDefs = 
{
	-- 攻击结果
	ResultTypeHit = 0,		-- 命中
	ResultTypeMiss = 1, 	-- 闪避	
	ResultTypeParry = 2,	-- 格挡
	ResultTypeCrit = 3,		-- 暴击
	ResultTypeCritMianShang = 4, -- 格挡免伤
	
	MAX_FIGHT_CAPACITYS = 					--最强战力
	{
		[10] = { 100,200,300,400,500,600 }, --白装到红装
		[20] = { 100,200,300,400,500,600 }, --白装到红装
		[30] = { 100,200,300,400,500,600 }, --白装到红装
		[40] = { 100,200,300,400,500,600 }, --白装到红装
		[50] = { 100,200,300,400,500,600 }, --白装到红装
		[60] = { 100,200,300,400,500,600 }, --白装到红装		
	},
	
	-- 战斗效果ID
	FIGHT_ERRECT_FANJI = 1,			--反击
	
	-- 战斗类型
	FIGHT_TYPE_ID_PVE = 1,
	FIGHT_TYPE_ID_PVP = 2,
	FIGHT_TYPE_ID_PVPE = 3,
	
	FIGHT_MONSTER_RESPONSE_DELAY_MSEC_MIN = 450, -- 怪物反击玩家的响应延迟时间
	FIGHT_MONSTER_RESPONSE_DELAY_MSEC_MAX = 650,

	-- 是否在服务端触发的战斗引导状态中
	FIGHT_IN_SERVER_GUIDE_SKILL_NO = 0,
	FIGHT_IN_SERVER_GUIDE_SKILL_YES = 1,


	FIGHT_ATTACK_DIST_ERR = 8,			-- 攻击目标容错距离

	UPDATE_FIGHT_RADIX_TYPE_ID_FOR_NONE = 999,	   -- 没有加成
	UPDATE_FIGHT_RADIX_TYPE_ID_FOR_LOVER = 1,	   -- 情侣在线增加伤害
	UPDATE_FIGHT_RADIX_TYPE_ID_FOR_LOVER_TEAM = 2, -- 情侣在线增加伤害(组队)
}
AsReadOnly(FightDefs)

