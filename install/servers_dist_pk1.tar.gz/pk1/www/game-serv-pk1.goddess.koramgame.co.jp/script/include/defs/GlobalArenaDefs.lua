--[[
竞技场 定义
author : xingzeng
date : 2014-08-18
$Id: $
--]]

GlobalArenaDefs = {
	ARENA_MAP_ID = 2,			-- 跨服竞技场必须在MAP2
		
	ARENA_CH_RANK_INIT = 1003,	-- 玩家的初始排名(注：实际初始排名从201开始)
		
	ARENA_CH_DETAIL_UPDATE_INTERVAL = 600,	-- 每10分钟更新一次竞技场属性

	MIAOSHA_NEED_BEYOND_FC_PERC = 0.2,	-- 大于战力50% 则秒杀对手

	RAND_REWARD_BAODI_TIMES = 500,		-- 随机奖励 连续X次没出保底奖励，则必出一次保底奖励
		
	PK_NEED_ENDURANCE = 2,				-- 每次PK需要消耗的耐力

	PK_LOG_NUM = 30,					-- 保留的PK日志条数

	FINAL_WAR_PLAYER_NUM = 200,		-- 可以参加末日之战的玩家数量

	SCORE_RADIUS = 0.1,				-- 积分系数
	SCORE_BASE = 30,				-- 积分计算基数	

	DEL_SCORE_RADIUS = 0.2,			-- 扣分比例

	SCORE_MAX = 50,					-- 最多能获得的积分
	SCORE_MIN = 10,					-- 胜利最多能获得的积分
}



AsReadOnly(GlobalArenaDefs)