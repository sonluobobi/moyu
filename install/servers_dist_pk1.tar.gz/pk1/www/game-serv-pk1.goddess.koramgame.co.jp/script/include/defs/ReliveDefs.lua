--------------------------------------------------------------------------------
-- 复活相关定义
-- shuyi.zhong
--------------------------------------------------------------------------------

ReliveDefs = {
	-- 复活类型
	RELIVE_TYPE_ID_FOR_NORMAL = 1,	-- 普通复活
	RELIVE_TYPE_ID_FOR_LOCAL = 2,	-- 原地复活

	-- 复活场景类型
	RELIVE_SCENE_CURRENT = 0,		-- 本场景
	RELIVE_SCENE_MAINCITY = 1,		-- 主城

	-- 普通复活倒记时间(秒)
	RELIVE_DELAY_SECOND_FIVE = 5,	 -- 5秒复活
	RELIVE_DELAY_SECOND_TWO = 2,	 -- 2秒复活

	-- 复活需要的魔石数量
	RELIVE_NEED_GOLD_NUM = 20,		

	-- 复活时间轮的大小
	RELIVE_TIME_WHEEL_SIZE = 120, 

	-- 快速复活的等级限制
	QUICKLY_RELIVE_LEVEL = 40,	--此等级以下会快速复活
}
