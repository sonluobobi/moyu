--[[
RPC回包类定义
author : yaozhong cen
date : 2012-11-29
$Id: $
--]]

RpcDefs =
{
	--RPC调用的rsp_code_id, 0为成功, 非0为失败
	RPC_RSP_CODE_ID_OK = 0,
	RPC_RSP_CODE_ID_ERR_COMMON = 1,
}

