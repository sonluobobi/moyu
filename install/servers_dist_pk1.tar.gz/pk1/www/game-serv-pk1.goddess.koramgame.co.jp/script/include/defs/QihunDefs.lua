--[[
器魂 系统定义
author : guoyin.huang
date : 2016-01-20

--]]
QihunDefs = {
	QIHUN_WUQI = 1,
	QIHUN_YIFU = 2,
}