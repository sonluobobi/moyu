--
--------------------------------------------------------------------------------
-- 孵蛋相关定义
--author : jinlin.liu
--date : 2016-09-10
--------------------------------------------------------------------------------


MatchEggDefs = {	
    ROOM_CANUSE = 1,     --可使用的孵化室
    ROOM_NOTUSE = 2,     --不可使用的孵化室

	ROOM_STATUS_FREE = 1, --1.空闲 2.放了幻兽还未配对 3.孵化中 4.孵化完成
	ROOM_STATUS_PUTTED = 2,
	ROOM_STATUS_EGGING = 3,
	ROOM_STATUS_EGGINGEND = 4,	
	
	ROOM_ID_VIP_BEGIN = 100,--根据vip开启的孵化室id从100开始
	
	chosed_equipid = 21010500, --初始选择的道具id--普通孵化器
    good_fuhuaqi_equipid = 21010501,   --好的孵化器id
    time_reduce_equipid = 21010502,	
}

