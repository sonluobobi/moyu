BattleDefs = 
{
	BATTLE_SCENE_ID = 20012,  --战场id		类型id 208
	BATTLE_WAIT_TIME = 5,     --倒计时5秒
	BATTLE_FIGHT_TIME = 90,   --战斗时间90秒
	BATTLE_PLAYER_NUM = 2,    --切磋场人数
	
	BATTLE_MATCH_CD = 30,     --自动匹配CD,秒
	
	BATTLE_POS_X = {18,42},      --X坐标 --type:ArrayList
	BATTLE_POS_Y = {42,18},      --Y坐标 --type:ArrayList
	
	BATTLE_STATUS_MATCH_CANCEL =0, --已取消匹配
	BATTLE_STATUS_IS_MATCHING = 1, --正在匹配中
	BATTLE_STATUS_MATCH_FAIL = 2, --匹配失败
	BATTLE_STATUS_MATCH_SUCCESS = 3, --匹配成功
	
}
AsReadOnly(BattleDefs)

