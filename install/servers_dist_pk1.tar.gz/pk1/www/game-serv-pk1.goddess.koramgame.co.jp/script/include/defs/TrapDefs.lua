
TrapDefs = 
{	
	-- 陷阱类型定义
	TRAP_SORT_ID_LOST_HP = 1,		  -- 固定扣血
	TRAP_SORT_ID_LOST_HP_PERCENT = 2, -- 百分比扣血
	TRAP_SORT_ID_SKILL_ID = 3,		  -- 通过技能计算扣血
	TRAP_SORT_ID_ADD_BUFFER = 4,	  -- 触发buffer (主角技能陷阱触发的BUFFER)
	TRAP_SORT_ID_PARENT_LEVEL = 5,	  -- 召唤者等级 * 固定值
	TRAP_SORT_ID_ADD_BUFFER_WANFA = 6,-- 玩法buffer (玩法里面的陷阱触发的BUFFER)


	TRAP_ID_FOR_CHUANRANXIANJIN = 1034, -- 丧尸危机里的传染陷阱，比较特殊，只能作用于玩家，写死
}

AsReadOnly(TrapDefs)
