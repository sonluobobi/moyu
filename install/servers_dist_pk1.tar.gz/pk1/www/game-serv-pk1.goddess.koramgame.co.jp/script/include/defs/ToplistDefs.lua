--[[
排行榜
author : xingzeng
date : 2012-05-24
$Id: $
--]]

local tableInsert = table.insert

ToplistDefs =
{
	-- 单服排行榜分类定义
	TOPLIST_SORT_ID_KILL_FORCE = 1,				-- 角色斩杀力排行榜
	TOPLIST_SORT_ID_CH_FIGHT_CAPACITY = 2,		-- 角色战力排行榜
	TOPLIST_SORT_ID_CH_LEVEL = 3,				-- 角色等级排行榜
	TOPLIST_SORT_ID_PET = 4,					-- 幻兽排行榜
	TOPLIST_SORT_ID_HORSE = 5,					-- 坐骑排行榜
	TOPLIST_SORT_ID_BABEL = 6,					-- 试炼塔排行榜(摩天豆蔓)
	TOPLIST_SORT_ID_TOLLGATE_STAR = 7,			-- 关卡星数排行榜
	TOPLIST_SORT_ID_FC_BIAOSHEN = 8,			-- 战力飙升榜
	TOPLIST_SORT_ID_GIVE_FLOWER = 9,			-- 送花榜
	TOPLIST_SORT_ID_KILL_PLAYER = 10,			-- 杀人榜
	TOPLIST_SORT_ID_GANG_BENFU = 11,			-- 本服军团排行榜
	TOPLIST_SORT_ID_NVSHENG = 12,				-- 女神排行榜
	TOPLIST_SORT_ID_HORSE_SPEED_SCORE = 13,		-- 坐骑速度积分排行榜
	
	TOPLIST_SORT_ID_VOUCHER = 30,				-- 翅膀充值排行榜(充值活动,由运营活动系统生成排行榜)
	TOPLIST_SORT_ID_VOUCHER_SHENBING = 31,		-- 神兵充值排行榜(充值活动,由运营活动系统生成排行榜)
	TOPLIST_SORT_ID_GOLD_EGG = 32,				-- 限时砸金蛋排行榜(消费活动，由运营活动系统生成排行榜)
	TOPLIST_SORT_ID_CONSUME = 33,				-- 消费排行榜(消费活动，由运营活动系统生成排行榜)
	TOPLIST_SORT_ID_RED_GODD = 34,				-- 红女神排行榜(消费活动，由运营活动系统生成排行榜)
	
	TOPLIST_SORT_ID_GANG_BENFU = 50,			-- 军团战服内的排行
	TOPLIST_SORT_ID_GANG_BENFU_FC = 51,			-- 军团战力排行
	
	-- 跨服排行榜
	TOPLIST_SORT_ID_ZHUSHEN_HUANGHUN = 101,		-- 诸神黄昏
	
	TOPLIST_NUM_FC_DB = 1000,					-- 战力排行榜DB里面保存的排行榜人数
	TOPLIST_NUM_FC_DB_MAX_FETCH = 1800,			-- 战力排行榜可取出最多人数
	
	-- 跨服战排行榜定义
	--
	
	-- 属于跨服排行榜的分类
	globalpk_toplist_sort_ids = {},

	-- 属于单服排行榜的分类
	toplist_sort_ids = {},

	-- 排行榜人数限制
	toplist_num_conf = {},	--type:Hashtable
	
	-- 诸神排行榜人数
	toplist_zhushen_num = 200,

	-- 排行榜对应的名称
	toplist_names = {},
	
	-- 排行榜生成时间表
	toplist_gen_time_list = {},
	
	-- 不在通用排行榜界面显示的排行榜类型
	toplist_common_ui_noshow = nil,
}

-- 不发奖的排行榜
ToplistDefs.toplist_no_reward_conf = {
	[ToplistDefs.TOPLIST_SORT_ID_BABEL] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_TOLLGATE_STAR] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_VOUCHER] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_GIVE_FLOWER] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_GANG_BENFU] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_HORSE_SPEED_SCORE] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_VOUCHER_SHENBING] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_GOLD_EGG] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_RED_GODD] = 1,
}

-- 单服排行榜人数限制
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_CH_FIGHT_CAPACITY] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_KILL_FORCE] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_CH_LEVEL] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_PET] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_HORSE] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_BABEL] = 50
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_TOLLGATE_STAR] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_FC_BIAOSHEN] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_GIVE_FLOWER] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_KILL_PLAYER] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_GANG_BENFU] = 30
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_NVSHENG] = 100
ToplistDefs.toplist_num_conf[ToplistDefs.TOPLIST_SORT_ID_HORSE_SPEED_SCORE] = 100

-- 不在通用排行榜界面显示的排行榜类型
ToplistDefs.toplist_common_ui_noshow = {
	[ToplistDefs.TOPLIST_SORT_ID_BABEL] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_TOLLGATE_STAR] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_VOUCHER] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_GIVE_FLOWER] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_GANG_BENFU] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_HORSE_SPEED_SCORE] = 1,
	[ToplistDefs.TOPLIST_SORT_ID_VOUCHER_SHENBING] = 1,
}

-- 单服排行榜分类ID数组
ToplistDefs.toplist_sort_ids =
{
	[ToplistDefs.TOPLIST_SORT_ID_KILL_FORCE]=true,
	[ToplistDefs.TOPLIST_SORT_ID_CH_FIGHT_CAPACITY]=true,
	[ToplistDefs.TOPLIST_SORT_ID_CH_LEVEL]=true,
	[ToplistDefs.TOPLIST_SORT_ID_PET]=true,
	[ToplistDefs.TOPLIST_SORT_ID_HORSE]=true,
	[ToplistDefs.TOPLIST_SORT_ID_BABEL]=true,
	[ToplistDefs.TOPLIST_SORT_ID_TOLLGATE_STAR]=true,
	[ToplistDefs.TOPLIST_SORT_ID_FC_BIAOSHEN]=true,
	[ToplistDefs.TOPLIST_SORT_ID_GIVE_FLOWER]=true,
	[ToplistDefs.TOPLIST_SORT_ID_KILL_PLAYER]=true,
	[ToplistDefs.TOPLIST_SORT_ID_NVSHENG]=true,
	[ToplistDefs.TOPLIST_SORT_ID_HORSE_SPEED_SCORE]=true,
}
-- 检查单服TOPLIST类型合法性
function ToplistDefs:validToplistSortId(sort_id)
	local is_ok = ToplistDefs.toplist_sort_ids[sort_id] and true or false
	return is_ok
end

-- 跨服排行榜分类ID数组
ToplistDefs.globalpk_toplist_sort_ids =
{
	
}

-- 排行榜对应的名称
ToplistDefs.toplist_names = {
	
}

-- 排行榜生成时间表
ToplistDefs.toplist_gen_time_list = {
	[ToplistDefs.TOPLIST_SORT_ID_CH_FIGHT_CAPACITY] = 60,	-- 每整点过X秒生成排行榜
	[ToplistDefs.TOPLIST_SORT_ID_PET] = 120,				-- 每整点过X秒生成排行榜
	[ToplistDefs.TOPLIST_SORT_ID_HORSE] = 180,				-- 每整点过X秒生成排行榜
	[ToplistDefs.TOPLIST_SORT_ID_BABEL] = 240,				-- 每整点过X秒生成排行榜
	[ToplistDefs.TOPLIST_SORT_ID_TOLLGATE_STAR] = 300,		-- 每整点过X秒生成排行榜
	[ToplistDefs.TOPLIST_SORT_ID_FC_BIAOSHEN] = 360,		-- 每整点过X秒生成排行榜
	[ToplistDefs.TOPLIST_SORT_ID_GIVE_FLOWER] = 420,
	[ToplistDefs.TOPLIST_SORT_ID_NVSHENG] = 480,
	[ToplistDefs.TOPLIST_SORT_ID_HORSE_SPEED_SCORE] = 540,
	[ToplistDefs.TOPLIST_SORT_ID_KILL_FORCE] = 600,			-- 每整点过X秒生成排行榜
	[ToplistDefs.TOPLIST_SORT_ID_CH_LEVEL] = 660,			-- 每整点过X秒生成排行榜
	[ToplistDefs.TOPLIST_SORT_ID_KILL_PLAYER] = 720,		-- 每整点过X秒生成排行榜
}

