
SkillDefs = 
{	
	--角色创建时的技能战力(初始技能变动时，需要修改)
	CH_DEFAULT_SKILL_FIGHT_FC = 60,	

	-- 技能父类型定义
	PARENT_SORT_ID_INITIATIVE = 0,	--主动技能
	PARENT_SORT_ID_PASSIVE = 1,		--被动技能
	PARENT_SORT_ID_AUTO    = 2,		--自动技能
	
	-- 技能所属职业
	SKILL_PROF_XUEZU 	 = 1, --血族
	SKILL_PROF_WANGLIN   = 2, --亡灵
	SKILL_PROF_ZHANSHI   = 3, --战士
	
	-- 技能派系
	SKILL_PROF_FACTION_WULI = 1,	--物理系
	SKILL_PROF_FACTION_FASHU = 2,	--法术系
	
	-- 技能类型定义
	SORT_ID_INIT = 0,		--初始技能
	SORT_ID_BASE = 1,		--普通技能
	SORT_ID_SUPER = 2,		--高级技能
	SORT_ID_SHENBING = 3,	--神兵技能
	
	-- 技能效果类型
	EFFECT_SORT_ID_NORMAL = 0,		--普通类
	EFFECT_SORT_ID_RESTORE = 1,		--回复类技能
	EFFECT_SORT_ID_RELIVE = 2,		--复活类技能
	EFFECT_SORT_ID_CONJURE = 3,		--召唤类技能
	EFFECT_SORT_ID_BUFFER = 4,		--仅增加buffer类
	EFFECT_SORT_ID_SPECIAL = 5,		--特殊技能类型(例如杀死傀儡，然后根据杀死的傀儡数来增加一个buff等)
	EFFECT_SORT_ID_DODGE = 6,		--脱离连击锁定技能

	-- 特殊技能类型的子类型(add by suwin at 2015-05-05)
	-- 用于上面的 EFFECT_SORT_ID_SPECIAL = 5 情况的
	SPECIAL_SORT_ID_FOR_DEL_MONSTER_HP_ADD_BUFF = 1,  -- SkillDetail.spec_params 字段格式 : {special_sort_id = 1, monster_base_id = 0, hp_percent = 0, add_buffer_id = 0} 
	SPECIAL_SORT_ID_FOR_ADD_TRAP_ROUND_ME = 2,		  -- SkillDetail.spec_params 字段格式 : {special_sort_id = 2, trap_id = 0, num = 0, angle = 0} 
	
	-- 技能载体
	OWNER_TYPER_PLAYER = 1,		--玩家技能
	OWNER_TYPER_MONSTER = 2,	--怪物技能
	OWNER_TYPER_PET = 3,		--幻兽技能
	OWNER_TYPER_BEAST = 4,		--召唤兽技能
	
	-- 技能/buffer效果作用目标
	SKILL_TARGET_ID_NONE	= 0,			-- 无目标
	SKILL_TARGET_ID_SELF	= 1,			-- 自身
	SKILL_TARGET_ID_MASTER  = 2,			-- 我的主人
	SKILL_TARGET_ID_ENEMY	= 3,			-- 敌方(不同阵营)
	SKILL_TARGET_ID_FRIEND	= 4,			-- 友方(同阵营)
	SKILL_TARGET_ID_MASTER_PET	= 5,		-- 我的出战侠客和侠客主人
	
	
	-- 技能影响类型
	AREA_TYPE_ID_SINGLE = 0,				--单点(单攻：选取需有目标)
	AREA_TYPE_ID_SELF_CIRCLE = 1,			--自己为圆心的周围
	AREA_TYPE_ID_DEST_CIRCLE = 2,			--目标为圆心的周围
	AREA_TYPE_ID_SPRINT_RECT_CIRCLE = 3,	--冲刺 路上矩形 加 目标点圆形
	AREA_TYPE_ID_SPRINT_RECT = 4,			--冲刺 路上矩形
	AREA_TYPE_ID_FRONT_RECT = 5,			--前方矩形
	AREA_TYPE_ID_FORWARD_DEST_POS = 6,		--前方目标点
	AREA_TYPE_ID_CROSS = 7,					--前方十字形(按长宽取值，两个矩形，相同中心点，相互垂直)
	
	SKILL_SLOT_POS_COUNT = 5,				--技能槽位置个数
	
	-- 技能触发时 施法对象的移动类型,对应move_type
	MOVE_TYPE_NORMAL = 0,					--正常移动
	MOVE_TYPE_SPRINT = 1,					--冲刺
	MOVE_TYPE_SHANYI = 2,					--闪移(没有这个类型，只是没有删除掉)
	MOVE_TYPE_JUMP = 3,						--跳跃
	MOVE_TYPE_CHONGZHUANG = 4,				--冲撞
	MOVE_TYPE_XUANFEN = 5,					--旋风(没有这个类型，只是没有删除掉)
	
	-- 攻击方声效类型（客户端使用）
	ATTACKER_SOUND_TYPE_RUIQI = 1,		--锐器
	ATTACKER_SOUND_TYPE_DUNQI = 2,		--钝器
	ATTACKER_SOUND_TYPE_DIANFASHI = 3,	--电法师
	ATTACKER_SOUND_TYPE_HUOFASHU = 4,	--火法术
	ATTACKER_SOUND_TYPE_BINFASHU = 5,	--冰法术

	-- 放置陷阱和召唤时，放置的位置类型
	PLACE_TYPE_SELF = 0,						--放置在自己所在的位置
	PLACE_TYPE_TARGET = 1,					--放置在目标所在的位置

	-- 技能id(add by suwin zhong at 2015-05-18)
	SKILL_ID_FOR_MINGGUOWUNV = 11401,		-- 法师，冥国巫女技能(用于技能免疫写死)
	SKILL_ID_FOR_ZHANSHICHONGFENG = 10304,  -- 战士，冲锋技能(用于技能免疫写死)

	-- 丧尸危机(add by suwin zhong at 2016-10-20)
	-- SKILL_ID_FOR_KONGQICHUANGRAN = 13007,   -- 空气传染
	SKILL_ID_FOR_KONGQICHUANGRAN = 99999999,   -- 空气传染(取消该技能)
	SKILL_ID_FOR_YIZHIJI = 13009,			-- 抑制剂
}

AsReadOnly(SkillDefs)
