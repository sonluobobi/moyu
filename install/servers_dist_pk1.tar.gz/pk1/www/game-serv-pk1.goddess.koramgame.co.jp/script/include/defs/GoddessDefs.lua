--[[
女神	系统定义
]]


GoddessDefs = {
	GODDESS_MAX_LEVEL = 50,	--女神讨好等级上限

	-- 女神信仰对应的单位ID(必须从1开始)
	BELIEVE_IN_START 	= 1,
	BELIEVE_IN_CH 		= 1,	--角色
	BELIEVE_IN_F_PET 	= 2,	--出战幻兽
	BELIEVE_IN_N_PET 	= 3,	--合体内幻兽
	BELIEVE_IN_W_PET 	= 4,	--合体外幻兽
	BELIEVE_IN_END 		= 4,	

	DEFAULT_GODDESS_CAPACITY = 50,	--默认女神位数量
	DEFAULT_TEMPLE_CAPACITY  = 99,	--默认神殿数量

	MAX_GODDESS_CAPACITY = 150,		--最大女神位数量
	MAX_TEMPLE_CAPACITY = 99,		--最大神殿位数量

	GODDESS_QUALITY_ID_BEG = 3,
	GODDESS_QUALITY_ID_PURPLE = 3,			--紫色
	GODDESS_QUALITY_ID_GOLD = 4,			--金色
	GODDESS_QUALITY_ID_RED = 5,				--红色
	GODDESS_QUALITY_ID_END = 5,
}	


if AsReadOnly then
	AsReadOnly(GoddessDefs)
end