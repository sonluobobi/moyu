-- 
--------------------------------------------------------------------------------
-- 军团定义
--author : fuqian.liao
--date : 2014-10-28
--
--------------------------------------------------------------------------------
--


GangDefs = {
	--------------------军团系统相关常量 start-------------------
	LEVEL_MAX = 200, --军团等级上限
	SILVER_NEED_FOR_CREATE = 200000,					--创建军团所需银两
	MAX_MEMBER = 30,									--默认的军团最大成员数
		
		
	--军团人数上限定义
	VIP_GANG_INIT_LEVEL              = 5, --VIP军团初始等级
	VIP_GANG_FOLLOWER_MAX          = 5, --VIP军团随从人数上限
	VIP_GANG_DEPUTY_MASTER_MAX = 2, --VIP军团副团长人数上限
	
	GANG_INIT_LEVEL              = 1, --普通军团初始等级
	GANG_FOLLOWER_MAX          = 3 , --普通军团随从人数上限
	GANG_DEPUTY_MASTER_MAX = 1, --普通军团副团长人数上限
	
	----------------军团职位定义 start ------------------------------
	
	JOB_NON_MEMBER	= 0,	--非军团成员
	JOB_MEMBER		= 1,	--军团成员职位
	JOB_FOLLOWER	= 2,	--军团亲信职位
	JOB_DEPUTY_MASTER = 3,	--副军团长职位
	JOB_MASTER		   = 4,	--军团长职位
		
	----------------军团职位定义 end-----------------------------------------------------
	
	
	---军团操作类型定义
	ACTION_TYPE_CANCEL_APPLY = 1, --撤销申请
	ACTION_TYPE_ACCEPT_APPLY = 2, --接受申请
	ACTION_TYPE_KICT_OUT         = 3,--踢出军团
	ACTION_TYPE_ADD_NOTICE     = 4,--添加公告
	ACTION_TYPE_OPPOINT_JOB   = 5,--任命职位
	ACTION_TYPE_UPGRADE_LEVEL       = 6, --升级
	ACTION_TYPE_UPGRADE_VIP           = 7, --升级为VIP军团
	ACTION_TYPE_DONATE                     = 8, --捐献
	ACTION_TYPE_MODIFY_DIRECT_JOIN                     = 9, --修改军团信息
	ACTION_TYPE_CHANGE_BADGE   = 10, --更换军团徽章
	ACTION_TYPE_TITLE_RENAME   = 11, --军团改名
	
	SYNC_GANG_FIGHT_CAPACITY = 60 * 60,  --1小时同步更新军团总战力
	MAX_APPLY_NUM = 3,					--最多申请军团个数
	MAX_GANG_APPLY_NUM = 100, 			--军团可接收申请记录数
	APPLY_EXPIRED_SEC = 86400,			--申请过期时间, 24小时(单位:秒)
	JOIN_GANG_CD_SEC = 1*60*60,		       --12*60*60	高等级玩家入帮CD时间, 12小时(单位:秒)
	JOIN_GANG_CD_TIME = 1,
	REPLACE_MASTER_CD_TIME =3*24*60*60,		--  3*24*60*60团长多长时间登录便可以申请继任帮主的时间
	REPLACE_MASTER_APPLY_EXPIRE = 12*60*60,	-- 12*60*60 继任帮主申请过期时间
		
	--------------------军团系统相关常量 end---------------------
		
	 --军团类别定义
	 GANG_TYPE_NORMAL = 0, --普通军团
	 GANG_TYPE_VIP       = 1, --vip军团
	 
	 SAVE_DATA_TYPE_GANG     = 0,
	 SAVE_DATA_TYPE_MEMBER = 1,
	 
	 BUILT_TYPE_FOR_GANG         = 0,
	 BUILT_TYPE_FOR_MEMBER     = 1,
	 
	 GANG_STATUS_VALID     = 1,
	 GANG_STATUS_INVALID = 0,
	 
	 --加入VIP军团的前30名成员可获得VIP礼包
	 VIP_REWARD_LIMIT = 30, --30
	 
	 --VIP奖励包
	 vip_gang_reward =  {
		[21010115] = 1,
		[21011102] = 1,
		[21010122] = 1,
		[21011501] = 10000,
	 },
	 
	 --军团数据更新间隔(秒)
	 GANG_SAVE_TO_DB_INTERVAL_SECOND = 2,
	 
	 --军团排名更新时间间隔(1小时)
	 RANK_REFRESH_INTERVAL = 3600,
	 
	gang_type_config = {}, 
	
	upgrade_exp = {}, --军团升级经验
	
	action_power_config = {},--操作权限配置
	
	gang_job_2_title = {},
	
	--军团捐献类型定义
	DONATE_TYPE_EQUIP = 0, --捐献道具
	DONATE_TYPE_GOLD   = 1, --捐献魔石
	
	--vip等级对应捐献经验（每份魔石）
	vip_2_donate_GangExp = {10,10,10,10,10,10,10,10,10,10,10,10,10},-- type:List<int>
	
	GOLD_NUM_PER_CONTRIBUTE     = 10, --魔石捐献1份=10魔石
	
	DONATE_EQUIP_PER_DAY_MAX = 9000, --每天最大捐献道具/狼图腾数量
	
	---UPGRADE_VIP_EXP_REWARD = 100000, --升级为VIP军团的经验奖励
	
	--闪避格挡暴击=6*LV
	--幸运斗志=3*LV
	--生命=90*LV
	--最小物攻最小魔攻=2*LV
	--最大物攻最大魔攻=4*LV
	--物理防御魔防=3*LV
	
	--军团科技效果系数
	skill_effect_ratio = 
	{
		dodge=6,
		parry=6,
		critical_hit=6,
		luck=3,
		douzhi=3,
		max_hp=90,
		min_attack=2,
		max_attack=4,
		defence_phy=3,
		defence_magic=3,
	}, 
	
	--职位科技加成系数
	skill_job_effect_ratio = {},
	
	--军团科技效果每升一级的增量
	skill_upgrade_increment = 50,
	
	SKILL_LEVEL_MAX = 200, --军团科技等级上限
	
	SKILL_UPGRADE_RATIO = 1000, --军团科技升级系数
	
	SKILL_OPEN_LEVEL=10,---军团等级30级之后才可以开启军团科技

	GANG_DONATE_DOLD_TYPE_PRIMARY = 1, --军团捐献魔石初级
	GANG_DONATE_DOLD_TYPE_MIDDLE = 2, --军团捐献魔石中级
	GANG_DONATE_DOLD_TYPE_HIGH = 3, --军团捐献魔石高级

	gang_donate_counter = {}, --军团捐献分档计数器
	gang_donate_vip_func_id = {}, --军团捐献分档vip func_id定义

	gang_badge_for_rand = {1,2,3,4,5,6,7,8,9,10,11,12}, --军团徽章随机获取列表

	GANG_DEFAULT_BADGE_ID = 7, --默认军团徽章
}

--科技职位加成
GangDefs.skill_job_effect_ratio = 
{
	0,0.1,0.2,0.3,
}
--GangDefs.skill_job_effect_ratio = table.values(GangDefs.skill_job_effect_ratio)

--职位ID->职位名称
GangDefs.gang_job_2_title = 
{
	[GangDefs.JOB_MEMBER]               = Language:getText('GANG_JOB_MEMBER'),
	[GangDefs.JOB_FOLLOWER]           = Language:getText('GANG_JOB_FOLLOWER'),
	[GangDefs.JOB_DEPUTY_MASTER] = Language:getText('GANG_JOB_DEPUTY_MASTER'),
	[GangDefs.JOB_MASTER]               = Language:getText('GANG_JOB_MASTER'),

}

GangDefs.gang_type_config = 
{
	--普通军团
	[GangDefs.GANG_TYPE_NORMAL] = 
	{
		init_level = 1, --初始等级
		[GangDefs.JOB_DEPUTY_MASTER] = 1, --副团长人数
		[GangDefs.JOB_FOLLOWER] = 3, --亲信人数3
	},
	
	--VIP军团
	[GangDefs.GANG_TYPE_VIP] = 
	{
		init_level = 5,
		[GangDefs.JOB_DEPUTY_MASTER] = 2, --副团长人数
		[GangDefs.JOB_FOLLOWER] = 5, --亲信人数5
	},
}

--职位对应权限配置
GangDefs.action_power_config = 
{
	--团员
	[GangDefs.JOB_MEMBER] = 
	{
		[GangDefs.ACTION_TYPE_ACCEPT_APPLY] = false,
		[GangDefs.ACTION_TYPE_CANCEL_APPLY] = false,
		[GangDefs.ACTION_TYPE_KICT_OUT]         = false,
		[GangDefs.ACTION_TYPE_ADD_NOTICE]     = false,
		[GangDefs.ACTION_TYPE_OPPOINT_JOB]   = false,
		[GangDefs.ACTION_TYPE_MODIFY_DIRECT_JOIN]   = false,
		[GangDefs.ACTION_TYPE_CHANGE_BADGE] = false,
		[GangDefs.ACTION_TYPE_TITLE_RENAME] = false,
	},
	
	--亲信
	[GangDefs.JOB_FOLLOWER] = 
	{
		[GangDefs.ACTION_TYPE_ACCEPT_APPLY] = true,
		[GangDefs.ACTION_TYPE_CANCEL_APPLY] = true,
		[GangDefs.ACTION_TYPE_KICT_OUT]         = false,
		[GangDefs.ACTION_TYPE_ADD_NOTICE]     = false,
		[GangDefs.ACTION_TYPE_OPPOINT_JOB]   = false,
		[GangDefs.ACTION_TYPE_MODIFY_DIRECT_JOIN]   = true,
		[GangDefs.ACTION_TYPE_CHANGE_BADGE] = false,
		[GangDefs.ACTION_TYPE_TITLE_RENAME] = false,
	},
	
	--副团长
	[GangDefs.JOB_DEPUTY_MASTER] = 
	{
		[GangDefs.ACTION_TYPE_ACCEPT_APPLY] = true,
		[GangDefs.ACTION_TYPE_CANCEL_APPLY] = true,
		[GangDefs.ACTION_TYPE_KICT_OUT]         = true,
		[GangDefs.ACTION_TYPE_ADD_NOTICE]     = true,
		[GangDefs.ACTION_TYPE_OPPOINT_JOB]   = false,
		[GangDefs.ACTION_TYPE_MODIFY_DIRECT_JOIN]   = true,
		[GangDefs.ACTION_TYPE_CHANGE_BADGE] = false,
		[GangDefs.ACTION_TYPE_TITLE_RENAME] = false,
	},
	
	--团长
	[GangDefs.JOB_MASTER] = 
	{
		[GangDefs.ACTION_TYPE_ACCEPT_APPLY] = true,
		[GangDefs.ACTION_TYPE_CANCEL_APPLY] = true,
		[GangDefs.ACTION_TYPE_KICT_OUT]         = true,
		[GangDefs.ACTION_TYPE_ADD_NOTICE]     = true,
		[GangDefs.ACTION_TYPE_OPPOINT_JOB]   = true,
		[GangDefs.ACTION_TYPE_MODIFY_DIRECT_JOIN]   = true,
		[GangDefs.ACTION_TYPE_CHANGE_BADGE] = true,
		[GangDefs.ACTION_TYPE_TITLE_RENAME] = true,
	},
	
}

--军团捐献档次对应计数器
GangDefs.gang_donate_counter = 
{
	[GangDefs.GANG_DONATE_DOLD_TYPE_PRIMARY] = 35,
	[GangDefs.GANG_DONATE_DOLD_TYPE_MIDDLE] = 36,
	[GangDefs.GANG_DONATE_DOLD_TYPE_HIGH] = 37,
}

--军团捐献档次对应vip func_id定义
GangDefs.gang_donate_vip_func_id = 
{
	[GangDefs.GANG_DONATE_DOLD_TYPE_PRIMARY] = 9,
	[GangDefs.GANG_DONATE_DOLD_TYPE_MIDDLE] = 18,
	[GangDefs.GANG_DONATE_DOLD_TYPE_HIGH] = 19,
}

--获取军团科技升级所需金钱
function GangDefs:getSkillUpgradeSilver(skill_level)
	return  (math.floor(skill_level/10.01)*3000 + 10000) * 2.5
end

--获取军团科技效果
function GangDefs:getSkillBaseEffect(effect_type,skill_level)
	return self.skill_effect_ratio[effect_type] * skill_level
end

--获取军团科技职位加成效果
function GangDefs:getSkillJobEffect(effect_type,skill_level,gang_job)
	return math.ceil(self.skill_effect_ratio[effect_type] * skill_level*self.skill_job_effect_ratio[gang_job])
end

--是否有操作权限
function GangDefs:isOwnPower(gang_job,action)
	local power = false
	if self.action_power_config[gang_job] then
		if self.action_power_config[gang_job][action] and self.action_power_config[gang_job][action] == true then
			power = true
		end
	end
	return power
end

--获取军团升到下一级所需经验
function GangDefs:getUpgradeExp(k)
	return math.floor(3*math.pow(k,2) + k*10 + 1968)
end

--获取普通军团升级为vip军团的经验奖励
function GangDefs:getVipGangExpReward()
    local exp=0
	for k=GangDefs.GANG_INIT_LEVEL+1 , 0+GangDefs.VIP_GANG_INIT_LEVEL do
	   exp=exp+GangDefs:getUpgradeExp(k)
	end
	return exp
end

--随机获取军团徽章id
function GangDefs:getRandBadge()
	return GangDefs.GANG_DEFAULT_BADGE_ID
	--return math.randomIndex(GangDefs.gang_badge_for_rand)
end