	--[[
道具、装备系统定义
author : xingzeng
date : 2014-08-14
--]]

local type = type
local floor = math.floor
local strSub = string.sub

EquipDefs =
{
	-- equip最基类定义
	EQUIP_BASE_SORT_ID_ZHBEI = 1,				-- 装备
	EQUIP_BASE_SORT_ID_DAOJU = 2,				-- 道具
	EQUIP_BASE_SORT_ID_SPIRIT = 3,				-- 精灵
	
	-- equip大类定义
	EQUIP_PARENT_SORT_ID_ZHUANGBEI = 10,		-- 装备大类
	EQUIP_PARENT_SORT_ID_FUNCTION = 21,			-- 功能道具大类
	EQUIP_PARENT_SORT_ID_TASK = 22,				-- 任务道具大类
	EQUIP_PARENT_SORT_ID_CHIP = 23,				-- 角色装备碎片大类
	EQUIP_PARENT_SORT_ID_JEWEL = 24,			-- 宝石大类
	EQUIP_PARENT_SORT_ID_BAOWU_CHIP = 25,		-- 幻兽宝物碎片大类
	EQUIP_PARENT_SORT_ID_PET_CHIP     = 26,		-- 幻兽碎片大类
	EQUIP_PARENT_SORT_ID_NS_CHIP 	= 27,		-- 女神碎片大类
	EQUIP_PARENT_SORT_ID_WING_CHIP 	= 28,		-- 翅膀碎片大类
	EQUIP_PARENT_SORT_ID_EQUIP_CHIP = 29,		-- 普通道具碎片大类
	EQUIP_PARENT_SORT_ID_SPIRIT = 30,			-- 精灵大类
	EQUIP_PARENT_SORT_ID_SPRIT_CHIP = 31,		-- 精灵碎片大类
	
	EQUIP_PARENT_SORT_ID_VIRTUAL     = 89,		-- 虚拟道具大类
	
	-------------------- 道具类型相关定义 start -----------------------
	EQUIP_SORT_ID_WUQI = 1001,					-- 武器
	EQUIP_SORT_ID_XIANGLIAN = 1002,				-- 项链
	EQUIP_SORT_ID_SHOUZHUO = 1003,				-- 手镯
	EQUIP_SORT_ID_JIEZHI = 1004,				-- 戒指
	EQUIP_SORT_ID_WUSHOU = 1005,				-- 护手、手套
	EQUIP_SORT_ID_TOUSHI = 1006,				-- 头饰
	EQUIP_SORT_ID_YIFU = 1007,					-- 衣服
	EQUIP_SORT_ID_YAODAI = 1008,				-- 腰带
	EQUIP_SORT_ID_HUTUI = 1009,					-- 护腿
	EQUIP_SORT_ID_XIEZI = 1010,					-- 鞋子
	EQUIP_SORT_ID_QINGLV = 1011,				-- 情侣婚戒
	EQUIP_SORT_ID_WING = 1012,					-- 翅膀
	EQUIP_SORT_ID_AVATAR = 1013,				-- 时装
	EQUIP_SORT_ID_MAGIC_RING = 1014,			-- 魔戒
	EQUIP_SORT_ID_SHENBING = 1015,				-- 神兵
	
	-- 时装子类型
	EQUIP_SUB_SORT_ID_LOVERS = 101301,			--情侣婚纱时装
	
	EQUIP_SORT_ID_HORSE1 = 1020,				-- 坐骑装备1
	EQUIP_SORT_ID_HORSE2 = 1021,				-- 坐骑装备2
	EQUIP_SORT_ID_HORSE3 = 1022,				-- 坐骑装备3
	EQUIP_SORT_ID_HORSE4 = 1023,				-- 坐骑装备4
	
	EQUIP_SORT_ID_PLAYER_BEGIN = 1001,
	EQUIP_SORT_ID_PLAYER_END = 1023,	
	EQUIP_SORT_ID_HORSE_BEGIN = 1020,
	EQUIP_SORT_ID_HORSE_END = 1023,
	EQUIP_SORT_ID_PLAYER_MAIN_BEGIN = 1001,		--玩家主装备起始类型ID
	EQUIP_SORT_ID_PLAYER_MAIN_END = 1010,		--玩家主装备结束的类型ID
	EQUIP_SORT_ID_PLAYER_EN_EATED_BEGIN = 1001,	--可以被幻兽吞噬的装备起始类型ID
	EQUIP_SORT_ID_PLAYER_EN_EATED_END = 1010,	--可以被幻兽吞噬的装备结束类型ID
	
	EQUIP_SORT_ID_BAOWU_EXP = 1030,						--经验宝物	
	EQUIP_SORT_ID_BAOWU_BEGIN = 1031,
	EQUIP_SORT_ID_BAOWU_WUQI = 1031,					--宝物核心(武器)
	EQUIP_SORT_ID_BAOWU_KAIJIA = 1032,					--宝物魂玉(铠甲)
	EQUIP_SORT_ID_BAOWU_HUDUN = 1033,					--宝物源灵(护盾)
	EQUIP_SORT_ID_BAOWU_ZHANXUE = 1034,					--宝物结晶(战靴)
	EQUIP_SORT_ID_BAOWU_HUSHENGFU = 1035,				--宝物法器
	EQUIP_SORT_ID_BAOWU_SHOUTAO = 1036,					--宝物圣物
	EQUIP_SORT_ID_BAOWU_END = 1036,	
	
	EQUIP_SORT_ID_TSTAR_START = 1050,
	EQUIP_SORT_ID_TSTAR_MAIN = 1050,			-- 幻兽双星装备 主星
	EQUIP_SORT_ID_TSTAR_SECOND = 1051,			-- 幻兽双星装备 傍星
	EQUIP_SORT_ID_TSTAR_END = 1069,
	
	EQUIP_SORT_ID_FUNCTION = 2101,				-- 功能道具
	EQUIP_SORT_ID_WING_EXP = 2102,				-- 翅膀经验
	EQUIP_SORT_ID_TIME_LIMIT_BAOXIANG = 2103, 	-- 限时宝箱
	EQUIP_SORT_ID_VIRTUAL  = 8900,				-- 虚拟道具
	EQUIP_SORT_ID_VIRTUAL_BW  = 8901,			-- 宝物虚拟道具
	EQUIP_SORT_ID_TASK_NORMAL = 2201,			-- 任务道具
	
	EQUIP_SORT_ID_CHIP_WUQI = 2301,					-- 碎片武器碎片
	EQUIP_SORT_ID_CHIP_XIANGLIAN = 2302,			-- 项链碎片
	EQUIP_SORT_ID_CHIP_SHOUZHUO = 2303,				-- 手镯碎片
	EQUIP_SORT_ID_CHIP_JIEZHI = 2304,				-- 戒指碎片
	EQUIP_SORT_ID_CHIP_WUSHOU = 2305,				-- 护手、手套碎片
	EQUIP_SORT_ID_CHIP_TOUSHI = 2306,				-- 头饰碎片
	EQUIP_SORT_ID_CHIP_YIFU = 2307,					-- 衣服碎片
	EQUIP_SORT_ID_CHIP_YAODAI = 2308,				-- 腰带碎片
	EQUIP_SORT_ID_CHIP_HUTUI = 2309,				-- 护腿碎片
	EQUIP_SORT_ID_CHIP_XIEZI = 2310,				-- 鞋子碎片
	EQUIP_SORT_ID_CHIP_QINGLV = 2311,				-- 情侣碎片
	--EQUIP_SORT_ID_CHIP_WING = 2312,					-- 翅膀碎片
	EQUIP_SORT_ID_CHIP_AVATAR = 2313,				-- 时装碎片
	EQUIP_SORT_ID_CHIP_MAGIC_RING = 2314,			-- 魔戒碎片
	EQUIP_SORT_ID_CHIP_SHENBING = 2315,				-- 神兵碎片
	EQUIP_SORT_ID_CHIP_TSTAR = 2316,				-- 幻兽双星碎片
	
	EQUIP_SORT_ID_CHIP_HORSE1 = 2320,				-- 坐骑装备1碎片
	EQUIP_SORT_ID_CHIP_HORSE2 = 2321,				-- 坐骑装备2碎片
	EQUIP_SORT_ID_CHIP_HORSE3 = 2322,				-- 坐骑装备3碎片
	EQUIP_SORT_ID_CHIP_HORSE4 = 2323,				-- 坐骑装备4碎片
	
	EQUIP_SORT_ID_JEWEL_DOUZHI = 2401,				-- 斗志宝石
	EQUIP_SORT_ID_JEWEL_ADDI_HARM = 2402,			-- 附伤宝石
	EQUIP_SORT_ID_JEWEL_ATTACK = 2404,				-- 攻击宝石
	EQUIP_SORT_ID_JEWEL_LUCK = 2405,				-- 幸运宝石
	EQUIP_SORT_ID_JEWEL_START = 2401,
	EQUIP_SORT_ID_JEWEL_END = 2499,
	EQUIP_SORT_ID_JEWEL_MAX_LEVEL = 9,				-- 宝石最高等级(注意：在ChItemDefs也有定义 MIXTURE_JEWEL_MAX_LEV)
	
	EQUIP_SORT_ID_BAOWU_CHIP_START = 2501,
	EQUIP_SORT_ID_BAOWU_CHIP_WUQI = 2501,			--宝物武器 碎片
	EQUIP_SORT_ID_BAOWU_CHIP_KAIJIA = 2502,			--宝物铠甲 碎片
	EQUIP_SORT_ID_BAOWU_CHIP_HUDUN = 2503,			--宝物护盾 碎片
	EQUIP_SORT_ID_BAOWU_CHIP_ZHANXUE = 2504,		--宝物战靴 碎片
	EQUIP_SORT_ID_BAOWU_CHIP_HUSHENGFU = 2505,		--宝物法器 碎片
	EQUIP_SORT_ID_BAOWU_CHIP_SHOUTAO = 2506,		--宝物圣物 碎片
	EQUIP_SORT_ID_BAOWU_CHIP_EXP = 2507,			--宝物经验 碎片
	EQUIP_SORT_ID_BAOWU_CHIP_END = 2507,
	
	EQUIP_SORT_ID_PET_CHIP = 2601,          --幻兽碎片
	
	EQUIP_SORT_ID_NS_CHIP = 2701,			--女神碎片
	
	EQUIP_SORT_ID_WING_CHIP = 2801,			-- 翅膀碎片

	EQUIP_SORT_ID_EQUIP_CHIP = 2901,		-- 道具碎片
	
	EQUIP_SORT_ID_SPIRIT_CHIP = 3101,		-- 精灵碎片
	
	-- 精灵
	EQUIP_SORT_ID_SPIRIT_HP = 3001,			-- 生命精灵
	EQUIP_SORT_ID_SPIRIT_DODGE = 3002,		-- 闪避精灵
	EQUIP_SORT_ID_SPIRIT_ADD_HARM = 3003,	-- 加伤精灵
	EQUIP_SORT_ID_SPIRIT_PARRY = 3004,		-- 格挡精灵
	EQUIP_SORT_ID_SPIRIT_DOUZHI = 3005,		-- 斗志精灵
	EQUIP_SORT_ID_SPIRIT_ATTACK = 3006,			-- 攻击精灵
	EQUIP_SORT_ID_SPIRIT_DEFENCE_PHY = 3007,	-- 物防精灵
	EQUIP_SORT_ID_SPIRIT_DEFENCE_MAGIC= 3008,	-- 魔防精灵
	EQUIP_SORT_ID_SPIRIT_CRITICAL_HIT = 3009,	-- 暴击精灵
	EQUIP_SORT_ID_SPIRIT_LUCK = 3010,			-- 幸运精灵
	EQUIP_SORT_ID_SPIRIT_REDUCE_HARM = 3011,	-- 减伤精灵


	-- 普通功能道具类型定义
	FUNCTION_EQUIP_TYPE_NORMAL = 0,					--普通类型
	FUNCTION_EQUIP_TYPE_PET_SKILL_BOOK = 1,			--侠客技能书
	FUNCTION_EQUIP_TYPE_GIFT = 2,					--普通礼包
	FUNCTION_EQUIP_TYPE_GIFT_RANDOM = 3,			--随机礼包
	FUNCTION_EQUIP_TYPE_SPY_NORMAL = 4,				--非时限性补给品
	FUNCTION_EQUIP_TYPE_SPY_BUFFER = 5,				--BUFFER(时限性补给品)
	FUNCTION_EQUIP_TYPE_PACKAGE_EXTEND = 6,			--扩充包裹类
	FUNCTION_EQUIP_TYPE_PET_EXP = 7,				--幻兽经验丹类
	FUNCTION_EQUIP_TYPE_PET_BREAK_LEVEL = 8,		--突破幻兽等级上限(龙牙)
	FUNCTION_EQUIP_TYPE_ADD_PHYSICAL = 9,		 	--使用体力药增加体力
	FUNCTION_EQUIP_TYPE_PET_JITAN = 11,			 	--幻兽祭坛相关类
	FUNCTION_EQUIP_TYPE_PET_CHIP = 12,		        --幻兽碎片(用于碎片合成功能;该处定义不太好，跟EQUIP_SORT_ID_PET_CHIP同语义)
	FUNCTION_EQUIP_TYPE_HORSE = 13,					--坐骑类功能道具
	FUNCTION_EQUIP_TYPE_JUNGONG = 14,				--军团类功能道具
	FUNCTION_EQUIP_SILVER = 15,						--银两类道具
	FUNCTION_EQUIP_EXP = 16,						--经验类道具
	FUNCTION_EQUIP_GOLD = 17,						--赠送魔石类道具
	FUNCTION_EQUIP_PET_XO = 18,						--XO兽类(为方便交易系统，后面补上类型)
	FUNCTION_EQUIP_TYPE_ADD_NAILI = 19,		 		--耐力药
	FUNCTION_EQUIP_RANDOM_EQUIP = 20,				--在某类型道具中随机开出道具的道具(使用其他道具配置中的random_param按类型进行随机)
	FUNCTION_EQUIP_TYPE_HONOUR = 21,				--增加荣誉
	FUNCTION_EQUIP_PROF_RANDOM_EQUIP = 22,			--与职业相关随机装备
	FUNCTION_EQUIP_CHAOS = 23,						--洗练书
	FUNCTION_EQUIP_GIFT_PROF = 24,					--职业相关的礼包
	FUNCTION_EQUIP_VOUCHER_GOLD = 25,				--充值魔石类道具(注意，这里的道具使用后会得到充值元宝)
	FUNCTION_EQUIP_GET_PET = 26,					--打开获得幻兽类功能道具
	FUNCTION_EQUIP_WING_EXP = 27,					--翅膀加经验类：金羽毛
	FUNCTION_EQUIP_DRAGON_GOLD = 28,				--军团龙币
	FUNCTION_EQUIP_ADD_TIMES = 29,					--增加次数的道具
	FUNCTION_EQUIP_INVITE_SCORE = 30,				--增加推广积分类道具
	FUNCTION_EQUIP_LEVEL_UP = 31,					--使用后可将角色等级提升一级
	FUNCTION_EQUIP_HORSE_GUOLAN = 32,				--果篮（注意，实际不是加在坐骑上，而是用一个通用的字段存起来，里面分了角色和幻兽属性）
	FUNCTION_EQUIP_TITLE = 33,						--使用后获得称号
	FUNCTION_EQUIP_QIHUN = 34,						--使用后获得器魂
	FUNCTION_EQUIP_TYPE_GODDESS_CHIP = 35,			--女神碎片(用于碎片合成功能;该处定义不太好，跟EQUIP_SORT_ID_NS_CHIP 同语义)
	FUNCTION_EQUIP_GODDESS_TEMPLE = 36,				--使用后获得女神神殿
	FUNCTION_EQUIP_GODDESS = 37,					--使用后获得女神
	FUNCTION_EQUIP_CHARM = 38,           			--使用后获得魅力
	FUNCTION_EQUIP_FRIEND = 39,           			--好友类功能道具
	FUNCTION_EQUIP_MAGIC_CAILIAO = 40,           	--魔戒升星材料
	FUNCTION_EQUIP_GANG_BAGEG = 41,					--军团徽章
	FUNCTION_EQUIP_EQUIP_CHIP = 42,					--直接可以合成普通道具的碎片（只与数量相关）
	FUNCTION_EQUIP_MONTH_CARD_RENEW = 43,			--月卡续费
	FUNCTION_EQUIP_TYPE_DAILY_FIGT = 44,			--每日礼包
	FUNCTION_EQUIP_TIME_LIMIT_GOLD_BAOXIANG = 45,	--限时魔石宝箱
	FUNCTION_EQUIP_VIP = 46,						--获取VIP
	FUNCTION_EQUIP_TYPE_LIFELONG_CARD = 47,			--终身卡
	FUNCTION_EQUIP_TYPE_FUND = 48,					--基金
	FUNCTION_EQUIP_TYPE_COUNTER = 49,				--增加某个计数器的次数
	FUNCTION_EQUIP_TYPE_BF_FIREWORKDS = 50,         --播放礼花特效
	FUNCTION_EQUIP_TYPE_HORSE_PIFU = 51,         	--坐骑皮肤
	FUNCTION_EQUIP_TYPE_AVATAR_UPGRADE_CL = 52,		--时装升级材料
	FUNCTION_EQUIP_TYPE_PET_UP_QUALITY = 53,		--幻兽升阶材料
	FUNCTION_EQUIP_TYPE_PET_UP_QUALITY_CHIP = 54,	--幻兽升阶材料碎片
	FUNCTION_EQUIP_TYPE_SUBLINE_EMENG = 55,			--噩梦副本令
	FUNCTION_EQUIP_TYPE_MALL_REBATE = 56,			--商城打折卡
	FUNCTION_EQUIP_TYPE_GENDER_GIFT = 57,			--性别礼包
	FUNCTION_EQUIP_TYPE_XUNHUA = 58,				--坐骑驯化材料
	

	-------------------------- 功能道具 ID定义 start -----------------------
	------ 功能道具: 普通类型 start ---------
	FUNCTION_EQUIP_ID_OPEN_HOLE = 21010001,			--打孔石
	FUNCTION_EQUIP_ID_PET_CHAOS = 21010002,			--银口哨 幻兽训练
	FUNCTION_EQUIP_ID_PET_XO_EQUIP = 21010003,		--XO兽 幻兽幻化
	FUNCTION_EQUIP_ID_RAID_CD_SPEED = 21010004,		--扫荡加速券
	FUNCTION_EQUIP_ID_RAID_ADD_TIMES = 21010005,	--扫荡强攻券
	FUNCTION_EQUIP_ID_ROB_MIANZHAN = 21010006,		--免战牌(宝物碎片夺宝)
	FUNCTION_EQUIP_ID_PET_SHOUHUN = 21010007,		--兽魂(不会产出,用于客户端显示使用)
	--FUNCTION_EQUIP_ID_CHAOS_BOOK = 21010008,		--洗练书
	FUNCTION_EQUIP_ID_VIT = 21010009,				--1点体力药
	FUNCTION_EQUIP_ID_ENDURANCE = 21010010,			--1点耐力药
	FUNCTION_EQUIP_ID_CONTRIBUTE = 21010011,		--军功
	FUNCTION_EQUIP_ID_MEDAL = 21010012,				--奖牌
	FUNCTION_EQUIP_RELIVE_EQUIP = 21010013,			--复活使用
	FUNCTION_EQUIP_ID_HUANHUA_CL = 21010014,		--幻化材料:幻晶
	FUNCTION_EQUIP_ID_CLEAR_REDNAME = 21010015,		--清红名道具：赎罪药
	FUNCTION_EQUIP_ID_PIGEON = 21010019,			--飞鸽
	FUNCTION_EQUIP_ID_HONOUR = 21010038,			--1点荣誉
	FUNCTION_EQUIP_ID_VIT_KE = 21010903,			--一颗体力药（25点）
	FUNCTION_EQUIP_ID_ENDURANCE_KE = 21010904,		--一颗耐力药（10点）
	FUNCTION_EQUIP_ID_VIT_SMALL = 21010901,			--小体力药
	FUNCTION_EQUIP_ID_ENDURANCE_SMALL = 21010902,	--小耐力药
	FUNCTION_EQUIP_ID_DRAGON_GOLD = 21010119,		--军团龙币
	FUNCTION_EQUIP_ID_ZHAOMULIN = 21010120,			--招募令
	FUNCTION_EQUIP_ID_SPEED_UPGRADE = 21010090,		--坐骑加速石
	FUNCTION_EQUIP_ID_TOLLGATE_MIAOSHA = 21010292,	--关卡秒杀令
	FUNCTION_EQUIP_ID_BABEL_TIMES = 21010097,		--豆蔓叶
	FUNCTION_EQUIP_ID_AVATAR_UP_LUCK = 21010099,	--时装升级 幸运卷轴
	FUNCTION_EQUIP_ID_LUCK_GODDESS_XUYUAN = 21010490,--许愿石
	FUNCTION_EQUIP_ID_FUHUAQI_PUTONG = 21010500,	--普通孵化器
	FUNCTION_EQUIP_ID_AIQINGSHI = 21010529,			--爱情石
	------ 功能道具: 普通类型 end -----------
	
	-- 扩充包裹类
	FUNCTION_EQUIP_ID_PACKAGE_EXTEND = 21010601,	--包裹扩充券
	FUNCTION_EQUIP_ID_PET_POS_EXTEND = 21010601,	--幻兽位扩充券(共用包裹扩充券)
	FUNCTION_EQUIP_ID_NS_POS_EXTEND  = 21010601,	--女神位扩充券(共用包裹扩充券)
	
	-- 幻兽经验丹类
	FUNCTION_EQUIP_ID_PET_EXP_FULL = 21010702,		--满的幻兽经验丹
	FUNCTION_EQUIP_ID_PET_EXP_ONE_DOT = 21010703,	--幻兽1点经验丹(幻兽经验池)
	
	-- 突破幻兽等级上限类
	FUNCTION_EQUIP_ID_PET_BREAK_LEVEL  = 21010801,	--龙牙
	
	--幻兽祭坛相关类 砸蛋刷幻兽用的道具(fuqian.liao)
	FUNCTION_EQUIP_ID_HIT_EGG_GREEN  = 21011101,	--绿锤子
	FUNCTION_EQUIP_ID_HIT_EGG_BLUE   = 21011102,	--蓝锤子
	FUNCTION_EQUIP_ID_HIT_EGG_PURPLE = 21011103,	--紫锤子
	FUNCTION_EQUIP_ID_HIT_EGG_GOLD   = 21010293,	--金锤子
	FUNCTION_EQUIP_ID_JITAN_REFRESH  = 21011104,	--刷新券(祭坛刷新用)
	
	--魅力活动道具
	FUNCTION_EQUIP_ID_CHARM_FLOWER_1  = 21010260, --1朵玫瑰
	FUNCTION_EQUIP_ID_CHARM_FLOWER_9  = 21010261, --9朵玫瑰
	FUNCTION_EQUIP_ID_CHARM_FLOWER_99  = 21010262, --99朵玫瑰
	
	FUNCTION_EQUIP_ID_WEDDING_XIANGBING = 21010333, --香槟
    FUNCTION_EQUIP_ID_WEDDING_LIHUA1 = 21010334, --礼花1
    FUNCTION_EQUIP_ID_WEDDING_LIHUA2 = 21010335, --礼花2
    FUNCTION_EQUIP_ID_WEDDING_LIHUA3 = 21010336, --礼花3
    FUNCTION_EQUIP_ID_WEDDING_LIHE = 21010337, --婚宴礼盒
	
	--军团相关类
	FUNCTION_EQUIP_ID_GANG_TU_TENG    = 21011401,		--图腾(捐献给军团可获得军功和军团经验)
	FUNCTION_EQUIP_ID_GANG_BADGE    = 21011402,			--军团荣誉徽章
	FUNCTION_EQUIP_ID_GANG_RENAME    = 21010437,		--军团改名卡

	-- 元宝类
	FUNCTION_EQUIP_ID_BIND_GOLD = 21011702,			--绑定的1元宝道具
	FUNCTION_EQUIP_ID_BIND_GOLD_10 = 21011701,		--绑定的10元宝道具
	
	-- 经验类
	FUNCTION_EQUIP_ID_EXP = 21011601,				--1点经验
	
	-- 银两类
	FUNCTION_EQUIP_ID_SILVER = 21011501,		--1点银两
	
	-- 师徒
	FUNCTION_EQUIP_ID_DEL_CONTRACT = 21011001,		--解除契约

	-- 每日任务
	FUNCTION_EQUIP_ID_DAILY_TASK_FIN = 21010062, 	--快速完成令

	-- 女神进阶道具
	FUNCTION_EQUIP_ID_GODDESS_UPGRADE = 21010014,	--幻晶

	--好友送心 
	FUNCTION_EQUIP_ID_FRIEND_INITMACY = 21013901,   --亲密度

	-- 改名卡
	FUNCTION_EQUIP_ID_RENAME = 21011403,		--改名卡

	-- 变性卡
	FUNCTION_EQUIP_ID_BIANXING = 21010471,		--变性
	
	--月卡
	FUNCTION_EQUIP_ID_MONTH_CARD_RENEW = 21014301,	--月卡续费卡

	--2V2秒杀令
	FUNCTION_EQUIP_2V2_QUICK_FIN_EQUIP = 21010517,	
	
	--坐骑驯化材料
	FUNCTION_EQUIP_ID_HORSE_XUNHUA_MAOSHUA = 21010518,		--毛刷
	FUNCTION_EQUIP_ID_HORSE_XUNHUA_JIANGSHEN = 21010519,	--缰绳
	FUNCTION_EQUIP_ID_HORSE_XUNHUA_MATITIE = 21010520,		--马蹄铁
	
	FUNCTION_EQUIP_ID_JEWEL_BLESS_CL = 21010645,			--宝石祝福圣水
	-------------------------- 功能道具 ID定义 end -----------------------

	--巨岩魔宝箱
	BIG_YANMO_BAOXIANG = 21010279,
	
	--绿色经验宝物
	BAOWU_EXP_EQUIP_ID_GREEN_EXP_BAOWU = 10300001, 	--绿色经验宝物
	
	--情侣时装ID
	--LOVERS_AVATAR_EID = 10130003,

	--诸神令
	FUNCTION_EQUIP_ID_ZHUSHENLIN = 21010098,
	
	--跨服服务器起始的角色道具ID
	GLOBALPK_SERV_CHEID_INC_START = 10000000,
	
	-- 功能道具类型ID对应的道具ID列表 (需要用到equip id的地方才会在这里定义)
	-- 内容定义在EquipDefs类定义后面
	function_equip_2_eids = {},
	
	--砸蛋类型对应消耗的道具列表
	hit_egg_type_2_equip_id = {},

	-- 消费类型定义
	EQUIP_CONSUME_TYPE_IMMEDI = 1,				-- 实时类型：使用即消失的道具，使用即记录为消耗,宝箱/礼包类,返金类,特殊功能类等
	EQUIP_CONSUME_TYPE_BUFF = 2,				-- 时效类型
	
	-------------------- 道具类型相关定义 end -----------------------
	
	-------------------- 虚拟物品类型相关定义 start --------------------
	-- 虚拟道具ID定义 (不会真正产出该道具，用户客户端显示道具图标使用)
	EQUIP_VIRTUAL_ID_EXP = 89000001;				--经验
	EQUIP_VIRTUAL_ID_SILVER = 89000002;				--银两	
	EQUIP_VIRTUAL_ID_ZB = 89000003,					--装备
	EQUIP_VIRTUAL_ID_BW = 89000004,					--宝物
	EQUIP_VIRTUAL_ID_ZHANLI = 89000005,				--战力
	EQUIP_VIRTUAL_ID_ZHANSHALI = 89000006, 			--斩杀力
	EQUIP_VIRTUAL_ID_JEWEL = 89000007, 				--宝石
	EQUIP_VIRTUAL_ID_BW_WUQI = 89010008,			--宝物武器
	EQUIP_VIRTUAL_ID_BW_KAIJIA = 89010009,			--宝物铠甲
	EQUIP_VIRTUAL_ID_BW_HUDUN = 89010010,			--宝物护盾
	EQUIP_VIRTUAL_ID_BW_ZHANXUE = 89010011,			--宝物战靴
	EQUIP_VIRTUAL_ID_BW_HUSHENGFU = 89010012,		--宝物法器
	EQUIP_VIRTUAL_ID_BW_SHOUTAO = 89010013,			--宝物圣物
	EQUIP_VIRTUAL_ID_BW_EXP = 89010014,				--宝物经验
	EQUIP_VIRTUAL_ID_GODNESS = 89010015,			--女神
	EQUIP_VIRTUAL_ID_PET = 89010016,				--幻兽
	EQUIP_VIRTUAL_ID_SPIRIT = 89010019,				--精灵
	EQUIP_VIRTUAL_ID_GOLD = 89000023,				--充值魔石
	EQUIP_VIRTUAL_ID_MAOXIANZHI = 89000025, 		--冒险值
	
	EQUIP_VIRTUAL_ID_WEIZHI_E_START = 89009001,		--问号位置虚拟道具起始ID
	EQUIP_VIRTUAL_ID_WEIZHI_E_END = 89009049,		--问号位置虚拟道具截止ID
	-------------------- 虚拟物品类型相关定义 end --------------------

	---------------------- 装备强化相关定义 start ---------------------------
	-- 装备品阶定义
	EQUIP_QUALITY_WHITE = 0,					-- 白色装备
	EQUIP_QUALITY_GREEN = 1,					-- 绿色装备
	EQUIP_QUALITY_GREEN_SUIT = 2,				-- 绿色套装装备
	EQUIP_QUALITY_BLUE = 3,						-- 蓝色装备
	EQUIP_QUALITY_BLUE_SUIT = 4,				-- 蓝色套装装备
	EQUIP_QUALITY_PURPLE = 5,					-- 紫色装备
	EQUIP_QUALITY_PURPLE_SUIT = 6,				-- 紫色套装装备
	EQUIP_QUALITY_GOLD = 7,						-- 金色装备
	EQUIP_QUALITY_GOLD_SUIT = 8,				-- 金色套装装备
	EQUIP_QUALITY_RED = 9,						-- 红色装备
	EQUIP_QUALITY_RED_SUIT = 10,				-- 红色套装装备
	EQUIP_QUALITY_RED_STAR1 = 11,				-- 红色1星
	EQUIP_QUALITY_RED_STAR2 = 12,				-- 红色2星
	EQUIP_QUALITY_RED_STAR3 = 13,				-- 红色3星
	EQUIP_QUALITY_RED_STAR4 = 14,				-- 红色4星
	EQUIP_QUALITY_RED_STAR5 = 15,				-- 红色5星
	EQUIP_QUALITY_RED_STAR6 = 16,				-- 红色6星
	EQUIP_QUALITY_MIN = 0,						-- 最小品阶值
	EQUIP_QUALITY_MAX = 14,						-- 目前开放的最高品阶
	
	-- 品阶对应的附加属性条数
	quality2addi_effect_num = {},
	
	-- 宝石类型到加成效果映射表
	-- 内容定义在EquipDefs类定义后面
	jewel_sort_2_effect_types = {},
	
	---------------------- 装备强化相关定义 end ---------------------------
	
	---------------------- 道具消耗相关定义 start ----------------------
	-- 自定义消耗元宝对应的道具id
	--CONSUME_GOLD_2_EQUIP_ID_STAR_RATE_CHAOS = 99900001,		-- 升星成功概率洗练
	---------------------- 道具消耗相关定义 end ----------------------
	
	-- 宝石类型到1级宝石ID映射
	jewelsort2eid = {},
	
	-- 孔数消耗的打孔石个数
	equip_punchnum2enum = {[0]=1, [1]=3, [2]=5},	-- type:Hashtable	
	
	--定义砸蛋类型
	HIT_EGG_TYPE_ID_GREEN  = 1, -- 绿蛋
	HIT_EGG_TYPE_ID_BLUE   = 2, -- 蓝蛋
	HIT_EGG_TYPE_ID_PURPLE = 3, -- 紫蛋
	HIT_EGG_TYPE_ID_GOLD   = 4, -- 金蛋
	
	--使用道具祭坛刷新配置
	equip_refresh_jitan_config = {},
	
	-- 魅力时装装备ID
	EQUIP_SORT_ID_CHARM_AVATAR = 10130002,
	
	-- 套装类型
	EQUIP_SUIT_SORT_ID_PLAYER = 0,	-- 人物常规装备套装(10个常规位)
	EQUIP_SUIT_SORT_ID_TSTAR = 1,	-- 幻兽双星装备套装
}

local EquipDefs = EquipDefs

--砸蛋类型对应消耗的道具列表
EquipDefs.hit_egg_type_2_equip_id[EquipDefs.HIT_EGG_TYPE_ID_GREEN]  = EquipDefs.FUNCTION_EQUIP_ID_HIT_EGG_GREEN
EquipDefs.hit_egg_type_2_equip_id[EquipDefs.HIT_EGG_TYPE_ID_BLUE]   = EquipDefs.FUNCTION_EQUIP_ID_HIT_EGG_BLUE
EquipDefs.hit_egg_type_2_equip_id[EquipDefs.HIT_EGG_TYPE_ID_PURPLE] = EquipDefs.FUNCTION_EQUIP_ID_HIT_EGG_PURPLE
EquipDefs.hit_egg_type_2_equip_id[EquipDefs.HIT_EGG_TYPE_ID_GOLD]   = EquipDefs.FUNCTION_EQUIP_ID_HIT_EGG_GOLD
-- 
function EquipDefs:getHitEggEquipByType(egg_type)
	return self.hit_egg_type_2_equip_id[egg_type]
end

-- 判断是否虚拟道具
function EquipDefs:isVirtualEquip( equip_id )
	return equip_id > 89000000
end

-- 判断是否为装备
function EquipDefs:isZhuangBei(equip_sort_id)
	return self:getParentSortId(equip_sort_id) == self.EQUIP_PARENT_SORT_ID_ZHUANGBEI
end

-- 判断是否精灵
function EquipDefs:isSpirit( equip_sort_id )
	return self:getParentSortId(equip_sort_id) == self.EQUIP_PARENT_SORT_ID_SPIRIT
end

-- 判断是否玩家装备
function EquipDefs:isPlayerEquipSortId( equip_sort_id )
	return equip_sort_id >= EquipDefs.EQUIP_SORT_ID_PLAYER_BEGIN and equip_sort_id <= EquipDefs.EQUIP_SORT_ID_PLAYER_END
end

-- 判断是否双星装备
function EquipDefs:isTStarEquipSortId( equip_sort_id )
	return equip_sort_id >= EquipDefs.EQUIP_SORT_ID_TSTAR_START and equip_sort_id <= EquipDefs.EQUIP_SORT_ID_TSTAR_END
end

-- 是否宝物(包含经验宝物)
function EquipDefs:isPetBaowu(equip_sort_id)
	return (equip_sort_id == self.EQUIP_SORT_ID_BAOWU_EXP) or 
		(equip_sort_id >= self.EQUIP_SORT_ID_BAOWU_BEGIN and equip_sort_id <= self.EQUIP_SORT_ID_BAOWU_END)
end

-- 是否宝物碎片
function EquipDefs:isPetBaowuChip(equip_sort_id)
	return (equip_sort_id >= self.EQUIP_SORT_ID_BAOWU_CHIP_START and equip_sort_id <= self.EQUIP_SORT_ID_BAOWU_CHIP_END)
end

-- 是否可以被幻兽吃的装备
function EquipDefs:isEnEatZhBeiByPet(equip_sort_id)
	if equip_sort_id == self.EQUIP_SORT_ID_MAGIC_RING then
		return true
	end
	if equip_sort_id >= EquipDefs.EQUIP_SORT_ID_HORSE_BEGIN and equip_sort_id <= EquipDefs.EQUIP_SORT_ID_HORSE_END then
		return true
	end
	if equip_sort_id >= EquipDefs.EQUIP_SORT_ID_TSTAR_START and equip_sort_id <= EquipDefs.EQUIP_SORT_ID_TSTAR_END then
		return true
	end
	return equip_sort_id >= EquipDefs.EQUIP_SORT_ID_PLAYER_EN_EATED_BEGIN and equip_sort_id <= EquipDefs.EQUIP_SORT_ID_PLAYER_EN_EATED_END
end

-- 是否有开启附加属性
function EquipDefs:isOpenAddiEffect(equip_sort_id)
	if equip_sort_id >= EquipDefs.EQUIP_SORT_ID_PLAYER_MAIN_BEGIN and equip_sort_id <= EquipDefs.EQUIP_SORT_ID_PLAYER_MAIN_END then
		return true
	else
		return false
	end
end

-- 是否婚纱
function EquipDefs:isWeddingCloth( equip_id )
	return equip_id == WeddingDefs.WED_ITEMID_COMMON_CLOTH  or 
           equip_id ==  WeddingDefs.WED_ITEMID_GOOD_CLOTH or
           equip_id ==  WeddingDefs.WED_ITEMID_SUPPER_CLOTH
end

-- 是否冒险值
function EquipDefs:isUndercroftExp( equip_id )
	return equip_id == 89000025
end
-------------------------- 道具类型相关定义 end -----------------------------

---------------------- 装备强化相关定义 start ---------------------------

-- 宝石类型到加成效果映射表
EquipDefs.jewel_sort_2_effect_types[EquipDefs.EQUIP_SORT_ID_JEWEL_DOUZHI] = {'douzhi'}
EquipDefs.jewel_sort_2_effect_types[EquipDefs.EQUIP_SORT_ID_JEWEL_ADDI_HARM] = {'addi_harm'}
EquipDefs.jewel_sort_2_effect_types[EquipDefs.EQUIP_SORT_ID_JEWEL_ATTACK] = {'min_attack','max_attack'}
EquipDefs.jewel_sort_2_effect_types[EquipDefs.EQUIP_SORT_ID_JEWEL_LUCK] = {'luck'}

-- 根据宝石类型获取加成效果
function EquipDefs:getJewelEffect(jewel_sort_id)
	local effect_types = self.jewel_sort_2_effect_types[jewel_sort_id]
	return effect_types[1], effect_types[2]
end


-- 宝石类型到1级宝石ID映射
EquipDefs.jewelsort2eid[EquipDefs.EQUIP_SORT_ID_JEWEL_DOUZHI] = 24010001
EquipDefs.jewelsort2eid[EquipDefs.EQUIP_SORT_ID_JEWEL_ADDI_HARM] = 24020001
EquipDefs.jewelsort2eid[EquipDefs.EQUIP_SORT_ID_JEWEL_ATTACK] = 24030001
EquipDefs.jewelsort2eid[EquipDefs.EQUIP_SORT_ID_JEWEL_LUCK] = 24050001

function EquipDefs:getJewelEidBySort(jewel_sort_id, jewel_level)
	local eid1 = EquipDefs.jewelsort2eid[jewel_sort_id]
	local jewel_eid = EquipDefs:getUpLevJewelEid(eid1, jewel_level-1)
	return jewel_eid
end

-- 获取大类ID
function EquipDefs:getParentSortId(equip_sort_id)
	return floor(equip_sort_id/100)
end

-- 根据宝石ID获取宝石分类ID
function EquipDefs:getJewelSortByEquipId(equip_id)
	return strSub(equip_id, 1, 4)
end
	
-- 根据一批宝石ID获取宝石分类ID数组
function EquipDefs:getJewelSortByEquipIds(arr_equip_id)
	local arr_sort_id = {}
	for _, equip_id in pairs(arr_equip_id) do
		arr_sort_id[equip_id] = strSub(equip_id, 1, 4)
	end
	
	return arr_sort_id
end

-- 获取高级别的宝石道具ID
function EquipDefs:getUpLevJewelEid(equip_id, up_level)
	return equip_id + up_level
end

-- 获取强化等级消耗的银两
-- 系数*（当前装备强化等级+1）^2
function EquipDefs:getStrongNeedSilver(arr_ratio, strong_level)
	local need_silver = 9999999999999
	for _,ratio_obj in pairs(arr_ratio) do
		if strong_level >= ratio_obj.level_min and strong_level <= ratio_obj.level_max then
			need_silver = math.round((ratio_obj.ratio1 * (strong_level+1) + ratio_obj.ratio2) * ratio_obj.ratio3)
			break
		end
	end
	return need_silver
end


---------------------- 装备强化相关定义 end ---------------------------

--判断是否幻兽碎片
function EquipDefs:isPetChip(equip_sort_id)
	return equip_sort_id == self.EQUIP_SORT_ID_PET_CHIP
end

--判断是否幻兽碎片
function EquipDefs:isGoddessChip(equip_sort_id)
	return equip_sort_id == self.EQUIP_SORT_ID_NS_CHIP
end

--获取某个品阶的装备颜色
EquipDefs.quality2color = {}
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_WHITE] = 'white1'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_GREEN] = 'green1'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_GREEN_SUIT] = 'green1'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_BLUE] = 'blue1'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_BLUE_SUIT] = 'blue1'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_PURPLE] = 'purple1'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_PURPLE_SUIT] = 'purple1'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_GOLD] = 'gold8'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_GOLD_SUIT] = 'gold8'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_RED] = 'red'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_RED_SUIT] = 'red'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_RED_STAR1] = 'red'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_RED_STAR2] = 'red'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_RED_STAR3] = 'red'
EquipDefs.quality2color[EquipDefs.EQUIP_QUALITY_RED_STAR4] = 'red'

function EquipDefs:getColorByQuality( quality )
	return EquipDefs.quality2color[quality]
end

do 	-- 获取带颜色的道具描述
	local color_equip_fmt = '<color=%s>%s</color>'
	function EquipDefs:getColorEquipStr( equip_base )
		local title = self:getEquipFmtByEid( equip_base.id )
		local quality = equip_base.quality
		local color_str = EquipDefs.quality2color[quality]
		return string.format(color_equip_fmt, color_str, title)
	end
end

do
	local format = '{equip_title:%d}'
	local string_format = string.format
	function EquipDefs:getEquipFmtByEid( equip_id )
		return string_format(format, equip_id)
	end
	local format_scene = '{scene_title:%d}'
	function EquipDefs:getSceneFmtBySid( scene_id )
		return string_format(format_scene, scene_id)
	end
end
do
local format = '{pet_title:%d}'
local string_format = string.format
	function EquipDefs:getPetFmtByEid( pet_id )
		return string_format(format, pet_id)
	end
end	