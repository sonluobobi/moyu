--------------------------------------------------------------------------------
-- 系统定义
-- fuqian.liao
--------------------------------------------------------------------------------

SlaveDefs = {
	
	-- 状态标志
	TYPE_ID_FOR_FREE     = 0,   -- 自由身
	TYPE_ID_FOR_MASTER = 1,   -- 师傅
	TYPE_ID_FOR_SLAVE   = 2,	-- 奴隶

	-- 只保留8条竞技场败将记录
	MAX_NUM_FOR_AREAN_LOSER = 8,

	-- 只保留10条夺敌之徒记录
	MAX_NUM_FOR_ENEMY = 10,

	-- 最多只能有1个徒弟
	MAX_NUM_FOR_SLAVE = 1,

	-- 记录奴隶系统消息数量
	MAX_NUM_FOR_SLAVE_MSG = 30,

	-- 徒弟的有效期(秒数)
	TIME_FOR_KEEP_SLAVE_SECOND = 12*3600, -- (一天)86400
	
	-- cd时间
	TIME_FOR_BIANCHI_SECOND = 30*60,   -- 鞭笞CD时间(10分钟)
	TIME_FOR_TAOHAO_SECOND   = 10*60,   -- 讨好CD时间(10分钟)

	-- 帮会成员数据过期时间(秒)，每5分钟同步一次数据
	TIME_FOR_KEEP_GANG_MEMBER_SECOND = 300, -- 5分钟
	
	--手下败将数据过期时间，每5分钟同步一次数据
	TIME_FOR_KEEP_LOSER_SECOND = 300, -- -- 5分钟

	-- 奴隶系统一些次数限制
	MAX_NUM_FOR_ACCEPT     = 5, -- 收徒5
	MAX_NUM_FOR_RESIST     = 5,  -- 反抗5
	MAX_NUM_FOR_TAOHAO     = 3,  -- 讨好3
	MAX_NUM_FOR_BIANCHI   = 3,  -- 鞭笞1
	MAX_NUM_FOR_CRY_HELP = 3,   -- 求救3

	-- 奴隶系统专用计数器类型
	COUNTER_TYPE_ID_FOR_ACCEPT     = 1, -- 收徒计数器
	COUNTER_TYPE_ID_FOR_RESIST     = 2, -- 反抗计数器
	COUNTER_TYPE_ID_FOR_TAOHAO     = 3, -- 讨好计数器
	COUNTER_TYPE_ID_FOR_BIANCHI   = 4, -- 鞭笞计数器
	COUNTER_TYPE_ID_FOR_CRY_HELP = 5, -- 求救计数器
	
	--讨好尊主的收益系数
	REWARD_FOR_TAOHAO_OK_EXP = 30, 
	
	--鞭笞奴仆的收益系数
	REWARD_FOR_BIANCHI_OK_EXP = 53, 
		
	--强制变成自由身份后的保护时间(30分钟)
	SAFE_TIME_EXPIRE = 30*60,
	
	--鞭笞随机碎片品阶概率
	bianchi_random_quality = {70,25,5},
	
	STAT_SLAVE_EXP_INTERVAL = 60, --设定多长时间结算一次奴仆经验(1分钟一个周期)
	ONE_MINUTE_SLAVE_EXP_FACTOR=1,--每分钟1点经验
	MAX_SLAVE_EXP_MINUTES = 60*24, --累积的奴仆经验上限(24小时）
	MAX_SLAVE_EXP = 144000, --最大仆从经验领取上限值

	--战斗类型	
	SLAVE_PK_ACCEPT = 1, --收徒
	SLAVE_PK_HELP = 2, --求助
	SLAVE_PK_RESIST = 3, --反抗

	SLAVE_PK_CD = 1*60, --主仆pk锁cd，默认一分钟
}