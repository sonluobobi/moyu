--[[
特殊奖励定义
author : guoiyin.huang
date : 2014-11-20
$Id: $
--]]

RewardSpecialDefs =
{
	REWARD_SPECIAL_SORT_MONTH_CARD = 1,			--月卡
	REWARD_SPECIAL_SORT_LIFELONG_CARD = 2,		--终身卡
	REWARD_SPECIAL_SORT_FUND = 3,				--基金
	REWARD_SPECIAL_SORT_INVITE_CODE_USED = 4,	--使用邀请码奖
	REWARD_SPECIAL_SORT_INVITE_CODE_REFERRALS = 5,--邀请下线反馈奖励
	REWARD_SPECIAL_SORT_FRIST_VOUCHER = 6,		--首冲奖励
	
	REWARD_SPECIAL_ID_FUND_PARENT_CARD = 1,		--基金主卡(含多子卡奖励)
	REWARD_SPECIAL_ID_INVITE_CODE_REFERRALS = 2,--邀请下线反馈奖励主ID(含多子卡奖励)
	
	REWARD_SPECIAL_ID_SUB_CARD = 100,			--子卡奖励开始ID
	REWARD_SPECIAL_ID_MONTH_CARD = 101,			--月卡ID
	REWARD_SPECIAL_ID_LIFELONG_CARD = 201,		--终身卡ID
	REWARD_SPECIAL_ID_FUND_ONE = 301,			--首个基金子卡ID
	REWARD_SPECIAL_ID_INVITE_CODE_USED = 401,	--使用邀请码奖
	REWARD_SPECIAL_ID_FRIST_VOUCHER = 601,		--首冲奖励
	
	-- 状态定义	
	REWARD_SPECIAL_STATUS_DISABLE_FETCH = 0,	--不可领取
	REWARD_SPECIAL_STATUS_NO_FETCH = 1,			--可领取且未领取
	REWARD_SPECIAL_STATUS_ALREADY_FETCH = 2,	--已领取
}

-- 去DB获取条件的奖励ID
RewardSpecialDefs.reward_ids_to_db_get_cond = {
	RewardSpecialDefs.REWARD_SPECIAL_ID_MONTH_CARD,
	RewardSpecialDefs.REWARD_SPECIAL_ID_LIFELONG_CARD,
	RewardSpecialDefs.REWARD_SPECIAL_ID_FUND_PARENT_CARD,
}

RewardSpecialDefs.reward_sorts_to_db_get_cond = {
	RewardSpecialDefs.REWARD_SPECIAL_SORT_MONTH_CARD,
	RewardSpecialDefs.REWARD_SPECIAL_SORT_LIFELONG_CARD,
	RewardSpecialDefs.REWARD_SPECIAL_SORT_FUND,
}


