--[[
军团日志 def
author : jianzhu
date : 2016-05-06
--]]

GangLogDefs = {
	GANG_LOG_PER_SIZE = 20, --军团日志每页展示数
	GANG_LOG_MAX_NUM = 100, --每个分类保存最大条数

	GANG_LOG_TYPE_BEGIN = 1, --开始
	GANG_LOG_TYPE_DONATE = 1, --捐献
	GANG_LOG_TYPE_DRAGON = 2, --屠龙
	GANG_LOG_TYPE_OTHER = 3, --其他
	GANG_LOG_TYPE_END = 3, --结束

	--捐献
	GANG_LOG_DESC_TYPE_DONATE1 = 1, --xxx为xx捐献了xx魔石，经验增加xxx
	GANG_LOG_DESC_TYPE_DONATE2 = 2,	--xxx为xx捐献了xx个狼图腾，经验增加xxx

	--屠龙
	GANG_LOG_DESC_TYPE_DRAGON1 = 10, --xxx对金龙造成了xxx点伤害，金龙增加xxx经验
	GANG_LOG_DESC_TYPE_DRAGON2 = 11, --xxx对金龙造成了xxx点伤害，金龙增加xxx经验，金龙升为x级

	--其他
	GANG_LOG_DESC_TYPE_OTHER1 = 20, --xxx加入了军团
	GANG_LOG_DESC_TYPE_OTHER2= 21, --xxx退出了军团
	GANG_LOG_DESC_TYPE_OTHER3 = 22, --xxx被xxx踢出了军团
	GANG_LOG_DESC_TYPE_OTHER4 = 23, --xxx将军团升为xx级
	GANG_LOG_DESC_TYPE_OTHER5 = 24, --xxx被任命为xxx
	GANG_LOG_DESC_TYPE_OTHER6 = 25, --xxx继任了军团长
}