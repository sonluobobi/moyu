--[[
魅力活动定义
author : jinlin.liu
date : 2016-5-16
--]]
--默认是一星
RingDefs =
{ 
  RING_SYS_STATUS_OPEN = 1, --开启状态
  RING_SYS_STATUS_CLOSED = 2,--关闭状态
  
  RING_TUPO_STATUS_NOT_NEED = 1, --表示不需要突破
  RING_TUPO_STATUS_NOT_TUPO = 2, --未突破
  RING_TUPO_STATUS_HAD_TUPO = 3, --已突破
  
  RING_SYS_OPEN_LEV = 60,--开启
  
  RING_COST_TYPE_UPGRADE = 1,--升级
  RING_COST_TYPE_TUPO = 2,--突破
}


