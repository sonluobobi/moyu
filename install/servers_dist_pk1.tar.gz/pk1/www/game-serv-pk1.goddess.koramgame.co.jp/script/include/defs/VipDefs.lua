--[[
VIP系统定义
author : xingzeng
date : 2012-03-27
填表注意：
	次数类型:
		需要在CounterDefs中配置关联的VIP功能ID,VIP表配置参照其他次数类型的配置即可
	商店中的限购：
		参照龙币的配置,value 对应此等级VIP的限购数量
	其他的：
		is_open 配置是否开启此功能
		is_show 配置是否在客户端显示此VIP功能
		value  	自定义的值，比如配置暴击率
		value2	自定义的hash值,可配置道具列表等
		gold 	魔石，当需要配置魔石的时候，配置在此
--]]

VipDefs =
{
	VIP_FUNC_ID_FREE_CHAT_TIMES = 1,			-- 每天免费聊天次数
	VIP_FUNC_ID_VIT_BUY_TIMES = 2,				-- 每天可购买体力次数
	VIP_FUNC_ID_ENDURANCE_BUY_TIMES = 3,		-- 每天可购买耐力次数
	VIP_FUNC_ID_VIP_GIFT = 4,					-- VIP礼包(价格用gold)
	VIP_FUNC_ID_BABEL_RAID = 5,					-- 豆蔓每天可魔石重置次数
	VIP_FUNC_ID_BUY_SUBLINE_TIMES = 6,			-- 购买副本令次数
	VIP_FUNC_ID_BUY_LONGBI_TIMES = 7,			-- 购买龙币次数
	VIP_FUNC_ID_STRONG_BOAJI_RADIX = 8,			-- 强化暴击率
	VIP_FUNC_ID_GANG_DONATE_GOLD = 9,			-- 军团捐献魔石初级
	VIP_FUNC_ID_GOLD_PIGEON = 10,				-- 花费魔石使用飞鸽
	VIP_FUNC_ID_BOSS_GUWU = 11,					-- BOSS之家免费鼓舞次数
	VIP_FUNC_ID_ARENA_CHLLAGE_TOP5 = 12,		-- 竞技场挑战前五
	VIP_FUNC_ID_CREATE_VIP_GANG = 13,			-- 创建VIP军团
	VIP_FUNC_ID_BUY_TITLE_PLACE = 14,			-- 购买称号位
	VIP_FUNC_ID_TEXIAO_GIFT = 15,				-- 特效
	VIP_FUNC_ID_PET_JITAN_TIMES = 16,			-- 幻兽祭坛免费次数上限
	VIP_FUNC_ID_TITLE = 17,						-- 称号
	VIP_FUNC_ID_GANG_DONATE_GOLD_MIDDLE	= 18,	-- 军团捐献魔石中级
	VIP_FUNC_ID_GANG_DONATE_GOLD_HIGH = 19,		-- 军团捐献魔石高级
	VIP_FUNC_ID_CHARM_SEND_GAOJI_ROSE = 20,		-- 可赠送高级玫瑰
	VIP_FUNC_ID_FRIEND_ADD_INITMACY_LEVEL2 = 21,	-- 好友系统送花2挡
	VIP_FUNC_ID_FRIEND_ADD_INITMACY_LEVLE3 = 22,	-- 好友系统送花3挡
	VIP_FUNC_ID_BABEL_TIMES = 23,					-- 豆蔓可魔石进入的次数
	VIP_FUNC_ID_BUY_GLOBAL_ARENA = 24,				-- 购买诸神黄昏次数
	VIP_FUNC_ID_UNDER_CROFT_TIMES = 25,				-- 地下城堡可魔石进入的次数
	VIP_FUNC_ID_ACTIVE_FUHUASHI_TIMES = 26,			-- 激活孵化室的次数

	VIP_FUNC_ID_DESC_BEG = 91,
	VIP_FUNC_ID_DESC_END = 99,					-- 只是用于描述，不对应功能
	VIP_FUNC_ID_VIP_UPGRADE = 100,				-- 到达VIP需要的魔石数
	

	VIP_MAX_LEVEL = 12,		--最高VIP等级

	NOTICE_VIP_LEVEL = 7,	--需要广播的VIP等级

	VIP_SRV_CONF = nil,		--VIP服务端的配置

	LEVEL_2_NEED_GOLD = nil,
}

if Language:isCN() then -- 中文版本
	VipDefs.VIP_SRV_CONF = {
		{func_id=100,level=1, gold=60},
		{func_id=100,level=2, gold=300},
		{func_id=100,level=3, gold=540},
		{func_id=100,level=4, gold=880},
		{func_id=100,level=5, gold=1600},
		{func_id=100,level=6, gold=2980},
		{func_id=100,level=7, gold=4980},
		{func_id=100,level=8, gold=9980},
		{func_id=100,level=9, gold=20000},
		{func_id=100,level=10, gold=50000},
		{func_id=100,level=11, gold=100000},
		{func_id=100,level=12, gold=200000},
	}	

else
	VipDefs.VIP_SRV_CONF = {
		{func_id=100,level=1, gold=45},
		{func_id=100,level=2, gold=200},
		{func_id=100,level=3, gold=450},
		{func_id=100,level=4, gold=900},
		{func_id=100,level=5, gold=1600},
		{func_id=100,level=6, gold=3000},
		{func_id=100,level=7, gold=5000},
		{func_id=100,level=8, gold=10000},
		{func_id=100,level=9, gold=20000},
		{func_id=100,level=10, gold=50000},
		{func_id=100,level=11, gold=100000},
		{func_id=100,level=12, gold=200000},
	}
end

do
	VipDefs.LEVEL_2_NEED_GOLD = {}
	for _, conf in pairs(VipDefs.VIP_SRV_CONF) do
		VipDefs.LEVEL_2_NEED_GOLD[conf.func_id] = VipDefs.LEVEL_2_NEED_GOLD[conf.func_id] or {}
		VipDefs.LEVEL_2_NEED_GOLD[conf.func_id][conf.level] = conf
	end
end

function VipDefs:getGold(func_id, level)
	return VipDefs.LEVEL_2_NEED_GOLD[func_id] and VipDefs.LEVEL_2_NEED_GOLD[func_id][level]
end