--[[
关卡系统定义
author : xingzeng
date : 2014-10-17
--]]

TollgateDefs = 
{	
	TOLLGATE_PER_TODAY_TIMES = 5,		--关卡每天次数
	TOLLGATE_RAID_CD_SEC = 3600,		--扫荡冷却时间
	TOLLGATE_CONSUME_VIT = 5,			--每次通关关卡消耗体力
	TOLLGATE_CONSUME_VIT_BOSS = 10,		--每次通关BOSS关卡消耗体力
	
	CHAPTER_ID_FIRST = 301,				--第一个章节的ID
	CHAPTER_ID_SECOND = 302,			--第二个章节的ID
	FINISH_GOTO_MCITY_CH_LEVEL = 41,	--角色满41级前关卡打完回主城
	
	-- 关卡统计数据 记录状态 (注意：状态值依次递增，不可随便修改)
	TOLLGATE_STATS_STATE_ENTRY = 0,		--已进入关卡
	TOLLGATE_STATS_STATE_LOADER_FIN = 0.5,	--进入关卡完成(客户端已加载资源完成)
	TOLLGATE_STATS_STATE_FAIL = 1,		--通关失败
	TOLLGATE_STATS_STATE_PASS_NO_REWARD = 2,--通关成功未领奖
	TOLLGATE_STATS_STATE_PASS_REWARED = 3,	--通关成功已领奖
	TOLLGATE_STATS_STATE_MIAOSHA = 4,	--秒杀令通关
}

function TollgateDefs:getNeedCdEquipNum(cd_expire, cur_time, speed_cd_count)
	return 2 + (speed_cd_count -1)
end

AsReadOnly(TollgateDefs)
