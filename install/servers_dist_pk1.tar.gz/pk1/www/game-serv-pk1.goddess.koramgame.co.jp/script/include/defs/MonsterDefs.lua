
MonsterDefs = 
{
	SORT_ID_NORMAL = 1,				 -- 普通怪
	SORT_ID_SKILL_CALLED = 2,		 -- 跟随主人的召唤兽-客户端操作AI
	SORT_ID_SKILL_CALLED_SERV_AI = 3,-- 静止的召唤兽-服务端操作AI
	
	-- 巡逻怪物(规则: 策划预先写好移动路径，两个/多个坐标，怪物顺序从开始坐标点向下一个坐标点移动)
	-- 随机移动(规则: 距离出生点2米内，随机找一个点移动；触发条件是被玩家看到)
	-- 静止怪物 不追击(规则: 永远不会动，就算被攻击也不动，不会追击但会反击)
	-- 静止怪物 追击(规则: IDLE状态不会动，被攻击状态下会移动去追击)
	MOVE_SORT_XUNLUO = 0,			--巡逻怪物
	MOVE_SORT_RANK = 1,				--随机移动
	MOVE_SORT_STATIC_NO_ZHUIJI = 2,	--静止怪物 不追击
	MOVE_SORT_STATIC_ZHUIJI = 3,	--静止怪物 追击
	
	MONSTER_RAND_MOVE_DIST = 4, 		  -- 怪物随机移动半径， type:float	
	FRAME_PER_RAND_MOVE_MONSTER_NUM = 20, -- 每帧随机移动的怪物最大数量
	
	CALLED_MONSTER_DEL_FAR_DIST = 28,	  -- 召唤兽远离主人25M后会被删除(3M容错)
	
	MONSTER_FIGHT_BASE_INTERVAL = 300,	  -- 怪物战斗基础频率 (单位：毫秒)


----------------------------------------- 下面是绝代的定义 ----------------------------------------------------------

	-- 怪物类型
	MONSTER_SORT_ID_FOR_NORMAL = 1,		-- 普通怪
	MONSTER_SORT_ID_FOR_BOSS   = 2,		-- boss怪
	MONSTER_SORT_ID_FOR_REWARD_WINE = 3,-- 奖励酒坛
	MONSTER_SORT_ID_FOR_WINE   = 4,		-- 普通酒坛
	MONSTER_SORT_ID_FOR_WORLD_BOSS = 5, -- 世界boss怪
	MONSTER_SORT_ID_FOR_GANG_BOSS = 6,  -- 帮会boss怪
	MONSTER_SORT_ID_FOR_TOWER_LASER = 7,-- 激光塔怪
	MONSTER_SORT_ID_FOR_SCENARIO = 8,	-- 剧情怪，没有ai
	MONSTER_SORT_ID_FOR_TOWER_FANGYU = 9,-- 防御塔
	MONSTER_SORT_ID_FOR_JIDI = 10,		-- 基地

	-- 怪物技能系类型
	MONSTER_PROF_PHY = 4,	-- 法术系怪物
	MONSTER_PROF_MAGIC = 5,	-- 物理系怪物

	-- is hate
	IS_HATE_YES = 1,	-- 有仇恨
	IS_HATE_NO  = 0,	-- 没有仇恨

	-- is_can_attack
	IS_CAN_ATTACK_YES = 1,		-- 会反击
	IS_CAN_ATTACK_NO  = 0,		-- 不会反击
	IS_CAN_ATTACK_EXCAPE = 2,	-- 不会反击，会逃跑

	-- is idle homing
	IS_IDLE_HOMING_YES = 1,	-- 会回家
	IS_IDLE_HOMING_NO  = 0,	-- 不会回家

	-- is_homing_max_hp
	IS_HOMING_MAX_HP_YES = 1, -- 回家会自动满血
	IS_HOMING_MAX_HP_NO  = 0, -- 回家不自动满血

	-- is active monster
	IS_ACTIVE_MONSTER_YES = 1,		-- 主动怪
	IS_ACTIVE_MONSTER_NO = 0,		-- 被动怪

	-- move sort id
	MOVE_SORT_ID_FOR_WAIT = 0,		-- 默认不动，被攻击会动
	MOVE_SORT_ID_FOR_LOOP = 1,		-- 默认循环移动，被攻击会动
	MOVE_SORT_ID_FOR_RANDOM = 2,	-- 默认随机移动，被攻击会动
	MOVE_SORT_ID_FOR_STATIC = 3,	-- 默认不动，被攻击也不动

	-- 移动类型
	MOVE_TYPE_ID_FOR_WALK = 1, -- 走动
	MOVE_TYPE_ID_FOR_RUN  = 2, -- 跑动
	
	-- 阵营id
	POWERS_ID_FOR_A = 1,  -- 甲方阵营(城战守方)
	POWERS_ID_FOR_B = 2,  -- 乙方阵营(城战功方)
	POWERS_ID_FOR_NO = 0, -- 不隶属于任何阵营的

	POWERS_ID_FOR_FUZHAN_A = 3, -- 服战(A)
	POWERS_ID_FOR_FUZHAN_B = 4, -- 服战(B)
	POWERS_ID_FOR_FUZHAN_C = 5, -- 服战(C)

	POWERS_ID_FOR_GL_GANG_PK_A  =  6,  --跨服帮战(A)
	POWERS_ID_FOR_GL_GANG_PK_B  =  7,  --跨服帮战(B)
}

do
	local format = '{monster_title:%d}'
	local string_format = string.format
	function MonsterDefs:getMonsterFmtByEid( monster_id )
		return string_format(format, monster_id)
	end
end

AsReadOnly(MonsterDefs)