--[[
角色、侠客、怪物、坐骑加成效果(战斗相关)类型定义
author : xingzeng
date : 2012-03-27
$Id: $
--]]
local tableInsert = table.insert

EffectType = {
	none_effect = 0,			-- 无效果
	
	-- 基础效果(绝对值效果) (1-100)
	-- max_hp 	:	类型名
	-- 1		:	类型ID
	max_hp = 1,					-- 最大血量
	max_attack = 2,				-- 最大攻击
	min_attack = 3,				-- 最小攻击
	defence_phy = 6,			-- 物理防御
	defence_magic = 7,			-- 法术防御
	douzhi = 8,					-- 斗志(致命)
	critical_hit = 9,			-- 暴击
	dodge = 10,					-- 闪避
	parry = 11,					-- 格挡
	
	addi_harm = 20,				-- 基础加伤:附加伤害绝对值(注：战斗BUFFER附加的附伤不能用该属性)
	reduce_harm = 21,			-- 基础减伤:降低伤害绝对值(注：战斗BUFFER附加的减伤不能用该属性)
	kill_force = 22,			-- 斩杀力
	luck = 23,					-- 幸运(韧性)
	
	speed = 30,					-- 速度加成
	
	harm = 41,					-- 增加伤害(作用在受击者身上)
	attack = 42,				-- 攻击
	
	-- 基础效果(百分比效果) (101-200)
	max_hp_perc = 101,					-- 最大血量 百分比 type:float
	max_attack_perc = 102,				-- 最大攻击 百分比
	min_attack_perc = 103,				-- 最小攻击 百分比
	defence_phy_perc = 106,				-- 增加防御 百分比
	defence_magic_perc = 107,			-- 法术防御 百分比
	douzhi_perc = 108,					-- 斗志 百分比
	critical_hit_perc = 109,			-- 暴击 百分比
	dodge_perc = 110,					-- 闪避 百分比
	parry_perc = 111,					-- 格挡 百分比
	addi_harm_value_perc = 112,			-- 加伤值 百分比
	reduce_harm_value_perc = 113,		-- 减伤值 百分比

	addi_harm_perc = 120,				-- 附伤 增加百分比伤害
	reduce_harm_perc = 121,				-- 免伤：降低百分比伤害
	kill_force_perc = 122,				-- 斩杀力 百分比
	luck_perc = 123,					-- 幸运 百分比
	
	speed_perc = 130,					-- 速度百分比
	
	harm_perc = 141,					-- 增加百分比伤害(作用在受击者身上)
	attack_perc = 142,					-- 攻击百分比 type:float
	attack_perc_only_master = 143,		-- 攻击百分比 type:float (只对主人有效果)
	
	----------------- 特殊效果 (301-800) start -------------------
	-- 特殊效果 (301-400)
	harm_target = 301,					-- 给目标增加伤害(作用在攻击者身上)
	harm_perc_target = 302,				-- 给目标增加伤害百分比(作用在攻击者身上)
	giddiness = 303,					-- 眩晕
	fanji_init_skill = 305,				-- 反击风暴：以自身初始单攻技能x%的伤害反还给敌人，反击范围x米
	dingshen = 306,						-- 定身
	biansheng = 307,					-- 变身
	rd_harm_perc_target = 308,			-- 给攻击命中目标增加伤害百分比(红名使用，可以叠加其他伤害类效果)
	rd_harm_perc = 309,					-- 给自己增加受伤害百分比(红名使用，可以叠加其他伤害类效果)
	ts_harm_perc_target = 310,			-- 天神下凡给目标增加伤害百分比(可以叠加其他伤害效果)
	bj_harm_perc_target = 311,			-- 暴击时给目标伤害+x%
	hp_more_harm_perc_target = 312,		-- 当生命%比目标生命%高，给目标伤害+x%
	critical_hit_rate_perc = 313,		-- 暴击率+x%
	parry_rate_perc = 314,				-- 格挡率+x%
	harm_target_inc_buff_multi = 315,	-- 物理伤害增加3x%，法术伤害增加x%，自身有增益buff，效果翻n倍
	kill_add_hp_perc_or_relive = 317,	-- 出战幻兽：击杀敌人后回复生命上限+x%，内存合体幻兽：击杀敌人后给外层幻兽复活%x的血
	dodge_rate_perc = 318,				-- 闪避率+x%
	tf_fendan_harm_perc = 319,			-- 天赋：非合体幻兽有x%概率分担y%的伤害，具体分担规则见天赋文档
	harm_perc_in_beast = 320,			-- 减免自己伤害x%(效果值为负数)，如果在自己召唤的柱子召唤物攻击范围内，减免效果翻x倍
	shensu = 321,						-- 神速(客户端使用)
	fengyin = 322,						-- 封印(客户端使用)
	seckill_touch_all = 323,			-- 秒杀接触到的小怪(客户端使用)
	harm_perc_target_super = 324,		-- 给目标增加伤害百分比 强力(可以跟harm_perc_target叠加)(作用在攻击者身上)
	restore_hp_full_all_cen = 325,		-- 回满所有层的血
	wudi_taopao = 326,					-- 无敌逃跑 (别人不能打自己，自己也不能打其他人)
	score_multi = 327,					-- 积分翻倍积分
	virus_ganran = 328,					-- 病毒感染
	virus_clear = 329,					-- 病毒清除
	virus_yizhi = 330,					-- 病毒抑制
	sb_skill_level = 331,				-- 神兵技能等级
	
	-- 类技能的效果 (401-450)
	parry_fanji_attack_perc = 401,		-- 格挡后反击敌人，反击伤害为<该幻兽攻击力*x%>
	zibao_multi_attack_perc = 402,		-- 自爆:死亡后对周围x米最多n个敌人造成<死亡单位的攻击力*y%>点伤害
	bomb_add_harm = 403,				-- 爆炸，对周围敌人造成伤害(客户端使用)
	
	-- 类陷阱的效果 (451-500)
	trap_add = 451,						-- 添加一个陷阱
	
	----------------- 特殊效果 (301-800) end -------------------
	
	-- 帧触发效果的BUFFER (801-850)
	lost_max_hp_perc = 801,				-- 每X秒流失最大血量x%
	restore_max_hp_perc = 802,			-- 每X秒回复最大血量x%
}

-- 效果属性对象定义
Effects = {}
do
	for name, id in pairs(EffectType) do
		Effects[name] = 0
	end
end

EffectTypeDefs = {
	-- 帧触发的BUFFER效果类型
	frame_trigger_buffer_effects = {
		[EffectType.lost_max_hp_perc]='lost_max_hp_perc',
		[EffectType.restore_max_hp_perc]='restore_max_hp_perc',
	},
	
	-- 角色重算战力相关属性
	ch_recalc_fc_relate_attribs = {
		'max_hp',
		'max_attack',
		'min_attack',
		'defence_phy',
		'defence_magic',
		'douzhi',
		'critical_hit',
		'dodge',
		'parry',
		'addi_harm',
		'reduce_harm',
		'addi_harm_perc',
		'reduce_harm_perc',
		'kill_force',
		'luck',
		'speed',
		'hp',
		'fight_capacity',
	},

	-- 装备附加效果 属性类型列表
	equip_addi_effect_types = {
		'max_hp','min_attack','defence_phy','defence_magic',
		'douzhi','critical_hit','dodge','parry',
	},
}

-- 战斗相关的属性类型列表
EffectsForFight = 
{	
	-- 基础属性
	max_hp 		 = 0,			-- 最大生命值
	
	max_attack = 0,				--最大攻击
	min_attack = 0,				--最小攻击
	
	defence_phy = 0,			--物理防御
	defence_magic = 0,			--魔法防御
	
	douzhi = 0,					-- 斗志
	critical_hit = 0,			-- 暴击
	dodge = 0,					-- 闪避
	parry = 0,					-- 格挡
	
	-- 高级属性
	addi_harm = 0,				-- 附伤 附加伤害绝对值
	addi_harm_perc = 0,			-- 加伤 增加百分比伤害
	reduce_harm = 0,			-- 减伤：降低伤害绝对值
	reduce_harm_perc = 0,		-- 免伤：降低百分比伤害
	kill_force = 0,				-- 斩杀力
	luck = 0,					-- 幸运
	
}
EffectNamesForFight = {}
do
	for name, id in pairs(EffectsForFight) do
		EffectNamesForFight[#EffectNamesForFight+1] = name
	end
end

local EffectType = EffectType


-- 存储了效果类型ID到效果类型名的映射
Effectid2name = {}
local Effectid2name = Effectid2name
do
	for name, id in pairs(EffectType) do
		Effectid2name[id] = name
	end
end

--- 获取所有的 key 数组
local _keys
function EffectType:getKeys()
	if not _keys then
		for k,v in pairs( EffectType) do _keys[#_keys+1] = k end 
	end
	return _keys
end

-- 通过数字ID获得效果类型名
function EffectType:id2name(id)
	return Effectid2name[id]
end

-- 获取对应的百分比的效果类型名
function EffectType:getPercName(name)
	local id = EffectType[name]
	
end

-- 将2个表的对应的属性加成效果值求和，并保存在第一个参数中
-- 会过滤EffectType内没有定义的属性
-- effect_values   		加成效果值数组(eg: {EffectType[max_hp]=33,EffectType[defence_magic]=33})
--						求和的结果保存在effect_values中
-- effect_values_tmp	加成效果值数组(eg: {EffectType[max_hp]=33,EffectType[defence_magic]=33})
function EffectType:sum(effect_values, effect_values_tmp, effect_types)
	if not effect_values_tmp then return end
	for effect_type, value in pairs(effect_values_tmp) do
		if EffectType[effect_type] and (not effect_types or effect_types[effect_type]) then
			local effect_value = effect_values[effect_type]
			effect_values[effect_type] = (effect_value or 0) + value
		end
	end
end

function EffectType:sumForEffectId(effect_values, effect_values_tmp, effect_types)
	if not effect_values_tmp then return end
	for effect_id, value in pairs(effect_values_tmp) do
		local effect_type = Effectid2name[effect_id]
		if effect_type and (not effect_types or effect_types[effect_type]) then
			local effect_value = effect_values[effect_type]
			effect_values[effect_type] = (effect_value or 0) + value
		end
	end
end

function EffectType:sumEx(effect_values, arr_effect_values)
	if not arr_effect_values then return end
	for _, effect_values_tmp in pairs(arr_effect_values) do
		for effect_type, value in pairs(effect_values_tmp) do
			if EffectType[effect_type] then
				local effect_value = effect_values[effect_type]
				effect_values[effect_type] = (effect_value or 0) + value
			end
		end
	end
end

-- 先将第一个表清空，然后将第二个表的各个加成效果值赋值给第一个表
-- effect_values   		存储第二个表的加成效果值数组
-- effect_values_tmp	加成效果值数组(eg: {max_hp=33})
function EffectType:assign(effect_values, effect_values_tmp)
	for effect,_ in pairs(effect_values) do
		effect_values[effect] = nil
	end
	
	for effect, value in pairs(effect_values_tmp) do
		effect_values[effect] = value
	end
end

function EffectType:isBaseEffect(effect_id)
	return effect_id > 0 and effect_id <= 200
end

function EffectType:isSpecialEffect(effect_id)
	return effect_id > 300 and effect_id <= 800
end

function EffectType:isPercBaseEffect(effect_id)
	if effect_id >= 101 and effect_id <= 200 then
		return true, effect_id - 100
	end
	
	return false
end

-- 是否为一级效果：直接影响玩家、幻兽属性
function EffectType:isYiJiEffect(effect_id)
	return (effect_id > 0 and effect_id <= 30) or (effect_id >= 101 and effect_id <= 130)
end

function EffectType:isAddHpEffectType(effect_id)
	return EffectType.lost_max_hp_perc == effect_id or EffectType.restore_max_hp_perc == effect_id
end

AsReadOnlyRelaxed(EffectType)
AsReadOnlyRelaxed(Effectid2name)
