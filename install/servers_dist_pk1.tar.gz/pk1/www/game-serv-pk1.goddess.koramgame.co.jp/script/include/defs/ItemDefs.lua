--[[
ITEM对象定义文件
author : xingzeng
date : 2015-05-06
--]]

ItemDefs = ItemDefs or {
	-- 物品类型
	ITEM_SORT_ID_EQUIP = 1,				-- 道具掉落物
	ITEM_SORT_ID_GATHER = 2,			-- 采集物
	ITEM_SORT_ID_SCENE_BUFFER = 3,		-- 场景BUFFER掉落物
	ITEM_SORT_ID_BUJIZHAN = 4,			-- 补给站
	
	-- 功能类型
	ITEM_FUNC_ID_EQUIP = 1,				-- 道具掉落物
	ITEM_FUNC_ID_SCENE_BUFFER = 2, 		-- 场景BUFFER掉落物
	ITEM_FUNC_ID_GATHER = 3,			-- 普通采集物
	ITEM_FUNC_ID_SCENE_BUFFER_GATHER = 4,-- 场景BUFFER采集物
	
	-- 拾取方式
	ITEM_PICKUP_MODE_NONE = 0,			-- 无法拾取
	ITEM_PICKUP_MODE_FREE = 1,			-- 自由拾取, 无限制
	ITEM_PICKUP_MODE_OWN = 2,			-- 拥有者拾取
	
	GATHER_SORT_ID_NORMAL = 0,			--普通类型
	GATHER_SORT_ID_CALL_BUFF = 1,		--能召唤出场景BUFF类型
	GATHER_SORT_ID_SCENE_REWARDBOX = 2,	--场景道具宝箱类型
}	
ItemDefs.SCENE_BUFFER_LIVE_TIME = 30000		-- 场景BUFFER掉落物的存活时间(毫秒)
ItemDefs.DROP_PACK_LIFE_DURATION = 60000	-- 道具掉落物生存期(毫秒)

-- 掉落物拾取上限配置
ItemDefs.limit_pickup_max_num_confs = {
	-- [场景ID] = {[道具ID]=可以拾取最大数量,...}
	[60008] = {[21010337]=12,},
}

AsReadOnly(ItemDefs)