--[[
角色幻兽宝物碎片 定义
author : xingzeng
date : 2014-08-18
$Id: $
--]]

ChPetBaowuChipDefs = ChPetBaowuChipDefs or {}

-- 拥有2个碎片才可以抢夺
ChPetBaowuChipDefs.CHIP_ROBOT_OWN_NUM_MIN = 2

ChPetBaowuChipDefs.CHIP_REFRESH_COOL_TIME = 2000	-- 碎片刷新冷却时间(单位：豪秒)
ChPetBaowuChipDefs.CHIP_ROB_NEED_ENDURANCE = 2		-- 抢夺一次需的耐力

-- 大于战力50%不需要PK
ChPetBaowuChipDefs.ROB_NO_PK_NEED_BEYOND_FC_PERC = 0.2

-- 显示最近30条被抢夺日志
ChPetBaowuChipDefs.BAOWU_CHIP_ROB_LOG_SHOW_MAX_CNT = 30

-- 连续抢夺最大次数
ChPetBaowuChipDefs.LIANXU_ROB_MAX_CNT = 10

-- 夺宝随机奖励 连续X次没出保底奖励，则必出一次保底奖励
ChPetBaowuChipDefs.ROB_RAND_REWARD_BAODI_TIMES = 500

-- 免战累计最长时间限制(含了全服免战时间)
ChPetBaowuChipDefs.MIANZHAN_LEIJI_TIME_MAX = 100 * 3600-1	--单位 秒

-- 常驻宝物ID列表
ChPetBaowuChipDefs.changzhu_baowu_equip_ids = {[10300001]=1,[10310001]=1,[10320001]=1,[10330001]=1,[10340001]=1,[10350001]=1,[10360001]=1}

-- 抢夺成功的概率基数
ChPetBaowuChipDefs.ROB_SUCCESS_PROBA_RADIX = 100000

AsReadOnly(ChPetBaowuChipDefs)
