TradeDefs = 
{
	-- 每个人的交易包裹位
	MAX_TRADE_PACKAGE_SIZE = 8,
	
	-- 商城每一页的数量
	TRADE_MALL_PAGE_SIZE = 10,

	-- 商城寄售时间(小时)
	TRADE_MALL_SALE_HOUR = 24,

	-- 交易税 10%的交易税
	TRADE_SALE_LOST_GOLD_PERCENT = 0.1,			--type:float

	-- 固定值扣5000金币
	TRADE_SALE_LOST_SILVER_NUM = 5000,
	
	-- XO兽交易类型表填的ID(供客户端使用)
	TRADE_TYPE_ID_EXP_EQUIP = 11,
}
AsReadOnly(TradeDefs)

