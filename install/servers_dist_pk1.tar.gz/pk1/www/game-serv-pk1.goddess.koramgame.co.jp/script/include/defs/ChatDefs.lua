--[[
聊天系统相关常量定义
author : fuqian.liao
date : 2014-10-28
$Id: $
--]]	

	
ChatDefs = {
  ---特殊用户定义绑定在gcid
  ROLE_SYS_BACKEND_GM_GCID = 1,
  ROLE_SYS_BACKEND_GM_UK = "1",
  NEED_CENTER_RETURN = -1,
  
  --跨服取gcid,unikey
  B2CENTER_GET_GCID = 1,
  B2CENTER_GET_UNIKEY = 2,
  
  
	----操作定义
	BAN_OPERATION_BAN=1,			--封号
	BAN_OPERATION_UNBAN=2,			--解封
	BAN_OPERATION_FORBID_TALK=3,	--禁言
	BAN_OPERATION_UNFORBID_TALK=4,  --解禁言
	
	-- 各种类型聊天时间间隔(单位：秒)
	CHAT_SECRET_INTERVAL	= 2,
	CHAT_TEAM_INTERVAL		= 2,
	CHAT_GANG_INTERVAL		= 2,
	CHAT_SCENE_INTERVAL		= 5,
	CHAT_WORLD_INTERVAL		= 5, 
	CHAT_PIGEON_INTERVAL	= 2, 
	CHAT_FORBID_INTERVAL	= 3600, --禁言时长，1小时
	
	CHAT_SCENE_WORLD_INTERVAL_BEFORE_52 = 30 ,---52级前玩家在世界和附近频道的发言间隔
	CHAT_SCENE_WORLD_INTERVAL_BEFORE_40 = 60 ,
	CHAT_SCENE_WORLD_INTERVAL_BEFORE_51 = 30 ,
	CHAT_SCENE_WORLD_INTERVAL_BEFORE_OTHER = 5 ,
	
	-- 聊天频道定义
	CHAT_TYPE_SECRET 	= 1, --私聊
	CHAT_TYPE_TEAM		= 2, --队伍聊天
	CHAT_TYPE_GANG		= 3, --帮会聊天
	CHAT_TYPE_SCENE		= 4, --附近
	CHAT_TYPE_WORLD		= 5, --世界
	CHAT_TYPE_FORBID	= 6, --禁言
	CHAT_TYPE_PIGEON	= 7, --飞鸽
		
	CH_FAPACITY_RANK_MIN_FORBIDTALK = 10,	-- 战力排行榜前10名的玩家可以禁言、解禁
	GAME_IN_FORBID_TALK_SEC_PER = 18000,		-- 游戏里面的禁言每次禁言时长
	CH_FAPACITY_FORBIDTALK_TIMES = 10,		-- 前10名禁言、解禁的次数
	
	CHAT_MAX_LENGTH=1024 ,---最大聊天内容长度（物品展示和组队邀请不限制,其他所有频道都限制）
	
	chat_type2_interval = {},
	
	CHAT_WEDDING_FACE = "#063",
	
	CHAT_FC_1 = "#064",                --战力第一
	CHAT_FC_2_10 = "#065",             --战力2-10
	CHAT_SLICE_1 = "#061",             --斩杀力第一
	CHAT_SLICE_2_10 = "#062",          --斩杀力2-10

	gang3={},			   --前三军团玩法的gcid  只map
	slice10={},			   --前10斩杀力玩法的gcid  只map
	fc10={},			   --前10战力玩法的gcid  只map	
	
}

--各种聊天锁定时间间隔
ChatDefs.chat_type2_interval[ChatDefs.CHAT_TYPE_SECRET] = ChatDefs.CHAT_SECRET_INTERVAL
ChatDefs.chat_type2_interval[ChatDefs.CHAT_TYPE_TEAM]     = ChatDefs.CHAT_TEAM_INTERVAL
ChatDefs.chat_type2_interval[ChatDefs.CHAT_TYPE_GANG]     = ChatDefs.CHAT_GANG_INTERVAL
ChatDefs.chat_type2_interval[ChatDefs.CHAT_TYPE_SCENE]   = ChatDefs.CHAT_SCENE_INTERVAL
ChatDefs.chat_type2_interval[ChatDefs.CHAT_TYPE_WORLD]   = ChatDefs.CHAT_WORLD_INTERVAL
ChatDefs.chat_type2_interval[ChatDefs.CHAT_TYPE_PIGEON]   = ChatDefs.CHAT_PIGEON_INTERVAL

function ChatDefs:getChatInterval(chat_type,level)

    if ((chat_type==ChatDefs.CHAT_TYPE_SCENE) or (chat_type==ChatDefs.CHAT_TYPE_WORLD)) then
		if level<=40  then return ChatDefs.CHAT_SCENE_WORLD_INTERVAL_BEFORE_40 end
        if level<=51  then return ChatDefs.CHAT_SCENE_WORLD_INTERVAL_BEFORE_51 end
        return ChatDefs.CHAT_SCENE_WORLD_INTERVAL_BEFORE_OTHER
	end	
	return ChatDefs.chat_type2_interval[chat_type]
end
AsReadOnly(ChatDefs)