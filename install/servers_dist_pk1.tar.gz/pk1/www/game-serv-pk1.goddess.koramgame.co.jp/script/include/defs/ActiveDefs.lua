--
--------------------------------------------------------------------------------
-- 活跃度相关定义
--author : fuqian.liao
--date : 2015-01-05
--------------------------------------------------------------------------------


ActiveDefs = {
	
	ACTIVE_DAY_MAX = 100,       -- 每日活跃度最大值

	ACTIVE_PAKAGE_STEP   = 4, -- 宝箱获取阶段

	--活动类型
	ACTIVE_LABEL_ID_DAILY   = 1, 	--日常
	ACTIVE_LABEL_ID_SUBLINE  = 2,   --副本
	ACTIVE_LABEL_ID_BOSS = 3,		--BOSS
	ACTIVE_LABEL_ID_OUTDOOR = 4,	--野外
	ACTIVE_LABEL_ID_ACTIVE = 5,		--活动
	ACTIVE_LABEL_ID_GANG = 6,       --军团战
	
	-- 活动的ID定义
	ACTIVE_ID_TIANMO = 3,			--天魔(BOSS之家)
	
	-- 玩法子项ID定义
	ACTIVE_SUB_ID_TIANMO_50 = 30305,--50级BOSS之家
	ACTIVE_SUB_ID_TIANMO_65 = 30301,--65级BOSS之家
	
	-- 玩法奖励找回类型
	REWARD_ZHAOHUI_TYPE_FREE = 1,	-- 只能免费找回
	REWARD_ZHAOHUI_TYPE_GOLD = 2,	-- 只能魔石找回
	REWARD_ZHAOHUI_TYPE_ALL = 3,	-- 可以免费也可魔石找回
}

AsReadOnly(ActiveDefs)
