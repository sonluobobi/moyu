--[[
场景系统定义
author : xingzeng
date : 2014-08-15
]]--

SceneDefs = SceneDefs or 
{
	-- 场景类型
	SCENE_SORT_ID_NORMAL_MCITY			= 1,  -- 主城
	SCENE_SORT_ID_OUTDOOR				= 2,  -- 野外
	SCENE_SORT_ID_TOLLGATE				= 3,  -- 关卡
	SCENE_SORT_ID_BAOWU_ROB				= 4,  -- 夺宝场景
	SCENE_SORT_ID_ARENA					= 5,  -- 竞技场
	SCENE_SORT_ID_SLAVE					= 6,  -- 奴隶
	SCENE_SORT_ID_SUBLINE				= 7,  -- 副本
	SCENE_SORT_ID_3V3					= 8,  -- 3V3
	SCENE_SORT_ID_TIANMO				= 9,  -- 天魔(BOSS之家)
	SCENE_SORT_ID_TIANMO_PRE			= 10, -- 天魔准备厅(BOSS之家)
	SCENE_SORT_ID_DAOJJ_PRE				= 11, -- 刀剑决准备厅
	SCENE_SORT_ID_DAOJJ_WAR				= 12, -- 刀剑决战场
	SCENE_SORT_ID_SCENARIO				= 13, -- 剧情场景	
    SCENE_SORT_ID_SELECT_ROLE 			= 14, -- 选择角色
    SCENE_SORT_ID_CREATE_ROLE 			= 15, -- 创建角色
	SCENE_SORT_ID_OUTDOOR_BENFU			= 16, -- 本服野外场景
	SCENE_SORT_ID_2V2					= 17, -- 2V2
	SCENE_SORT_ID_GANG_CHUSAI			= 18, -- 帮战初赛
	SCENE_SORT_ID_GANG_BATTLE 	 		= 19, -- 军团战
    SCENE_SORT_ID_GANG_DRAGON 	 		= 20, -- 军团屠龙
    SCENE_SORT_ID_BABEL					= 21, -- 试炼塔
    SCENE_SORT_ID_GANG_JUESAI 	 		= 22, -- 帮战决赛
    SCENE_SORT_ID_FINALWAR_PRE          = 23, -- 末日之战准备厅
    SCENE_SORT_ID_FINALWAR              = 24, -- 末日之战
    SCENE_SORT_ID_GLOBAL_ARENA 			= 25, -- 跨服竞技场（诸神黄昏）
    SCENE_SORT_ID_WEDDING               = 26, -- 婚宴
	SCENE_SORT_ID_SUBLINE_EMENG         = 27, -- 噩梦副本
	SCENE_SORT_ID_UNDER_CROFT 			= 28, -- 地下城堡
	SCENE_SORT_ID_SHENGCUN_PRE 			= 29, -- 生还准备厅
	SCENE_SORT_ID_SHENGCUN_WAR 			= 30, -- 生还战场
	SCENE_SORT_ID_OUTDOOR_BOSS 			= 31, -- 跨服BOSS野外
	SCENE_SORT_ID_LOVER_TEMPLE 			= 32, -- 爱情圣殿

	-- 场景难度
	SCENE_DIFFICUITY_NORMAL = 1,      --普通本
	SCENE_DIFFICUITY_HARD = 2,        --困难本
	SCENE_DIFFICUITY_HARD_SUPER = 3,  --精英本
	SCENE_TOLLGATE_DIFFICUITY_NUM = 3,--关卡的难度级别个数
	
	-- 场景安全模式
	SCENE_SAFE_MODE_PEACE = 1,
	SCENE_SAFE_MODE_PVE = 2,
	SCENE_SAFE_MODE_PVP = 3,	
	SCENE_SAFE_MODE_PVPE = 4,
	
	-------------------- 各场景ID定义 start ----------------------
	GPK_BLACK_ROOM_SCENE_ID = 30199,		-- 黑房子ID
	BAOWU_CHIP_ROB_SCENE_ID = 9001,			-- 宝物碎片 夺宝场景ID
	ARENA_SCENE_ID = 50001,					-- 竞技场场景ID
	OUTDOOR_SCENE_ID = 20005,				-- 野外场景ID
	OUTDOOR_SCENE_ID_PK = 20009,			-- 第二野外场景ID(可PK)
	SLAVE_SCENE_ID = 50002,					-- 主仆
	TOLLGATE_FIRST_SCENE_ID = 301001,		-- 第一个关卡场景ID
	PVE_2V2_SCENE_ID = 99999,				-- 2V2场景
	SECOND_MCITY_SCENE_ID = 10001,			-- 第二个主城(注：第一个主城是新手村)
	NEWCOMER_SCENE_ID = 10021,				-- 第一个主城(新手村)
	GLOBAL_AREANA_SCENE_ID = 90011,			-- 跨服竞技场（诸神黄昏）
	UNDERCROFT_SCENE_IDS = {60012,60013,60014,60015,60016},	-- 地下城堡场景ID串
	LOVER_TEMPLE_SCENE_IDS = {60020,60021,60022},	-- 爱情圣殿ID串
	-------------------- 各场景ID定义 end ----------------------
	
	-- 有玩法AOI数据的场景类型列表
	wanfa_aoi_data_scene_sorts = {},		--type:List<int>
	wanfa_aoi_data_scene_sorts_ht = {},

	-- 需要有小地图的场景类型
	small_map_scene_sorts = nil,

	-- 需要支持仇敌的小地图场景类型
	small_map_scene_enemy_sorts = nil,
	
	-- 在主城限制AOI进入视野、移动广播的人数
	MCITY_LIMIT_BC_CH_NUM = 12,
}

SceneDefs.MCITY_LIMIT_BC_CH_NUM = 12
SceneDefs.wanfa_aoi_data_scene_sorts = {
	SceneDefs.SCENE_SORT_ID_3V3,
	SceneDefs.SCENE_SORT_ID_OUTDOOR,
	SceneDefs.SCENE_SORT_ID_DAOJJ_WAR,
	SceneDefs.SCENE_SORT_ID_GANG_BATTLE,
	SceneDefs.SCENE_SORT_ID_SHENGCUN_WAR,
	SceneDefs.SCENE_SORT_ID_OUTDOOR_BOSS,
	SceneDefs.SCENE_SORT_ID_LOVER_TEMPLE,
}

SceneDefs.small_map_scene_sorts = {
	[SceneDefs.SCENE_SORT_ID_OUTDOOR] = 1,
	[SceneDefs.SCENE_SORT_ID_SUBLINE] = 1,
	[SceneDefs.SCENE_SORT_ID_SUBLINE_EMENG] = 1,
	[SceneDefs.SCENE_SORT_ID_DAOJJ_WAR] = 1,
	[SceneDefs.SCENE_SORT_ID_GANG_JUESAI] = 1,
	[SceneDefs.SCENE_SORT_ID_GANG_BATTLE] = 1,
	[SceneDefs.SCENE_SORT_ID_FINALWAR] = 1,
	[SceneDefs.SCENE_SORT_ID_SHENGCUN_WAR] = 1,
	[SceneDefs.SCENE_SORT_ID_OUTDOOR_BOSS] = 1,
	[SceneDefs.SCENE_SORT_ID_LOVER_TEMPLE] = 1,
}

SceneDefs.small_map_scene_enemy_sorts = {
	[SceneDefs.SCENE_SORT_ID_OUTDOOR] = 1,
	[SceneDefs.SCENE_SORT_ID_DAOJJ_WAR] = 1,
	[SceneDefs.SCENE_SORT_ID_OUTDOOR_BOSS] = 1
}

do
	for k,v in pairs(SceneDefs.wanfa_aoi_data_scene_sorts) do
		SceneDefs.wanfa_aoi_data_scene_sorts_ht[v] = true
	end
end


-- 判断是否普通类型
-- param scene_base / scene_sort_id
function SceneDefs:isNormalScene(scene_base)
	local scene_sort_id = type(scene_base) == 'table' and scene_base.scene_sort_id or scene_base
	
	return scene_sort_id == self.SCENE_SORT_ID_NORMAL_MCITY
end

--判断是否婚宴场景
function SceneDefs:isWeddingScene(scene_base)
    local scene_sort_id = type(scene_base) == 'table' and scene_base.scene_sort_id or scene_base
    
    return scene_sort_id == self.SCENE_SORT_ID_WEDDING
end

-- 判断角色是否在婚宴场景
function SceneDefs:isInWeddingScene( character )
	local scene_base =  SceneBaseService:getSceneBaseById(character.scene_id)
	return SceneDefs:isWeddingScene( scene_base )
end

-- 根据玩家等级获取主城的
function SceneDefs:getMCitySceneId(level)
	return 10001
end

-- 判断是否在生存场景
function SceneDefs:isInShengcun( aoi_scene )
	return aoi_scene.scene_base.scene_sort_id == SceneDefs.SCENE_SORT_ID_SHENGCUN_WAR
end

AsReadOnly(SceneDefs)


