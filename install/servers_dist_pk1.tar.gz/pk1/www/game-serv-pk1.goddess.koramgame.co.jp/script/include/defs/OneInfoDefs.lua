--[[
单字段信息
author : guoyin.huang
date : 2015-01-14
--]]

OneInfoDefs = {
	-- 000-099  本服基础
	ID_TEST = 1,				--测试
	ID_TIANMO_WIN_TEAM = 2,		--天魔(BOSS之家)胜利的队伍
	ID_TIANMO_BOSS_KILLER = 3,	--天魔(BOSS之家)击杀BOSS的玩家
	ID_GAME_UPDATE_INFO = 4,	--游戏更新信息
	ID_OPE_ACTIVITY_FIX_STATUS = 5,	--固化活动开启状态
	ID_OPE_ACTIVITY_LANG_PACKS = 6,	--活动语言包信息
	ID_GANG_BATTLE_GAME_TOP_LIST = 7,	--军团战本服排行样
	ID_OPE_ACTIVITY_LANG_PACKS2 = 8,	--活动语言包信息 新版
	ID_GASHAPON_INFO = 9,				--扭蛋数据
	ID_SERVEROPENDATE_INFO = 10,              --开服日期
	ID_HOLIDAY_DROP = 11,				--假日掉落
	ID_WANFA_REWARD_DOUBLE = 12, 		--玩法双倍
	ID_COMBINE_SERV_TIME = 13, 			--合服时间
	
	-- 100-199 本服战斗相关
	ID_GANG_BATTLE = 100, 				--军团战决赛数据
	ID_OUTDOOR_BOSS_LV = 101,			--野外BOSS中心区等级
	ID_GANG_BATTLE_PK_TOP_LIST = 102, 	--军团战跨服排行榜
	ID_GANG_BATTLE_STATUS = 103,		--军团战状态信息
	
	-- 200-299 跨服使用
	
	id2desc = {},
	
}

-- ID->对应描述
OneInfoDefs.id2desc[OneInfoDefs.ID_TEST] = '测试'
OneInfoDefs.id2desc[OneInfoDefs.ID_GANG_BATTLE_PK_TOP_LIST] = '军团战积分跨服排行榜'
OneInfoDefs.id2desc[OneInfoDefs.ID_GANG_BATTLE_GAME_TOP_LIST] = '军团战积分本服排行榜'
OneInfoDefs.id2desc[OneInfoDefs.ID_GANG_BATTLE_STATUS] = '军团战状态信息'
OneInfoDefs.id2desc[OneInfoDefs.ID_GASHAPON_INFO] = '扭蛋数据'
OneInfoDefs.id2desc[OneInfoDefs.ID_HOLIDAY_DROP] = '假日主城掉落'
OneInfoDefs.id2desc[OneInfoDefs.ID_WANFA_REWARD_DOUBLE] = '玩法双倍'