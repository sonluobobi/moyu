--[[
机器人定义文件
author : xingzeng
date : 2014-11-17
--]]

RobotDefs = RobotDefs or
{
	-- 机器人列表(简要信息)
	-- 注：数组按等级递增排序
	-- 每个等级段分3个职业  1001 对应其他2个职业为1013, 1025, 以此类推
	robots_simple = {
		{id = 1001, level = 1},
		{id = 1002, level = 10},
		{id = 1003, level = 20},
		{id = 1004, level = 30},
		{id = 1005, level = 40},
		{id = 1006, level = 50},
		{id = 1007, level = 60},
		{id = 1008, level = 70},
		{id = 1009, level = 80},
		{id = 1010, level = 90},
		{id = 1011, level = 100},
		{id = 1012, level = 120},
	},
	
	ROBOT_CID_START = 1,		-- 机器人起始角色ID
	ROBOT_CID_END = 1036,		-- 机器人最大角色ID
	
	-- 跨服竞技场机器人CID范围
	GLOBAL_AREANA_ROBOT_CID_START = 1000,
	GLOBAL_AREANA_ROBOT_CID_END   = 1011,

	-- 客户端主动获取机器人（2V2玩法等）
	ROBOT_SORT_ID_BEGIN = 1,
	ROBOT_SORT_ID = 1,		-- 从比自己战力低的玩家中获取机器人
	ROBOT_SORT_ID_GANG = 2,	-- 从帮会成员获取机器人
	ROBOT_SORT_ID_TOP = 3,  -- 战力排行前10
	ROBOT_SORT_ID_END = 3,
}

local math_random = math.random

-- 根据角色ID判断是否为机器人
function RobotDefs:isRobot(cid)
	return cid >= self.ROBOT_CID_START and cid <= self.ROBOT_CID_END
end

-- 获取对应等级的机器人简要信息
-- return robot_cid, robot_level
function RobotDefs:getRobotSimpleByLev(level)
	local robots_simple = self.robots_simple
	local cnt = #robots_simple
	for i = cnt, 1, -1 do
		local robot = robots_simple[i]
		if robot.level <= level then
			local robot_cid = (math_random(1, 3)-1) * 12 + robot.id
			return robot_cid, robot.level
		end
	end
	
	-- return default
	return robots_simple[cnt].id, robots_simple[cnt].level
end

AsReadOnly(RobotDefs)