---[[
--	移动相关定义
--  by mjl
--  at 2013年11月25日
---]]

MotionDefs = 
{
		TYPE_MOVE = 1,					-- 移动
		TYPE_JUMP = 2,					-- 跳跃
		TYPE_TIAO_PI = 3,				-- 跳劈
		TYPE_SHAN_YI = 4,				-- 闪移
		TYPE_CHONG_ZHUANG = 5,			-- 冲撞

		SPEED_RATE = 					-- 速度加成, type:ArrayList
		{
			1.0,	-- 移动
			1.0,	-- 跳跃
			1.5, 	-- 跳劈
			3.5,	-- 闪移
			--3.5, 	-- 冲撞
		},
		SPEED_FIX = {},					-- 固定速度
		
		--SPEED_MONSTER_CHONG_ZHUANG = 12/1000,		-- 怪物的冲撞速度
}

local SPEED_FIX = MotionDefs.SPEED_FIX
SPEED_FIX[MotionDefs.TYPE_CHONG_ZHUANG] = 30/1000