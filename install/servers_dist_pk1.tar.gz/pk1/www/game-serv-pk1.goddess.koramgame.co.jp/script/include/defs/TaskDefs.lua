--
--------------------------------------------------------------------------------
-- 任务相关定义
--
-- author : guoyin.huang
-- date : 2014-12-24
--
--------------------------------------------------------------------------------
--


TaskDefs = {
	--缓存相关常量
	ACCEPTABLE_CACHE_PER_LEVEL     = 10,

	--任务类型
	TASK_SORT_MAIN_LINE			    = 1,  --主线任务
	TASK_SORT_SUB_LINE          	= 2,  --支线任务
	TASK_SORT_LOOP 					= 3,  --环任务

	--接取方式
	TASK_ACCEPT_TYPE_FOR_SYSTEM	    = 0,	--系统分配方式
	TASK_ACCEPT_TYPE_FOR_NPC		= 1,	--NPC领取方式

	--特殊任务检测类型
	TASK_SPECAIL_CHECK_TYPE_DONE	= 1,	--目标型任务(达成某个条件才算完成)
	TASK_SPECAIL_CHECK_TYPE_DO 		= 2,	--做了型任务(做了即算完成)

	--任务状态
	CH_TASK_STATUS_ACCEPT	    = 1,	--已接受
	CH_TASK_STATUS_FINISHED	    = 2,	--已完成
	CH_TASK_STATUS_DELIVERED  	= 4,	--已交付
	CH_TASK_STATUS_GIVE_UP	    = 8,	--已放弃
	CH_TASK_STATUS_ACCEPTABLE   = 12,	--可接取
	CH_TASK_STATUS_NO_ACCEPTABLE= 13,	--不可接取

	-- 爱情圣殿任务类型
	LOVE_TEMPLE_SORT_ID_MONSTER = 1,	--杀怪任务
	LOVE_TEMPLE_SORT_ID_CAIJI = 2,		--采集任务
	LOVE_TEMPLE_SORT_ID_WABAO = 3,		--挖宝任务
	LOVE_TEMPLE_SORT_ID_FIND_MEMBER = 4,--找到队友

	--目标类型
	DST_SORT_TOLLGATE				= 1,	--关卡
	DST_SORT_GUIDE					= 2,	--引导任务
	DST_SORT_NPC_DIALOG				= 3,	--npc对话
	DST_SORT_SPECIAL				= 4,	--特殊类型
	DST_SORT_KILL_MONSTER   		= 5,  	--杀死指定怪物数量任务
	DST_SORT_COLLECT_EQUIP  		= 6,  	--收集制定道具数量任务
	DST_SORT_TIMES_REDUCE			= 7,	--角色计数器变化
	DST_SORT_ENTRY_SCENE			= 8,	--进入场景
	DST_SORT_JOIN_PK_ACTIVE			= 9,	--进入某个PK玩法
	DST_SORT_JOIN_PK_SUB_SCTIVE 	= 10,	--进入某个PK子玩法


	--特殊任务定义
	-- 参与某个事件  (注意：任务系统均为进行一次，不支持多次)
	TASK_SPECIAL_TYPE_DUOBAO			  = 101, --夺宝XX次
	TASK_SPECIAL_TYPE_GANG_GIVE 		  = 102, --帮会捐献X次
	TASK_SPECIAL_TYPE_PET_XUILIAN 	 	  = 104, --进行X次幻兽训练
	TASK_SPECIAL_TYPE_PET_UPGRADE 	  	  = 105, --进行X次幻兽升级(喂食)
	TASK_SPECIAL_TYPE_BAOWU_UPGRADE	  	  = 106, --进行X次宝物升级
	TASK_SPECIAL_TYPE_HORSE_UPGRADE		  = 107, --进行X次坐骑升级或进化
	TASK_SPECIAL_TYPE_SHOUHUN_BUY		  = 108, --兽魂商店兑换
	TASK_SPECIAL_TYPE_ARENA				  = 109, --参加X次竞技场
	TASK_SPECIAL_TYPE_TOLLGATE_SUC		  = 110, --关卡通关X次
	TASK_SPECIAL_TYPE_GODDESS_KISS		  = 111, --进行X次女神亲密
	TASK_SPECIAL_TYPE_SLAVE_BIANCHI		  = 112, --进行X次鞭笞讨好
	TASK_SPECIAL_TYPE_ZADAN				  = 113, --进行X次砸蛋
	TASK_SPECAIL_TYPE_EQUIP_STRONG 		  = 114, --进行X次装备强化
	TASK_SPECAIL_TYPE_TIANMO 			  = 115, --参加X次天魔
	TASK_SPECIAL_TYPE_LINWEI_SUC		  = 116, --成功完成一次临危受命
	TASK_SPECIAL_TYPE_STRONG_PLACE		  = 117, --强化某部位的装备(参数为order_by)
	TASK_SPECIAL_TYPE_CHAT		  		  = 118, --发言(参数为频道)
--	TASK_SPECIAL_TYPE_SIGN		  		  = 119, --签到
	TASK_SPECIAL_TYPE_PET_XINAJI		  = 120, --幻兽献祭
	TASK_SPECIAL_TYPE_PET_HUANHUA		  = 121, --幻兽幻化
	TASK_SPECIAL_TYPE_BUY_JITAN_CHIPS	  = 122, --兑换祭坛碎片
	TASK_SPECIAL_TYPE_PET_PACK_BW		  = 123, --装备幻兽宝物
	TASK_SPECIAL_TYPE_OPEN_BAOXIANG		  = 124, --开启某ID的宝箱
	TASK_SPECIAL_TYPE_DAIYLY_TASK		  = 125, --完成一个日常任务
	TASK_SPECIAL_TYPE_PET_JICHEN 		  = 126, --完成一次幻兽继承
	TASK_SPECIAL_TYPE_CATCH_SLAVE		  = 127, --抓住仆人
	TASK_SPECIAL_TYPE_BS_XIANGQIAN 		  = 128, --宝石镶嵌(给某一位置镶嵌宝石)
	TASK_SPECIAL_TYPE_EQUIP_XILIAN		  = 129, --装备洗炼(洗练某一位置)
	TASK_SPECIAL_TYPE_PET_YUANZHUO		  = 130, --任命幻兽为某圆桌骑士
	TASK_SPECIAL_TYPE_TOLLGATE_LINAZHAN   = 131, --进行一次连战
	TASK_SPECIAL_TYPE_JINGLIAN			  = 132, --进行一次装备精炼
	TASK_SPECAIL_TYPE_2V2				  = 133, --进入一次2V2场景（每日任务使用）
	TASK_SPECIAL_TYPE_SHOP				  = 134, --进行一次商店购买(每日任务使用)
	TASK_SPECIAL_TYPE_BABEL				  = 135, --挑战一次摩天豆蔓
	TASK_SPECIAL_TYPE_COIN_DOZER		  = 136, --进行一次推币
	TASK_SPECIAL_TYPE_GANG_DRAGON		  = 137, --进行一次军团屠龙
	TASK_SPECIAL_TYPE_OUTDOOR_KILL_MONSTER= 138, --野外杀怪
	TASK_SPECAIL_TYPE_VIT_LINGQU		  = 139, --领取一次体力套餐

	

	-- 达成某个条件(需要注册检测函数，可参见其他类型的实现)
	TASK_SPECAIL_TYPE_FIN_ZB		  	  = 150, --装备某个道具
	TASK_SPECIAL_TYPE_FIN_PET_FT		  = 151, --设置某ID幻兽出战(指定与不指定幻兽)
	TASK_SPECIAL_TYPE_FIN_HORSE			  = 152, --获得某ID的坐骑
	TASK_SPECIAL_TYPE_FIN_TARGET		  = 153, --爵位升至某等级
	TASK_SPECIAL_TYPE_FIN_PET_HT_N		  = 154, --将某ID幻兽设置为合体内(指定与不指定幻兽)
	TASK_SPECIAL_TYPE_FIN_PET_HT_W		  = 155, --将某ID幻兽设置为合体外(指定与不指定幻兽)
	TASK_SPECIAL_TYPE_FIN_STRONG_2_X	  = 156, --将某装备强化到X级(指定与不指定装备)
	TASK_SPECIAL_TYPE_FIN_FC_2_X		  = 157, --将战力提升到X
	TASK_SPECIAL_TYPE_FIN_ZSL_2_X		  = 158, --斩杀力提升到X
	TASK_SPECIAL_TYPE_FIN_PET_2_XJ		  = 159, --幻兽升到X级(指定与不指定幻兽)
	TASK_SPECIAL_TYPE_FIN_PET_HH_2_XJ  	  = 160, --幻兽幻化到X星级(指定与不指定幻兽)
	TASK_SPECIAL_TYPE_FIN_JINLIAN_2_XJ 	  = 161, --装备精炼到X级(指定与不指定装备)
	TASK_SPECIAL_TYPE_FIN_GODDESS_TH_2_XJ = 162, --女神讨好到X级（指定或不指定女神）
	TASK_SPECIAL_TYPE_FIN_BW_2_XJ 		  = 163, --宝物升到X级（指定或不指定宝物）
	TASK_SPECIAL_TYPE_FIN_ENTRY_GANG 	  = 164, --加入或者退出军团
	TASK_SPECIAL_TYPE_FIN_PACK_XJ_BS	  = 165, --镶嵌X级的宝石
	TASK_SPECIAL_TYPE_FIN_SIGN			  = 166, --完成签到
	TASK_SPECIAL_TYPE_FIN_QISHI			  = 167, --检测圆桌骑士是否完成
	TASK_SPECIAL_TYPE_FIN_ZADAN			  = 168, --检测砸三个蛋完成
	TASK_SPECIAL_TYPE_FIN_CONT_JITAN 	  = 169, --幻兽祭坛连续兑换
	TASK_SPECIAL_TYPE_FIN_PACK_BW 		  = 170, --装备宝物
	TASK_SPECIAL_TYPE_FIN_STAR	 		  = 171, --星点有点亮
	TASK_SPECAIL_TYPE_FIN_PIHU			  = 172, --女神庇护
	TASK_SPECAIL_TYPE_FIN_TOLLGATE_TM_OVER= 173, --某一关卡的次数用完
	
	
	DAILY_TASK_REWARD_SCORE_1 = 40,		--第一级奖励需要的积分
	DAILY_TASK_REWARD_SCORE_2 = 80,		--第二级奖励需要的积分
	DAILY_TASK_REWARD_SCORE_3 = 120,	--第三级奖励需要的积分
	DAILY_TASK_REWARD_SCORE_4 = 150,	--第四级奖励需要的积分
	
	TASK_ID_DRESS_EQUIP = 1000301,		--穿戴装备的任务ID
	
}
