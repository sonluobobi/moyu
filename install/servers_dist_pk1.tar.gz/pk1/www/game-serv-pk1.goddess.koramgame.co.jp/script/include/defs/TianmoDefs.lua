--[[
天魔灭心定义
author : xingzeng
date : 2013-03-23
$Id: $
--]]

TianmoDefs = TianmoDefs or 
{
	TIANMO_PRE_TIME = 180,					--准备时间
	TIANMO_TOTAL_DURATION_TIME = 1020,		--活动总时间(不含准备时间)
	TIANMO_STATUS_DURATION_MATCHED = 3,		--匹配完成状态持续时间
	TIANMO_STATUS_DURATION_FIGHTING = 100,	--开战状态的持续时间
	TIANMO_STATUS_DURATION_LUNKONG = 2,		--轮空持续时间
	TIANMO_PASS_FAIL_TO_LOWER_ROOM_DELAY = 5,	--通关失败进入底1层的延迟时间
	TIANMO_END_CLEAR_DELAY = 6,					--活动结束，延迟清理玩家
	
	TIANMO_OPENS_TIME_INTERVAL = 2,			--2次开启天魔灭心之间时间间隔要求(秒)
	
	TIANMO_LAY_TOTAL_NUM = 7,				--总的层数
	TIANMO_NORMAL_LAY_NUM = 6,				--普通的层数
	
	TIANMO_BOSS_ROOM_STATUS_OPEN = 1,		--BOSS房间状态：开启
	TIANMO_BOSS_ROOM_STATUS_CLOSE = 2,		--BOSS房间状态：关闭
	TIANMO_BOSS_ROOM_STATUS_PASS = 3,		--BOSS房间状态：完成
	
	TIANMO_ROOM_STATUS_MATCHING = 1,		--匹配对手中
	TIANMO_ROOM_STATUS_MATCHED = 2,			--已经匹配成功
	TIANMO_ROOM_STATUS_FIGHTING = 3,		--开打中
	TIANMO_ROOM_STATUS_PASS = 4,			--已经通关
	TIANMO_ROOM_STATUS_LUNKONG = 5,			--轮空
	
	TIANMO_BOSS_ROOM_TEAM_NUM_MAX = 10,		--BOSS房间队总量
	
	TIANMO_TEAM_BUSY_EXPIRE = 5,			--天魔的队伍进入场景冻结时间
	
	TIANMO_TIMER_BC_INTERVAL = 90,			--定时广播的时间间隔
	
	HARM_TOPLIST_UP_TIME = 4,			--排行榜更新频率(秒)
	
	GO_NEXT_LAY_BAOJI_PROBA = 10,			--进入下一层暴击概率(10%)
	
}

--匹配中状态的持续时间(注：必须大于2)(单位:秒)
TianmoDefs.tianmo_status_durationmatching = {30, 30, 30, 40, 50, 60}

AsReadOnly(TianmoDefs)