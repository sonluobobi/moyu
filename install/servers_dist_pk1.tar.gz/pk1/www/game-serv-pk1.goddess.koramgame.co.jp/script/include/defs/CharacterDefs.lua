--------------------------------------------------------------------------------
-- 角色相关定义
-- shuyi.zhong
--------------------------------------------------------------------------------

CharacterDefs = {
	-- 浏览器类型
	BROWSER_ID_FOR_ANDROID = 1,	-- 安卓
	BROWSER_ID_FOR_IPHONE = 2,	-- iphone
	BROWSER_ID_FOR_IPAD = 3,	-- ipad

	-- 职业
	PROF_ID_START = 1, 		--职业开始
	PROF_ID_FOR_XUEZHU  = 1,	-- 血族
	PROF_ID_FOR_ZHAOHUANSHI = 2,-- 召唤师
	PROF_ID_FOR_ZHANSHI = 3,	-- 战士
	PROF_ID_END = 3, 		--职业结束
	PROF_ID_FOR_NONE  = 10,		-- 无职业

	-- 最大等级
	CHARACTER_LEVEL_MAX = 200, -- 最大等级200级

	-- 血条索引ID
	CHARACTER_HP_INDEX_MAX_HP = 1,	 -- 最内层血条
	CHARACTER_HP_INDEX_MAX_HP_2 = 2, -- 内层幻兽血条
	CHARACTER_HP_INDEX_MAX_HP_3 = 3, -- 外层幻兽血条
	
	-- 角色默认出生点信息
	CHARACTER_DEFAULT_SCENE_ID = 10020,
	CHARACTER_DEFAULT_POS_X = 29,
	CHARACTER_DEFAULT_POS_Y = 20,
	CHARACTER_DEFAULT_DIRECTION = 60,

	-- 角色默认初始速度
	CAHRACTER_DEFAULT_SPEED = 6,

	CHARACTER_NUM_MAX = 100,		-- 一个玩家最大可拥有的角色个数
	
	RELIVE_CD_SECONDS = 10,			-- 复活等待时间

	CHARACTER_FOV_SIZE = 12,		-- 视野

	-- 角色默认 BODY_SIZE
	CHARACTER_BODY_SIZE = 0,

	-- 角色移动速度
	CHARACTER_DEFAULT_JUMP_DISTANCE = 12,	-- 默认跳跃最大距离

	-- 角色性别信息
	CHARACTER_GENDER_MAN = 1,		-- 性别：男
	CHARACTER_GENDER_WOMAN = 2,		-- 性别：女
	
	-- 角色是否在线
	IS_ONLINE_YES = 1,
	IS_ONLINE_NO  = 0,

	-- 角色元宝状态
	GOLD_STATE_IS_NOT_CHECKED = 0,	-- 未与平台对账
	GOLD_STATE_IS_CHECKED     = 1,	-- 已经与平台对账

	-- 角色身上保护类型
	PROTECT_TYPE_ID_FOR_RELIVE = 1,		 -- 死亡复活保护
	PROTECT_TYPE_ID_FOR_ENTER_SCENE = 2, -- 进入场景保护

	-- 角色身上的保护状态默认时间
	SAFE_TIME_FOR_ENTER_SCENE = 10,		-- 进入新场景有10秒保护(玩家一移动/攻击，立刻取消保护)
	SAFE_TIME_FOR_NO_ENTER_SCENE_MAX = 5000,	--非进入场景保护的其他保护最大时间
	SAFE_TIME_FOR_RELIVE	  = 5,		-- 原地复活有5秒保护
	
	-- 角色是否能够做什么事
	DO_TYPE_FOR_MOVE = 1,	-- 是否允许移动
	DO_TYPE_FOR_GATHER = 2,	-- 是否允许采集

	-- 角色属性上限
	MAX_LIMIT_EXP = 2147483646,				-- 经验最大值
	MAX_LIMIT_SILVER = 999999999,			-- 银两
	MAX_LIMIT_GOLD	 = 999999999,			-- 元宝
	MAX_LIMIT_ZHENQI  = 9999999,			-- 真气
	MAX_LIMIT_HORNOR  = 999999999,			-- 荣誉
	MAX_LIMIT_CONTRIBUTE = 9999999,			-- 帮贡
	MAX_LIMIT_MUHON = 9999999,				-- 武魂
	MAX_LIMIT_HP = 9999999,					-- HP
	MAX_LIMIT_ATTACK = 99999,				-- 攻击力
	MAX_LIMIT_DEFFENCE = 99999,				-- 防御
	MAX_LIMIT_HIT = 99999,					-- 命中
	MAX_LIMIT_DODGE = 99999,				-- 闪避
	MAX_LIMIT_CRITICAL_HIT = 99999,			-- 暴击
	MAX_LIMIT_CRITICAL_HIT_RESIST = 99999,	-- 招架
	MAX_LIMIT_VIT = 150,					-- 体力(仅定时回复的时候限制)
	MAX_LIMIT_ENDURANCE = 50,				-- 耐力(仅定时回复的时候限制)
	MAX_LIMIT_SHOUHUN = 9999999,			-- 兽魂
	MAX_LIMIT_INVITE_SCORE = 9999999,		-- 推广积分

	-- 角色经验加成类型
	EXP_RADIX_TYPE_ID_FOR_SUBLINE_TEAM = 1, -- 副本组队经验加成
	
	RMB_2_GOLD_NUM = 10,					-- 人民币兑换的元宝数量
	
	--角色被封的状态
	BAN_STATUS_NO_BAN = 0,					-- 正常（未封停、禁言)
	BAN_STATUS_BAN = 1,						-- 封停
	BAN_STATUS_FORBID_TALK_GM = 2,			-- 禁言	（gm)
	BAN_STATUS_FORBID_TALK_PLAYER = 3,		-- 禁言	(玩家)
	
	-- 持久化类型
	SAVE_TYPE_NORMAL = 1,					--定时持久化
	SAVE_TYPE_LOGOUT = 21,					--离线持久化
	
	-- 角色x秒自动持久化一次(别少于60秒，不然也不会有效果)
	CHARACTER_DEFAULT_SAVE_TO_DB_SECOND = 60,--单位秒 --TODO 改为300秒
	
	-- 体力
	CHARACTER_VIT_RESTORE_INTERVAL = 6,			-- 体力每X分钟回复一点 单位：分钟
	
	-- 耐力
	CHARACTER_ENDURANCE_RESTORE_INTERVAL = 15,	-- 体力每X分钟回复一点 单位：分钟
	
	-- 体力免费领取的时间段
	vit_free_fetch_time_area = {{12, 18}, {18, 24}},
	
	-- 每次免费领取的体力点数
	FREE_FETCH_VIT_PER = 50,
}
AsReadOnly(CharacterDefs)