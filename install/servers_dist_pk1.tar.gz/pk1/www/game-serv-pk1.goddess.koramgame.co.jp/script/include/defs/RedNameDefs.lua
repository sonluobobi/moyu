--------------------------------------------------------------------------------
-- 红名相关定义
--------------------------------------------------------------------------------

RedNameDefs = {
	-- 红名状态
	RED_NAME_STATUS_SAVE 	= 99,	--保护状态(刀剑决用到)
	RED_NAME_STATUS_NORMAL 	= 0,	--正常状态
	RED_NAME_STATUS_LIGHT 	= 1,	--轻度红名
	RED_NAME_STATUS_MIDDLE 	= 2,	--中度红名
	RED_NAME_STATUS_SERIOUS = 3,	--重度红名
	
	-- 各红名状态对应的BUFFER ID
	redname_status2buffer_ids = {},
	
	MAX_LIMIT_REDNAME = 30,				-- 最大红名点
	REDNAME_AUTO_REDUCE_INTERVAL = 2,	-- 自动消除红名的时间间隔(单位：分)
	TO_REDNAME_MIN_VALUE = 3,			-- 变红名的最小点数
}

RedNameDefs.redname_status2buffer_ids[RedNameDefs.RED_NAME_STATUS_LIGHT] = {50000001, 50000002}
RedNameDefs.redname_status2buffer_ids[RedNameDefs.RED_NAME_STATUS_MIDDLE] = {50000003, 50000004}
RedNameDefs.redname_status2buffer_ids[RedNameDefs.RED_NAME_STATUS_SERIOUS] = {50000005, 50000006}
