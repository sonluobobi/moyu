--[[
小地图定义文件
author : xingzeng
date : 2015-04-21
--]]

ScenarioDefs = ScenarioDefs or {

-- 转换怪物波次类型定义
CALL_M_PHASE_TYPE_NORMAL = 0,		-- 普通
CALL_M_PHASE_TYPE_CIRCLE = 1,		-- 循环出现(陷阱)
CALL_M_PHASE_TYPE_SIT_RAND = 2,		-- 占位随机(光棱塔)

}


AsReadOnly(ScenarioDefs)