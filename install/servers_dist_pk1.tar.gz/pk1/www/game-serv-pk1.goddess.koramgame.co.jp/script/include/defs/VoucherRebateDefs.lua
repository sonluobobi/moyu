--[[
测试返利系统 service
author : jianzhu.liu
date : 2016-06-16
]]--

local my_area_id = (external and external.getVouchAid and external.getVouchAid()) or 0

VoucherRebateDefs = {
	
}

--判断是否有测试返利
function VoucherRebateDefs:checkIsOpen()
	--if Language:isTestServ() then return true end

	--[[
	if my_area_id >= 2078980 and my_area_id <= 2078999 then
		return true
	end
	--]]

	if my_area_id == 2078011 or my_area_id == 2106011 then 
		return true
	end

	return false
end

