--[[
语音录制定义
author : biquan.xu
date : 2016-02-19
--]]

VoiceRecordType =
{
	VOICE_RECORD_CHAT = 1 , --语音聊天
	VOICE_RECORD_FLOWER_COMPETE = 2 , --魅力竞赛
	VOICE_RECORD_CHANNEL_BUTTON_WORLD = 3, -- 世界图标
	VOICE_RECORD_CHANNEL_BUTTON_GANG = 4, -- 军团图标
}

