--[[
服务器定义
author : suwin zhong
date : 2013-04-26
$Id: $
--]]

local strFind = string.find

ServerDefs =
{
	cn_android = {},	-- 国内安卓
	cn_ios = {},		-- 国内IOS
	cn_yyb = {},		-- 国内应用宝

	ouzhou = {},		-- 欧洲
	beimei = {},		-- 北美
	beimei_new = {},	-- 北美(新)
	nanmei = {},		-- 南美
	dongnanya = {},		-- 东南亚
	riben = {},			-- 日本
	hanguo = {},		-- 韩国
}

-- 合服配置区
-- 简体 国内IOS start
-- ServerDefs.cn_ios[155203] = 1
-- 简体 国内IOS end

-------------------------------------------------------------------------------------------------
-- 获取一个服务器的名字前缀(用于跨服排行榜和跨服名字前缀)
-- is_need_underline : 是否需要下划线
-- return string
function ServerDefs:getServerName(is_need_underline, area_id)
	-- 大区id
	local area_id = area_id
	if not area_id then
		area_id = external and external.getVouchAid() or 2078001
	end

	local server_title = 's'
	local server_id = 0

	----------------------------------------------------------------------------------------

	if Language:isWorldAreaOuZhou(area_id) then
		-- 欧洲
		server_id = ServerDefs.ouzhou[area_id] or (area_id - 4108000)

	elseif Language:isWorldAreaBeiMei(area_id) then
		-- 北美
		server_id = ServerDefs.beimei[area_id] or (area_id - 4109000)
	
	elseif Language:isWorldAreaBeiMeiNew(area_id) then
		-- 北美(新)
		server_id = ServerDefs.beimei_new[area_id] or (area_id - 4140000)

	elseif Language:isWorldAreaNanMei(area_id) then
		-- 南美
		server_id = ServerDefs.nanmei[area_id] or (area_id - 4110000)

	elseif Language:isWorldAreaDongNanYa(area_id) then
		-- 东南亚
		server_id = ServerDefs.dongnanya[area_id] or (area_id - 4111000)

	elseif Language:isWorldAreaRiBen(area_id) then
		-- 日本
		server_id = ServerDefs.riben[area_id] or (area_id - 4112000)

	elseif Language:isWorldAreaHanGuo(area_id) then
		-- 韩国
		server_id = ServerDefs.hanguo[area_id] or (area_id - 4113000)

	else
		-- 中国
		if Language:isCnAreaAndroid() then
			if (area_id < 2078990) then
				-- 安卓正式服
				server_id = ServerDefs.cn_android[area_id] or (area_id - 2078010)
			else
				-- 安卓测试服
				server_title = 't'
				server_id = (area_id - 2078989)
			end
		elseif Language:isCnAreaIos() then
			if (area_id < 2104990) then
				-- IOS正式服
				server_id = ServerDefs.cn_ios[area_id] or (area_id - 2104010)
			else
				-- IOS测试服
				server_title = 't'
				server_id = (area_id - 2104989)
			end
		else
			if (area_id < 2106990) then
				-- 应用宝正式服
				server_id = ServerDefs.cn_yyb[area_id] or (area_id - 2106010)
			else
				-- 应用宝测试服
				server_title = 't'
				server_id = (area_id - 2106989)
			end
		end
	end

	----------------------------------------------------------------------------------------

	local the_name = server_title .. server_id

	-- 需要下划线
	if is_need_underline then
		the_name = the_name .. '_'
	end

	return the_name
end