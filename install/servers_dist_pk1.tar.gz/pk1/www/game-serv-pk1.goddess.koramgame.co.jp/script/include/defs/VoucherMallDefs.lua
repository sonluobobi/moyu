--[[
充值商城 定义
author : xingzeng
date : 2016-01-08
$Id: $
--]]

VoucherMallDefs = 
{
	VOUCHER_MALL_SORT_NORMAL = 0,			--普通充值
	VOUCHER_MALL_SORT_CARD = 1,				--购买活动卡(月卡，终身卡，基金)
	VOUCHER_MALL_SORT_REWARD_GOLD = 2,		--充值赠送元宝类
	VOUCHER_MALL_SORT_SHENHE = 10,			--审核服专属类，仅审核服显示
	
	-- ID定义
	VOUCHER_MALL_ID_MONTH_CARD = 1,			--月卡
	VOUCHER_MALL_ID_LIFELONG_CARD = 2,		--终身卡
	VOUCHER_MALL_ID_FUND_CARD = 3,			--基金
	
	--GOOGLE兑换码的使用状态
	GOOGLE_CODE_STATE_NO_GOOGLE_CONFIRM_USE = 0,	--未去google消费订单
	GOOGLE_CODE_STATE_GOOGLE_CONFIRM_USEED = 1,		--已消费google订单
	
	-- 充值订单返现状态
	ORDER_STATE_NO_REWARD = 0,				-- 未发奖
	ORDER_STATE_REWARDING = 1,				-- 发奖中
	ORDER_STATE_REWARDED = 2,				-- 已发奖
	ORDER_STATE_CANNOT_REWARD = 3,			-- 不用发奖(发奖次数已满)
	
	-- 第三方充值的首冲返现比例
	OTHER_FANXIAN_PERC_SHOUCH = 1,			-- 第三方充值首冲返现100%
	OTHER_FANXIAN_PERC = 0.05,				-- 第三方充值返现5%
}

AsReadOnly(VoucherMallDefs)