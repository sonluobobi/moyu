--[[
神兵系统Defs
author : guoyin.huang
date : 2016-06-14
]]--

ShenbingDefs = {
	

	SHENBING_ELEMENT_BEGIN = 1,
	SHENBING_ELEMENT_FENG = 1,	--元素风
	SHENBING_ELEMENT_SHUI = 2,	--元素水
	SHENBING_ELEMENT_HUO = 3,	--元素火
	SHENBING_ELEMENT_END = 3,
	
	SHENBING_MULTI_RATE = {},

	XILIAN_OWN_CH = 1,		--角色所有
	XILIAN_OWN_F_PET = 2,	--出战幻兽所有
	XILIAN_OWN_HT_N = 3, 	--合体内
	XILIAN_OWN_HT_W = 4,	--合体外

	XILIAN_ATTRIB_NUM = 5,			--洗出来的属性条数

	DEFAULT_SB_LV = 1,		--默认神兵等级
}

-- 获取倍数
function ShenbingDefs:getMulti(  )
	local random_num = math.random(1, 100)
	if random_num <= 5 then 
		return 5
	end
	if random_num <= 25 then 
		return 2
	end
	return 1
end

ShenbingDefs.star_random = {1000000,800000,600000,400000,300000,200000,100000,70000,30000,14000,13000,12000,11000,10000,8740,7480,6220,4960,3700,2440,2320,2200,2080,1960,1840,1720,1600,1480,1360,1240,1175,1110,1045,980,915,850,785,720,655,590,570,550,530,510,490,470,450,430,410,390,380,370,360,350,340,330,320,310,300,290}

function ShenbingDefs:randomStar(min_star, max_star)
	local total_weight = 0
	for i=min_star, max_star do
		total_weight = total_weight + ShenbingDefs.star_random[i]
	end

	local random_weight = math.random(1, total_weight)
	for i=min_star, max_star do
		random_weight = random_weight - ShenbingDefs.star_random[i]
		if random_weight <= 0 then 
			return i
		end
	end
	assert(false)
end