--[[
幻兽定义文件
author : xingzeng
date : 2014-10-11
--]]

PetDefs = PetDefs or 
{
	-- 幻兽类型
	PET_SORT_ID_BEGIN = 3,	-- 幻兽类型BEGIN
	PET_SORT_ID_XUEZU = 3,	-- 血族型
	PET_SORT_ID_ZHHUANSHI = 4,	-- 召唤师型
	PET_SORT_ID_ZHANSHI = 5,		-- 战士型
	PET_SORT_ID_HP = 6,			-- 生命型
	PET_SORT_ID_END = 6,		-- 幻兽类型END
	PET_SORT_ID_ZHHUANSHI_DEFENCE_PHY = 7,		-- 魔防物防型(暂未使用)
	
	-- 可以出战的幻兽类型列表(注：已无限制)
	enable_fight_pet_sort_ids = {},		--type:Hashtable
	
	MAX_PET_LEVEL = 200,			-- 幻兽最大等级
	HUANHUA_NEED_PET_LEVEL = 10,	-- 幻化需要幻兽最低等级
	INIT_MAX_OWN_PET_NUM = 150,		-- 初始拥有幻兽数量上限
	MAX_OWN_PET_NUM = 300,			-- 最大可拥有幻兽数量上限
	MAX_OWN_PET_NUM_THEORY = 300,	-- 理论最大可拥有幻兽数量上限
	PET_INIT_LEVEL = 15,			-- 幻兽初始等级
	MAX_ZIZHI = 10,					-- 最大资质
	
	-- 断交方式
	FREE_PET_OP_ID_HUANHUA = 1,		-- 幻化吞噬断交
	FREE_PET_OP_ID_JITAN_XIANJI = 2,-- 祭坛献祭断交
	
	-- 合体位置定义(注：客户端有写死，不能修改)
	HETI_POS_START = 1,
	HETI_POS_IN = 1,				-- 合体里
	HETI_POS_OUT = 2,				-- 合体外
	HETI_POS_END = 2,
	
	-- 幻兽品阶
	PET_QUALITY_ID_GREEN  = 1,			--绿色
	PET_QUALITY_ID_BLUE   = 2,			--蓝色
	PET_QUALITY_ID_PURPLE = 3,			--紫色
	PET_QUALITY_ID_GOLD = 4,			--金色
	PET_QUALITY_ID_RED = 5,				--红色
		
	-- 幻兽资质(只有蓝色品阶以上才有4种资质，绿品阶只有1、2两种资质)
	PET_APTITUDE_ID_BEGIN = 1,
	--绿品阶
	PET_APTITUDE_ID_1   = 1,			
	PET_APTITUDE_ID_2   = 2,			
	
	--蓝品阶
	PET_APTITUDE_ID_3   = 3,			
	PET_APTITUDE_ID_4   = 4,			
	PET_APTITUDE_ID_5   = 5,			
	PET_APTITUDE_ID_6   = 6,			
	
	--紫品阶
	PET_APTITUDE_ID_7   = 7,			
	PET_APTITUDE_ID_8   = 8,			
	PET_APTITUDE_ID_9   = 9,			
	PET_APTITUDE_ID_10  = 10,	

	--金品阶
	PET_APTITUDE_ID_11  = 11,	

	PET_APTITUDE_ID_END = 10,

	--定义砸蛋类型
	HIT_EGG_TYPE_ID_GREEN  = 1, -- 绿蛋
	HIT_EGG_TYPE_ID_BLUE   = 2, -- 蓝蛋
	HIT_EGG_TYPE_ID_PURPLE = 3, -- 紫蛋
	HIT_EGG_TYPE_ID_GOLD   = 4,	-- 金蛋
	
	HIT_EGG_TYPE_ID_BEGIN = 1,
	HIT_EGG_TYPE_ID_END   = 3,
	
	-- 幻兽天赋类型
	PET_TIANFU_SORT_ID_NORMAL = 0,	-- 普通
	PET_TIANFU_SORT_ID_BUFFER = 1,	-- 幻兽死亡触发的BUFFER
	
	-- 合体幻兽天赋激活类型
	PET_HT_TIANFU_ACTIVE_SORT_LIVE = 0,		-- 活的时候激活
	PET_HT_TIANFU_EFFECT_SORT_SHOUJI = 1,	-- 活且为受击者时激活
	
	--初始化砸蛋免费次数
	hit_egg_type_2_free_num = {},
	
	--幻兽品阶跟获得免费砸蛋时间间隔映射(秒)
	hit_egg_type_2_interval = {},
	
	--砸蛋类型跟获得幻兽品阶的权重映射
	hit_egg_type_2_weight = {},
	
		
	--第10次砸蛋刷出紫色幻兽各个资质的权重
	pet_aptitude_2_weight = {},
	
	--[[
	当计数器n=9，下一次必定刷出紫色幻兽。
	正常情况下按照以上的权重随机刷出一个幻兽。
	但如果连续x次没有刷出紫色1幻兽，下一次计数器刷出的幻兽必定为紫色1.
	目前参与保底的幻兽品阶为紫色1、紫色2和紫色3
	]]
	refresh_pet_baodi_config = {},
	
	--连续砸蛋次数
	multi_hit_egg = 10,
	
	--兽魂祭坛刷新免费次数
	jitan_free_refresh_num = 2,
	
	--兽魂商店获得免费刷新次数的时间间隔(秒),7200
	get_free_refresh_interval = 7200, --测试修改
	
	--品阶跟资质对应关系
	pet_quality_2_aptitude = {},
	
	--批次砸蛋的折扣(乘以十不能为小数)
	multi_discount = 0.9,
	
	-- 幻兽阵法位置总个数
	PET_TROOP_NUM_FREE_MAX = 7,
	PET_TROOP_NUM_MAX = 10,
	
	-- 一个金蛋对应的积分
	SCORE_PET_GOLD_EGG = 10,	
	-- 红女神祈祷对应的积分
	SCORE_PET_RED_GODD = 10,
	-- 红女神祈祷保底
	PET_REDGODD_BAODI_REWARD = 400,

	-- 多少分可以领取保底奖励
	PET_GOLD_EGG_BAODI_REWARD = 200,
	
	-- 多少次必出金幻兽
	PET_GOLD_EGG_BAODI_CISHU = 56,

	-- 出金幻兽的概率
	PET_GOLD_EGG_RADIUS = 0.0268,
}

-- 可以出战的幻兽类型列表
local enable_fight_pet_sort_ids = PetDefs.enable_fight_pet_sort_ids
enable_fight_pet_sort_ids[PetDefs.PET_SORT_ID_ZHANSHI] = 1
enable_fight_pet_sort_ids[PetDefs.PET_SORT_ID_ZHHUANSHI] = 1
enable_fight_pet_sort_ids[PetDefs.PET_SORT_ID_XUEZU] = 1
enable_fight_pet_sort_ids[PetDefs.PET_SORT_ID_HP] = 1
	
-------------------- 幻兽刷新相关 start ----------------------------------------------------


--品阶跟资质对应关系
PetDefs.pet_quality_2_aptitude[PetDefs.PET_QUALITY_ID_GREEN] =
{
	[PetDefs.PET_APTITUDE_ID_1] = 1,
	[PetDefs.PET_APTITUDE_ID_2] = 2,
}

PetDefs.pet_quality_2_aptitude[PetDefs.PET_QUALITY_ID_BLUE] =
{
	[PetDefs.PET_APTITUDE_ID_3] = 3,
	[PetDefs.PET_APTITUDE_ID_4] = 4,
	[PetDefs.PET_APTITUDE_ID_5] = 5,
	[PetDefs.PET_APTITUDE_ID_6] = 6,
}

PetDefs.pet_quality_2_aptitude[PetDefs.PET_QUALITY_ID_PURPLE] =
{
	[PetDefs.PET_APTITUDE_ID_7] = 7,
	[PetDefs.PET_APTITUDE_ID_8] = 8,
	[PetDefs.PET_APTITUDE_ID_9] = 9,
	[PetDefs.PET_APTITUDE_ID_10] = 10,
}

--刷新次数保底配置
PetDefs.refresh_pet_baodi_config[PetDefs.PET_QUALITY_ID_PURPLE]  = 
{
	-- 资质->保底次数
	[PetDefs.PET_APTITUDE_ID_10] = 120,
	[PetDefs.PET_APTITUDE_ID_9]  = 60,
	[PetDefs.PET_APTITUDE_ID_8]  = 40,
}


--第10次砸蛋刷出紫色幻兽各个资质的权重
PetDefs.pet_aptitude_2_weight[PetDefs.PET_QUALITY_ID_PURPLE]  = 
{
	--紫色品阶
	[PetDefs.PET_QUALITY_ID_PURPLE] = 
	{
		--各资质权重
		[PetDefs.PET_APTITUDE_ID_10] = 2,
		[PetDefs.PET_APTITUDE_ID_9]   = 5,
		[PetDefs.PET_APTITUDE_ID_8]   = 10,
		[PetDefs.PET_APTITUDE_ID_7]   = 83,
	}
}
--第10次跨金蛋刷出紫色幻兽各个资质的权重
PetDefs.pet_aptitude_2_weight[PetDefs.PET_QUALITY_ID_GOLD]  = 
{
	--紫色品阶
	[PetDefs.PET_QUALITY_ID_PURPLE] = 
	{
		--各资质权重
		[PetDefs.PET_APTITUDE_ID_10] = 199,
		[PetDefs.PET_APTITUDE_ID_9]   = 499,
		[PetDefs.PET_APTITUDE_ID_8]   = 997,
		[PetDefs.PET_APTITUDE_ID_7]   = 8279,
	},
}


--根据幻兽品阶获得免费砸蛋时间间隔
function PetDefs:getPetAptitudeWeightByType(egg_type)
	return self.pet_aptitude_2_weight[egg_type]
end


--初始化砸蛋免费次数
PetDefs.hit_egg_type_2_free_num[PetDefs.PET_QUALITY_ID_GREEN]  = 5
PetDefs.hit_egg_type_2_free_num[PetDefs.PET_QUALITY_ID_BLUE]   = 1
PetDefs.hit_egg_type_2_free_num[PetDefs.PET_QUALITY_ID_PURPLE] = 1
PetDefs.hit_egg_type_2_free_num[PetDefs.PET_QUALITY_ID_GOLD] = 1

--根据幻兽品阶获得免费砸蛋时间间隔
function PetDefs:getHitFreeNumByEggType(egg_type)
	return self.hit_egg_type_2_free_num[egg_type]
end


--幻兽品阶跟获得免费砸蛋时间间隔映射(秒)
PetDefs.hit_egg_type_2_interval[PetDefs.PET_QUALITY_ID_GREEN]  = 300  --5分钟  
PetDefs.hit_egg_type_2_interval[PetDefs.PET_QUALITY_ID_BLUE]    = 86400   --86400
PetDefs.hit_egg_type_2_interval[PetDefs.PET_QUALITY_ID_PURPLE] = 259200  --259200
PetDefs.hit_egg_type_2_interval[PetDefs.PET_QUALITY_ID_GOLD] = 43200  --259200

--根据幻兽品阶获得免费砸蛋时间间隔
function PetDefs:getHitIntervalByEggType(egg_type)
	return self.hit_egg_type_2_interval[egg_type]
end


PetDefs.redgodd_interval  = 43200  --12小时  
PetDefs.redgodd_free_num = 3
function PetDefs:getFreeNum()
    return PetDefs.redgodd_free_num
end
--红女神免费砸蛋间隔
function PetDefs:getRedPrayInterval()
    return PetDefs.redgodd_interval
end

---------------砸蛋类型跟获得幻兽品阶的权重映射 start --------------------------------
--砸绿蛋
PetDefs.hit_egg_type_2_weight[PetDefs.PET_QUALITY_ID_GREEN]  = 
{
	[PetDefs.PET_QUALITY_ID_GREEN]  = 
	{
		[PetDefs.PET_APTITUDE_ID_1] = 5749,
		[PetDefs.PET_APTITUDE_ID_2] = 2500,
	},
	
	[PetDefs.PET_QUALITY_ID_BLUE]  = 
	{
		[PetDefs.PET_APTITUDE_ID_3] = 1000,
		[PetDefs.PET_APTITUDE_ID_4] = 450,
		[PetDefs.PET_APTITUDE_ID_5] = 200,
		[PetDefs.PET_APTITUDE_ID_6] = 100,
	},
	
	[PetDefs.PET_QUALITY_ID_PURPLE]  = 
	{
		[PetDefs.PET_APTITUDE_ID_7] = 1,
		[PetDefs.PET_APTITUDE_ID_8] = 0,
		[PetDefs.PET_APTITUDE_ID_9] = 0,
		[PetDefs.PET_APTITUDE_ID_10] = 0,
	},
	
}

--砸蓝蛋
PetDefs.hit_egg_type_2_weight[PetDefs.PET_QUALITY_ID_BLUE]  = 
{
	[PetDefs.PET_QUALITY_ID_GREEN]  = 
	{
		[PetDefs.PET_APTITUDE_ID_1] = 0,
		[PetDefs.PET_APTITUDE_ID_2] = 0,
	},
	
	[PetDefs.PET_QUALITY_ID_BLUE]  = 
	{
		[PetDefs.PET_APTITUDE_ID_3] = 379,
		[PetDefs.PET_APTITUDE_ID_4] = 300,
		[PetDefs.PET_APTITUDE_ID_5] = 200,
		[PetDefs.PET_APTITUDE_ID_6] = 100,
	},
	
	[PetDefs.PET_QUALITY_ID_PURPLE]  = 
	{
		[PetDefs.PET_APTITUDE_ID_7] = 20,
		[PetDefs.PET_APTITUDE_ID_8] = 1,
		[PetDefs.PET_APTITUDE_ID_9] = 0,
		[PetDefs.PET_APTITUDE_ID_10] = 0,
	},
}

--砸紫蛋
PetDefs.hit_egg_type_2_weight[PetDefs.PET_QUALITY_ID_PURPLE]  = 
{
	[PetDefs.PET_QUALITY_ID_GREEN]  = 
	{
		[PetDefs.PET_APTITUDE_ID_1] = 0,
		[PetDefs.PET_APTITUDE_ID_2] = 0,
	},
	
	[PetDefs.PET_QUALITY_ID_BLUE]  = 
	{
		[PetDefs.PET_APTITUDE_ID_3] = 0,
		[PetDefs.PET_APTITUDE_ID_4] = 0,
		[PetDefs.PET_APTITUDE_ID_5] = 483,
		[PetDefs.PET_APTITUDE_ID_6] = 300,
	},
	
	[PetDefs.PET_QUALITY_ID_PURPLE]  = 
	{
		[PetDefs.PET_APTITUDE_ID_7] = 150,
		[PetDefs.PET_APTITUDE_ID_8] = 50,
		[PetDefs.PET_APTITUDE_ID_9] = 12,
		[PetDefs.PET_APTITUDE_ID_10] = 5,
	},
	
}

--砸金蛋
PetDefs.hit_egg_type_2_weight[PetDefs.PET_QUALITY_ID_GOLD]  = 
{
	[PetDefs.PET_QUALITY_ID_GREEN]  = 
	{
		[PetDefs.PET_APTITUDE_ID_1] = 0,
		[PetDefs.PET_APTITUDE_ID_2] = 0,
	},
	
	[PetDefs.PET_QUALITY_ID_BLUE]  = 
	{
		[PetDefs.PET_APTITUDE_ID_3] = 0,
		[PetDefs.PET_APTITUDE_ID_4] = 0,
		[PetDefs.PET_APTITUDE_ID_5] = 4817,
		[PetDefs.PET_APTITUDE_ID_6] = 2992,
	},
	
	[PetDefs.PET_QUALITY_ID_PURPLE]  = 
	{
		[PetDefs.PET_APTITUDE_ID_7] = 1496,
		[PetDefs.PET_APTITUDE_ID_8] = 499,
		[PetDefs.PET_APTITUDE_ID_9] = 120,
		[PetDefs.PET_APTITUDE_ID_10] = 50,
	},
}

--根据砸蛋类型获得刷出幻兽的权重
function PetDefs:getWeightByEggType(egg_type)
	return self.hit_egg_type_2_weight[egg_type]
end


--职业第一次砸蛋一定出的幻兽列表
PetDefs.prof_2_first_egg_pet_id = {
	[PetDefs.HIT_EGG_TYPE_ID_GREEN] = {
		[1] = 500305,
		[2] = 500306,
		[3] = 500303,
	},
	[PetDefs.HIT_EGG_TYPE_ID_BLUE] = {
		[1] = 500504,
		[2] = 500504,
		[3] = 500504,
	},
	[PetDefs.HIT_EGG_TYPE_ID_PURPLE] = {
		[1] = 500705,
		[2] = 500706,
		[3] = 500703,
	},		
}
---------------砸蛋获得幻兽品阶的权重映射 end --------------------------------

---------------幻兽祭坛刷出权重 start ----------------------------------------
-- 含女神
PetDefs.pet_jitan_type_2_weight = {
	[PetDefs.PET_SORT_ID_XUEZU] = 168,
	[PetDefs.PET_SORT_ID_ZHHUANSHI] = 168,
	[PetDefs.PET_SORT_ID_HP] = 168,
	[PetDefs.PET_SORT_ID_ZHANSHI] = 168,
	other = 13,
	goddess = 303,
	gold_equip = 13,
}

-- 不含女神
PetDefs.pet_jitan_type_2_weight_no_ns = {
	[PetDefs.PET_SORT_ID_XUEZU] = 244,
	[PetDefs.PET_SORT_ID_ZHHUANSHI] = 244,
	[PetDefs.PET_SORT_ID_HP] = 244,
	[PetDefs.PET_SORT_ID_ZHANSHI] = 244,
	other = 12,	
	gold_equip = 12,
}

function PetDefs:getRandomPetSortId(is_use_goddess)
	if is_use_goddess then
		return math.randomIndex2(PetDefs.pet_jitan_type_2_weight)
	else
		return math.randomIndex2(PetDefs.pet_jitan_type_2_weight_no_ns)
	end
end

PetDefs.pet_jitan_best_pet_2_weight = {
	[PetDefs.PET_APTITUDE_ID_7] = {			-- 最高可刷出资质
		[PetDefs.PET_APTITUDE_ID_7] = 87,	-- 资质7
	}, 
	[PetDefs.PET_APTITUDE_ID_8] = {
		[PetDefs.PET_APTITUDE_ID_7] = 62,	-- 资质7
		[PetDefs.PET_APTITUDE_ID_8] = 25,	-- 资质8
	}, 
	[PetDefs.PET_APTITUDE_ID_9] = {
		[PetDefs.PET_APTITUDE_ID_7] = 20,	-- 资质7
		[PetDefs.PET_APTITUDE_ID_8] = 42,	-- 资质8
		[PetDefs.PET_APTITUDE_ID_9] = 25,	-- 资质9
	}, 	
	[PetDefs.PET_APTITUDE_ID_10] = {
		[PetDefs.PET_APTITUDE_ID_7] = 12,	-- 资质7
		[PetDefs.PET_APTITUDE_ID_8] = 18,	-- 资质8
		[PetDefs.PET_APTITUDE_ID_9] = 32,	-- 资质9
		[PetDefs.PET_APTITUDE_ID_10] = 25,	-- 资质10
	},
}

function PetDefs:getRandomAptitude(max_aptitude_from_sort)
	local item = assert(PetDefs.pet_jitan_best_pet_2_weight[max_aptitude_from_sort])
	return math.randomIndex2(item)
end
---------------幻兽祭坛刷出权重 end ----------------------------------------
-------------------- 幻兽刷新相关 end ---------------------------------------------------------

--获取某个品阶的装备颜色
PetDefs.quality2color = {}
PetDefs.quality2color[PetDefs.PET_QUALITY_ID_GREEN] = 'green1'
PetDefs.quality2color[PetDefs.PET_QUALITY_ID_BLUE] = 'blue1'
PetDefs.quality2color[PetDefs.PET_QUALITY_ID_PURPLE] = 'purple1'
PetDefs.quality2color[PetDefs.PET_QUALITY_ID_GOLD] = 'gold8'
function PetDefs:getColorByQuality( quality )
	return PetDefs.quality2color[quality]
end

do
local format = '{pet_title:%d}'
local string_format = string.format
	function PetDefs:getPetFmtByEid( pet_id )
		return string_format(format, pet_id)
	end
end

AsReadOnly(PetDefs)

