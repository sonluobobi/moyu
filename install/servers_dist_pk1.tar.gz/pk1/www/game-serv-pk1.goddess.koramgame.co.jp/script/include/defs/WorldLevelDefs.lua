--[[
	世界等级定义
]]
WorldLevelDefs = {
	WORLD_LV_EXP_DAILYTASK = 1,		--每日任务经验加成
	WORLD_LV_EXP_TOLLGATE = 2,		--关卡
	WORLD_LV_EXP_LINWEI = 3,		--临危

	LV_LOWER_THAN_WL = 4,		--低于世界等级多少级才享有
	MIN_LV_ADD_EXP = 45,		--多少级的玩家才可拥有经验加成

	sortid_2_exp_raidx = nil,
}

WorldLevelDefs.sortid_2_exp_raidx = {
	[WorldLevelDefs.WORLD_LV_EXP_DAILYTASK] = true,
	[WorldLevelDefs.WORLD_LV_EXP_TOLLGATE] = true,
	[WorldLevelDefs.WORLD_LV_EXP_LINWEI] = true,
}

function WorldLevelDefs:getExpRadix(sort_id, world_level, character_level)
	if not WorldLevelDefs.sortid_2_exp_raidx[sort_id]   	-- 不支持
	or character_level < WorldLevelDefs.MIN_LV_ADD_EXP 		-- 等级不够
	or world_level - character_level <= WorldLevelDefs.LV_LOWER_THAN_WL then -- 等级距离世界等级太近
		return 1
	else
		local LV_LOWER_THAN_WL = WorldLevelDefs.LV_LOWER_THAN_WL
		if character_level > 150 then 
			LV_LOWER_THAN_WL = 20
		elseif character_level > 120 then 
			LV_LOWER_THAN_WL = 16
		elseif character_level > 100 then 
			LV_LOWER_THAN_WL = 12
		elseif character_level > 80 then 
			LV_LOWER_THAN_WL = 8
		else
			LV_LOWER_THAN_WL = 4
		end			

		if world_level - LV_LOWER_THAN_WL - character_level <= 1 then return 1 end 
		
		local add_perc = math.log(world_level - LV_LOWER_THAN_WL - character_level)
		if add_perc < 0 then add_perc = 0 end
		if add_perc > 10 then add_perc = 10 end
		return 1 + add_perc

	end
end
