--------------------------------------------------------------------------------
-- 场景坐标
-- guoyin.huang
--------------------------------------------------------------------------------

ScenePositionDefs = {
	SCENE_POSITION_TYPE_MONSTER = 1,	-- 怪物出生点
	SCENE_POSITION_TYPE_CAIJI = 2,		-- 采集
	SCENE_POSITION_TYPE_WABAO = 3,		-- 挖宝
	SCENE_POSITION_TYPE_NPC = 4,		-- NPC位置
}
