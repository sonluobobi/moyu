--[[
角色通用奖励定义
author : guoiyin.huang
date : 2014-11-20
$Id: $
--]]

RewardDefs =
{
	-- 奖励包类型定义
	REWARD_SORT_ID_COMMON = 1,			-- 普通奖励包

	--------- 奖励包奖励收益类型定义 start --------------	
	-- 影响包裹
--	REWARD_INCOME_SORT_ID_EQUIP			 = 'equips',		-- 道具
	
	-- 下面类型不会直接影响角色属性
--	REWARD_INCOME_SORT_ID_SCORE			 = 'score',			-- 积分
--	REWARD_INCOME_SORT_ID_RANK			 = 'rank',			-- 排名
--	REWARD_INCOME_SORT_ID_INTRO_ID		 = 'intro_id',		-- 奖励描述文字语言包ID
	
	REWARD_EXPIRE_TIME = 1296000,			-- 奖励包保留15天
	REWARD_COUNT_MAX = 50,					-- 同类奖励包最多累计20份
	
	-- 奖励包的状态定义 (奖励包通用类型)
	REWARD_STATUS_NO_FETCH = 0,			--可领取
	REWARD_STATUS_ALREADY_FETCH = 1,	--已领取
	REWARD_STATUS_DISABLE_FETCH = 2,	--不可领取

	-- 奖励包获得来源模块ID对应模块名
	reward_from_module_name = {},

	-- 奖励包获得来源模块ID对应模块描述
	reward_from_module_intro = {},

	-- 奖励包分享时的描述
	reward_from_module_share = {},

	------------------------ 各自开发定义ID区域 start ------------------------
	-- 通用奖励包获得来源模块ID定义
	--REWARD_FROM_MODULE_ID_TOLLGATE_RAID = 1,		-- 关卡扫荡
	--REWARD_FROM_MODULE_ID_TOLLGATE_PASS = 2,		-- 关卡通关
	REWARD_FROM_MODULE_ID_VIP_GANG = 3, 			-- VIP军团礼包
	REWARD_FROM_MODULE_ID_GANG_STORAGE_GET = 4,		-- 军团仓库奖励
	REWARD_FROM_MODULE_ID_GANG_STORAGE_FAN = 5,		-- 军团仓库返还
	REWARD_FROM_MODULE_ID_GANG_STORAGE_FAN_SELF = 6,-- 军团仓库自动返还
	REWARD_FROM_MODULE_ID_ARENA = 7,				-- 竞技场排名奖励
	REWARD_FROM_MODULE_ID_ARENA_LUCK = 8,			-- 竞技场幸运排名奖励
	REWARD_FORM_MODULE_ID_TRADE = 9,				-- 交易系统获得奖励
	REWARD_FROM_MODULE_ID_SLAVE = 10, 				-- 仆从贡献奖励
	REWARD_FROM_MODULE_ID_HONGBAO_LINWEI = 11, 		-- 临危摇骰子奖励
	REWARD_FROM_MODULE_ID_LINWEI = 12, 				-- 临危受命奖励
	
	REWARD_FROM_MODULE_ID_SUBLINE = 14, 			-- 副本奖励

	REWARD_FROM_MODULE_ID_TIANMO_KILLBOSS = 16, 	-- BOSS之家击杀BOSS奖励
	REWARD_FROM_MODULE_ID_TIANMO_RANK = 17, 		-- BOSS之家排名奖励
	REWARD_FROM_MODULE_ID_TIANMO_LAY = 18, 			-- BOSS之家层次奖励
	REWARD_FROM_MODULE_ID_DAILY_TASK = 19, 			-- 日常任务昨日未领奖励
	REWARD_FROM_MODULE_ID_DAOJIANJUE = 20, 			-- 刀剑奖励(帝国争锋)
	REWARD_FROM_MODULE_ID_TOPLIST = 21, 			-- 排行榜奖励
	REWARD_FROM_MODULE_ID_GMT = 22,  				-- GMT后台道具奖品
	REWARD_FROM_MODULE_ID_GANG_BATTLE = 23,			-- 军团战奖励
	REWARD_FROM_MODULE_ID_GANG_BATTLE_PASS = 24,	-- 军团战轮空奖励
	REWARD_FROM_MODULE_ID_GANG_TOPLIST_REWARD = 25,	-- 军团战赛季排行榜奖励
	REWARD_FROM_MODULE_ID_GANG_DRAGON = 26, 		-- 军团金龙升级奖励
	REWARD_FROM_MODULE_ID_BABEL_FINISH = 27,		-- 试炼塔完成某一层奖励
	REWARD_FROM_MODULE_ID_BABEL_RAID  = 28,			-- 试炼塔扫荡奖励
	REWARD_FROM_MODULE_ID_LUCKY_CAT  = 29,			-- 招财猫奖励
	REWARD_FROM_MODULE_ID_VOUCHER_REWARD  = 30,		-- 充值赠送
	REWARD_FROM_MODULE_ID_CHARM  = 31,           -- 魅力活动排名赠送
	REWARD_FROM_MODULE_ID_LOVERS_DIVORCE  = 32,     -- 情侣系统离婚礼物
	REWARD_FROM_MODULE_ID_JB_HS_SUCCESS  = 33,     -- 美女与野兽(护送成功)
	REWARD_FROM_MODULE_ID_VOUCHER_GIFT = 34,		-- 充值礼
	REWARD_FROM_MODULE_ID_JB_HS_FAIL  = 35,     -- 美女与野兽(护送失败)
	REWARD_FROM_MODULE_ID_JB_JS_SUCCESS  = 36,     -- 美女与野兽(截杀成功)
	REWARD_FROM_MODULE_ID_JB_JS_FAIL  = 37,     -- 美女与野兽(截杀失败)
	REWARD_FROM_MODULE_ID_VOUCHER_GIFT_BUCHANG = 38,	--充值有礼变更补偿
	REWARD_FROM_MODULE_ID_SEND_GANG_BADGE = 39,	--发送军团徽章
	REWARD_FROM_MODULE_ID_ACT_CODE = 40,		--礼包码
	REWARD_FROM_MODULE_ID_FINAL_WAR1 = 41,   --末日之战-巅峰战场
	REWARD_FROM_MODULE_ID_FINAL_WAR2 = 42,   --末日之战-前哨战场
	REWARD_FROM_MODULE_ID_BABEL_BUFA = 43,	 --豆蔓奖励补发
	REWARD_FROM_MODULE_ID_HUNYAN_ROBBALL = 44,  --婚宴发奖励
	REWARD_FROM_MODULE_ID_HUNYAN_TOAST = 45,  --婚宴举杯奖励
	REWARD_FROM_MODULE_ID_HUNYAN_FIREWORKS_LUCK = 46,  --婚宴礼花幸运奖励
	REWARD_FROM_MODULE_ID_HUNYAN_GIFTS = 47,  --婚宴礼金
	REWARD_FROM_MODULE_ID_ZHUSHEN_TOPLIST = 48,	--诸神黄昏排行榜奖励
	REWARD_FROM_MODULE_ID_GANG_CH_RANK = 49,	--军团战个人排行奖励
	REWARD_FROM_MODULE_ID_WEDRING = 50,	--婚戒
	REWARD_FROM_MODULE_ID_WEDRING_CLOTH = 51,    --预约婚宴奖励
	REWARD_FROM_MODULE_ID_WEDRING_CLOTH_COPUER = 52,    --预约婚宴对方礼服奖励
	REWARD_FROM_MODULE_ID_LUCK_GODDESS_SPECIAL = 53,    --幸运女神活动专属奖励
	REWARD_FROM_MODULE_ID_SUBLINE_EMENG = 54,			--噩梦副本奖励
	REWARD_FROM_MODULE_ID_DAOJIANJUE_WEEK = 55,			--帝国争锋周未领取奖励
	REWARD_FROM_MODULE_ID_DAOJIANJUE_GUAJI_LEAVE = 56,	--帝国争锋挂机被踢奖励
	REWARD_FROM_MODULE_ID_SCORE_POPUP  = 57,     -- 弹窗评分
	REWARD_FROM_MODULE_ID_SHENGCUN  = 58,     -- 生存挑战(丧尸危机)
	REWARD_FROM_MODULE_ID_LOVER_TEMPLE  = 59,     -- 爱情圣殿

	------------------------ 各自开发定义ID区域 end ------------------------
	
	REWARD_GET_GOLD_MEMO = '领奖系统奖励元宝',
	
	-- 活动战果的类型定义
	REWARD_WIN_TYPE_WIN = 1,					-- 胜利
	REWARD_WIN_TYPE_FAIL = 2,					-- 失败
	REWARD_WIN_TYPE_DRAW = 3,					-- 平局
	REWARD_WIN_TYPE_BYE = 4,					-- 轮空
	REWARD_WIN_TYPE_LAST_KILL = 5,				-- 最后一击
	REWARD_WIN_TYPE_NONE = 6,					-- 无战果
	REWARD_WIN_TYPE_LOSING_STREAK = 7,			-- 连败
}


-- 奖励包获得来源模块ID对应模块名
local _module_name = RewardDefs.reward_from_module_name
-- 奖励包获得来源模块ID对应模块描述
local _module_intr = RewardDefs.reward_from_module_intro
-- 奖励包获得来源模块ID对应分离描述
local _module_shar = RewardDefs.reward_from_module_share
--[[
	_module_name	对应奖励标题
	_module_intr	对应奖励的正文部分
	_module_shar	对应分享部分，如果没有，则不能分享
]]

-- VIP帮会奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_VIP_GANG]  = OKMsgCodes.REWARD_TITLE_VIP_GANG
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_VIP_GANG]  = OKMsgCodes.REWARD_INTRO_VIP_GANG
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_VIP_GANG] = OKMsgCodes.REWARD_SHARE_VIP_GANG

-- 军团仓库出售成功奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GANG_STORAGE_GET] = OKMsgCodes.REWARD_TITLE_GANG_STORAGE_GET
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GANG_STORAGE_GET] = OKMsgCodes.REWARD_INTRO_GANG_STORAGE_GET
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_GANG_STORAGE_GET] = OKMsgCodes.REWARD_SHARE_GANG_STORAGE_GET

-- 军团仓库被返还
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GANG_STORAGE_FAN] = OKMsgCodes.REWARD_TITLE_GANG_STORAGE_FAN
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GANG_STORAGE_FAN] = OKMsgCodes.REWARD_INTRO_GANG_STORAGE_FAN

-- 军团仓库自动返还奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GANG_STORAGE_FAN_SELF] = OKMsgCodes.REWARD_TITLE_GANG_STORAGE_FAN
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GANG_STORAGE_FAN_SELF] = OKMsgCodes.REWARD_INTRO_GANG_STORAGE_FAN_SELF

-- 交易
_module_name[RewardDefs.REWARD_FORM_MODULE_ID_TRADE] = OKMsgCodes.TRADE_SALE_THE_EQUIP_OK_TITLE
_module_intr[RewardDefs.REWARD_FORM_MODULE_ID_TRADE] = OKMsgCodes.TRADE_SALE_THE_EQUIP_OK_INTRO
_module_shar[RewardDefs.REWARD_FORM_MODULE_ID_TRADE] = OKMsgCodes.TRADE_SALE_THE_EQUIP_OK_SHARE

-- 竞技场
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_ARENA] = OKMsgCodes.REWARD_TITLE_ARENA
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_ARENA] = OKMsgCodes.REWARD_INTRO_ARENA
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_ARENA] = OKMsgCodes.REWARD_INTRO_ARENA
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_ARENA_LUCK] = OKMsgCodes.REWARD_TITLE_ARENA_LUCK
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_ARENA_LUCK] = OKMsgCodes.REWARD_INTRO_ARENA_LUCK
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_ARENA_LUCK] = OKMsgCodes.REWARD_INTRO_ARENA_LUCK

-- 仆从贡献奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_SLAVE]  = OKMsgCodes.REWARD_TITLE_SLAVE_BIANCHI
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_SLAVE]  = OKMsgCodes.REWARD_INTRO_SLAVE_BIANCHI
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_SLAVE] = OKMsgCodes.REWARD_SHARE_SLAVE_BIANCHI

-- 摇骰子奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_HONGBAO_LINWEI] = OKMsgCodes.REWARD_TITLE_LINWEI_HONGBAO
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_HONGBAO_LINWEI] = OKMsgCodes.REWARD_INTRO_LINWEI_HONGBAO
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_HONGBAO_LINWEI] = OKMsgCodes.REWARD_SHARE_LINWEI_HONGBAO

-- 临危任务奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_LINWEI] = OKMsgCodes.REWARD_TITLE_LINWEI
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_LINWEI] = OKMsgCodes.REWARD_INTRO_LINWEI
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_LINWEI] = OKMsgCodes.REWARD_SHARE_LINWEI

-- 副本奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_SUBLINE] = OKMsgCodes.REWARD_TITLE_SUBLINE
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_SUBLINE] = OKMsgCodes.REWARD_INTRO_SUBLINE
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_SUBLINE] = OKMsgCodes.REWARD_INTRO_SUBLINE

-- 噩梦副本奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_SUBLINE_EMENG] = OKMsgCodes.REWARD_TITLE_SUBLINE
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_SUBLINE_EMENG] = OKMsgCodes.REWARD_INTRO_SUBLINE
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_SUBLINE_EMENG] = OKMsgCodes.REWARD_SHARE_SUBLINE

_module_name[RewardDefs.REWARD_FROM_MODULE_ID_DAOJIANJUE_WEEK] = OKMsgCodes.REWARD_TITLE_DAOJIANJUE_WEEK
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_DAOJIANJUE_WEEK] = OKMsgCodes.REWARD_INTRO_DAOJIANJUE_WEEK

_module_name[RewardDefs.REWARD_FROM_MODULE_ID_DAOJIANJUE_GUAJI_LEAVE] = OKMsgCodes.REWARD_TITLE_DAOJIANJUE_GUAJI_LEAVE
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_DAOJIANJUE_GUAJI_LEAVE] = OKMsgCodes.REWARD_INTRO_DAOJIANJUE_GUAJI_LEAVE

-- 幸运女神活动专属奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_LUCK_GODDESS_SPECIAL] = OKMsgCodes.REWARD_TITLE_LUCK_GODDESS_SPECIAL
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_LUCK_GODDESS_SPECIAL] = OKMsgCodes.REWARD_INTRO_LUCK_GODDESS_SPECIAL

-- BOSS之家击杀BOSS奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_KILLBOSS] = OKMsgCodes.REWARD_TITLE_TIANMO_KILLBOSS
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_KILLBOSS] = OKMsgCodes.REWARD_INTRO_TIANMO_KILLBOSS
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_KILLBOSS] = OKMsgCodes.REWARD_SHARE_TIANMO_KILLBOSS

-- BOSS之家排名奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_RANK] = OKMsgCodes.REWARD_TITLE_TIANMO
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_RANK] = OKMsgCodes.REWARD_INTRO_TIANMO
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_RANK] = OKMsgCodes.REWARD_SHARE_TIANMO_RANK

-- BOSS之家层数奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_LAY] = OKMsgCodes.REWARD_TITLE_TIANMO
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_LAY] = OKMsgCodes.REWARD_INTRO_TIANMO_LAY
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_TIANMO_LAY] = OKMsgCodes.REWARD_SHARE_TIANMO_LAY

-- 日常任务昨日未领奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_DAILY_TASK] = OKMsgCodes.REWARD_TITLE_DAILY_TASK
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_DAILY_TASK] = OKMsgCodes.REWARD_INTRO_DAILY_TASK
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_DAILY_TASK] = OKMsgCodes.REWARD_SHARE_DAILY_TASK

-- 帝国争锋奖励（刀剑）
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_DAOJIANJUE] = OKMsgCodes.REWARD_TITLE_DAOJIANJUE
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_DAOJIANJUE] = OKMsgCodes.REWARD_INTRO_DAOJIANJUE
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_DAOJIANJUE] = OKMsgCodes.REWARD_SHARE_DAOJIANJUE

-- 排行榜奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_TOPLIST] = OKMsgCodes.REWARD_TITLE_TOPLIST
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_TOPLIST] = OKMsgCodes.REWARD_INTRO_TOPLIST
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_TOPLIST] = OKMsgCodes.REWARD_SHARE_TOPLIST

--GMT后台发奖
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GMT] = OKMsgCodes.REWARD_TITLE_GMT
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GMT] = OKMsgCodes.REWARD_INTRO_GMT

--军团战奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GANG_BATTLE] = OKMsgCodes.REWARD_TITLE_GANG_BATTLE
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GANG_BATTLE] = OKMsgCodes.REWARD_INTRO_GANG_BATTLE
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_GANG_JUESAI_RANK] = OKMsgCodes.REWARD_SHARE_GANG_JUESAI_RANK
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GANG_CH_RANK] = OKMsgCodes.REWARD_TITLE_GANG_BATTLE_CH_RANK
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GANG_CH_RANK] = OKMsgCodes.REWARD_INTRO_GANG_BATTLE_CH_RANK

--军团战轮空奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GANG_BATTLE_PASS] = OKMsgCodes.REWARD_TITLE_GANG_BATTLE_PASS
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GANG_BATTLE_PASS] = OKMsgCodes.REWARD_INTRO_GANG_BATTLE_PASS
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_GANG_BATTLE_PASS] = OKMsgCodes.REWARD_SHARE_GANG_JUESAI_WIN_GANG


--军团战初赛排名奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GANG_TOPLIST_REWARD] = OKMsgCodes.REWARD_TITLE_GANG_TOPLIST_REWARD
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GANG_TOPLIST_REWARD] = OKMsgCodes.REWARD_INTRO_GANG_TOPLIST_REWARD
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_GANG_CHUSAI] = OKMsgCodes.REWARD_SHARE_GANG_CHUSAI

--军团屠龙金龙升级奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_GANG_DRAGON] = OKMsgCodes.REWARD_TITLE_GANG_DRAGON
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_GANG_DRAGON] = OKMsgCodes.REWARD_INTRO_GANG_DRAGON

--试炼塔完成某一层奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_BABEL_FINISH] = OKMsgCodes.REWARD_TITLE_BABEL_FINISH
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_BABEL_FINISH] = OKMsgCodes.REWARD_INTRO_BABEL_FINISH
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_BABEL_FINISH] = OKMsgCodes.REWARD_SHARE_BABEL_FINISH

--试炼塔扫荡奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_BABEL_RAID] = OKMsgCodes.REWARD_TITLE_BABEL_RAID
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_BABEL_RAID] = OKMsgCodes.REWARD_INTRO_BABEL_RAID
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_BABEL_RAID] = OKMsgCodes.REWARD_SHARE_BABEL_RAID

--充值商城赠送魔石
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_VOUCHER_REWARD] = OKMsgCodes.REWARD_TITLE_VOUCHER_REWARD
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_VOUCHER_REWARD] = OKMsgCodes.REWARD_INTRO_VOUCHER_REWARD
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_VOUCHER_REWARD] = OKMsgCodes.REWARD_INTRO_VOUCHER_REWARD

--招财猫
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_LUCKY_CAT] = OKMsgCodes.REWARD_TITLE_LUCKY_CAT
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_LUCKY_CAT] = OKMsgCodes.REWARD_INTRO_LUCKY_CAT
--_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_LUCKY_CAT] = OKMsgCodes.REWARD_SHARE_LUCKY_CAT

--魅力活动奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_CHARM] = OKMsgCodes.REWARD_TITLE_CHARM_REWARD
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_CHARM] = OKMsgCodes.REWARD_INTRO_CHARM_REWARD

--情侣系统离婚礼物
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_LOVERS_DIVORCE] = OKMsgCodes.REWARD_TITLE_LOVERS_DIVORCE
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_LOVERS_DIVORCE] = OKMsgCodes.REWARD_INTRO_LOVERS_DIVORCE

--充值礼连续五天奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_VOUCHER_GIFT] = OKMsgCodes.REWARD_TITLE_VOUCHER_GIFT_REWARD
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_VOUCHER_GIFT] = OKMsgCodes.REWARD_INTRO_VOUCHER_GIFT_REWARD


--美女与野兽活动奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_JB_HS_SUCCESS] = OKMsgCodes.REWARD_TITLE_JB_REWARD
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_JB_HS_SUCCESS] = OKMsgCodes.REWARD_INTRO_JB_HS_SUCCESS_REWARD
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_JB_HS_FAIL] = OKMsgCodes.REWARD_TITLE_JB_REWARD
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_JB_HS_FAIL] = OKMsgCodes.REWARD_INTRO_JB_HS_FAIL_REWARD
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_JB_JS_SUCCESS] = OKMsgCodes.REWARD_TITLE_JB_REWARD
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_JB_JS_SUCCESS] = OKMsgCodes.REWARD_INTRO_JB_JS_SUCCESS_REWARD
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_JB_JS_FAIL] = OKMsgCodes.REWARD_TITLE_JB_REWARD
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_JB_JS_FAIL] = OKMsgCodes.REWARD_INTRO_JB_JS_FAIL_REWARD

--末日战场
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_FINAL_WAR1] = OKMsgCodes.REWARD_TITLE_FINALWAR_REWARD1
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_FINAL_WAR1] = OKMsgCodes.REWARD_INTRO_FINALWAR1
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_FINAL_WAR2] = OKMsgCodes.REWARD_TITLE_FINALWAR_REWARD2
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_FINAL_WAR2] = OKMsgCodes.REWARD_INTRO_FINALWAR2


-- 充值有礼活动变更补偿
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_VOUCHER_GIFT_BUCHANG] = OKMsgCodes.REWARD_TITLE_VGIFT_BUCHANG
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_VOUCHER_GIFT_BUCHANG] = OKMsgCodes.REWARD_INTRO_VGIFT_BUCHANG

-- 发送军团徽章
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_SEND_GANG_BADGE] = OKMsgCodes.REWARD_TITLE_SEND_GANG_BADGE

-- 礼包码
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_ACT_CODE] = OKMsgCodes.REWARD_TITLE_ACT_CODE
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_ACT_CODE] = OKMsgCodes.REWARD_INTRO_ACT_CODE

_module_name[RewardDefs.REWARD_FROM_MODULE_ID_BABEL_BUFA] = OKMsgCodes.REWARD_TITLE_BABEL_BUFA
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_BABEL_BUFA] = OKMsgCodes.REWARD_INTRO_BABEL_BUFA

-- 婚宴发奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_HUNYAN_ROBBALL] = OKMsgCodes.REWARD_TITLE_HUNYAN_ROB
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_HUNYAN_ROBBALL] = OKMsgCodes.REWARD_INTRO_HUNYAN_ROB

_module_name[RewardDefs.REWARD_FROM_MODULE_ID_HUNYAN_TOAST] = OKMsgCodes.REWARD_TITLE_HUNYAN_TOAST
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_HUNYAN_TOAST] = OKMsgCodes.REWARD_INTRO_HUNYAN_TOAST

_module_name[RewardDefs.REWARD_FROM_MODULE_ID_HUNYAN_FIREWORKS_LUCK] = OKMsgCodes.REWARD_TITLE_HUNYAN_FIREWORKS_LUCK
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_HUNYAN_FIREWORKS_LUCK] = OKMsgCodes.REWARD_INTRO_HUNYAN_FIREWORKS_LUCK


_module_name[RewardDefs.REWARD_FROM_MODULE_ID_HUNYAN_GIFTS] = OKMsgCodes.REWARD_TITLE_HUNYAN_GIFTS
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_HUNYAN_GIFTS] = OKMsgCodes.REWARD_INTRO_HUNYAN_GIFTS

_module_name[RewardDefs.REWARD_FROM_MODULE_ID_ZHUSHEN_TOPLIST] = OKMsgCodes.REWARD_TITLE_ZHUSHEN_TOP
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_ZHUSHEN_TOPLIST] = OKMsgCodes.REWARD_INTRO_ZHUSHEN_TOP

--婚戒奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_WEDRING] = OKMsgCodes.REWARD_TITLE_WEDRING
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_WEDRING] = OKMsgCodes.REWARD_INTRO_WEDRING

--婚宴礼服奖励
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_WEDRING_CLOTH] = OKMsgCodes.REWARD_TITLE_WEDRING_CLOTH
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_WEDRING_CLOTH] = OKMsgCodes.REWARD_INTRO_WEDRING_CLOTH
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_WEDRING_CLOTH_COPUER] = OKMsgCodes.REWARD_TITLE_WEDRING_CLOTH
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_WEDRING_CLOTH_COPUER] = OKMsgCodes.REWARD_INTRO_WEDRING_CLOTH_COPUER

--评分弹窗
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_SCORE_POPUP] = OKMsgCodes.REWARD_TITLE_SCORE_POPUP
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_SCORE_POPUP] = OKMsgCodes.REWARD_INTRO_SCORE_POPUP

--生存挑战（丧尸危机0
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_SHENGCUN] = OKMsgCodes.REWARD_TITLE_SHENGCUN
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_SHENGCUN] = OKMsgCodes.REWARD_INTRO_SHENGCUN

--生存挑战（丧尸危机0
_module_name[RewardDefs.REWARD_FROM_MODULE_ID_LOVER_TEMPLE] = OKMsgCodes.REWARD_TITLE_LOVER_TEMPLE
_module_intr[RewardDefs.REWARD_FROM_MODULE_ID_LOVER_TEMPLE] = OKMsgCodes.REWARD_INTRO_LOVER_TEMPLE
_module_shar[RewardDefs.REWARD_FROM_MODULE_ID_LOVER_TEMPLE] = OKMsgCodes.REWARD_SHARE_LOVER_TEMPLE

-- 活动战果的类型TITLE定义
RewardDefs.reward_win_type_titles = {
	--[RewardDefs.REWARD_WIN_TYPE_WIN] = Language:getText('t702'),
	--[RewardDefs.REWARD_WIN_TYPE_FAIL] = Language:getText('t703'),
}


-- 格式化发离线奖励包需要的参数
--[[ eg :
	local arr_reward = {}
	
	local reward_equips = {} 	--道具列表{[equip_id] = equip_num}

	for _, ch in pairs(arr_ch) do
		local reward_income = {}
		reward_income.var1 = r  (var1-4只支持字符串类型)
		reward_income.var2 = r
		reward_income.var3 = r
		reward_income.var4 = r
		reward_income.win_type = 1	--胜利类型,如果填值，会显示胜利失败图标	REWARD_WIN_TYPE_WIN = 1,REWARD_WIN_TYPE_FAIL = 2
		reward_income.rank = 1 		--如果填值，会显示排行大图标
		reward_income.score = 1 	--如果填值，会显示积分大图标
		reward_income.color_equip1 	--如果填值，会替换语言包中的[color_equip1]，道具ID会变成对应的道具的名字，并显示对应的颜色
		reward_income.color_equip2  --同上

		语言包中的[equips]会被替换为道具列表
		
		local reward = RewardDefs:formatRewardParams(ch.id, ch.player_id, reward_income, reward_equips)
		arr_reward[#arr_reward+1] = reward
	end
	
	RewardService:addCommonReward(nil, SceneDefs.SCENE_SORT_ID_WORLD_BOSS, RewardDefs.REWARD_FROM_MODULE_ID_WORLD_BOSS, arr_reward)	
--]]
function RewardDefs:formatRewardParams(cid, player_id, reward_income, reward_equips, reward_title, reward_intro, reward_share)
	local reward = {}
	local reward_content = {}
	reward.cid = cid
	reward.player_id = player_id
	
	if table.isTable(reward_income) then 
		reward_content = table.structure_clone( reward_income, 3) 
	end

	reward_content.equips = reward_equips
	local reward_title_type = type(reward_title)
	local reward_intro_type = type(reward_intro)
	if reward_title_type == 'number' then
		reward_content.title_id = reward_title
	elseif reward_title_type == 'string' then
		reward_content.title = reward_title
	end
	if reward_intro_type == 'number' then
		reward_content.intro_id = reward_intro
	elseif reward_intro_type == 'string' then
		reward_content.intro = reward_intro
	end
	if reward_share == 'number' then
		reward_content.share_id = reward_share
	elseif reward_share == 'string' then
		reward_content.share = reward_share
	end	
	
	reward.reward = reward_content
	return reward
end
