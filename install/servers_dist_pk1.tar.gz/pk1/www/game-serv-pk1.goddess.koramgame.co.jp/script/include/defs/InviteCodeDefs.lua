--[[
邀请码定义
author : xingzeng.jiang
date : 2015-12-04
$Id: $
--]]

InviteCodeDefs =
{
	--邀请人的等级要求
	INVITE_PLAYER_LEVEL_MIN = 50,
	
	--被邀请人过期时间(x天未更新过数据，则认为不会在客户端显示)
	INVITEE_EXPIRE = 15 * 24 * 3600,
}
