--[[
军团战  defs
author: guoyin.huang
date: 2016-04-05
]]--

GangBattleNewDefs = {
	-- 军团战状态
	STATUS_COMMON = 1,	-- 基础状态
	STATUS_BAOMING = 2,	-- 报名中
	STATUS_MATCH = 3,	-- 匹配中
	STATUS_MATCH_FIN = 4,	-- 匹配完成
	STATUS_FIGHTING = 5,-- 战斗中

	-- 军团战阵营
	BATTLE_CAMP_UP = 1,	-- 阵营上
	BATTLE_CAMP_LD = 2,	-- 阵营左下
	BATTLE_CAMP_RD = 3,	-- 阵营右下


	FIGHT_STATUS_PRE = 1,	--准备阶段
	FIGHT_STATUS_WAR = 2,	--战斗阶段
	FIGHT_STATUS_FIN = 3,	--结束阶段

	MSG_B2PKB_UPLOAD_FOR_TOP = 1,		--上报军团战积分数据
	MSG_B2PKB_UPLOAD_FOR_BAOMING = 2,	--用于上报报名数据

	MSG_PKB2B_NOTICE_UPLOAD_SCORE =11,		--通知游戏服上报所有军团积分
	MSG_PKB2B_NOTICE_UPLOAD_BAOMING = 12,	--通知游戏服上报所有可参与PK军团战的军团数据
	MSG_PKB2B_NOTICE_CLEAR_BAOMING = 13,	--通知游戏服清空报名数据
	MSG_PKB2B_NOTICE_GEN_VS_LIST = 14,		--通知游戏服生成对战表
	MSG_PKB2B_SEND_PK_VS_LIST = 15,			--广播给游戏服，PK服的对战表
	MSG_PKB2B_NOTICE_TOPLIST = 16,			--排行榜
	MSG_PKB2b_NOTICE_STATUS = 17,			--广播状态数据（包括各项时间）
	MSG_PKB2B_NOTICE_GEN_TOP_LIST = 18,		--广播到游戏服生成对战表
	MSG_PKB2B_NOTICE_TOPLIST_REWARD = 19,	--跨服排行榜发奖
	MSG_PKB2B_NOTICE_SAVE_HISTORY = 20,		--保存对战数据
	MSG_PKB2B_NOTICE_SAVE_ZHULI = 21,		--保存军团主力
	MSG_PKB2b_NOTICE_CLEAR_SCORE = 22,		--清除赛季积分
	MSG_PKB2B_NOTICE_PASS_REWARD = 23,		--发轮空奖励
}