
PackageTypeDefs = {
	SORT_ID_DAOJU_BIG = 1,		--道具大类
	SORT_ID_DAOJU = 2,			--道具
	SORT_ID_BAOSHI = 3,			--宝石
	SORT_ID_EXCHANGE = 4,		--交易物
	SORT_ID_MAGIC_RING_CAILIAO = 200,	--魔戒材料
	
	SORT_ID_EQUIPBIG = 5,		--装备大类
	SORT_ID_EQUIP = 6,			--装备
	SORT_ID_BAOWU = 7,			--宝物
	SORT_ID_TOW_STAR = 18,		--幻兽双星
	
	SORT_ID_CHIP_BIG = 8,		--碎片大类
	SORT_ID_EQUIP_CHIP = 9,		--装备碎片
	SORT_ID_PET_CHIP = 10,		--幻兽碎片
	
	SORT_ID_GODDESS = 11,		--女神
	
	SORT_ID_GODDESS_CHIP = 12,	--女神碎片
	SORT_ID_AVATAR_CHIP = 13,	--时装碎片
	SORT_ID_WING_CHIP = 14,		--翅膀碎片
	SORT_ID_SHENGYU_CHIP = 15,	--神域碎片
	
	SORT_ID_SPIRIT = 16,		--精灵
	
	SORT_ID_OTHER_CHIP = 17,	--其他碎片
	--SORT_ID_TOW_STAR = 18,	--双星 (在上面已定义，这里是占位，避免重复用此ID)
	SORT_ID_TOW_STAR_CHIP = 19,	--幻兽双星碎片
	
	SORT_ID_WING_BIG = 100,		--翅膀大类
	SORT_ID_WING = 101,			--翅膀
		
	SORT_ID_AVATAR = 102,		--时装
	
}
AsReadOnly(PackageTypeDefs)
