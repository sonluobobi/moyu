--[[
随机奖励包定义
author : xingzeng
date : 2014-08-18
$Id: $
--]]

RandRewardPackDefs =
{
	-- 分组定义
	RAND_REWARD_PACK_GID_ROB_CHIP = 1,		-- 碎片抢夺 后的随机奖励包
	RAND_REWARD_PACK_GID_ARENA = 2,			-- 竞技场随机奖励包
	RAND_REWARD_PACK_GID_SLAVE = 3,			-- 鞭笞奴隶随机奖励包
	RAND_REWARD_PACK_GID_TOLLGATE = 4,		-- 关卡奖励包
	RAND_REWARD_PACK_GID_TOLLGATE2 = 5,		-- 关卡附加奖励包
	RAND_REWARD_PACK_GID_ZHUSHENG = 6,		-- 诸神黄昏奖励包
}
