--[[
角色列表系统ctrl
author : fuqian.liao
date : 2015-02-10
--]]

CharacterListDefs = {

	-- 角色列表中心服务器  使用接口地址
	CENTER_SERV_HOST_URL = 'http://s0.moyu.kunlun.com/character_list/index.php',
	
	TOKEN_DECODE_KEY = 'xafjlajjlj^&*^*%*%',	--与角色列表中心通信的密钥
	
	CURL_KEY = 1,	-- 

}

-- 获取角色列表中心服地址
function CharacterListDefs:getCharacterListCenterServUrl()
	local server_url = CharacterListDefs.CENTER_SERV_HOST_URL
	--[[
	if Language:isTW() then
		server_url = 'http://act.tth.kimi.com.tw/activation_code/index.php'
	elseif Language:isKR() then
		server_url = 'http://act.zd.koramgame.co.kr/activation_code/index.php'
	elseif Language:isVN() then
		server_url = 'http://act.tdsk.tuyetdaisongkieu.com/activation_code/index.php'
	elseif Language:isTH() then
		server_url = 'http://act.lt.webgame.in.th/activation_code/index.php'
	end
	]]
	return server_url
end

