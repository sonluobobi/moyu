--[[
竞技场 定义
author : xingzeng
date : 2014-08-18
$Id: $
--]]

ArenaDefs = ArenaDefs or {}

ArenaDefs.ARENA_MAP_ID = 1			-- 竞技场必须在MAP1(注：必须跟夺宝同一个MAP)
	
ArenaDefs.ARENA_CH_RANK_INIT = 1003	-- 玩家的初始排名(注：实际初始排名从201开始)
	
ArenaDefs.ARENA_CH_DETAIL_UPDATE_INTERVAL = 600	-- 每10分钟更新一次竞技场属性

ArenaDefs.MIAOSHA_NEED_BEYOND_FC_PERC = 0.2	-- 大于战力50% 则秒杀对手

ArenaDefs.RAND_REWARD_BAODI_TIMES = 500		-- 随机奖励 连续X次没出保底奖励，则必出一次保底奖励
	
ArenaDefs.PK_NEED_ENDURANCE = 2				-- 每次PK需要消耗的耐力

ArenaDefs.PK_LOG_NUM = 30					-- 保留的PK日志条数

AsReadOnly(ArenaDefs)