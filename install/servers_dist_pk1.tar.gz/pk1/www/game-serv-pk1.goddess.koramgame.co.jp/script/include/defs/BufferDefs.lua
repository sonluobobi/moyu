

BufferDefs = 
{
	BUFFER_TMP_OWN_SAME_TYPE_MAX_COUNT = 50,-- 拥有正面或反面临时BUFFER的最大个数(正面、反面BUFFER个数各为5个)
	
}



AsReadOnly(BufferDefs)