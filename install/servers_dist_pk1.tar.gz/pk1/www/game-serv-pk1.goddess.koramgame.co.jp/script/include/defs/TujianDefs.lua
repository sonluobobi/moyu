--[[
图鉴系统定义
author : guoyin.huang
date : 2016-03-29
--]]


TujianDefs = {
	SORT_ID_WING = 1,		--获得某个翅膀外形 
	SORT_ID_HORSE = 2,		--获得某个坐骑
	SORT_ID_WUQI = 3,		--获得某个武器
	SORT_ID_AVATA = 4,		--获得某个衣服或时装
	SORT_ID_SHENBING = 5,	--获得某个神兵
	SORT_ID_HORSE_PIFU = 6,	--坐骑皮肤
}