--[[
末日战场	系统定义
]]


FinalWarDefs = {
	STATUS_PREPARE = 0,			-- 准备状态
	STATUS_FIGHT = 1,			-- 战斗状态
	STATUS_FINISH = 2,			-- 完成状态
	
	STATUS_COMMON = 1,          --普通状态
	STATUS_GOD   = 2,          --女神状态
	STATUS_HUANGGUANG = 3,          --皇冠状态
	
	SUBID_FINALWAR1 = 90000,       --巅峰
	SUBID_FINALWAR2 = 90001,       --前哨
	
	FW_BUFFERID_GOD = 40000007,
	FW_BUFFERID_HG = 31000003,
	
	pre_scene_id1 = 90007,  --末日之战巅峰准备厅场景
    war_scene_id1 = 90008,   --末日之战巅峰战斗场景
    
    pre_scene_id2 = 90009,  --末日之战前哨准备厅场景
    war_scene_id2 = 90010,   --末日之战前哨战斗场景
    
    join_war1_rankneed = 40, --末日之战巅峰战场的名次要求
    join_war2_rankneed = 200, --末日之战前哨战场的名次要求
    
    GOD_BUFFER_ID = 1041,
	
	
}

fw_simple_entity = {
        nick = '',
        servname = '',  -- 下发客户端server_name
        rank = 0,
        appear = '',     
        gangname='',
        viplv = 0,     -- 0为普通军团1为vip军团
        badge_id=0, 
        updated='',      -- 下发即activity_time需要转时间戳
    }
    
fw_list_entity = {
    unique_key = '',
    nick = '',
    servname = '', 
    group_id = 0,
    prof = 0,
    score = 0, 
    rank = 0,
    active_id = 0,  
    killedtotal = 0,
    killcommon = 0,
    killgod = 0,
    killhuangguang = 0,
    continuekill = 0,
    appear = '',   
    gangname='',
    badge_id=0,
    viplv=0,  
    updated='',          
}

