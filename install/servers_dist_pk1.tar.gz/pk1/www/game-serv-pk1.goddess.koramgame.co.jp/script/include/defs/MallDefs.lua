--[[
商城系统定义
author : guoyin.huang
date : 2015-01-22
$Id: $
--]]


MallDefs =
{
	-- 商城的分类定义
	MALL_SORT_ID_MIN = 1,				--商城分类ID最小值
	MALL_SORT_ID_SIMPLE = 1,			--普通道具
	MALL_SORT_ID_VIP = 2,				--VIP商城
	MALL_SORT_ID_VOUCHER_GOLD = 3,		--充值魔石商城
	MALL_SORT_ID_MAX = 3,				--商城分类ID最大值
	
	-- 购买返回过期时间
	PRE_MALL_BUY_EXPIRE_SEC = 60,		
	
	-- 商城限购类型
	MALL_LIMIT_BUY_NOT = 0,				--不限购
	MALL_LIMIT_BUY_FOREVER = 1,			--永久性限购
	MALL_LIMIT_BUY_DAY = 2,				--按天限购
	
	-- 单次最大购买数量
	MALL_MAX_BUY_NUM = 9999,			
	
	--消耗元宝的描述语
	MALL_BUY_USE_GOLD_MEMO = '商城购买',
}

