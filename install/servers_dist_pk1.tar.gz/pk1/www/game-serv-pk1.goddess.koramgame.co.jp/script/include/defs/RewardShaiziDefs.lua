--[[
摇骰子奖励定义
author : guoiyin.huang
date : 2015-04-10
$Id: $
--]]

RewardShaiziDefs =
{
	YAO_SHAIZI_TIME = 10,			-- 摇骰子的时间(单位：秒)
}

