-- 
--------------------------------------------------------------------------------
-- 玩法杀人表现配置
--
-- author : guoyin.huang
-- date : 2014-12-24
--
--------------------------------------------------------------------------------
--

WanfaKillDefs = {
	-- type:杀人广播的类型
	KILL_NOTICE_TYPE_FIRST     = 1,	-- 首杀
	KILL_NOTICE_TYPE_CONT_TIME = 2,	-- 连杀（一段时间内的连杀）
	KILL_NOTICE_TYPE_CONTINUE  = 3,	-- 连续击杀（永久性连杀）
	KILL_NOTICE_TYPE_END_CONT  = 4,	-- 终结连杀
	KILL_NOTICE_TYPE_KILL = 5,		-- 谁杀了谁（xxxx击杀了xxxxx）
	KILL_NOTICE_TYPE_TO_ERR_MSG = 6,-- 通过错误消息发送（你杀死了XXX）
	KILL_NOTICE_TYPE_SHOW_KILL = 7,	-- 显示杀字
	KILL_NOTICE_TYPE_COMMON_MSG = 8,-- 普通文字(客户端使用)
	KILL_NOTICE_TYPE_TOTAL_KILL = 9,-- 总杀人数(按5的倍数增长)
	KILL_NOTICE_TYPE_GANG_KILL = 10,-- 军团被杀
	KILL_NOTICE_TYPE_RANK_KILL = 11,-- 榜上被杀,军团长,战力榜，斩杀力榜

	-- 连续击杀时间间隔
	continue_kill_timelong = 30,	--30秒

	-- 连续杀人
	cont_time_kill = {
		[0] = 0,
		[1] = 0,	--1杀不广播
		[2] = 2,	--双杀
		[3] = 3,	--三杀
		[4] = 4,	--四杀
		other = 5,	--五杀   5人及以上均算5杀
	},

	-- 连杀
	continue_kill = {
		[0] = 0,
		[1] = 0,
		[2] = 0,
		[3] = 3,	--大杀特杀
		[4] = 4,	--接近暴走
		[5] = 5,	--无人可挡
		[6] = 6,	--主宰比赛
		[7] = 7,	--如同神一般
		other = 8,	--8人及以上均播放 超越神了
	},
	--总杀人数
	total_kill = {
        [1] = 20, --20的倍数        
    }
}

-- 场景支持的杀人表现列表
WanfaKillDefs.seceneid_2_killconfig = {
		[80001] = {	--3V3场景
			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,		--支持首杀
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,	--双杀，三杀等
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,  --无人可挡等
			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 	--终结连杀
			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true, 	  	--谁杀了谁
--			[WanfaKillDefs.KILL_NOTICE_TYPE_TO_ERR_MSG] = true,	--通知杀人者杀了谁
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true, 	--显示杀字
		},
		[90006] = {	--刀剑（帝国）战场 
			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,	 	
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,	
--			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,	
--			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 	
--			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = false, 	  	
			[WanfaKillDefs.KILL_NOTICE_TYPE_TO_ERR_MSG] = true,	
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true, 
		},
		[20009] = {	--可PK临危
--			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = false,	
--			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
--			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
--			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
--			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true, 
--			[WanfaKillDefs.KILL_NOTICE_TYPE_TO_ERR_MSG] = true,
--			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_TOTAL_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_GANG_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_RANK_KILL] = true,
		},	
		
		[20006] = {   --可PK临危
--          [WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = false, 
--          [WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
--          [WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
--          [WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
--          [WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true, 
--          [WanfaKillDefs.KILL_NOTICE_TYPE_TO_ERR_MSG] = true,
--          [WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
            [WanfaKillDefs.KILL_NOTICE_TYPE_TOTAL_KILL] = true,
            [WanfaKillDefs.KILL_NOTICE_TYPE_GANG_KILL] = true,
            [WanfaKillDefs.KILL_NOTICE_TYPE_RANK_KILL] = true,
        },  	
	
		[60018] = {	--丧尸危机
--			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,
--			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
--			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
--			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
--			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
		},		
		[51001] = {	--天魔第一层
			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
		},	
		[51002] = {	--天魔第二层
			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,	
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
		},	
		[51003] = {	--天魔第三层
			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,	
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
		},	
		[51004] = {	--天魔第四层
			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,	
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
		},	
		[51005] = {	--天魔第五层
			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,	
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
		},	
		[51006] = {	--天魔第六层
			[WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,	
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true, 
			[WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = true,
			[WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true,
		},	
		
		[90008] = {   --巅峰战场 
            [WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,      
            [WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,  
--          [WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,  
--          [WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true,   
--          [WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = false,      
            [WanfaKillDefs.KILL_NOTICE_TYPE_TO_ERR_MSG] = true, 
            [WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true, 
        },  
        [90010] = {   --前哨战场 
            [WanfaKillDefs.KILL_NOTICE_TYPE_FIRST] = true,      
            [WanfaKillDefs.KILL_NOTICE_TYPE_CONT_TIME] = true,  
--          [WanfaKillDefs.KILL_NOTICE_TYPE_CONTINUE]  = true,  
--          [WanfaKillDefs.KILL_NOTICE_TYPE_END_CONT] = true,   
--          [WanfaKillDefs.KILL_NOTICE_TYPE_KILL] = false,      
            [WanfaKillDefs.KILL_NOTICE_TYPE_TO_ERR_MSG] = true, 
            [WanfaKillDefs.KILL_NOTICE_TYPE_SHOW_KILL] = true, 
        },   
}	