---[[
--	公式表达式
--  by mjl
--  at 2013年10月16日
---]]

FormulaDefs = 
{
	PARAMS_PET_STARS = --侠客品阶参数--type:double[]
	{
		0.4,0.5,0.55,0.6,0.65,0.75,0.8,0.9,1.0
	}, 
	
	LOOP_TASK_REWARD_PROBS =   --环任务经验奖励系数--type:double[]
	{
	0.1,0.15,0.2,0.25,0.3
	},


-------------------元宝公式-------------------------------------------------------
--		
--
-------------------元宝公式-------------------------------------------------------end



-------------------普通公式-------------------------------------------------------
--
	
	PET_PRACTICE_ADD_HIT = 		--((1740+INT(修行等级/10)*260)*INT(修行等级/10)/2+(100+INT(修行等级/10.01)*26)*MOD(修行等级,10))
		'ceil(((3300+floor(pet_practice_level/10) *100)*floor(pet_practice_level/10)/2+(170+floor(pet_practice_level/10.01)*10)*(pet_practice_level%10))*PARAMS_PET_STARS[pet_star])',
	
	PET_PRACTICE_ADD_ATTACK = 	--侠客修行附加攻击，(pet_practice_level,pet_quality) //侠客修行等级
		'ceil(PET_PRACTICE_ADD_HIT*1.5)',
	
	PET_PRACTICE_ADD_DEFENCE = 	--侠客修行附加防御，(pet_practice_level,pet_quality)//侠客修行等级
		'ceil(PET_PRACTICE_ADD_HIT*0.5)',
	
	PET_PRACTICE_ADD_OTHER = 	--侠客修行附加其它，(pet_practice_level,pet_quality)//侠客修行等级
		'ceil(PET_PRACTICE_ADD_HIT)',
		
	PET_LILIAN_ADD_ATTACK =		--侠客历练附加攻击，(pet_lilian_level,pet_quality)	//侠客历练等级
		'ceil(((1740+floor(pet_lilian_level/10) *260)*floor(pet_lilian_level/10)/2+(100+floor(pet_lilian_level/10.01)*26)*(pet_lilian_level%10))*1.5*PARAMS_PET_STARS[pet_star])',
	PET_LILIAN_ADD_HP = 		--侠客历练附加生命，(pet_lilian_level,pet_quality) //侠客历练等级
		'ceil(PET_LILIAN_ADD_ATTACK*45)',
	PET_LILIAN_ADD_DEFENCE =	--侠客历练附加防御，(pet_lilian_level,pet_quality)	//侠客历练等级
		'ceil(PET_LILIAN_ADD_ATTACK*0.25)',
		
	DAILY_TASK_REWARD_ZHENQI = 	--日常任务奖励真气，(ch_level,task_star) //角色等级，任务星级//round（5*角色等级+100，0）
		' round( (5 * ch_level + 100) * ( 0.16 * task_star*task_star + 0.04*task_star + 0.8)) ',
	DAILY_TASK_REWARD_EXP = 	--日常任务奖励经验，(ch_level,task_star) //角色等级，任务星级//round（15*角色等级^2+24*角色等级+60，0）
		' round((15 * ch_level*ch_level + 24*ch_level + 60) * ( 0.16 * task_star*task_star + 0.04*task_star + 0.8 )) ',	
	
	LOOP_TASK_REWARD_EXP = 	--环任务奖励经验，(ch_level) //角色等级
		' round((437.5 * ch_level*ch_level + 700*ch_level + 1750) * LOOP_TASK_REWARD_PROBS[task_loop]) ',	
		
	--DAILY_TASK_REWARD_SILVER = 	--日常任务奖励银两，(ch_level,task_star) //角色等级，任务星级
	--	' round(2000 *  ( 0.16 * task_star*task_star + 0.04*task_star + 0.8)) ',
	
	EQUIP_QIANGHUA_MAX_LEVEL = --装备强化最高等级 (equip_level)
	' (floor(equip_level/20) + 1) * 10 ',
	
	
-------------------普通公式-------------------------------------------------------end

}


local FormulaDefs = FormulaDefs
local getlocal = debug.getlocal
local _G = _G
local rawget = rawget
local unpack = unpack
local assert = assert
local env = setmetatable({},
{
	__index = function(env,k)	
		local f = rawget(FormulaDefs,k..'_F')
		if f then
			local args = {}
			for i=1,100 do
				local lc,lv,lx = getlocal(2,i)
				if lc == '(*temporary)' or not lc then break; end
				args[i] = lv
			end
			return f(unpack(args))
		end		
		return FormulaDefs[k]
	end
})


local maths =
[==[
	local round = math.round
	local floor = math.floor
	local ceil  = math.ceil
	local min	= math.min
	local max	= math.min
]==]

--
FormulaDefs.PET_PRACTICE_ADD_HIT_F 		= assert(loadstring(maths ..'  return function(pet_practice_level,pet_star) return ' .. FormulaDefs.PET_PRACTICE_ADD_HIT .. ' end'))()
FormulaDefs.PET_PRACTICE_ADD_ATTACK_F	= assert(loadstring(maths ..'  return function(pet_practice_level,pet_star) return ' .. FormulaDefs.PET_PRACTICE_ADD_ATTACK .. ' end'))()
FormulaDefs.PET_PRACTICE_ADD_DEFENCE_F	= assert(loadstring(maths .. ' return function(pet_practice_level,pet_star) return ' .. FormulaDefs.PET_PRACTICE_ADD_DEFENCE .. ' end'))()
FormulaDefs.PET_PRACTICE_ADD_OTHER_F	= assert(loadstring(maths ..'  return function(pet_practice_level,pet_star) return ' .. FormulaDefs.PET_PRACTICE_ADD_OTHER .. ' end'))()

--
FormulaDefs.PET_LILIAN_ADD_HP_F =        assert(loadstring(maths .. ' return function(pet_lilian_level,pet_star) return ' .. FormulaDefs.PET_LILIAN_ADD_HP .. ' end'))()
FormulaDefs.PET_LILIAN_ADD_ATTACK_F =    assert(loadstring(maths .. ' return function(pet_lilian_level,pet_star) return ' .. FormulaDefs.PET_LILIAN_ADD_ATTACK .. ' end'))()
FormulaDefs.PET_LILIAN_ADD_DEFENCE_F =   assert(loadstring(maths .. ' return function(pet_lilian_level,pet_star) return ' .. FormulaDefs.PET_LILIAN_ADD_DEFENCE .. ' end'))()

--
FormulaDefs.DAILY_TASK_REWARD_ZHENQI_F = assert(loadstring(maths .. ' return function(ch_level,task_star) return ' .. FormulaDefs.DAILY_TASK_REWARD_ZHENQI .. ' end'))()
FormulaDefs.DAILY_TASK_REWARD_EXP_F =    assert(loadstring(maths .. ' return function(ch_level,task_star) return ' .. FormulaDefs.DAILY_TASK_REWARD_EXP .. ' end'))()

FormulaDefs.LOOP_TASK_REWARD_EXP_F = assert(loadstring(maths .. ' return function(ch_level,task_loop) return ' .. FormulaDefs.LOOP_TASK_REWARD_EXP .. ' end'))()

--
FormulaDefs.EQUIP_QIANGHUA_MAX_LEVEL_F = assert(loadstring(maths .. ' return function(equip_level) return ' .. FormulaDefs.EQUIP_QIANGHUA_MAX_LEVEL .. ' end'))()

----------------------------------
for k,v in pairs(FormulaDefs) do
	if type(v) == 'function' then
		setfenv(v,env)
	end
end
----------------------------------
--
--print(FormulaDefs.PET_LILIAN_ADD_ATTACK_F(3,1))
--
AsReadOnly(FormulaDefs)
