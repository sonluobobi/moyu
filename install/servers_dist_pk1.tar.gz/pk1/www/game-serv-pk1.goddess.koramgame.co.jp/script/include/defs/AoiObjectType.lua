-- aoi对象类型定义
AoiObjectType =
{
	-- AOI对象类型值不能修改(不能超过16种类型)
	AOI_OBJECT_TYPE_ID_PLAYER 	= 1,			-- 玩家
	AOI_OBJECT_TYPE_ID_PET 		= 2,			-- 侠客
	AOI_OBJECT_TYPE_ID_ROBOT 	= 3,			-- 机器人
	AOI_OBJECT_TYPE_ID_GUARD_NPC = 4,			-- 守护NPC(一些守护活动，会被怪物攻击的NPC等)
	AOI_OBJECT_TYPE_ID_MONSTER 	= 5,			-- 怪物
	AOI_OBJECT_TYPE_ID_NPC 		= 6,			-- NPC	
	AOI_OBJECT_TYPE_ID_ITEM 	= 7,			-- 小物品(动态采集物/掉落品/银两/...)
	AOI_OBJECT_TYPE_ID_GODDNESS = 8,			-- 女神
	
	AOI_OBJECT_TYPE_ID_TRAP 	= 10,			-- 陷阱
	AOI_OBJECT_TYPE_ID_BEAST	= 11,			-- 召唤兽
	
	AOI_OBJECT_TYPE_ID_TRANSMIT = 20,			-- 传送点 (没有AOI对象存在，以静态的SceneAoi对象存在)
	AOI_OBJECT_TYPE_ID_HORSE 	= 21,			-- 坐骑(抓马场上的自由坐骑，非玩家坐骑)
	AOI_OBJECT_TYPE_ID_PLANT 	= 22,			-- 静态采集物(客户端实现)
	AOI_OBJECT_TYPE_ID_SPIRIT	= 23,			-- 精灵对象(客户端实现)
}
AsReadOnly(AoiObjectType)