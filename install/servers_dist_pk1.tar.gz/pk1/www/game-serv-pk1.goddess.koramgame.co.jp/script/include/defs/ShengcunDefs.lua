--[[
生存挑战	系统定义
]]


ShengcunDefs = {
	STATUS_COMMON = 1,		--未匹配
	STATUS_MATCHING = 2,	--匹配中
	STATUS_FIGHTING = 3,	--战斗中

	scene_pre = 60019,		--准备厅
	scene_war = 60018,		--战斗场

	SHENGCUN_PROF_SHIYAOYUAN = 1,	--试药员
	SHENGCUN_PROF_YAOJISHI = 2,		--药剂师
	SHENGCUN_PROF_YANJIUYUAN = 3,	--研究员
	SHENGCUN_PROF_ZOMBIE = 4,		--僵尸
	
	CAMP_MEMBER_NUM = 3,	--每个阵营需要的人数
	CAMP_NUM = 5,			--阵营数量

	BUJI_STATUS_EMPTY = 1,	--空状态
	BUJI_STATUS_ZHANLING = 2, 	--已占领
}

ShengcunDefs.prof_2_speed = {
	[ShengcunDefs.SHENGCUN_PROF_SHIYAOYUAN] = 1.5,
	[ShengcunDefs.SHENGCUN_PROF_YAOJISHI] = 3,
	[ShengcunDefs.SHENGCUN_PROF_YANJIUYUAN] = 3,
	[ShengcunDefs.SHENGCUN_PROF_ZOMBIE] = 0,
}