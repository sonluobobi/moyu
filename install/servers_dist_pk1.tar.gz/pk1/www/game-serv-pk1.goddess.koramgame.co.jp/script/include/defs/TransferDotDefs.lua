--[[
传送点定义
author : xingzeng.jiang
date : 2014-08-12
--]]

TransferDotDefs = 
{
	TRANSFER_SORT_ID_NORMAL = 1,				-- 传出点-普通
	TRANSFER_SORT_ID_TOLLGATE = 2,				-- 传出点-关卡
	TRANSFER_SORT_ID_PK_2_GAME = 3,				-- 传出点-PK服回到游戏服
	TRANSFER_SORT_ID_SCENE_INNER = 4,			-- 传出点-场景内
	TRANSFER_SORT_ID_FUNCTION = 5,				-- 传出点-功能型
	TRANSFER_SORT_ID_OUT_BEGIN = 1,				-- 传出点 类型ID范围
	TRANSFER_SORT_ID_OUT_END = 100,
	
	TRANSFER_SORT_ID_IN_RELIVE = 101,			-- 复活点
	TRANSFER_SORT_ID_IN_NORMAL = 103,			-- 普通传入点(进入场景出生在传入点坐标)
	TRANSFER_SORT_ID_IN_NORMAL_MALE = 104,		-- 普通传入点, 男性专用
	TRANSFER_SORT_ID_IN_NORMAL_FEMALE = 105,	-- 普通传入点, 女性专用
	
	TRANSFER_SORT_ID_IN_BEGIN = 101,			-- 传入点 类型ID范围
	TRANSFER_SORT_ID_IN_END = 200,
	
	TRANSFER_SORT_ID_DOT = 201,					-- 普通点(用于各个玩法使用)
	
	TRANSFER_DOT_ID_TOLLGATE = 1002101,			-- 关卡的传送点基础ID
}



AsReadOnly(TransferDotDefs)

