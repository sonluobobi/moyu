---[[
--	客户端作弊定义
--  by mjl
--  at 2014年7月5日
---]]
--

ClientCheatDefs = 
{	
	CHEAT_TYPE_CLOCK_SPEED = 1,				--变速齿轮
	
	
	PUNISH_TYPE_NONE = 101,					--不惩罚
	PUNISH_TYPE_MOVE_TO_LAST_SCENE = 102,	--回到上个场景
	PUNISH_TYPE_LOGOUT = 103,				--退出游戏	
	
		
}