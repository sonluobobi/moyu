--[[
情侣系统 def
author : jianzhu
date : 2016-04-08
--]]

LoversDefs = {
	MIN_INTIMACY = 1314, --可选择结婚好友，亲密度最低值

	marry_gifts = {[21010338] = 1, [10130003]= 1, [21010260] = 20}, --新婚礼物

	--离婚状态
	DIVORCE_STATUS_NO = 0, --未申请离婚
	DIVORCE_STATUS_WAIT = 1, --离婚处理中
	DIVORCE_STATUS_CANCEL = 2, --离婚取消
	DIVORCE_STATUS_DONE = 3, --离婚成功
	
	APPLY_MARRY_CD = 1 * 60 * 60, --求婚请求间隔时间

	DIVORCE_OUTTIME_CD = 1*24*60*60, --离婚超时时间

	LOVERS_MIN_LEVEL = 30, --结婚对象等级最低要求

	--情侣在线加成配置
	LOVERS_ONLINE_ADD_PERCENT = 0.05, --在线建成比例，小数配置
	LOVERS_ONLINE_ADD_PERCENT_TEAM = 0.1, --组队建成比例，小数配置
}
