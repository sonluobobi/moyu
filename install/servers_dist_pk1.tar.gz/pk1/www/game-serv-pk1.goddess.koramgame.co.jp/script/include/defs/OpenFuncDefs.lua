--[[
系统功能开关，等级限制系统
author : shuyi.zhong
date : 2015-07-11
--]]

local tableInsert = table.insert

----- 注意，这里的ID不能修改

OpenFuncDefs =
{
	ID_FOR_CHARACTER = 1,	                -- 角色按钮及角色标签
	ID_FOR_SKILL_BASE = 3,			-- 技能标签-基础标签
	ID_FOR_SKILL_SENIOR = 4,		-- 技能标签-高级标签
	ID_FOR_HORSE = 5,			-- 坐骑标签/后续会改到坐骑按钮
	ID_FOR_QISHI = 6,			-- 骑士/后续会改为骑士按钮
	ID_FOR_JUEWEI = 7,			-- 爵位标签
	ID_FOR_WING = 8,			-- 翅膀标签

	ID_FOR_BAG = 9,			        -- 背包按钮及其全部标签

	ID_FOR_PET = 10,			-- 幻兽按钮及幻兽基础标签
	ID_FOR_PET_UPGRADE = 12,		-- 幻兽升级标签
	ID_FOR_PET_HUANGHUA = 13,		-- 幻兽幻化标签
	ID_FOR_PET_BAOWU_UPGRADE = 14,		-- 幻兽宝物升级标签
	ID_FOR_PET_CHUANGCHENG = 15,		 -- 幻兽传承标签
	ID_FOR_PET_TRAIN = 16,			-- 幻兽训练标签

	ID_FOR_EQUIP_DUANZHAO = 17,             -- 锻造按钮及强化标签
	ID_FOR_EQUIP_JINLIAN = 19,		-- 精炼标签
	ID_FOR_EQUIP_XIANQIAN = 20,		-- 镶嵌标签
	ID_FOR_EQUIP_HECHENG = 21,		-- 合成标签
	ID_FOR_EQUIP_XILIAN = 22,		-- 洗练标签

	ID_FOR_GANG = 23,			-- 军团按钮及主殿标签、大厅标签
	ID_FOR_GANG_SHOP = 26,			-- 商店标签
	ID_FOR_GANG_STORAGE = 27,		-- 仓库标签
	ID_FOR_GANG_SKILL = 28,			-- 科技标签

	ID_FOR_TRADE = 29,			-- 交易按钮及其下全部标签
	ID_FOR_JISHOU = 30,			-- 寄售功能
	ID_FOR_BUY = 31,			-- 购买物品功能

	ID_FOR_NVSHENG = 32,			-- 女神按钮及女神基础标签
	ID_FOR_TAOHAO = 33,			-- 讨好标签

	ID_FOR_PAIHANG = 34,			-- 排行按钮及其下全部标签

	ID_FOR_LINGQUTILI = 35,			-- 领取体力
	ID_FOR_YUNYINHUODONG = 36,		-- 等级开服礼包
	ID_FOR_DAILY_TASK = 37,			-- 每日任务
	ID_FOR_DAILY_SIGN_IN = 38,		-- 每日签到
	ID_FOR_PET_ZHADAN = 39,			-- 砸蛋按钮及砸蛋标签
	ID_FOR_PET_JITANG = 40,			-- 幻兽祭坛

	ID_FOR_WANFA = 41,			-- 玩法按钮及日常标签、组队标签
	ID_FOR_GUANGKA = 42,			-- 关卡 后续会改为单独一个按钮
	ID_FOR_DUOBAO = 44,			-- 夺宝
	ID_FOR_JINJICHANG = 45,			-- 竞技场
	ID_FOR_SLAVE = 46,			-- 主仆


	ID_FOR_LINGWEI = 48,			-- 临危

	ID_FOR_DIGUOZHENGFENG = 50,		-- 帝国争锋
	ID_FOR_STAR_SUBLINE = 51,		-- 星级副本
	ID_FOR_BOSS_HOME = 52,			-- boss之家
	ID_FOR_3V3 = 53,			-- 3V3
	ID_FOR_HORNOR_SHOP = 54,		-- 荣誉商店，后续会改为单独一个按钮

	ID_FOR_TUOGUANG = 55,			-- 托管功能
	ID_FOR_GUANGKALIANZHAN = 56,	        -- 关卡连战X次功能
	ID_FOR_DUOBAOLIANQIAN = 57,		-- 夺宝连抢X次功能
	ID_FOR_WORLD_CHAT = 58,			-- 世界频道发言
	ID_FOR_SCENE_CHAT = 59,			-- 附近频道发言
	ID_FOR_SHANCHENG = 60,			-- 商城
	
	ID_FOR_HETI_NEI = 62,			-- 幻兽内层合体
	ID_FOR_HETI_WAI = 63,			-- 幻兽外层合体

	ID_FOR_2v2 = 65,			-- 2v2

	ID_FOR_ZHENRONG = 66,			-- 侧边阵容按钮及阵容tab
	ID_FOR_QISHI_TISHENG = 67,		-- 用于控制骑士任命有属性加成，以及任命的骑士星级越高有加成
	ID_FOR_XIANJI = 68,		        -- 用于打开献祭界面，查看掉落需要
	ID_FOR_BIANQIANG = 69,			-- 用于控制什么时候开始变强提醒

	ID_FOR_XINGZUO = 70,			-- 星座
	ID_FOR_PET_SUIPIAN = 71,		-- 幻兽界面碎片tab
        ID_FOR_YICHU = 72,			-- 人物界面衣橱tab
        ID_FOR_SHEZHI = 73,			--  侧边菜单的设置按钮
	ID_FOR_CHENGHAO = 74,			--  人物界面的称号tab

	ID_FOR_GANG_WAR = 75,			-- 军团战
	ID_FOR_GANG_DARGON = 76,		-- 屠龙
	ID_FOR_TUIBI = 77,			-- 推币机
	ID_FOR_GANG_TOWER = 78,			-- 豆蔓爬塔
	ID_FOR_GET_PET = 79,			-- 获得初始出战幻兽
	ID_FOR_GET_HORSE = 80,			-- 获得初始马
	ID_FOR_SUBLINE_45 = 81,			-- 45副本 

	ID_FOR_PIGEON = 82,			--飞鸽
	ID_FOR_FRIEND = 83,			--好友
	ID_FOR_RECHARGE = 84,			--充值和首冲
	ID_FOR_VIP = 85,			--VIP
	ID_FOR_MONTHCARD = 86,			--月卡
	ID_FOR_FUND = 87,			--基金
	ID_FOR_CAT = 88,			--招财猫
	ID_FOR_GET_WING = 89,			--充值得翅膀
	ID_FOR_HORSE_FRUIT = 90,		--坐骑果子
	ID_FOR_PARTNER = 91,			--推广伙伴

	ID_FOR_QIHUN = 92,			--器魂特效
	ID_FOR_8DAYS = 93,			--8天登录
	ID_FOR_GODDESS_REGION = 94,		--女神神域
	ID_FOR_GODDESS_JINJIE = 95,		--女神进阶
	ID_FOR_GODDESS_QIYUE = 96,		--祭坛-女神契约
	ID_FOR_LEVELGIFT = 97,			--登录礼
	ID_FOR_DAYGIFT = 98,			--等级礼
	ID_FOR_MEILI = 99,			--魅力竞赛
	ID_FOR_FASHION = 100,			--时装
	ID_FOR_GODDESS_REGION2 = 101,		--女神神域2
	ID_FOR_GODDESS_REGION3 = 102,		--女神神域3
	ID_FOR_GODDESS_REGION4 = 103,		--女神神域4

	ID_FOR_LOVE = 100,			--情侣
	ID_FOR_LOVE_GAY = 105,		        --允许同性结婚
	ID_FOR_FB_LIKE = 106,		        --关注fb 
	ID_FOR_FB_FRIEND = 107,		        --fb邀请好友 友谊之城
	ID_FOR_FB_GIFT = 108,		        --fb赠送 好友应援
	ID_FOR_DUOBIAO = 110,			--夺镖 美女与野兽
	ID_FOR_RECHARGE_5DAYS = 111,			--五天充值有礼
	ID_FOR_GOAL_7DAYS = 112,			--七天目标
	ID_FOR_BAOWU_JINLIAN = 113,			--宝物精炼
	ID_FOR_RING = 114,			--魔戒
	ID_FOR_ACTIVITY_CODE = 115,			--礼包码(激活码)

	ID_FOR_HORSE_EQUIP = 116,			--坐骑装备
	ID_FOR_GOD_EQUIP = 117,				--神兵
	--ID_FOR_HELP = 118,				--关注help
	ID_FOR_GET_EQUIP = 119,			--装备获取

	ID_FOR_MORI = 120,			--末日之战、诸神黄昏104
	ID_FOR_PET_UP = 121,			--幻兽进阶104
	ID_FOR_MARRY_FEAST = 122,			--婚宴104

	ID_FOR_RED1 = 123,			--110级-139级的关卡、副本、boss之家，红装
	ID_FOR_RED2 = 124,			--140级-169级的关卡、boss之家，红2装
	
	ID_FOR_AVATAR_UPGRADE = 125,		--时装升级
	ID_FOR_SHOP_VIP = 126,			--vip商城
	ID_FOR_SHOP_RECHARGE = 127,		--商城

	ID_FOR_MARRY_FEAST_GIFT = 128,		--婚宴送礼金（防信用卡退款）104

	ID_FOR_CASTLE = 129,			--地下城堡106
	ID_FOR_ELF = 130,			--配对孵化106
	ID_FOR_NIGHTMARE = 131,			--噩梦本106
	ID_FOR_GUARD = 132,			--精灵阵容守护106
	ID_FOR_RED3 = 133,			--135、145副本106

	ID_FOR_RED4 = 134,			--155、165副本107
	ID_FOR_ZOMBIE = 135,			--丧尸危机107
	ID_FOR_HORSE2 = 136,			--坐骑驯化107
	ID_FOR_BOSS50 = 139,			--boss之家50级 填1跨服，999单服(注:该配置不能热更新)
	ID_FOR_BOSS65 = 140,			--boss之家65级 填1跨服，999单服(注:该配置不能热更新)
	ID_FOR_SCORE = 141,			--商店评分107
	ID_FOR_EQUIP_HORSE_XIANQIAN = 142,		-- 坐骑宝石镶嵌
	ID_FOR_EQUIP_OTHER_XIANQIAN = 143,		-- 其他宝石镶嵌(神兵、翅膀等)
	ID_FOR_RED_GODD = 144,			-- 红女神
	ID_FOR_PET_UP6_10 = 145,		-- 幻兽进阶扩展6-10阶107

	ID_FOR_LOVE_PLACE = 146,		-- 爱情圣殿108
	ID_FOR_LOVERING_UP = 147,		-- 婚戒升级108
	ID_FOR_KNIGHT_HELP = 148,		-- 骑士助战108(骑士ID 1-4 不含宝物)
	ID_FOR_GOD_EQUIP6_8 = 149,		-- 神兵扩展6-8阶108
	ID_FOR_JEWEL_BLESS = 150,		-- 主角宝石祝福
	ID_FOR_JEWEL_BLESS_HORSE = 151,		-- 坐骑宝石祝福
	ID_FOR_JEWEL_BLESS_OTHER = 152,		-- 其他宝石祝福
	ID_FOR_KNIGHT_HELP_BW = 153,		-- 骑士助战宝物部分
	ID_FOR_KNIGHT_HELP_5 = 154,		-- 骑士助战108(骑士ID 5-7)
	ID_FOR_KNIGHT_HELP_8 = 155,		-- 骑士助战108(骑士ID 8-10)
	ID_FOR_RED5 = 156,			--170级-199级的关卡、boss之家，产出幻兽双星
	ID_FOR_BACK = 157,			-- 奖励找回
	ID_FOR_TOW_STAR = 158,			-- 幻兽双星108
	
	---------------------------------------------------
	ID_2_VALUE = {},			-- 功能开放对应的任务id or等级。1000以上为任务，1000以下为等级

	---------------------------------------------------
	TASK_OPEN_LIST = {},			-- 任务开启的(程序自动生成)
	ARRAY_ID_2_VALUE = {},			-- 数组结构(程序自动生成)
	LEVEL_2_FUN_LIST = {},			-- 等级开启（程序自动生成），用于功能开启后的初始化
}

--------------------------------------------------
local ID_2_VALUE = OpenFuncDefs.ID_2_VALUE

ID_2_VALUE[ OpenFuncDefs.ID_FOR_CHARACTER ] = 1			   --角色
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SKILL_BASE ] = 2		  --技能基础
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SKILL_SENIOR ] = 9		  --技能高级
ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE ] = 34			  --坐骑
ID_2_VALUE[ OpenFuncDefs.ID_FOR_QISHI ] = 58			  --骑士
ID_2_VALUE[ OpenFuncDefs.ID_FOR_JUEWEI ] = 38			  --爵位
ID_2_VALUE[ OpenFuncDefs.ID_FOR_WING ] = 1			  --翅膀

ID_2_VALUE[ OpenFuncDefs.ID_FOR_BAG ] = 1			 --背包

ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET ] = 5			  --幻兽
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UPGRADE ] = 1002601		 --幻兽升级
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_HUANGHUA ] = 1001101	  --幻兽幻化
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_BAOWU_UPGRADE ] = 1003101    --幻兽宝物升级
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_CHUANGCHENG ] = 1001401       --传承
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_TRAIN ] = 1005801            --训练66级

ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_DUANZHAO ] = 7		  --锻造
ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_JINLIAN ] = 62             --精炼
ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_XIANQIAN ] = 52	    --镶嵌宝石52级
ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_HECHENG ] = 52	       --宝石合成
ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_XILIAN ] = 40              --洗炼

ID_2_VALUE[ OpenFuncDefs.ID_FOR_GANG ] = 29			 --军团
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GANG_SHOP ] = 29
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GANG_STORAGE ] = 29
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GANG_SKILL ] = 29		 -- 军团等级10级开启(特殊)

ID_2_VALUE[ OpenFuncDefs.ID_FOR_TRADE ] = 18                   --交易
ID_2_VALUE[ OpenFuncDefs.ID_FOR_JISHOU ] = 21                  --寄售
ID_2_VALUE[ OpenFuncDefs.ID_FOR_BUY ] = 18                     --购买

ID_2_VALUE[ OpenFuncDefs.ID_FOR_NVSHENG ] = 16                 --女神
ID_2_VALUE[ OpenFuncDefs.ID_FOR_TAOHAO ] = 16                  --讨好

ID_2_VALUE[ OpenFuncDefs.ID_FOR_PAIHANG ] = 42                 --排行

ID_2_VALUE[ OpenFuncDefs.ID_FOR_LINGQUTILI ] = 19               --领取体力
ID_2_VALUE[ OpenFuncDefs.ID_FOR_YUNYINHUODONG ] = 1             --运营活动
ID_2_VALUE[ OpenFuncDefs.ID_FOR_DAILY_TASK ] = 1002701          --每日任务27级
ID_2_VALUE[ OpenFuncDefs.ID_FOR_DAILY_SIGN_IN ] = 68            --签到
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_ZHADAN ] = 1001401          --砸蛋
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_JITANG ] = 1002001          --祭坛

ID_2_VALUE[ OpenFuncDefs.ID_FOR_WANFA ] = 10			  --玩法；子玩法都是等级开启
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUANGKA ] = 2                   --关卡
ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBAO ] = 23                   --夺宝
ID_2_VALUE[ OpenFuncDefs.ID_FOR_JINJICHANG ] = 17               --竞技场
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SLAVE ] = 54                    --主仆

ID_2_VALUE[ OpenFuncDefs.ID_FOR_LINGWEI ] = 41                    --野外
ID_2_VALUE[ OpenFuncDefs.ID_FOR_DIGUOZHENGFENG ] = 31           --帝国
ID_2_VALUE[ OpenFuncDefs.ID_FOR_STAR_SUBLINE ] = 35             --副本
ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS_HOME ] = 50                --boss之家
ID_2_VALUE[ OpenFuncDefs.ID_FOR_3V3 ] = 60                      --3v3
ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORNOR_SHOP ] = 31              --荣誉商店

ID_2_VALUE[ OpenFuncDefs.ID_FOR_TUOGUANG ] = 3                  --托管
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUANGKALIANZHAN ] = 43          --连战
ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBAOLIANQIAN ] = 37           --连抢
ID_2_VALUE[ OpenFuncDefs.ID_FOR_WORLD_CHAT ] = 30               --世界聊天
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCENE_CHAT ] = 30               --附近聊天
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PIGEON ] = 1					--飞鸽
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHANCHENG ] = 52                 --商城

ID_2_VALUE[ OpenFuncDefs.ID_FOR_HETI_NEI ] = 14                 --幻兽内层合体
ID_2_VALUE[ OpenFuncDefs.ID_FOR_HETI_WAI ] = 44                 --幻兽外层合体

ID_2_VALUE[ OpenFuncDefs.ID_FOR_2v2 ] = 10			  --2v2

ID_2_VALUE[ OpenFuncDefs.ID_FOR_ZHENRONG ] = 5				-- 侧边菜单的阵容按钮及阵容tab (出战一起开启)
ID_2_VALUE[ OpenFuncDefs.ID_FOR_QISHI_TISHENG ] = 999		-- 用于控制骑士任命有属性加成，以及任命的骑士星级越高有加成
ID_2_VALUE[ OpenFuncDefs.ID_FOR_XIANJI ] = 1002001	        -- 献祭；用于查看掉落
ID_2_VALUE[ OpenFuncDefs.ID_FOR_BIANQIANG ] = 8		        -- 用于控制什么时候开始变强提醒

ID_2_VALUE[ OpenFuncDefs.ID_FOR_XINGZUO ] = 1002899              -- 星座
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_SUIPIAN ] = 39                   -- 幻兽碎片

ID_2_VALUE[ OpenFuncDefs.ID_FOR_YICHU ] = 34			-- 衣橱
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHEZHI ] = 1                   -- 设置
ID_2_VALUE[ OpenFuncDefs.ID_FOR_CHENGHAO ] = 1			-- 称号
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GANG_WAR ] = 29			-- 军团战

ID_2_VALUE[ OpenFuncDefs.ID_FOR_GANG_DARGON ] = 29		-- 屠龙
ID_2_VALUE[ OpenFuncDefs.ID_FOR_TUIBI ] = 25			-- 推币机
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GANG_TOWER ] = 57		-- 豆蔓爬塔
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GET_PET ] = 1000501		-- 获得初始出战幻兽
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GET_HORSE ] = 1001102		-- 获得初始马
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SUBLINE_45 ] = 45		-- 45副本 

ID_2_VALUE[ OpenFuncDefs.ID_FOR_FRIEND ] = 1                   -- 好友
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RECHARGE ] = 1		       --充值和首冲
ID_2_VALUE[ OpenFuncDefs.ID_FOR_VIP ] = 1			 --VIP
ID_2_VALUE[ OpenFuncDefs.ID_FOR_MONTHCARD ] = 1		        --月卡
ID_2_VALUE[ OpenFuncDefs.ID_FOR_FUND ] = 1			--基金
ID_2_VALUE[ OpenFuncDefs.ID_FOR_CAT ] = 15			--招财猫
ID_2_VALUE[ OpenFuncDefs.ID_FOR_WING ] = 1			--充值得翅膀
ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE_FRUIT ] = 34	        --坐骑果子
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900			 --推广伙伴
ID_2_VALUE[ OpenFuncDefs.ID_FOR_QIHUN ] = 1			 --器魂特效
ID_2_VALUE[ OpenFuncDefs.ID_FOR_8DAYS ] = 16			 --8天登录
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GODDESS_REGION ] = 1004399	 --女神神域43级
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GODDESS_JINJIE ] = 76			 --女神进阶
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GODDESS_QIYUE ] = 76			 --祭坛-女神契约
ID_2_VALUE[ OpenFuncDefs.ID_FOR_LEVELGIFT ] = 300			--登录礼
ID_2_VALUE[ OpenFuncDefs.ID_FOR_DAYGIFT ] = 1			 --等级礼
ID_2_VALUE[ OpenFuncDefs.ID_FOR_MEILI ] = 1			 --魅力竞赛
ID_2_VALUE[ OpenFuncDefs.ID_FOR_FASHION ] = 1			 --时装
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GODDESS_REGION2 ] = 59			 --女神神域2
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GODDESS_REGION3 ] = 63			 --女神神域3
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GODDESS_REGION4 ] = 67			 --女神神域4

ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33				--情侣
ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_GAY ] = 999			--同性结婚
ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_LIKE ] = 199				--关注fb
ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_FRIEND ] = 199			--fb邀请好友 友谊之城
ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_GIFT ] = 199				--fb赠送 好友应援

ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBIAO ] = 72				--夺镖 美女与野兽102
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RECHARGE_5DAYS ] = 1			--五天充值有礼
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GOAL_7DAYS ] = 1			--七天目标
ID_2_VALUE[ OpenFuncDefs.ID_FOR_BAOWU_JINLIAN ] = 87                   --宝物精炼
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RING ] = 72			           --魔戒102
ID_2_VALUE[ OpenFuncDefs.ID_FOR_ACTIVITY_CODE ] = 1			--礼包码(激活码)

ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE_EQUIP ] = 80			--坐骑装备103
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GOD_EQUIP ] = 1			        --神兵103
--ID_2_VALUE[ OpenFuncDefs.ID_FOR_HELP ] = 190			        --关注help103(已废弃，因已在固化活动表录入)
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GET_EQUIP ] = 43			        --装备获取103

ID_2_VALUE[ OpenFuncDefs.ID_FOR_MORI ] = 93			        --末日之战、诸神黄昏104
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP ] = 40			        --幻兽进阶104-5
ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 51			--婚宴104-5

ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 1			--140级-169级的关卡、副本、boss之家，红2装
ID_2_VALUE[ OpenFuncDefs.ID_FOR_AVATAR_UPGRADE ] = 1		--时装升级

ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_VIP ] = 52			--VIP商城
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_RECHARGE ] = 52		--充值商城

ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 51		--婚宴送礼金（防信用卡退款）104

ID_2_VALUE[ OpenFuncDefs.ID_FOR_CASTLE ] = 77		--地下城堡106
ID_2_VALUE[ OpenFuncDefs.ID_FOR_ELF ] = 77		--配对孵化
ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 1		--噩梦本
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUARD ] = 77		--精灵阵容守护
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1		--135、145副本

ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED4 ] = 1			--155、165副本107
ID_2_VALUE[ OpenFuncDefs.ID_FOR_ZOMBIE ] = 97			--丧尸危机107
ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE2 ] = 97			--坐骑驯化107
ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS50 ] = 1			--boss之家50级 填1跨服，999单服(注:该配置不能热更新)
ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS65 ] = 1			--boss之家65级 填1跨服，999单服(注:该配置不能热更新)
ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_HORSE_XIANQIAN ] = 52      --坐骑宝石镶嵌
ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_OTHER_XIANQIAN ] = 999      --其他宝石镶嵌(神兵、翅膀等)
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED_GODD ] = 30			  --红女神
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 999			--商店评分 1开 其他关
ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP6_10 ] = 1		-- 幻兽进阶扩展6-10阶107

ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_PLACE ] = 68		-- 爱情圣殿108
ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVERING_UP ] = 68		-- 婚戒升级108
ID_2_VALUE[ OpenFuncDefs.ID_FOR_GOD_EQUIP6_8 ] = 1		-- 神兵扩展6-8阶108
ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS ] = 1			-- 主角宝石祝福
ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_HORSE ] = 999		--坐骑宝石祝福
ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_OTHER ] = 999		--其他宝石祝福
ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_BW ] = 999		--骑士助战宝物部分
ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP ] = 1		-- 骑士助战108(不含宝物)
ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_5 ] = 999		--骑士助战108(骑士ID 5-7)(如果热更新,需要修改PetConfig.php文件)
ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_8 ] = 999		--骑士助战108(骑士ID 8-10)
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED5 ] = 1			--170级-199级的关卡、boss之家，产出幻兽双星
ID_2_VALUE[ OpenFuncDefs.ID_FOR_BACK ] = 1			--奖励找回
ID_2_VALUE[ OpenFuncDefs.ID_FOR_TOW_STAR ] = 170		--幻兽双星

----- 多语言开关 add by suwin zhong at 2016-01-27 start -----
if Language:isEN() then -- 英文版本 (包含了东南亚 南美 欧洲 北美 新北美等)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900			 --推广伙伴
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_WORLD_CHAT ] = 15               --世界聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCENE_CHAT ] = 15               --附近聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TRADE ] = 74                   --交易 999定义为侧边栏不可见此按钮，后续按钮排序顶上
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JISHOU ] = 74                  --寄售
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BUY ] = 74                     --购买
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_LIKE ] = 999			--关注fb
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_FRIEND ] = 1			--fb邀请好友 友谊之城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_GIFT ] = 1			--fb赠送 好友应援
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33			--情侣
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 1			--140级-169级的关卡、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHANCHENG ] = 35                 --基础商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_VIP ] = 35			--VIP商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_RECHARGE ] = 35		--充值商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 999		--婚宴送礼金（防信用卡退款）104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_GAY ] = 1			--同性结婚
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 51			--婚宴104-5
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1			--135、145副本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 1			--商店评分107 
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED4 ] = 1			--155、165副本107
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS50 ] = 1			--boss之家50级 填1跨服，999单服(注:该配置不能热更新)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS65 ] = 1			--boss之家65级 填1跨服，999单服(注:该配置不能热更新)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP6_10 ] = 999		-- 幻兽进阶扩展6-10阶107

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_PLACE ] = 68		-- 爱情圣殿108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVERING_UP ] = 68		-- 婚戒升级108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GOD_EQUIP6_8 ] = 1		-- 神兵扩展6-8阶108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS ] = 1			-- 主角宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_HORSE ] = 999		--坐骑宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_OTHER ] = 999		--其他宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_BW ] = 999		--骑士助战宝物部分
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP ] = 999		-- 骑士助战108(不含宝物)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_5 ] = 999		--骑士助战108(骑士ID 5-7)(如果热更新,需要修改PetConfig.php文件)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_8 ] = 999		--骑士助战108(骑士ID 8-10)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED5 ] = 999			--170级-199级的关卡、boss之家，产出幻兽双星
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BACK ] = 1			--奖励找回
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TOW_STAR ] = 999		--幻兽双星




end

local my_area_id = (external and external.getVouchAid and external.getVouchAid()) or 2078001

-- 俄罗斯大区
if Language:isWorldAreaELuoSi() then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900			 --推广伙伴
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_WORLD_CHAT ] = 15               --世界聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCENE_CHAT ] = 15               --附近聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TRADE ] = 74                   --交易 999定义为侧边栏不可见此按钮，后续按钮排序顶上
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JISHOU ] = 74                  --寄售
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BUY ] = 74                     --购买
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_LIKE ] = 999			--关注fb
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_FRIEND ] = 1			--fb邀请好友 友谊之城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_GIFT ] = 1			--fb赠送 好友应援

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHANCHENG ] = 35                 --基础商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_VIP ] = 35			--VIP商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_RECHARGE ] = 35		--充值商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE_EQUIP ] = 80			--坐骑装备103
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RING ] = 72			           --魔戒102
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBIAO ] = 72				--夺镖 美女与野兽102

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33				--情侣
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_GAY ] = 1				--同性结婚
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 999		--婚宴送礼金（防信用卡退款）104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 51			--婚宴104-5

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MORI ] = 93			        --末日之战、诸神黄昏104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP ] = 40			        --幻兽进阶104-5
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_CASTLE ] = 999				--地下城堡106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ELF ] = 999				--配对孵化
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 999			--噩梦本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUARD ] = 999				--精灵阵容守护

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 999			--140级-169级的关卡、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 999			--135、145副本

	
	-- 评审费
	if my_area_id == 4138801 then
		ID_2_VALUE[ OpenFuncDefs.ID_FOR_FUND ] = 199			--基金
	end
end

-- 东南亚(新马)
if Language:isWorldAreaDongNanYa() then
	
end

-- 台湾
if Language:isTW() then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 1			--140级-169级的关卡、副本、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1			--135、145副本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_CASTLE ] = 77		--地下城堡106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ELF ] = 77		--配对孵化
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 1		--噩梦本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUARD ] = 77		--精灵阵容守护
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 999			--商店评分 1开 其他关
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED4 ] = 999			--155、165副本107
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ZOMBIE ] = 97			--丧尸危机107
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE2 ] = 97			--坐骑驯化107
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS50 ] = 1			--boss之家50级单服填1跨服，999单服(注:该配置不能热更新)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS65 ] = 1			--boss之家65级单服填1跨服，999单服(注:该配置不能热更新)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_HORSE_XIANQIAN ] = 52      --坐骑宝石镶嵌
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_OTHER_XIANQIAN ] = 999      --其他宝石镶嵌(神兵、翅膀等)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED_GODD ] = 30			    --红女神
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP6_10 ] = 1		-- 幻兽进阶扩展6-10阶107

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_PLACE ] = 68		-- 爱情圣殿108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVERING_UP ] = 68		-- 婚戒升级108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GOD_EQUIP6_8 ] = 1		-- 神兵扩展6-8阶108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS ] = 1			-- 主角宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_HORSE ] = 999		--坐骑宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_OTHER ] = 999		--其他宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_BW ] = 999		--骑士助战宝物部分
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP ] = 1		-- 骑士助战108(不含宝物)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_5 ] = 999		--骑士助战108(骑士ID 5-7)(如果热更新,需要修改PetConfig.php文件)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_8 ] = 999		--骑士助战108(骑士ID 8-10)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED5 ] = 999			--170级-199级的关卡、boss之家，产出幻兽双星
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BACK ] = 1			--奖励找回
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TOW_STAR ] = 999		--幻兽双星

		
end

-- 韩国 开交易 fb 国服台湾内置活动
if Language:isWorldAreaHanGuo() then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900		--推广伙伴
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_WORLD_CHAT ] = 15               --世界聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCENE_CHAT ] = 15               --附近聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_LIKE ] = 1			--关注fb
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_FRIEND ] = 1			--fb邀请好友 友谊之城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_GIFT ] = 1			--fb赠送 好友应援

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MORI ] = 93			        --末日之战、诸神黄昏104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP ] = 40			        --幻兽进阶104-5
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33				--情侣
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 51			--婚宴104-5
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 51		--婚宴送礼金（防信用卡退款）104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_GAY ] = 999			--同性结婚
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBIAO ] = 72				--美女与野兽102

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 1			--商店评分 1开 其他关
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS50 ] = 999			--boss之家50级单服填1跨服，999单服(注:该配置不能热更新)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS65 ] = 999			--boss之家65级单服填1跨服，999单服(注:该配置不能热更新)

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_CASTLE ] = 77		--地下城堡106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ELF ] = 77		--配对孵化
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUARD ] = 77		--精灵阵容守护

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1		--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 999		--140级-169级的关卡、副本、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1		--135、145副本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 1		--噩梦本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED4 ] = 999		--155、165副本107
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ZOMBIE ] = 97		--丧尸危机107
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE2 ] = 97		--坐骑驯化107

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_HORSE_XIANQIAN ] = 52      --坐骑宝石镶嵌
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_OTHER_XIANQIAN ] = 999      --其他宝石镶嵌(神兵、翅膀等)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED_GODD ] = 30			  --红女神
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP6_10 ] = 999		-- 幻兽进阶扩展6-10阶107

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_PLACE ] = 999		-- 爱情圣殿108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVERING_UP ] = 999		-- 婚戒升级108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GOD_EQUIP6_8 ] = 1		-- 神兵扩展6-8阶108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS ] = 999			-- 主角宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_HORSE ] = 999		--坐骑宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_OTHER ] = 999		--其他宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_BW ] = 999		--骑士助战宝物部分
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP ] = 999		-- 骑士助战108(不含宝物)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_5 ] = 999		--骑士助战108(骑士ID 5-7)(如果热更新,需要修改PetConfig.php文件)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_8 ] = 999		--骑士助战108(骑士ID 8-10)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED5 ] = 1			--170级-199级的关卡、boss之家，产出幻兽双星
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BACK ] = 1			--奖励找回
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TOW_STAR ] = 170		--幻兽双星

	
	-- 韩服T2关闭充值
	if my_area_id == 4139802 then
		ID_2_VALUE[ OpenFuncDefs.ID_FOR_RECHARGE ] = 999		       --充值和首冲
	end
end

-- QUICKIOS
if Language:isCnAreaQuickIOS() then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ACTIVITY_CODE ] = 900			--礼包码(激活码)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MORI ] = 93			        --末日之战、诸神黄昏104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP ] = 999			        --幻兽进阶104-5

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33			--情侣
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 1		--婚宴送礼金（防信用卡退款）104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_GAY ] = 999		--同性结婚
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 51		--婚宴104-5

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 999			--140级-169级的关卡、副本、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 999			--135、145副本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 999			--商店评分107
end

-- 欧洲大区 开交易 fb
if Language:isWorldAreaOuZhou(my_area_id) then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900			 --推广伙伴
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_WORLD_CHAT ] = 15               --世界聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCENE_CHAT ] = 15               --附近聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TRADE ] = 74                   --交易 999定义为侧边栏不可见此按钮，后续按钮排序顶上
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JISHOU ] = 74                  --寄售
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BUY ] = 74                     --购买
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_LIKE ] = 1			--关注fb
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_FRIEND ] = 1			--fb邀请好友 友谊之城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_GIFT ] = 1			--fb赠送 好友应援
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHANCHENG ] = 35                 --基础商城	
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_VIP ] = 35			--VIP商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_RECHARGE ] = 35		--充值商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS50 ] = 999			--boss之家50级单服填1跨服，999单服(注:该配置不能热更新)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BOSS65 ] = 999			--boss之家65级单服填1跨服，999单服(注:该配置不能热更新)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 1			--商店评分 1开 其他关

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33			--情侣 33
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_GAY ] = 1		--同性结婚
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 1		--婚宴104-5 51
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 51	--婚宴送礼金（防信用卡退款）104 51

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBIAO ] = 72			--夺镖 美女与野兽102 72
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MORI ] = 93			--末日之战、诸神黄昏104 93
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP ] = 40			--幻兽进阶104-5  40

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 1			--140级-169级的关卡、副本、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1			--135、145副本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED4 ] = 1			--155、165副本107

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_CASTLE ] = 77		--地下城堡106 77
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ELF ] = 77		--配对孵化 77
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 1	--噩梦本 1
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUARD ] = 77		--精灵阵容守护 77

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ZOMBIE ] = 97		--丧尸危机107 97
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE2 ] = 97			--坐骑驯化107 97

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_HORSE_XIANQIAN ] = 52      --坐骑宝石镶嵌 52
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_EQUIP_OTHER_XIANQIAN ] = 52      --其他宝石镶嵌(神兵、翅膀等)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED_GODD ] = 30			 --红女神
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP6_10 ] = 1		-- 幻兽进阶扩展6-10阶107

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_PLACE ] = 68		-- 爱情圣殿108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVERING_UP ] = 68		-- 婚戒升级108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GOD_EQUIP6_8 ] = 1		-- 神兵扩展6-8阶108
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS ] = 1			-- 主角宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_HORSE ] = 1		--坐骑宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JEWEL_BLESS_OTHER ] = 1		--其他宝石祝福
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_BW ] = 999		--骑士助战宝物部分
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP ] = 1		-- 骑士助战108(不含宝物)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_5 ] = 999		--骑士助战108(骑士ID 5-7)(如果热更新,需要修改PetConfig.php文件)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_KNIGHT_HELP_8 ] = 999		--骑士助战108(骑士ID 8-10)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED5 ] = 1			--170级-199级的关卡、boss之家，产出幻兽双星
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BACK ] = 1			--奖励找回
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TOW_STAR ] = 170		--幻兽双星
end

-- 南美大区 不开交易 开fb
if Language:isWorldAreaNanMei(my_area_id) then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900			 --推广伙伴总是不开的
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_WORLD_CHAT ] = 15               --世界聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCENE_CHAT ] = 15               --附近聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TRADE ] = 74                   --交易 999定义为侧边栏不可见此按钮，后续按钮排序顶上
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JISHOU ] = 74                  --寄售
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BUY ] = 74                     --购买
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_LIKE ] = 999			--关注fb
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_FRIEND ] = 1			--fb邀请好友 友谊之城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_GIFT ] = 1			--fb赠送 好友应援
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHANCHENG ] = 35                 --基础商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_VIP ] = 35			--VIP商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_RECHARGE ] = 35		--充值商城
		
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE_EQUIP ] = 80		--坐骑装备103
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RING ] = 72			--魔戒102

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33				--情侣
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_GAY ] = 1				--同性结婚
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 999		--婚宴送礼金（防信用卡退款）104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 51			--婚宴104-5

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBIAO ] = 72			--夺镖 美女与野兽102
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MORI ] = 93			 --末日之战、诸神黄昏104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP ] = 40			        --幻兽进阶104-5
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_CASTLE ] = 999			--地下城堡106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ELF ] = 999			--配对孵化106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUARD ] = 999			--精灵阵容守护106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 999		--噩梦本106

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 999			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 999			--140级-169级的关卡、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 999			--135、145副本

	if my_area_id == 4141802 then
		ID_2_VALUE[ OpenFuncDefs.ID_FOR_RECHARGE ] = 999		       --充值和首冲
	end
end

-- 国内对外测试服 S4
if my_area_id == 2078004 then
ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 32				--情侣
ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBIAO ] = 72				--夺镖 美女与野兽
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RING ] = 72			           --魔戒
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 1			--140级-169级的关卡、boss之家，红2装
ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 1		--噩梦本
ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1			--135、145副本
ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 999			--商店评分 1开 其他关
end

-- 国内对外测试服 S7
if my_area_id == 2078007 then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 1			--140级-169级的关卡、副本、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1			--135、145副本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 999			--商店评分 1开 其他关
end

-- IOS服
if my_area_id >= 2104001 and my_area_id <= 2104999 then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ACTIVITY_CODE ] = 900			 --礼包码(激活码)
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 1			--140级-169级的关卡、副本、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1			--135、145副本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCORE ] = 999			--商店评分107 
end

-- IOS评审服
if my_area_id == 2104001 or my_area_id == 2104002 then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900			 --推广伙伴
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ACTIVITY_CODE ] = 900			 --礼包码(激活码)
end

-- 台服T2
if my_area_id == 4137802 then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RECHARGE ] = 999		       --充值和首冲
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GET_WING ] = 999
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RECHARGE_5DAYS ] = 999
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_RECHARGE ] = 999
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MONTHCARD ] = 999
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FUND ] = 999
end

-- 新北美
if Language:isWorldAreaBeiMeiNew() then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900			 --推广伙伴
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_WORLD_CHAT ] = 15               --世界聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCENE_CHAT ] = 15               --附近聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TRADE ] = 74                   --交易 999定义为侧边栏不可见此按钮，后续按钮排序顶上
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JISHOU ] = 74                  --寄售
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BUY ] = 74                     --购买
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_LIKE ] = 999			--关注fb
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_FRIEND ] = 1			--fb邀请好友 友谊之城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_GIFT ] = 1			--fb赠送 好友应援
	
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33			--情侣
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 51		--婚宴送礼金（防信用卡退款）10
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 51			--婚宴104-5
	
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 1			--140级-169级的关卡、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 1			--135、145副本
	
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHANCHENG ] = 35                 --基础商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_VIP ] = 35			--VIP商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_RECHARGE ] = 35		--充值商城

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MORI ] = 93			        --末日之战、诸神黄昏104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP ] = 40			        --幻兽进阶104-5
	
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE_EQUIP ] = 80			--坐骑装备103
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RING ] = 72			           --魔戒102
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBIAO ] = 72				--夺镖 美女与野兽102

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_CASTLE ] = 77		--地下城堡106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ELF ] = 77		--配对孵化
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 1		--噩梦本
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUARD ] = 77		--精灵阵容守护

end

-- 越泰 开交易 fb
if Language:isYueNanTaiGuo() then
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PARTNER ] = 900			 --推广伙伴总是不开的
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_WORLD_CHAT ] = 15               --世界聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SCENE_CHAT ] = 15               --附近聊天
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_TRADE ] = 15                   --交易 999定义为侧边栏不可见此按钮，后续按钮排序顶上
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_JISHOU ] = 15                  --寄售
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_BUY ] = 15                     --购买
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_LIKE ] = 1			--关注fb
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_FRIEND ] = 1			--fb邀请好友 友谊之城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_FB_GIFT ] = 1			--fb赠送 好友应援
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHANCHENG ] = 35                 --基础商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_VIP ] = 35			--VIP商城
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_SHOP_RECHARGE ] = 35		--充值商城
		
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_HORSE_EQUIP ] = 80		--坐骑装备103
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RING ] = 72			--魔戒102

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE ] = 33				--情侣
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_LOVE_GAY ] = 1			--同性结婚
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST_GIFT ] = 999		--婚宴送礼金（防信用卡退款）104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MARRY_FEAST ] = 51			--婚宴104-5
	
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_DUOBIAO ] = 72			--夺镖 美女与野兽102
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_MORI ] = 999			 --末日之战、诸神黄昏104
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_PET_UP ] = 40			        --幻兽进阶104-5
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_CASTLE ] = 77			--地下城堡106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_ELF ] = 77			--配对孵化106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_GUARD ] = 77			--精灵阵容守护106
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_NIGHTMARE ] = 999		--噩梦本106

	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED1 ] = 1			--110级-139级的关卡、副本、boss之家，红装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED2 ] = 999			--140级-169级的关卡、boss之家，红2装
	ID_2_VALUE[ OpenFuncDefs.ID_FOR_RED3 ] = 999			--135、145副本
	
	-- CBT T2服关闭充值
	if my_area_id == 4146802 then
		ID_2_VALUE[ OpenFuncDefs.ID_FOR_RECHARGE ] = 999		       --充值和首冲
	end 
end
	
----- 多语言开关 add by suwin zhong at 2016-01-27 end -------

-- 通过任务类型完成的功能
local TASK_OPEN_LIST = OpenFuncDefs.TASK_OPEN_LIST
local ARRAY_ID_2_VALUE = OpenFuncDefs.ARRAY_ID_2_VALUE
for open_func_id, value in pairs(ID_2_VALUE) do
	if 1000 < value then
		local task_open_list = TASK_OPEN_LIST[value]
		if not task_open_list then
			task_open_list = {}
		end
		tableInsert(task_open_list, open_func_id)
		TASK_OPEN_LIST[value] = task_open_list
	end
	
	local arr_now = {
			open_func_id = open_func_id,
			   condition = value,
					}
	tableInsert(ARRAY_ID_2_VALUE, arr_now)
end

-- 角色等级对应的功能列表(add by guoyin.huang)
local LEVEL_2_FUN_LIST = OpenFuncDefs.LEVEL_2_FUN_LIST
for open_func_id, value in pairs(ID_2_VALUE) do
	if 1000 > value then
		LEVEL_2_FUN_LIST[value] = LEVEL_2_FUN_LIST[value] or {}
		tableInsert(LEVEL_2_FUN_LIST[value], open_func_id)
	end
end