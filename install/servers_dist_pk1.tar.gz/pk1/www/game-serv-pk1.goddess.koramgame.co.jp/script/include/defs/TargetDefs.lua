--[[
目标系统定义
author : guoyin.huang
date : 2015-01-06
--]]

TargetDefs = {
	--目标状态
	TARGET_STATUS_DEFAULT   = 0, --未完成
	TARGET_STATUS_FINISHED  = 1, --已完成

	--目标类型定义
	TARGET_TYPE_CHARACTER_LEVEL= 1,  			--人物等级	
	TARGET_TYPE_CHARACTER_FC= 2,  				--人物战力 
	TARGET_TYPE_ZHANSHALI = 3,					--斩杀力
	TARGET_TYPE_STRONG = 4,						--全身强化等级
	TARGET_TYPE_BS = 5,							--全身宝石等级
	TARGET_TYPE_HORSE = 6,						--坐骑等级
	TARGET_TYPE_PET = 7,						--幻兽总星级
	TARGET_TYPE_JINLIAN = 8,					--全身精练等级
	TARGET_TYPE_STAR = 9,						--星座星级
	

	-- 需要广播的爵位等级
	TARGET_NEED_BROADCAST = 12,

	TARGET_MAX_LEVEL = 26,		--爵位最高等级
}
