--[[
成就系统定义
author : guoyin.huang
date : 2016-03-29
--]]

AchieveDefs = {
	-- 成就系统类型定义

	-- 检测完成型(需要写检测完成的函数)
	ACHIEVE_SORT_ID_LV = 1,						--达到一定等级
	ACHIEVE_SORT_ID_HORSE = 2,					--达到坐骑等级
	ACHIEVE_SORT_ID_FULL_BS_LV = 3,				--全身宝石等级
	ACHIEVE_SORT_ID_FIN_TOLLGATE = 4,			--通关某个关卡
	ACHIEVE_SORT_ID_FIN_ZB_PJ = 5,				--装备品阶达成
	ACHIEVE_SORT_ID_FIN_BABEL_LV = 6,			--豆蔓达到多少层
	ACHIEVE_SORT_ID_FIN_GODDESS = 7,			--获得某个女神
	ACHIEVE_SORT_ID_FIN_GANG_SKILL_LV = 8,		--军团科技累积达到多少积
	ACHIEVE_SORT_ID_FIN_FC = 9,					--战力达成


	-- 触发完成型（如果有传value,则会比较与配置文件中的value进行比较）
	ACHIEVE_SORT_ID_BC_GOLD_BW = 101,			--鞭笞出金色宝物
	ACHIEVE_SORT_ID_ARENA_CON_WIN = 102,		--竞技场连胜次数
	ACHIEVE_SORT_ID_DO_DAOJIANJUE_WIN_FIRST = 103,	--帝国争锋胜利并且是第一名
	ACHIEVE_SORT_ID_DO_DAOJIANJUE_LOSE_FIRST = 104,	--帝国争锋失败并且是第一名
	
	ACHIEVE_SORT_ID_DO_KILL_FC_OVER		= 106,		--杀死战力比自己高的玩家
	ACHIEVE_SORT_ID_DO_KILL_FC_OVER_20	= 107,		--杀死战力比自己高20%的玩家
	ACHIEVE_SORT_ID_DO_KILL_FC_OVER_30	= 108,		--杀死战力比自己高30%的玩家
	ACHIEVE_SORT_ID_DO_TBJ_GET_BAOXIANG = 109,		--推币机推落宝箱

	ACHIEVE_SORT_ID_DO_TIANMO_KILLER = 111,			--BOSS之家最后一击
	
	ACHIEVE_SORT_ID_DO_HONGBGAO_300 = 113,			--单次临危红包数量达到300
	ACHIEVE_SORT_ID_DO_KILLER_DSTS = 114,			--大杀特杀
	ACHIEVE_SORT_ID_DO_STOP_KILLER_DSTS = 115,		--终止大杀特杀
	ACHIEVE_SORT_ID_DO_ALL_7_PET = 116,				--集齐所有7资质幻兽
	ACHIEVE_SORT_ID_DO_ALL_10_PET = 117,				--集齐所有10资质幻兽



	-- 累积次数型(累积的次数会使用value 或者 1)
	ACHIEVE_SORT_ID_CNT_DAOJIANJUE_WIN = 201,			--帝国争锋胜利次数
	ACHIEVE_SORT_ID_CNT_SLAVE_ZS = 202,				 	--招收奴隶次数
	ACHIEVE_SORT_ID_CNT_SLAVE_JJ = 203,					--解救奴隶次数
	ACHIEVE_SORT_ID_CNT_SLAVE_FK = 204,					--反抗次数（不管成功与否）
	ACHIEVE_SORT_ID_CNT_TJJ_SILVER = 205,				--推币机累积金币数量
	ACHIEVE_SORT_ID_CNT_TRADE_BUY = 206,				--交易购买次数累积
	ACHIEVE_SORT_ID_CNT_TIANMO_GUWU = 207,				--BOSS之家使用鼓舞次数
	ACHIEVE_SORT_ID_CNT_TIANMO_WIN = 208,				--BOSS之家胜利次数
	ACHIEVE_SORT_ID_CNT_GODDESS_TH = 209,				--女神讨好次数
	ACHIEVE_SORT_ID_CNT_SHOP_HORNOR = 210,				--累积消耗的荣誉
	ACHIEVE_SORT_ID_CNT_KILL = 211,						--野外杀死玩家
	ACHIEVE_SORT_ID_CNT_BABEL_BOSS_NUM = 212,			--豆蔓BOSS层的次数
	ACHIEVE_SORT_ID_CNT_TB_DROP_1_TIME = 213,			--一次投币推下多少道具
	ACHIEVE_SORT_ID_CNT_SLAVE_FANKANG_SUC = 214,		--反抗成功的次数

}

-- 是否需要检测成就
function AchieveDefs:isNeedCheckAchieve()
	return not Language:isCN()
--	return true
end

AchieveDefs.need_2_pk = {
	[1] = AchieveDefs.ACHIEVE_SORT_ID_CNT_KILL,
	[2] = AchieveDefs.ACHIEVE_SORT_ID_CNT_TIANMO_WIN,
	[3] = AchieveDefs.ACHIEVE_SORT_ID_CNT_TIANMO_GUWU,
	[4] = AchieveDefs.ACHIEVE_SORT_ID_DO_STOP_KILLER_DSTS,
	[5] = AchieveDefs.ACHIEVE_SORT_ID_DO_KILLER_DSTS,
	[6] = AchieveDefs.ACHIEVE_SORT_ID_DO_HONGBGAO_300,
	[7] = AchieveDefs.ACHIEVE_SORT_ID_DO_KILL_FC_OVER,
	[8] = AchieveDefs.ACHIEVE_SORT_ID_DO_KILL_FC_OVER_20,
	[9] = AchieveDefs.ACHIEVE_SORT_ID_DO_KILL_FC_OVER_30,
}