--[[
军团战  defs
author: jianzhu
date: 2015-10-19
]]--

GangBattleDefs = {
	GANG_BATTLE_MAX_MUN_FOR_FINALS 	= 4,  	--军团战决赛军团数
	GANG_BATTLE_JOIN_GANG_DAYS_FOR_BATTLE   = 2*24*60, 	--参赛入团时间限制
	GANG_BATTLE_GANG_AWARDS_FOR_WIN 	= 10, --胜利队伍军团奖励积分
	GANG_BATTLE_GANG_AWARDS_FOR_LOSE 	= 2,  --失败队伍军团奖励积分

	--日期配置
	week_days_chusai = {3,4},	--初赛配置 0=星期天
	chusai_interval = 60*60, --初赛默认持续时间
	chusai_notice_interval = 3*60, --初赛结束公告延迟时间
	
	--初赛时间设置
	timestr_chusai = {
		[1] = {'21:00:00', '22:00:00'},
	},

	week_days_juesai = {6}, --决赛配置
	timestr_juesai_start = '21:00:00', --决赛开始时间
	juesai_interval = 15*60, --决赛持续时间
	juesai_prepare_time = 5*60, --决赛准备时间

	--状态定义
	STATUS_BEFORE_BATTLE = 1, --初赛开始前
	STATUS_IN_CHUSAI = 2, --初赛中
	STATUS_BEFORE_FINALS_BATTLE = 3, --初赛结束，决赛未开始
	STATUS_IN_FINALS_BATTLE = 4, --决赛中

	--王城定义
	GANG_BATTLE_CITY_NORTH = 1, --北城
	GANG_BATTLE_CITY_EAST = 2, --东城
	GANG_BATTLE_CITY_SOUTH = 3, --南城
	GANG_BATTLE_CITY_WEST = 4, --西城
}

-- 排名到王城
GangBattleDefs.rank_2_city = {
	[1] = GangBattleDefs.GANG_BATTLE_CITY_NORTH,
	[2] = GangBattleDefs.GANG_BATTLE_CITY_EAST,
	[3] = GangBattleDefs.GANG_BATTLE_CITY_SOUTH,
	[4] = GangBattleDefs.GANG_BATTLE_CITY_WEST,
}

function GangBattleDefs:getCityByRank(rank)
	return self.rank_2_city[rank]
end	