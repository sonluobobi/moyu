--[[
情侣婚戒定义
author : jinlin.liu
date : 2016-11-02
--]]
--默认是0星
LoverRingDefs =
{ 
  LOVER_RING_OPEN = 1, --开启状态
  LOVER_RING_CLOSED = 2,--关闭状态
  --36810
  LOVER_RING_QUIALITY_3 = 3, --银对戒
  LOVER_RING_QUIALITY_6 = 6, --白金对戒
  LOVER_RING_QUIALITY_8 = 8, --宝石对戒
  LOVER_RING_QUIALITY_10 = 10, --钻石对戒
}


