-- 自动搜索csv加载
g_csvs = 
{
	common = {
		"SceneBase",
	},
	
	map = {
		"FilterWords",      	-- 过滤
		
		"EquipDJBase",			-- 道具
		"EquipZBBase",			-- 装备
		"EquipBSBase",			-- 宝石
		"EquipBWBase",			-- 宝物
		"EquipCBBase",			-- 翅膀
		"EquipSpiritBase",		-- 精灵
		"EquipTowStarBase",		-- 双星
		"SkillBase",			-- 注：技能加载需要在怪物前面
		"SkillDetail",			-- 技能升级信息
		"MonsterBase",			-- 怪物基本信息
		"MonsterSkillAi",		-- 怪物技能ai
		"SceneAoi",				-- 场景aoi分布
		"TransferDotBase",		-- 传送点
		"TrapBase",				-- 陷阱
		"BufferBase",			-- buffer
		"EquipExtEffectBase",	-- 装备强化
		"PetBase",				-- 幻兽
		"PetExpBase",			-- 幻兽经验
		"DropPackBase",			-- 掉落物
		"TollgateChapterBase",	-- 关卡
		"BeastBase",			-- 召唤物
		"RandRewardPackBase",	-- 随机奖励包
		"EquipSuitBase",		-- 套装
		"HorseBase",			-- 坐骑
		"TaskBase",				-- 任务
		"DailyTaskUpgrade",		-- 每日任务升级
		"DailyTaskBase",		--每日任务
		"PetTroopBase",			-- 幻兽阵法
		"PetTroopEffectBase",	-- 幻兽阵法加成属性
		"WingFigure",			--翅膀外形
		"WingUpgrade",			--翅膀升级
		"TargetBase",			--目标系统
		"TargetDetail",			--目标详细
		"AchieveBase",			--成就
		"LoginRewardBase",		--登陆奖励
		"OnlineRewardBase",		--在线奖励
		"PetBreakLevBase",		-- 幻兽等级突破
		"ActiveBase",           -- 玩法表
		"ActiveSubBase",        -- 子玩法表
		"ShopBase", 			--商店
		"ShopEquip",			--商店道具
		"StrongSilverRatioBase",--装备强化银两消耗系数
		"GoddessBase",			--女神
		"SignBase",				--签到
		"Sign8Day",				--8天签到
		"GoddessMakeup",		--女神讨好
		"GoddessTemple",		--女神神殿
		"GuardNpcBase",
		"ScenePosition",		-- 场景中的坐标点
		"VipBase",				-- VIP功能
		"EquipJinglianBase",	-- VIP功能
		"OpeActiveDetail",		-- 活动礼包
		"TitleBase",			-- 称号
		"PetTianfuBase",		-- 幻兽天赋
		"PetHuanhuaBase",	-- 幻兽幻化属性
		"StarBase", 		--星座基本
		"StarDetail",  		--星座详情
		"BabelBase",		--试炼塔
		"GangDragon",			--军团屠龙等级奖励
		"GangDragonHarm",		--军团屠龙伤害龙币对应配置
		"GangSkillBase",		-- 军团科技
		"RewardSpecialBase",	--特殊奖励包
		"VoucherMallBase",		--充值商城
		"QihunBase",			--器魂
		"ShouhunShopBase",		-- 兽魂商店
		"ShouhunShopQiyue",		--契约
		"SceneBufferBase",		-- 场景BUFFER基础表
		"SceneBufferRefBase",	-- 场景BUFFER刷新表
		"RingUpgrade",
		"LoverRingUpgrade",     -- 婚戒
		"GashaponBase",			-- 扭蛋
		"GashaponDetail",		-- 扭蛋
		"ShenbingBase",			-- 神兵基础
		"ShenbingDetail",		-- 神兵详细
		"HorseUpgradeBase",		-- 坐骑速度升级 
		"TujianBase",			-- 图鉴
		"AvatarUpgradeBase",	-- 时装升级
		"Wedding", 				--婚宴		
		"PetUpQualityBase",		-- 幻兽升阶
		"ActiveRewardZhaohui",	-- 玩法
		"SpiritDefaultEffect",	-- 精灵默认属性配置
		"SpiritUpgradeBase",			-- 精灵基础配置
		"UndercroftBase",		-- 地下城堡基础配置
		"UndercroftExpReward",	-- 地下城堡冒险值奖励配置
		"MatchEgg",	-- 孵化配置
		"DaojianjueWeekReward",	-- 帝国争锋周奖励
		"HorseXunhuaBase",		-- 坐骑驯化
		"ShenbingSkillBase",		-- 神兵技能
		"ShenbingXilianBase",	-- 神兵洗练基础
		"ShenbingXilianDetail",	-- 神兵洗练详细
	},
	
	base = {
	
		"FilterWords",      	-- 过滤
		"VipBase",				-- VIP功能
		"ActiveBase",           -- 玩法表
		"ActiveSubBase",        -- 子玩法表
		"EquipDJBase",			-- 道具
		"EquipZBBase",			-- 装备
		"EquipBSBase",			-- 宝石
		"EquipBWBase",			-- 宝物
		"EquipCBBase",			-- 翅膀		
		"EquipSpiritBase",		-- 精灵
		"EquipTowStarBase",		-- 双星
		--"GangSkillBase",		-- 军团科技
		"TeamBase",				-- 组队
		"LinweiTaskBase",		--临危任务
		"ToplistReward",		--排行榜奖励
		"GangDragon",			--军团屠龙等级奖励
		"RewardSpecialBase",	--特殊奖励包
		"OpeActiveBase",		-- 活动礼包名称
		"FriendsLevel", 		-- 好友系统
		"CharmReward",     		-- 魅力活动
		"OpeActivityFixBase",		-- 固化活动表
		"OpeActivityItemFixBase",	-- 固化活动项表
		"GashaponBase",			-- 扭蛋
		"GashaponDetail",		-- 扭蛋
		"FinalWarReward", --子玩法奖励
		"Wedding", --婚宴
		"MatchEgg",   -- 孵化配置
		"TitleBase",		-- 称号
	},
	
	db = {
		"FilterWords",      	-- 过滤
		
		"PetBase",				-- 幻兽
		"TitleBase",			-- 称号
		"TaskBase",				-- 任务
		"VoucherMallBase",		-- 充值商城(数据量少)
		"HorseUpgradeBase",		-- 坐骑速度升级(数据量少)
	},
	
	pkmap = {
		"EquipDJBase",			-- 道具
		"EquipZBBase",			-- 装备
		"EquipBSBase",			-- 宝石
		"EquipBWBase",			-- 宝物
		"EquipCBBase",			-- 翅膀
		"EquipSpiritBase",		-- 精灵
		"EquipTowStarBase",		-- 双星
		"SkillBase",			-- 注：技能加载需要在怪物前面
		"SkillDetail",			-- 技能升级信息
		"MonsterBase",			-- 怪物基本信息
		"MonsterSkillAi",		-- 怪物技能ai
		"SceneAoi",				-- 场景aoi分布
		"TransferDotBase",		-- 传送点
		"PetBase",				-- 幻兽
		"HorseBase",			-- 坐骑
		"TrapBase",				-- 陷阱
		"BufferBase",			-- buffer
		"BeastBase",			-- 召唤物
		"LinweiTaskBase",		--临危任务
		"LinweiTaskLib",		--临危任务库
		"GuardNpcBase",			--守护NPC		
		"ActiveBase",           -- 玩法表
		"ActiveSubBase",        -- 子玩法表		
		"SceneBufferBase",		-- 场景BUFFER基础表
		"SceneBufferRefBase",	-- 场景BUFFER刷新表
		"GatherBase",			-- 采集物
		"DropPackBase",			-- 掉落物
		"ScenePosition",		-- 场景中的坐标点
		"PetTianfuBase",		-- 幻兽天赋
		"VipBase",				-- VIP功能
		"AchieveBase",			--成就
		"JieBiao",     		-- 劫镖
		"RandRewardPackBase",	-- 随机奖励包
		"TeamRobotNicks",		-- 机器人名字（用于诸神黄昏）
		"TrapRefreshBase",	--陷阱刷新表
		"ShenbingSkillBase",			-- 神兵技能
		"LoverTempleTaskBase", 	--爱情圣殿任务
	},
	
	pkbase = {	
		"FilterWords",      	-- 过滤
		
		"ActiveBase",           -- 玩法表
		"ActiveSubBase",        -- 子玩法表
		"TeamRobotNicks",		-- 机器人名字
	},
	
	pkdb = {
	}
}
CsvLoader = CsvLoader or 
{
	init = false,
}


-- 加载csv文件
local csv_dir = GLOBAL_LUA_SCRIPT_DIR .. '/include/csv/csv_' .. Language:getCSVLang()
function CsvLoader:loadCsv(csv)
	local dao_name = csv .. 'Dao'
	if csv == 'EquipDJBase' or csv == 'EquipZBBase' 
	or csv == 'EquipBSBase' or csv == 'EquipBWBase' 
	or csv == 'EquipCBBase' or csv == 'EquipSpiritBase' 
	or csv == 'EquipTowStarBase' then
		dao_name = 'EquipBaseDao'
	end
	local dao = rawget(_G,dao_name)	
	if dao then
		local csv_path =  csv_dir .. "/" .. csv ..  '.csv'
		local csv_data = nil
		-- 这里加上需要支持区域的表格后，也需要在main.lua中添加，不然检查表时会报错
		if csv == 'VoucherMallBase' or csv == 'VipBase' or csv == 'OpeActivityFixBase' or csv == 'AchieveBase'
			or csv == 'OpeActivityItemFixBase' or csv == 'TitleBase' or csv == 'OpeActiveBase' 
			or csv == 'RewardSpecialBase' or csv == 'ShopEquip'
			then
			csv_data = readCSV1(csv_path)					
		else
			csv_data = readCSV(csv_path)	
		end
		dao:loadFromCsv(csv_data)
		
		setmetatable(dao,nil)
		--dao.loadFromCsv = nil
		
		if csv ~= 'DropPackBase' and csv ~= 'OpeActivityFixBase' and csv ~= 'OpeActivityItemFixBase' and
			csv ~= 'VoucherMallBase' then
			for k,v in pairs(csv_data) do	
				if not getmetatable(v) then
					AsReadOnly(v)
				end
			end
		end
	end
end

g_serv_name=nil

-- interface调用入口
function CsvLoader:load(serv_name)
    g_serv_name=serv_name
	for _, csv in ipairs(g_csvs.common) do -- 读取各个地方都需要的csv
		self:loadCsv(csv)
	end
	
	for _, csv in ipairs(g_csvs[g_serv_name]) do -- 根据各自类型加载不同的csv
		self:loadCsv(csv)
	end
	
	--table.dump('FilterWordsDao:',FilterWordsDao)
	--print('FilterWordsDao:',FilterWordsDao)
	self.init = true
	collectgarbage('collect')
end

