

local US_PER_MS=1000
local US_PER_SECOND=1000*US_PER_MS

---DebugSetting的选现可能在非开发服设置
DebugSetting=
{
   bAssertIF_NOT=0,--//是否在发生IF_NOT和不满足IF_OK时assert 在不稳定的调试版本才需要。运营的版本最好不要开这个
}

if opCodes then

--
Debug={
bTraceAddLuaTask = 0,

bPrintAndLogMsgEnablePrint=1,

bDebugging=0,---是否调试中，如果在调试状态下可以写很多日志

TRACE_GET_PATH_PERFORMANCE=1,---是否跟踪分析getpath的性能

-------日志配置
bShouldSperateLogFiles=0,---是否区分thread_log,stat等 默认0 表示所有日志打到一个文件，否则表示分开存储

bLogFileNameWithDT=0,--日志文件名是否以日期时间开头

iDBQueryLongTimeThresholdUS=0,--5*US_PER_MS,----多长时间的数据库查询算是长查询


bDontLogEndHandlePacket=1,--是否记录每个处理过的包

iOutputLuaDbgStringPrintOrLog=2,---把lua分析日志打印到屏幕还是写到日志文件 0/1：打印屏幕上 2：写到线程日志 3:二者都有 默认打印到屏幕上

bTraceClock=0,--是否跟踪clock

-----c++性能监测
iGetFovTimeoutUS=0,--1000,---跟踪getFov_Internal的超时 单位 us，0 表示不监视
iCallAddAOIObjTimeoutUS=0,--5* US_PER_MS,--跟踪调用c++ AddAOIObj addAOIObjList的时间消耗 超过则日??0表示不记录
iCallGetFovChangeObjectsTimeoutUS=0,--5* US_PER_MS,--跟踪调用c++ getFovChangeObjects的时间消耗 超过则日志 0表示不记录

----包分析
bTracePacketRef=0,--是否跟踪包创建 释放及引用记数
bTraceSocketRef=0,--是否跟踪socket对象的创建释放

bDumpLuaSndPkg=0,--是否记录Lua发包信息

bDumpPkgBinIfNeeded=0,--;//是否打印路由过程中的网络2进制包（非Read/Write)
bDumpPkgBinSndRcv=0,--;//是否打印Socket收发过程中的网络2进制包(Read/Write)
bDumpPushOutPacket=0,--1,--//是否跟踪Socket::pushOutPacket/pushOutPacketList
bDumpP2CForwardPkg=0,--//是否跟踪 ForwardPacketToClientRunnable::addPacket

---------消息流向分析


iDisableTracePkgCnt=0,--禁止记录包信息的个数iDiasbleTracePkgxx
iDisableTracePkg1=opCodes.C2M_SCENE_START_MOVE_TO_DEST,--,--- = 4022, // 角色开始移动
iDisableTracePkg2=opCodes.M2C_SCENE_OBJ_APPEAR,--,---- = 4003, // aoi对象出现
iDisableTracePkg3=opCodes.M2C_SCENE_OBJ_DISAPPEAR,--,----  = 4004, // aoi对象消失    


DisableTracePkgList={},---  哪些包不需要记录信息
  
---部分包的性能处理不跟踪
idisablePkgLuaTimeoutGuardCnt=1,--0,--//禁止跟踪lua性能的包 （如果有包经常的异常超时就放这里）
idisablePkgLuaTimeoutGuard1=0,--0,-- idisablePkgLuaTimeoutGuard已经被DisablePkgLuaTimeoutGuardList 替代 可以删除了

DisablePkgLuaTimeoutGuardList={},---

-----lua 性能分析
bEnableLuaTimeoutGuard=0,--1,---是否允许引擎内部对所有lua的性能监控（通过函数特别开关的除外）

bPROFILE_LUA_ENG_TRACE_GC=0,--是否启动lua gc跟踪

iCallLuaUpdateTimeoutThresholdUS=0,--10*US_PER_MS,---调用lua的 c_update的超时 0表示不监视

iCallLuaTimeoutLongUS=10* US_PER_MS,--lua engine跟踪调用lua接口的超长消耗 超过则日志 0表示不记录
iCallLuaTimeoutUS=0,--10* US_PER_MS,--lua engine跟踪调用lua接口的消耗 超过则日志 0表示不记录

------lua引擎内部的跟踪分析
iProfileLuaEngPrecallTimeOutUS=0,--5*US_PER_MS,---超过时间则记录 0表示不记录
iProfileLuaEngExecuteTimeOutUS=0,--5*US_PER_MS,---超过时间则记录 0表示不记录
iProfileLuaEngPcallTimeOutUS=0,--5*US_PER_MS,---超过时间则记录 0表示不记录

iProfileLuaEngCPrecallTimeOutUS=0,--5*US_PER_MS,---lua调用C函数性能监测 超过时间则记录 0表示不记录
iProfileLuaEngCPcallTimeOutUS=0,--5*US_PER_MS,---lua调用C函数性能监测 超过时间则记录 0表示不记录

-----消息处理超时监控
iHandleMsgTimeoutWarningUS=10*US_PER_MS,---处理消息超过指定时间则记录日志 0表示不记录 

iHandleMsgTimeoutWarningGetLoginedDataUS=1*US_PER_MS,---处理消息超过指定时间则记录日志 0表示不记录 C2M_CHARACTERS_GET_LOGINED_DATA

-----------包统计分析:bPROFILE_ENABLE_NETSTATIC为1时才有效
bPROFILE_ENABLE_NETSTATIC=1,--是否允许统计流量

iMsgToDumpMinEnterCount=1,----最少多少个包才dump统计信息
PROFILE_NETSTATIC_LOG_DUMP_MAX_NUM=10,--打印前几名流量的包的统计信息

---统计频率
PROFILE_STAT_PERIOD_US=0,--60*5*US_PER_SECOND,---统计周期

PROFILE_ENABLE_DUMP_CPU_MEM_USAGE=1,--是否允许周期性输出进程cpu 内存的频率 

PROFILE_ENABLE_DUMP_PLAYER_COUNT_DETAIL=0,--是否周期性打印每个场景的在线数 正式服不要开放

--功能开关
bPROFILE_ENABLE_THROUGH_CACHE_BUF=0,--是否允许可达点缓冲 因为是起点到终点 实际上通常不同角色走同一条路的几率不大  宏PROFILE_ENABLE_THROUGH_CACHE_BUF开放后这个标记才有效


------log开关
bProfileWritePkgC2X=0,--是否记录客户端上行包 调试专用  正式服不要打开 否则log太多
bProfileWritePkgC2B_GET_SERVER_TIME=0,---bProfileWritePkgP2C打?笔欠窦锹糃2B_GET_SERVER_TIME（这个包太多了 一般没必要记录）

bLogEndHandlePacket=0,--是否记录处理过的包 如果打开的话 包太多时很容易造成巨大的日志
iDontLogEndHandleCnt=0,--哪些包不记录  被DontLogEndHandleList替代了 可以删除
iDontLogEndHandle1=4003,--M2C_SCENE_OBJ_APPEAR 4003, // aoi对象出现
iDontLogEndHandle2=4004,--M2C_SCENE_OBJ_DISAPPEAR 4004, // aoi对象消失
iDontLogEndHandle3=4023,--M2C_SCENE_START_MOVE_TO_DEST

DontLogEndHandleList={},---哪些包处理完之后不记录日志

bEnableLogNet=1,----是否允许记录消息包收发

bLogUndoPacket=0,--队列超过 socketEachProcNum 时是否记录log 压力测试时很容易写很多log 


bLogPlayerCountNeeded=0,--是否打印在线数
PROFILE_ENABLE_ANALYST=0,---是否统计各调用点的性能消耗 

PROFILE_DISABLE_NET_STAT=1,---是否关掉网络统计  默认：0

PROFILE_NET_STAT_MIN_TOTAL_SND=1024,--发送最小多少字节才记录统计信息
PROFILE_NET_STAT_MIN_TOTAL_RCV=1024,--接收最小多少字节才记录统计信息
	
bDumpProcStatRawToLog=0,--是否把原始的cat /proc/xxx等读到的内容写到log

bGlobalEnableDumpLuaCallStack=0,--是否允许输出lua调用栈

---c++ lua都影响到的
bProfileLuaTraceOnStartup=0,--是否分析启动阶段的性能（c++ + lua)


---只用于调试的开关 正式版本不能使用
bTraceClearReadBuffer=0,--是否跟踪clear read buffer

b_trace_p2c_send_data=0,---是否跟踪p2c的消息包

PROFILE_DEBUG_CLIENT_PKG=0,--1, --是否调试输出与客户端的消息收发

PROFILE_DEBUG_CLIENT_PKG_DUMP_BIN=0,--1, --是否调试输出与客户端的消息收发内容（已经废弃 只是为了兼容旧版本 必须保留这个设置）

PROFILE_DEBUG_CLIENT_PKG_DUMP_BIN_BEFORE_CONVERT=0, --是否调试输出与客户端的消息收发内容（转小包前）
PROFILE_DEBUG_CLIENT_PKG_DUMP_BIN_AFTER_CONVERT=0, --是否调试输出与客户端的消息收发内容（转小包后）

PROFILE_DUMP_BIN_PACKET_BEFORE_AFTER_CONVERT_TO_SMALL=0,--是否packet转small前后的内容

bPBDBG_ENABLE_TRACE_ENC_DEC_FIELD=0,--是否默认调试输出protobuf的打包解包过程（这个开关影响所有protobuf包的默认选现，但是每个包可以自行在lua里设置开关）
bPBC_ENABLE_DEBUG_BIN_PKG=0,--是否默认输出pbc的2进制包打包解包过程

iPrintLogLevel=0,--4,---哪个等级开始的log需要打印到屏幕上 LOG_LEVEL(		LOOSE=1,	INFO=2,	WARN=3,	ERRO=4,)  -1表示所有 0 表示不打印

PROFILE_ENABLE_TRACE_PKG_RCV_FROM_CLIENT=0,--1,--//是否将客户端发送过来的消息内容存到日志文件中

PROFILE_TRACE_FORWARD_TO_CLIENT=0,--1, --是否跟踪转发给客户端的消息包

bPrintPkgInfo=0,--0,--打印跟踪到的包信息
bTraceCallMainIndex=0,--1,--是否跟踪分析call_mainindex的性能


--是否跟踪分析客户端包响应时间
bEnableTraceClientPkgHandleTime=0,--是否跟踪客户端包响应时间 如果跟踪可能会影响性能表现


--跟踪一段时间的包排行
bEnablePkgRankBegin=1467892800,--跟踪包排行的起始时间用时间戳
bEnablePkgRankEnd=1467900000,--跟踪包排行的结束时间用时间戳
bEnablePkgRankNum=30,--跟踪包排行需要打印的排行数

---优化参数
uP2CForwardThreadNum=2,---暂时未使用 
bUseCondSelf=1,--是否每个容器使用自己的cond  使用这个标志 唯一风险是一个loop内 可能一个cond被多次触发，然后对方频繁得到通知 被唤醒，好处就是消息及时得到相应而且不会浪费太多时间去查询列表  ---也可以考虑不用这个开关  把等待的地方的周期延长为10或者20ms 但是会影响响应速度

}
	
end	
			
local function isTestServer()
	local my_area_id = external and external.getAid()
	if my_area_id>=970 and my_area_id<=999 then
		return true
	end
	return false
end

---------DisableLogReadWrite 用于设置哪些包不需要记录log  修改后 运行bin/globalvars_reload.lua才会生效

if opCodes then
	--
	DisableLogReadWrite={
	DisableLogReadWriteCnt=14,
        
	DisableLogReadWrite1=opCodes.M2C_FIGHT_FIGHT,
	DisableLogReadWrite2=opCodes.M2C_FIGHT_FIGHT_ERROR,
	DisableLogReadWrite3=opCodes.C2M_FIGHT_FIGHT,
	DisableLogReadWrite4=opCodes.M2C_FIGHT_HARM,
	DisableLogReadWrite5=opCodes.M2C_FIGHT_USE_NOT_ATTACK_SKILL,

	DisableLogReadWrite6=opCodes.M2C_SCENE_START_MOVE_TO_DEST,
	DisableLogReadWrite7=opCodes.C2M_SCENE_START_MOVE_TO_DEST,
	DisableLogReadWrite8=opCodes.M2C_SCENE_STOP_MOVE,
	DisableLogReadWrite9=opCodes.M2C_SCENE_CHANGE_SPEED,
	
	DisableLogReadWrite10=opCodes.M2C_SCENE_OBJ_APPEAR,
	DisableLogReadWrite11=opCodes.M2C_SCENE_OBJ_DISAPPEAR,
	
	DisableLogReadWrite12=opCodes.M2C_SCENE_GET_OBJ_APPEAR_DATA,
	DisableLogReadWrite13=opCodes.C2M_SCENE_GET_OBJ_APPEAR_DATA,
		
	DisableLogReadWrite14=opCodes.PKB2C_TEAM_INVITE,
	
	--------
	--DisableLogReadWrite12=opCodes.M2C_BUFFER_UPDATE,	
	--DisableLogReadWrite15=opCodes.M2C_BUFFER_DEL,	
	--DisableLogReadWrite=opCodes.M2C_SMALL_MAP_ITEMS_UPDATE	

	--M2C_CHARACTER_UPDATE_ATTRIB
	--CLIENT_PING

	--M2C_CHARACTER_UPDATE_ATTRIB,
	--M2C_SCENE_OBJ_APPEAR_DATA_UPDATE,

	--C2B_GET_SERVER_TIME,
	--B2C_GET_SERVER_TIME
	}
end


if isTestServer() then
  DisableLogReadWrite={DisableLogReadWriteCnt=0}
end

---DisableLogReadWriteList正式生效后要删除以上多余的 DisableLogReadWriteXXX
if opCodes then

	DisableLogReadWriteList={        
	opCodes.M2C_FIGHT_FIGHT,
	opCodes.M2C_FIGHT_FIGHT_ERROR,
	opCodes.C2M_FIGHT_FIGHT,
	opCodes.M2C_FIGHT_HARM,
	opCodes.M2C_FIGHT_USE_NOT_ATTACK_SKILL,

	opCodes.M2C_SCENE_START_MOVE_TO_DEST,
	opCodes.C2M_SCENE_START_MOVE_TO_DEST,
	opCodes.M2C_SCENE_STOP_MOVE,
	opCodes.M2C_SCENE_CHANGE_SPEED,
	
	opCodes.M2C_SCENE_OBJ_APPEAR,
	opCodes.M2C_SCENE_OBJ_DISAPPEAR,
	
	opCodes.M2C_SCENE_GET_OBJ_APPEAR_DATA,
	opCodes.C2M_SCENE_GET_OBJ_APPEAR_DATA,
		
	opCodes.PKB2C_TEAM_INVITE,
	}

end
	
if isTestServer() then
  DisableLogReadWriteList={}
end

  

