
Statics =
{
	-- AOI对象状态类型
	-- MotionService 管理
	-- 注：不能修改， 移动MotionService模块写死了用0,1,2，没有使用这里定义的常量
	AOI_OBJECT_STATUS_ID_IDLE		= 0,		-- 静止状态
	AOI_OBJECT_STATUS_ID_MOVING		= 1,		-- 移动状态
	AOI_OBJECT_STATUS_ID_JUMP		= 2,		-- 跳跃状态

	AOI_OBJECT_STATUS_ID_FIGHTING   = 3,		-- 战斗状态
	AOI_OBJECT_STATUS_ID_DEAD	    = 4, 		-- 死亡状态(不保留尸体)
	AOI_OBJECT_STATUS_ID_FOLLOW     = 5,		-- 跟随状态
	AOI_OBJECT_STATUS_ID_AUTO_FIGHT = 6,		-- 自动战斗状态
	AOI_OBJECT_STATUS_ID_COLLECT    = 7,		-- 采集状态
	AOI_OBJECT_STATUS_ID_XIULIAN    = 8,		-- 修炼状态
	AOI_OBJECT_STATUS_ID_FREEZE     = 9,		-- 冻结状态
	AOI_OBJECT_STATUS_ID_SIT	    = 10,		-- 打坐状态
	AOI_OBJECT_STATUS_ID_AUTO_PLAY  = 11,		-- 挂机状态
	AOI_OBJECT_STATUS_ID_START_OCCUPY_FLAG = 12,-- 帮战战旗(据点)状态：准备占领中
	AOI_OBJECT_STATUS_ID_FINI_OCCUPY_FLAG = 13,	-- 帮战战旗(据点)状态：已经占领
	AOI_OBJECT_STATUS_ID_FOR_HOMING = 14,		-- 返回出生点状态
	AOI_OBJECT_STATUS_ID_PRE_DEAD	= 15, 		-- 死亡状态(保留尸体)
	AOI_OBJECT_STATUS_ID_FISHING	= 16,		-- 钓鱼状态
	AOI_OBJECT_STATUS_ID_DEAD_FOREVER = 17,		-- 死亡状态(永不复活)
	AOI_OBJECT_STATUS_ID_AI_PREPARE = 18,		-- AI预备状态(怪物)
	AOI_OBJECT_STATUS_ID_AI_PLAYING = 19,		-- AI释放状态(怪物)
	
	-- entity对象状态
	-- CharacterService 管理
	GAME_OBJECT_STATUS_ID_IDLE			= 0,	-- 空闲状态
	GAME_OBJECT_STATUS_ID_FIGHTING		= 1,	-- 战斗状态
	GAME_OBJECT_STATUS_ID_PRE_DEAD		= 2, 	-- 死亡状态(保留尸体)
	GAME_OBJECT_STATUS_ID_DEAD			= 3, 	-- 死亡状态(尸体消失)
	
	GAME_OBJECT_STATUS_ID_COLLECT		= 4,	-- 采集状态
	GAME_OBJECT_STATUS_ID_XIULIAN		= 5,	-- 修炼状态
	GAME_OBJECT_STATUS_ID_FISHING		= 6,	-- 钓鱼状态
	GAME_OBJECT_STATUS_ID_SIT			= 7,	-- 打坐状态	
	GAME_OBJECT_STATUS_ID_AI_PREPARE	= 8,	-- AI预备状态(怪物)
	GAME_OBJECT_STATUS_ID_AI_PLAYING	= 9,	-- AI释放状态(怪物)
	
	GAME_OBJECT_PROTECT_ENTER_SCENE 	= 1,	-- 进入场景保护
	GAME_OBJECT_PROTECT_RELIVE 			= 2,	-- 复活保护
	
	-- 阵营 (不能大于99)
	DEFAULT_ZHENYING_NEUTRAL = 0,	-- 中立
	DEFAULT_ZHENYING_PLAYER = 1,	-- 玩家
	DEFAULT_ZHENYING_PLAYER_2 = 2,	-- 玩家2(PVP玩法中两方阵营)
	DEFAULT_ZHENYING_TRAP = 3,		-- 陷阱
	DEFAULT_ZHENYING_BEAST = 4,		-- 召唤兽
	DEFAULT_ZHENYING_GUARD_NPC = 5, -- 守护npc
	DEFAULT_ZHENYING_MONSTER = 6,	-- 怪物
	DEFAULT_ZHENYING_SHOU = 7,  -- 守
	DEFAULT_ZHENYING_GONG = 8,  -- 攻
	DEFAULT_ZHENYING_MAX = 100, 	-- 最大阵营ID
	
	-- 金钱属性定义
	MONEY_TYPE_ID_FOR_GOLD = 1,		-- 元宝
	MONEY_TYPE_ID_FOR_VOUCHER = 2,	-- 礼券
	MONEY_TYPE_ID_FOR_SILVER = 3,	-- 银两
	MONEY_TYPE_ID_FOR_CONTRIBUTE = 4,-- 军功
	MONEY_TYPE_ID_FOR_HONOUR = 5,	-- 荣誉
	MONEY_TYPE_ID_FOR_INVITE_SCORE = 6,	-- 推广积分
	MONEY_TYPE_ID_FOR_VIT = 7,			-- 体力
	MONEY_TYPE_ID_FOR_ENDURANCE = 8,	-- 耐力
	MONEY_TYPE_ID_FOR_SHOUHUN = 9,		-- 兽魂

	-- ID类型定义
	CSV_ID_TYPE_PET = 1,			--幻兽
	CSV_ID_TYPE_GODDESS = 2,		--女神
	CSV_ID_TYPE_EQUIP_ZB = 3,		--装备


	-- PK服连接类型
	PK_SERVER_TYPE_ID_VOICE_CHAT = 1, -- 语音聊天服
	PK_SERVER_TYPE_ID_FOR_GAME = 2, -- pk游戏服
	PK_SERVER_TYPE_ID_FOR_CENTER = 3, -- 数据中心服
	PK_SERVER_TYPE_ID_FORWARD	 = 3, -- 全区全服转发服务器服 （暂时业务量不大 直接放到中心服中转)

	-- PK服游戏类型 (注意不能大于255)
	PK_GAME_TYPE_ID_SUBLINE 		= 1,	--组队副本
	PK_GAME_TYPE_ID_3V3 			= 2,	--3V3
	PK_GAME_TYPE_ID_TIANMO 			= 3,	--BOSS之家
	PK_GAME_TYPE_ID_OUTDOOR_BOSS	= 4,	--野外BOSS
	PK_GAME_TYPE_ID_LINWEI			= 5,	--临危受命
	PK_GAME_TYPE_ID_DAOJJ			= 6,	--刀剑(帝国争锋)
	PK_GAME_TYPE_ID_GANG_BATTLE 	= 7,	--军团战
	PK_GAME_TYPE_ID_GANG_BATTLE_CHUSAI = 8,	--帮战初赛(将弃用)
	PK_GAME_TYPE_ID_FINALWAR        = 9,     --末日之战
	PK_GAME_TYPE_ID_ZHUSHEN			= 10,	--诸神黄昏
	PK_GAME_TYPE_ID_SUBLINE_EMENG	= 11,	--组队噩梦副本
	PK_GAME_TYPE_ID_SHENGCUN 		= 12,	--生存挑战
	PK_GAME_TYPE_ID_PIGEON          = 13,   --飞鸽
	PK_GAME_TYPE_ID_LOVER_TEMPLE 	= 14,	--爱情圣殿
	

	PK_GAME_TYPE_ID_OUTDOOR_BOSS_NOTICD  = 49,	--野外BOSS(只用于广播)
	
	PK_GAME_TYPE_ID_REWARD_SHAIZI	= 50,	--摇骰子奖励
	PK_GAME_TYPE_ID_DROP_ITEM_PICKUP= 51,	--掉落物拾取
	PK_GAME_TYPE_ID_REWARD_HONGBAO	= 52,	--抽红包奖励
	PK_GAME_TYPE_ID_OUTDOOR_BOSS_RWD = 53,	--野外精英BOSS奖励
	PK_GAME_TYPE_ID_FRIENDS_JOIN_ACT = 54,	--好友共参与活动奖励
	PK_GAME_TYPE_ID_OUTDOOR_BOSS_MAX_HARM_RWD = 55,	-- 野外巨炎魔最高伤害所在队伍奖励
	PK_GAME_TYPE_ID_OUTDOOR_JB_RWD = 56, --美女与野兽(劫镖)
	PK_GAME_TYPE_ID_ZHUSHEN_TOP_REWARD = 57,--诸神黄昏排行榜奖励
	
	-- 本服游戏类型
	GAME_TYPE_ID_ARENA				= 101,	--竞技场
	GAME_TYPE_ID_DUOBAO				= 102,	--夺宝
	GAME_TYPE_ID_ZHUPU				= 103,	--主仆
	GAME_TYPE_ID_2V2				= 104,	--2V2
	GAME_TYPE_ID_GOLLGATE			= 105,	--关卡
	GAME_TYPE_ID_BABEL				= 106,	--摩天豆蔓
	GAME_TYPE_ID_GANG_DRAGON		= 107,	--军团屠龙
	GAME_TYPE_ID_CONI_DOZER			= 108,	--推币机
	GAME_TYPE_ID_GANG_BATTLE 		= 109,	--军团战（本服）
	GAME_TYPE_ID_WEDDING            = 110,  --婚宴玩法
	GAME_TYPE_ID_DAILY_TASK 		= 111,	--日常任务
	
	-- CURL回调KEY 定义
	CURL_KEY_ACTIVATION_CODE_USE	= 1,	--使用激活码
	
	GOOGLE_GIFT_CODE_KEY = '134(@#Q&ssdaaalshf|d)',
}


---玩法在pk服的分配方案
Statics.pk_mapping={
    [Statics.PK_GAME_TYPE_ID_TIANMO] = "group_id1",
    [Statics.PK_GAME_TYPE_ID_3V3] = "group_id1",
    [Statics.PK_GAME_TYPE_ID_DAOJJ] = "group_id1",
    [Statics.PK_GAME_TYPE_ID_FINALWAR] = "group_id1",
    [Statics.PK_GAME_TYPE_ID_ZHUSHEN] = "group_id1",
    [Statics.PK_GAME_TYPE_ID_GANG_BATTLE] = "group_id1",
    [Statics.PK_GAME_TYPE_ID_PIGEON] = "group_id1",
    [Statics.PK_GAME_TYPE_ID_OUTDOOR_BOSS] = "group_id1",
    
    [Statics.PK_GAME_TYPE_ID_LINWEI] = "group_id2",
    [Statics.PK_GAME_TYPE_ID_SUBLINE] = "group_id2",
    [Statics.PK_GAME_TYPE_ID_SUBLINE_EMENG] = "group_id2",
    [Statics.PK_GAME_TYPE_ID_SHENGCUN] = "group_id2",
}



