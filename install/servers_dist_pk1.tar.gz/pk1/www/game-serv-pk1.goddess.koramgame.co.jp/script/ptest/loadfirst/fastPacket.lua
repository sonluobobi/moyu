
local decode_c = cjson.decode_c
	
local encode_c = cjson.encode_c
	
local findArg=testclient.findArg

local pb_lua = pb_lua
local pb_lua_encode=pb_lua.encode
local pb_lua_clear_buf=pb_lua.clear_buf

local pb_getFastPkg = testclient.pb_getFastPkg
local pb_setFastPkg = testclient.pb_setFastPkg

g_bShowDbgMsg=(findArg('bShowDbgMsg:',true)>0)


local socket_send=testclient.socket_send


local printAndLog=external.printAndLog

	
function plogmsg(plr,...)
  local txt=string.format(...)
  local str=string.format('[%d] pid:%d %s',g_Aid,(plr and plr.pid) or 0,txt)
  print(str)
  printAndLog(str)
end

	
function plog(plr,...)
  local txt=string.format(...)
  printAndLog(string.format('pid:%d %s',(plr and plr.pid) or 0,txt))
end

function pmsg(plr,...)
  local txt=string.format(...)
  local txt2=string.format('[%d] pid:%d %s',g_Aid,(plr and plr.pid) or 0,txt)
  printAndLog(txt2)
end

function dbgmsg(plr,...)
  
  if g_bShowDbgMsg then  
	local txt=string.format(...)
	print(string.format('[%d] pid:%d %s',g_Aid,plr.pid or 0,txt)) 
  end
end

--[[
	��packet��ȡһ��table
--]]
function FastPacket_readTable ( fastPacket )	
	local cstr = fastPacket:readCString(self)
	return decode_c(cstr,false)
end

--[[
	��packet��ȡһ��table, ���ڻ�ȡ�ͻ��˲���
	msg_name : string 		 protobuf ��Ϣ�� �磺'PackChItemBar.C2M_CHITEM_BAR_DRESS'
	is_reuse : false/true    JSON��ʽ����ʱ�õ�table�Ƿ���(Ĭ��false��ÿ�ζ����Ḵ��table)
							 �������������Ҫ�Ѳ����ڵ�table����dao������Ҫ��nil/false
--]]

	local pb_lua = pb_lua
	local pb_lua_decode=pb_lua.decode
	
	function FastPacket_readParams(msg_name, fastPacket)
		
		if fastPacket:getEncodeType() == ENCODE_TYPE_PB then
			local buf,len=pb_getFastPkg(fastPacket)
			local is_ok, arr_params,strTblTxt
			
			is_ok, arr_params,strTblTxt = pb_lua_decode(msg_name,buf,len)
				
			if is_ok then
			
				--if LOG_LEVEL<=LOG_LEVEL_DEBUG then
				--	external_debug('PB decode ok.msg_name:'..msg_name..' strTblTxt:'..strTblTxt)
				--end
				
				return arr_params, fastPacket:getPacketId()
			else
				error('PB decode failed. msg_name:'.. msg_name..' error:'..arr_params)				
				
				--packet_dumpPkgAsString(fastPacket,0,0,true,"pb decode error")
				
				if LOG_LEVEL>=LOG_LEVEL_ERROR then
					external_error('PB decode failed. msg_name:'.. msg_name.. ' error:'..arr_params)		
				end
				
				--Logger:info('[Packet:readParams] decode params error', msg_name, self:getLuaOpCode(), self:getPacketId(), arr_params,' strTblTxt:',strTblTxt)
				return
			end
		end
		if fastPacket:getEncodeType() == ENCODE_TYPE_JSON then
			local cstr = fastPacket:readCString()
			return decode_c(cstr, false), fastPacket:getPacketId()
		else
		  error('packet not pb or json.encode type:',g_Aid,fastPacket:getEncodeType())
		end
	end
	

function FastPacket_readPath(fastPacket)
---PBDT_PATH
    local pos_arr={}
	local pos_len= fastPacket:readPathCnt()		
	local iArrayIdx=0
	for iArrayIdx=1,pos_len do
		local fCoord = fastPacket:readPath(iArrayIdx)
		pos_arr[iArrayIdx]=fCoord
	end
	return pos_arr,pos_len
end

	local packetSnd = FastPacket()
	
function packet_sndReqPing(plr)	
	packetSnd:clear(false,false)	
	packetSnd:setOpt(false,false)
	
	packetSnd:initFastPacket(opCodes.CLIENT_PING,ENCODE_TYPE_BIN)  
	sendFastPacket(plr,packetSnd)
end 


	function packet_sndReqClientRegister(plr)	
		packetSnd:clear(false,false)	
		packetSnd:setOpt(false,false)
		packetSnd:initFastPacket(opCodes.CLIENT_REGISTER,ENCODE_TYPE_BIN)
		
		packetSnd:writeUInt32(plr.aid)
		packetSnd:writeUInt32(plr.pid)
		
		--int iLen=snprintf(temp,sizeof(temp)-2, "%s|-|%d|-|%d|-|%s","Jdsj^&@!$Adfod=-Feng$%Yun123",clientAid, pid,"");
		local strRaw="Jdsj^&@!$Adfod=-Feng$%Yun123".."|-|"..plr.aid.."|-|"..plr.pid.."|-|"
		
		local _key=makeMD5(strRaw)
		packetSnd:writeString(_key)
		
		sendFastPacket(plr,packetSnd)
   end

function packet_readPath(packet)
---PBDT_PATH
    local pos_arr={}
	local pos_len= packet:readPathCnt()		
	local iArrayIdx=0
	for iArrayIdx=1,pos_len do
		local fCoord = packet:readPath(iArrayIdx)
		pos_arr[iArrayIdx]=fCoord
	end
	return pos_arr,pos_len
end

---�����������
function sendFastPacket(plr,fastpacketSnd)
   socket_send(LUA_ENG_C_PROXY,plr.conn,fastpacketSnd)
end

local fastpacketSndGMCmd = FastPacket()

function sendGMCmd(plr,method,params)
	local cmd={method=method,params=params}
				
    fastpacketSndGMCmd:clear(false,false)	
	fastpacketSndGMCmd:initFastPacket(opCodes.C2B_COMMON_GM,ENCODE_TYPE_JSON)			
	fastpacketSndGMCmd:writeCString(encode_c(cmd))									
    sendFastPacket(plr,fastpacketSndGMCmd)
end


local fastpacketSndPB = FastPacket()
function sendPB(plr,msg_name,opCode,proto_buff_msg,bPBC)
    fastpacketSndPB:clear(bPBC or false,false)	
	fastpacketSndPB:initFastPacket(opCode,ENCODE_TYPE_PB)
	
	local bOK,encode,strTblTxt 		
	bOK,encode,strTblTxt= pb_lua_encode(msg_name, proto_buff_msg)	
	
		
	if bOK then
		local wHdrSize=pb_setFastPkg(fastpacketSndPB, encode)
		pb_lua_clear_buf()
	else 	   
		pb_lua_clear_buf()		
		error('PB encode failed. msg_name:'.. msg_name.. ' error:'.. encode)		
		--external_error('PB encode failed. msg_name:'.. msg_name.. ' error:'.. encode)		
		
		assert(bOK)	
	end			
    sendFastPacket(plr,fastpacketSndPB)
end

local fastpacketSndJSon = FastPacket()
function SndJSon(plr,opCode,tbl)				
    fastpacketSndJSon:clear(false,false)	
	fastpacketSndJSon:initFastPacket(opCode,ENCODE_TYPE_JSON)			
	fastpacketSndJSon:writeCString(encode_c(tbl))									
    sendFastPacket(plr,fastpacketSndJSon)
end

