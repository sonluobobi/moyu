
local findArg=testclient.findArg

g_acc_per_thread=findArg("acc_per_thread:",true)
if g_acc_per_thread<1 then
  g_acc_per_thread=1
end

g_appindex=findArg("appindex:",true)

g_thread_num=findArg("thread_num:",true)
if g_thread_num<1 then
  g_thread_num=1
end


g_bEnableDumpGM=(findArg('bEnableDumpGM:',true)==1)

--LUA_ENG_C_PROXY

--thread index
g_testclient_eng_idx=LUA_ENG_IDX
print('g_testclient_eng_idx:',g_testclient_eng_idx)

print('IS_PK_SVR:',IS_PK_SVR)

--if IS_PK_SVR then
--	g_IP=findArg('pkip:')
--	g_Port=findArg('pkport:',true)
--else
	g_IP=findArg('ip:')
	g_Port=findArg('port:',true)
--end

g_Aid=findArg('aid:',true)--107997

g_action=findArg('action:')
print('====>action:'..g_action)

local accfrom=findArg('accfrom:',true)

--每个app 有 g_thread_num个线程 每个线程有g_acc_per_thread个账号
g_accfrom=accfrom+(g_thread_num*g_appindex+g_testclient_eng_idx)*g_acc_per_thread

g_accto=g_accfrom+g_acc_per_thread-1

print('g_accfrom:',g_accfrom,g_accto)

g_bNoLogin=(findArg('nologin:',true)==1)

g_timer_hdlrs_with_plr=g_timer_hdlrs_with_plr or {}
g_timer_hdlrs_no_plr=g_timer_hdlrs_no_plr or {}
g_on_close_conn_hdlrs=g_on_close_conn_hdlrs or {}

g_bBattleTest=(g_action=="battletest")--战斗模拟器机器人初始化

g_bEnablePet=false
g_bEnableSkill=false

if g_bBattleTest then
	g_bEnablePet=true
	g_bEnableSkill=true
end

ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB
	
MOVE_TYPE = {
	TYPE_MOVE = 1, --// 移动
	TYPE_JUMP = 2,-- // 跳跃
	TYPE_TIAO_PI = 3,-- // 跳劈
	TYPE_SHAN_YI = 4, --// 闪移
	TYPE_CHONG_ZHUANG = 5,--// 冲撞
}

g_nick2Plr={}
g_cid2Plr={}

g_mapAcc2Plr=g_mapAcc2Plr or {}
g_mapConn2Plr=g_mapConn2Plr or {}

g_bDumpMsgRcv=(findArg('bDumpMsgRcv:',true)==1)---是否显示接收到的包的信息

g_bTaceMove=(findArg('bTaceMove:',true)==1) --是否跟踪移动信息

--g_pksvr_needed=false--是否需要pk服

--发生作用的 数据库连接配置
Mysql =
{
	hostname= '124.243.197.99', 
	database="moyu",
	port="3306",
	username="suwin",
	password="iamsuwin"
}

---231数据库连接配置
Mysql231 =
{
	hostname= '42.62.23.231',
	database="moyu_dev159",
	port="3306",
	username="suwin",
	password="iamsuwin"
}
---214数据库连接配置
Mysql214 =
{
	hostname= '124.243.197.99', 
	database="moyu",
	port="3306",
	username="suwin",
	password="iamsuwin"
}
