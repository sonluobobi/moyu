-- id => skill_base
SkillBaseDao = {
	--[id] = skill_base,
	parent_id2skills = {},		--parent_id2skills[skill_parent_id][skill_id]=skill_base
	
	prof_id2skills = {},		--职业对应的技能列表
	
}

-- 使用公式计算好的技能数据，不用每次战斗时都计算一次
-- [id][level] => detail
SkillDetailDao = {}

SkillDetailId2Detail = {}

local SkillDefs = SkillDefs

function SkillBaseDao:loadFromCsv(csv_data)
	local parent_id2skills = SkillBaseDao.parent_id2skills
	local prof_id2skills = SkillBaseDao.prof_id2skills
	--print ('SkillBaseDao:loadFromCsv')
	for i, csv in pairs(csv_data) do
		local skill_base = SkillBase:new(csv)
		skill_base.distance_sq = skill_base.distance * skill_base.distance
		SkillBaseDao[csv.id] = skill_base
		SkillDetailDao[csv.id] = {}
		
		if skill_base.parent_id and skill_base.parent_id > 0  then
			local skill_bases = parent_id2skills[skill_base.parent_id] or {}
			parent_id2skills[skill_base.parent_id] = skill_bases
			skill_bases[skill_base.id] = skill_base
		end
		if skill_base.prof and skill_base.prof > 0 then 
			local prof_base = prof_id2skills[skill_base.prof] or {}
			prof_id2skills[skill_base.prof]  = prof_base
			prof_base[skill_base.id] = skill_base
		end
	end
--	table.dump(prof_id2skills, -1)
end

function SkillDetailDao:loadFromCsv(csv_data)
	for i, csv in pairs(csv_data) do
		local skill_id = csv.skill_id		
		if not SkillBaseDao[skill_id] then 
			print(' skill base not exists ' , skill_id)
		end
		local skill_base = assert(SkillBaseDao[skill_id], ' skill base not exists ' .. skill_id)
		
		local skill_detail = SkillDetail:new(csv, skill_base)

		assert(skill_detail.skill_level>0 , 'skill detail, skill_level can not be 0, id=' .. i)		
		SkillDetailDao[skill_id][skill_detail.skill_level] = skill_detail
		
		SkillDetailId2Detail[csv.id]=skill_detail
	--	table.dump(skill_detail, 3)
	end
	
end

