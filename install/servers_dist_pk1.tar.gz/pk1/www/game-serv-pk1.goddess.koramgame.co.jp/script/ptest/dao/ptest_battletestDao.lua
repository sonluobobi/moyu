battletest_players={}


local function handle_attr(player,k,v)
	 if k=="nick" then
	   player.nick=v
	   return true
	 end
	 if k=="nskill1" then
      if not player.skills then
        player.skills={}
      end
	   table.insert(player.skills,v)
	   return true
	 end
	 if k=="nskill2" then
      if not player.skills then
        player.skills={}
      end
	   table.insert(player.skills,v)
	   return true
	 end
	 if k=="nskill3" then
      if not player.skills then
        player.skills={}
      end
	   table.insert(player.skills,v)
	   return true
	 end
	 if k=="skill1" then
      if not player.skills then
        player.skills={}
      end
	   table.insert(player.skills,v)
	   return true
	 end
	 if k=="skill2" then
      if not player.skills then
        player.skills={}
      end
	   table.insert(player.skills,v)
	   return true
	 end
	 if k=="skill3" then
      if not player.skills then
        player.skills={}
      end
	   table.insert(player.skills,v)
	   return true
	 end
	 if k=="skill4" then
      if not player.skills then
        player.skills={}
      end
	   table.insert(player.skills,v)
	   return true
    end


    if string.sub(k,1,3)=="pet" then
      if not player.pets then
        player.pets={}
      end
      local str_len=string.len(k)
      local idx=UNumber.str2Int(string.sub(k,4,4))
      --pet1_xxx
      local attr=string.sub(k,6,str_len)
      local pet=player.pets[idx]
      if not pet then
         pet={}
         player.pets[idx]=pet
      end

      --print('pet idx:',idx,attr,'=',v)
	  pet[attr]=v

      return true
    end
    player[k]=v
    return true
end

local encode_c = cjson.encode_c


function init_testroles()
  local xls_setting=GLOBAL_LUA_SCRIPT_DIR.."ptest/csv_fight/ptest_setting.csv"
  local csv_data=readCSV(xls_setting)
  --print('init_testroles :',csv_data)

  local players={}
  for _, test_character in pairs(csv_data) do
    local player={}
    --player.skills={}
    --player.pets={}
	for k,v in pairs(test_character) do
	  handle_attr(player,k,v)
    end

    player.pets_wanted_cnt={}
    for k,v in pairs(player.pets) do
       if not  player.pets_wanted_cnt[v.pet_id] then
         player.pets_wanted_cnt[v.pet_id]=0
       end
       player.pets_wanted_cnt[v.pet_id]=player.pets_wanted_cnt[v.pet_id]+1
    end

    battletest_players[player.player_id]=player
    --table.insert(players,player)
  end

  --table.dump( "init_testroles players:", players, 10 )

  --for _, player in pairs(csv_data) do
  --  sendData(player)
  --end

end

if g_bBattleTest then
	init_testroles()
end
