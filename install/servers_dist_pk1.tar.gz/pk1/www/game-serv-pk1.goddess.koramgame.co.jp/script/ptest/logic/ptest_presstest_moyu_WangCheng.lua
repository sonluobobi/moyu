----小型压力测试
---主城 50个人随机走路 不战斗   6000-60050
local c_opHandlers = c_opHandlers._handlers

local random = math.random

local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr
local timer_hdlrs_no_plr=g_timer_hdlrs_no_plr

local fastpacketSnd = FastPacket()

local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local sqrt=math.sqrt
local ceil=math.ceil

local printAndLog=external.printAndLog


local decode_c = cjson.decode_c
local encode_c = cjson.encode_c


local TYPE_MOVE=MOVE_TYPE.TYPE_MOVE


local mapAcc2Plr=g_mapAcc2Plr

local findArg=testclient.findArg

local g_testWangCheng=(g_action=='testWangCheng')
	
local randMoveStep=findArg('randMoveStep:',true)
if not randMoveStep or randMoveStep<1 then
   randMoveStep=1
end

local randMoveMax=findArg('randMoveMax:',true) ---设置randMoveMax 表示需要在初始位置附近范围内移动 不设置表示使用 randMoveStep的最大步长随机移动
if not randMoveMax then
  randMoveMax=0
end

local wing_random=0--findArg('wing_random:',true) or 0
local horse_add=0--findArg('horse_add:',true) or 0
local initpos=1 -----findArg('initpos:',true) or 0
local uplev_auto=0---findArg('uplev_auto:',true) or 0


local bDoMove=1 ----findArg('bDoMove:',true) 
if not bDoMove then
  bDoMove=0
end

local prandmove=1---findArg('prandmove:',true)  or 0

print('bDoMove/randMoveStep/max:',bDoMove,randMoveStep,randMoveMax)
 
---主城 10001 50个人随机走路 不战斗   6000-60050

local testPolicy=
{
aoe_mapid=10001,--10001王城  20099本服野外
autoUpLevTo=100,--自动升级到100级

minLifeAutoHp=10000,---低于指定血量 则自动补血

actionFreqMS=1000*1,--走路或者战斗的频度

initX=40,---进入地图后自动切到指定位置
initY=85,
}


 local pmEnvWangCheng={
pidFrom=g_accfrom,
pidTo=g_accto,
bEnable=g_testWangCheng,

}
if g_testWangCheng then
	g_test_players[#g_test_players+1]=pmEnvWangCheng
end


local l_iWangChengRandMoveIdx=0
local g_horseidx=100001
local function tm_presstest_test_logic_simple(plr,tNow)
	 if not g_testWangCheng then
	   return
	 end
	local testData=plr.testData 
	if not testData.tNextAction then
	  testData.tNextAction=tNow
	end
	if tNow<testData.tNextAction then
	   return
	end

	testData.tNextAction=tNow+1000

	if wing_random>0 then
		if not testData.wing_random then
			testData.wing_random=true
			pmsg(plr,'wing_random:')
			sendGMCmd(plr,'wing_random')	
			return
		end
	end
	
	if horse_add >0 then
		if not testData.horse_add then
			testData.horse_add=true
			pmsg(plr,'horse_add:'..g_horseidx)
			sendGMCmd(plr,'horse_del')	
			sendGMCmd(plr,'horse_add',g_horseidx)		
			g_horseidx=g_horseidx+1
			if g_horseidx >100039 then
			 g_horseidx=100001
			end
			return
		end
	end
	

	--简单测试 客户端每秒 发一次走路请求 
	--if initpos > 0 then
		if not testData.initpos then
			testData.initpos=true
			pmsg(plr,'fly '..testPolicy.initX..' '..testPolicy.initY)
			sendGMCmd(plr,'fly',testPolicy.initX..' '..testPolicy.initY)		
			return
		end
	--end
	
	--if  bDoMove then
	if bDoMove>0 then
	    if testData.randPos then
	       return 
	    end
	    testData.randPos=true
	    
	    local accDiff=plr.pid-g_accfrom
	    local lx=accDiff/7
	    local ly=accDiff%7
	    
	    local x=testPolicy.initX+lx
	    local y=testPolicy.initY-ly	    
		sendGMCmd(plr,'fly',string.format("%d %d",x,y))
	end
	
	if prandmove>0 then --prandmove then
		l_iWangChengRandMoveIdx=l_iWangChengRandMoveIdx+2
		pmsg(plr,'prandmove WangCheng',plr.pid,plr.aoi_id,l_iWangChengRandMoveIdx)
		sendGMCmd(plr,'prandmove',string.format("%d %d %d %d",randMoveStep,randMoveMax,testPolicy.initX,testPolicy.initY))
	end
end

-----------定时器

local function tm_presstest(plr,tNow)
  if not g_testWangCheng then
    return
  end    
 if not plr then
	 return 
  end
	local aoi_obj_plr=getAoiObjPlr(plr)
  if not aoi_obj_plr  or not aoi_obj_plr.x then
    return 
  end
  if not plr.bEnterSceneComplete then
    return
  end
  if not plr.testData then
   plr.testData={}
  end
  if not plr.ch then
     return
  end
  
  local testData=plr.testData
  
  if uplev_auto > 0 then
	--先确保等级达到了要求
	  if plr.ch.level<testPolicy.autoUpLevTo then    
		  if not testData.tNextUplev then
			 testData.tNextUplev=0
		  end
		  if tNow <testData.tNextUplev then
			 return
		  end
		  testData.tNextUplev=tNow+1000*10--不需要太频繁检查升级
		  
  			pmsg(plr,'uplev req sent levNow:%d',plr.ch.level)
			sendGMCmd(plr,'uplev',string.format('%d',testPolicy.autoUpLevTo-plr.ch.level))
			return 
	  end
  end 
  
  --初始化当前目标场景
  if not testData.current_test_sceneid then
		testData.current_test_sceneid=testPolicy.aoe_mapid
  end
  
  if plr.scene_id~=testData.current_test_sceneid  then
		---还没有进入目标场景 则自动切换
		if not testData.tNextEnterScene then
		   testData.tNextEnterScene=0
		end
		if tNow<testData.tNextEnterScene then
		   return
		end
		 testData.tNextEnterScene=tNow+1000*100--

		pmsg(plr,'scene_move req sent levNow:%d',plr.ch.level,plr.scene_id,testData.current_test_sceneid)
		sendGMCmd(plr,'scene_move',string.format('%d',testData.current_test_sceneid))
		return 
  end
    
  ----场景已经切换好 可以正式开始测试业务
	tm_presstest_test_logic_simple(plr,tNow) 
  
end

g_timer_hdlrs_with_plr[#g_timer_hdlrs_with_plr+1]=tm_presstest

