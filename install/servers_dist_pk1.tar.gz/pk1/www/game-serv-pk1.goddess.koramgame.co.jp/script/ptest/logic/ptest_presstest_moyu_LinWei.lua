----小型压力测试
---临危野外 40个人随机走路 不战斗  6100-6140
local c_opHandlers = c_opHandlers._handlers

local random = math.random

local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr
local timer_hdlrs_no_plr=g_timer_hdlrs_no_plr

local fastpacketSnd = FastPacket()

local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local sqrt=math.sqrt
local ceil=math.ceil

local printAndLog=external.printAndLog


local decode_c = cjson.decode_c
local encode_c = cjson.encode_c


local TYPE_MOVE=MOVE_TYPE.TYPE_MOVE


local mapAcc2Plr=g_mapAcc2Plr

local findArg=testclient.findArg

local g_testLinWei=(g_action=='testLinWei')
 --临危是跨服的 必须设置运行参数  pksvr_needed

---临危野外 20005 (40级) 40个人随机走路 不战斗  6100-6140
---20009 50级+
 local pmEnvLinWei={
pidFrom=g_accfrom,
pidTo=g_accto,
bEnable=g_testLinWei,

bConnPKNeeded=true
}

if g_testLinWei and not IS_PK_SVR then ---游戏服发动  pk服是被动连接
g_test_players[#g_test_players+1]=pmEnvLinWei
end

local main_city_scene_id=10001 ---先回到主城才能进pk服

local testPolicy=
{
target_mapid=20005,
autoUpLevTo=80,--自动升级到100级

minLifeAutoHp=10000,---低于指定血量 则自动补血

actionFreqMS=1000*1,--走路或者战斗的频度

game_type_id=5, ---目标玩法 PK_GAME_TYPE_ID_LINWEI:5
child_game_type_id=30501,
}


local function pksvr_info_got_hdlr(plr,pkip,pkport)
  	sndEnterPk(plr,testPolicy.game_type_id,testPolicy.child_game_type_id)  
end
g_pksvr_info_got_hdlr[#g_pksvr_info_got_hdlr+1]=pksvr_info_got_hdlr

local pksvr_login=testclient.pksvr_login

--成功进入玩法
local function pksvr_enter_wanfa_hdlr(plr,game_type_id,child_game_type_id)
--table.dump('plr.ch:',plr.ch,-1)
    plr.bEnterPKSvr=true
    local gcid=testclient.mergeUint(g_Aid,plr.ch.id)
    
    pmsg(plr,'bEnterPKSvr!!!!',plr.pid,plr.ch.id,gcid)
    
    pksvr_login(LUA_ENG_C_PROXY,plr.pid,gcid)
end
g_pksvr_enter_wanfa_hdlr[#g_pksvr_enter_wanfa_hdlr+1]=pksvr_enter_wanfa_hdlr

-----------定时器


  ---游戏服进入场景后 尝试进入pk服 然后在pk服开展测试业务
local function tm_presstest_gamesvr(plr,tNow)
  if not plr.LinWei then
     plr.LinWei={}
  end
  if plr.bEnterPKSvr then
	return 
  end
if not plr.testData  then
  plr.testData ={}
end
local testData=plr.testData 
  
  --先确保等级达到了要求
  if plr.ch.level<testPolicy.autoUpLevTo then    
	  if not testData.tNextUplev then
		 testData.tNextUplev=0
	  end
	  if tNow <testData.tNextUplev then
	     return
	  end
	  testData.tNextUplev=tNow+1000*10--不需要太频繁检查升级
	  
  		pmsg(plr,'uplev req sent levNow:%d',plr.ch.level)
		sendGMCmd(plr,'uplev',string.format('%d',testPolicy.autoUpLevTo-plr.ch.level))
		return 
  end
  
  ---先确保进入主城 然后才能进入pk服
  if main_city_scene_id~=plr.scene_id then
     if not testData.tNextEnterMainCity then
		testData.tNextEnterMainCity=0
	 end
	 if tNow<testData.tNextEnterMainCity then
	    return
	 end
	 testData.tNextEnterMainCity=tNow+1000*10        
	 sendGMCmd(plr,'scene_move',main_city_scene_id)
	 return 
  end
    
  if plr.tNextGetPkgSvrInfo and tNow<plr.tNextGetPkgSvrInfo then
     return
  end
  
  
  if not plr.bPKSvrInfoGot then
     plr.tNextGetPkgSvrInfo = tNow+1000*1
     --查询pk服信息
     sendGetPkInfo(plr)     
     return 
  end
end

local l_iLinweiRandMoveIdx=0

function tm_presstest_test_logic_pk_simple(plr,tNow)
 if not g_testLinWei then
   return
 end
if not plr.testData  then
  plr.testData ={}
end
local testData=plr.testData 
if not testData.tNextAction then
  testData.tNextAction=tNow
end
if tNow<testData.tNextAction then
   return
end
testData.tNextAction=tNow+1000
	
--简单测试 客户端每秒 发一次战斗 或者走路请求 

	if not testData.initpos then
	    testData.initpos=true
		sendGMCmd(plr,'prandmove 100')
		return
	end
	
l_iLinweiRandMoveIdx=l_iLinweiRandMoveIdx+1
pmsg(plr,'prandmove linwei',plr.pid,plr.aoi_id,l_iLinweiRandMoveIdx)
sendGMCmd(plr,'prandmove')

end


---临危的测试业务在pk服
local function tm_presstest_pksvr(plr,tNow)  
  if not plr.testData then
   plr.testData={}
  end
  if not plr.ch then
     return
  end
    
	local testData=plr.testData
	
  --初始化当前目标场景
  if plr.scene_id~=testPolicy.target_mapid  then
		---还没有进入目标场景 则自动切换
		if not testData.tNextEnterScene then
		   testData.tNextEnterScene=0
		end
		if tNow<testData.tNextEnterScene then
		   return
		end
		 testData.tNextEnterScene=tNow+1000*100--

		testData.current_test_sceneid=testPolicy.target_mapid
		
		pmsg(plr,'!!!!!scene_move req sent ')
		sendGMCmd(plr,'scene_move',string.format('%d',testData.current_test_sceneid))
		return 
  end
    
  ----场景已经切换好 可以正式开始测试业务
	tm_presstest_test_logic_pk_simple(plr,tNow) 
  
end



local function tm_presstest(plr,tNow)
  if not g_testLinWei then
    return
  end    
 if not plr then
	 return 
  end
	local aoi_obj_plr=getAoiObjPlr(plr)
  if not aoi_obj_plr  or not aoi_obj_plr.x then
    return 
  end
  if not plr.bEnterSceneComplete then
    return
  end
  if not plr.testData then
   plr.testData={}
  end
  if not plr.ch then
     return
  end


  local testData=plr.testData
  
  --pk服和游戏服的逻辑不同
  if IS_PK_SVR then
    tm_presstest_pksvr(plr,tNow)
  else
    tm_presstest_gamesvr(plr,tNow)
  end
end
g_timer_hdlrs_with_plr[#g_timer_hdlrs_with_plr+1]=tm_presstest