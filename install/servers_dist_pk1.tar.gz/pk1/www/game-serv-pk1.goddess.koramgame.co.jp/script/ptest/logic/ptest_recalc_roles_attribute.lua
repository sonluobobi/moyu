--- 角色属性重算

---登录账号第每个角色 重算属性
local c_opHandlers = c_opHandlers._handlers

local random = math.random

local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr
local timer_hdlrs_no_plr=g_timer_hdlrs_no_plr

local fastpacketSnd = FastPacket()

local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local sqrt=math.sqrt
local ceil=math.ceil


local decode_c = cjson.decode_c
local encode_c = cjson.encode_c


local TYPE_MOVE=MOVE_TYPE.TYPE_MOVE


local mapAcc2Plr=g_mapAcc2Plr

local findArg=testclient.findArg

local g_bRecalRolesAttr=(g_action=='recalc')

local g_recalc_ini=findArg("recalc_ini:",false)

local g_pids={}
if g_bRecalRolesAttr then
	io.input( io.open(g_recalc_ini), 'r')
	for line in io.lines() do
	   g_pids[#g_pids+1]=tonumber(line)+0
	end

io.close(io.input())

--table.dump('g_bRecalRolesAttr g_pids:',g_pids,-1)
end			
 
--每个app 有 g_thread_num个线程 每个线程有g_acc_per_thread个账号

--只支持单账号（多账号未测试）

local g_idxfrom=1+(g_thread_num*g_appindex+g_testclient_eng_idx)*g_acc_per_thread

local g_recal_pid_idx_from=g_idxfrom
local g_recal_pid_idx_to=g_idxfrom+g_acc_per_thread-1

if g_recal_pid_idx_to>#g_pids then
  g_recal_pid_idx_to=#g_pids
end
local g_recal_pid_idx=g_recal_pid_idx_from

local g_role_idx=1
local g_characterList
local g_recal_pid_running

local g_bFinished
-----------定时器

local function tm_recal_role_attrib_no_plr(tNow)  
  if not g_bRecalRolesAttr then
     return
  end
  if g_recal_pid_idx>g_recal_pid_idx_to then
	if not g_bFinished then
		pmsg(plr,'------------------@@@@recalc finished!!')
		g_bFinished= true
	end
    return
  end
  --有账号正在测试
  if g_recal_pid_running then
     return 
  end
  local pid=g_pids[g_recal_pid_idx]+0
  g_recal_pid_running=pid
  g_role_idx=1  
  
  pmsg(plr,'acc begin:',g_recal_pid_running,g_recal_pid_idx,g_role_idx)
  --登录账号 开始测试
  
	local envRecal={}	
	envRecal.pidFrom=pid
	envRecal.pidTo=pid
	envRecal.bEnable=true
	envRecal.bDontAutoReconnect=true
	
	g_test_players[#g_test_players+1]=envRecal
end
g_timer_hdlrs_no_plr[#g_timer_hdlrs_no_plr+1]=tm_recal_role_attrib_no_plr

-------------------
local function tm_recal_role_attrib_with_plr(plr,tNow)  
  if not g_bRecalRolesAttr then
     return
  end
  if not plr then
    return
  end
  if not plr.recalc_info then
    plr.recalc_info={}
  end
  
  local recalc_info=plr.recalc_info
  
  if not plr.bEnterSceneComplete then
     return 
  end
  if not g_characterList then
    return 
  end
  
  --2000个账号 2000*200/1000=400s
    ----已经进入场景 则发送重算请求 然后等一会断开连接
    if not recalc_info.bCmdRecalcSent then
       recalc_info.bCmdRecalcSent= true
       
		sendGMCmd(plr,'recalc')
	
		pmsg(plr,'recal:',g_recal_pid_running,g_role_idx)
    
       recalc_info.tLogout=tNow+50
    end
    if tNow<recalc_info.tLogout then
      return
    end
    pmsg(plr,'oneRole finished:',g_recal_pid_running,g_recal_pid_idx,g_role_idx,#g_characterList)
    
    --超时 自动断开 
    disconn_plr(plr)
    g_role_idx=g_role_idx+1
    
  
  ---所有角色都登录完毕则表示当前账号结束 准备处理下一个账号
  if g_characterList and g_role_idx>#g_characterList then
    g_recal_pid_running=nil
    g_role_idx=1
    g_characterList=nil
    
    g_recal_pid_idx=g_recal_pid_idx+1
    
	pmsg(plr,'acc next idx:',g_recal_pid_idx)
else
  local pid=g_pids[g_recal_pid_idx]+0
	local envRecal={}	
	envRecal.pidFrom=pid
	envRecal.pidTo=pid
	envRecal.bEnable=true
	envRecal.bDontAutoReconnect=true
	
	g_test_players[#g_test_players+1]=envRecal
  end
  
	  
end
g_timer_hdlrs_with_plr[#g_timer_hdlrs_with_plr+1]=tm_recal_role_attrib_with_plr


function evtHdlr_CharacterListGot(plr,characterList)
  if not g_bRecalRolesAttr then
     return 1
  end
    g_characterList=characterList
	return g_role_idx  
end

function evtHdlr_CharacterListEmpty(plr)
  g_characterList={}
  if not g_bRecalRolesAttr then
     return nil
  end
  g_recal_pid_running=nil --测试下一个账号
  g_role_idx=1
  g_recal_pid_idx=g_recal_pid_idx+1
  return nil
end

if g_bRecalRolesAttr then
	g_evtHdlr_CharacterListGot=evtHdlr_CharacterListGot
	g_evtHdlr_CharacterListEmpty=evtHdlr_CharacterListEmpty
end