----压力测试
local c_opHandlers = c_opHandlers._handlers

local random = math.random

local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr
local timer_hdlrs_no_plr=g_timer_hdlrs_no_plr

local fastpacketSnd = FastPacket()

local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local sqrt=math.sqrt
local ceil=math.ceil

local printAndLog=external.printAndLog


local decode_c = cjson.decode_c
local encode_c = cjson.encode_c


local TYPE_MOVE=MOVE_TYPE.TYPE_MOVE


local mapAcc2Plr=g_mapAcc2Plr

local findArg=testclient.findArg

local g_bPresstest=(g_action=='presstest')
if g_bPresstest then
  print('presstest enabled!!!')
end

--只初始化 不走路战斗
local g_initonly=(findArg('initonly:',true)==1)
 
local envPresstest={
pidFrom=g_accfrom,
pidTo=g_accto or g_accfrom,
bEnable=g_bPresstest
}
g_test_players[#g_test_players+1]=envPresstest

--夺宝,4xxxx,100~xx :固定在map1
----200xx野外,3xxxx关卡,301000~~309999关卡,100301~100501,2001x :在map2
----10001,10002 主城， 在map3~n
--测试策略：
--建角色 在新手村（10021）
--升级到100级
--切到新手野外（20012）
--随机移动 打怪

--跨服pk测试复杂 暂时不考虑

--新手野外最多30人


--新手野外地图分布点
local pos_list_newbie={--20012
[1]={x=39,y=80},
[2]={x=29,y=68},
[3]={x=20,y=66},
[4]={x=18,y=78},
[5]={x=28,y=88},
}

local monster_pos_arr={[20012]=pos_list_newbie}

local function getMonsterPos(plr)
  local poslist=monster_pos_arr[plr.scene_id]
  if not poslist then
     pmsg(plr,'plr.scene_id------',plr.scene_id)
  end
  local cnt=#poslist
  local idx=plr.pid%cnt+1
  return poslist[idx]
end

local xuezu_skill_default={id=10101,cd=400}--血族
local wangling_skill_default={id=10201,cd=400}--亡灵
local zhanshi_skill_default={id=10301,cd=400}--战士

local prof_setting={
[1]={skills={[1]=xuezu_skill_default}},
[2]={skills={[1]=wangling_skill_default}},
[3]={skills={[1]=zhanshi_skill_default}},
}

local function getSkill(plr)
--pmsg(plr,'plr.ch.prof',plr.ch.prof,plr.prof)
   local skills=prof_setting[plr.ch.prof].skills
   local idx=1--random(1,#skills)-1+1
   return skills[idx]
end

local testPolicy=
{
aoe_mapid=20012,

autoUpLevTo=100,--自动升级到100级

minLifeAutoHp=10000,---低于指定血量 则自动补血

actionFreqMS=1000*1,--走路或者战斗的频度
}


local g_bMove=true
local function tm_presstest_test_logic_simple(plr,tNow)
  
 if not g_bPresstest then
   return
 end
  
local testData=plr.testData 
if not testData.tNextAction then
  testData.tNextAction=tNow
end

if tNow<testData.tNextAction then
   return
end
testData.tNextAction=tNow+1000
	
 
if not testData.tNextRestPos then
   testData.tNextRestPos=tNow
end
if tNow>=testData.tNextRestPos then
    --print('reset pos')
	testData.tNextRestPos=tNow+1000*60*2
	
	pmsg(plr,'resetpos',plr.pid,plr.aoi_id)
    local pos=getMonsterPos(plr)
    sendGMCmd(plr,'fly',string.format('%d %d',pos.x+random()%10-5,pos.y+random()%10-5))
    return 
end

--print('action tNow:',tNow)

--简单测试 客户端每秒 发一次战斗 或者走路请求 
  g_bMove= (not g_bMove)
  if g_bMove then
    pmsg(plr,'prandmove',plr.pid,plr.aoi_id)
	sendGMCmd(plr,'prandmove')
  else
	pmsg(plr,'pattack',plr.pid,plr.aoi_id)
	testData.current_skill=getSkill(plr)
	sendGMCmd(plr,'pattack',string.format("%d",testData.current_skill.id))
  end
end

-----------定时器

local function tm_presstest(plr,tNow)
  if not g_bPresstest then
    return
  end    
 if not plr then
	 return 
  end
	local aoi_obj_plr=getAoiObjPlr(plr)
  if not aoi_obj_plr  or not aoi_obj_plr.x then
    return 
  end
  if not plr.bEnterSceneComplete then
    return
  end
  if not plr.testData then
   plr.testData={}
  end
  if not plr.ch then
     return
  end
  
  local testData=plr.testData
  --先确保等级达到了要求
  if plr.ch.level<testPolicy.autoUpLevTo then    
	  if not testData.tNextUplev then
		 testData.tNextUplev=0
	  end
	  if tNow <testData.tNextUplev then
	     return
	  end
	  testData.tNextUplev=tNow+1000*10--不需要太频繁检查升级
	  
  		pmsg(plr,'uplev req sent levNow:%d',plr.ch.level)
		sendGMCmd(plr,'uplev',string.format('%d',testPolicy.autoUpLevTo-plr.ch.level))
		return 
  end
  
  
  --初始化当前目标场景
  if not testData.current_test_sceneid then
		testData.current_test_sceneid=testPolicy.aoe_mapid
  end
  
  if plr.scene_id~=testData.current_test_sceneid  then
		---还没有进入目标场景 则自动切换
		if not testData.tNextEnterScene then
		   testData.tNextEnterScene=0
		end
		if tNow<testData.tNextEnterScene then
		   return
		end
		 testData.tNextEnterScene=tNow+1000*100--

		pmsg(plr,'scene_move req sent levNow:%d',plr.ch.level)
		sendGMCmd(plr,'scene_move',string.format('%d',testData.current_test_sceneid))
		return 
  end
  
  if g_initonly then
     return 
  end
  
  ----场景已经切换好 可以正式开始测试业务
	tm_presstest_test_logic_simple(plr,tNow) 
  
end
g_timer_hdlrs_with_plr[#g_timer_hdlrs_with_plr+1]=tm_presstest
