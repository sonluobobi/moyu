
local c_opHandlers = c_opHandlers._handlers

local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr

local fastpacketSnd = FastPacket()

local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local random = math.random
local sqrt=math.sqrt
local ceil=math.ceil

local printAndLog=external.printAndLog

local decode_c = cjson.decode_c
local encode_c = cjson.encode_c


---------------
do
	function m2c_ch_pet_allinfo_get(plr, fastPacket,tNow)	
		--	    
	    local params=FastPacket_readParams("PackChPet.M2C_CH_PET_ALLINFO_GET",fastPacket)
		table.dump( "m2c_ch_pet_allinfo_get  :", params, 10 )	 
		table.dump( "arr_ch_pet  :", params.arr_ch_pet or {}, 10 )	 
		
	        if not plr.pets then
	          plr.pets={}
	        end
	        
	    if params.arr_ch_pet then
	      for k=1,#params.arr_ch_pet do
	        local pet=params.arr_ch_pet[k]
	        if not pet.level then
	           pet.level=PetDefs.PET_INIT_LEVEL
	        end
	        plr.pets[pet.id]=pet
	      end
	    end
	    
	    plr.fight_ch_pet_id=params.fight_ch_pet_id
	    plr.heti_ch_pet_ids=params.heti_ch_pet_ids
	    
	    plr.bChPetAllInfoGot=true
	    	    
	end
	if g_bEnablePet then
	c_opHandlers[opCodes.M2C_CH_PET_ALLINFO_GET] = m2c_ch_pet_allinfo_get
	end
end

--- ��ս���ޡ�����������Է���(����ʱ����)
do
	function m2c_ch_pet_fight_heti_pets(plr, fastPacket,tNow)	
		--	    
	    local params=FastPacket_readParams("PackChPet.M2C_CH_PET_FIGHT_HETI_PETS",fastPacket)
		table.dump( "fight_ch_pet  :", params.fight_ch_pet, 10 )		
		table.dump( "heti_ch_pets  :", params.heti_ch_pets, 10 )
		
	    plr.fight_ch_pet_id=params.fight_ch_pet.id
	    plr.pets[plr.fight_ch_pet_id]=params.fight_ch_pet
	        
	    plr.heti_ch_pet_ids={}
	    for k=1,#params.heti_ch_pets do
	      local pet=params.heti_ch_pets[k]
	      plr.pets[pet.id]=pet
	      table.insert(plr.heti_ch_pet_ids,pet.id)
	    end 	    
	end
	if g_bEnablePet then
	c_opHandlers[opCodes.M2C_CH_PET_FIGHT_HETI_PETS] = m2c_ch_pet_fight_heti_pets
	end
end


--- ���ó�ս���޳ɹ�
do
	function m2c_ch_pet_set_fight_pet(plr, fastPacket,tNow)  
	    local params=FastPacket_readParams("PackChPet.M2C_CH_PET_SET_FIGHT_PET",fastPacket)		
	    plr.fight_ch_pet_id=params.ch_pet_id	            
	end
	if g_bEnablePet then
	c_opHandlers[opCodes.M2C_CH_PET_SET_FIGHT_PET] = m2c_ch_pet_set_fight_pet
	end
end

--- ���ú������ �ɹ�
do
	function m2c_ch_pet_set_heti_pet(plr, fastPacket,tNow)  
	    local params=FastPacket_readParams("PackChPet.M2C_CH_PET_SET_HETI_PET",fastPacket)		
	    plr.heti_ch_pet_ids[params.order_by]=params.ch_pet_id	            
	end
	if g_bEnablePet then
	c_opHandlers[opCodes.M2C_CH_PET_SET_HETI_PET] = m2c_ch_pet_set_heti_pet
	end
end

--- �������� �ɹ�
do
	function m2c_ch_pet_upgrade(plr, fastPacket,tNow)  
	    local params=FastPacket_readParams("PackChPet.M2C_CH_PET_UPGRADE",fastPacket)		
	    local pet=plr.pets[params.ch_pet_id]
	    --pet
	    --print('--------------m2c_ch_pet_upgrade',params.ch_pet_id)
	end
	
	if g_bEnablePet then
	c_opHandlers[opCodes.M2C_CH_PET_UPGRADE] = m2c_ch_pet_upgrade
	end
end

--- ����ͻ�Ƴɹ�
do
	function m2c_ch_pet_break_level(plr, fastPacket,tNow)  
	    local params=FastPacket_readParams("PackChPet.M2C_CH_PET_BREAK_LEVEL",fastPacket)		
	    local pet=plr.pets[params.ch_pet_id]
	    --pet
	    print('--------------m2c_ch_pet_break_level',params.ch_pet_id)
	end
	if g_bEnablePet then
	c_opHandlers[opCodes.M2C_CH_PET_BREAK_LEVEL] = m2c_ch_pet_break_level
	end
end

--- ���ػ�����ϸ��Ϣ
do
	function m2c_ch_pet_detail_get(plr, fastPacket,tNow)  
	    local params=FastPacket_readParams("PackChPet.M2C_CH_PET_DETAIL_GET",fastPacket)		
	    plr.pets[params.ch_pet.id]=params.ch_pet
	    --pet
	    print('--------------m2c_ch_pet_detail_get idPet:',params.ch_pet.id,' level:',params.ch_pet.level)
	end
	if g_bEnablePet then
	c_opHandlers[opCodes.M2C_CH_PET_DETAIL_GET] = m2c_ch_pet_detail_get
	end
end

--- �»��һ����
do
	function m2c_ch_pet_add(plr, fastPacket,tNow)  
	    local params=FastPacket_readParams("PackChPet.M2C_CH_PET_ADD",fastPacket)		
	    if not plr.pets then
	      plr.pets={}
	    end
	    plr.pets[params.ch_pet.id]=params.ch_pet
	    
	    print('--------------m2c_ch_pet_add idPet:',params.ch_pet.id,' level:',params.ch_pet.level)
	end
	if g_bEnablePet then
	c_opHandlers[opCodes.M2C_CH_PET_ADD] = m2c_ch_pet_add
	end
end
