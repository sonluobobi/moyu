
local c_opHandlers = c_opHandlers._handlers

local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr

local fastpacketSnd = FastPacket()

local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local random = math.random
local sqrt=math.sqrt
local ceil=math.ceil

local printAndLog=external.printAndLog

local decode_c = cjson.decode_c
local encode_c = cjson.encode_c

local SkillDetailDao = SkillDetailDao
local SkillDetailId2Detail=SkillDetailId2Detail

---------------

do
	local lcSkillBaseDao
	local lcSkillDetailDao
	function m2c_ch_skill_skills_info_get(plr, fastPacket,tNow)	
	   if not lcSkillDetailDao then lcSkillDetailDao=SkillDetailDao end
	   if not lcSkillBaseDao then lcSkillBaseDao=SkillBaseDao end
		--	    
	    local params=FastPacket_readParams("PackSkill.M2C_CH_SKILL_SKILLS_INFO_GET",fastPacket)
		--table.dump( "m2c_ch_skill_skills_info_get  :", params, 10 )	 
		
		--table.dump( "lcSkillBaseDao  :", lcSkillBaseDao, 10 )
		--table.dump( "lcSkillDetailDao  :", lcSkillDetailDao, 10 )		 
		
		local arr_ch_skill=params.arr_ch_skill
		
		plr.arr_ch_skill={}
		
		for k=1,#arr_ch_skill do
		  local skill_id=arr_ch_skill[k].skill_id
		  plr.arr_ch_skill[skill_id]=arr_ch_skill[k].level
		  
		  --skillbase nil,why?
		  local skillbase=lcSkillBaseDao[skill_id]
			
		--table.dump( "skillbase  :", skillbase, 10 )		
		
		  local skillname= ""--lcSkillDetailDao[skill_id][arr_ch_skill[k].level]
		  if skillbase then
		    skillname=skillbase.title
		  end
		  
		  --skillbase.title
		  --print('skillname:',skillname)
		  --pmsg(plr,"[%d] skillid:%d level:%d title:%s",k ,skill_id or 0,arr_ch_skill[k].level or 0,skillname or "")
		end
		
		plr.bSkillInfoGot=true		
	end
	if g_bEnableSkill then
	c_opHandlers[opCodes.M2C_CH_SKILL_SKILLS_INFO_GET] = m2c_ch_skill_skills_info_get
	end
end


do
	function m2c_ch_skill_open(plr, fastPacket,tNow)	
	    local params=FastPacket_readParams("PackSkill.M2C_CH_SKILL_CHSKILL_OPEN",fastPacket)
		--table.dump( "m2c_ch_skill_open  :", params, 10 )	 
		
		 plr.arr_ch_skill[params.skill_id]=params.level

	end
	if g_bEnableSkill then
	c_opHandlers[opCodes.M2C_CH_SKILL_CHSKILL_OPEN] = m2c_ch_skill_open
	end
end

do
	function m2c_ch_skill_upgrade(plr, fastPacket,tNow)	
	    local params=FastPacket_readParams("PackSkill.M2C_CH_SKILL_UPGRADE",fastPacket)
		--table.dump( "m2c_ch_skill_upgrade  :", params, 10 )	 
		
		 plr.arr_ch_skill[params.skill_id]=params.level

	end
	if g_bEnableSkill then
	c_opHandlers[opCodes.M2C_CH_SKILL_UPGRADE] = m2c_ch_skill_upgrade
	end
end
