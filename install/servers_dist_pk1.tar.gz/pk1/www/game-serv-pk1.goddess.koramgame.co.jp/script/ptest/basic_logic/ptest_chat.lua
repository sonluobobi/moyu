
local c_opHandlers = c_opHandlers._handlers

local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr

local fastpacketSnd = FastPacket()

local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local random = math.random
local sqrt=math.sqrt
local ceil=math.ceil

local printAndLog=external.printAndLog




local decode_c = cjson.decode_c
local encode_c = cjson.encode_c


function gm_sendCmd(plr,cmd,p1,p2,p3,p4,p5)
   local gmcmd={method=cmd}
   local strCmd='./'..cmd
   if p1 then 
      gmcmd.p1=p1
   end
   if p2 then 
      gmcmd.p2=p2
   end
   if p3 then 
      gmcmd.p3=p3
   end
   if p4 then 
      gmcmd.p5=p4
   end
   if p5 then 
      gmcmd.p5=p5
   end
   local json=encode_c(gmcmd)
   
   print('gm_sendCmd',plr.pid,' gmcmd:',json)
   
  fastpacketSnd:clear(false,false)	  
  fastpacketSnd:initFastPacket(opCodes.C2B_COMMON_GM,ENCODE_TYPE_JSON)  
  fastpacketSnd:writeCString(json)
  sendFastPacket(plr,fastpacketSnd)	
end
		  
function gm_sendCmdFlyTo(plr,x,y,scene_id)
   gm_sendCmd(plr,'fly',x,y,scene_id)
end
		  
---------------
