--��ɫ����֧�ֺ�������¼ ����������
---------------

local luaOpCodeHandler = g_luaOpcodeHandler
local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr
local timer_hdlrs_no_plr=g_timer_hdlrs_no_plr

local random = math.random
local sqrt=math.sqrt
local floor=math.floor

local plog=plog

local g_tNextTryLogin=0
local g_register_interval_ms=5000---�������ʱ

local mergeUint=testclient.mergeUint

g_test_players={}--�����˺��б� 

--�Զ�����
local func_init_player
local function plrs_autologin(testEnv,tNow) 
  if not testEnv.bEnable then
     return
  end
     
  if not func_init_player then func_init_player=init_player end     
   if not testEnv.pidFrom then
     return 
   end 
   if not testEnv.pidTo then
     testEnv.pidTo =testEnv.pidFrom
   end 
   if not testEnv.pidCurrent then
     testEnv.pidCurrent=testEnv.pidFrom
   end
     
  if testEnv.pidCurrent>testEnv.pidTo then
    return 
  end
    
   if tNow<g_tNextTryLogin then
     return
   end
  
   
   --��¼���ټ�� 100 ms
   g_tNextTryLogin=tNow+100
   
	local mapAcc2Plr=g_mapAcc2Plr

    
	local kpid=make_kpid(g_Aid,testEnv.pidCurrent,g_Aid)
    
  --��ǰ�Ƿ������Ҫ����  
  local plr=mapAcc2Plr[kpid]	
  
	print("kpid1:",kpid,g_Aid,testEnv.pidCurrent,plr)
    
  if not plr then 	
	  plr=func_init_player(g_Aid,testEnv.pidCurrent,g_Aid)		    
	  
	print("kpid2:",kpid,g_Aid,testEnv.pidCurrent,plr)
    
	  if plr then
		 testEnv.pidCurrent=testEnv.pidCurrent+1  
		 
		 plr.PressTest={}
      else
        plog(nil,'failed to connect plr:',testEnv.pidCurrent)
        plog(nil,'failed to connect kpid:',kpid)
	  end
	  
	  return 
  end  
  if plr.tLockEnd and tNow<plr.tLockEnd then
    return
  end
  
  --�Ѿ�ע��ɹ� ������һ��
  if plr.bClientRegisterOK then
	 testEnv.pidCurrent=testEnv.pidCurrent+1
	 return
  end
	  
  ---δע��
  if (not plr.tNextRegister)  then
		plr.tNextRegister=tNow+g_register_interval_ms
		return 
  end
  
  if tNow<plr.tNextRegister then
		return 
  end    
  --��ʱ δ������ �Ͽ�������
  disconn_plr(plr)
  dbgmsg(plr,'register timeout!disconnect .')
end

local function tm_test_autologin(tNow) 
  for k,v in pairs(g_test_players) do  
     plrs_autologin(v,tNow)
  end
end
timer_hdlrs_no_plr[#timer_hdlrs_no_plr+1]=tm_test_autologin

local function plrs_ping(plr,tNow) 
  if not plr then
     return
  end
  if not plr.bClientRegisterOK then
	return 
  end
  if not plr.tPingNext then
    plr.tPingNext=0
  end
  if tNow<plr.tPingNext then
     return
  end
  plr.tPingNext=tNow+1000*25
    
  packet_sndReqPing(plr)
end
g_timer_hdlrs_with_plr[#g_timer_hdlrs_with_plr+1]=plrs_ping


--�����Զ�����
local function plrs_on_disconn(testEnv,plr) 
  if not testEnv.bEnable then
     return
  end    
  --- pk����ʱ������������
  if plr.bPK then
	return
  end
  
  -----------
  if testEnv.bDontAutoReconnect then
    return 
  end
  ---������ѹ�������˺ŷ�Χ
  if plr.pid<testEnv.pidFrom then
     return
  end  
  if plr.pid>testEnv.pidTo then
     return
  end   
  ----�¸���������
  testEnv.pidCurrent=plr.pid
  g_tNextTryLogin=0
  plr.bClientRegisterOK=false
  plog(plr,'���� �Զ���������') 
end


local function on_disconn(plr) 
  for k,v in pairs(g_test_players) do
     plrs_on_disconn(v,plr)
  end
  
  local mapAcc2Plr=g_mapAcc2Plr

  mapAcc2Plr[plr.kpid]=nil
end
g_on_close_conn_hdlrs[#g_on_close_conn_hdlrs+1]=on_disconn


