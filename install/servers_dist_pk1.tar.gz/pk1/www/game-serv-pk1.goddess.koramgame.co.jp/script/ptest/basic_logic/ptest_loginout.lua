 
local c_opHandlers = c_opHandlers._handlers

local makeMD5=testclient.makeMD5

--54
local PROTO_VER = 2

---这里优化开关直接读服务端的 不需要通过协议走

--local PROFILE_BIN_PKG_TAG_NEEDED=false
--local PROFILE_ENABLE_MOVE_PKG_OPT=false
--local PROFILE_ENABLE_APPEAR_DISAPPEAR_OPT=false
--local PROFILE_ENABLE_FIGHT_PKG_OPT=false

local PROFILE_BIN_PKG_TAG_NEEDED=OptimizeSetting.PROFILE_BIN_PKG_TAG_NEEDED
local PROFILE_ENABLE_MOVE_PKG_OPT=OptimizeSetting.PROFILE_ENABLE_MOVE_PKG_OPT
local PROFILE_ENABLE_APPEAR_DISAPPEAR_OPT=OptimizeSetting.PROFILE_ENABLE_APPEAR_DISAPPEAR_OPT
local PROFILE_ENABLE_FIGHT_PKG_OPT=OptimizeSetting.PROFILE_ENABLE_FIGHT_PKG_OPT

local PROFILE_ENABLE_DUM_BIN_APPEAR_DISAPPEAR=OptimizeDbg.PROFILE_ENABLE_DUM_BIN_APPEAR_DISAPPEAR

local fastpacketSnd = FastPacket()

local FastPacket_readParams=FastPacket_readParams
	
local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local decode_c = cjson.decode_c
local encode_c = cjson.encode_c

function sendRegister(plr)
		fastpacketSnd:clear(false,false)	
		fastpacketSnd:setOpt(false,false)
		fastpacketSnd:initFastPacket(opCodes.CLIENT_REGISTER,ENCODE_TYPE_BIN)
		
		fastpacketSnd:writeUInt32(plr.aid)
		fastpacketSnd:writeUInt32(plr.pid)
		
		local strRaw="Jdsj^&@!$Adfod=-Feng$%Yun123".."|-|"..plr.aid.."|-|"..plr.pid.."|-|"
		local _key=makeMD5(strRaw)
		fastpacketSnd:writeString(_key)
		
		sendFastPacket(plr,fastpacketSnd)
end

---接收服务端的优化设置 并请求身份验证
do
	
	function p2c_optimize_debug_flags(plr, fastPacket)	
		local PROTOVER_SERVER=fastPacket:readUInt32()
		if not (PROTOVER_SERVER==PROTO_VER) then
			error("PROTOVER_SERVER:",PROTOVER_SERVER," != NetConstant.PROTO_VER:",PROTO_VER)
		end
		PROFILE_BIN_PKG_TAG_NEEDED = (fastPacket:readByte () > 0);
		PROFILE_ENABLE_MOVE_PKG_OPT = (fastPacket:readByte () > 0);
		PROFILE_ENABLE_APPEAR_DISAPPEAR_OPT = (fastPacket:readByte ()> 0);
		PROFILE_ENABLE_FIGHT_PKG_OPT = (fastPacket:readByte () > 0);
		
		--print("PROFILE_BIN_PKG_TAG_NEEDED:",PROFILE_BIN_PKG_TAG_NEEDED," PROFILE_ENABLE_MOVE_PKG_OPT:",PROFILE_ENABLE_MOVE_PKG_OPT,
        --	" PROFILE_ENABLE_APPEAR_DISAPPEAR_OPT:",PROFILE_ENABLE_APPEAR_DISAPPEAR_OPT,
		  --           " PROFILE_ENABLE_FIGHT_PKG_OPT:",PROFILE_ENABLE_FIGHT_PKG_OPT)
		
		---sendRegister(plr)
		
		---这里获得没有意义了 因为已经共享 服务端的lua 所以 直接取服务端的配置就可以了
	end
	c_opHandlers[opCodes.P2C_OPTIMIZE_DEBUG_FLAGS] = p2c_optimize_debug_flags
end

---服务端返回登录结果
do
	function p2c_client_register(plr, fastPacket)	
	    plr.bClientRegisterOK=true
		print('client register ok.pid:',plr.pid,plr.aid,IS_PK_SVR)
	    
		local retCode=fastPacket:readByte()
		if g_bNoLogin then
			print(' g_bNoLogin!')
			return
		  end
		--- pk服不需要查询角色列表 直接登录
		if IS_PK_SVR then 
		    local gcid=g_pksvr_default_gcid[plr.pid]
		    if gcid then
				g_pksvr_default_gcid[plr.pid]=nil
				print('pkserver auto login:',plr.pid,gcid)
				sendPKSvrLoginGame(plr,gcid)
		    end
			return
		end
		
		if retCode==0 then
			 --//登录成功 查询角色列表			 
			fastpacketSnd:clear(false,false)		
			fastpacketSnd:setOpt(false,false)
			fastpacketSnd:initFastPacket(opCodes.C2B_CHARACTER_GET_CHARACTER_LIST_BY_PLAYER_ID,ENCODE_TYPE_BIN)
			
			---
			sendFastPacket(plr,fastpacketSnd)
		else
			print('client register failed.retcode:',retCode)
		end
	end
	c_opHandlers[opCodes.CLIENT_REGISTER] = p2c_client_register
end

---角色列表收到时 回调返回要登录第几个角色
g_evtHdlr_CharacterListGot=nil

---角色列表为空时 返回创建的新角色名
g_evtHdlr_CharacterListEmpty=nil

---服务端返回角色列表
do	
	function b2c_get_character_list_by_player_id(plr, fastPacket)
	    --	ENCODE_TYPE_JSON
		local cstrChList=fastPacket:readCString()
		local tbl=decode_c(cstrChList,false)
		--table.dump( "b2c_get_character_list_by_player_id:", tbl, 10 )
				
		if tbl and tbl.arr_character and #tbl.arr_character>0 then		
		    local iLoginIdx=1
			if g_evtHdlr_CharacterListGot then
				iLoginIdx=g_evtHdlr_CharacterListGot(plr,tbl.arr_character)	          
			end
	        
		  --player found SendReqLogin(m_PlayerHero.gcid);	
		   if iLoginIdx and iLoginIdx>0 then
				local login={gcid=tbl.arr_character[1].gcid,browser_id=0}			
				SndJSon(plr,opCodes.C2B_CHARACTER_CHARACTER_LOGIN,login)
			end			
		else
		  --no player found
		  
		  dbgmsg(plr,'b2c_get_character_list_by_player_id SendReqCreateRole')
		
		  --SendReqCreateRole(szNick,0,1,1);
		  
	      local newrole={}
	      local newrole_nick
	      if g_evtHdlr_CharacterListEmpty then
	         newrole_nick=g_evtHdlr_CharacterListEmpty(plr)
	         if not newrole_nick then
	            --不需要创建角色
	            return
	         end
	      end
	      
			  if g_bBattleTest then
				  local player_data=battletest_players[plr.pid]
				  if not newrole_nick then
					newrole_nick=string.format("ROBOT_%u",plr.pid);
				  end
				  newrole.picture=0
				  newrole.gender=1
				  --newrole.haircolor=0
				  --newrole.head=0
				  newrole.browser_id=0
				  newrole.prof=player_data.prof
				  table.dump( "newrole:", newrole, 10 )
			  else
				  newrole_nick='n'..plr.pid
				  newrole.picture=0
				  newrole.gender=1
				  --newrole.haircolor=0
				  newrole.head=0
				  newrole.browser_id=0
				  newrole.prof=3
			  end
			  
			  newrole.nick=newrole_nick
				  
			   --newrole.nick= utf8:new(newrole.nick)
				
			  SndJSon(plr,opCodes.C2B_CHARACTER_CREATE_NEW_CHARACTER,newrole)
		end
		
		---
	end
	c_opHandlers[opCodes.B2C_CHARACTER_GET_CHARACTER_LIST_BY_PLAYER_ID] = b2c_get_character_list_by_player_id
end

---服务端返回创建角色成功
do
	function b2c_create_role(plr, fastPacket)			 
		
	    local params=FastPacket_readParams("",fastPacket)	
		--table.dump( "b2c_create_role params:", params, 10 )
			    
		local err_id=params.error_id
		
		if err_id==0 then					
			 --//创建角色成功 查询角色列表	 
			fastpacketSnd:clear(false,false)	
			fastpacketSnd:setOpt(false,false)
			fastpacketSnd:initFastPacket(opCodes.C2B_CHARACTER_GET_CHARACTER_LIST_BY_PLAYER_ID,ENCODE_TYPE_BIN)
			
			---
			sendFastPacket(plr,fastpacketSnd)
			
			dbgmsg(plr,'b2c_create_role_ok')
			
		else
			local errname=errorCodeNames[err_id] 
			print('b2c_create_role failed!!!! ',plr.pid,err_id,errname)
		end
		
	end
	c_opHandlers[opCodes.B2C_CHARACTER_CREATE_NEW_CHARACTER] = b2c_create_role
end

g_evtHdlr_character_base_got={}

---登录成功后 服务端会主动发送一些信息给客户端 M2C_CHARACTER_GET_CHARACTER_BASE/M2C_SCENE_ENTRY
do
    local setIniString=testclient.setIniString
	function m2c_get_character_base(plr, fastPacket)	
		fastPacket:setOpt(false,false)
		
	    local params=FastPacket_readParams("PackCharacter.M2C_CHARACTER_GET_CHARACTER_BASE",fastPacket)
		
		--table.dump( "m2c_get_character_base ret:", params, 10 )
		
	    plr.bLoginOK=true
	    
	    --todo 只保存用到的 否则内存太大了
	    plr.ch={}
	    --只保存用到的 否则内存太大了
	    plr.ch.aoi_type=params.ch.aoi_type
	    plr.ch.id=params.ch.id
	    plr.ch.nick=params.ch.nick
	    plr.ch.hp=params.ch.hp
	    plr.ch.aoi_id=params.ch.aoi_id
	    plr.ch.max_hp=params.ch.max_hp
	    plr.ch.level=params.ch.level
	    plr.ch.prof=params.ch.prof
	    
		--plr.ch=params.ch
		--plr.aoi_id=plr.ch.aoi_id
		
		print('aoi_id:',plr.pid,plr.aoi_id)
		
		g_cid2Plr[plr.ch.id]=plr	
		g_nick2Plr[plr.ch.nick]=plr
        			
		if g_bBattleTest then
		   g_pid2Cid[plr.pid]=params.ch.id
		   setIniString('Roles',string.format('%d',plr.pid),string.format('%d',params.ch.id),'roles.ini')
		end
	end
	c_opHandlers[opCodes.M2C_CHARACTER_GET_CHARACTER_BASE] = m2c_get_character_base
end
do
	function m2c_get_character_update_attrib(plr, fastPacket)	
		fastPacket:setOpt(false,false)
		
	    local params=FastPacket_readParams("PackCharacter.M2C_CHARACTER_UPDATE_ATTRIB",fastPacket)	 
	    
	    --table.dump( "m2c_get_character_update_attrib ret:", params, 10 )
	    
		local plrReal=plr--g_cid2Plr[params.ch.id]

		if not plrReal.ch then
		 plrReal.ch={}
		end
	    for k,v in pairs(params.ch) do
	      if k~="id" then
	        plrReal.ch[k]=v
	      end
	    end
	end
	c_opHandlers[opCodes.M2C_CHARACTER_UPDATE_ATTRIB] = m2c_get_character_update_attrib
end


---登录成功后 服务端会主动发送一些信息给客户端 M2C_CHARACTER_GET_CHARACTER_BASE/M2C_SCENE_ENTRY
do
	function m2c_scene_entry(plr, fastPacket)
		fastPacket:setOpt(false,false)
		--json
	    local params=FastPacket_readParams("",fastPacket)
	    
	    --table.dump( "m2c_scene_entry ret:", params, 10 )
  
		plr.aoi_id=params.aoi_id
		plr.scene_id=params.scene_id
		plr.scene_ins_id=params.scene_ins_id
		
		
		onChangePos(plr,params.aoi_id,params.x,params.y,false)
			
	local aoi_obj_plr=getAoiObjPlr(plr);
		print('m2c_scene_entry plr x,y',aoi_obj_plr.x,aoi_obj_plr.y)
		 --//	 
		--SendReqEnterComplete
		local reqEnterComplete={scene_ins_id=plr.scene_ins_id};
				
		SndJSon(plr,opCodes.C2M_SCENE_ENTER_SCENE_COMPLETE,reqEnterComplete)
		
		
		if not IS_PK_SVR then
		
			if not plr.bFirstInfoGot then
				plr.bFirstInfoGot=true;
				---SendReqGetFirstInfo();
				fastpacketSnd:clear(false,false)	
				fastpacketSnd:setOpt(false,false)
				fastpacketSnd:initFastPacket(opCodes.C2M_CHARACTERS_GET_LOGINED_DATA,ENCODE_TYPE_BIN)										
				sendFastPacket(plr,fastpacketSnd)
			end
		
		end
		
	end
	c_opHandlers[opCodes.M2C_SCENE_ENTRY] = m2c_scene_entry
end


			
---收到服务端通知：场景初始化完成
do
	function m2c_scene_enter_scene_complete(plr, fastPacket)
		
	    local params=FastPacket_readParams("",fastPacket)
	    
		table.dump( "m2c_scene_enter_scene_complete params  :", params, -1 )	
		--table.dump( "m2c_scene_enter_scene_complete plr :", plr, -1 )	
			
	local aoi_obj_plr=getAoiObjPlr(plr);
		
		if params.scene_ins_id then
		    if IS_PK_SVR then
				if not plr.ch then
				   plr.ch={}
				end
		    end
		    
			pmsg(plr,'m2c_scene_enter_scene_complete ok ,params.scene_ins_id:%d scene_id:%d x:%f y:%f nick:%s ',params.scene_ins_id,plr.scene_id,aoi_obj_plr.x,aoi_obj_plr.y,plr.ch.nick)
			
			--table.dump( "m2c_scene_enter_complete ok :", params, 10 )		
			
			plr.scene_ins_id=params.scene_ins_id
			plr.bEnterSceneComplete=true
			
		else			
			local opcodename =opcodeNames[params.reqopcode] or ""
			local errname=errorCodeNames[params.err_id] 
			print('m2c_scene_enter_complete params.reqopcode:',params.reqopcode,params.err_id,errname)
				
		end
				 
		
	end
	c_opHandlers[opCodes.M2C_SCENE_ENTER_SCENE_COMPLETE] = m2c_scene_enter_scene_complete
end
			
do
	function m2c_common_error(plr, fastPacket)
	    local params=FastPacket_readParams("",fastPacket)	 
	    
		local opcodename =opcodeNames[params.reqopcode] or ""
		local errname=errorCodeNames[params.err_id] or ""
	   
		print(string.format('rcv :m2c_common_error err_id:%d(%s) reqopcode:%d(%s) ',params.err_id,errname,params.reqopcode,opcodename))
		
	    --table.dump( "paramsxxx:", params, 10 )
	end
	c_opHandlers[opCodes.M2C_COMMON_ERROR] = m2c_common_error
end
	
do
	function m2c_common_gm(plr, fastPacket)
	    local params=FastPacket_readParams("",fastPacket)	 
	    
		local opcodename =opcodeNames[params.reqopcode] or ""
		local errname=errorCodeNames[params.err_id] or ""
		local data=params.data or ""
	   
	   if g_bEnableDumpGM then
			table.dump( "m2c_common_gm:", params, 10 )
	   
			--print(string.format("rcv :m2c_common_gm err_id:%d(%s) reqopcode:%d(%s) data:%s.",params.err_id or 0,errname,params.reqopcode or 0,opcodename,data))
			print(string.format("rcv :m2c_common_gm data:%s.",data))
		
	   end
	end
	c_opHandlers[opCodes.M2C_COMMON_GM] = m2c_common_gm
end

