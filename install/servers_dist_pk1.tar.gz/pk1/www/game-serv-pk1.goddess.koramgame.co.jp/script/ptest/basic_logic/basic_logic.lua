local mergeUint=testclient.mergeUint

function make_kpid(aid,pid,bornAid)
	local kpid=mergeUint(aid,pid)
	return kpid
end
    

function canSendReqMove(plr,tNow)
  --�г����ڼ��ֹ�ƶ�
  if plr.tChgMapLockExpired  then
     if tNow<plr.tChgMapLockExpired then
       --print('!canSendReqMove tChgMapLockExpired')
       return false
     end
     plr.tChgMapLockExpired=nil
  end
  --ǰһ���ƶ����������ڼ� �������ٷ��ƶ�����
  if plr.tReqMoveSendLockExpire then
    if tNow<plr.tReqMoveSendLockExpire then
       --print('!canSendReqMove tReqMoveSendLockExpire')
      return false
    end
    plr.tReqMoveSendLockExpire=nil
  end
 
  return true
end

function onObjDieOrDisappear(plr,aoi_id)
    if aoi_id==plr.aoi_id then
		--����������������aoiobj
		return
    end
	plr.aoi_objs[aoi_id]=nil
end

----����aoi objѪ��
function onUpdateHp(plr,aoi_id,new_hp)
	local aoi_obj=getAoiObj(plr,aoi_id)
	if aoi_obj then
	  aoi_obj.hp=new_hp
	end
	if new_hp ==0 then
	  onObjDieOrDisappear(plr,aoi_id)
	end
	
	if plr.aoi_id==aoi_id then
	  plr.ch.hp=hp
	end
end

function IsPlayerOrRobot(aoi_type)
	return (aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_PLAYER ) or (aoi_type == AoiObjectType.AOI_OBJECT_TYPE_ID_ROBOT )
end

function getAoiObj(plr,aoi_id,bAutoAddIfNotFound)
	
	if not aoi_id then
		return nil
	end
	if not plr.aoi_objs then
	  plr.aoi_objs={}
	end
   local aoi_obj=plr.aoi_objs[aoi_id]
   if not aoi_obj then
      if bAutoAddIfNotFound then
			aoi_obj={aoi_id=aoi_id}
			plr.aoi_objs[aoi_id]=aoi_obj
	  end
   end
   return aoi_obj
end

function getAoiObjPlr(plr)
	return getAoiObj(plr,plr.aoi_id,true)
end

function onChangePos(plr,aoi_id,x,y,bMoving)
	local aoi_obj=getAoiObj(plr,aoi_id,aoi_id==plr.aoi_id)
	if not aoi_obj then
		return
	end
	
	   aoi_obj.is_moving=bMoving or false
	   aoi_obj.x=x
	   aoi_obj.y=y	
end
