
function sndEnterPk(plr,game_type_id,child_game_type_id)
  		pmsg(plr,'try to enter game_type_id:%d join_room_id:%d',game_type_id,child_game_type_id)
  		
        local tbl={game_type_id=game_type_id,child_game_type_id=child_game_type_id or 0}
		SndJSon(plr,opCodes.C2B_PKSERVER_JOIN_IN,tbl)	
end

function sndLeavePk(plr,join_game_id,child_game_type_id)
  		pmsg(plr,'sndLeavePk game_type_id:%d child_game_type_id:%d',game_type_id,child_game_type_id)
        local data ={}
        data.game_type_id = game_type_id
        data.child_game_type_id = child_game_type_id
        
        sendPB(plr,'PackPKServer.C2PKB_SCENE_LOGOUT',PackPKServer.C2PKB_SCENE_LOGOUT,data,false)
end


g_pksvr_enter_wanfa_hdlr={}

---�����淨
do
	function m2c_pkserver_join_in(plr, fastPacket)		
		fastPacket:setOpt(false,false)
		--json
	    local params=FastPacket_readParams("",fastPacket)	 
	    
		pmsg(plr,'m2c_pkserver_join_in:game_type_id:%d child_game_type_id:%d',params.game_type_id,params.child_game_type_id)
			    	
		for _,hdlr in pairs(g_pksvr_enter_wanfa_hdlr) do
		   hdlr(plr,params.game_type_id,params.child_game_type_id)
		end
		
	end
	c_opHandlers[opCodes.M2C_PKSERVER_JOIN_IN] = m2c_pkserver_join_in
end


    function sendPKSvrLoginGame(plr,gcid)
        print('sendPKSvrLoginGame:',plr.pid,gcid)
        
		local login={gcid=gcid,browser_id=0}			
		SndJSon(plr,opCodes.C2B_CHARACTER_CHARACTER_LOGIN,login)
    end
    
    -- ��ȡPK����Ϣ
    function sendGetPkInfo(plr)
		print('--------sendGetPkInfo:',plr.pid)
        local tbl={}
		SndJSon(plr,opCodes.C2B_PKSERVER_REGISTER,tbl)
    end
    
    g_pksvr_info_got_hdlr={}
    
    local pksvr_conn=testclient.pksvr_conn
---PK����Ϣ
do
	function b2c_pkserver_register(plr, fastPacket)		
		fastPacket:setOpt(false,false)
		--json
	    local params=FastPacket_readParams("",fastPacket)	 
	    
	    plr.bPKSvrInfoGot=true
	    
		print('rcv pkSvrInfo:',params.ip,params.port)
			    

		pksvr_conn(LUA_ENG_C_PROXY,params.ip,params.port,plr.pid)
		
		for _,hdlr in pairs(g_pksvr_info_got_hdlr) do
		   hdlr(plr,params.ip,params.port)
		end
		
	end
	c_opHandlers[opCodes.B2C_PKSERVER_REGISTER] = b2c_pkserver_register
end


