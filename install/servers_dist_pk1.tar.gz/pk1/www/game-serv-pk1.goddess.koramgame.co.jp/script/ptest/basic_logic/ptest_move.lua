
local c_opHandlers = c_opHandlers._handlers
local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr
local timer_hdlrs_no_plr=g_timer_hdlrs_no_plr
local fastpacketSnd = FastPacket()

local ENCODE_TYPE_BIN=encodeType.ENCODE_TYPE_BIN
local ENCODE_TYPE_JSON=encodeType.ENCODE_TYPE_JSON
local ENCODE_TYPE_PB=encodeType.ENCODE_TYPE_PB

local random = math.random
local sqrt=math.sqrt
local ceil=math.ceil

local printAndLog=external.printAndLog

local PROFILE_BIN_PKG_TAG_NEEDED=OptimizeSetting.PROFILE_BIN_PKG_TAG_NEEDED
local PROFILE_ENABLE_MOVE_PKG_OPT=OptimizeSetting.PROFILE_ENABLE_MOVE_PKG_OPT
local PROFILE_ENABLE_DUM_BIN_MOVE_PKG=OptimizeDbg.PROFILE_ENABLE_DUM_BIN_MOVE_PKG

local canMove=canMove

g_pidRandMove={}


---移动测试
---------------
---------------
local pos_is_standable=testclient.is_standable

function is_standable(scene_id,x,y)
  return pos_is_standable(scene_id,x,y)
end

local TYPE_MOVE=MOVE_TYPE.TYPE_MOVE
local fastpacket_WritePath=fastpacket_WritePath

function sendReqMoveTo(plr,x,y)
  local aoi_obj=plr.aoi_objs[plr.aoi_id]

    local pos_arr={aoi_obj.x,aoi_obj.y,x,y}
    
	fastpacketSnd:clear(false,false)	
	fastpacketSnd:setOpt(PROFILE_ENABLE_MOVE_PKG_OPT,false)--PROFILE_ENABLE_DUM_BIN_MOVE_PKG)	        
	fastpacketSnd:initFastPacket(opCodes.C2M_SCENE_START_MOVE_TO_DEST,ENCODE_TYPE_BIN)

				
	fastpacketSnd:writeUInt(plr.scene_ins_id);
	fastpacketSnd:writeUInt(plr.aoi_id);
	fastpacketSnd:writeByte(TYPE_MOVE);

	fastpacket_WritePath(fastpacketSnd,pos_arr)
							
	sendFastPacket(plr,fastpacketSnd)     
	
    plr.pos_arr=pos_arr
end	
	