
local c_opHandlers = c_opHandlers._handlers


local mapAcc2Plr=g_mapAcc2Plr
local mapConn2Plr=g_mapConn2Plr

local socket_connect=testclient.socket_connect
local socket_send=testclient.socket_send
local socket_close=testclient.socket_close

local timer_hdlrs_with_plr=g_timer_hdlrs_with_plr
local timer_hdlrs_no_plr=g_timer_hdlrs_no_plr

local players_to_login={}


--接口：进程初始化
function c_initWorld()	
   print('-----c_initWorld')
   
	CsvLoader:load('map')
   print('-----c_initWorld finshed')
	
	return 12345
end

--接口：进程关闭处理
function c_shutdownWorld()	
   print('-----c_shutdownWorld')
	return 12345
end


--初始化玩家 连接服务器
function init_player(aid,acc,bornAid,bNotRandChgMap,bNotRandMove)

if not acc or acc<1 then
  error('init player failed.invalid acc:',acc)
  return
end
    
local kpid=make_kpid(aid,acc,bornAid)
    
    
local plr=mapAcc2Plr[kpid]
if plr then
  return plr
end

local conn=socket_connect(LUA_ENG_C_PROXY,g_IP,g_Port)
if conn then
   plr={conn=conn,acc=acc,aid=aid,pid=acc,kpid=kpid,bornAid=bornAid}
   plr.bPK=(plr.aid~=g_Aid)
   plr.connAid=aid
   
   mapAcc2Plr[kpid]=plr
   mapConn2Plr[conn]=plr

	plr.bNotRandChgMap=bNotRandChgMap
	plr.bNotRandMove=bNotRandMove
	
	sendRegister(plr)
	
   print(string.format('-----pid:%d=%p connect success.ip:%s port:%d plr=%p connAid:%d.',plr.pid,conn,g_IP,g_Port,plr,plr.connAid))
else
   print(' [',acc,'] xx failed to connect',g_IP,' port:',g_Port)
end

end

--周期性调用 目前50ms一次
g_idx=1
function c_update(tNow)
   --print('-----c_update',g_idx)
   g_idx=g_idx+1
      
      if not mapConn2Plr then
           mapConn2Plr=g_mapConn2Plr
      end
    for _,plr in pairs(mapConn2Plr) do
        on_timer_with_plr(plr,tNow)
    end
        
    for _,hdlr_no_plr in pairs(timer_hdlrs_no_plr) do
        hdlr_no_plr(tNow)
    end
     
end

local pksvr_disconn=testclient.pksvr_disconn

--网络连接被断开
function c_conn_close(conn)
   
local plr=mapConn2Plr[conn]

print(string.format('-----pid:%d=%p c_conn_close connAid:%d',plr.pid,conn,plr.connAid))
   
   
if plr then

	if not IS_PK_SVR then 
		pksvr_disconn(LUA_ENG_C_PROXY,plr.pid)
	end

  mapAcc2Plr[plr.kpid]=nil
  
  plr.bFirstInfoGot=nil
  
  plr.bLoginOK=false
end

mapConn2Plr[conn]=nil

end

--断开玩家连接
function disconn_plr(plr)
   local conn=plr.conn
	print('-----pid:%d=%p connAid:%d disconn_plr',plr.pid,conn,plr.connAid)
    
  for _,hdlr  in ipairs(g_on_close_conn_hdlrs) do  
	  hdlr(plr)
  end
  
	socket_close(LUA_ENG_C_PROXY,conn)
   
	if plr then
	  mapAcc2Plr[plr.kpid]=nil
	  
	  plr.bFirstInfoGot=nil
	  
	  plr.bLoginOK=false
	end

	mapConn2Plr[conn]=nil


end


---网络消息回调
function c_conn_rcv(conn,luacode,fast_packet,tNow)
    local plr=mapConn2Plr[conn]
    
	local opcodename =opcodeNames[luacode] or ""
   if g_bDumpMsgRcv then print(string.format('\n-----pid:%d=%p connAid:%d c_conn_rcv luacode:%d(%s) fastPacket:%p ',plr.pid,conn,plr.connAid,luacode,opcodename,fast_packet)) end
   
    local plr=mapConn2Plr[conn]

   local hdlr=c_opHandlers[luacode]
   if hdlr then
	  hdlr(plr,fast_packet,tNow)
   end

end

function on_timer_with_plr(plr,tNow)   

  for _,tm  in ipairs(timer_hdlrs_with_plr) do  
	  tm(plr,tNow)
  end
end

function c_pksvr_close_by_pid(pid)
   print('c_pksvr_close_by_pid:',pid)
	local kpid=make_kpid(g_Aid,pid,g_Aid)
    local plr=mapAcc2Plr[kpid]
    if not plr then
		return 
    end
	disconn_plr(plr)    
end

function c_pksvr_conn_by_pid(pszIP,uPort,pid)

   print('c_pksvr_conn_by_pid:',pszIP,uPort,pid)
g_IP=pszIP
g_Port=uPort

 local env={
pidFrom=pid,
pidTo=pid,
bEnable=true
}
g_test_players[#g_test_players+1]=env

end

g_pksvr_default_gcid={}

function c_pksvr_login_by_pid(pid,gcid)
	local kpid=make_kpid(g_Aid,pid,g_Aid)
    local plr=mapAcc2Plr[pid]
    print('c_pksvr_login_by_pid:',pid,gcid,plr)
    
    if not plr then    
		g_pksvr_default_gcid[pid]=gcid    
		return 
    end
    sendPKSvrLoginGame(plr,gcid)
end

