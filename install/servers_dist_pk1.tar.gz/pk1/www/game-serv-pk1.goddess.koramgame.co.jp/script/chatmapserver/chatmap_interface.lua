--[[
框架入口 c++调用入口函数
--]]
local tostring = tostring
local mapserver_id = g_mapserver_id
local pairs = pairs
local c_opHandlers = c_opHandlers._handlers
local i_opHandlers = i_opHandlers._handlers
local opcodeNames = opcodeNames
local AoiSceneService = AoiSceneService
local CharacterService = CharacterService
local CharacterCtrl = CharacterCtrl
local SceneCtrl = SceneCtrl
local Time = Time
local WorldPacket = WorldPacket
local Logger = Logger

local GLOBAL_PROCESS_ID=GLOBAL_PROCESS_ID
local GLOBAL_THREAD_ID=GLOBAL_THREAD_ID

-- 游戏是否已启动并初始化完成
-- 具体点说：c++框架层已调用c_initWorld 函数，lua并已经加载完成所有csv表 
g_is_world_inited = false

--加载LUA脚本完成后（包括reload)
do
	-- 响应LUA脚本加载或热更新完成
	local string_find, string_len = string.find, string.len
	function c_after_load()
		local ReadOnly = ReadOnly
		local gmt = getmetatable(_G)
		
		-- 调用所有service  ctrl 的 onAfterLoadLua(响应LUA脚本加载或热更新完成) 函数
		for cls_name, cls_obj in pairs(_G) do
			if type(cls_obj) == 'table' and cls_obj ~= _G and cls_obj ~= gmt then
				local mt = getmetatable(cls_obj)
				if mt ~= ReadOnly and type(cls_obj.onAfterLoadLua) == 'function' and
					(string_find(cls_name, 'Ctrl') == string_len(cls_name) - 3 or
						string_find(cls_name, 'Service') == string_len(cls_name) - 6)
					then
					cls_obj:onAfterLoadLua()
				end
			end
		end
	end
end

-- 启动初始化
function c_initWorld()
	local area_id = external.getAid()
	if area_id<970 then print = function()end end
	return 12345
end


--客户端请求
do
	function c_clientIndex(character, gpid, packet)
	end

	-- 内部请求
	function c_internalIndex(character, gpid, packet)
	end

	--- 玩家离开场景
	-- character
	-- is_diff_map_server : 是否是不同的mapserver
	-- packet_id : 包的id
	function c_leaveMap(character, is_diff_map_server, packet_id)
		return 12345
	end


	-- 创建lua玩家实体，和c++实体互绑
	-- cplr : 
	-- is_login : 是否是登录第一次调用
	-- packet_id : 包的id
	local push_character_garbage = assert(push_character_garbage)
	function c_initPlayer(cplr, is_login, packet_id)
		return 1;
	end
end


---进入场景
do
	local params = {}
	function c_enterMap(character, space_id, scene_id, line_id, is_login, packet_id)

		return 12345
	end
end

---销毁场景
function c_removeSpace(space_id)	
end

-- 每帧调用
do
	function c_update(time_now)
	end
end

-- 定时器回调
do
	local CharacterService
	local c_internalIndex = c_internalIndex
	function c_timerIndex(packet)
	end
end

-- 服务器退出
function c_shutdownWorld()
end

local upvalue_packet = external.makeNoGcPacket() -- 不会被gc的一块内存，用于在不同mapserver之间迁移角色数据的时候打包属性复用，不会每次都生成新的内存
function get_upvalue_packet()
	return upvalue_packet
end
	
-- 掉线重连
local params = {}
local SceneBaseDao = SceneBaseDao
function c_reconnect(character,packet_id,ip)
end

--离线之前Base向Map请求确认当前是否允许玩家离线 目前基本上都返回true
function c_try_logout(character,packet_id)
	return true
end

-- 离线退出游戏
function c_logout(character, packet_id)
	
end

--关闭服务器时保存数据
function c_save_table(character)
end

