SERVER_NAME = 'baseserver'
--需要加载的lua代码目录
--加载代码之前会先加载上层的include目录，子目录的代码比同层的lua代码后加载
loadLuaDirs =
{
	"../loadfirst_noreload",
	
	"../loadfirst",
	"../lib",
	"../include",
	"../common/entity",
	"../common/dao",
	"../common/service",
	"../common/ctrl",	
	"entity",
	"dao",
	"service",
	"ctrl",
}
reLoadLuaDirs = 
{
	"../loadfirst",
	"../include",
	"../common/service",
	"../common/ctrl",
	"service",
	"ctrl",
}