--[[
框架入口 c++调用入口函数
--]]

local c_opHandlers = c_opHandlers._handlers
local i_opHandlers = i_opHandlers._handlers
local opcodeNames = opcodeNames
local Time = Time
local SceneCtrl = SceneCtrl
local WorldPacket = WorldPacket
local ServerCall = ServerCall
local SceneBaseDao = SceneBaseDao
local GangService = GangService

local IS_TEST_SERVER = Config.IS_TEST_SERVER

g_is_world_inited = g_is_world_inited or false

	
--加载脚本完成后（包括reload)
do
	-- 响应LUA脚本加载或热更新完成
	local string_find, string_len = string.find, string.len
	function c_after_load()
		local ReadOnly = ReadOnly
		local gmt = getmetatable(_G)
		
		-- 调用所有service  ctrl 的 onAfterLoadLua(响应LUA脚本加载或热更新完成) 函数
		for cls_name, cls_obj in pairs(_G) do
			if type(cls_obj) == 'table' and cls_obj ~= _G and cls_obj ~= gmt then
				local mt = getmetatable(cls_obj)
				if mt ~= ReadOnly and type(cls_obj.onAfterLoadLua) == 'function' and
					(string_find(cls_name, 'Ctrl') == string_len(cls_name) - 3 or
						string_find(cls_name, 'Service') == string_len(cls_name) - 6)
					then
					cls_obj:onAfterLoadLua()
				end
			end
		end
	end
end

-- 启动初始化
function c_initWorld()	
	local area_id = external.getAid()
	if area_id<970 then print = function()end end
	
	g_is_world_inited = true
	
	return 12345
end

--base接收到map的连接请求时
function c_afterMapserverRegister(mapserver_id)

end

---内部函数 非接口
local function dohandle(request_name, handlers, character, gpid, packet)
  local opcode = packet:getOpcode()
  local handler = handlers[opcode]
  if not handler then
    local opcode_name = opcodeNames[opcode] or 'unknown'
    Logger:error('baseserver no found the function for',request_name,'opcode=',opcode,'opcode_name=',opcode_name)
  else
    WorldPacket.g_character = character
    WorldPacket.g_opcode = opcode
    WorldPacket.g_packet_id = packet:getPacketId()
    
    handler(character,packet,gpid)
    
    WorldPacket.g_character = 0
    WorldPacket.g_opcode = 0
    WorldPacket.g_packet_id = 0
  end
end



-- 客户端请求
function c_clientIndex(character, gpid, packet)
    dohandle('clientIndex', c_opHandlers, character, gpid, packet)
end


-- 内部请求
function c_internalIndex(character,gpid,packet)
    dohandle('internalIndex', i_opHandlers, character, gpid, packet)
end


-- 获取(分配)场景实例ID (没有会分配一个场景实例ID)
-- character:userdata	角色对象
-- packet:usedata 从mapserver传输过来的参数
function c_getInstanceSpaceId(character, packet)
	return nil
end


-- packet 平台发送过来的防沉迷信息
-- 注：packet解码之后的table需要包含字段cid,player_id,offline_time,online_time
function c_preventEnthralUp()
end

-- 每帧调用
do
	local random = math.random
	
	local frame_ms_cd = Config.FRAME_MS_CD -- 每帧的触发间隔
	local next_update_time = 0 -- 下一帧的触发时间
	
	function c_update( time_now )
		-- 不到下帧开始时间，返回		
	end
end


-- 服务器退出
function c_shutdownWorld()
end

-- 定时器回调
do
	function c_timerIndex(packet)		
	end
end

-- 创建lua玩家实体，和c++实体互邦
function c_initPlayer(cplr)
	local character = Character:new(cplr) -- 空壳
	cplr:bindLuaPlayer(character)	
end


-- 进入场景之后
function c_afterEnterMap(character, space_id, scene_id, line_id,is_login,packet_id)	
end


-- 掉线重连
function c_reconnect(character,packet_id)
end


-- 离开场景之后
function c_afterLeaveMap(character, packet_id)
	
end


-- 离线退出游戏  -- map已经离线
function c_logout(character, packet_id)
end


-- 断线
function c_disconnect(character, packet_id, gpid,isSoftLeave)
end

---pk服连接游戏服成功
function c_pk2game_connect_ok_Index(aid,group)
end




