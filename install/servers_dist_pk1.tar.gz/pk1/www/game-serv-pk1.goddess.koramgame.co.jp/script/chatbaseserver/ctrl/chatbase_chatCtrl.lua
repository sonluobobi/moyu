--[[
语音聊天ctrl
author : jinlin.liu
date : 2016-6-15
]]--

local c_opHandlers = c_opHandlers._handlers
local i_opHandlers = i_opHandlers._handlers

local opCodes = opCodes
local Time    = Time
local WorldPacket = WorldPacket
local tableInsert = table.insert
local table       = table
local ChatDefs  = ChatDefs

local externalMergeUInt = external.mergeUInt
local externalSplitUInt = external.splitUInt

local writeBlobToFile=external.writeBlobToFile
local readBlobFromFile=external.readBlobFromFile

ChatCtrl = ChatCtrl or {}


do
	
	function ChatCtrl.B2VB_GET_VCHAT_SERV_INFO(_, packet)				
		local arr_params1 = packet:readParams(opCodes.B2VB_GET_VCHAT_SERV_INFO)

		local gpid=arr_params1.gpid
		local aid=arr_params1.aid 
		
		if not gpid then
		  print("出错not gpid",gpid)
		  Logger:error('传往语音服 无gpid，已经出错')
		else
		  local arr_params = {}
      arr_params.opcode = opCodes.VB2B_GET_VCHAT_SERV_INFO
      arr_params.ip = Config.PROXY_SERVER_IP
      arr_params.port = Config.PROXY_SERVER_PORT
      arr_params.host = Config.host
      arr_params.gpid = gpid
      local areaaid = external.mergeUInt(aid % 1000, 0)
      print("areaaidareaaidareaaid",areaaid,aid)
      table.dump("B2VB_GET_VCHAT_SERV_INFO从中心到游戏服====",arr_params,-1)
      WorldPacket:pkServer2GameSendPack(opCodes.VB2B_GET_VCHAT_SERV_INFO, areaaid, arr_params)
		end		
					 
	end
	i_opHandlers[opCodes.B2VB_GET_VCHAT_SERV_INFO] = ChatCtrl.B2VB_GET_VCHAT_SERV_INFO
end

