--[[
组队 service
author : guoyin.huang
date : 2015年03月24日

]]--


TeamRobotService = TeamRobotService or {}

-- 从base发来的存储机器人的请求
do
	local team_robot_item = {child_game_type_id = 0, data='', pos = 0}
	function TeamRobotService:b2d_saveRobot( _, pack_data )
		DatabaseService:replaceByEntityCls('tbl_team_robot', pack_data, team_robot_item)
	end
end

-- 从base发来的加载缓存机器人的请求
do
	local sql = 'select child_game_type_id, data, pos from tbl_team_robot order by child_game_type_id, pos'
	local team_robot_item = {child_game_type_id = 0, data='', pos = 0}
	function TeamRobotService:b2d_loadRobot(sid, data)
		local callback = data.callback

		local fields = DatabaseService:selectEx(sql)
		local arr_team_robot = DatabaseService:getDBEntitys(fields, team_robot_item) or {}
		-- 因数据较大，一次只传送一个
		for _, team_robot in pairs(arr_team_robot) do
			ServerCall:d2xCall_0(sid, callback, nil, team_robot)	
		end	
	end
end