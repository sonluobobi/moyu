
--[[
军团战 service
author : guoyin.huang
date : 2016年04月05日
]]--

GangBattleNewService = GangBattleNewService or {}

function GangBattleNewService:b2d_clearVsData()
	Logger:info('GangBattleNewService:b2d_clearVsData')
	local sql = 'delete from tbl_gang_battle_vs'
	DatabaseService:executeEx(sql)
end

-- 保存对战数据
do
	local vs_list_entity = {
		id = 0,
		unique_key_1 = '',
		gang_info_1 = '', 
		unique_key_2 = '',
		gang_info_2 = '', 
		unique_key_3 = '',
		gang_info_3 = '',	
		group_id = 0,
		status = 0,			--状态
	}
	function GangBattleNewService:saveVsList( _, vs_list )
		vs_list.gang_info_1 = WorldPacket:encodeData(vs_list.gang_info_1)
		vs_list.gang_info_2 = vs_list.gang_info_2 and WorldPacket:encodeData(vs_list.gang_info_2)
		vs_list.gang_info_3 = vs_list.gang_info_3 and WorldPacket:encodeData(vs_list.gang_info_3)
		DatabaseService:replaceByEntityCls('tbl_gang_battle_vs', vs_list, vs_list_entity)
	end

	
	function GangBattleNewService:loadVsList( sid, data )
		local callback = data.callback
		local sql = 'select * from tbl_gang_battle_vs'
	
		local fields = DatabaseService:selectEx(sql)
		local arr_vs_info = DatabaseService:getDBEntitys(fields, vs_list_entity) or {}
		
		-- 一次传送30个
		local data = {}
		data.vs_list = {}
		local num = 0
		for _, vs_info in pairs(arr_vs_info) do
			num = num + 1
			table.insert(data.vs_list, vs_info)
			if num >= 30 then 
				ServerCall:d2xCall_0(sid, callback, nil, data)
				data.vs_list = {}	
			end
		end			
		data.is_fin = true
		ServerCall:d2xCall_0(sid, callback, nil, data)
	end
end

