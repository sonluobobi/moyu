--[[
玩法参与统计
author : guoyin.huang
date : 2015-09-21
--]]

StatActiveService = StatActiveService or {}

local tbl_name = 'tbl_stat_wanfa'

-- 增加日志记录
local stat_entity = 
{
	cid = 0,
	area_id = 0,
	game_type_id = 0,
	child_game_type_id = 0,
	game_title = '',
	child_game_title = '',
	play_start_time = '',
	updated = '',
}

function StatActiveService:m2d_addLog( _, data )
	data.updated = Time:getDateTimeStrNow()
	-- 保存到数据库中
	DatabaseService:replaceByEntityCls(tbl_name, data, stat_entity)
end