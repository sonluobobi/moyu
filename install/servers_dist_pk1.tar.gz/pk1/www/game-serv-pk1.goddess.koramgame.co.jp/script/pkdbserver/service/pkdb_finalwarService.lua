
--[[
末日之战 service
author : jinlin.liu 
date : 2016-07-08
]]--
local string_format = string.format
local fw_list_entity = fw_list_entity
local fw_simple_entity = fw_simple_entity
FinalWarService = FinalWarService or {}

function FinalWarService:b2d_cleardata()
	--Logger:info('FinalWarService:b2d_cleardata')
	local sql = 'delete from tbl_finalwar_data'
	DatabaseService:executeEx(sql)
end

-- 保存战斗数据
do	
	function FinalWarService:m2d_saveData( _, vs_list )
	   --table.dump("m2d_saveData00000000000",vs_list,-1)
	   if vs_list and vs_list.data then	  
	       local sendtobase = {}     
    	   for k,v in pairs(vs_list.data) do	       
    	       DatabaseService:replaceByEntityCls('tbl_finalwar_data', v, fw_list_entity)    	       
    	   end
       else
           Logger:error("m2d_saveData 传入参数有误")        	   
       end	   
	end
	
	function FinalWarService:b2d_loadData( sid, data )
		local callback = data.callback
		local group_id = data.group_id
		local sql = string_format('select * from tbl_finalwar_data where group_id=%d and active_id = %d and rank in (1,2,3)',group_id,FinalWarDefs.SUBID_FINALWAR1)
	
		local fields = DatabaseService:selectEx(sql)
		local arr_vs_info = DatabaseService:getDBEntitys(fields, fw_simple_entity) or {}
		
		local data = {}
		data.data = arr_vs_info
		data.group_id = group_id		
		ServerCall:d2xCall_0(sid, callback, nil, data)
	end
end

