local string_format = string.format
local string_len = string.len
local pairs = pairs
local type = type
local Logger = Logger

DatabaseService = DatabaseService or {}

local DatabaseService = DatabaseService
local Database = Database

local sql = Database.sql
local database = Database.database -- userdata: 与mysql的链接 

do
	local encode = cjson.encode
	local type = type
	function StdString:appendValue(v)
		
		local typev = type(v) 
	
		if typev == 'string' then
			self:appendEscapeStr('',v)
		elseif typev == 'table' then
			self:appendEscapeStr('',encode(v))
		else
			self:append(v)
		end
	end
	
	local pairs = pairs
	function StdString:appendWhere(where)		
		if where then	
			self:append(' WHERE ')			
			if type(where) == 'table' then
				self:append(' 1 ')			
				for k,v in pairs(where) do			
					self:append(' AND `')
					self:append(k)					
					if type(v) == 'string' then
						self:append('` LIKE ')			
					else
						self:append('` = ')	
					end
					self:appendValue(v)		
				end
			else
				self:append(where)			
			end
		end
	end
	
end


local Logger = Logger
local Time = Time

local type = type
local assert = assert
local error = error
local pairs = pairs
local implode = table.concat

function DatabaseService:init(db)
	Database:init(db)
	database = Database.database
end

---[[
--插入一条记录
--@return 自增id/-1
--]]
function DatabaseService:insert(tbl_name, obj, is_replace)
	
	assert(tbl_name)
	assert(obj)
	
	local keys_len = 0
	local keys = {}
	for k,v in pairs(obj) do
		keys_len = keys_len + 1
		keys[keys_len] = k
	end	

	if is_replace then
		sql:assign("REPLACE INTO `")
	else
		sql:assign("INSERT INTO `")
	end
	
	sql:append(tbl_name)	
	sql:append("` (`")	
	local keys_str = implode(keys, '` , `')
	sql:append(keys_str)	
	sql:append("`) VALUES (")
	sql:appendValue(obj[keys[1]])
	for i=2,keys_len do -- 不用 for k,v in pairs(obj) do，以确保key 和  value 一定是一一对应的	
		sql:append(", ")
		local v = obj[keys[i]] -- 效率会差点，没事		
		sql:appendValue(v)
	end
	sql:append(") ")
	
	local id = database:insertAndGetId(sql)	
	if id == -1 then
		local error_msg = Time:getDateTimeStrNow() .. ' fail to insert : ' .. sql:c_str()
		Logger:mysqlError(error_msg)
		error(error_msg)		
	end		
	return id		
end

function DatabaseService:query(full_sql)
	local fields, ret = database:query(sql)
	if not ret then
		local error_msg = Time:getDateTimeStrNow() .. ' fail to select : ' .. sql:c_str()
		Logger:mysqlError(error_msg)
		error(error_msg)
	end	
	
	if fields then		
		local mysql_fields_size = Database.mysql_fields_size + 1
		Database.mysql_fields_size = mysql_fields_size
		Database.mysql_fields[mysql_fields_size] = fields		
	end
	
	return fields, ret
end	

---[[
--查询操作
--@param keys string(one field or *) / array (more keys)
--@param where string or obj(key => value)
--@return 结果集和成功标识(bool)
--]]
local stringMatch = string.match
function DatabaseService:select(tbl_name,keys,where,order_by,limit)

	assert(tbl_name)
	assert(keys)

	sql:assign("SELECT ")
	
	if keys == '*' then				 -- *
		keys = keys
	elseif type(keys) == 'string' then
		local s = stringMatch(keys, '[%a%d_,]+')
		if s == keys then 
			keys = keys
		end
	elseif type(keys) == 'table' then
		for i=1,#keys do
			local field = keys[i]
			if stringMatch(field, '[%a%d_]+') == field then 
				keys[i] = '`' .. field .. '`'
			end
		end	
		keys = implode(keys,' , ')
	else
		error('[DatabaseService:select] The param:keys is err.' .. tostring(keys))
	end	
	
	sql:append(keys)
	
	sql:append(' FROM `')	
	sql:append(tbl_name)
	sql:append('` ')
	
	sql:appendWhere(where)
	
	if order_by then
		sql:append(' ORDER BY ')
		sql:append(order_by)
	end
	
	if limit then	
		sql:append(' LIMIT ')
		sql:append(limit)
	end
	
	local fields, ret = DatabaseService:query(sql)	
	
	return fields
end

---[[
--查询操作
--@param full_sql  完整的查询语句
--@return 结果集和成功标识(bool)
--]]
function DatabaseService:selectEx(full_sql)
	assert(full_sql)
	sql:assign(full_sql)
	
	local fields, ret = DatabaseService:query(sql)	
	
	return fields
end

-- 使用结果集， 获取数据结构列表
function DatabaseService:fetAll(fields, entity, id_key)
	local objs = {}
	if fields then
		local count = fields:rowCount()		
		for i = 1,count do
			local obj = {}				
			for k,v in pairs(entity) do				
				if v == 0 then
					obj[k] = fields:getIntField(k)
				elseif v == 0.1 then
					obj[k] = fields:getFloatField(k)
				else
					obj[k] = fields:getStringField(k)   
				end				
			end
			fields:nextRow()
			if id_key then
				objs[ obj[id_key] ] = obj
			else
				objs[i] = obj
			end			
		end
	end
	return objs
end

-- 获取最大的ID
function DatabaseService:getMaxId(tbl_name, where, id_name)
	local maxid = 0
	local where = where or ' 1 '
	local keys = id_name and string_format(' max(%s) as maxid ', id_name) or ' max(id) as maxid '
	local fields = self:select(tbl_name, keys, where)
	if fields then
		maxid = fields:getIntField('maxid')
	end
	return maxid
end

-- 获取记录总条数
function DatabaseService:getRecordCnt(tbl_name, where)
	local cnt = 0
	local where = where or ' 1 '
	local keys = ' count(*) as cnt '
	local fields = self:select(tbl_name, keys, where)
	if fields then
		cnt = fields:getIntField('cnt')
	end
	return cnt
end

-- 根据ENTITY定义数据结构获取数据库对应的数据
-- fields:userdata 		执行数据库查询之后返回的数据
-- entity_cls:table		数据结构定义类
-- return arr_entity:table
function DatabaseService:getDBEntitys(fields, entity_cls)
	if not fields then return end
	
	local arr_entity = {}
	local count = fields:rowCount()
	for i = 1, count do
		local entity = {}
		
		for k, v in pairs(entity_cls) do
			local v_type = type(v)
			if v_type == 'number' then
				entity[k] = fields:getIntField(k)
			elseif v_type == 'string' then
				entity[k] = fields:getStringField(k)
			end
		end
		
		arr_entity[i] = entity
		
		fields:nextRow()
	end
	
	return arr_entity
end

--(支持table类型)
-- 根据ENTITY定义数据结构获取数据库对应的数据
-- fields:userdata 		执行数据库查询之后返回的数据
-- entity_cls:table		数据结构定义类
-- return arr_entity:table
function DatabaseService:getDBEntitys_2(fields, entity_cls)
	if not fields then return end
	
	local arr_entity = {}
	local count = fields:rowCount()
	for i = 1, count do
		local entity = {}
		
		for k, v in pairs(entity_cls) do
			local v_type = type(v)
			if v_type == 'number' then
				entity[k] = fields:getIntField(k)
			elseif v_type == 'string' then
				entity[k] = fields:getStringField(k)
			elseif v_type == 'table' then
				local tmp_data = fields:getStringField(k)
				if tmp_data and string.len(tmp_data) > 0 then
					entity[k] =WorldPacket:decodeData(tmp_data)
				else
					entity[k] = v
				end
			end
		end
		
		arr_entity[i] = entity
		
		fields:nextRow()
	end
	
	return arr_entity
end

--从数据库中读取数据
--@param sql			new出来的stdString, 用于保存sql语句
--@param tbl_name		表名
--@param class_obj		提供字段名的class对象
--@return arr_entity		读取的数据数组
function DatabaseService:getDBEntitysEx(tbl_name, entity_cls, where, keys)
	if not tbl_name or not entity_cls then return nil end
	keys = keys or '*'
	
	sql:assign(string_format("SELECT %s FROM `%s` WHERE %s", keys, tbl_name, where or '1'))
	local fields = DatabaseService:query(sql)
	local arr_entity = nil
	if fields then
		arr_entity = self:getDBEntitys(fields, entity_cls)
	end
	
	return arr_entity
end

function DatabaseService:getDBEntityOne(tbl_name, entity_cls, where)
	if not tbl_name or not entity_cls then return nil end
	
	sql:assign(string_format("SELECT * FROM `%s` WHERE %s", tbl_name, where or '1'))
	local fields = DatabaseService:query(sql)
	
	local count = fields:rowCount()
	for i = 1, count do
		local entity = {}
		
		for k, v in pairs(entity_cls) do
			local v_type = type(v)
			if v_type == 'number' then
				entity[k] = fields:getIntField(k)
			elseif v_type == 'string' then
				entity[k] = fields:getStringField(k)
			end
		end
		
		return entity
	end
end

---[[
--更新操作
--@return 影响记录数/-1
--]]
function DatabaseService:update(tbl_name,obj,where,order_by,limit, no_error)

	assert(tbl_name)
	assert(obj)

	sql:assign("UPDATE `")
	sql:append(tbl_name)
	sql:append('` SET ')
	
	local need_comma = false
	for k,v in pairs(obj) do		
		
		if need_comma then
			sql:append(', ')	
		end
		need_comma = true
		
		sql:append('`')
		sql:append(k)
		sql:append('` = ')
		sql:appendValue(v)
	end	
		
	sql:appendWhere(where)
		
	if order_by then
		sql:append(' ORDER BY ')
		sql:append(order_by)
	end
	
	if limit then	
		sql:append(' LIMIT ')
		sql:append(limit)
	end
	
	local row = database:executeAndGetAffected(sql)	
	if row == -1 then		
		local error_msg = Time:getDateTimeStrNow() .. ' fail to update : ' .. sql:c_str()
		Logger:mysqlError(error_msg)
		if no_error then			
			Logger:error(error_msg)
		else
			error(error_msg)
		end
	end	
	return row

end


---[[
--更新操作
--@return 影响记录数/-1
--]]
function DatabaseService:update2(tbl_name,up_str,where,order_by,limit, no_error)

	assert(tbl_name)
	assert(obj)

	sql:assign("UPDATE `")
	sql:append(tbl_name)
	sql:append('` SET ')
	sql:append(up_str)
	
	sql:appendWhere(where)
	
	if order_by then
		sql:append(' ORDER BY ')
		sql:append(order_by)
	end
	
	if limit then	
		sql:append(' LIMIT ')
		sql:append(limit)
	end
	
	local row = database:executeAndGetAffected(sql)	
	if row == -1 then		
		local error_msg = Time:getDateTimeStrNow() .. ' fail to update : ' .. sql:c_str()
		Logger:mysqlError(error_msg)
		if no_error then			
			Logger:error(error_msg)
		else
			error(error_msg)
		end
	end	
	return row
end

---[[
--删除操作
--@return 删除记录数/-1
--]]
function DatabaseService:delete(tbl_name,where,order_by,limit)

	assert(tbl_name)

	sql:assign("DELETE FROM `")
	sql:append(tbl_name)
	sql:append('` ')
		
	sql:appendWhere(where)
	
	if order_by then
		sql:append(' ORDER BY ')
		sql:append(order_by)
	end
	
	if limit then	
		sql:append(' LIMIT ')
		sql:append(limit)
	end
	
	local row = database:executeAndGetAffected(sql)	
	if row == -1 then
		local error_msg = Time:getDateTimeStrNow() .. ' fail to delete : ' .. sql:c_str()
		Logger:mysqlError(error_msg)
		error(error_msg)
	end	
	return row
end


---[
--执行一条sql语句
--@return bool
--]]
function DatabaseService:execute(sql)
	assert(sql)
	local ret = database:execute(sql)	
	if not ret then
		local error_msg = Time:getDateTimeStrNow() .. ' fail to execute : ' .. sql:c_str()
		Logger:mysqlError(error_msg)
		error(error_msg)
	end
	return ret
end

function DatabaseService:executeEx(sql_str)
	sql:assign(sql_str)
	return self:execute(sql)
end

-- 添加一条记录到DB
-- 不支持BOOL类型的字段
function DatabaseService:addEx(tbl_name, record, is_auto_id, entity_cls)
	sql:assign(string_format('INSERT INTO `%s` ( ', tbl_name))
	local comma = ''
	
	for k, _ in pairs(record) do
		if not entity_cls or entity_cls[k] then
			if comma ~= '' then sql:append(comma) end
			sql:append('`');sql:append(k);sql:append('`')
			if comma == '' then comma = ',' end
		end
	end
	sql:append(') VALUES (')
	
	comma = ''
	for k, value in pairs(record) do
		if not entity_cls or entity_cls[k] then
			local v_type = type(value)
			
			if v_type == 'number' then
				sql:append(string_format('%s %s ', comma, value))
				if comma == '' then comma = ',' end
			elseif v_type == 'string' then
				sql:appendEscapeStr(comma, value)
				if comma == '' then comma = ',' end
			else
				Logger:debug('Utils.db_addEx error field type. type:', k, value, v_type)
			end
		end
	end
	sql:append(')')
	
	if is_auto_id then
		local id = database:insertAndGetId(sql)
		if id == -1 then
			local error_msg = Time:getDateTimeStrNow() .. ' fail to insert : ' .. sql:c_str()
			Logger:mysqlError(error_msg)
			error(error_msg)		
		end	
		return id
	else
		local re = self:execute(sql)
		return re
	end
end

-- 注意：当：value == '' and field的类型==number  则 value = 0
function DatabaseService:updateEx(tbl_name, where, up_params, entity_cls)
	sql:assign(string_format('UPDATE `%s` set ', tbl_name))
	local comma = ''
	
	for k, v in pairs(entity_cls) do
		local v_type = type(v)
		local value = up_params[k]
		
		if value then
			if v_type == 'number' then
				if type(value) == 'string' and string_len(value) == 0 then
					value = 0
				end
				
				sql:append(string_format('%s `%s` = ', comma, k))
				sql:append(value)
				if comma == '' then comma = ',' end
			elseif v_type == 'string' then
				value = tostring(value)
				if string_len(value) > 0 then
					sql:appendEscapeStr(string_format('%s `%s` = ', comma, k), value)
				else
					sql:append(string_format('%s `%s` = ""', comma, k))
				end
				
				if comma == '' then comma = ',' end
			end
		end
	end
	sql:append(string_format(' WHERE %s ', where))
	
	self:execute(sql)
end

-- 替换一个entity对象到DB
function DatabaseService:replaceByEntityCls(tbl_name, record, entity_cls)
	sql:assign(string.format('REPLACE INTO `%s` set ', tbl_name))
	local comma = ''
	
	for k, v in pairs(entity_cls) do
		local v_type = type(v)
		local value = record[k]
		
		if value then
			if v_type == 'number' then
				sql:append(string.format('%s `%s` = ', comma, k))
				sql:append(value)
				if comma == '' then comma = ',' end
			elseif v_type == 'string' then
				sql:appendEscapeStr(string.format('%s `%s` = ', comma, k), value)
				if comma == '' then comma = ',' end
			end
		end
	end
	
	self:execute(sql)
end

