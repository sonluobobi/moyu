--[[
单字段信息
author : guoyin.huang
date : 2015-01-14
--    使用方式
--        1, 在 OneInfoDefs 中定义唯一 ID
--        2, 调用 x2d_getInfo 获取信息
--            ServerCall:b2dCall( 'OneInfoService:x2d_getInfo',  gcid, {id=xxx, callback='xxx'} )
	       ServerCall:m2dCall( 'OneInfoService:x2d_getInfo',gcid, {id=xxx, callback='xxx'} )
--            其中 callback 是回调函数, 例如 'GangBattleService:d2b_onGetApplays'
--        3, 调用 x2d_saveInfo 保存信息
--            ServerCall:b2dCall( 'OneInfoService:x2d_saveInfo', gcid,{id=xxx, info='xxx'} )
	       ServerCall:m2dCall( 'OneInfoService:x2d_saveInfo',gcid, {id=xxx, info='xxx'} )
--            其中 info 是需要保存的字符串
--
--]]

local Time = Time
local table = table

local upvalue_one_infos = {}

OneInfoService = OneInfoService or {}

local DatabaseService
function OneInfoService:onAfterLoadLua()
	DatabaseService = _G.DatabaseService
end

--- 获取信息
-- params
--    id          -- ID
--    callback    -- 回调函数名
--    info        -- 返回的内容
function OneInfoService:x2d_getInfo( sid, params )
	local id = tonumber(params.id)
	local callback = assert( params.callback )
	local arr_info = self:_getOneInfoList()
	params.info = arr_info[id] and arr_info[id].info or ''
	ServerCall:d2xCall( sid, callback, nil, params )
end

--- 保存信息
-- params
--    id          -- ID
--    info:string -- 要保存的内容
function OneInfoService:x2d_saveInfo( sid, params )
	local id = tonumber( params.id )
	local info = tostring( params.info ) or ''
	self:saveInfo( id, info )
end


--- 获取信息
-- @return string/nil
function OneInfoService:getInfo( id )
	assert( id > 0 )
	local arr_info = self:_getOneInfoList()
	return arr_info[id] and arr_info[id].info or ''
end


--- 保存信息
function OneInfoService:saveInfo( id, info )
	if not info then info = '' end
	assert( type(info) == 'string' )
	
	local arr_info = self:_getOneInfoList()
	local obj = arr_info[id] or {}
	if table.isTableEmpty(obj) then
		obj.id     = id
		obj.desc = OneInfoDefs.id2desc[id] or ''
		obj.created = Time:getDateTimeStrNow()
	end
	obj.info = info
	obj.updated = Time:getDateTimeStrNow()
	
	-- 保存数据库
	DatabaseService:insert('tbl_one_info', obj, true)
	
	--保存upvalue信息
	arr_info[id] = obj
end

--- 清空信息
function OneInfoService:clearInfo( id )
	self:saveInfo( id, '' )
end


------------------------------------------------------------------------
--  私有辅助
------------------------------------------------------------------------

--- 获取信息
-- @return {}
function OneInfoService:_getOneInfoList()
	if not table.isTableEmpty(upvalue_one_infos) then 
		return upvalue_one_infos
	end
	
	local fields = DatabaseService:select("tbl_one_info", " * ")
	if fields then
		local count = fields:rowCount()
		for i = 1, count do
			local obj = {}
			obj.id           = fields:getIntField('id')
			obj.info       = fields:getStringField('info')
			obj.desc       = fields:getStringField('desc')
			obj.created = fields:getStringField('created')
			obj.updated = fields:getStringField('updated')
			
			upvalue_one_infos[obj.id] = obj
			
			fields:nextRow()
		end
	end
	return upvalue_one_infos 
end


