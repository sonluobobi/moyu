--[[
竞技场CTRL
author : guoyin.huang
date : 2016-07-08
]]--

local string_format = string.format
local DatabaseService = DatabaseService
local table_concat = table.concat
local array_slice = array.array_slice
local math = math

GlobalArenaCtrl = GlobalArenaCtrl or {}
local GlobalArenaCtrl = GlobalArenaCtrl

local GlobalArenaPKLog = {
	arena_id = 0,
	nick = '',
	passive_arena_id = 0,
	passive_arena_nick = '',
	is_win = 0,
	score = 0,
	created = '',
}

local GlobalArenaInfo = {
	id = 0,	
	-- 区域信息
	group_id = 0,	-- 所在跨服分组
	gcid = 0,		-- GCID
	area_id = 0, 	--	大区ID
	area_name = '',	--  服务器名
	cid = 0,		-- 	角色ID（用于发奖使用）
	player_id = 0,	--  
	prof = 0,
	gender = 0,
	ch_nick = '',		--  角色昵称
	gang_title = '',--  军团名称
	badge_id = 0,		--  军团
	gang_uk = '',	-- 	军团unique_key
	score = 0,		--  所得积分
	ch_detail = '',	--  角色属性
	unique_key = '',--  unique_key
	created = '',	--  创建时间
	updated = '',	--  数据更新时间
	honour = 0,		--  累积获得的荣誉
}


local GlobalArenaTop = {
	id = 0,	
	-- 区域信息
	group_id = 0,	-- 所在跨服分组
	gcid = 0,		-- GCID
	area_id = 0, 	--	大区ID
	area_name = '',	--  服务器名
	cid = 0,		-- 	角色ID（用于发奖使用）
	player_id = 0,	--  
	prof = 0,
	gender = 0,
	ch_nick = '',		--  角色昵称
	gang_title = '',--  军团名称
	badge_id = 0,		--  军团
	score = 0,		--  所得积分
	unique_key = '',--  unique_key
	rank = 0,		--  排名
	created = '',	--  创建时间
	updated = '',	--  数据更新时间
	honour = 0,		--  累积获得的荣誉
}

do
	local tomap_opcode = opCodes.D2M_ARENA_LOAD
	function GlobalArenaCtrl.m2d_load(sid, packet)
		-- 获取参数
		local arr_params, packet_id = packet:readParams()
		-- 先加载机器人数据
		GlobalArenaCtrl:loadRobotDetails(sid, packet_id)

		-- 加载角色积分数据（带排名信息）
		GlobalArenaCtrl.localChDetail( sid, packet_id )

		-- 往MAP加载排行榜数据
		GlobalArenaCtrl:loadToplistForMap( sid, packet_id )

	end
	i_opHandlers[opCodes.M2D_GLOBAL_ARENA_LOAD] = GlobalArenaCtrl.m2d_load
	
	-- 加载竞技场角色数据
	function GlobalArenaCtrl.localChDetail( sid, packet_id )
		local arena_robot_details = DatabaseService:getDBEntitysEx('tbl_global_arena', GlobalArenaInfo, ' 1 ')
		
		local total_num = arena_robot_details and #arena_robot_details or 0
		if total_num <= 0 then 
			return 
		end

		-- 分批发到map
		local page = math.ceil(total_num/10)
		local index = 1
		for i=1, page do
			local arena_ch_details = {}
			for pos=(i-1) * 10 + 1, i*10 do
				if arena_robot_details[pos] then 
					arena_robot_details[pos].created = Time:getSecondsByDateTimeStr( arena_robot_details[pos].created )
					table.insert(arena_ch_details, arena_robot_details[pos])
				end
			end
			local tomap_data = {}
			tomap_data.opcode = tomap_opcode
			tomap_data.arena_ch_details = arena_ch_details
			WorldPacket:dbSendOK(sid, tomap_data, packet_id)				
		end
	end
	-- 加载竞技场机器人数据
	function GlobalArenaCtrl:loadRobotDetails(sid, packet_id)
		
		local where = string_format(' (id >= %d and id <= %d) ', RobotDefs.GLOBAL_AREANA_ROBOT_CID_START, RobotDefs.GLOBAL_AREANA_ROBOT_CID_END)
		local arena_robot_details = DatabaseService:getDBEntitysEx('tbl_player_global_arena', ChFieldsForArena, where)
		
		local total_num = arena_robot_details and #arena_robot_details or 0
		if total_num <= 0 then 
			Logger:info('[GlobalArenaCtrl.loadChDetails] 获取到的竞技场角色属性为空')
			return 
		end

		GlobalArenaCtrl:_formatArenaChDetails(arena_robot_details)
		
		local tomap_data = {}
		tomap_data.opcode = tomap_opcode
		tomap_data.arena_robot_details = arena_robot_details
		WorldPacket:dbSendOK(sid, tomap_data, packet_id)
	end

	-- 加载排行榜数据
	function GlobalArenaCtrl:loadToplistForMap( sid, packet_id )
		local arena_robot_details = DatabaseService:getDBEntitysEx('tbl_global_arena_rank', GlobalArenaTop, ' 1 ')
		
		local total_num = arena_robot_details and #arena_robot_details or 0
		if total_num <= 0 then 
			return 
		end

		-- 分批发到map
		local page = math.ceil(total_num/10)
		local index = 1
		for i=1, page do
			local arena_ch_details = {}
			for pos=(i-1) * 10 + 1, i*10 do
				table.insert(arena_ch_details, arena_robot_details[pos])
			end
			local tomap_data = {}
			tomap_data.opcode = tomap_opcode
			tomap_data.toplist = arena_ch_details
			WorldPacket:dbSendOK(sid, tomap_data, packet_id)				
		end
	end
end

-- BASE从DB加载排行榜
do
	local GlobalArenaTop = {
		unique_key = '',	--uk
		rank = 0,			--排名
		group_id = 0,		--所在分组
		area_id = 0,		--所在大区
	}

	local tobase_opcode = opCodes.X2B_GLOBAL_ARENA_LOAD_TOPLIST
	function GlobalArenaCtrl.b2d_loadToplist( sid, packet)
		local arr_params, packet_id = packet:readParams()
		local toplist = DatabaseService:getDBEntitysEx('tbl_global_arena_rank', GlobalArenaTop, ' rank <= 200 ')
		
		local total_num = toplist and #toplist or 0
		if total_num <= 0 then 
			Logger:info('[GlobalArenaCtrl.loadChDetails] 获取到的竞技场角色属性为空')
			return 
		end

		ServerCall:d2xCall(sid, 'GlobalArenaService:loadTopList', 0, toplist)
	end
	i_opHandlers[opCodes.B2D_GLOBAL_ARENA_LOAD_TOPLIST] = GlobalArenaCtrl.b2d_loadToplist
end

-- 获取竞技场PK日志
function GlobalArenaCtrl.m2d_getArenaPKLog(sid, packet)
	-- 获取参数
	local arr_params, packet_id = packet:readParams()
	local arena_id = arr_params.arena_id
	local gcid = arr_params.gcid
	local callback = arr_params.callback
	-- 仅仅返回竞技场被PK日志
	local where = 'passive_arena_id = ' .. arena_id .. ' ORDER BY created desc LIMIT 0, ' .. GlobalArenaDefs.PK_LOG_NUM
	local arena_pk_logs = DatabaseService:getDBEntitysEx('tbl_log_global_arena_pk', GlobalArenaPKLog, where)
	-- 把创建时间改成int，节省传输流量
	if arena_pk_logs then
		for _, arena_pk_log in pairs(arena_pk_logs) do
			arena_pk_log.created = Time:getSecondsByDateTimeStr(arena_pk_log.created)
		end
	end
	local data = {}
	data.arena_id = arena_id
	data.gcid = gcid
	data.historys = arena_pk_logs or {}
	ServerCall:d2xCall(sid, callback, gcid, data)
end
i_opHandlers[opCodes.M2D_GLOBAL_ARENA_GET_PK_LOG] = GlobalArenaCtrl.m2d_getArenaPKLog

-- 保存竞技场PK日志
function GlobalArenaCtrl.m2d_saveArenaPKLog(sid, packet)
	-- 获取参数
	local arr_params, packet_id = packet:readParams()
	local data = arr_params.data
	data.created = Time:getDateTimeStrNow()
	DatabaseService:addEx('tbl_log_global_arena_pk', data, true, GlobalArenaPKLog)
end
i_opHandlers[opCodes.M2D_GLOBAL_ARENA_SAVE_PK_LOG] = GlobalArenaCtrl.m2d_saveArenaPKLog

-- 创建竞技场角色
function GlobalArenaCtrl.m2d_saveChArenaInfo(sid, packet)
	-- 获取参数
	local arr_params, packet_id = packet:readParams()
	local data = arr_params.data
	data.created = Time:getDateTimeStrNow()
	data.updated = data.created
	data.honour = data.honour or 0
	DatabaseService:addEx('tbl_global_arena', data, true, GlobalArenaInfo)
end
i_opHandlers[opCodes.M2D_GLOBAL_ARENA_SAVE] = GlobalArenaCtrl.m2d_saveChArenaInfo

-- 更新竞技场角色数据
function GlobalArenaCtrl.m2d_updatechArenaInfo( sid, packet )
	-- 获取参数
	local arr_params, packet_id = packet:readParams()
	local data = arr_params.data
	local arena_id = arr_params.arena_id
	data.updated = Time:getDateTimeStrNow()
	DatabaseService:update('tbl_global_arena',data,' id = ' .. arena_id)
end
i_opHandlers[opCodes.M2D_GLOBAL_ARENA_UPDATE] = GlobalArenaCtrl.m2d_updatechArenaInfo

-- 格式化机器人数
function GlobalArenaCtrl:_formatArenaChDetails(arena_robot_details)
	for _, arena_ch_detail in pairs(arena_robot_details) do
		-- 外形相关
		local ch_appear = arena_ch_detail.appear
		if ch_appear and string.len(ch_appear) > 3 then 
			ch_appear = WorldPacket:decodeData(ch_appear)
		else
			ch_appear = nil
		end

		if ch_appear then
			arena_ch_detail.wuqi_eid = ch_appear.weaponid or 0
			arena_ch_detail.yifu_avatar_eid = 0
			arena_ch_detail.qihun_wuqi = ch_appear.qihun_wuqi or 0
			arena_ch_detail.qihun_yifu = ch_appear.qihun_yifu or 0
			arena_ch_detail.full_jl_lev = 0
			arena_ch_detail.shenbing_eid = ch_appear.shenbing or 0
			arena_ch_detail.sb_skill_level = ch_appear.sb_skill_level or 0
		else
			arena_ch_detail.qihun_wuqi =  0
			arena_ch_detail.qihun_yifu =  0
			arena_ch_detail.wuqi_eid, arena_ch_detail.yifu_avatar_eid = 0, 0
			arena_ch_detail.full_jl_lev = 0
			arena_ch_detail.shenbing_eid = 0
			arena_ch_detail.sb_skill_level = 0
		end
		arena_ch_detail.item_strongs_info = nil
		arena_ch_detail.items = nil
		arena_ch_detail.appear = nil
		
		-- 幻兽数据
		local pets_info = arena_ch_detail.pets
		if (type(pets_info) == "string" and string.len(pets_info) > 1) then
			pets_info = WorldPacket:decodeData(pets_info)
			local fight_ch_pet_id = pets_info.fight_ch_pet_id
			local heti_ch_pet_ids = pets_info.heti_ch_pet_ids
			local ch_pets = pets_info.ch_pets
			local new_ch_pets = {}
			if fight_ch_pet_id and fight_ch_pet_id > 0 then
				new_ch_pets[fight_ch_pet_id] = ch_pets[fight_ch_pet_id]
			end
			if heti_ch_pet_ids then
				for _, ch_pet_id in pairs(heti_ch_pet_ids) do
					new_ch_pets[ch_pet_id] = ch_pets[ch_pet_id]
				end
			end
			pets_info.ch_pets = new_ch_pets
			
			arena_ch_detail.pets = WorldPacket:encodeData(pets_info)
		end
	end
end

-- 生成排行榜
function GlobalArenaCtrl.genToplist( sid, packet )	
	local arr_params, packet_id = packet:readParams()
	local base_sid= arr_params.base_sid
	-- 清空排行榜表
	local del_sql = 'delete from tbl_global_arena_rank'
	DatabaseService:executeEx(del_sql)

	local group_ids_sql = 'select distinct group_id as group_id from tbl_global_arena'
	local group_ids_fields = DatabaseService:selectEx(group_ids_sql)
	if group_ids_fields then 
		local arr_group_ids = DatabaseService:getDBEntitys(group_ids_fields, {group_id=0})
		for _, group_info in pairs(arr_group_ids) do
			-- 重新生成排行榜
			local rank_sql = [[insert into tbl_global_arena_rank
				(id, ch_nick, group_id, area_id, area_name, cid, player_id, gcid, gender, prof, unique_key, gang_title, badge_id, score, honour, rank, updated, created)
				select * from (Select g.id as id, g.ch_nick as ch_nick, g.group_id as group_id, g.area_id as area_id, g.area_name as area_name, g.cid as cid, g.player_id as player_id,  g.gcid as gcid, g.gender as gender, g.prof as prof, g.unique_key as unique_key, g.gang_title as gang_title, g.badge_id as badge_id, g.score as score,g.honour as honour, (@rowNum:=@rowNum+1) as rank, g.updated as updated, g.created as created
				From tbl_global_arena g,
				(Select (@rowNum :=0) ) b where g.group_id = %d
				Order by g.score desc, g.created ) tmp
			]]
			DatabaseService:executeEx(string.format(rank_sql, group_info.group_id))		
		end
	end

	-- 清空竞技场表
	local del_arena_sql = 'delete from tbl_global_arena'
	DatabaseService:executeEx(del_arena_sql)

	-- 清空战斗历史表
	local del_arena_pk_history = 'delete from tbl_log_global_arena_pk'
	DatabaseService:executeEx(del_arena_pk_history)
end
i_opHandlers[opCodes.M2D_GLOBAL_ARENA_GEN_TOPLIST] = GlobalArenaCtrl.genToplist