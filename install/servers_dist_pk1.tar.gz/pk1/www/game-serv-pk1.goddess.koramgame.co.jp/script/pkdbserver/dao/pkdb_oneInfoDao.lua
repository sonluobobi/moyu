--[[
单字段信息
author : guoyin.huang
date : 2015-01-14
--]]


OneInfoDao = {
  infos = nil,
}
