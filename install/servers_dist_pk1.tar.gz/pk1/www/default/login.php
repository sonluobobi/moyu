<?php
	$login_url = trim($_POST['login_url']);
	if (!$login_url) $login_url = $_GET['login_url'];
	if (!$login_url)
	{
		file_put_contents('/data/moyu/log/nginx-error-intoroot', date('Ymd H:i:s') . "  " . $_SERVER['REMOTE_ADDR'] . "  " . $_SERVER['HTTP_HOST'] . "\n", FILE_APPEND);
		die();
	}
	
	$isinnercall = $_POST['isinnercall'] ? $_POST['isinnercall']:$_GET['isinnercall'];
	if ($isinnercall == '1') die();
	if ($_SERVER['REMOTE_ADDR'] == '52.77.192.93' || $_SERVER['REMOTE_ADDR'] == '127.0.0.1') die();
	
	$data = http_build_query($_POST);
	$opts = array(  
		'http'=>array(  
			'method'=>"POST",  
			'content' => $data,  
		)
	);
	$cx_context = stream_context_create($opts);
	$login_url = $login_url . ((strpos($login_url, '?') > 0) ? '&':'?') . 'isinnercall=1';
	echo file_get_contents($login_url, false, $cx_context);

	file_put_contents('/data/moyu/log/nginx-ok-intoroot', date('Ymd H:i:s') . "  " . $_SERVER['REMOTE_ADDR'] . "  " . json_encode($_POST) . "\n", FILE_APPEND);
?>
