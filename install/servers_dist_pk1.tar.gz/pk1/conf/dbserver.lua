
assert(confDir, "config dir not set")
dofile(confDir .. 'common.lua')

--Mysql.username = ''
--Mysql.password = ''


LuaThreadCount = MapserverNum
RegionThreadCount = MapserverNum
RegionPaketCountMax = 1000
LuaMaxProcUsTime = 10000


--语音服没有数据库请求需求
if ProxyServerType==1 then
  RegionThreadCount=1
  LuaThreadCount=1
end

Log.Path= Log.ParentPath .. "dbserver.log"

if not g_bTestServer then
	Log.Level = 2
end

Log.NeedGlobalLock = 1

InternalNetThreadNum = MapserverNum + 1
--vchat and center
if ProxyServerType==1 or ProxyServerType==3 then
  InternalNetThreadNum=1
end

