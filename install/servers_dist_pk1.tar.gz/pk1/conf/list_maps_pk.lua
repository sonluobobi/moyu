
MapServers ={}
MapServers[1] =
{
	{MapId="20001-20099",Shared='0'}, --野外
	{MapId="40001-40999",Shared='0'}, --副本
	{MapId="50001-50099",Shared='0'}, --副本
	{MapId="51000-51099",Shared='0'}, --天魔
	{MapId="90003-90006",Shared='0'},--帝国
	{MapId="80001-80009",Shared='0'},--3V3
	{MapId="60001",Shared='0'},    --军团战
	{MapId="60002",Shared='0'}, --军团战	
	{MapId="90011",Shared='0'}, --诸神黄昏
	{MapId="90007-90010",Shared='0'}, --末日之战
	{MapId="60018-60019",Shared='0'}, --丧尸场景	
	{MapId="60020-60022",Shared='0'}, --爱情圣殿场景   
	{MapId="60023-60030",Shared='0'}, --军团战役场景 
}


