all_servers={}
