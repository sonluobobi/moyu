GlobalServerConfNames=
{
 
       [3] = 'centerservers',
       [2] = 'pkservers',

        [1] = 'vchatservers',
}

