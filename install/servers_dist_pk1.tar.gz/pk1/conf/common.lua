dofile (confDir .. 'private.lua')
---其他监听端口递增***
local dbPort = ProxyPort+1
local basePortMaps = ProxyPort+3
local basePortCommanders = ProxyPort+4
local basePortProxy= ProxyPort+5

local pk=''
if ProxyServerType>0 then
  pk='pk'
end
if ProxyServerType==1 then
  pk='chat'
end
if ProxyServerType==3 then
  pk='center'
end

if ProxyServerType==1 then
   voiceDataDir=LogDirBase..'voicedata/'
end   

--脚本目录
ScriptDir = GameServDir .. 'script/'
--
--阻挡文件目录
MapDataScenePath = GameServDir .. 'scenes/%d.shield'

--proxy 监听 client
ProxyServer =
{
	Host=ProxyServerHost,
	Port=ProxyPort,
	ClientLogoutDelay=60, --停机维护公告时间 (秒）
}



       

--db 监听 base和map
DbServer =
{
	Host=DbServerHost,
	Port=dbPort,
	ScriptDir=pk..'dbserver',
}

--base监听 proxy和maps
BaseServer =
{
	Host=BaseServerHost,
	ProxyPort=basePortProxy , MapPort=basePortMaps , CommanderPort=basePortCommanders,
	PlayerLogoutTimeout=180, --离线缓冲时间
	ScriptDir=pk..'baseserver',
}
if ProxyServerType>0 then
    BaseServer.PlayerLogoutTimeout=170 --pk should closed before normal game server
end
        

MapServer =
{
	ScriptDir=pk..'mapserver',
}

--应用程序全局配置
IsDeamon=0

-- Epoll设置
-- TimeOut:网络线程每次等待事件的最大时间（ms）
-- SocketHolderSize:最大允许的fd上限值, 不配置默认值为65535
-- EachEventSize:每次epoll允许响应的最大事件数.不配置默认值为4096
Epoll = {TimeOut = 50, --[[SocketHolderSize = 65535, EachEventSize = 4096 --]]}


-- 主线程每次循环睡眠的时间（ms）
ProcessWaitTime = 30


-- 是否立即处理网路包
IsImmediately = 0


-- Client的KeepAlive设置(秒)
KeepAliveSetting = { MaxTimeSpan=300 , EachCheckNum=1000}


-- server之间的重连(ms)
Reconnect  ={TimeSpan = 1000, Count = 1000}
if ProxyServerType>0 then
   Reconnect.TimeSpan=200
end

--日志配置 Path字段在子模块配置
--Level: 0-DEBUG, 1-LOOSE, 2-INFO, 3-WARN, 4-ERROR
--BufSize: 缓冲区大小，不需要时设置为0， 单位为M

Log =
{
	Level=3,BufSize=30,ParentPath=LogDir,  FileNum=30 , FileSize=100 , --Path='',
}
if g_bTestServer then
	Log.Level=0
	Log.BufSize=0
end


--mapserver 数量 普通服4个 语音服1个  pk服6个
MapserverNum = 6
if ProxyServerType==1 then
--语音服1个map
MapserverNum=1
end
if ProxyServerType==3 then
---中心服 1个map
MapserverNum=1
end

if ProxyServerType==0 then
---游戏服:4
MapserverNum=4

---测试游戏服只要开2个map
if g_bTestServer then
	MapserverNum=2
end

end

if g_bPressTest then
  --压力测试:6
  MapserverNum = 6 
end


ClientNetThreadNum = 0
InternalNetThreadNum = MapserverNum + 1

         
if ProxyServerType==1 then
        ----语音服务器的proxy有lua脚本，其他服务器都没有
        ProxyServer.ScriptDir='chatserver'
        --语音服务器 允许大包
        if g_bTestServer then
          ProxyServer.MaxClientPkgSize=1024*512
        end
end




if  ProxyServerType>0 then

	local strCfgDir=confDir
	local strCfg1=strCfgDir..'pk_sever_init.lua'
	dofile(strCfg1)

end

--Debug={
--bDebuging=1
--}

