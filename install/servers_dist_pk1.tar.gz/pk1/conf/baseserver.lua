
assert(confDir, "config dir not set")
dofile(confDir .. 'common.lua')

InternalNetThreadNum = MapserverNum + 2

if not g_bTestServer then
	Log.Level = 2
end

Log.Path= Log.ParentPath .. "baseserver.log"
