--pk服才需要加载这些

--print('ProxyServerType:',ProxyServerType,confDir)

if ProxyServerType>0 then

dofile(confDir ..'global_server_conf_names.lua')
GlobalServerConfName = GlobalServerConfNames[ProxyServerType]
local strCfg2=confDir .. GlobalServerConfName..'.lua'
dofile(strCfg2)
PKServers =  all_servers[ARENA_ID]
Global_Group2Info=PKServers

--print('Global_Group2Info:',Global_Group2Info)
--print('PKServers:',PKServers)

end
