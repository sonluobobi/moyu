
assert(confDir, "config dir not set")
dofile(confDir ..'common.lua')

local list_map_file="list_maps.lua"
if ProxyServerType>0 then
	list_map_file="list_maps_pk.lua"
end
if g_bPressTest then
	list_map_file="list_maps_ptest.lua"
end
dofile(confDir..list_map_file)

local last_mapserver = MapServers[ #MapServers ]

--分压
local add_num = MapserverNum - #MapServers
for i=1,add_num do
	table.insert(MapServers,last_mapserver)
end

InternalNetThreadNum=2
Log.Path= Log.ParentPath .. "mapserver.%d.log"

if not g_bTestServer then
	Log.Level = 2
end

