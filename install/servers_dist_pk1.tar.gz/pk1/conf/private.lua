--运行标识
name='pk1'

--0:game 1:voiceChat 2:pk
ProxyServerType = 2

--游戏目录
GameServDir = '/data/moyu/pk1/www/game-serv-pk1.goddess.koramgame.co.jp/'

LogDirBase='/data/moyu/pk1/'

LogDir = LogDirBase..'log/'

--proxy端口
ProxyPort=40511 

--服务器自身ip pk服才需要这个


ProxyServerIp='161.202.150.208'

--大区id
ARENA_ID=901
VOUCH_AREA_CODE=4162901
--语言
LANG='en'

--游戏服名
GAME_SERV_NAME = name
--产品id
PRODUCT_ID=4162

--开服时
SERVER_OPEN_DATE = 20160728


--mysql配置
Mysql =
{
	hostname="127.0.0.1", 
	database="moyu_pk1", 
	port="3306",
        username="moyu",
        password="NoNeed4Pass32768"

}

--平台配置
RegionServerToken="kXVd8Z8Y.HLo2ks1TwYgrPooTgdFCF5M9XpU_B8.EoD2-yAB_N8josb1Q87LSJsu1JTAXlDysseg4u7sCf447kKnb.pSN26pnzlhZWhxqsDTVH9v98MWfDTQJIIaVfIn_W1Be_1Csst8FHr1hUA3FxV5MkCae53O.B-JTd.LB1c0"

--------------------------
BaseServerHost='127.0.0.1'
DbServerHost='127.0.0.1'
ProxyServerHost='127.0.0.1'

WebServerIp='127.0.0.1'

GameServerIp = '127.0.0.1'


GAME_TIME_ZONE=9+24

MaxOnlinePlayerNum = 12000       --最大在线人数
MaxWaitPlayerNum = 2000         --最大排队人数

DOMAIN_SUFFIX='.goddess.koramgame.co.jp'


RegionServerDomain="http://region.koramgame.co.jp/index.php"
RegionServerDomainAddGold="http://api.m.koramgame.co.jp"



