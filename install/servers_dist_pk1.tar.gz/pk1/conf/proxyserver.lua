
assert(confDir, "config dir not set")
dofile(confDir .. '/common.lua')

BaseServers = 
{
	BaseServer	
}



Log.Path= Log.ParentPath .. "proxy.log"


IsImmediately = 1

SocketEachProcNum = 3
MaxDelayPacketNum = 1000 ----单个socket最大积包数 超过则断开连接

ClientNetThreadNum = MapserverNum
InternalNetThreadNum = 1
if ProxyServerType>0 then
  ---pk服 会连多个服 需要增加内部通信线程数
  InternalNetThreadNum=3
end

if not g_bTestServer then
	Log.Level = 3
end



